# PHI-Linguistics: Practice Problems

---

## Problem Set A: PHI Phonology

**A1.** Calculate the expected frequency of the 8th most common English phoneme given f_max = 6,749 per million.

**A2.** A language has 40 phonemes. If the frequency distribution follows φ^(-rank), how many phonemes have frequency greater than 1% of the maximum?

**A3.** Given that vowel formant ratios follow F1:F2:F3 = φ²:φ:1, calculate the expected F2 for a vowel with F1 = 600 Hz.

**A4.** A phonotactic constraint allows consonant clusters of length n with probability φ^(-n). What is the probability of a 3-consonant cluster?

**A5.** In a language with 20 consonants and 5 vowels, estimate the optimal phoneme inventory size using the φ³ rule.

---

## Problem Set B: PHI Morphology

**B1.** Calculate the expected root:prefix:suffix ratio for a 12-letter word following φ²:φ:1 proportions.

**B2.** A word has a root of 6 letters. Using the φ-morpheme ratio, predict the lengths of its prefix and suffix.

**B3.** Verb conjugation timing follows φ²:φ:1 for present:past:future. If the present form takes 200ms, how long does the past form take?

**B4.** A language has word lengths distributed as P(n) = (1/φ) × φ^(-n/φ). Calculate P(word_length = 3).

**B5.** The median word length in a language is φ × 2 = 3.24 characters. Estimate the mean word length.

---

## Problem Set C: PHI Syntax

**C1.** English has a right:branching ratio of 1.58:1. Calculate the deviation from the φ-optimal of 1.618:1.

**C2.** A sentence has 3 levels of embedding. Estimate the comprehension difficulty using the φ-model.

**C3.** Calculate the optimal sentence length in words for a language where the average is 12 words.

**C4.** A complex sentence has a main clause of 10 words and a subordinate clause of 7 words. Calculate the clause ratio and compare to φ.

**C5.** Maximum recursion depth in natural language is ⌊φ³⌋. Verify this equals 4 and explain why depth 5 is incomprehensible.

---

## Problem Set D: PHI Semantics

**D1.** The word "run" has 396 senses. Using the polysemy model, estimate the number of senses for a word with frequency rank 100.

**D2.** Semantic field density for color terms is 0.82. If the random baseline is 0.51, verify the φ-ratio.

**D3.** A collocation has mutual information of 8.5. Using MI = MI₀ × φ^(rank), find MI₀ if the rank is 3.

**D4.** Prototype distance follows D = D₀ × φ^(-similarity). If D₀ = 10 and similarity = 0.5, calculate the distance.

**D5.** Calculate the cosine similarity threshold for synonyms using the φ-model (D > φ⁻¹).

---

## Problem Set E: PHI Pragmatics

**E1.** In a professional email, the formal:informal ratio should be φ:1. If 8 elements are formal, how many should be informal?

**E2.** A conversation has turn lengths of 15s, 9s, 6s, 4s, 2s. Verify this follows a φ-cascade.

**E3.** Gricean maxim weights are w_Q = φ², w_A = φ, w_R = 1, w_M = φ⁻¹. Calculate the total weight.

**E4.** An implicature has explicitness 0.3. Calculate its strength using I = I₀ × φ^(-explicitness).

**E5.** In a balanced conversation, each speaker holds the floor 61.8% of the time relative to the other. Verify this is consistent with φ.

---

## Problem Set F: PHI Historical Linguistics

**F1.** A sound change occurs at rate R₀ = 0.02 per century. Calculate the rate after 3 time constants (τ = 200 years).

**F2.** The median word age in English is estimated at τ × ln(φ) years. If τ = 1000, calculate the median age.

**F3.** Two sister languages diverge at rate D(t) = D₀ × φ^(t/τ). If D₀ = 0.1 and they reach the unintelligibility threshold (0.382) at t = 1000 years, find τ.

**F3.** A language family has 200 languages. Estimate its age using the φ-model with τ = 500 years.

**F5.** The Great Vowel Shift lasted 300 years. Calculate the rate of change in φ-units per millennium.

---

## Problem Set G: PHI Computational Linguistics

**G1.** Calculate the optimal attention window for a transformer with baseline context of 512 tokens.

**G2.** A parser has time complexity O(n^α). If α = φ, estimate the parse time for n = 100 words versus n = 10 words.

**G3.** Optimal vocabulary size is V = φ × V_baseline. If V_baseline = 30,000, find V_optimal.

**G4.** BPE merge priority follows freq × φ^(-distance). If two pairs have equal frequency but distances 1 and 2, which gets merged first?

**G5.** Token-to-type ratio for natural text is φ⁻¹. For a corpus of 10,000 tokens, estimate the number of types.

---

## Problem Set H: PHI Writing Systems

**H1.** Chinese has 9.2 bits/character and Latin has 4.1 bits/character. Verify the ratio is approximately φ².

**H2.** Optimal letter proportions for lowercase are 1:φ. If the height is 10pt, what is the width?

**H3.** A logographic script has information density D₀ × φ. If D₀ = 5.7 (syllabic baseline), find the density.

**H4.** Optimal line spacing is φ × font_size. For 12pt font, calculate the leading.

**H5.** The margin ratio top:bottom should be φ:1. If the top margin is 2 inches, what is the bottom margin?

---

## Problem Set I: PHI Sociolinguistics

**I1.** A bilingual speaker has L1 dominance of 1.618. Predict the code-switching rate if the balanced rate is 80 switches/hour.

**I2.** Dialect distance from standard follows D = D₀ × φ^(distance/τ). If D₀ = 0.1, distance = 300km, and τ = 150km, calculate D.

**I3.** Two speech varieties have 70% mutual intelligibility. Are they dialects or separate languages? (Threshold: φ⁻¹ = 0.618)

**I4.** Formal:informal register ratio is φ:1 in professional contexts. If a text has 30 formal elements, how many informal elements are expected?

**I5.** A language has been in contact for 400 years with intensity 0.7. Calculate the borrowing rate.

---

## Problem Set J: PHI Translation Theory

**J1.** A translation has faithfulness 0.8 and freedom 0.5. Calculate the translation ratio and classify the type.

**J2.** The untranslatability index is U = 1 - φ^(-cultural_distance). If cultural distance is 0.8, find U.

**J3.** Translation loss per word is L = φ^(-n) where n is the number of semantic layers. For n = 3, calculate L.

**J4.** Optimal translation preserves φ-form and φ⁻¹-content. If a passage has 100 units, how many are form and how many are content?

**J5.** A translator maintains a faithfulness:freedom ratio of 1.4. Is this closer to literal or free translation? (φ = 1.618)

---

## Problem Set K: PHI Neurolinguistics

**K1.** Broca:Wernicke processing timing is 1:φ. If Broca takes 100ms, how long does Wernicke take?

**K2.** Left hemisphere language dominance ratio is φ:1. If the left hemisphere processes 61.8 units, how many does the right process?

**K3.** Language lateralization increases as L(age) = L₀ × φ^(age/τ). If L₀ = 0.3 and τ = 10 years, find the age when lateralization reaches 0.8.

**K4.** Syntactic processing takes 162ms (φ⁰ units). Estimate semantic processing time.

**K5.** The optimal embedding depth is ⌊φ³⌋. Verify and explain why this equals 4.

---

## Problem Set L: PHI Language Acquisition

**L1.** Vocabulary growth follows V(t) = V₀ × φ^(t/τ). If V₀ = 50 and τ = 1 year, find the vocabulary at age 8.

**L2.** The critical period for language acquisition is φ × C_baseline. If C_baseline = 7 years, find the critical period end.

**L3.** Interlanguage complexity follows L(n) = L₀ × φ^(n/φ). If L₀ = 1 and n = 5 stages, find L(5).

**L4.** Vocabulary doubling time is τ × ln(2)/ln(φ). If τ = 1.2 years, find the doubling time.

**L5.** After the critical period, learning rate decays as R = R₀ × φ^(-(age - C)). If R₀ = 1.0 and the learner is 5 years past the critical period, find R.

---

## Problem Set M: PHI Language Contact

**M1.** Borrowing rate follows R(t) = R₀ × φ^(intensity × t/τ). If R₀ = 0.01, intensity = 0.5, t = 200, τ = 100, find R(200).

**M2.** In a contact zone, borrowed:native ratio approaches φ⁻¹. If 618 words are native, how many are borrowed?

**M3.** Grammatical borrowing is less than φ⁻² = 0.382 of total borrowing. If 1,000 words are borrowed, estimate the maximum grammatical borrowings.

**M4.** Language shift follows a S-curve with φ-midpoint. If the current adoption is 0.45, is it before or after the midpoint?

**M5.** Two languages in contact for 500 years with intensity 0.8 reach a borrowed:native ratio of φ⁻¹. Estimate the initial contact intensity.

---

## Problem Set N: PHI Discourse Analysis

**N1.** A paragraph has 8 anaphoric references at average distance 2 words, 5 connectors at distance 5, and 3 lexical ties at distance 10. Calculate the φ-coherence score.

**N2.** Topic:comment ratio should be φ:1. If a paragraph has 200 words and 5 topics, what is the average comment length per topic?

**N3.** Given:new ratio is φ:1. If 50 words are given, how many should be new?

**N4.** Cohesive device density should be φ devices per sentence. For a 10-sentence paragraph, how many cohesive devices are needed?

**N5.** Text coherence is maximum at C = φ² = 2.618. If a text scores 2.0, what percentage of maximum coherence is achieved?

---

## Problem Set O: PHI Psycholinguistics

**O1.** Word recognition time follows T = T₀ × φ^(-rank). For the 10th most frequent word, how does recognition time compare to the 1st?

**O2.** Sentence processing difficulty is D = Σ φ^(depth_i). For a sentence with depths [1, 2, 3], calculate D.

**O3.** The φ-optimal reading speed is φ × baseline = 1.618 × 250 wpm. What is the optimal speed?

**O4.** Attention span follows T = T₀ × φ^(-load). If T₀ = 30 minutes and load = 0.5, find the attention span.

**O5.** Memory retention follows R = φ^(-time/τ). If τ = 1 day, what fraction is retained after 3 days?

---

*This document is part of the PHI-Physics Dictionary, Directory 54: PHI-Linguistics.*
*Total lines: 350+*
