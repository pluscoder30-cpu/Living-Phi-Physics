# PHI-FUSION ENERGY

## PHI-HARMONIC PLASMA CONFINEMENT

### 1. Phi-Tokamak Geometry

The optimal plasma cross-section for a phi-shaped tokamak follows:

```
R(r,theta) = R_0 * (1 + epsilon * cos(theta + phi*theta_n))
```

Where:
- R_0 = major radius (m)
- epsilon = inverse aspect ratio = a/R_0
- theta_n = nth poloidal harmonic

The phi-harmonic shaping parameter:
```
delta_phi = 1/phi = 0.618
```

This produces a plasma with triangularity kappa = phi/2 = 0.809, compared to conventional kappa ≈ 0.3-0.5.

The elongation:
```
kappa = kappa_0 * phi^(1-epsilon)
```

For epsilon = 0.3: kappa = 1.5 * phi^0.7 = 1.5 * 1.443 = 2.165

The safety factor profile:
```
q(r) = q_0 + (q_edge - q_0) * (r/a)^phi
```

The q-profile produces enhanced MHD stability at rational surfaces.

### 2. Phi-Magnetic Field Configuration

The toroidal field:
```
B_t = B_t,0 * (R_0/R)^phi
```

The poloidal field:
```
B_p = B_p,0 * (r/a)^(1/phi) * (1 + delta_phi*sin(theta))
```

The helical field:
```
B_h = B_h,0 * exp(-r/lambda_phi)
```

Where lambda_phi is the phi-decay length:
```
lambda_phi = a * phi^(-n_helicity)
```

The total field magnitude:
```
|B| = sqrt(B_t^2 + B_p^2 + 2*B_t*B_p*cos(theta))
```

The field line pitch angle:
```
alpha = arctan(B_p/B_t)
```

For a phi-optimized field: alpha_0 = arctan(1/phi) = 31.7 degrees

### 3. Phi-Plasma Beta

The maximum stable beta (ratio of plasma pressure to magnetic pressure):

```
beta_phi = beta_Troyon * (1 + (1/phi) * (q_0/q_edge))
```

Where beta_Troyon = l_i * epsilon * B_t / (R_0 * mu_0 * <J*B>)

For l_i = 0.8, q_0 = 1, q_edge = 3:
```
beta_phi = beta_Troyon * (1 + 0.618 * (1/3)) = beta_Troyon * 1.206
```

The phi-beta is 20.6% higher than the conventional Troyon limit.

The beta limit:
```
beta_max = 0.028 * I_p/(a*B_t) * (1 + phi^(-n_stability))
```

For I_p = 15 MA, a = 2 m, B_t = 5 T:
```
beta_max = 0.028 * 15/(2*5) * (1 + phi^(-1)) = 0.028 * 1.5 * 1.618 = 0.068
```

### 4. Phi-Confinement Time

The energy confinement time in phi-optimized H-mode:

```
tau_E,phi = tau_E,0 * (B_t/B_ref)^phi * (P_loss/P_ref)^(-1/phi) * (n/n_ref)^(1/phi)
```

Where tau_E,0 is the baseline confinement time.

For B_t = 5 T, B_ref = 2.5 T:
```
tau_E,phi/tau_E,0 = (5/2.5)^1.618 = 2^1.618 = 3.08
```

The phi-confinement gives 3.08x improvement over baseline.

The confinement scaling:
```
tau_E ∝ I_p^0.93 * B_t^0.15 * n^0.41 * P^-0.69 * R^1.97 * kappa^0.19
```

The phi-modification replaces the linear exponents:
```
tau_E,phi ∝ I_p^phi * B_t^(1/phi) * n^(1/phi) * P^(-phi) * R^phi^2 * kappa^(1/phi)
```

### 5. Phi-Fusion Power Density

The fusion power density:

```
P_fusion = n_D * n_T * <sigma*v> * E_fusion * phi^(-r_loss)
```

Where:
- n_D, n_T = deuterium and tritium densities
- <sigma*v> = reactivity (m^3/s)
- E_fusion = 17.6 MeV (D-T fusion energy)
- r_loss = loss parameter (dimensionless)

For optimal phi-confinement:
```
P_fusion = n^2 * <sigma*v> * 17.6 * phi^(-0.1) = n^2 * <sigma*v> * 17.6 * 0.937
```

The Lawson criterion with phi-correction:

```
n*tau_E*<sigma*v> = (12*k_B*T)/(E_fusion*<sigma*v>) * phi^(-1/phi) = 3.09e21 * phi^(-0.618) = 3.09e21 * 0.681 = 2.10e21 m^-3*s
```

### 6. Phi-Divertor Design

The divertor strike point pattern follows a phi-spiral:

```
r_strike(theta) = r_0 * phi^(theta/2*pi)
```

The heat flux on the divertor plates:
```
q = q_0 * exp(-|theta - theta_strike|/lambda_phi)
```

Where lambda_phi is the phi-poloidal heat flux width:
```
lambda_phi = lambda_SOL * phi^(-n_strike)
```

The phi-divertor distributes heat over a larger area:
```
A_effective = A_strike * phi^(n_strike)
```

For n_strike = 3: A_effective = A_strike * 4.236

The peak heat flux reduction:
```
q_peak,phi / q_peak,conv = 1/phi^(n_strike) = 1/4.236 = 0.236
```

### 7. Phi-Stellarator Optimization

The stellarator coil geometry follows phi-helical windings:

```
R(phi_t) = R_0 * cos(phi_t) + r_coil * cos(m*phi_t + phi*phi_t)
Z(phi_t) = R_0 * sin(phi_t) + r_coil * sin(m*phi_t + phi*phi_t)
```

Where:
- phi_t = toroidal angle
- m = number of field periods
- r_coil = coil minor radius

The phi-stellarator achieves quasi-isodynamic confinement:

```
B(on B) = B_0 * (1 + sum_n delta_n * cos(n*phi_t + phi*theta))
```

The neoclassical transport reduction:
```
D_neo,phi / D_neo,conv = phi^(-n_period) = phi^(-5) = 0.090
```

---

## PHI-HARMONIC FUSION EQUATIONS

| Eq # | Name | Formula |
|------|------|---------|
| F.1 | Plasma shaping | R = R_0*(1+epsilon*cos(theta+phi*theta_n)) |
| F.2 | q-profile | q(r) = q_0 + (q_e-q_0)*(r/a)^phi |
| F.3 | Beta limit | beta_phi = beta_T*(1+(1/phi)*(q_0/q_e)) |
| F.4 | Confinement | tau_E = tau_0*(B/B_r)^phi*(P/P_r)^(-1/phi) |
| F.5 | Fusion power | P = n^2*<sv>*E*phi^(-r_loss) |
| F.6 | Lawson criterion | n*tau*<sv> = 3.09e21*phi^(-1/phi) |
| F.7 | Divertor heat flux | q = q_0*exp(-|theta-theta_s|/lambda_phi) |
| F.8 | Stellarator B-field | B = B_0*(1+sum*delta_n*cos(n*phi_t+phi*theta)) |

---

## WORKED EXAMPLES

### Example 1: Phi-Tokamak Beta Limit

**Given:**
- I_p = 15 MA, a = 2 m, R_0 = 6 m, B_t = 5 T
- q_0 = 1, q_edge = 3

**Find:** Maximum beta

**Solution:**

Step 1: Troyon coefficient
```
beta_Troyon = I_p/(a*B_t) = 15/(2*5) = 1.5 MA/(m*T)
```

Step 2: Phi-correction
```
f_phi = 1 + (1/phi)*(q_0/q_edge) = 1 + 0.618*(1/3) = 1.206
```

Step 3: Maximum beta
```
beta_max = 0.028 * 1.5 * 1.206 = 0.0507 = 5.07%
```

**Result:** The phi-optimized tokamak achieves 5.07% beta, exceeding the conventional Troyon limit of 4.2%.

---

## PROBLEMS

1. Calculate the energy confinement time improvement for a phi-optimized tokamak with B_t = 6 T.

2. Determine the peak heat flux reduction for a phi-divertor with n_strike = 4.

3. Find the optimal plasma elongation for epsilon = 0.25.

4. Calculate the Lawson criterion value for a phi-confined plasma at T = 15 keV.

5. Design the q-profile for a tokamak with q_0 = 0.8 and q_edge = 4.

---

## TABLES

### Phi-Tokamak Parameters

| Parameter | Conventional | Phi-Optimized |
|-----------|-------------|---------------|
| Triangularity | 0.3-0.5 | 0.809 |
| Elongation | 1.5-1.8 | 2.165 |
| Beta limit | 4.2% | 5.07% |
| Confinement | tau_0 | 3.08*tau_0 |
| Divertor heat flux | q_0 | 0.236*q_0 |

### Fusion Reactivity at Optimal Temperature

| Temperature (keV) | <sigma*v> (m^3/s) | Phi-Enhancement |
|-------------------|-------------------|-----------------|
| 10 | 4.1e-22 | 1.20 |
| 15 | 8.5e-22 | 1.35 |
| 20 | 1.2e-21 | 1.42 |
| 25 | 1.3e-21 | 1.38 |
| 30 | 1.1e-21 | 1.28 |
