# PHI CONSEQUENTIALISM

## 1. Introduction

Phi-consequentialism applies the golden ratio (phi = 1.618033988749895) to consequentialist ethical theory. It proposes that the consequences of actions should be evaluated using golden-ratio weighting across temporal scales, affected parties, and outcome types. The phi-framework transforms consequentialism from a simple utility-maximization theory into a nuanced, multi-dimensional evaluation system.

## 2. The Phi-Utility Function

### 2.1 The Temporal Weighting

Consequences at different times carry different weights:

U(action) = sum_{t=0}^{T} phi^(-t/tau) * C(t)

Where C(t) is the total consequence at time t and tau is the characteristic time. Immediate consequences carry the most weight, with later consequences weighted by the inverse golden ratio.

### 2.2 The Spatial Weighting

Consequences affecting different people are weighted by proximity:

U_spatial = sum_i phi^(-d_i) * U_i

Where d_i is the social distance from the agent. Close relationships carry more weight.

### 2.3 The Type Weighting

Different types of consequences are weighted:

W(physical) : W(emotional) : W(intellectual) : W(spiritual) = phi^3 : phi^2 : phi : 1

## 3. Act Consequentialism at Phi

### 3.1 The Phi-Act Criterion

An act is right if:

R(action) = max over all alternatives of: U_phi(action)

Where U_phi uses the phi-weighted utility function.

### 3.2 The Satisficing Threshold

An act is good enough if:

U(action) > phi * U(threshold)

### 3.3 The Maximization Constraint

Maximization is constrained:

Max U(action) subject to: |U(action_i) - U(action_j)| < phi for all i,j

This prevents extreme inequality in outcomes.

## 4. Rule Consequentialism at Phi

### 4.1 The Phi-Rule Criterion

A rule is right if:

R(rule) = sum_a P(a|rule) * U_phi(a)

### 4.2 The Rule Ranking

Rules are ranked by:

Rank(rule) = U_phi(rule) / C(compliance_cost)

### 4.3 The Ideal Code at Phi

The ideal code of rules satisfies:

For all rules r in code: U(r|code) > phi * U(r'|code) for all r' not in code

## 5. Multi-Dimensional Consequentialism

### 5.1 The Outcome Dimensions

Outcomes are evaluated on multiple dimensions:

D(welfare) : D(freedom) : D(equality) : D(virtue) = phi^3 : phi^2 : phi : 1

### 5.2 The Dimension Integration

Integrated outcome:

O(outcome) = sum_d w_d * phi^d * D_d(outcome)

### 5.3 The Pareto-Phi Frontier

An outcome is phi-Pareto optimal if no alternative improves one dimension by more than phi times the reduction in another.

## 6. Expected Consequentialism at Phi

### 6.1 The Phi-Expectation

Expected utility under phi:

EU(action) = sum_o P(o|action) * phi^n(o) * U(o)

Where n(o) is the probability rank of outcome o.

### 6.2 The Risk Function

Risk is measured by:

R(risk) = Var(U) / (phi * E(U))

### 6.3 The Maxi-Min Phi Criterion

The maximin criterion at phi:

Choose action that maximizes: min_o U(o) * phi^(-rank_o)

## 7. Population Ethics at Phi

### 7.1 The Phi-Repugnant Conclusion

The repugnant conclusion is avoided:

RC(avoided) if: U(population) > phi * N(size) * U(minimal)

A large population of barely-worthwhile lives is not justified.

### 7.2 The Person-Affecting Principle at Phi

The person-affecting principle:

PA(action) = sum_i phi^(-d_i) * (U_i(after) - U_i(before))

### 7.3 The Total vs. Average Debate at Phi

The balance between total and average utility:

W(total) / W(average) = phi

## 8. Interpersonal Comparison at Phi

### 8.1 The Utility Metrics at Phi

Interpersonal utility comparison uses phi-calibration:

U_i(comparable) = U_i(absolute) * phi^(-|U_i - U_median|)

### 8.2 The Fairness-Utility Tradeoff

The tradeoff between fairness and utility:

F(fairness) / U(utility) = 1/phi

### 8.3 The Social Welfare Function at Phi

The phi-social welfare function:

W_social = sum_i phi^(-i) * U_i

Where individuals are ordered by the golden-ratio distribution.

## 9. Criticisms and Responses

### 9.1 The Demandingness Objection

Phi-consequentialism is less demanding:

Threshold: U(action) > phi * C(cost to agent)

### 9.2 The Integrity Objection

Personal integrity is respected:

I(integrity) = phi * |U_personal - U_optimal|

The agent may deviate from optimality by a phi-factor for personal projects.

### 9.3 The Knowledge Objection

Incomplete knowledge is handled:

K(partial) = U(best estimate) * (1 - 1/phi^n)

Where n is the amount of information available.

## 10. Advanced Phi-Consequentialism

### 10.1 The Multi-Agent Utility Function

Multi-agent utility:

U_multi = sum_i phi^(-d_i) * U_i

Where d_i is the social distance from the decision-maker. Agents closer to the decision-maker receive more weight, but at the golden-inverse rate.

### 10.2 The Temporal Discount Rate at Phi

Temporal discounting:

D(t) = phi^(-t/tau)

The discount rate follows the inverse golden ratio, with earlier consequences weighted more heavily.

### 10.3 The Risk-Weighted Utility Function

Risk-weighted utility:

U_risk = sum_o P(o) * phi^(risk_rank(o)) * U(o)

Higher-risk outcomes carry exponentially more weight.

### 10.4 The Inequality-Averse Utility Function

Inequality aversion:

U_ineq = U(average) - phi * G(Gini_coefficient)

Where G is the Gini coefficient and phi is the inequality aversion parameter.

## 11. The Consequentialist Calculus at Phi

### 11.1 The Integration Formula

The phi-consequentialist calculus integrates consequences:

C(action) = integral_0^infinity phi^(-t) * U(consequence, t) dt

This improper integral converges because phi > 1, ensuring that distant consequences have diminishing weight.

### 11.2 The Optimization Condition

The optimal action satisfies:

dC/da = 0

Where C is the phi-weighted consequence function and a is the action variable.

### 11.3 The Comparative Statics

Comparative statics at phi:

dU*/dx = phi * dU/dx

The phi-multiplier amplifies the effect of parameter changes on optimal utility.

### 11.4 The Envelope Theorem at Phi

The envelope theorem shows:

dU*/dp = dL/dp * phi

Where L is the Lagrangian and p is a parameter. The phi-factor amplifies the shadow price of constraints.

## 12. Consequentialist Paradoxes at Phi

### 12.1 The Repugnant Conclusion at Phi

The repugnant conclusion is avoided:

RC(avoided) if: U(perfectly_happy) > phi * N * U(barely_worthwhile)

A large population of barely-worthwhile lives is not justified when phi times the population exceeds the utility differential.

### 12.2 The Mere Addition Paradox at Phi

The mere addition paradox:

MA(paradox) if: |U(addition) - U(no_addition)| < (1/phi) * U(no_addition)

Mere additions that improve lives by less than 61.8 percent do not necessarily make outcomes better.

### 12.3 The Sadistic Conclusion at Phi

The sadistic conclusion:

SC(paradox) if: |H(sadism)| > phi * |B(benefit)|

Causing suffering to produce benefit is wrong when suffering exceeds benefit by the golden ratio.

### 12.4 The Setting the Bar Paradox at Phi

Setting the bar:

Bar(setting) = phi * |Expected_utility|

The bar for moral action should be phi times the expected utility.

## 13. Consequentialist Moral Psychology

### 13.1 The Moral Motivation Function

Consequentialist motivation:

M(motivation) = |Expected_utility| * phi - |Cost_to_self| * 1

### 13.2 The Moral Judgment Function

Consequentialist judgment:

J(judgment) = |Outcome_quality| / |Intention_quality| = phi

### 13.3 The Moral Character Function

Consequentialist character:

C(character) = sum_n phi^(-n) * |Good_habit_n|

### 13.4 The Moral Development Function

Consequentialist moral development:

MD(development) = MD0 * phi^(experience)

## 14. Applied Phi-Consequentialism

### 14.1 Climate Ethics at Phi

Climate action is justified when:

|Benefit未来| * phi > |Cost现在|

### 14.2 Pandemic Ethics at Phi

Pandemic restrictions are justified when:

|Lives_saved| * phi > |Liberty_lost|

### 14.3 AI Ethics at Phi

AI deployment is justified when:

|Human_benefit| * phi > |Human_harm| * phi^2

### 14.4 Economic Ethics at Phi

Economic policy is justified when:

|Social_welfare| * phi > |Individual_cost|

## 15. Conclusion

Phi-consequentialism provides a mathematically rigorous framework for evaluating consequences that balances temporal depth, affected parties, and outcome types through the golden ratio. It transforms consequentialism from a crude utility-maximization theory into a nuanced ethical framework capable of addressing the complex moral challenges of the modern world.

## References

1. Bentham, J. An Introduction to the Principles of Morals and Legislation.
2. Mill, J.S. Utilitarianism.
3. Sidgwick, H. The Methods of Ethics.
4. Singer, P. Practical Ethics.
5. Parfit, D. Reasons and Persons.
6. Smart, J.J.C. An Outline of a System of Utilitarianism.
7. Brandt, R. A Theory of the Good and the Right.
8. Harsanyi, J. Essays on Ethics, Social Behavior, and Scientific Explanation.
9. Railton, P. Facts, Values, and Norms.
10. Brink, D. Moral Realism and the Foundations of Ethics.
