# 01 — The Golden Ratio (φ) | Intermediate Level

## Ages 13–16 | Algebraic Foundations

---

## 1. Definition

The golden ratio φ (phi) is defined as:

```
φ = (1 + √5) / 2 ≈ 1.6180339887...
```

This number appears when a line is divided so that the ratio of the whole to the
larger part equals the ratio of the larger part to the smaller part.

```
Whole / Long = Long / Short = φ
```

---

## 2. Algebraic Proof: φ² = φ + 1

**Claim:** φ² = φ + 1

**Proof:**

Let φ = (1 + √5) / 2.

```
φ² = ((1 + √5) / 2)²
   = (1 + 2√5 + 5) / 4
   = (6 + 2√5) / 4
   = (3 + √5) / 2
```

Now compute φ + 1:

```
φ + 1 = (1 + √5)/2 + 1
       = (1 + √5 + 2) / 2
       = (3 + √5) / 2
```

Since both sides equal (3 + √5)/2, we have φ² = φ + 1. ∎

**Why this matters:** This identity lets us simplify any expression involving φ².
Any power of φ can be reduced to a linear expression in φ.

---

## 3. The Conjugate: −1/φ

The conjugate of φ is:

```
φ* = (1 − √5) / 2 ≈ −0.6180339887...
```

Key identity: φ* = −1/φ.

**Proof:**

```
φ · φ* = ((1 + √5)/2) · ((1 − √5)/2)
       = (1 − 5) / 4
       = −4/4 = −1

Therefore: φ* = −1/φ  ✓
```

Also: φ − φ* = √5, and φ · φ* = −1.

---

## 4. Fibonacci Sequence Connection

The Fibonacci sequence is:

```
F(1) = 1,  F(2) = 1,  F(3) = 2,  F(4) = 3,
F(5) = 5,  F(6) = 8,  F(7) = 13,  F(8) = 21, ...
```

Each term is the sum of the two preceding terms: F(n) = F(n−1) + F(n−2).

**Theorem:** The ratio F(n+1)/F(n) converges to φ as n → ∞.

**Proof sketch:** Assume the ratio converges to some value L.

```
F(n+1)/F(n) = L  as n → ∞

But F(n+1) = F(n) + F(n−1), so:
F(n+1)/F(n) = 1 + F(n−1)/F(n) = 1 + 1/L

Therefore: L = 1 + 1/L
            L² = L + 1
            L² − L − 1 = 0

By the quadratic formula: L = (1 + √5)/2 = φ  (taking positive root)
```

---

## 5. Binet's Formula (Preview)

The nth Fibonacci number can be computed directly:

```
F(n) = (φⁿ − (−φ)⁻ⁿ) / √5
```

This is remarkable: a formula involving irrational numbers that always produces
a whole number.

**Example: F(7)**

```
F(7) = (φ⁷ − (−1/φ)⁷) / √5
     = (29.034... − (−0.0344...)) / 2.236...
     = 29.069... / 2.236...
     = 13  ✓
```

---

## 6. The Golden Angle

The golden angle is derived from dividing a circle (360°) in the golden ratio:

```
Golden angle = 360° × (1 − 1/φ)
            = 360° × (2 − φ)
            = 360° × (3 − √5)/2
            ≈ 137.507764°
```

**Why 137.508°?**

```
360° / φ² = 360° / ((3 + √5)/2)
           = 720° / (3 + √5)
           = 720°(3 − √5) / ((3)² − 5)
           = 720°(3 − √5) / 4
           = 180°(3 − √5)
           ≈ 137.508°
```

---

## 7. Phyllotaxis: Nature's Use of φ

Phyllotaxis is the arrangement of leaves, seeds, and petals in plants.

**Why the golden angle?**

When seeds are placed at 137.508° intervals, no two seeds are ever exactly
aligned radially. This produces the most efficient packing.

```
Sunflower seed head:
- Seeds arranged at golden angle intervals
- Produces 34 and 55 spirals (consecutive Fibonacci numbers)
- Or 55 and 89 spirals in larger heads
- Ratio 55/34 ≈ 1.6176 ≈ φ
```

**Examples in nature:**
- Pinecone spirals: 8 and 13
- Daisy petals: typically 34, 55, or 89
- Sunflower seeds: 34 & 55, or 55 & 89
- Leaf arrangements: each leaf at ~137.5° from the previous

---

## 8. Continued Fraction of φ

The golden ratio has the simplest continued fraction:

```
φ = 1 + 1/(1 + 1/(1 + 1/(1 + ...)))
```

This is written as [1; 1, 1, 1, 1, ...].

This means φ is the "most irrational" number — it is the hardest to approximate
by rationals, because all its partial quotients are 1 (the smallest possible).

---

## 9. The Golden Ratio and Pentagons

In a regular pentagon with side length s, the diagonal has length φs.

```
Pentagon diagonal / side = φ
```

The pentagram (five-pointed star) contains φ at every intersection:

```
In the pentagram:
  long segment / short segment = φ
  whole diagonal / long segment = φ
  The ratio of areas of nested pentagons = φ²
```

---

## 10. Worked Problems

### Problem 1: Find φ² using the identity

**Question:** Without using a calculator, compute φ².

**Solution:**

From φ² = φ + 1:
```
φ² = (1 + √5)/2 + 1 = (3 + √5)/2 ≈ 2.618
```

---

### Problem 2: Find 1/φ

**Question:** Express 1/φ in simplest form.

**Solution:**

```
1/φ = 2/(1 + √5)
    = 2(√5 − 1) / ((1 + √5)(√5 − 1))
    = 2(√5 − 1) / (5 − 1)
    = 2(√5 − 1) / 4
    = (√5 − 1) / 2
    ≈ 0.618
```

Note: 1/φ = φ − 1. This means φ is the only number where 1/φ = φ − 1.

---

### Problem 3: Fibonacci ratio convergence

**Question:** Compute F(6)/F(5), F(7)/F(6), and F(8)/F(7). How close to φ?

**Solution:**

```
F(6)/F(5) = 8/5 = 1.600000
F(7)/F(6) = 13/8 = 1.625000
F(8)/F(7) = 21/13 ≈ 1.615385

φ ≈ 1.618034

Error at F(7)/F(6): |1.625 − 1.618| ≈ 0.007
Error at F(8)/F(7): |1.615 − 1.618| ≈ 0.003
```

The ratio converges quickly, alternating above and below φ.

---

### Problem 4: The golden angle

**Question:** If a flower places petals at the golden angle, how many petals
before one is within 1° of the first?

**Solution:**

```
Golden angle ≈ 137.508°

After n petals, position = n × 137.508° mod 360°

n=1: 137.508°
n=2: 275.016°
n=3: 412.524° mod 360° = 52.524°
n=4: 550.032° mod 360° = 190.032°
n=5: 687.540° mod 360° = 327.540°
n=6: 825.048° mod 360° = 105.048°
...
```

Because φ is irrational, the petals never exactly repeat. But they fill the
circle uniformly, creating the characteristic spiral pattern.

---

### Problem 5: Pentagon diagonal

**Question:** A regular pentagon has side length 10 cm. What is the length of
its diagonal?

**Solution:**

```
Diagonal = φ × side
         = φ × 10
         = 10φ
         ≈ 16.18 cm
```

---

### Problem 6: Simplify φ³

**Question:** Express φ³ in the form aφ + b.

**Solution:**

```
φ³ = φ · φ²
   = φ(φ + 1)       [using φ² = φ + 1]
   = φ² + φ
   = (φ + 1) + φ     [using φ² = φ + 1 again]
   = 2φ + 1
```

So φ³ = 2φ + 1 ≈ 4.236.

---

### Problem 7: Solve x² − x − 1 = 0

**Question:** Find the positive root of x² − x − 1 = 0.

**Solution:**

By the quadratic formula:
```
x = (1 ± √(1 + 4)) / 2
  = (1 ± √5) / 2
```

Positive root: x = (1 + √5)/2 = φ ≈ 1.618.

---

### Problem 8: Find φ⁴

**Question:** Express φ⁴ in the form aφ + b.

**Solution:**

```
φ⁴ = φ · φ³
   = φ(2φ + 1)        [from Problem 6]
   = 2φ² + φ
   = 2(φ + 1) + φ     [using φ² = φ + 1]
   = 2φ + 2 + φ
   = 3φ + 2
```

So φ⁴ = 3φ + 2 ≈ 6.854.

---

### Problem 9: The reciprocal identity

**Question:** Prove that φ − 1/φ = 1.

**Solution:**

```
φ − 1/φ = φ − (φ − 1)     [since 1/φ = φ − 1]
        = 1  ✓
```

Alternatively:
```
φ − 1/φ = (1+√5)/2 − (√5−1)/2
        = (1 + √5 − √5 + 1) / 2
        = 2/2 = 1  ✓
```

---

### Problem 10: Fibonacci with Binet's formula

**Question:** Use Binet's formula to compute F(5).

**Solution:**

```
F(5) = (φ⁵ − (−1/φ)⁵) / √5

φ⁵ = φ · φ⁴ = φ(3φ + 2) = 3φ² + 2φ = 3(φ+1) + 2φ = 5φ + 3
    = 5(1.618...) + 3 = 11.090...

(−1/φ)⁵ = −(1/φ)⁵ ≈ −0.0902...

F(5) = (11.090... + 0.0902...) / 2.236...
     = 11.180... / 2.236...
     = 5  ✓
```

---

### Problem 11: Golden rectangle area

**Question:** A golden rectangle has width 1. What is its area?

**Solution:**

```
Width = 1
Length = φ ≈ 1.618

Area = width × length = 1 × φ = φ ≈ 1.618
```

If you remove a square (1×1), the remaining rectangle has dimensions
1 × (φ − 1) = 1 × 1/φ, which is also a golden rectangle.

---

### Problem 12: Compare φ and 1/φ

**Question:** Which is larger: φ or 1/φ? By how much?

**Solution:**

```
φ ≈ 1.618034
1/φ ≈ 0.618034

φ − 1/φ = 1 (exactly, from Problem 9)

So φ is exactly 1 greater than 1/φ.
```

---

### Problem 13: Express √5 in terms of φ

**Question:** Write √5 using φ.

**Solution:**

```
φ = (1 + √5)/2
2φ = 1 + √5
√5 = 2φ − 1
```

Verify: 2(1.618...) − 1 = 2.236... = √5 ✓

---

### Problem 14: φ and the decimal expansion

**Question:** The decimal part of φ is (√5 − 1)/2. Compute this to 6 decimal
places.

**Solution:**

```
√5 ≈ 2.236068

(√5 − 1)/2 = (2.236068 − 1)/2
           = 1.236068/2
           = 0.618034
```

So φ = 1.618034...

---

### Problem 15: Design a golden spiral rectangle

**Question:** Starting with a 1×1 square, create a golden rectangle by adding
a square to the long side. What are the dimensions after 3 such additions?

**Solution:**

```
Step 0: 1 × 1 square
Step 1: Add 1×1 square → 1 × 2 rectangle
Step 2: Add 2×2 square → 2 × 3 rectangle
Step 3: Add 3×3 rectangle → 3 × 5 rectangle

Notice: dimensions are consecutive Fibonacci numbers!
1, 1, 2, 3, 5, 8, ...

After 3 additions: 3 × 5 = 15 square units.
The ratio 5/3 ≈ 1.667, approaching φ.
```

---

## 11. Summary Table

| Property | Value |
|----------|-------|
| Definition | φ = (1+√5)/2 |
| Decimal | 1.6180339887... |
| Fraction | φ = 1 + 1/φ |
| Polynomial | φ² − φ − 1 = 0 |
| Conjugate | φ* = (1−√5)/2 = −1/φ |
| Golden angle | 137.508° |
| Continued fraction | [1; 1, 1, 1, ...] |
| Relationship to √5 | √5 = 2φ − 1 |
| Key identity | φ² = φ + 1 |

---

## 12. Key Takeaways for Ages 13–16

1. **φ is algebraic:** It is the positive root of x² − x − 1 = 0.
2. **φ² = φ + 1:** This lets us reduce any power of φ to a linear expression.
3. **Fibonacci ratios → φ:** The ratio of consecutive Fibonacci numbers converges to φ.
4. **1/φ = φ − 1:** The golden ratio is the unique number satisfying this.
5. **Nature uses φ:** Phyllotaxis, spirals, and growth patterns use the golden angle.
6. **Pentagons and φ:** The diagonal/side ratio of a regular pentagon is exactly φ.

---

*Next: 02_intermediate_silver.md — The Silver Ratio*
