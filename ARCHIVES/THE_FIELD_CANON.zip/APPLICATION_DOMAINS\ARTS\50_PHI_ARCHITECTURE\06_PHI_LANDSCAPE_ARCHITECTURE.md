# PHI-LANDSCAPE ARCHITECTURE

## 1. PHI-Landscape Principles

### 1.1 The PHI-Landscape

Landscape architecture with phi = 1.6180339887 creates outdoor spaces that feel naturally organized, with plant arrangements, path systems, water features, and hardscape elements following golden-ratio proportions.

### 1.2 The PHI-Site Plan

```
PHI-Site organization:

Built area : Landscape area = 1 : phi

For a site of total area A:
  Built: A / (1 + phi) = 38.2%
  Landscape: A x phi / (1 + phi) = 61.8%
  
  Example (1 hectare = 10,000 m²):
    Built: 3,820 m²
    Landscape: 6,180 m²
    
  The phi-site ensures:
    Majority of site is landscape (green, permeable, living)
    Built area is significant but not dominant
    Natural systems are prioritized
```

## 2. PHI-Planting Design

### 2.1 PHI-Planting Plan

```
PHI-Planting proportions:

Canopy trees : Understory trees : Shrubs : Groundcover = phi^3 : phi^2 : phi : 1

For a planting area with groundcover unit G:
  Shrubs: G x phi
  Understory: G x phi^2
  Canopy: G x phi^3
  
  Example (G = 100 m² of groundcover):
    Shrubs: 162 m²
    Understory: 262 m²
    Canopy: 424 m²
    
  Total planted area: 100 + 162 + 262 + 424 = 948 m²
  (The phi-sum converges: total = G x phi^3 / (phi - 1) = G x phi^3 / 0.618)
```

### 2.2 PHI-Plant Spacing

```
PHI-Plant spacing:

Tree spacing follows Fibonacci sequence:
  Groundcover: 15 cm, 25 cm, 40 cm, 65 cm
  Perennials: 30 cm, 50 cm, 80 cm, 130 cm
  Shrubs: 60 cm, 100 cm, 160 cm, 260 cm
  Trees: 3 m, 5 m, 8 m, 13 m, 21 m

The phi-spacing ensures:
  Dense planting for immediate effect
  Adequate room for mature growth
  Natural-looking distribution
```

### 2.3 PHI-Plant Layers

```
PHI-Vertical planting layers:

Layer 1 (ground): 0-0.3 m height
Layer 2 (herbaceous): 0.3-1.0 m
Layer 3 (shrub): 1.0-3.0 m
Layer 4 (understory tree): 3.0-8.0 m
Layer 5 (canopy tree): 8.0-20.0 m

Layer heights at phi-intervals:
  Layer 2 = Layer 1 x phi = 0.3 x phi = 0.49 m (adjust to 0.3-1.0)
  Layer 3 = Layer 2 x phi = 1.0 x phi = 1.62 m (adjust to 1.0-3.0)
  Layer 4 = Layer 3 x phi = 3.0 x phi = 4.86 m (adjust to 3.0-8.0)
  Layer 5 = Layer 4 x phi = 8.0 x phi = 12.94 m (adjust to 8.0-20.0)

The phi-layers create a natural canopy structure
that mimics forest ecology
```

## 3. PHI-Water Features

### 3.1 PHI-Pond Design

```
PHI-Pond:

Pond width : Pond length = 1 : phi

For a pond of width W:
  Length = W x phi
  
  Example (W = 10 m):
    Length = 10 x phi = 16.2 m
    
  Pond area = 10 x 16.2 = 162 m²
    
  Edge treatment:
    Soft edge (plants) : Hard edge (stone) = phi : 1
    Soft: 61.8% of perimeter
    Hard: 38.2% of perimeter
    
  Depth profile:
    Shallow (0-0.5 m) : Deep (0.5-2.0 m) = phi : 1
    Shallow: 61.8% of pond area
    Deep: 38.2% of pond area
```

### 3.2 PHI-Fountain

```
PHI-Fountain:

Fountain height : Basin diameter = phi : 1

For a basin of diameter D:
  Height = D x phi
  
  Example (D = 3 m):
    Height = 3 x phi = 4.86 m
    
  Water jet height : Fountain height = 1 : phi
    Jet = 4.86 / phi = 3.0 m (same as basin diameter)
    
  Basin depth : Basin diameter = 1 : phi^2
    Depth = 3 / phi^2 = 1.15 m
```

### 3.3 PHI-Stream

```
PHI-Stream:

Stream width : Stream length = 1 : phi^3

For a stream of width W:
  Length = W x phi^3
  
  Example (W = 1 m):
    Length = 1 x phi^3 = 4.24 m
    
  Pool : Riffle = phi : 1
    Pool length: 61.8% of stream length
    Riffle length: 38.2% of stream length
    
  Pool depth : Pool width = 1 : phi
    For pool width of 2 m:
    Depth = 2 / phi = 1.24 m
```

## 4. PHI-Hardscape

### 4.1 PHI-Paving Patterns

```
PHI-Paving:

Paver length : Paver width = phi : 1

For a paver of width W:
  Length = W x phi
  
  Example (W = 100 mm):
    Length = 100 x phi = 162 mm (round to 160 mm)
    
  Joint width : Paver width = 1 : phi^3
    Joint = 100 / phi^3 = 23.6 mm (round to 24 mm)
    
  The phi-pavers create:
    Elongated modules that lead the eye
    Rhythm through phi-proportioned joints
    Visual interest at human scale
```

### 4.2 PHI-Wall Design

```
PHI-Retaining wall:

Wall height : Wall length = 1 : phi

For a wall of height H:
  Length = H x phi
  
  Example (H = 1.0 m):
    Length = 1.0 x phi = 1.62 m
    
  Wall thickness : Wall height = 1 : phi^2
    Thickness = 1.0 / phi^2 = 0.38 m
    
  The phi-wall:
    Is proportional to its height
    Has a natural visual weight
    Fits within the landscape at human scale
```

### 4.3 PHI-Gazebo

```
PHI-Gazebo:

Gazebo diameter : Gazebo height = phi : 1

For a gazebo of height H:
  Diameter = H x phi
  
  Example (H = 3.0 m):
    Diameter = 3.0 x phi = 4.86 m
    
  Column height : Column spacing = phi : 1
    Column height = 2.4 m (standard)
    Column spacing = 2.4 / phi = 1.48 m
    
  Roof pitch : 30 degrees (standard)
  PHI-roof pitch: 30 / phi = 18.5 degrees (gentle)
```

## 5. PHI-Garden Design

### 5.1 PHI-Formal Garden

```
PHI-Formal garden:

Parterre width : Parterre length = 1 : phi

For a parterre of width W:
  Length = W x phi
  
  Example (W = 5 m):
    Length = 5 x phi = 8.1 m
    
  Path width : Parterre width = 1 : phi^2
    Path = 5 / phi^2 = 1.91 m
    
  Hedge height : Path width = phi : 1
    Hedge = 1.91 x phi = 3.09 m (tall hedge)
    
  Better: Hedge height = 1.0 m (standard)
  PHI-hedge = 1.0 x phi = 1.62 m (medium hedge)
```

### 5.2 PHI-Cottage Garden

```
PHI-Cottage garden:

Bed width : Path width = phi : 1

For a path of width P:
  Bed = P x phi
  
  Example (P = 0.6 m):
    Bed = 0.6 x phi = 0.97 m
    
  Plant height sequence (following Fibonacci):
    Front: 0.3 m, 0.5 m, 0.8 m, 1.3 m, 2.1 m
    
  The phi-height sequence creates:
    Graduated view from path
    Full, layered planting
    Natural-looking abundance
```

### 5.3 PHI-Zen Garden

```
PHI-Zen garden:

Sand area : Rock area = phi : 1

For a total garden area G:
  Sand: G x phi / (1 + phi) = 61.8%
  Rock: G / (1 + phi) = 38.2%
  
  Example (G = 20 m²):
    Sand: 12.4 m²
    Rock: 7.6 m²
    
  Rake pattern spacing:
    Standard: 5 cm
    PHI: 5 x phi = 8.1 cm (round to 8 cm)
    
  Rock placement:
    At phi-intersections of garden grid
    Largest rock at primary phi-point
    Medium rocks at secondary phi-points
    Small rocks at tertiary phi-points
```

## 6. PHI-Urban Landscape

### 6.1 PHI-Street Tree

```
PHI-Street tree:

Tree spacing : Tree height = phi : 1

For a tree of mature height H:
  Spacing = H x phi
  
  Example (H = 15 m):
    Spacing = 15 x phi = 24.3 m
    
  Tree pit width : Tree spacing = 1 : phi^2
    Pit = 24.3 / phi^2 = 9.3 m (wide pit)
    
  Better: Pit width = 2.0 m (standard)
  PHI-pit = 2.0 x phi = 3.24 m (generous pit)
```

### 6.2 PHI-Park Design

```
PHI-Park:

Active area : Passive area = 1 : phi

For a total park area P:
  Active: P / (1 + phi) = 38.2%
  Passive: P x phi / (1 + phi) = 61.8%
  
  Example (10 hectare park):
    Active: 3.82 hectares (sports, playgrounds)
    Passive: 6.18 hectares (lawns, gardens, woods)
    
  Path network:
    Main path: 4.0 m wide
    Secondary: 4.0 / phi = 2.47 m
    Tertiary: 2.47 / phi = 1.53 m
    
  The phi-paths create hierarchy from promenade to trail
```

### 6.3 PHI-Plaza Design

```
PHI-Plaza:

Plaza width : Plaza length = 1 : phi

For a plaza of width W:
  Length = W x phi
  
  Example (W = 40 m):
    Length = 40 x phi = 64.7 m
    
  Hardscape : Softscape = phi : 1
    Hardscape: 61.8% (paving, seating)
    Softscape: 38.2% (planting, water)
    
  Seating area : Circulation area = 1 : phi
    Seating: 38.2% of hardscape
    Circulation: 61.8% of hardscape
```

## 7. PHI-Plant Selection

### 7.1 PHI-Color in Planting

```
PHI-Plant color:

Green foliage : Flower color = phi : 1

For a planting area with flower color F:
  Green: F x phi
  
  Example (F = 100 m² of flowers):
    Green: 162 m² of foliage
    
  Flower color distribution:
    Primary color: 61.8% of flower area
    Secondary color: 23.6%
    Accent color: 14.6%
    
  Seasonal distribution:
    Spring bloom: 38.2% of species
    Summer bloom: 61.8% of species
    (phi-weighted toward summer)
```

### 7.2 PHI-Plant Form

```
PHI-Plant form:

Upright : Rounded : Weeping = phi^2 : phi : 1

For a planting with weeping form W:
  Rounded: W x phi
  Upright: W x phi^2
  
  Example (W = 10 plants):
    Rounded: 16 plants
    Upright: 26 plants
    
  The phi-form distribution:
    Upright dominant (structural)
    Rounded secondary (filling)
    Weeping accent (flowing)
```

### 7.3 PHI-Foliage Texture

```
PHI-Foliage texture:

Fine : Medium : Coarse = phi^2 : phi : 1

For a planting with coarse foliage C:
  Medium: C x phi
  Fine: C x phi^2
  
  Example (C = 10 plants):
    Medium: 16 plants
    Fine: 26 plants
    
  The phi-texture creates:
    Fine texture dominant (soft, airy)
    Medium texture secondary (substantial)
    Coarse texture accent (bold, dramatic)
```

## 8. PHI-Sustainable Landscape

### 8.1 PHI-Stormwater Garden

```
PHI-Stormwater garden:

Rain garden area : Drainage area = 1 : phi

For a drainage area of D:
  Rain garden = D / phi
  
  Example (D = 1000 m²):
    Rain garden = 1000 / phi = 618 m² (too large)
    
  Better: Rain garden = D / phi^2 = 382 m² (still large)
  
  Practical: Rain garden = D / phi^3 = 236 m² (reasonable)
  
  Planting zones:
    Center (wettest): 38.2% of rain garden
    Middle: 38.2%
    Edge (driest): 23.6%
```

### 8.2 PHI-Bioswale

```
PHI-Bioswale:

Swale width : Swale length = 1 : phi

For a swale of width W:
  Length = W x phi
  
  Example (W = 2 m):
    Length = 2 x phi = 3.24 m
    
  Swale depth : Swale width = 1 : phi^2
    Depth = 2 / phi^2 = 0.76 m
    
  Plant density:
    Center: 100% (dense)
    Edge: 100/phi = 61.8% (moderate)
```

### 8.3 PHI-Rain Garden

```
PHI-Rain garden:

Ponding depth : Ponding area = 1 : phi

For a ponding area of A:
  Depth = A / phi (in mm, for small areas)
  
  Example (A = 10 m²):
    Depth = 10 / phi = 6.18 mm (too shallow)
    
  Better: Depth = 150 mm (standard)
  PHI-depth = 150 / phi = 92.7 mm (shallow)
  
  Planting:
    Center (submerged): 23.6% of area
    Middle (moist): 38.2% of area
    Edge (dry): 38.2% of area
```

## 9. PHI-Landscape Lighting

### 9.1 PHI-Light Placement

```
PHI-Landscape lighting:

Path light spacing : Path light height = phi : 1

For a path light of height H:
  Spacing = H x phi
  
  Example (H = 0.6 m):
    Spacing = 0.6 x phi = 0.97 m
    
  Light cone angle: 120 degrees (standard)
  PHI-light cone: 120 / phi = 74.3 degrees (narrow)
```

### 9.2 PHI-Tree Uplighting

```
PHI-Tree uplighting:

Light distance : Tree height = 1 : phi

For a tree of height H:
  Light distance = H / phi
  
  Example (H = 10 m):
    Light distance = 10 / phi = 6.18 m
    
  Number of lights: 3 (Fibonacci number)
  Light spacing: 360/3 = 120 degrees apart
```

## 10. PHI-Landscape Metrics

### 10.1 PHI-Landscape Score

```
Calculate a landscape's PHI-Landscape Score:

Components (each 0-20):
  1. Planting proportions (phi-compliance)
  2. Path hierarchy (phi-based)
  3. Water features (phi-proportions)
  4. Hardscape materials (phi-palette)
  5. Sustainability (phi-ratios in stormwater, planting)

Total: /100
Target: > 61.8
```

### 10.2 PHI-Landscape Checklist

```
[ ] Site follows phi-ratio (built:landscape = 1:phi)
[ ] Planting layers at phi-heights
[ ] Plant spacing follows Fibonacci sequence
[ ] Water features at phi-proportions
[ ] Paths follow phi-hierarchy
[ ] Hardscape materials weighted by phi
[ ] Color distribution follows phi (61.8/23.6/14.6)
[ ] Lighting at phi-spacing
[ ] Stormwater managed at phi-ratios
[ ] Overall feel: natural, balanced, harmonious
```

## References

- Lynch, K. & Hack, G. (1984). "Site Planning"
- Robinson, N. (2004). "The Planting Design Handbook"
- Thayer, R. (1994). "Gray World, Green Heart"
- Simonds, J. & Starke, B. (2013). "Landscape Architecture: A Manual of Site Planning and Design"
- Wenk, E. & Brookes, A. (1995). "Ecological Design"
