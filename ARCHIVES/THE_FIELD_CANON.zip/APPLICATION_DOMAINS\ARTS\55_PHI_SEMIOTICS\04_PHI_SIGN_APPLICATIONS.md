# PHI-Semiotics: Applications

---

## 1. PHI-Brand Identity Design

### 1.1 PHI-Logo Proportions

```
Logo elements follow PHI-hierarchy:
  Primary mark: phi^0 = 1.000
  Wordmark: phi^(-1) = 0.618
  Tagline: phi^(-2) = 0.382

Logo proportions:
  Width : Height = phi : 1 = 1.618 : 1

Clear space:
  Minimum clear space = phi * logo_height = 1.618 * logo_height
```

### 1.2 PHI-Brand Color System

```
Primary : Secondary : Accent = phi : 1/phi : 1/phi^2
                              = 1.618 : 0.618 : 0.382
                              = 61.8% : 23.6% : 14.6%

Color temperature:
  Warm : Cool = phi : 1 = 1.618 : 1 (for energy brands)
  Cool : Warm = phi : 1 = 1.618 : 1 (for tech brands)
```

---

## 2. PHI-Web Design

### 2.1 PHI-Layout Grid

```
Column system:
  Content : Sidebar = phi : 1 = 1.618 : 1

For 12-column grid:
  Content: 7.45 -> 7-8 columns
  Sidebar: 4.55 -> 4-5 columns

Optimal: 8 columns content, 4 columns sidebar (ratio 2:1, close to phi)
```

### 2.2 PHI-Responsive Breakpoints

```
Breakpoint ratios:
  Mobile : Tablet : Desktop = 1 : phi : phi^2 = 1 : 1.618 : 2.618

  Mobile: 375px
  Tablet: 375 * phi = 607px -> 768px (standard)
  Desktop: 375 * phi^2 = 981px -> 1200px (standard)

Content scaling:
  Font_mobile : Font_tablet : Font_desktop = 1 : phi : phi^2
```

---

## 3. PHI-Motion Graphics

### 3.1 PHI-Easing Curves

```
Animation easing:
  Ease-in: phi^(-1) = 0.618 of total duration
  Ease-out: phi^0 = 1.000 of total duration (dominant)
  Ease-in-out: phi : 1 = 1.618 : 1

Keyframe distribution:
  0%: Start (phi^(-3) = 0.236 of movement)
  38.2%: Mid (phi^(-1) = 0.618 of movement)
  100%: End (phi^0 = 1.000 of movement)
```

### 3.2 PHI-Transition Timing

```
Transition duration:
  Quick: 100ms * phi^(-1) = 62ms
  Standard: 100ms * phi^0 = 100ms
  Slow: 100ms * phi^1 = 162ms

Stagger delay:
  Delay = phi * base_delay = 1.618 * base_delay
```

---

## 4. PHI-Typography

### 4.1 PHI-Type Scale

```
Optimal type scale:
  Display: phi^4 = 6.854
  H1: phi^3 = 4.236
  H2: phi^2 = 2.618
  H3: phi^1 = 1.618
  Body: phi^0 = 1.000
  Small: phi^(-1) = 0.618
  Caption: phi^(-2) = 0.382

For base 16px:
  Display: 110px
  H1: 68px
  H2: 42px
  H3: 26px
  Body: 16px
  Small: 10px
  Caption: 6px
```

### 4.2 PHI-Line Height

```
Optimal line height:
  Headings: font_size * phi = 1.618 * font_size
  Body: font_size * phi^(1/2) = 1.272 * font_size

For 16px body text:
  Line height = 16 * 1.272 = 20.4px -> 20px

Line length:
  Optimal = phi * 40 characters = 64.7 -> 65 characters
```

---

## 5. PHI-Photography Composition

### 5.1 PHI-Rule of Thirds

```
Enhanced rule with PHI:
  Horizontal lines at: phi^(-1) = 0.618 and 1 - phi^(-1) = 0.382
  Vertical lines at: phi^(-1) = 0.618 and 1 - phi^(-1) = 0.382

Power points at intersections:
  (0.382, 0.382), (0.382, 0.618), (0.618, 0.382), (0.618, 0.618)

Subject placement:
  Primary subject at (0.618, 0.618)
  Secondary subject at (0.382, 0.382)
```

### 5.2 PHI-Crop Ratios

```
Crop ratios:
  Original: 3:2 = 1.500
  PHI-crop: phi:1 = 1.618

For 3:2 original (e.g., 3000x2000):
  PHI-crop: 3000 x 1854 (phi-ratio)
  
  Or: 3236 x 2000 (phi-ratio maintaining width)
```

---

## 6. PHI-Iconography

### 6.1 PHI-Icon Grid

```
Icon proportions:
  Canvas: phi:1 = 1.618:1 (landscape) or 1:phi (portrait)
  
  For square canvas:
    Icon element at phi^(-1) = 0.618 of canvas
    Padding: (1 - 0.618)/2 = 0.191 on each side

Stroke weight:
  Standard: phi^(-2) = 0.382 of icon size
  Bold: phi^(-1) = 0.618 of icon size
  Light: phi^(-3) = 0.236 of icon size
```

---

## 7. PHI-Data Visualization

### 7.1 PHI-Chart Proportions

```
Pie chart PHI-slices:
  Largest slice: phi^0 = 1.000
  Next: phi^(-1) = 0.618
  Next: phi^(-2) = 0.382
  Next: phi^(-3) = 0.236
  Next: phi^(-4) = 0.146
  Other: phi^(-5) = 0.090

Bar chart:
  Bar width : Gap = phi : 1 = 1.618 : 1

Line chart:
  Data points at phi-intervals
```

### 7.2 PHI-Heat Map

```
Color intensity:
  Hot: phi^0 = 1.000
  Warm: phi^(-1) = 0.618
  Neutral: phi^(-2) = 0.382
  Cool: phi^(-3) = 0.236
  Cold: phi^(-4) = 0.146
```

---

## 8. PHI-Package Design

### 8.1 PHI-Box Proportions

```
Box dimensions:
  Width : Depth : Height = phi^2 : phi : 1 = 2.618 : 1.618 : 1

For height = 10cm:
  Width = 26.18cm
  Depth = 16.18cm

Label placement:
  Front: phi^0 = 1.000 (primary)
  Side: phi^(-1) = 0.618
  Top: phi^(-2) = 0.382
  Back: phi^(-3) = 0.236
```

---

## 9. PHI-Environmental Design

### 9.1 PHI-Signage System

```
Sign hierarchy:
  Building sign: phi^0 = 1.000
  Directional: phi^(-1) = 0.618
  Informational: phi^(-2) = 0.382
  Regulatory: phi^(-3) = 0.236

Sign spacing:
  Distance = phi * sign_height = 1.618 * sign_height
```

---

## 10. PHI-User Interface

### 10.1 PHI-Button Design

```
Button proportions:
  Width : Height = phi : 1 = 1.618 : 1

For height = 44px (minimum touch target):
  Width = 44 * 1.618 = 71.2px -> 72px

Padding:
  Horizontal = phi * Vertical = 1.618 * Vertical
  If Vertical = 12px: Horizontal = 19.4px -> 20px

Border radius:
  Rounded: height/2 = 22px
  PHI-rounded: height/phi = 44/1.618 = 27.2px -> 27px
```

### 10.2 PHI-Form Design

```
Field spacing:
  Between fields: phi * font_size = 1.618 * font_size

Label : Input ratio:
  Label width : Input width = 1 : phi = 1 : 1.618

  For 12-column grid:
    Label: 4 columns
    Input: 8 columns (phi-proportioned)
```

---

## 11. PHI-Gaming Design

### 11.1 PHI-Level Design

```
Level proportions:
  Safe zone : Challenge zone : Boss zone = phi^2 : phi : 1
                                          = 2.618 : 1.618 : 1

For a 1000-unit level:
  Safe: 500 units (50%)
  Challenge: 309 units (30.9%)
  Boss: 191 units (19.1%)

Enemy distribution:
  Easy : Medium : Hard = phi^2 : phi : 1 = 2.618 : 1.618 : 1
```

---

## 12. PHI-Architecture

### 12.1 PHI-Facade Design

```
Facade proportions:
  Width : Height = phi : 1 = 1.618 : 1

Window proportions:
  Window : Wall = phi^(-1) : 1 = 0.618 : 1

  61.8% wall, 38.2% windows

Window spacing:
  Distance between windows = phi * window_width = 1.618 * window_width
```

---

## 13. PHI-Video Production

### 13.1 PHI-Aspect Ratios

```
Cinematic ratios:
  Standard: 16:9 = 1.778
  PHI-cinema: phi:1 = 1.618 (closer to 5:3)
  Ultra-wide: phi^2:1 = 2.618 (approximately 21:9)

For 1920px width:
  PHI-cinema height: 1920/1.618 = 1187px
```

---

## 14. PHI-Game UI

### 14.1 PHI-Health Bar

```
Health segments:
  Total segments: phi^3 = 4.236 -> 4 segments
  Segment ratio: phi : 1 = 1.618 : 1

  Segment 1: 40% (phi^3/total)
  Segment 2: 25% (phi^2/total)
  Segment 3: 15% (phi/total)
  Segment 4: 10% (1/total)

Color transition:
  Green : Yellow : Orange : Red = phi^3 : phi^2 : phi : 1
```

---

## 15. PHI-Advertising Layout

### 15.1 PHI-Print Ad

```
Print ad proportions:
  Image : Headline : Body : CTA = phi^3 : phi^2 : phi : 1

For full-page ad (100%):
  Image: 50%
  Headline: 25%
  Body: 15%
  CTA: 10%

Bleed margins:
  Top : Bottom = phi : 1 = 1.618 : 1
  Left : Right = 1 : phi = 1 : 1.618
```

---

## Summary: PHI Design Applications

| Application | PHI-ratio | Result |
|-------------|-----------|--------|
| Logo | phi:1 | Width 61.8% longer than height |
| Web layout | phi:1 | Content 61.8%, sidebar 38.2% |
| Type scale | phi^n | Exponential size progression |
| Photography | phi:1 | Crop to golden ratio |
| Icons | phi:1 | Golden ratio canvas |
| Charts | phi-weighted | Natural data hierarchy |
| Packaging | phi^2:phi:1 | 3D golden proportions |
| Signage | phi-hierarchy | Clear information levels |
| UI buttons | phi:1 | Optimal touch targets |
| Level design | phi^2:phi:1 | Balanced challenge zones |
| Facades | phi:1 | Golden building proportions |
| Video | phi:1 | Cinematic golden ratio |
| Health bars | phi^n | Visual segment hierarchy |
| Print ads | phi^3:phi^2:phi:1 | Message weight distribution |

---

*This document is part of the PHI-Physics Dictionary, Directory 55: PHI-Semiotics.*
*Total lines: 350+*
