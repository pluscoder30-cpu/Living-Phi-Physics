# PHI-MICROTONAL SYSTEMS

## 1. Foundations of PHI-Tuning

### 1.1 The Problem with Equal Temperament

Standard 12-tone equal temperament (12-TET) divides the octave into 12 equal steps of 100 cents each. This compromises every interval except the octave. The golden ratio offers an alternative organizing principle that creates a self-consistent tuning system based on natural resonance.

### 1.2 The PHI-Octave

In phi-tuning, the octave is divided into phi-proportional parts rather than equal parts:

```
12-TET step: 100 cents (12 steps = octave)
PHI-step: 1200/phi = 741.64 cents (minor sixth)
```

This creates a two-note scale: {0, 741.64 cents}. The interval is approximately a minor sixth, one of the most consonant intervals in traditional music.

### 1.3 The PHI-Series Scale

Building a scale from phi-iterations of the base step:

```
Note 0: 0 cents (unison)
Note 1: 741.64 cents (1 step)
Note 2: 1483.28 cents (2 steps) -> reduced by octave: 283.28 cents
Note 3: 2224.92 cents -> reduced: 224.92 cents
Note 4: 2966.56 cents -> reduced: 966.56 cents
Note 5: 3708.20 cents -> reduced: 108.20 cents
Note 6: 4449.84 cents -> reduced: 449.84 cents
Note 7: 5191.48 cents -> reduced: 791.48 cents
Note 8: 5933.12 cents -> reduced: 333.12 cents
Note 9: 6674.76 cents -> reduced: 74.76 cents
Note 10: 7416.40 cents -> reduced: 216.40 cents
Note 11: 8158.04 cents -> reduced: 958.04 cents
```

## 2. The Fibonacci-Tonal System

### 2.1 Fibonacci Equal Temperament

Divide the octave into F(n) equal parts:

```
F(5) = 5-TET: 240 cents per step
  phi-interval: 3 steps = 720 cents (error: 2.6%)

F(6) = 8-TET: 150 cents per step
  phi-interval: 5 steps = 750 cents (error: 1.1%)

F(7) = 13-TET: 92.31 cents per step
  phi-interval: 8 steps = 738.46 cents (error: 0.42%)

F(8) = 21-TET: 57.14 cents per step
  phi-interval: 13 steps = 742.86 cents (error: 0.16%)

F(9) = 34-TET: 35.29 cents per step
  phi-interval: 21 steps = 741.18 cents (error: 0.06%)
```

### 2.2 Subharmonic Series

The subharmonic series (undertones) contains phi-related intervals:

```
f_n = f0 / n

Subharmonics of 100 Hz:
  S1: 100.00 Hz
  S2: 50.00 Hz
  S3: 33.33 Hz
  S5: 20.00 Hz
  S8: 12.50 Hz

phi-ratios:
  S3/S5 = 1.667 (error: 3.0%)
  S5/S8 = 1.600 (error: 1.1%)
```

### 2.3 PHI-Just Intonation

A just intonation scale where intervals are ratios of Fibonacci numbers:

```
Ratio    Note    Cents    Name
1/1      C       0.000    Unison
8/5      Ab      814.360  Minor sixth
5/3      A       884.359  Major sixth
3/2      G       701.955  Perfect fifth
4/3      F       498.045  Perfect fourth
5/4      E       386.314  Major third
6/5      Eb      315.641  Minor third
13/8     Ab      840.528  Neutral sixth
21/13    F#      830.037  Acute fourth
34/21    D       853.334  Septimal tritone
```

## 3. PHI-Microtonal Scales

### 3.1 The PHI-19 Scale

19 notes per octave with phi-spacing:

```
Step size: 1200/19 = 63.16 cents
phi-interval: 12 steps = 757.89 cents (error: 2.2%)

Scale degrees (cents):
  0, 63, 126, 189, 253, 316, 379, 442, 505, 568,
  632, 695, 758, 821, 884, 947, 1011, 1074, 1137
```

### 3.2 The PHI-31 Scale

31 notes per octave:

```
Step size: 1200/31 = 38.71 cents
phi-interval: 19 steps = 735.48 cents (error: 0.83%)

Notable intervals:
  5 steps: 193.55 cents (minor third)
  8 steps: 309.68 cents
  12 steps: 464.52 cents (perfect fourth)
  13 steps: 503.23 cents
  19 steps: 735.48 cents (phi-interval)
  24 steps: 929.03 cents (major seventh)
```

### 3.3 The PHI-43 Scale

43 notes per octave (43 is a Lucas number):

```
Step size: 1200/43 = 27.91 cents
phi-interval: 27 steps = 753.49 cents (error: 1.8%)

Construction:
  Start with 12-TET (12 notes)
  Add 31 phi-subdivisions
  Total: 43 notes
```

## 4. PHI-Interval Composition

### 4.1 Building Chords with phi-Intervals

```
PHI-Major Triad:
  Root: 0 cents
  Third: 480 cents
  Fifth: 770 cents
  Intervals: 480, 290 cents
  Ratio: 480/290 = 1.655 (error: 2.3%)

PHI-Minor Triad:
  Root: 0 cents
  Third: 296 cents
  Fifth: 770 cents
  Intervals: 296, 474 cents
  Ratio: 474/296 = 1.601 (error: 1.1%)
```

### 4.2 PHI-Seventh Chords

```
PHI-Dominant Seventh:
  Root: 0, Third: 480, Fifth: 770, Seventh: 1020
  Overall span: 1020/630 = 1.619 (error: 0.06%)

PHI-Major Seventh:
  Root: 0, Third: 480, Fifth: 770, Seventh: 1150
  Overall span: 1150/710 = 1.620 (error: 0.1%)
```

### 4.3 PHI-Extended Chords

```
PHI-Ninth Chord:
  Root: 0, Third: 480, Fifth: 770, Seventh: 1020, Ninth: 1310
  Octave-reduced: 110 cents

PHI-Thirteenth Chord:
  Root: 0, Third: 480, Fifth: 770, Seventh: 1020
  Ninth: 110, Eleventh: 400, Thirteenth: 890
```

## 5. PHI-Perfect Pitch and Tuning

### 5.1 PHI-Absolute Pitch

```
Reference: A4 = 432 Hz
phi-pitch classes:
  C: 256 Hz, D: 288 Hz, E: 324 Hz
  F: 341 Hz, G: 384 Hz, A: 432 Hz, B: 486 Hz
```

### 5.2 PHI-ET Calibration

```
For 34-TET with phi-reference:
  Step = 35.29 cents
  A4 = 432 Hz (reference)
  C4: 255.2 Hz (-317.65 cents)
  E4: 315.7 Hz (-141.18 cents)
  G4: 353.8 Hz (-35.29 cents)
```

### 5.3 Hearing Range and phi-Sensitivity

```
Human hearing: 20 Hz - 20,000 Hz
phi-divided bands:
  Band 1: 20 - 32.4 Hz (sub-bass)
  Band 2: 32.4 - 52.4 Hz (bass)
  Band 3: 52.4 - 84.7 Hz (low mid)
  Band 4: 84.7 - 136.1 Hz (mid)
  Band 5: 136.1 - 220.2 Hz (upper mid)
  Band 6: 220.2 - 356.2 Hz (presence)
  Band 7: 356.2 - 576.3 Hz (brightness)
  Band 8: 576.3 - 932.4 Hz (brilliance)
```

## 6. Computational PHI-Tuning

### 6.1 Scale Generator

```python
import math

PHI = (1 + 5**0.5) / 2
OCTAVE = 1200  # cents

def phi_scale(num_notes):
    """Generate a phi-proportional scale."""
    step = OCTAVE / PHI
    scale = []
    for i in range(num_notes):
        cents = (i * step) % OCTAVE
        scale.append(round(cents, 2))
    return sorted(set(scale))

def fibonacci_tet(n):
    """Generate Fibonacci equal temperament."""
    fib = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
    notes = fib[n]
    step = OCTAVE / notes
    scale = [round(i * step, 2) for i in range(notes)]
    phi_step = round(OCTAVE / PHI, 2)
    phi_note = min(scale, key=lambda x: abs(x - phi_step))
    return scale, phi_note

def verify_phi_interval(scale):
    """Check how well scale approximates phi-interval."""
    target = OCTAVE / PHI
    closest = min(scale, key=lambda x: abs(x - target))
    error = abs(closest - target) / target * 100
    return closest, error
```

### 6.2 Tuning Fork Calculator

```python
def phi_fork_set(base_freq=136.1):
    """Generate phi-spaced tuning fork frequencies."""
    forks = [base_freq]
    for i in range(7):
        forks.append(round(forks[-1] * PHI, 1))
    return forks

def fork_harmonics(freq, num_harmonics=8):
    """Calculate harmonics of a phi-fork."""
    return [round(freq * n, 1) for n in range(1, num_harmonics + 1)]
```

## 7. Historical Context

### 7.1 Ancient Greek Microtonality

Pythagorean tuning used ratios of small integers. The phi-intervals (8:5, 13:8, 21:13) were known but considered "imperfect" because they did not reduce to simple ratios. Modern phi-tuning reclaims these intervals as structurally superior due to their self-referential nature.

### 7.2 Arab Maqam and phi

The Arabic maqam system includes quarter-tones (50 cents) and three-quarter-tones (150 cents). The phi-interval (741.64 cents) falls between the neutral third (350 cents) and the perfect fourth (500 cents), creating a "golden third" that exists in no traditional system.

### 7.3 Contemporary phi-Composers

Experimental composers using phi-tuning include:
- Ben Johnston (just intonation with phi-ratios)
- Easley Blackwood (microtonal scales including phi)
- James Tenney (spectral music with phi-harmonics)
- Michael Harrison (phi-resonant piano tuning)

## References

- Sethares, W. (2005). "Tuning, Timbre, Spectrum, Scale"
- Erno, L. (1962). "Fibonacci and Lucas Numbers in Music"
- Blackwood, E. (1985). "The Structure of Recognizable Diatonic Tunings"
- Tenney, J. (1988). "A History of Consonance and Dissonance"
- Keislar, D. (1987). "History and Principles of Microtonal Tuning Systems"
