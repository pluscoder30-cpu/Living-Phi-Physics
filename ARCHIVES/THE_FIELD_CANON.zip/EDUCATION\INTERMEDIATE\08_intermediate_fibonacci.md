# 08 — The Fibonacci Ratio | Intermediate Level

## Ages 13–16 | Binet's Formula and the Fibonacci Sequence

---

## 1. Definition

The Fibonacci sequence is:

```
F(1) = 1,  F(2) = 1
F(n) = F(n-1) + F(n-2)  for n >= 3
```

First 20 terms:

```
1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610,
987, 1597, 2584, 4181, 6765
```

The "Fibonacci ratio" refers to the limit:

```
lim(n->inf) F(n+1)/F(n) = phi = (1+sqrt(5))/2
```

---

## 2. Binet's Formula

The nth Fibonacci number can be computed directly:

```
F(n) = (phi^n - psi^n) / sqrt(5)
```

where phi = (1+sqrt(5))/2 and psi = (1-sqrt(5))/2 = -1/phi.

This is remarkable: a formula involving irrational numbers that always
produces a whole number.

---

## 3. Proof of Binet's Formula

**Theorem:** F(n) = (phi^n - psi^n) / sqrt(5)

**Proof by strong induction:**

**Base cases:**

```
F(1) = (phi^1 - psi^1) / sqrt(5)
     = ((1+sqrt(5))/2 - (1-sqrt(5))/2) / sqrt(5)
     = (sqrt(5)) / sqrt(5)
     = 1  (check)

F(2) = (phi^2 - psi^2) / sqrt(5)
     = ((3+sqrt(5))/2 - (3-sqrt(5))/2) / sqrt(5)
     = (sqrt(5)) / sqrt(5)
     = 1  (check)
```

**Inductive step:** Assume the formula holds for all k <= n. Then:

```
F(n+1) = F(n) + F(n-1)

= [phi^n - psi^n + phi^(n-1) - psi^(n-1)] / sqrt(5)

= [phi^(n-1)(phi + 1) - psi^(n-1)(psi + 1)] / sqrt(5)
```

Since phi^2 = phi + 1 and psi^2 = psi + 1:

```
= [phi^(n-1) * phi^2 - psi^(n-1) * psi^2] / sqrt(5)

= [phi^(n+1) - psi^(n+1)] / sqrt(5)
```

This completes the induction. (End of proof)

---

## 4. Cassini's Identity

**Theorem:** F(n-1) * F(n+1) - F(n)^2 = (-1)^n

**Example:**

```
n=5: F(4)*F(6) - F(5)^2 = 3*8 - 5^2 = 24 - 25 = -1 = (-1)^5
n=6: F(5)*F(7) - F(6)^2 = 5*13 - 8^2 = 65 - 64 = 1 = (-1)^6
```

---

## 5. GCD Property

**Theorem:** gcd(F(m), F(n)) = F(gcd(m, n))

**Example:**

```
gcd(F(6), F(9)) = gcd(8, 34) = 2 = F(3)
gcd(6, 9) = 3, and F(3) = 2  (check)
```

---

## 6. Zeckendorf's Theorem

Every positive integer can be uniquely represented as a sum of non-consecutive
Fibonacci numbers.

**Examples:**

```
100 = 89 + 8 + 3 = F(11) + F(6) + F(4)
64 = 55 + 8 + 1 = F(10) + F(6) + F(2)
1000 = 987 + 13 = F(16) + F(7)
```

---

## 7. Fibonacci in Nature

Beyond phyllotaxis, Fibonacci numbers appear in:

```
Bee ancestry: males have 1 parent, females have 2
              Generations: 1, 1, 2, 3, 5, 8, 13, ...
Pinecone spirals: 8 and 13
Sunflower seeds: 34 and 55
Rabbit population growth (Fibonacci's original problem)
```

---

## 8. Fibonacci Matrices

The matrix power formula:

```
| 1  1 |^n     | F(n+1)  F(n)   |
| 1  0 |    =   | F(n)    F(n-1) |
```

This gives a fast way to compute Fibonacci numbers using matrix exponentiation.

**Example for n=4:**

```
| 1  1 |^4     | 5  3 |
| 1  0 |    =   | 3  2 |

So F(4) = 3, F(5) = 5  (check)
```

---

## 9. Worked Problems

### Problem 1: Compute F(10) using Binet's formula

**Question:** Use Binet's formula to find F(10).

**Solution:**

```
F(10) = (phi^10 - psi^10) / sqrt(5)

phi^10 = (1.618034)^10 = 122.991869
psi^10 = (-0.618034)^10 = 0.008131

F(10) = (122.991869 - 0.008131) / 2.236068
     = 122.983738 / 2.236068
     = 55  (check)
```

---

### Problem 2: Cassini's Identity

**Question:** Verify Cassini's Identity for n = 7.

**Solution:**

```
F(6)*F(8) - F(7)^2 = 8*21 - 13^2
                    = 168 - 169
                    = -1
(-1)^7 = -1  (check)
```

---

### Problem 3: Ratio convergence

**Question:** Compute F(n+1)/F(n) for n = 5 through 10.

**Solution:**

```
F(6)/F(5) = 8/5 = 1.6000
F(7)/F(6) = 13/8 = 1.6250
F(8)/F(7) = 21/13 = 1.6154
F(9)/F(8) = 34/21 = 1.6190
F(10)/F(9) = 55/34 = 1.6176
F(11)/F(10) = 89/55 = 1.6182

phi = 1.618034...

The ratios oscillate above and below phi, converging quickly.
```

---

### Problem 4: Sum of Fibonacci numbers

**Question:** Prove that sum(F(1) to F(n)) = F(n+2) - 1.

**Solution:**

```
Sum = F(1) + F(2) + ... + F(n)

Since F(k) = F(k+2) - F(k+1):

Sum = [F(3)-F(2)] + [F(4)-F(3)] + ... + [F(n+2)-F(n+1)]
    = F(n+2) - F(2)
    = F(n+2) - 1
```

**Example:** Sum(F(1) to F(5)) = 1+1+2+3+5 = 12 = F(7) - 1 = 13 - 1. (check)

---

### Problem 5: GCD property

**Question:** Find gcd(F(8), F(12)).

**Solution:**

```
gcd(F(8), F(12)) = F(gcd(8,12)) = F(4) = 3

Check: F(8) = 21, F(12) = 144
gcd(21, 144) = 3  (check)
```

---

### Problem 6: Zeckendorf representation

**Question:** Write 200 as a sum of non-consecutive Fibonacci numbers.

**Solution:**

```
Largest F(n) <= 200: F(12) = 144
Remainder: 200 - 144 = 56

Largest F(n) <= 56: F(10) = 55
Remainder: 56 - 55 = 1

Largest F(n) <= 1: F(2) = 1

200 = 144 + 55 + 1 = F(12) + F(10) + F(2)
```

---

### Problem 7: Fibonacci and the golden rectangle

**Question:** A golden rectangle has dimensions F(n+1) x F(n). Find the
dimensions for n = 6.

**Solution:**

```
n = 6: F(7) x F(6) = 13 x 8

Ratio: 13/8 = 1.625

phi = 1.618034...

Error: |1.625 - 1.618| / 1.618 = 0.43%
```

---

### Problem 8: Lucas numbers

**Question:** The Lucas sequence is L(0)=2, L(1)=1, L(n)=L(n-1)+L(n-2).
Compute L(1) through L(8).

**Solution:**

```
L(0) = 2
L(1) = 1
L(2) = 3
L(3) = 4
L(4) = 7
L(5) = 11
L(6) = 18
L(7) = 29
L(8) = 47
```

The Lucas numbers satisfy the same recurrence as Fibonacci but with
different starting values.

---

### Problem 9: Fibonacci identity

**Question:** Prove that F(n)^2 + F(n+1)^2 = F(2n+1).

**Solution:**

```
Using Binet's formula:

F(n)^2 + F(n+1)^2 = [(phi^n - psi^n)^2 + (phi^(n+1) - psi^(n+1))^2] / 5

This simplifies to (phi^(2n+1) - psi^(2n+1)) / sqrt(5) = F(2n+1)
```

**Example:** F(4)^2 + F(5)^2 = 9 + 25 = 34 = F(9). (check)

---

### Problem 10: The Fibonacci spiral

**Question:** If each square in the Fibonacci tiling has side length F(n),
what is the total area covered by the first 6 squares?

**Solution:**

```
Squares with sides: 1, 1, 2, 3, 5, 8

Areas: 1, 1, 4, 9, 25, 64

Total area = 1 + 1 + 4 + 9 + 25 + 64 = 104 square units
```

---

### Problem 11: Parity pattern

**Question:** What is the pattern of even/odd numbers in the Fibonacci sequence?

**Solution:**

```
F(1) = 1 (odd)
F(2) = 1 (odd)
F(3) = 2 (even)
F(4) = 3 (odd)
F(5) = 5 (odd)
F(6) = 8 (even)
F(7) = 13 (odd)
F(8) = 21 (odd)
F(9) = 34 (even)

Pattern: O, O, E, O, O, E, O, O, E, ...
Every third Fibonacci number is even.
```

---

### Problem 12: Fibonacci primes

**Question:** Which Fibonacci numbers are prime?

**Solution:**

```
F(3) = 2 (prime)
F(4) = 3 (prime)
F(5) = 5 (prime)
F(7) = 13 (prime)
F(11) = 89 (prime)
F(13) = 233 (prime)
F(17) = 1597 (prime)
F(23) = 28657 (prime)
F(29) = 514229 (prime)

Note: F(n) can only be prime if n is prime (except F(4)=3).
But not all prime-indexed Fibonacci numbers are prime:
F(19) = 4181 = 37 x 113 (not prime)
```

---

### Problem 13: Matrix exponentiation

**Question:** Use the matrix formula to compute F(6).

**Solution:**

```
| 1  1 |^5     | F(6)  F(5) |
| 1  0 |    =   | F(5)  F(4) |

Computing step by step:
| 1  1 |^2 = | 2  1 |
| 1  0 |     | 1  1 |

| 1  1 |^4 = | 2  1 |^2 = | 5  3 |
| 1  0 |     | 1  1 |     | 3  2 |

| 1  1 |^5 = | 5  3 | x | 1  1 | = | 8  5 |
| 1  0 |     | 3  2 |   | 1  0 |   | 5  3 |

F(6) = 8  (check)
```

---

### Problem 14: Fibonacci and Pascal's triangle

**Question:** The sum of the shallow diagonals of Pascal's triangle gives
Fibonacci numbers. Verify for the first 5 diagonals.

**Solution:**

```
Pascal's triangle:
Row 0:           1
Row 1:         1   1
Row 2:       1   2   1
Row 3:     1   3   3   1
Row 4:   1   4   6   4   1

Diagonal sums:
D1: 1 = F(1)
D2: 1 = F(2)
D3: 1 + 1 = 2 = F(3)
D4: 1 + 2 = 3 = F(4)
D5: 1 + 3 + 1 = 5 = F(5)
```

---

### Problem 15: Growth rate comparison

**Question:** Compare the growth of Fibonacci, powers of 2, and powers of phi.

**Solution:**

```
n  | F(n) | 2^n   | phi^n
---|------|-------|--------
1  | 1    | 2     | 1.618
2  | 1    | 4     | 2.618
3  | 2    | 8     | 4.236
4  | 3    | 16    | 6.854
5  | 5    | 32    | 11.090
6  | 8    | 64    | 17.944
7  | 13   | 128   | 29.034
8  | 21   | 256   | 46.979

Fibonacci grows slower than both 2^n and phi^n.
But F(n) ~ phi^n / sqrt(5), so it grows at the same RATE as phi^n.
```

---

## 10. Summary Table

| Property | Value |
|----------|-------|
| Recurrence | F(n) = F(n-1) + F(n-2) |
| Binet's formula | F(n) = (phi^n - psi^n) / sqrt(5) |
| Cassini | F(n-1)*F(n+1) - F(n)^2 = (-1)^n |
| GCD | gcd(F(m), F(n)) = F(gcd(m,n)) |
| Sum | Sum(F(1)..F(n)) = F(n+2) - 1 |
| Growth | F(n) ~ phi^n / sqrt(5) |
| Parity | Every 3rd is even |

---

## 11. Key Takeaways for Ages 13-16

1. **Binet's formula** computes F(n) directly without recursion.
2. **Cassini's identity** relates consecutive Fibonacci numbers.
3. **The GCD property** connects Fibonacci numbers to number theory.
4. **Zeckendorf's theorem** gives unique representations using Fibonacci numbers.
5. **Matrix exponentiation** computes F(n) in O(log n) time.
6. **The Fibonacci ratio** converges to phi, the golden ratio.

---

*Next: 09_intermediate_lucas.md — The Lucas Numbers*
