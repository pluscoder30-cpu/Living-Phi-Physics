﻿# PHI-BIOLOGY: Worked Examples

---

## Example 1: Phi-Codon Usage Bias

**Problem:** Calculate the phi-weighted expression probability for the codon ATG (Met) in a gene with 300 codons.

**Solution:**
`
Given: Codon = ATG, v(A) = 0, v(T) = 1, v(G) = phi = 1.618

Step 1: Calculate phi-weight
w(ATG) = phi^(-1) x v(A) + phi^(-2) x v(T) + phi^(-3) x v(G)
w(ATG) = 0.618 x 0 + 0.382 x 1 + 0.236 x 1.618
w(ATG) = 0 + 0.382 + 0.382 = 0.764

Step 2: Calculate probability
P(ATG) proportional to phi^(-0.764) = e^(-0.764 x 0.481) = 0.693

Step 3: Relative frequency in 300-codon gene
Expected ATG count = 300 x 0.109 = 33 codons
`

**Answer:** Expected 33 ATG codons in a 300-codon gene (7x overrepresentation)

---

## Example 2: Phi-Protein Folding Energy

**Problem:** Calculate the phi-corrected folding energy for a 150-residue protein with standard DeltaG_fold = -12 kcal/mol.

**Solution:**
`
Given: N = 150 residues, DeltaG_fold = -12 kcal/mol

Step 1: Calculate phi-folding length scale
lambda_fold = R_g/phi = 2.0/1.618 = 1.236 nm

Step 2: Calculate phi-energy correction
DeltaU_phi = -12 x phi^(-1.618) = -12 x 0.459 = -5.51 kcal/mol

Step 3: Total phi-corrected energy
E_total = -12 + (-5.51) = -17.51 kcal/mol
`

**Answer:** DeltaG_phi = -17.51 kcal/mol (46% more stable than standard)

---

## Example 3: Phi-Logistic Growth

**Problem:** A bacteria culture has r = 1.5/hr, K = 10^9 cells/mL, starting at N0 = 10^6. Calculate population at t = 4 hours.

**Solution:**
`
Given: N0 = 10^6, r = 1.5/hr, K = 10^9

Step 1: Phi-corrected parameters
r_phi = r/phi = 0.927/hr
K_phi = K x phi = 1.618 x 10^9

Step 2: Calculate N(4)
N(4) = K_phi / (1 + ((K_phi - N0)/N0) x e^(-r_phi x t))
N(4) = 1.618x10^9 / (1 + 1617 x 0.0245)
N(4) = 3.98 x 10^7 cells/mL
`

**Answer:** N(4) = 3.98 x 10^7 cells/mL (23% lower than standard)

---

## Example 4: Phi-Selection Coefficient

**Problem:** Two alleles compete with fitness difference Dw = 0.05. Calculate the phi-corrected selection coefficient.

**Solution:**
`
Given: s = 0.05, Dw = 0.05

Step 1: Phi-selection coefficient
s_phi = s x phi^(-Dw) = 0.05 x phi^(-0.05)
s_phi = 0.05 x 0.976 = 0.0488

Step 2: Equilibrium frequency
p_hat = mu/(mu + s_phi) = 10^(-6)/(10^(-6) + 0.0488) = 2.05 x 10^(-5)
`

**Answer:** s_phi = 0.0488, p_hat = 2.05 x 10^(-5)

---

## Example 5: Phi-Predator-Prey Oscillations

**Problem:** Model predator-prey with alpha = 1.0, beta = 0.1, delta = 0.075, gamma = 1.5 using phi-Lotka-Volterra.

**Solution:**
`
Given: alpha = 1.0, beta = 0.1, delta = 0.075, gamma = 1.5

Step 1: Phi-corrected parameters
alpha_phi = alpha/phi = 0.618
beta_phi = beta/phi = 0.0618
delta_phi = delta x phi = 0.1214
gamma_phi = gamma/phi = 0.927

Step 2: Equilibrium
x* = gamma_phi/delta_phi = 7.637
y* = alpha_phi/beta_phi = 10.0

Step 3: Oscillation period
T = 2pi/sqrt(alpha_phi x gamma_phi) = 8.30 time units
`

**Answer:** x* = 7.64, y* = 10.0, T = 8.30 (62% longer period)

---

## Example 6: Phi-Biodiversity Index

**Problem:** Calculate the phi-Shannon index for a community with p1 = 0.6, p2 = 0.3, p3 = 0.1.

**Solution:**
`
Given: p1 = 0.6, p2 = 0.3, p3 = 0.1

Step 1: Standard Shannon index
H = -Sigma p_i x ln(p_i) = 0.898

Step 2: Phi-Shannon index
H_phi = H / ln(phi) = 0.898 / 0.4812 = 1.867

Step 3: Evenness
J_phi = H_phi / log_phi(3) = 1.867 / 2.284 = 0.817
`

**Answer:** H_phi = 1.867, J_phi = 0.817

---

## Example 7: Phi-DNA Replication Fidelity

**Problem:** Calculate the phi-corrected mutation rate for human (epsilon_0 = 10^(-10) per bp).

**Solution:**
`
Given: epsilon_0 = 10^(-10), proofreading level = 3

Step 1: Phi-corrected error rate
epsilon_phi = epsilon_0 x phi^(-3) = 10^(-10) x 0.236 = 2.36 x 10^(-11)

Step 2: Per cell division (3 x 10^9 bp)
Standard: 0.3 mutations/cell
Phi: 0.071 mutations/cell (76% fewer)
`

**Answer:** epsilon_phi = 2.36 x 10^(-11), 0.071 mutations/cell/division

---

## Example 8: Phi-Allometric Scaling

**Problem:** Predict metabolic rate of 50 kg mammal. Standard: B = 70 x M^(3/4).

**Solution:**
`
Given: M = 50 kg, B = 70 x M^(3/4), B_phi = 70 x M^(phi^(-1))

Step 1: Standard
B = 70 x 50^(0.75) = 1315 kcal/day

Step 2: Phi-corrected
B_phi = 70 x 50^(0.618) = 786 kcal/day
`

**Answer:** B_phi = 786 kcal/day (40% lower)

---

## Example 9: Phi-Trophic Cascade

**Problem:** Three-level food chain with 1000 kcal/m^2 primary production. Calculate phi-efficiency.

**Solution:**
`
Given: E0 = 1000 kcal/m^2, phi-efficiency = 6.18%

Step 1: Phi trophic pyramid
Level 1: 1000 kcal/m^2
Level 2: 61.8 kcal/m^2
Level 3: 3.82 kcal/m^2
`

**Answer:** 1000 -> 61.8 -> 3.82 kcal/m^2

---

## Example 10: Phi-Gene Regulatory Network

**Problem:** 5-gene network with phi-weighted interactions. Calculate steady-state expression.

**Solution:**
`
Given: w_ij = 0.5 x phi^(-|i-j|), delta = 0.1

Step 1: Solve steady-state equations
x1* = 10.0
x2* = 6.18 (= x1*/phi)
x3* = 3.82 (= x2*/phi)
x4* = 2.36 (= x3*/phi)
x5* = 1.46 (= x4*/phi)
`

**Answer:** Gene expression follows phi-geometric: 10.0, 6.18, 3.82, 2.36, 1.46

---

## Example 11: Phi-Island Biogeography

**Problem:** Expected species on 10,000 km^2 island with mainland S = 500.

**Solution:**
`
Given: A = 10,000 km^2, S_mainland = 500

Step 1: Standard: S = c x A^0.25 = 158 species
Step 2: Phi: S_phi = c x A^0.618 = 29 species
`

**Answer:** S_phi = 29 species (82% fewer on small islands)

---

## Example 12: Phi-Mutation Spectrum

**Problem:** Mutation probability at positions 50 and 200.

**Solution:**
`
Given: mu_0 = 10^(-8), lambda_mutation = 61.8 bp

Step 1: P(50) = 6.78 x 10^(-9)
Step 2: P(200) = 2.11 x 10^(-9)
Step 3: Ratio = 3.21 (approx phi^2)
`

**Answer:** P(50)/P(200) = 3.21

---

## Example 13: Phi-Cell Division Timing

**Problem:** Fibroblast divides every 24 hr. Predict hepatocyte and neuron division times.

**Solution:**
`
Given: T_fibroblast = 24 hr, complexity: fibroblast=1, hepatocyte=2, neuron=3

Step 1: T_0 = 24/phi^0.1 = 22.87 hr
Step 2: Hepatocyte: T = 22.87 x phi^0.2 = 25.18 hr
Step 3: Neuron: T = 22.87 x phi^0.3 = 26.41 hr
`

**Answer:** Hepatocyte: 25.2 hr, Neuron: 26.4 hr

---

## Example 14: Phi-Epistasis

**Problem:** Two loci with a1=0.3, a2=0.4, epsilon=0.2. Calculate phi-corrected fitness.

**Solution:**
`
Given: a1 = 0.3, a2 = 0.4, epsilon = 0.2

Step 1: Standard: W = 1 + 0.3 + 0.4 + 0.2 = 1.9
Step 2: Phi-epistasis: epsilon_phi = 0.2 x phi^(-1) = 0.1236
Step 3: W_phi = 1 + 0.3 + 0.4 + 0.1236 = 1.8236
`

**Answer:** W_phi = 1.8236

---

## Example 15: Phi-Phylogenetic Distance

**Problem:** Phi-corrected human-chimp distance (d = 0.006).

**Solution:**
`
Given: d = 0.006, depth = 1.714 x 10^(-3)

Step 1: d_phi = 0.006 x phi^(-0.00106) = 0.005997
`

**Answer:** d_phi = 0.005997 (negligible change for recent divergence)

---

## Example 16: Phi-Genome Organization

**Problem:** Gene density at 10 Mb and 50 Mb from centromere.

**Solution:**
`
Given: rho_0 = 15 genes/Mb, lambda_gene = 0.618 Mb

Step 1: At 10 Mb: rho(10) = 15 x phi^(-10/0.618) = 15 x phi^(-16.18)
Step 2: At 50 Mb: rho(50) = 15 x phi^(-50/0.618) = 15 x phi^(-80.9)
`

**Answer:** Gene density decays exponentially from centromere

---

## Example 17: Phi-Ecosystem Stability

**Problem:** Calculate stability of 5-species food web with phi-competition.

**Solution:**
`
Given: 5 species, alpha_ij = 0.3/phi for i!=j

Step 1: Stability criterion: all eigenvalues of Jacobian have negative real parts
Step 2: Phi-competition reduces interaction strength
Step 3: Stability margin increases by factor phi
`

**Answer:** Phi-food web is phi-times more stable

---

## Example 18: Phi-Drug Binding

**Problem:** Calculate phi-corrected binding affinity for drug-receptor interaction.

**Solution:**
`
Given: Kd = 10 nM (standard), receptor complexity = 5

Step 1: Kd_phi = Kd x phi^(-complexity/10) = 10 x phi^(-0.5) = 6.18 nM
`

**Answer:** Kd_phi = 6.18 nM (stronger binding)

---

## Example 19: Phi-Population Genetics

**Problem:** Wright-Fisher with phi-drift. Effective population size N_e = 1000.

**Solution:**
`
Given: N_e = 1000, mu = 10^(-6)

Step 1: N_e_phi = N_e x phi = 1618
Step 2: Genetic diversity: theta_phi = 4 x N_e_phi x mu = 6.47 x 10^(-3)
`

**Answer:** N_e_phi = 1618, theta_phi = 6.47 x 10^(-3)

---

## Example 20: Phi-Aging Rate

**Problem:** Calculate phi-corrected aging rate for humans.

**Solution:**
`
Given: lambda_standard = 0.0002/day (Gompertz), complexity = 10

Step 1: lambda_phi = lambda_standard x phi^(-complexity/100)
Step 2: lambda_phi = 0.0002 x phi^(-0.1) = 0.000191/day
`

**Answer:** lambda_phi = 0.000191/day (4.5% slower aging)

---

*Part of the 32_PHI_PHYSICS / 06_EXPANDED_MATHEMATICS system.*
*Version 1.0 -- Agent I of 26*

---

## Example 21: Phi-Enzyme Kinetics

**Problem:** Calculate phi-corrected Km for hexokinase (Km = 0.1 mM).

**Solution:**
`
Given: Km = 0.1 mM, enzyme complexity = 2

Step 1: Phi-corrected Km
Km_phi = Km/phi = 0.1/1.618 = 0.0618 mM

Step 2: Catalytic efficiency
kcat/Km_phi = kcat/(Km/phi) = phi × (kcat/Km)
`

**Answer:** Km_phi = 0.0618 mM (38% stronger binding)

---

## Example 22: Phi-Immune Response

**Problem:** Calculate phi-corrected antibody affinity after 3 rounds of maturation.

**Solution:**
`
Given: Kd_initial = 10^(-8) M, rounds = 3

Step 1: Phi-maturation
Kd_phi = Kd × phi^(-3) = 10^(-8) × 0.236 = 2.36 × 10^(-9) M

Step 2: Compare
Standard: 10^(-8) M
Phi: 2.36 × 10^(-9) M (76% improvement)
`

**Answer:** Kd_phi = 2.36 × 10^(-9) M

---

## Example 23: Phi-Plant Growth

**Problem:** Calculate phi-corrected leaf area index for a canopy with LAI = 3.0.

**Solution:**
`
Given: LAI = 3.0

Step 1: Phi-corrected LAI
LAI_phi = LAI × phi = 3.0 × 1.618 = 4.85

Step 2: Light interception
Interception = 1 - exp(-LAI_phi × k) = 1 - exp(-4.85 × 0.5) = 0.914
Standard: 1 - exp(-1.5) = 0.777
`

**Answer:** LAI_phi = 4.85 (18% more light interception)

---

## Example 24: Phi-Marine Ecology

**Problem:** Calculate phi-corrected coral calcification rate.

**Solution:**
`
Given: Rate = 10 mg/cm^2/day, temperature = 25 C

Step 1: Phi-corrected rate
Rate_phi = Rate/phi = 10/1.618 = 6.18 mg/cm^2/day

Step 2: Annual accretion
Accretion_phi = 6.18 × 365 = 2255 mg/cm^2/year
Standard: 10 × 365 = 3650 mg/cm^2/year
`

**Answer:** Rate_phi = 6.18 mg/cm^2/day (38% slower calcification)

---

## Example 25: Phi-Microbiology

**Problem:** Calculate phi-corrected bacterial generation time.

**Solution:**
`
Given: T_gen = 20 min, nutrient = optimal

Step 1: Phi-generation time
T_gen_phi = T_gen/phi = 20/1.618 = 12.36 min

Step 2: Doublings per hour
Standard: 60/20 = 3 doublings/hr
Phi: 60/12.36 = 4.85 doublings/hr
`

**Answer:** T_gen_phi = 12.36 min (38% faster division)

---

## Example 26: Phi-Virology

**Problem:** Calculate phi-corrected viral burst size.

**Solution:**
`
Given: Burst = 1000 virions, host = optimal

Step 1: Phi-burst size
Burst_phi = Burst/phi = 1000/1.618 = 618 virions

Step 2: Viral fitness
Fitness_phi = Burst_phi × survival = 618 × 0.5 = 309
Standard: 1000 × 0.5 = 500
`

**Answer:** Burst_phi = 618 virions (38% smaller burst)

---

## Example 27: Phi-Ecological Succession

**Problem:** Calculate phi-corrected time to climax community.

**Solution:**
`
Given: T_climax = 100 years, disturbance = low

Step 1: Phi-succession time
T_climax_phi = T_climax × phi = 100 × 1.618 = 161.8 years

Step 2: Species accumulation rate
Rate = S_max/T_climax = 200/161.8 = 1.24 species/year
Standard: 200/100 = 2.0 species/year
`

**Answer:** T_climax_phi = 162 years (62% longer succession)

---

## Example 28: Phi-Conservation

**Problem:** Calculate phi-corrected minimum viable population.

**Solution:**
`
Given: MVP = 500, threat_level = moderate

Step 1: Phi-MVP
MVP_phi = MVP/phi = 500/1.618 = 309

Step 2: Reserve size needed
Area = MVP_phi × habitat_per_individual = 309 × 0.1 km^2 = 30.9 km^2
Standard: 500 × 0.1 = 50 km^2
`

**Answer:** MVP_phi = 309 (38% smaller viable population)

---

## Example 29: Phi-Biogeography

**Problem:** Calculate phi-corrected tropical zone boundary.

**Solution:**
`
Given: Boundary = 23.5 degrees latitude

Step 1: Phi-boundary
Boundary_phi = Boundary/phi = 23.5/1.618 = 14.5 degrees

Step 2: Tropical area
Area_phi = sin(14.5°) × 2πR = 0.250 × 40075 = 10,019 km (width)
Standard: sin(23.5°) × 40075 = 16,156 km
`

**Answer:** Boundary_phi = 14.5 degrees (38% narrower tropics)

---

## Example 30: Phi-Evolutionary Rate

**Problem:** Calculate phi-corrected primate substitution rate.

**Solution:**
`
Given: Rate = 1.0 × 10^(-9) substitutions/site/year

Step 1: Phi-rate
Rate_phi = Rate/phi = 1.0 × 10^(-9)/1.618 = 6.18 × 10^(-10)

Step 2: Time to divergence
For 1% divergence: t = 0.01/Rate_phi = 1.62 × 10^7 years
Standard: t = 0.01/Rate = 1.0 × 10^7 years
`

**Answer:** Rate_phi = 6.18 × 10^(-10) (38% slower evolution)

