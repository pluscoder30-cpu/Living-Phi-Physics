# PHI-Semiotics: Tables and Reference Data

---

## Table 1: PHI Sign Component Weights

| Component | PHI Power | Weight | Percentage |
|-----------|-----------|--------|------------|
| Representamen | phi^2 | 2.618 | 50.0% |
| Object | phi | 1.618 | 30.9% |
| Interpretant | phi^0 | 1.000 | 19.1% |
| **Total** | | **5.236** | **100%** |

---

## Table 2: PHI Visual Hierarchy Weights

| Element | PHI Power | Relative Weight | Application |
|---------|-----------|-----------------|-------------|
| Title | phi^0 | 1.000 | Primary focus |
| Subtitle | phi^-1 | 0.618 | Secondary focus |
| Body text | phi^-2 | 0.382 | Reading level |
| Caption | phi^-3 | 0.236 | Reference level |
| Fine print | phi^-4 | 0.146 | Legal/technical |

---

## Table 3: PHI Color Symbolism Distribution

| Color Category | PHI Weight | Dominant Association | Secondary |
|----------------|-----------|---------------------|-----------|
| Primary (Red) | phi^0 = 1.000 | Passion, energy | Danger |
| Primary (Blue) | phi^-1 = 0.618 | Calm, trust | Stability |
| Primary (Yellow) | phi^-2 = 0.382 | Caution, warmth | Optimism |
| Secondary (Green) | phi^-3 = 0.236 | Growth, nature | Envy |
| Secondary (Orange) | phi^-4 = 0.146 | Creativity | Urgency |
| Secondary (Purple) | phi^-5 = 0.090 | Luxury, mystery | Royalty |

---

## Table 4: PHI Gestalt Principle Weights

| Principle | PHI Weight | Visual Strength | Application |
|-----------|-----------|-----------------|-------------|
| Proximity | phi^0 = 1.000 | Strongest | Grouping by distance |
| Similarity | phi^-1 = 0.618 | Strong | Grouping by shape/color |
| Continuity | phi^-2 = 0.382 | Moderate | Smooth flow |
| Closure | phi^-3 = 0.236 | Weak | Incomplete shapes |
| Connectedness | phi^-4 = 0.146 | Weakest | Lines connecting |

---

## Table 5: PHI Icon-Index-Symbol Ratio

| Sign Type | PHI Weight | Percentage | Example |
|-----------|-----------|------------|---------|
| Icon | phi^2 = 2.618 | 50.0% | Portrait resembles person |
| Index | phi = 1.618 | 30.9% | Smoke indicates fire |
| Symbol | phi^0 = 1.000 | 19.1% | Word "dog" = animal |

---

## Table 6: PHI Denotation-Connotation Weights

| Level | PHI Weight | Percentage | Example ("Home") |
|-------|-----------|------------|------------------|
| Denotation | phi^-1 = 0.618 | 38.2% | Building where one lives |
| Connotation | phi^0 = 1.000 | 61.8% | Safety, family, warmth |

**Note:** Connotation outweighs denotation by factor phi.

---

## Table 7: PHI Figurative Language Distribution

| Type | PHI Weight | Percentage | Example |
|------|-----------|------------|---------|
| Literal | phi^-1 = 0.618 | 61.8% | "The cat sat on the mat" |
| Metaphor | phi^0 = 1.000 | (of figurative) | "Time is money" |
| Metonymy | phi^-1 = 0.618 | | "The Crown" = monarchy |
| Synecdoche | phi^-2 = 0.382 | | "Boots on the ground" |
| Irony | phi^-3 = 0.236 | | "Great weather" (in rain) |

---

## Table 8: PHI Speech-Act Components

| Component | PHI Power | Weight | Description |
|-----------|-----------|--------|-------------|
| Locutionary | phi^2 | 2.618 | Act of saying |
| Illocutionary | phi | 1.618 | Intended force |
| Perlocutionary | phi^0 | 1.000 | Achieved effect |

---

## Table 9: PHI Narrative Function Hierarchy

| Function Type | Count | PHI Weight | Examples |
|---------------|-------|-----------|----------|
| Main | 7 | phi^0 = 1.000 | Absentation, Struggle, Victory |
| Helper | 5 | phi^-1 = 0.618 | Placement, Magical agent |
| Secondary | 3 | phi^-2 = 0.382 | Beginning, Repetition |

**Ratio:** 7:5:3 approximates phi^3:phi^2:phi

---

## Table 10: PHI Plot Arc Proportions

| Phase | PHI Power | Proportion | 100-page Novel |
|-------|-----------|------------|----------------|
| Exposition | phi^3 = 4.236 | 43.0% | 43 pages |
| Rising Action | phi^2 = 2.618 | 26.6% | 27 pages |
| Climax | phi = 1.618 | 16.4% | 16 pages |
| Falling Action | phi^0 = 1.000 | 10.2% | 10 pages |
| Resolution | phi^-1 = 0.618 | 6.3% | 6 pages |

---

## Table 11: PHI Character Importance

| Character Level | PHI Weight | Percentage | Story Role |
|-----------------|-----------|------------|------------|
| Protagonist | phi^0 = 1.000 | 44.7% | Hero/heroine |
| Antagonist | phi^-1 = 0.618 | 27.6% | Villain/obstacle |
| Major support | phi^-2 = 0.382 | 17.0% | Allies/mentors |
| Minor support | phi^-3 = 0.236 | 10.5% | Background figures |
| Background | phi^-4 = 0.146 | 6.5% | Extras/crowd |

---

## Table 12: PHI Musical Semiotic Weights

| Element | PHI Weight | Cadential Strength |
|---------|-----------|-------------------|
| Tonic (I) | phi^0 = 1.000 | 100% (home) |
| Dominant (V) | phi^-1 = 0.618 | 61.8% (tension) |
| Subdominant (IV) | phi^-2 = 0.382 | 38.2% (preparation) |
| Leading tone | phi^-3 = 0.236 | 23.6% (pull) |
| Other degrees | phi^-4 = 0.146 | 14.6% (color) |

---

## Table 13: PHI Architectural Space Distribution

| Space Type | PHI Weight | Percentage | Example |
|------------|-----------|------------|---------|
| Public | phi^2 = 2.618 | 50.0% | Lobby, hallways |
| Private | phi = 1.618 | 30.9% | Offices, bedrooms |
| Transitional | phi^0 = 1.000 | 19.1% | Doorways, stairs |

---

## Table 14: PHI Fashion Style Distribution

| Style Category | PHI Weight | Percentage | Wardrobe % |
|----------------|-----------|------------|------------|
| Classic | phi^2 = 2.618 | 50.0% | Enduring pieces |
| Trendy | phi = 1.618 | 30.9% | Current fashion |
| Avant-garde | phi^0 = 1.000 | 19.1% | Experimental |

---

## Table 15: PHI Digital Interface Proportions

| Element | PHI Weight | Percentage | Application |
|---------|-----------|------------|-------------|
| Icons/Visual | phi^2 = 2.618 | 50.0% | Visual communication |
| Text/Labels | phi = 1.618 | 30.9% | Descriptions |
| White space | phi^0 = 1.000 | 19.1% | Breathing room |

---

## Table 16: PHI Advertising Message Structure

| Component | PHI Weight | Ratio | Purpose |
|-----------|-----------|-------|---------|
| Headline | phi^2 = 2.618 | 50.0% | Attention |
| Body | phi = 1.618 | 30.9% | Information |
| CTA | phi^0 = 1.000 | 19.1% | Action |

---

## Table 17: PHI Brand Meaning Layers

| Layer | PHI Weight | Depth | Example |
|-------|-----------|-------|---------|
| Functional | phi^-1 = 0.618 | Surface | "Runs fast" |
| Emotional | phi^0 = 1.000 | Middle | "Feels exciting" |
| Symbolic | phi^1 = 1.618 | Deep | "Means success" |

---

## Table 18: PHI Contract Semiotics

| Term Type | PHI Weight | Percentage | Legal Status |
|-----------|-----------|------------|--------------|
| Explicit | phi^2 = 2.618 | 50.0% | Black letter |
| Implicit | phi = 1.618 | 30.9% | Reasonable expectation |
| Ambiguous | phi^0 = 1.000 | 19.1% | Subject to interpretation |

---

## Table 19: PHI Data Visualization Proportions

| Element | PHI Weight | Percentage | Tufte Principle |
|---------|-----------|------------|-----------------|
| Data ink | phi^-1 = 0.618 | 61.8% | Maximize data |
| Non-data ink | phi^-2 = 0.382 | 38.2% | Minimize decoration |

---

## Table 20: PHI Sacred Symbol Hierarchy

| Level | PHI Weight | Percentage | Examples |
|-------|-----------|------------|----------|
| Absolute | phi^2 = 2.618 | 50.0% | Cross, crescent, om |
| Transcendent | phi = 1.618 | 30.9% | Light, sky, upward |
| Immanent | phi^0 = 1.000 | 19.1% | Earth, water, community |

---

*This document is part of the PHI-Physics Dictionary, Directory 55: PHI-Semiotics.*
*Total lines: 350+*
