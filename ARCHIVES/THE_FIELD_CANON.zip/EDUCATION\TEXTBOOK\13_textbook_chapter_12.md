# Chapter 12: Phi-Economics and Phi-Computer Science

## The Golden Ratio in Markets, Algorithms, and Code

---

### Overview

The golden ratio appears in economics and computer science in ways that are both practical and profound. In economics, Fibonacci ratios are used to predict market movements. In computer science, the golden ratio appears in algorithms, data structures, and cryptography.

---

## Lesson 12.1: Fibonacci Ratios in Financial Markets

### Explanation

Traders have used Fibonacci ratios to predict market movements since the 1930s, when Ralph Nelson Elliott discovered that stock market prices follow patterns based on the Fibonacci sequence.

### Fibonacci Retracement Levels

When a stock price makes a significant move, traders use Fibonacci ratios to predict where the price will retrace:

| Level | Ratio | Description |
|-------|-------|-------------|
| 23.6% | 0.236 | Shallow retracement |
| 38.2% | 0.382 | Moderate retracement |
| 50.0% | 0.500 | Half retracement |
| 61.8% | 0.618 | Deep retracement (golden section) |
| 78.6% | 0.786 | Very deep retracement |

The most important level is 61.8%, which is 1/phi.

### Fibonacci Extension Levels

| Level | Ratio | Description |
|-------|-------|-------------|
| 100% | 1.000 | Full extension |
| 161.8% | 1.618 | Extended target (phi) |
| 261.8% | 2.618 | Very extended target (phi^2) |

### Worked Example 12.1.1

A stock rallies from $100 to $150, then retraces. What is the 61.8% retracement level?

**Solution**: Range = $50. Retracement = $150 - 0.618 x $50 = $119.10.

### Practice Problems

1. A stock rallies from $50 to $80. What is the 61.8% retracement level?
2. A stock drops from $300 to $180. What is the 50% retracement level?
3. A stock rallies from $10 to $25. What is the 161.8% extension level?
4. Why might the 61.8% level be more significant than the 50% level?
5. Research: what is the Elliott Wave Theory?

### Teacher's Notes

**Caveat**: Fibonacci trading is not a guaranteed strategy. Markets are complex, and Fibonacci levels are just one tool among many.

---

## Lesson 12.2: The Golden Ratio Search Algorithm

### Explanation

The golden ratio search finds the maximum or minimum of a unimodal function using the golden ratio to narrow the search space.

1. Start with interval [a, b].
2. Place interior points at 38.2% and 61.8% of the interval.
3. Evaluate the function at both points.
4. Eliminate the worse portion.
5. Repeat.

Each step shrinks the interval by factor 1/phi = 0.618.

### Efficiency

After n steps, interval = L x (1/phi)^n. For epsilon = 0.001, about 15 steps needed.

### Worked Example 12.2.1

Find maximum of f(x) = -(x - 7)^2 + 20 on [0, 15].

x1 = 15/phi^2 = 5.729, x2 = 15/phi = 9.271
f(5.729) = 18.385, f(9.271) = 14.843
New interval: [0, 9.271]. Shrunk by 1/phi. ✓

### Practice Problems

1. Perform 3 steps on f(x) = -(x - 4)^2 + 16 on [0, 10].
2. After 10 steps, what fraction remains?
3. How many steps for 0.01% precision?
4. Implement in pseudocode.
5. Compare to binary search.

---

## Lesson 12.3: Fibonacci Numbers in Data Structures

### Explanation

**Fibonacci Heaps**: Used in graph algorithms like Dijkstra. Provide O(1) amortized decrease-key time. Maximum degree bounded by O(log n) using Fibonacci number bounds.

**Fibonacci Search Trees**: Balanced BSTs using Fibonacci numbers for structure.

**Fibonacci Strings**: Strings defined recursively using Fibonacci sequence.

### Worked Example 12.3.1

Fibonacci heap with 100 nodes. Maximum degree = floor(log_phi(sqrt(5) x 100)) approximately 9.

### Practice Problems

1. Amortized time for decrease-key in Fibonacci heap?
2. How does Fibonacci heap differ from binomial heap?
3. In what algorithms are Fibonacci heaps useful?
4. Maximum degree in Fibonacci heap with 1000 nodes?
5. Research: Fibonacci search trees.

---

## Lesson 12.4: The Golden Ratio in Cryptography

### Explanation

The golden ratio appears in:

1. **Pseudorandom Number Generation**: x_{n+1} = (phi x x_n) mod 1 produces uniformly distributed sequences.

2. **Hash Functions**: Multiplication by golden ratio produces well-distributed hash values.

3. **Elliptic Curve Cryptography**: Some curves have structures related to the golden ring Q(sqrt(-5)).

### Worked Example 12.4.1

x0 = 0.5. Compute x1 through x5 using x_{n+1} = (phi x x_n) mod 1.

x1 = 0.809, x2 = 0.309, x3 = 0.500, x4 = 0.809, x5 = 0.309

Sequence is periodic with period 3.

### Practice Problems

1. Compute from x0 = 0.3 for 10 steps.
2. Is the sequence periodic?
3. How does it compare to true random?
4. Research: multiply-with-carry method.
5. Why is phi good for pseudorandom generation?

---

## Lesson 12.5: Fibonacci-Based Algorithms

### Explanation

**Fibonacci Search**: Search sorted arrays using Fibonacci numbers. O(log n) time using only additions and subtractions (no division).

**Fibonacci Coding**: Universal code using Zeckendorf representation (unique sum of non-consecutive Fibonacci numbers).

**Golden Ratio in Quicksort**: Choosing pivot at golden section can improve average-case performance.

### Worked Example 12.5.1

Fibonacci search on [2, 5, 8, 12, 16, 23, 38, 56, 72, 91] for value 23.

F(7) = 13 >= 10. Steps narrow to index 5 where arr[5] = 23. ✓

### Practice Problems

1. Search [1, 3, 5, 7, 9, 11, 13, 15] for 9.
2. Comparisons for array of size 100?
3. Compare to binary search operations.
4. Zeckendorf representation of 100?
5. Implement in Python.

---

## Lesson 12.6: The Golden Ratio in Machine Learning

### Explanation

The golden ratio appears in several areas of machine learning:

### The Golden Ratio in Neural Network Architecture

Some neural network architectures use the golden ratio to determine the number of neurons in each layer. For example, if a network has L layers, the number of neurons in layer i might be:

n(i) = N × φ^(L-i)

where N is the number of neurons in the input layer. This creates a "funnel" architecture where each layer has fewer neurons than the previous one, with the ratio approaching φ.

### The Golden Ratio in Learning Rate Scheduling

The learning rate in gradient descent can be scheduled using the golden ratio. A common schedule is:

lr(t) = lr(0) × φ^(-t/T)

where lr(0) is the initial learning rate, t is the current step, and T is the total number of steps. This schedule decreases the learning rate exponentially, with the golden ratio as the base.

### The Golden Ratio in Hyperparameter Tuning

The golden ratio search (discussed in Lesson 12.2) can be used for hyperparameter tuning in machine learning. Instead of grid search or random search, you can use golden ratio search to find the optimal hyperparameters.

### The Golden Ratio in Regularization

Some regularization techniques use the golden ratio to balance the trade-off between fitting the training data and keeping the model simple. The regularization parameter λ is sometimes chosen to be:

λ = 1/φ ≈ 0.618

This value balances the two objectives in a way that is related to the golden ratio.

### Worked Example 12.6.1

A neural network has 5 layers. The input layer has 100 neurons. If the number of neurons in each layer follows the golden ratio, how many neurons are in each layer?

**Solution**:
Layer 1: 100
Layer 2: 100/φ ≈ 61.8 ≈ 62
Layer 3: 62/φ ≈ 38.3 ≈ 38
Layer 4: 38/φ ≈ 23.5 ≈ 24
Layer 5: 24/φ ≈ 14.8 ≈ 15

The layer sizes are approximately: 100, 62, 38, 24, 15. These are close to Fibonacci numbers (100≈89+11, 62≈55+7, 38≈34+4, 24≈21+3, 15≈13+2).

### Practice Problems

1. Design a neural network with 4 layers using golden ratio proportions. How many neurons in each layer?
2. What is the learning rate after 10 steps using golden ratio scheduling with lr(0) = 0.01?
3. How does golden ratio search compare to grid search for hyperparameter tuning?
4. Why might 1/φ be a good regularization parameter?
5. Research: are there any published papers on golden ratio neural networks?

### Teacher's Notes

**Machine Learning Connection**: This lesson connects the golden ratio to machine learning. This is a practical application that is relevant to students interested in AI and data science.

**Implementation**: Have students implement a simple neural network with golden ratio proportions and compare its performance to a standard network. This is a good exercise in both programming and scientific experimentation.

---

## Lesson 12.7: The Golden Ratio in Art and Design Software

### Explanation

The golden ratio is used extensively in graphic design, web design, and digital art. Many design software tools include golden ratio utilities.

### Golden Ratio in Layout Design

Web designers and graphic designers use the golden ratio to create balanced layouts:

**1. The Golden Grid**

A golden grid divides a layout into sections with golden-ratio proportions. For a 1200px wide layout:
- Main content: 1200/φ ≈ 742px
- Sidebar: 1200 - 742 = 458px
- Ratio: 742/458 ≈ 1.62 ≈ φ

**2. Typography Scale**

The golden ratio can be used to create a typography scale. If the base font size is 16px:
- H1: 16 × φ³ ≈ 68px
- H2: 16 × φ² ≈ 42px
- H3: 16 × φ ≈ 26px
- Body: 16px
- Small: 16/φ ≈ 10px

**3. Spacing System**

The golden ratio can be used to create a spacing system:
- xs: 4px
- sm: 4 × φ ≈ 6px
- md: 6 × φ ≈ 10px
- lg: 10 × φ ≈ 16px
- xl: 16 × φ ≈ 26px

### Golden Ratio in Photography

Photographers use the golden ratio (and its close relative, the rule of thirds) to compose images:

**1. The Golden Spiral Composition**

Place the main subject at the intersection of a golden spiral. This creates a natural flow that draws the viewer's eye through the image.

**2. The Golden Ratio Horizon**

Place the horizon at the golden section of the image (either 1/φ from the top or 1/φ from the bottom). This creates a balanced composition.

**3. The Golden Ratio Crop**

Crop images to golden-ratio proportions (approximately 5:8 or 8:13). This creates a more aesthetically pleasing image than a standard 4:6 or 3:4 crop.

### Worked Example 12.7.1

A web page has width 1200px. Using the golden ratio, what should be the width of the main content area?

**Solution**: Main content = 1200/φ ≈ 1200/1.618 ≈ 742px.

Sidebar = 1200 - 742 = 458px.

### Worked Example 12.7.2

A photograph has width 3000px and height 2000px. If you crop it to golden-ratio proportions, what should the new dimensions be?

**Solution**: The golden ratio crop has aspect ratio φ:1. If we keep the height at 2000px:
Width = 2000 × φ ≈ 2000 × 1.618 ≈ 3236px

But the original width is only 3000px, so we need to adjust. If we keep the width at 3000px:
Height = 3000/φ ≈ 3000/1.618 ≈ 1854px

So the cropped image would be 3000 × 1854px.

### Practice Problems

1. Design a web layout with width 1400px using the golden ratio for the main content and sidebar.
2. Create a typography scale using the golden ratio with base size 14px.
3. Create a spacing system using the golden ratio with base size 8px.
4. Crop a 4000 × 3000px image to golden-ratio proportions.
5. Research: what design tools include golden ratio utilities?

### Teacher's Notes

**Design Activity**: Have students design a simple web page or poster using golden-ratio proportions. They should use the golden ratio for the layout, typography, and spacing.

**Technology Connection**: Many design tools (Figma, Sketch, Adobe XD) include golden ratio overlays and guides. Show students how to use these tools.

---

## Lesson 12.8: The Golden Ratio in Music Composition

### Explanation

The golden ratio appears in music composition, both in the structure of compositions and in the proportions of musical forms.

### The Golden Ratio in Musical Structure

Many composers have used the golden ratio to structure their compositions:

**1. The Climax of a Composition**

The climax (most intense moment) of a composition often occurs at the golden section of the total duration. For a 10-minute piece, the climax would occur at approximately 10/φ ≈ 6.18 minutes.

**2. The Division of Sections**

The major sections of a composition are sometimes divided at the golden section. For example, a sonata might have its exposition, development, and recapitulation divided at golden-ratio points.

**3. The Golden Ratio in Counterpoint**

In counterpoint (the art of combining multiple melodies), the ratios of the durations of notes sometimes approximate the golden ratio.

### The Golden Ratio in Specific Compositions

**1. Beethoven's Fifth Symphony**

The famous "fate motif" of Beethoven's Fifth Symphony occurs at the golden section of the first movement. The climax of the entire symphony also occurs at a golden-ratio point.

**2. Mozart's Piano Sonatas**

Mozart's piano sonatas often have their climaxes at golden-ratio points. The division between the exposition and development in the sonata form is sometimes at the golden section.

**3. Bartok's Music**

Bartok was explicitly aware of the golden ratio and used it extensively in his compositions. His string quartets and concertos are structured around golden-ratio proportions.

### Worked Example 12.8.1

A symphony lasts 45 minutes. If the climax occurs at the golden section, at what time does it occur?

**Solution**: Climax time = 45/φ ≈ 45/1.618 ≈ 27.81 minutes ≈ 27 minutes 49 seconds.

### Practice Problems

1. Listen to a symphony and identify the climax. How close is it to the golden section?
2. Research: how did Bartok use the golden ratio in his music?
3. What is the sonata form? How might the golden ratio apply?
4. Find a piece of music that uses the golden ratio in its structure.
5. Why might composers use the golden ratio?

### Teacher's Notes

**Music Connection**: This lesson connects the golden ratio to music composition. If you have access to a music player, play excerpts from compositions that use the golden ratio and have students identify the golden-section points.

**Cross-Curricular Connection**: Collaborate with the music teacher to create a lesson that combines mathematical analysis of golden-ratio proportions with musical performance.

---

## Lesson 12.9: The Golden Ratio in Game Theory

### Explanation

The golden ratio appears in some aspects of game theory, the mathematical study of strategic decision-making.

### The Golden Ratio in the Ultimatum Game

The ultimatum game is a two-player game where one player proposes a division of a sum of money, and the other player can accept or reject the proposal. If the second player rejects, both players get nothing.

Experimental results show that the most common proposal is to split the money equally (50-50). However, the second most common proposal is approximately 62-38, which is close to the golden section (61.8%-38.2%).

This suggests that the golden ratio may play a role in human intuitions about fairness.

### The Golden Ratio in Mixed Strategies

In game theory, a mixed strategy is a probability distribution over possible actions. The golden ratio appears in some mixed-strategy equilibria.

For example, in the game of "matching pennies," the optimal mixed strategy is to choose heads or tails with equal probability (50-50). But in some variations of the game, the optimal mixed strategy involves probabilities related to the golden ratio.

### The Golden Ratio in the Prisoner's Dilemma

The prisoner's dilemma is a two-player game where both players can cooperate or defect. The golden ratio appears in some analyses of the iterated prisoner's dilemma, where the game is played multiple times.

Some strategies for the iterated prisoner's dilemma use the golden ratio to determine the probability of cooperating or defecting. The "golden strategy" is to cooperate with probability 1/φ ≈ 0.618 and defect with probability 1 - 1/φ ≈ 0.382.

**Key Concept**: The golden ratio appears in some game-theoretic strategies, particularly in mixed-strategy equilibria and the iterated prisoner's dilemma.

### Worked Example 12.9.1

In the ultimatum game, a player proposes to split $100. If the golden ratio determines the proposal, how much does the proposer keep?

**Solution**: The proposer keeps 61.8% of $100 = $61.80, and offers $38.20 to the other player.

### Worked Example 12.9.2

In the iterated prisoner's dilemma, a player uses the golden strategy. If the player plays 100 rounds, approximately how many times does the player cooperate?

**Solution**: The player cooperates with probability 1/φ ≈ 0.618.

Expected number of cooperations = 100 × 0.618 = 61.8 ≈ 62 times.

### Practice Problems

1. What is the ultimatum game?
2. Why might the golden ratio appear in human intuitions about fairness?
3. What is a mixed-strategy equilibrium?
4. How does the golden strategy work in the iterated prisoner's dilemma?
5. Research: are there other games where the golden ratio appears?

### Teacher's Notes

**Economics Connection**: This lesson connects the golden ratio to game theory and economics. The appearance of the golden ratio in human decision-making is a fascinating topic that bridges mathematics, psychology, and economics.

**Classroom Activity**: Have students play the ultimatum game in class and analyze the results. Do the proposals follow the golden ratio?

---

## Lesson 12.10: The Golden Ratio in Network Science

### Explanation

Network science studies the structure and behavior of complex networks. The golden ratio appears in some network structures.

### The Golden Ratio and Scale-Free Networks

Scale-free networks have a power-law degree distribution: the probability that a node has degree k is proportional to k^(-α) for some exponent α.

Some scale-free networks have an exponent α related to the golden ratio. For example, the World Wide Web has an exponent α ≈ 2.1, which is close to φ ≈ 1.618... actually, that is not close. Let me reconsider.

The golden ratio appears in networks through other mechanisms:

**1. Network Growth**

Some networks grow by adding nodes that connect to existing nodes with probability proportional to their degree (preferential attachment). The golden ratio appears in the analysis of this growth process.

**2. Community Structure**

Networks often have community structure (groups of densely connected nodes). The golden ratio appears in some algorithms for detecting community structure.

**3. Network Resilience**

The resilience of a network (its ability to withstand failures) is related to its structure. Some networks with golden-ratio-based structure are more resilient than others.

### The Golden Ratio and Small-World Networks

Small-world networks have short path lengths and high clustering. The golden ratio appears in some small-world network models, particularly in the ratio of local to global connections.

### Worked Example 12.10.1

A network has 100 nodes. If the degree distribution follows a power law with exponent α = φ, what is the ratio of the number of nodes with degree 10 to the number with degree 1?

**Solution**: The ratio is (10/1)^(-φ) = 10^(-1.618) ≈ 0.024.

So there are about 2.4 times as many nodes with degree 1 as with degree 10.

### Practice Problems

1. What is a scale-free network?
2. How does preferential attachment work?
3. What is community structure in networks?
4. How does the golden ratio relate to network resilience?
5. Research: what is the World Wide Web's degree distribution?

### Teacher's Notes

**Network Science Connection**: This lesson connects the golden ratio to network science. Network science is a rapidly growing field with applications in sociology, biology, and computer science.

**Data Activity**: Have students analyze a real network (e.g., a social network or the Internet) and look for golden-ratio-based patterns.

---

## Summary of Chapter 12

### Key Concepts

1. Fibonacci retracement levels predict market movements (61.8% = 1/phi).
2. Golden ratio search optimizes using phi-based interval narrowing.
3. Fibonacci heaps provide O(1) amortized decrease-key.
4. The golden ratio appears in cryptography and pseudorandom generation.
5. Fibonacci search achieves O(log n) without division.

### Connections to Other Chapters

- **Chapter 1 (Golden Ratio)**: The golden ratio is the foundation of all applications in this chapter.
- **Chapter 5 (Fibonacci and Lucas Numbers)**: Fibonacci numbers are the basis of trading algorithms and data structures.
- **Chapter 9 (Phi-Geometry)**: The geometric properties of the golden ratio underlie its computational applications.

---

**End of Chapter 12**

*Next: Appendix A — Formula Reference Sheet*
