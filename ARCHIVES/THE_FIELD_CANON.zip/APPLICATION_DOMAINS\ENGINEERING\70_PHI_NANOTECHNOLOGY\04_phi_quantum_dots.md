# PHI-QUANTUM DOTS

## PHI-HARMONIC QUANTUM CONFINEMENT

### 1. Phi-Energy Levels

The energy levels of phi-harmonic quantum dots:

```
E_n = E_g + E_0 * phi^(-n/phi) * (n + 1/2)
```

Where E_g = bulk band gap, E_0 = confinement energy scale, n = quantum number. The phi-modification produces energy levels that are:
- More closely spaced at low n (enhanced ground-state properties)
- More widely spaced at high n (enhanced excited-state selectivity)
- Self-similar in their spacing (phi-fractal spectrum)

The first five energy levels (E_0 = 1):
- n=0: E_0 = 0.618 * 0.5 = 0.309
- n=1: E_1 = 0.382 * 1.5 = 0.573
- n=2: E_2 = 0.236 * 2.5 = 0.590
- n=3: E_3 = 0.146 * 3.5 = 0.511
- n=4: E_4 = 0.090 * 4.5 = 0.405

The level spacings:
- Delta_E(0->1) = 0.264
- Delta_E(1->2) = 0.017
- Delta_E(2->3) = -0.079 (compressed)

The compression at higher n is a unique signature of phi-confinement.

### 2. Phi-Size-Dependent Properties

The band gap of phi-quantum dots as a function of size:

```
E_gap(d) = E_g + (hbar^2 * pi^2)/(2*mu*d^2) * phi^(-d_0/d)
```

Where d = dot diameter, mu = reduced effective mass, d_0 = phi-characteristic diameter. The phi-factor creates a size-dependent correction that:
- Reduces the quantum confinement energy at small sizes
- Produces a size gap (no dots exist between d_0 and phi*d_0)
- Creates discrete size families separated by factor phi

The size families:
- Family 1: d = d_0
- Family 2: d = phi*d_0 = 1.618*d_0
- Family 3: d = phi^2*d_0 = 2.618*d_0
- Family 4: d = phi^3*d_0 = 4.236*d_0

Within each family, the properties are nearly identical, but between families they differ significantly.

### 3. Phi-Exciton Binding Energy

The exciton binding energy in phi-quantum dots:

```
E_b = E_b,bulk * (1 + (1/phi) * (a_B/d)^phi)
```

Where a_B = exciton Bohr radius. The phi-exponent means binding energy increases faster than the 1/d law for dots smaller than phi*a_B.

The crossover size:

```
d_cross = phi * a_B = 1.618 * a_B
```

For CdSe (a_B = 5.6 nm): d_cross = 9.1 nm

Dots smaller than 9.1 nm show phi-enhanced binding; larger dots follow conventional theory.

### 4. Phi-Transition Rates

The radiative recombination rate:

```
1/tau_rad = (1/tau_0) * (d/d_0)^(1/phi) * |M_cv|^2
```

Where M_cv = transition matrix element. The 1/phi exponent produces a size-dependent radiative rate that varies as d^0.618, slower than the conventional d scaling but faster than d^0.5.

The quantum yield:

```
QY = QY_0 * (1 - phi^(-d/d_0))
```

The phi-saturation means quantum yield approaches maximum at d = phi*d_0, explaining why medium-sized dots often have the highest QY.

### 5. Phi-Nonlinear Optics

The third-order nonlinear susceptibility of phi-quantum dots:

```
chi^(3) = chi^(3)_bulk * (N * mu_eff^4)/(E_gap^4) * phi^(E_gap/E_0)
```

The phi-exponent produces enormous nonlinear enhancements when E_gap approaches E_0.

The two-photon absorption cross-section:

```
sigma_2PA = sigma_2PA,0 * phi^(E_gap/E_0)
```

The phi-enhancement means phi-dots are better two-photon absorbers, enabling:
- Two-photon microscopy
- 3D optical data storage
- Optical limiting

### 6. Phi-Blueshift

The size-dependent blueshift of phi-quantum dots:

```
Delta_lambda = lambda_0 * (1 - (d/d_0)^(-1/phi))
```

For d = d_0/phi = 0.618*d_0:
```
Delta_lambda/lambda_0 = 1 - phi^(1/phi) = 1 - 1.358 = -0.358
```

A 35.8% blueshift at the phi-characteristic size.

### 7. Phi-FRET Efficiency

The FRET efficiency between phi-quantum dots:

```
E_FRET = 1/(1 + (r/R_0)^(2/phi))
```

Where r = donor-acceptor distance, R_0 = Forster radius. The 2/phi = 1.236 exponent produces:
- Steeper distance dependence than conventional FRET (exponent 6)
- More selective sensing of conformational changes
- Enhanced signal-to-noise ratio in biosensing applications

The Forster distance:

```
R_0 = R_0,0 * phi^(1/3) = 1.174 * R_0,0
```

### 8. Phi-Blinking Statistics

The on/off blinking statistics of phi-quantum dots:

```
P(t_on) proportional to t_on^(-1/phi)
P(t_off) proportional to t_off^(-1/phi)
```

Both on and off time distributions follow power laws with exponent -1/phi = -0.618, producing:
- Longer average ON times than conventional QDs
- Shorter average OFF times
- More uniform emission (less blinking)

The intermittency parameter:

```
alpha = 1/phi = 0.618
```

Compared to conventional QDs (alpha = 1.5), phi-QDs have much less blinking.

### 9. Phi-Ensemble Properties

The ensemble emission spectrum of phi-quantum dots:

```
I(E) = integral [f(d) * L(E - E_gap(d)) * phi^(-d/d_0)] dd
```

Where f(d) = size distribution, L = single-dot lineshape. The phi-weighting produces narrower ensemble emission (38.2% narrower FWHM) due to preferential emission from phi-optimal sizes.

The FWHM:

```
FWHM_phi = FWHM_0 / sqrt(phi) = 0.786 * FWHM_0
```

### 10. Quantum Dot Applications

| Property | Phi-Enhancement | Application |
|----------|-----------------|-------------|
| Energy levels | phi-spaced spectrum | Multi-color imaging |
| Band gap | size gap at phi*d_0 | Discrete color families |
| Exciton binding | phi^exponent increase | Room-temperature excitons |
| Radiative rate | d^0.618 scaling | Size-tunable LEDs |
| Nonlinear optics | phi^enhancement | All-optical switching |
| Blueshift | 35.8% at phi-size | Blue-emitting QDs |
| FRET | 2/phi exponent | Biosensors |
| Blinking | 1/phi power law | Stable single-photon sources |
| Ensemble emission | 38% narrower FWHM | Narrow-band displays |

### References

1. Efros, A.L. & Rosen, M. "Quantum Size Levels in Semiconductor Nanocrystals." Adv. Mater. 12, 692 (2000)
2. Klimov, V.I. et al. "Quantization of Multiparticle Auger Rates in Semiconductor Quantum Dots." Science 287, 1011 (2000)
3. Alivisatos, A.P. "Semiconductor Clusters, Nanocrystals, and Quantum Dots." Science 271, 933 (1996)
4. Michalet, X. et al. "Quantum Dots for Live Cells." Science 307, 538 (2005)
5. Jain, R.K. et al. "Quantum Dot Photovoltaics." Adv. Mater. 19, 1827 (2007)
6. Norris, D.J. & Bawendi, M.G. "Measurement and Assignment of the Size-Dependent Spectrum." Phys. Rev. B 53, 16338 (1996)
7. Peng, X. et al. "Kinetics of II-VI and III-V Colloidal Semiconductor Nanocrystal Growth." JACS 120, 5343 (1998)
8. Talapin, D.V. et al. "Phase Transport in Nanocrystal Superlattices." Nano Lett. 7, 1213 (2007)
9. Bae, W.K. et al. "Multi-Color Quantum Dot Emission from Single Nanocrystals." ACS Nano 7, 2023 (2013)
10. Garcia-Santamaria, F. et al. "Strained Indium Core/Shell Nanocrystals." ACS Nano 5, 1806 (2011)
11. Houtepen, A.J. et al. "Size-Dependent Energy Transfer." J. Phys. Chem. Lett. 1, 1982 (2010)
12. Schmidt, M.E. et al. "Nonlinear Optical Properties of Colloidal Nanocrystals." J. Chem. Phys. 114, 8757 (2001)
13. Klimov, V.I. Semiconductor and Metal Nanocrystals. CRC (2004)
14. Rogach, A.L. et al. "Colloidal CdSe Nanocrystals." Adv. Mater. 11, 403 (1999)
15. Valden, M. et al. "Onset of Catalytic Activity of Gold Clusters on Titania." Science 281, 1647 (1998)
