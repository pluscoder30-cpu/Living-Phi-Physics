# PHI-ENVIRONMENTAL SCIENCE: Answer Key

---

## Problem 1: Climate Oscillation Decomposition

**(a) Periods:**
```
T_k = φ^k × T₀
T₁ = φ × 120 = 194.2 years
T₂ = φ² × 120 = 314.2 years
T₃ = φ³ × 120 = 508.3 years
```

**(b) Total variation:**
```
ΔT_total = 2 × (B₁ + B₂ + B₃)
= 2 × (0.8 + 0.5 + 0.3)
= 2 × 1.6
= 3.2°C
```

**(c) Temperature at t = 200:**
```
T(200) = T̄ + 0.8 × cos(2π×200/194.2) + 0.5 × cos(2π×200/314.2) + 0.3 × cos(2π×200/508.3)
= T̄ + 0.8 × cos(6.48) + 0.5 × cos(4.00) + 0.3 × cos(2.47)
= T̄ + 0.8 × 0.960 + 0.5 × (−0.654) + 0.3 × (−0.782)
= T̄ + 0.768 − 0.327 − 0.235
= T̄ + 0.206°C
```

**(d) Constructive interference:**
```
All cosines = 1 when:
2πt/T₁ = 2πn₁, 2πt/T₂ = 2πn₂, 2πt/T₃ = 2πn₃
t = n₁ × T₁ = n₂ × T₂ = n₃ × T₃
LCM(194.2, 314.2, 508.3) ≈ 5,000 years (approximate)
```

---

## Problem 2: Biodiversity Prediction

**(a) S₀/A₀:**
```
300 = S₀ × 50^0.618
50^0.618 = 12.77
S₀ = 300/12.77 = 23.5
```

**(b) For 200 km²:**
```
S(200) = 23.5 × 200^0.618
= 23.5 × 32.15
= 756 species
```

**(c) Standard model (exponent 0.25):**
```
S_std(200) = 300 × (200/50)^0.25
= 300 × 4^0.25
= 300 × 1.414
= 424 species
```

**(d) Area for 1,000 species:**
```
1000 = 23.5 × A^0.618
A^0.618 = 42.55
A = 42.55^(1/0.618) = 42.55^1.618 = 614 km²
```

---

## Problem 3: Carbon Cycle Modeling

**(a) Without saturation:**
```
CO₂(100) = 410 × φ^(100/350)
= 410 × φ^0.286
= 410 × 1.173
= 481 ppm
```

**(b) With saturation:**
```
CO₂(100) = 410 × 1.173 × (1 − 410/1200)
= 410 × 1.173 × 0.658
= 316 ppm
```

**(c) Time for 600 ppm:**
```
600 = 410 × φ^(t/350) × (1 − 410/1200)
600 = 410 × φ^(t/350) × 0.658
φ^(t/350) = 600/(410 × 0.658) = 2.228
t/350 = ln(2.228)/ln(φ) = 0.801/0.481 = 1.665
t = 583 years
```

**(d) Equilibrium CO₂:**
```
At equilibrium: dCO₂/dt = 0
CO₂_eq = K_carbon × (1 − τ_carbon × α/K_carbon)
For simple model: CO₂_eq ≈ K_carbon = 1,200 ppm
```

---

## Problem 4: Pollution Dispersion

**(a) Concentrations:**
```
r = 4 km: C = 80 × φ^(−4/12) = 80 × φ^(−0.333) = 80 × 0.794 = 63.5 units
r = 8 km: C = 80 × φ^(−8/12) = 80 × φ^(−0.667) = 80 × 0.630 = 50.4 units
r = 16 km: C = 80 × φ^(−16/12) = 80 × φ^(−1.333) = 80 × 0.397 = 31.8 units
```

**(b) Total mass in zone 0-8 km:**
```
Average concentration ≈ (80 + 50.4)/2 = 65.2
Area = π(8²) = 201.1 km²
Total mass = 201.1 × 65.2 = 13,112 units
```

**(c) Distance for C < 5:**
```
5 = 80 × φ^(−r/12)
0.0625 = φ^(−r/12)
ln(0.0625) = −r/12 × ln(φ)
r = −12 × ln(0.0625)/ln(φ)
= −12 × (−2.773)/0.481
= 69.2 km
```

**(d) 1/r decay comparison:**
```
Standard: C = 80 × 12/r
At r = 4: C_std = 240 (normalized to 80 at r=12)
At r = 8: C_std = 120
At r = 16: C_std = 60
Phi-model: 63.5, 50.4, 31.8 (phi decays faster initially)
```

---

## Problem 5: Sustainability Assessment

**(a) Optimal extraction:**
```
E_opt = R/φ = 800/1.618 = 494.4 tons/year
```

**(b) Sustainability index:**
```
SI = E × φ^(−E/E_opt) / (E_opt × φ^(−1))
= 600 × φ^(−600/494.4) / (494.4 × 0.618)
= 600 × φ^(−1.213) / 305.5
= 600 × 0.442 / 305.5
= 265.2 / 305.5
= 0.868
```

**(c) Reduction for SI = 1.0:**
```
1.0 = E × φ^(−E/494.4) / 305.5
E × φ^(−E/494.4) = 305.5
Solving numerically: E ≈ 494 tons/year (= E_opt)
Reduction needed: (600 − 494)/600 = 17.7%
```

**(d) Depletion time at E = 900:**
```
T_deplete = R₀/(E − E_opt) × ln(φ)
= 5000/(900 − 494.4) × 0.481
= 5000/405.6 × 0.481
= 12.33 × 0.481
= 5.93 years
```

---

## Problem 6: Ecosystem Balance

**(a) Check balance:**
```
Product = Π (r_i/r_max)^(1/φ^i)
= (0.9/0.9)^(1/φ^1) × (0.7/0.9)^(1/φ^2) × (0.5/0.9)^(1/φ^3) × (0.3/0.9)^(1/φ^4)
= 1.0^0.618 × 0.778^0.382 × 0.556^0.236 × 0.333^0.146
= 1.000 × 0.909 × 0.901 × 0.917
= 0.756
```

**(b) Product value:**
```
Product = 0.756
```

**(c) Deviation:**
```
|Product − 1| = |0.756 − 1| = 0.244 = 24.4% deviation
```

**(d) Most impactful adjustment:**
```
Sensitivity: ∂(Product)/∂(r_i)
Species 1: 0.618 × Product/r₁ = 0.618 × 0.756/0.9 = 0.515
Species 2: 0.382 × Product/r₂ = 0.382 × 0.756/0.7 = 0.412
Species 3: 0.236 × Product/r₃ = 0.236 × 0.756/0.5 = 0.357
Species 4: 0.146 × Product/r₄ = 0.146 × 0.756/0.3 = 0.368
Species 1 has highest sensitivity → most impactful to adjust
```

---

## Problem 7: Ocean Acidification

**(a) Find ΔpH:**
```
8.05 = 8.12 − ΔpH × (1 − φ^(−40/250))
0.07 = ΔpH × (1 − φ^(−0.16))
0.07 = ΔpH × (1 − 0.888)
0.07 = ΔpH × 0.112
ΔpH = 0.07/0.112 = 0.625
```

**(b) pH at t = 80:**
```
pH(80) = 8.12 − 0.625 × (1 − φ^(−80/250))
= 8.12 − 0.625 × (1 − φ^(−0.32))
= 8.12 − 0.625 × (1 − 0.801)
= 8.12 − 0.625 × 0.199
= 8.12 − 0.124
= 7.996
```

**(c) Time for pH < 7.8:**
```
7.8 = 8.12 − 0.625 × (1 − φ^(−t/250))
0.32 = 0.625 × (1 − φ^(−t/250))
0.512 = 1 − φ^(−t/250)
φ^(−t/250) = 0.488
−t/250 = ln(0.488)/ln(φ) = −0.717/0.481 = −1.491
t = 250 × 1.491 = 372.8 years
```

**(d) Acidification rate at t = 100:**
```
dpH/dt = −ΔpH × ln(φ)/τ × φ^(−t/τ)
= −0.625 × 0.481/250 × φ^(−100/250)
= −0.001203 × 0.757
= −0.000911 pH units/year
```

---

## Problem 8: Renewable Energy Adoption

**(a) Adoption at various times:**
```
t = 10: F = 0.90 / (1 + φ^(−(10−t₀)/12))
Need t₀ from initial condition:
0.20 = 0.90 / (1 + φ^(t₀/12))
1 + φ^(t₀/12) = 4.5
φ^(t₀/12) = 3.5
t₀/12 = ln(3.5)/ln(φ) = 1.253/0.481 = 2.605
t₀ = 31.26

t = 10: F = 0.90 / (1 + φ^(−(10−31.26)/12)) = 0.90 / (1 + φ^1.772) = 0.90 / (1 + 2.247) = 0.90/3.247 = 27.7%
t = 20: F = 0.90 / (1 + φ^(−(20−31.26)/12)) = 0.90 / (1 + φ^0.938) = 0.90 / (1 + 1.819) = 0.90/2.819 = 31.9%
t = 30: F = 0.90 / (1 + φ^(−(30−31.26)/12)) = 0.90 / (1 + φ^0.105) = 0.90 / (1 + 1.052) = 0.90/2.052 = 43.9%
```

**(b) Time for 50%:**
```
0.50 = 0.90 / (1 + φ^(−(t−31.26)/12))
1 + φ^(−(t−31.26)/12) = 1.8
φ^(−(t−31.26)/12) = 0.8
−(t−31.26)/12 = ln(0.8)/ln(φ) = −0.223/0.481 = −0.464
t−31.26 = 12 × 0.464 = 5.57
t = 36.8 years
```

**(c) Adoption rate at t = 15:**
```
dF/dt = F × (1 − F/F_max) × ln(φ)/τ_adopt
At t = 15: F = 0.90 / (1 + φ^(−(15−31.26)/12)) = 0.90 / (1 + φ^1.355) = 0.90 / (1 + 2.003) = 0.90/3.003 = 30.0%
dF/dt = 0.30 × (1 − 0.30/0.90) × 0.481/12
= 0.30 × 0.667 × 0.0401
= 0.00802 per year = 0.802%/year
```

**(d) Standard logistic comparison:**
```
Standard: F = F_max / (1 + e^(−(t−t₀)/σ))
At t = 30: F_std ≈ 0.90 / (1 + e^(−0.105)) = 0.90 / (1 + 0.900) = 0.90/1.900 = 47.4%
Phi-model: 43.9%
Phi grows slightly faster at early times (3.5% difference at t=30)
```

---

## Problem 9: Water Quality

**(a) Water quality index:**
```
WQ = φ^(−Σ C/C_th) = φ^(−1.5) = 0.487
```

**(b) Classification:**
```
WQ = 0.487 → Fair quality (0.4 < WQ < 0.6)
```

**(c) Load for "Good" quality:**
```
0.618 = φ^(−Σ C/C_th)
ln(0.618) = −Σ C/C_th × ln(φ)
−0.481 = −Σ C/C_th × 0.481
Σ C/C_th = 1.0
```

**(d) If load doubles to 3.0:**
```
WQ = φ^(−3.0) = 0.236 → Poor quality
```

---

## Problem 10: Planetary Boundaries

**(a) Individual contributions:**
```
Boundary 1 (50%): (1 − 0.5^1.618) = 1 − 0.328 = 0.672
Boundary 2 (70%): (1 − 0.7^1.618) = 1 − 0.580 = 0.420
Boundary 3 (90%): (1 − 0.9^1.618) = 1 − 0.844 = 0.156
Boundary 4 (110%): (1 − 1.1^1.618) = 1 − 1.173 = −0.173 (negative = critical)
```

**(b) Total SOS:**
```
SOS = 0.672 × 0.420 × 0.156 × (−0.173)
= −0.0077 (negative = system in critical state)
```

**(c) Most critical:**
```
Boundary 4 (110% of critical) is most critical
Its contribution is negative, making SOS negative
```

**(d) Reduction needed:**
```
For SOS > 0.5: need all terms positive and product > 0.5
Boundary 4 must be reduced below 100%
To get SOS = 0.5 with other boundaries fixed:
0.5 = 0.672 × 0.420 × 0.156 × (1 − x^1.618)
0.5 = 0.0440 × (1 − x^1.618)
11.36 = 1 − x^1.618
x^1.618 = −10.36 (impossible)
Need to reduce ALL boundaries significantly
```

---

## Problem 11: Energy Return on Investment

**(a) Phi-EROI:**
```
EROI_φ = (E_out/E_in) × φ^(−E_in/E_opt)
= 5 × φ^(−1.5)
= 5 × 0.487
= 2.435
```

**(b) Standard EROI:**
```
EROI_std = E_out/E_in = 5.0
```

**(c) Efficiency ratio:**
```
Ratio = EROI_φ/EROI_std = 2.435/5.0 = 0.487 = φ^(−1.5)
```

**(d) Breakeven:**
```
EROI_φ = 1.0 (breakeven)
1.0 = (E_out/E_in) × φ^(−E_in/E_opt)
Assuming E_out/E_in = 5:
1.0 = 5 × φ^(−E_in/E_opt)
0.2 = φ^(−E_in/E_opt)
ln(0.2) = −E_in/E_opt × ln(φ)
E_in/E_opt = −ln(0.2)/ln(φ) = 1.609/0.481 = 3.345
```

---

## Problem 12: Air Quality Index

**(a) AQI:**
```
AQI = φ^(pollutant_load) = φ^2.0 = 2.618
```

**(b) Classification:**
```
AQI = 2.618 → Unhealthy for Sensitive Groups (1.5-3.0 range)
```

**(c) Load for "Moderate" quality:**
```
AQI = 1.0 (Moderate threshold)
1.0 = φ^(load)
load = 0 (Moderate starts at baseline)
For upper Moderate (AQI = 1.5):
1.5 = φ^(load)
load = ln(1.5)/ln(φ) = 0.405/0.481 = 0.842
```

**(d) Health impact ratio:**
```
H = AQI^φ = 2.618^1.618 = 4.595
Baseline (AQI = 1): H₀ = 1^1.618 = 1.0
Ratio = 4.595/1.0 = 4.595
```

---

## Problem 13: Aquifer Depletion

**(a) Water levels:**
```
t = 20: h = 100 × φ^(−20/80) = 100 × φ^(−0.25) = 100 × 0.871 = 87.1 m
t = 40: h = 100 × φ^(−40/80) = 100 × φ^(−0.5) = 100 × 0.786 = 78.6 m
t = 80: h = 100 × φ^(−80/80) = 100 × φ^(−1) = 100 × 0.618 = 61.8 m
```

**(b) Depletion rate at t = 40:**
```
dh/dt = −h × ln(φ)/τ
= −78.6 × 0.481/80
= −78.6 × 0.00601
= −0.472 m/year
```

**(c) Time for h < 20 m:**
```
20 = 100 × φ^(−t/80)
0.2 = φ^(−t/80)
t = −80 × ln(0.2)/ln(φ) = 80 × 3.219 = 257.5 years
```

**(d) Recharge rate for sustainability:**
```
For sustainability: recharge ≥ extraction
Extraction rate = −dh/dt × area
At steady state: recharge = 0.472 m/year × area
If area = 100 km²: recharge = 47.2 million m³/year
```

---

## Problem 14: Particulate Dispersion

**(a) PM at various distances:**
```
r = 2 km: PM = 150 × φ^(−2/8) = 150 × φ^(−0.25) = 150 × 0.871 = 130.7 μg/m³
r = 4 km: PM = 150 × φ^(−4/8) = 150 × φ^(−0.5) = 150 × 0.786 = 117.9 μg/m³
r = 8 km: PM = 150 × φ^(−8/8) = 150 × φ^(−1) = 150 × 0.618 = 92.7 μg/m³
```

**(b) WHO limit exceedance zone:**
```
WHO limit: 15 μg/m³
15 = 150 × φ^(−r/8)
0.1 = φ^(−r/8)
r = −8 × ln(0.1)/ln(φ) = 8 × 4.788 = 38.3 km
Exceedance zone: 0-38.3 km
```

**(c) Population exposed:**
```
Area = π(38.3²) = 4,608 km²
Population = 4,608 × 5,000 = 23,040,000 people
```

**(d) R_PM for compliance at 4 km:**
```
15 = 150 × φ^(−4/R_PM)
0.1 = φ^(−4/R_PM)
ln(0.1) = −4/R_PM × ln(φ)
R_PM = −4/ln(0.1) × ln(φ) = 4/2.303 × 0.481 = 0.835 km
```

---

## Problem 15: Climate Adaptation

**(a) Phi-design level:**
```
Phi-level = 0.3 × φ = 0.3 × 1.618 = 0.485 m
```

**(b) Standard level:**
```
Standard = 0.3 m (exactly the projection)
```

**(c) Cost ratio:**
```
Cost ∝ protection level² (standard engineering)
Cost_phi/Cost_std = (0.485/0.3)² = 1.618² = 2.618
Phi-protection costs 2.618× more
```

**(d) Additional risk reduction:**
```
Standard: protects against 0.3 m (100% of projected)
Phi: protects against 0.485 m (161.8% of projected)
Additional protection: 0.185 m = 61.8% more
Risk reduction: from 100% exposure to 0% exposure for 0.3m events
For 0.485m events: standard fails, phi succeeds
Additional risk reduction: probability of events between 0.3-0.485m
```

---

*End of PHI-ENVIRONMENTAL SCIENCE Answers*
