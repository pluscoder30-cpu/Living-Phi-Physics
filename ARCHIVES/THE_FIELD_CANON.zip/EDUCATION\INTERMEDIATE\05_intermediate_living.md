# 05 — Living Mathematics | Intermediate Level

## Ages 13–16 | Mathematics in Nature and Life

---

## 1. What is "Living Mathematics"?

Living Mathematics studies how mathematical patterns appear in biological
systems, growth processes, and the natural world. It connects abstract
algebra to tangible, observable phenomena.

Key themes:
- Growth patterns (Fibonacci, golden ratio)
- Packing efficiency (phyllotaxis)
- Fractal geometry in nature
- Scaling laws and allometric growth
- Diffusion and reaction-diffusion patterns

---

## 2. Allometric Growth: The 3/4 Power Law

Many biological quantities scale with body mass M according to power laws:

```
Metabolic rate:    B ∝ M^(3/4)
Heart rate:        f ∝ M^(-1/4)
Lifespan:          T ∝ M^(1/4)
Aorta diameter:    d ∝ M^(3/4)
```

**The 3/4 power law (Kleiber's Law):**

```
B = B₀ · M^(3/4)
```

where B₀ is a constant that varies by species.

**Example:**
- Mouse (M = 0.02 kg): B ≈ 0.02^(3/4) ≈ 0.066 W
- Human (M = 70 kg): B ≈ 70^(3/4) ≈ 24.6 W
- Elephant (M = 5000 kg): B ≈ 5000^(3/4) ≈ 562 W

The ratio of metabolic rates is NOT proportional to mass. A human is 3500×
heavier than a mouse but uses only ~370× more energy.

---

## 3. Surface Area and Volume Scaling

As organisms grow, their surface area and volume scale differently:

```
For a sphere of radius r:
  Surface area: A = 4πr²  (scales as r²)
  Volume: V = (4/3)πr³    (scales as r³)
  A/V ratio = 3/r         (decreases with size)
```

**Why this matters:**
- Heat loss is proportional to surface area
- Heat production is proportional to volume
- Small animals lose heat faster (higher A/V ratio)
- This is why small mammals need more food per unit mass

---

## 4. Fractal Dimension in Nature

Many natural structures are fractal-like, with non-integer dimensions:

```
Coastline:         D ≈ 1.25 (varies by measurement scale)
Tree branching:    D ≈ 1.5 - 2.0
Lung airways:      D ≈ 2.97 (nearly fills 3D space)
River networks:    D ≈ 1.8 - 2.2
Blood vessels:     D ≈ 2.7
```

**Fractal dimension** measures how a structure fills space as you zoom in.

**Box-counting method:**
```
D = lim(ε→0) [log(N(ε)) / log(1/ε)]

where N(ε) = number of boxes of size ε needed to cover the structure
```

---

## 5. Fibonacci Numbers in Nature

Beyond phyllotaxis, Fibonacci numbers appear in:

```
Pinecone spirals:    8 and 13 (or 13 and 21)
Sunflower seeds:     34 and 55 (or 55 and 89)
Pineapple scales:    8, 13, 21
Daisy petals:        34, 55, or 89
Branching patterns:  1, 1, 2, 3, 5, 8, 13, ...
```

**Why Fibonacci?** The recurrence F(n) = F(n−1) + F(n−2) is the simplest
additive growth rule that avoids overcrowding. Each new element is placed
in the gap left by the previous two.

---

## 6. Diffusion-Limited Aggregation (DLA)

When particles diffuse randomly and stick together, they form fractal clusters:

```
DLA dimension: D ≈ 1.71 in 2D
              D ≈ 2.5 in 3D
```

**Examples:**
- Lightning bolts
- River deltas
- Mineral deposits (dendrites)
- Neuron growth
- Coral growth

---

## 7. Reaction-Diffusion Patterns

Turing patterns form when two chemicals diffuse at different rates:

```
Activator: promotes its own production (slow diffusion)
Inhibitor: suppresses the activator (fast diffusion)

Result: Spots, stripes, or labyrinthine patterns
```

**Turing's model (1952):**

```
∂u/∂t = Dᵤ∇²u + f(u,v)
∂v/∂t = Dᵥ∇²v + g(u,v)

where Dᵥ >> Dᵤ (inhibitor diffuses faster)
```

**Examples in nature:**
- Zebra stripes
- Leopard spots
- Tropical fish patterns
- Shell markings

---

## 8. Logistic Growth

Population growth with a carrying capacity K:

```
dP/dt = rP(1 − P/K)

Solution: P(t) = K / (1 + ((K − P₀)/P₀)e^(−rt))
```

This S-shaped curve describes:
- Bacterial growth in a petri dish
- Adoption of new technology
- Spread of diseases (early phase)
- Population dynamics

---

## 9. Worked Problems

### Problem 1: Allometric scaling

**Question:** A cat weighs 4 kg and has a metabolic rate of 16 W. A tiger weighs
200 kg. Estimate the tiger's metabolic rate using Kleiber's Law.

**Solution:**

```
B ∝ M^(3/4)

B_tiger / B_cat = (M_tiger / M_cat)^(3/4)
                = (200/4)^(3/4)
                = 50^(3/4)
                = 50^(0.75)
                ≈ 18.8

B_tiger ≈ 18.8 × 16 ≈ 301 W
```

The tiger is 50× heavier but uses only ~19× more energy.

---

### Problem 2: Surface area scaling

**Question:** If a cell doubles its radius, by what factor does its surface area
and volume change?

**Solution:**

```
Original radius: r
New radius: 2r

Surface area: 4πr² → 4π(2r)² = 16πr²
Factor: 16πr² / 4πr² = 4 (quadruples)

Volume: (4/3)πr³ → (4/3)π(2r)³ = (32/3)πr³
Factor: (32/3)πr³ / (4/3)πr³ = 8 (octuples)

Surface area increases 4×, volume increases 8×.
The A/V ratio halves, making diffusion less efficient.
```

---

### Problem 3: Fractal dimension

**Question:** A coastline is measured with rulers of length 1 km, 0.1 km, and
0.01 km. The measured lengths are 1000 km, 1600 km, and 2560 km respectively.
Estimate the fractal dimension.

**Solution:**

```
Using D = log(N₂/N₁) / log(ε₁/ε₂)

From 1 km to 0.1 km:
  N₁ = 1000/1 = 1000 segments
  N₂ = 1600/0.1 = 16000 segments
  D = log(16000/1000) / log(1/0.1)
    = log(16) / log(10)
    = 1.204

From 0.1 km to 0.01 km:
  N₂ = 2560/0.01 = 256000 segments
  D = log(256000/16000) / log(0.1/0.01)
    = log(16) / log(10)
    = 1.204

Fractal dimension D ≈ 1.20
```

---

### Problem 4: Fibonacci in pinecones

**Question:** A pinecone has 8 spirals clockwise and 13 counterclockwise.
What is the ratio? How close to φ is it?

**Solution:**

```
Ratio = 13/8 = 1.625

φ ≈ 1.618034

Difference: |1.625 − 1.618| ≈ 0.007

Percentage error: 0.007/1.618 ≈ 0.43%
```

Very close to φ, as expected from the Fibonacci-golden ratio connection.

---

### Problem 5: Logistic growth

**Question:** A bacteria culture has r = 0.5/hour and K = 1,000,000 cells.
Starting with 1000 cells, how many are there after 10 hours?

**Solution:**

```
P(t) = K / (1 + ((K − P₀)/P₀)e^(−rt))

P(10) = 1,000,000 / (1 + ((1,000,000 − 1000)/1000)e^(−0.5×10))
      = 1,000,000 / (1 + 999 × e^(−5))
      = 1,000,000 / (1 + 999 × 0.006738)
      = 1,000,000 / (1 + 6.731)
      = 1,000,000 / 7.731
      ≈ 129,349 cells
```

---

### Problem 6: Heart rate scaling

**Question:** A mouse (0.02 kg) has a heart rate of 600 bpm. Estimate the heart
rate of a human (70 kg) using allometric scaling.

**Solution:**

```
f ∝ M^(−1/4)

f_human / f_mouse = (M_human / M_mouse)^(−1/4)
                   = (70/0.02)^(−1/4)
                   = 3500^(−0.25)
                   ≈ 0.0728

f_human ≈ 0.0728 × 600 ≈ 43.7 bpm
```

Actual human resting heart rate is ~60-80 bpm. The scaling gives a reasonable
estimate, though other factors affect actual heart rate.

---

### Problem 7: DLA cluster dimension

**Question:** In a DLA simulation, a box of size 100 contains 500 particles.
When the box size is halved to 50, 190 particles are in the same region.
Estimate the fractal dimension.

**Solution:**

```
D = log(N₂/N₁) / log(ε₁/ε₂)
  = log(190/500) / log(50/100)
  = log(0.38) / log(0.5)
  = (−0.4202) / (−0.3010)
  ≈ 1.396
```

This is lower than the theoretical DLA dimension of ~1.71, suggesting the
cluster is still growing or the measurement is approximate.

---

### Problem 8: A/V ratio and cell size

**Question:** Why can't cells be infinitely large?

**Solution:**

```
For a spherical cell of radius r:
  Surface area: A = 4πr²
  Volume: V = (4/3)πr³
  A/V = 3/r

As r increases:
  - Volume grows as r³ (nutrient demand)
  - Surface area grows as r² (nutrient supply)
  - A/V decreases as 3/r

At r = 1 μm: A/V = 3 μm⁻¹  (efficient)
At r = 10 μm: A/V = 0.3 μm⁻¹  (inefficient)
At r = 100 μm: A/V = 0.03 μm⁻¹  (starvation)

Cells must be small enough that A/V is sufficient for diffusion.
This is why most cells are 1-100 μm in diameter.
```

---

### Problem 9: River network fractals

**Question:** A river network has 100 tributaries in a 10 km² region. When the
region is expanded to 100 km², there are 500 tributaries. Estimate the fractal
dimension.

**Solution:**

```
D = log(N₂/N₁) / log(A₂/A₁)^(1/2)
  = log(500/100) / log(100/10)^(1/2)
  = log(5) / log(√10)
  = 0.6990 / 0.5
  ≈ 1.398
```

This suggests a fractal dimension of ~1.4, consistent with measured values
for river networks (D ≈ 1.5-2.0).

---

### Problem 10: Branching in trees

**Question:** A tree branches such that each branch splits into 2 new branches.
After 8 levels of branching, how many branch tips are there?

**Solution:**

```
Level 0: 1 trunk
Level 1: 2 branches
Level 2: 4 branches
Level 3: 8 branches
...
Level n: 2ⁿ branches

Level 8: 2⁸ = 256 branch tips
```

If the branching followed Fibonacci (1, 2, 3, 5, 8, ...), the pattern would
be different and more space-filling.

---

### Problem 11: Allometric comparison

**Question:** Compare the metabolic rates per kilogram for a mouse (0.02 kg)
and an elephant (5000 kg).

**Solution:**

```
Specific metabolic rate: B/M = B₀ · M^(3/4) / M = B₀ · M^(-1/4)

Ratio: (B/M)_mouse / (B/M)_elephant = (M_elephant / M_mouse)^(1/4)
     = (5000/0.02)^(1/4)
     = 250000^(0.25)
     ≈ 22.36

The mouse has ~22× higher metabolic rate per kilogram than the elephant.
```

---

### Problem 12: Shell spiral geometry

**Question:** A nautilus shell grows such that its radius increases by a factor
of φ every quarter turn. If the initial radius is 1 cm, what is the radius
after 3 full turns?

**Solution:**

```
3 full turns = 12 quarter turns

Radius after n quarter turns: r = φⁿ

r(12) = φ¹²
      = (1.618034)¹²
      ≈ 321.997 cm
      ≈ 3.22 meters
```

The nautilus shell is a logarithmic spiral, not a golden spiral, but the
growth factor per quarter turn is similar to φ.

---

### Problem 13: Turing pattern wavelengths

**Question:** In a reaction-diffusion system, Dᵤ = 0.01 and Dᵥ = 0.4. The
critical wavenumber is k_c = √(fᵤgᵥ / (DᵤDᵥ))^(1/2). If fᵤ = 1 and gᵥ = 1,
estimate the wavelength of the pattern.

**Solution:**

```
k_c = √(fᵤgᵥ / (DᵤDᵥ))^(1/2)
    = √(1 × 1 / (0.01 × 0.4))^(1/2)
    = √(1/0.004)^(1/2)
    = √(250)^(1/2)
    = (15.81)^(1/2)
    ≈ 3.98

Wavelength: λ = 2π/k_c ≈ 6.28/3.98 ≈ 1.58 length units
```

---

### Problem 14: Population doubling time

**Question:** Using the logistic model with r = 0.03/year and K = 10 billion,
estimate how long it takes for a population of 1 billion to reach 5 billion.

**Solution:**

```
P(t) = K / (1 + ((K − P₀)/P₀)e^(−rt))

5 = 10 / (1 + ((10 − 1)/1)e^(−0.03t))
5 = 10 / (1 + 9e^(−0.03t))
1 + 9e^(−0.03t) = 2
9e^(−0.03t) = 1
e^(−0.03t) = 1/9
−0.03t = ln(1/9) = −2.197
t = 2.197/0.03 ≈ 73.2 years
```

---

### Problem 15: Why 3/4 power?

**Question:** Explain why metabolic rate scales as M^(3/4) rather than M^(2/3)
(which would be expected from surface area scaling).

**Solution:**

```
If metabolism were limited by surface area:
  B ∝ A ∝ M^(2/3)  [since A ∝ r² and M ∝ r³]

But organisms have fractal-like distribution networks (blood vessels,
airways) that increase the effective surface area beyond simple geometry.

The 3/4 power arises from:
  B ∝ M^(2/3) × (fractal correction)
  The fractal correction factor ≈ M^(1/12)
  Total: B ∝ M^(2/3 + 1/12) = M^(3/4)

This is the West-Brown-Enquist (WBE) model of metabolic scaling.
```

---

## 10. Summary Table

| Concept | Scaling Law | Example |
|---------|-------------|---------|
| Metabolic rate | B ∝ M^(3/4) | Kleiber's Law |
| Heart rate | f ∝ M^(-1/4) | Mouse vs elephant |
| Lifespan | T ∝ M^(1/4) | Small animals die younger |
| Surface area | A ∝ M^(2/3) | Heat loss |
| Volume | V ∝ M^1 | Nutrient demand |
| A/V ratio | A/V ∝ M^(-1/3) | Cell size limit |

---

## 11. Key Takeaways for Ages 13–16

1. **Scaling laws are everywhere:** Body size determines metabolic rate, heart
   rate, lifespan, and more.
2. **The 3/4 power law** is universal across mammals, from mice to whales.
3. **Fractals describe nature:** Coastlines, trees, lungs, and rivers are fractal.
4. **Fibonacci is functional:** It optimizes packing and growth in plants.
5. **Reaction-diffusion creates patterns:** Turing's model explains zebra stripes.
6. **The A/V ratio limits cell size:** Cells must be small enough for diffusion.

---

*Next: 06_intermediate_plastic.md — The Plastic Number*
