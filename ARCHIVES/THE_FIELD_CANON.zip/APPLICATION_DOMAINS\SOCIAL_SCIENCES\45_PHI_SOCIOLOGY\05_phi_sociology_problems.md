# PHI-SOCIOLOGY: Problems and Exercises

---

## Problem 1: Network Topology Analysis

A social network has 1,000 nodes with a phi-power degree distribution P(k) = C × k^(−1/φ).

(a) Find the normalization constant C.
(b) Calculate the average degree ⟨k⟩.
(c) Find the probability that a randomly selected node has degree > 50.
(d) Determine the clustering coefficient C_φ.

---

## Problem 2: Information Cascade Prediction

Information starts from a single source in a network with 5,000 nodes. The per-link transmission probability is p = 0.6. Using phi-weighted cascade:

(a) Find the probability of reaching someone 3 hops away.
(b) Calculate the expected number of people reached at distance 5.
(c) Determine the cascade cutoff distance d* where P_cascade < 0.01.
(d) Compare with the standard cascade model.

---

## Problem 3: Cultural Resonance Analysis

A cultural trait has frequency ω_C = 4.236 × ω₀, where ω₀ is the population's base frequency.

(a) Identify the harmonic number n.
(b) Calculate the propagation time relative to τ₀.
(c) Find the propagation time for a non-resonant trait at ω_C = 1.5 × ω₀.
(d) Determine the ratio of resonant to non-resonant propagation speeds.

---

## Problem 4: Organizational Design

A company has 2,000 employees and wants to restructure using phi-hierarchical principles.

(a) Find the optimal number of management levels.
(b) Calculate the average span of control.
(c) Design the level-by-level breakdown (number of people at each level).
(d) Compare with a standard 6-level hierarchy.

---

## Problem 5: Urban Scaling Prediction

City A has population 50,000 and produces 10,000 patents/year. City B has population 500,000.

(a) Predict City B's patent production using phi-urban scaling (exponent 1/φ).
(b) Predict using standard scaling (exponent 1.2).
(c) Calculate the difference between predictions.
(d) Which model better matches empirical data?

---

## Problem 6: Social Field Calculation

Three individuals with social charges q = [10, 20, 30] are located at distances r = [1, 2, 3] × R₀ from a target individual.

(a) Calculate the total social potential at the target's location.
(b) Find the equilibrium distance if the charges were equal.
(c) Determine the social force direction on the target.
(d) Compare with standard 1/r² potential.

---

## Problem 7: Collective Intelligence

A group of 25 people has individual intelligence I = 120 (IQ units). The cohesion factor is η = 0.8.

(a) Calculate the group intelligence using phi-model.
(b) Calculate using standard √N model.
(c) Find the improvement ratio.
(d) Determine the minimum group size for the group to exceed I = 500.

---

## Problem 8: Conflict Resolution

Two groups have a conflict with initial intensity I₀ = 500 and threshold I_threshold = 25.

(a) Find the resolution time in terms of τ_resolve.
(b) Calculate for τ_resolve = 2 years.
(c) If intensity doubles to 1,000, find the new resolution time.
(d) Determine the intensity reduction needed to halve the resolution time.

---

## Problem 9: Information Memory

A social media post receives 5,000 engagements on day 0. τ_memory = 5 days.

(a) Find engagements at days 1, 3, 7, and 14 using phi-decay.
(b) Calculate the same using exponential decay (same half-life).
(c) Compare the two models at day 14.
(d) Determine when engagements drop below 100.

---

## Problem 10: Institutional Effectiveness

An institution starts with effectiveness E₀ = 100 and decays with τ_institution = 15 years.

(a) Find effectiveness at years 5, 10, 15, and 30.
(b) Calculate the half-life of effectiveness.
(c) Determine when effectiveness drops below 10.
(d) If reforms increase effectiveness by 50% every 20 years, find the long-term steady-state effectiveness.

---

## Problem 11: Demographic Phase-Locking

Two neighboring cities have natural demographic periods of T₁ = 25 years and T₂ = 30 years.

(a) Find the phi-phase-locking period.
(b) Calculate the beat frequency.
(c) Determine the phase difference after 50 years.
(d) Predict when the cities will be in phase.

---

## Problem 12: Migration Wave Analysis

A migration wave starts with v₀ = 8 km/yr and R_front = 60 km.

(a) Find the velocity at 30 km, 60 km, and 120 km.
(b) Calculate the time to reach each distance.
(c) Determine the distance where velocity drops below 1 km/yr.
(d) Compare with a standard exponential decay model.

---

## Problem 13: Cultural Mixing

Two cultures with traits C₁ = 100 and C₂ = 60 mix according to phi-ratios.

(a) Find the resulting mixed culture value.
(b) Calculate the mixing stability index.
(c) Determine the time to full mixing if τ_mix = 10 years.
(d) Predict the trait value after 5 years.

---

## Problem 14: Social Network Resilience

A phi-network with 1,000 nodes loses 38.2% of its nodes randomly.

(a) Find the remaining clustering coefficient.
(b) Calculate the new average path length.
(c) Determine if the network remains connected (using percolation theory).
(d) Find the minimum node fraction needed for connectivity.

---

## Problem 15: Information Velocity

Information travels through a phi-network with D_φ = 100 nodes²/hop.

(a) Find the propagation speed at distance d = 5 hops.
(b) Calculate the time to reach d = 10 hops.
(c) Determine the diffusion coefficient needed to reach d = 20 in 100 time steps.
(d) Compare with standard diffusion (D = 100, same time).

---

*End of PHI-SOCIOLOGY Problems*
