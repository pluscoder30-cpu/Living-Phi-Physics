# Foundation Mathematics: Practice Worksheet

## 100 Problems Across All 10 Systems

This worksheet has 10 problems for each of the 10 ratio-systems you've learned. Draw, count, and explore — no formal proofs needed!

---

## Part 1: Phi (Golden Ratio) — Problems 1-10

### Problem 1: Count the Petals
Look at a picture of a daisy. Count the petals. Is it a Fibonacci number? (Common answers: 13, 21, 34, 55)

### Problem 2: Draw a Golden Rectangle
Draw a rectangle that is 4 cm × 6.47 cm. Is this close to a golden rectangle? (Ratio should be about 1:1.618)

### Problem 3: The Golden Spiral
Draw a golden spiral inside a golden rectangle. Start with a 1×1 square, then add squares of sizes 1, 2, 3, 5, 8...

### Problem 4: Find Phi
Divide these Fibonacci numbers and record the ratio:
- 8 ÷ 5 = ?
- 13 ÷ 8 = ?
- 21 ÷ 13 = ?
- 34 ÷ 21 = ?

How close to 1.618 do you get?

### Problem 5: Nature Hunt
Find 3 things in nature that show phi proportions. Write them down!

### Problem 6: The Golden Identity
Verify: Phi + 1 = Phi × Phi
Use Phi = 1.618
- Phi + 1 = 2.618
- Phi × Phi = ?

### Problem 7: Credit Card
Measure a credit card. Is it a golden rectangle? (Standard size: 85.6 × 53.98 mm)

### Problem 8: Sunflower Spirals
If a sunflower has 34 spirals going clockwise, how many spirals go counterclockwise? (Hint: consecutive Fibonacci numbers)

### Problem 9: Golden Ratio in Your Body
Measure the distance from your navel to the floor, and from the top of your head to your navel. What's the ratio?

### Problem 10: Phi Poem
Write a 4-line poem about phi using these words: spiral, nature, golden, ratio

---

## Part 2: Silver Ratio — Problems 11-20

### Problem 11: The Paper Fold
Take a piece of A4 paper. Fold it in half. Measure both pieces. Do they have the same proportions?

### Problem 12: Draw a Silver Rectangle
Draw a rectangle that is 5 cm × 12.07 cm. (5 × 2.414)

### Problem 13: The Octagon
Draw a regular octagon. Measure the distance across and the length of one side. What's the ratio?

### Problem 14: Silver Sequence
Write out the silver sequence: 2, 2, 6, 14, 34, 82...
Now divide consecutive terms. How close to 2.414 do you get?

### Problem 15: Paper Sizes
List the dimensions of A4, A3, A2, and A1 paper. Are they all the same ratio?

### Problem 16: The Silver Cut
Draw a silver rectangle. Cut off a square. Is the remaining rectangle also silver?

### Problem 17: Silver vs Gold
Which is longer: a golden rectangle or a silver rectangle with the same height?

### Problem 18: Silver Identity
Verify: Silver² = 2 × Silver + 1
Use Silver = 2.414
- Silver² = 5.828
- 2 × Silver + 1 = ?

### Problem 19: Silver Architecture
Find a window or door in your house that has silver proportions. Measure it!

### Problem 20: Silver Poem
Write a 4-line poem about silver using these words: paper, fold, fit, ratio

---

## Part 3: Bronze Ratio — Problems 21-30

### Problem 21: Draw a Bronze Rectangle
Draw a rectangle that is 4 cm × 13.2 cm. (4 × 3.303)

### Problem 22: Bronze Sequence
Write out: 1, 3, 10, 33, 109, 360...
Now divide consecutive terms. How close to 3.303 do you get?

### Problem 23: The Three-Square Cut
Draw a bronze rectangle. Cut off THREE squares. Is the remaining rectangle also bronze?

### Problem 24: Bronze Identity
Verify: Bronze² = 3 × Bronze + 1
Use Bronze = 3.303
- Bronze² = 10.910
- 3 × Bronze + 1 = ?

### Problem 25: Compare All Three
Draw golden, silver, and bronze rectangles with the same height. Which is longest?

### Problem 26: The Tridecagon
A 13-sided polygon has bronze proportions in its diagonals. Draw a simple version!

### Problem 27: Bronze in History
What historical period is named after bronze? When did it happen?

### Problem 28: Bronze Metal
What two metals are mixed to make bronze?

### Problem 29: Bronze Patterns
Create a repeating pattern using bronze rectangles. Draw it!

### Problem 30: Bronze Poem
Write a 4-line poem about bronze using these words: spiral, big, strong, third

---

## Part 4: Harmonic Math — Problems 31-40

### Problem 31: Musical Ratios
What are the ratios for:
- Octave = ? : 1
- Fifth = ? : ?
- Fourth = ? : ?
- Third = ? : ?

### Problem 32: The Harmonic Series
Write the first 8 terms of the harmonic series:
1, 1/2, 1/3, 1/4, ...

### Problem 33: String Lengths
If a guitar string is 64 cm long, how long is the string when you press at the halfway point? What note does it play?

### Problem 34: Wave Patterns
Draw two waves:
- Wave A: 3 cycles in the same space
- Wave B: 4 cycles in the same space

How often do they line up?

### Problem 35: The Tetractys
Draw the Pythagorean tetractys (triangle of 10 dots). What musical ratios does it contain?

### Problem 36: Piano Keys
If you have a piano, measure the length of the white keys. Are they in harmonic proportions?

### Problem 37: Harmony in Nature
Find 3 examples of harmony in nature (not music). Write them down!

### Problem 38: The 12-Note Wheel
Draw a circle divided into 12 sections. Label each section with a note (C, C#, D, etc.).

### Problem 39: Consonant vs Dissonant
What's the difference between consonant and dissonant sounds?

### Problem 40: Harmony Poem
Write a 4-line poem about harmony using these words: sound, ratio, fit, music

---

## Part 5: Living Math — Problems 41-50

### Problem 41: The Coherence Web
Draw a web connecting: you, friends, family, pets, plants, animals, weather, sun. Count the connections!

### Problem 42: The Fractal Tree
Draw a tree that branches in a fractal pattern:
- Trunk
- 2 branches
- 4 branches
- 8 branches
- 16 branches

### Problem 43: Pattern Journal
Write down 3 patterns you noticed today (in nature, music, conversations, etc.)

### Problem 44: The Connection Map
Choose "water" as a topic. Draw a map connecting water in oceans, clouds, rivers, your body, plants, and ice.

### Problem 45: Living Pattern Art
Create a piece of art that shows living math (spirals, branches, repeating patterns).

### Problem 46: The Rhythm Exercise
Clap a rhythm: clap, clap, pause, clap, clap, pause. Can you make a more complex pattern?

### Problem 47: Body Proportions
Measure these ratios on your body:
- Head height ÷ Body height
- Hand length ÷ Forearm length

### Problem 48: Ecosystem Model
Draw a simple ecosystem: 5 plants, 3 herbivores, 1 carnivore. Connect them with arrows.

### Problem 49: Music-Math Connection
Listen to a song and try to draw the wave pattern of the melody.

### Problem 50: Living Math Poem
Write a 4-line poem about living math using these words: alive, connect, pattern, grow

---

## Part 6: Plastic Number — Problems 51-60

### Problem 51: Draw a 3D Spiral
Draw a spiral that goes upward (like a spring). Try to make each turn 1.325 times bigger!

### Problem 52: Plastic Rectangle
Draw a rectangle that is 6 cm × 7.95 cm. (6 × 1.325)

### Problem 53: The Padovan Pattern
Write the Padovan sequence: 1, 1, 1, 2, 2, 3, 4, 5, 7, 9, 12...
Now divide consecutive terms. How close to 1.325 do you get?

### Problem 54: Plastic Identity
Verify: Plastic³ = Plastic + 1
Use Plastic = 1.325
- Plastic³ = 2.325
- Plastic + 1 = ?

### Problem 55: 3D Shape
Build a spiral tower using 5 blocks, each 1.325 times taller than the one below.

### Problem 56: Plastic vs Other Ratios
Draw golden, silver, bronze, and plastic rectangles with the same height. Which seems most "balanced"?

### Problem 57: Spiral Hunt
Find 3 things with 3D spirals: a spring, a spiral staircase, a shell. Measure the ratio between turns if you can!

### Problem 58: Plastic in Music
If you have a piano, play notes that are a plastic interval apart. How does it sound?

### Problem 59: Plastic Art
Create a picture using plastic proportions. Draw spirals and triangles.

### Problem 60: Plastic Poem
Write a 4-line poem about plastic using these words: 3D, spiral, spring, cube

---

## Part 7: Supergolden — Problems 61-70

### Problem 61: Draw a Supergolden Rectangle
Draw a rectangle that is 5 cm × 7.33 cm. (5 × 1.466)

### Problem 62: The Supergolden Triangle
Draw an equilateral triangle. Draw another triangle inside it, rotated slightly. Connect the centers to make a spiral!

### Problem 63: The Cow Path
Imagine a cow walking in a supergolden spiral. Draw its path!

### Problem 64: Supergolden Sequence
Write: 1, 1, 1, 2, 3, 4, 6, 9, 13, 19, 28...
Now divide consecutive terms. How close to 1.466 do you get?

### Problem 65: Supergolden Identity
Verify: Supergolden³ = Supergolden² + 1
Use Supergolden = 1.466
- Supergolden³ = 3.146
- Supergolden² + 1 = ?

### Problem 66: 3-Fold Pattern
Create a pattern with 3-fold symmetry (looks the same after rotating 120°).

### Problem 67: Compare All Ratios
Draw golden, silver, bronze, plastic, and supergolden rectangles. Which one do you like best?

### Problem 68: Supergolden in Nature
Find 3 things in nature that show supergolden proportions (3-fold symmetry, cow paths, etc.)

### Problem 69: Supergolden Music
Play notes that are a supergolden interval apart on a piano. How does it sound?

### Problem 70: Supergolden Poem
Write a 4-line poem about supergolden using these words: three, count, cow, nature

---

## Part 8: Fibonacci — Problems 71-80

### Problem 71: The Rabbit Table
Make a table showing the rabbit problem for 12 months. How many pairs after a year?

### Problem 72: Fibonacci in Nature
Find 3 Fibonacci things in nature: pinecone, sunflower, flower petals. Count them!

### Problem 73: Draw the Fibonacci Spiral
Draw the Fibonacci spiral using squares of sizes 1, 1, 2, 3, 5, 8.

### Problem 74: Fibonacci Calculator
Write the Fibonacci sequence up to 100. Now divide each by the one before it. How close to phi do you get?

### Problem 75: Fibonacci Art
Create a picture using Fibonacci numbers: 1 circle, 1 circle, 2 circles, 3 circles, 5 circles, 8 circles.

### Problem 76: Fibonacci Quilt
Make a "quilt" using Fibonacci squares: color 1 small square red, 1 orange, 2×2 yellow, 3×3 green, 5×5 blue, 8×8 purple.

### Problem 77: Fibonacci Music
Play notes 1, 2, 3, 5, 8 on a piano. Does it sound familiar?

### Problem 78: The Fibonacci Race
Two friends race. One runs 1 lap, then 1, 2, 3, 5, 8... laps. How many laps after 10 rounds?

### Problem 79: Fibonacci Patterns
Draw stars in Fibonacci amounts: 1, 1, 2, 3, 5, 8. Arrange them in a spiral!

### Problem 80: Fibonacci Poem
Write a 4-line poem about Fibonacci using these words: add, nature, spiral, count

---

## Part 9: Lucas Numbers — Problems 81-90

### Problem 81: Lucas Calculator
Write the Lucas sequence up to 200: 2, 1, 3, 4, 7, 11, 18, 29, 47, 76, 123, 199

### Problem 82: Fibonacci vs Lucas
Write both sequences side by side for n = 0 to 10. What patterns do you see?

### Problem 83: The Lucas Spiral
Draw a Lucas spiral using squares of sizes 1, 2, 3, 4, 7, 11.

### Problem 84: Add Them Up
Calculate F(n) + L(n) for n = 5, 6, 7. What do you notice?

### Problem 85: Lucas Primes
Find all Lucas numbers up to 200 that are prime.

### Problem 86: Tower of Hanoi
How many moves does it take to solve Tower of Hanoi with 4 disks? (Hint: 2^4 - 1)

### Problem 87: Lucas Art
Create a picture using Lucas numbers: 2 circles, 1 circle, 3 circles, 4 circles, 7 circles.

### Problem 88: Lucas Pattern
Draw a pattern using Lucas numbers: 2, 1, 3, 4, 7 stars. Arrange them in a spiral!

### Problem 89: Compare Sequences
Write Fibonacci, Lucas, and their sums for n = 0 to 10. What pattern do you see?

### Problem 90: Lucas Poem
Write a 4-line poem about Lucas using these words: twin, Fibonacci, start, two

---

## Part 10: Padovan — Problems 91-100

### Problem 91: Padovan Calculator
Write the Padovan sequence up to 100: 1, 1, 1, 2, 2, 3, 4, 5, 7, 9, 12, 16, 21, 28, 37

### Problem 92: Draw the Padovan Spiral
Draw equilateral triangles with side lengths: 1, 1, 1, 2, 2, 3, 4, 5, 7... Arrange them in a spiral!

### Problem 93: Triangle Count
Draw the first 10 triangles of the Padovan spiral. Count them!

### Problem 94: Padovan vs Fibonacci
Write both sequences for n = 0 to 10. What differences do you notice?

### Problem 95: Build a Padovan Tower
Use blocks to build a tower with Padovan proportions: 1, 1, 1, 2, 2, 3, 4, 5 cm blocks.

### Problem 96: Padovan Art
Create a picture using Padovan triangles: 3 small, 2 medium, 1 large, 1 larger.

### Problem 97: Padovan Patterns
Draw a repeating pattern using Padovan triangles.

### Problem 98: Real-World Padovan
Find 3 things with Padovan proportions: spiral staircase, crystal, shell.

### Problem 99: Padovan Journal
In your journal: write the sequence, draw the spiral, list 3 differences from Fibonacci.

### Problem 100: Padovan Poem
Write a 4-line poem about Padovan using these words: triangle, spiral, plastic, count

---

## Bonus: Creative Projects

### Project 1: Ratio Poster
Create a poster showing all 10 ratio-systems with examples and pictures.

### Project 2: Ratio Music
Compose a short piece of music that uses different ratios for different sections.

### Project 3: Ratio Art
Create a piece of art that incorporates at least 5 different ratio-systems.

### Project 4: Ratio Journal
Keep a journal for one week, finding examples of each ratio-system in your daily life.

### Project 5: Ratio Presentation
Prepare a 5-minute presentation about your favorite ratio-system to share with classmates.

---

*Math is not just about numbers — it's about the patterns that connect everything in the universe. Keep exploring!*
