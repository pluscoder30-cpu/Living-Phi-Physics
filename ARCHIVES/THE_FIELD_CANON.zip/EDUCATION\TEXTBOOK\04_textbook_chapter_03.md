# Chapter 3: The Bronze Ratio

## The Third Metallic Ratio

---

### Overview

The bronze ratio, sometimes denoted by τ (tau) or B, is the third member of the metallic ratio family. It is defined by the equation x² = 3x + 1, and its value is approximately 3.3027756377...

The bronze ratio is less well-known than the golden or silver ratios, but it has its own fascinating properties and appearances in mathematics and nature.

---

## Lesson 3.1: Definition and Properties

### Explanation

The **bronze ratio** is defined as the positive solution of:

x² = 3x + 1

or equivalently:

x² - 3x - 1 = 0

Using the quadratic formula:

x = (3 + √(9 + 4)) / 2 = (3 + √13) / 2

So:

B = (3 + √13) / 2 ≈ 3.3027756377...

**Key Concept**: The bronze ratio is B = (3 + √13)/2 ≈ 3.3027756377...

### Properties of the Bronze Ratio

**Property 1**: B² = 3B + 1

This is the defining equation. Let us verify numerically:
B² = (3.3027756377)² ≈ 10.908326...
3B + 1 = 3 × 3.3027756377 + 1 = 9.908326... + 1 = 10.908326... ✓

**Property 2**: 1/B = B - 3

This can be derived from the defining equation. From B² = 3B + 1, we get:
B² - 3B = 1
B(B - 3) = 1
1/B = B - 3

Numerically: B - 3 = 0.3027756377, and 1/B = 1/3.3027756377 ≈ 0.3027756377. ✓

**Property 3**: B³ = 3B² + B = 10B + 3

From B² = 3B + 1:
B³ = B × B² = B(3B + 1) = 3B² + B = 3(3B + 1) + B = 9B + 3 + B = 10B + 3

Numerically: 10 × 3.3027756377 + 3 = 33.027756377 + 3 = 36.027756377
And: B³ = (3.3027756377)³ ≈ 36.027756377 ✓

**Property 4**: Bⁿ = aₙB + bₙ for integers aₙ, bₙ

Each power of B can be expressed as a linear combination of B and 1 with integer coefficients. The coefficients follow a pattern related to the sequence defined by:

a(0) = 0, a(1) = 1, a(n) = 3a(n-1) + a(n-2)

This is the **bronze sequence** (or "tribonacci-like" sequence with multiplier 3).

### The Bronze Sequence

The bronze sequence is defined by:

a(0) = 0, a(1) = 1, a(n) = 3a(n-1) + a(n-2) for n ≥ 2

The first few terms are:

0, 1, 3, 10, 33, 109, 360, 1189, 3927, 12970, ...

The ratios of consecutive terms approach the bronze ratio:

a(2)/a(1) = 3/1 = 3.0000
a(3)/a(2) = 10/3 ≈ 3.3333
a(4)/a(3) = 33/10 = 3.3000
a(5)/a(4) = 109/33 ≈ 3.3030
a(6)/a(5) = 360/109 ≈ 3.3028
a(7)/a(6) = 1189/360 ≈ 3.3028
a(8)/a(7) = 3927/1189 ≈ 3.3028

These approach B ≈ 3.3027756377...

**Key Concept**: The bronze sequence is the bronze analogue of the Fibonacci sequence, just as the Pell sequence is the silver analogue.

### Worked Example 3.1.1

Compute the first 10 terms of the bronze sequence.

**Solution**: a(0) = 0, a(1) = 1.
a(2) = 3(1) + 0 = 3
a(3) = 3(3) + 1 = 10
a(4) = 3(10) + 3 = 33
a(5) = 3(33) + 10 = 109
a(6) = 3(109) + 33 = 360
a(7) = 3(360) + 109 = 1189
a(8) = 3(1189) + 360 = 3927
a(9) = 3(3927) + 1189 = 12970

### Worked Example 3.1.2

Verify that B = (3 + √13)/2 satisfies the equation 1/B = B - 3.

**Solution**: B = (3 + √13)/2 ≈ 3.3027756377

B - 3 = (3 + √13)/2 - 3 = (3 + √13 - 6)/2 = (√13 - 3)/2

1/B = 2/(3 + √13) = 2(3 - √13)/((3 + √13)(3 - √13)) = 2(3 - √13)/(9 - 13) = 2(3 - √13)/(-4) = (√13 - 3)/2

So 1/B = B - 3. ✓

### Practice Problems

1. Compute B to six decimal places.
2. Verify that B² = 3B + 1 numerically.
3. Compute the first 10 terms of the bronze sequence.
4. Compute a(10) and a(11) using the bronze recurrence.
5. Verify that a(10)/a(9) ≈ B.

### Teacher's Notes

**Pattern Recognition**: Ask students to compare the golden, silver, and bronze sequences:

- Golden: a(n) = a(n-1) + a(n-2) → ratio approaches φ ≈ 1.618
- Silver: a(n) = 2a(n-1) + a(n-2) → ratio approaches δ ≈ 2.414
- Bronze: a(n) = 3a(n-1) + a(n-2) → ratio approaches B ≈ 3.303

What do you notice? The multiplier in the recurrence (1, 2, 3) determines which metallic ratio the sequence approaches. This is a beautiful pattern.

**Extension**: Ask students to find the general metallic sequence for n = 4 (copper) and n = 5 (nickel). What are the recurrences? What do the ratios approach?

---

## Lesson 3.2: The Bronze Rectangle

### Explanation

A **bronze rectangle** is a rectangle whose length-to-width ratio is the bronze ratio B ≈ 3.303.

Just as removing one square from a golden rectangle leaves a golden rectangle, and removing two squares from a silver rectangle leaves a silver rectangle, removing three squares from a bronze rectangle leaves another bronze rectangle.

Let us verify this. Suppose we have a bronze rectangle with length L and width W, where L/W = B. If we remove three W × W squares, the remaining rectangle has length W and width L - 3W.

For this remaining rectangle to also be bronze (in the other orientation), we need:

W / (L - 3W) = L / W = B

This gives us:

W² = L(L - 3W)

W² = L² - 3LW

Rearranging:

L² - 3LW - W² = 0

Dividing by W²:

(L/W)² - 3(L/W) - 1 = 0

Let B = L/W. Then:

B² - 3B - 1 = 0

This is the bronze ratio equation! ✓

**Key Concept**: Removing three squares from a bronze rectangle leaves another bronze rectangle.

### Constructing a Bronze Rectangle

1. Start with a square of side s.
2. The bronze rectangle has dimensions Bs × s = ((3 + √13)/2)s × s.
3. To construct this, you need to add (B - 1)s = ((1 + √13)/2)s to one side of the square.
4. This length can be constructed using a compass and straightedge, since √13 is constructible.

The construction:
1. Draw a square of side s.
2. On one side, mark off a length of 3s (three side-lengths).
3. At the end of this, add a length of (√13 - 3)s/2... this is getting complicated.

Actually, a simpler approach: since B = (3 + √13)/2, we need to construct √13 first.

√13 is the hypotenuse of a right triangle with legs 2 and 3 (since 2² + 3² = 4 + 9 = 13).

So:
1. Draw a square of side s.
2. On one side, construct a right triangle with legs 2s and 3s. The hypotenuse is s√13.
3. Transfer this length to the side of the square using a compass.
4. The resulting rectangle has dimensions (3s + s√13)/2 × s = B × s × s, which is bronze.

Wait, that is not quite right either. Let me think more carefully.

The bronze rectangle has dimensions L × W where L/W = B = (3 + √13)/2.

If W = s, then L = s(3 + √13)/2 = (3s + s√13)/2.

To construct this:
1. Start with a square of side s.
2. Construct a line segment of length s√13 (using the right triangle with legs 2s and 3s).
3. Add this to 3s: the total length is 3s + s√13.
4. Divide by 2: the result is (3s + s√13)/2 = L.

This is the length of the bronze rectangle.

### Worked Example 3.2.1

A bronze rectangle has width 6 cm. What is its length?

**Solution**: Length = B × width = 3.3027756377 × 6 = 19.816653826 cm.

### Worked Example 3.2.2

What fraction of a bronze rectangle's area is removed when you take out three squares?

**Solution**: If the bronze rectangle has dimensions B × 1 (taking W = 1 for simplicity), its area is B.

Three squares each have area 1 × 1 = 1, so total removed area is 3.

Fraction removed: 3/B = 3/3.3027756377 ≈ 0.9083.

Fraction remaining: (B - 3)/B = 1/B² ≈ 0.0917.

So about 9.17% of the area remains after removing three squares.

### Practice Problems

1. A bronze rectangle has width 10 cm. What is its length? Round to two decimal places.
2. A bronze rectangle has length 50 cm. What is its width? Round to two decimal places.
3. Verify that removing three squares from a bronze rectangle leaves another bronze rectangle (numerically).
4. A bronze rectangle has area 300 cm². What are its dimensions?
5. A bronze spiral has equation r = a × B^(2θ/π). What is r when θ = π/2 (one quarter turn)?

### Teacher's Notes

**Pattern Extension**: Ask students to generalize: for the nth metallic ratio M(n), how many squares must be removed from a metallic rectangle to leave another metallic rectangle? (Answer: n squares.)

**Visual Comparison**: Have students draw golden, silver, and bronze rectangles side by side. The golden rectangle is the most "square-like," the bronze rectangle is the most "elongated." This visual comparison helps students understand how the metallic ratios grow.

---

## Lesson 3.3: The Bronze Spiral and Higher Metallic Spirals

### Explanation

The **bronze spiral** is a logarithmic spiral with equation:

r = a × B^(2θ/π)

where B is the bronze ratio. For every quarter turn, the radius increases by a factor of B.

However, because removing three squares from a bronze rectangle requires three quarter-turns to complete one "cycle," the bronze spiral has a different growth pattern than the golden or silver spirals.

More generally, the **nth metallic spiral** has equation:

r = a × M(n)^(2θ/π)

where M(n) is the nth metallic ratio.

### Comparing Metallic Spirals

| Spiral | Growth factor per quarter turn | Growth factor per full turn |
|--------|-------------------------------|----------------------------|
| Golden | φ ≈ 1.618 | φ⁴ ≈ 6.854 |
| Silver | δ ≈ 2.414 | δ⁴ ≈ 33.97 |
| Bronze | B ≈ 3.303 | B⁴ ≈ 119.0 |

The bronze spiral grows much faster than the golden spiral. After one full turn, the bronze spiral is about 119 times its original size, while the golden spiral is only about 7 times its original size.

### Worked Example 3.3.1

A golden spiral and a bronze spiral both start with radius 1 cm. After one complete turn (360°), what are their radii?

**Solution**: 
Golden spiral: r = φ⁴ = ((1 + √5)/2)⁴ ≈ 6.854 cm
Bronze spiral: r = B⁴ = ((3 + √13)/2)⁴ ≈ 119.0 cm

The bronze spiral is about 17 times larger than the golden spiral after one turn.

### Practice Problems

1. A silver spiral starts with radius 1 cm. After one complete turn, what is its radius?
2. A bronze spiral starts with radius 2 cm. After one complete turn, what is its radius?
3. After how many quarter turns does a golden spiral reach 10 times its original radius?
4. After how many quarter turns does a bronze spiral reach 10 times its original radius?
5. Compare the growth of golden, silver, and bronze spirals by computing their radii after 1, 2, and 3 complete turns.

### Teacher's Notes

**Visualization**: Use a graphing calculator or computer program to plot the golden, silver, and bronze spirals on the same axes. This visual comparison is very powerful.

**Nature Connection**: Ask students whether they think bronze spirals appear in nature. (They do not, as far as we know — nature strongly prefers the golden ratio.) Why might nature prefer the golden ratio over the bronze ratio? (The golden ratio minimizes overlap in leaf arrangements, which is why it is favored by evolution.)

---

## Lesson 3.4: The Complete Metallic Ratio Family

### Explanation

We have now studied three metallic ratios: golden (n = 1), silver (n = 2), and bronze (n = 3). Let us complete the picture by examining the general metallic ratio family.

The **nth metallic ratio** M(n) is defined as the positive solution of:

x² = nx + 1

or equivalently:

x² - nx - 1 = 0

Using the quadratic formula:

M(n) = (n + √(n² + 4)) / 2

### Properties of the Metallic Ratio Family

**Property 1**: M(n) > n for all n ≥ 1.

Proof: M(n) = (n + √(n² + 4))/2 > (n + n)/2 = n. ✓

**Property 2**: M(n) → ∞ as n → ∞.

Proof: M(n) = (n + √(n² + 4))/2 > (n + n)/2 = n → ∞. ✓

**Property 3**: 1/M(n) = M(n) - n.

This follows from the defining equation M(n)² = nM(n) + 1, so M(n)(M(n) - n) = 1.

**Property 4**: M(n)² = nM(n) + 1.

This is the defining equation.

**Property 5**: The metallic sequences are defined by a(n) = na(n-1) + a(n-2), and the ratios of consecutive terms approach M(n).

### Table of Metallic Ratios

| n | Name | Formula | Value | 1/M(n) |
|---|------|---------|-------|--------|
| 1 | Golden | (1 + √5)/2 | 1.6180339887 | 0.6180339887 |
| 2 | Silver | (2 + √8)/2 | 2.4142135623 | 0.4142135623 |
| 3 | Bronze | (3 + √13)/2 | 3.3027756377 | 0.3027756377 |
| 4 | Copper | (4 + √20)/2 | 4.2360679774 | 0.2360679774 |
| 5 | Nickel | (5 + √29)/2 | 5.1925824035 | 0.1925824035 |
| 6 | Zinc | (6 + √40)/2 | 6.1622776601 | 0.1622776601 |

Notice that 1/M(n) = M(n) - n, and this decreases as n increases.

### Worked Example 3.4.1

Compute M(10) (the "decathlon" metallic ratio) to six decimal places.

**Solution**: M(10) = (10 + √(100 + 4))/2 = (10 + √104)/2 = (10 + 10.198039027)/2 = 20.198039027/2 = 10.099019514.

### Worked Example 3.4.2

Verify that 1/M(4) = M(4) - 4.

**Solution**: M(4) = (4 + √20)/2 = (4 + 2√5)/2 = 2 + √5 ≈ 4.2360679774.

M(4) - 4 = 2 + √5 - 4 = √5 - 2 ≈ 0.2360679774.

1/M(4) = 1/(2 + √5) = (2 - √5)/((2 + √5)(2 - √5)) = (2 - √5)/(4 - 5) = (2 - √5)/(-1) = √5 - 2 ≈ 0.2360679774.

So 1/M(4) = M(4) - 4. ✓

### Practice Problems

1. Compute M(6) to six decimal places.
2. Verify that M(6)² = 6M(6) + 1 numerically.
3. Compute 1/M(6) and verify it equals M(6) - 6.
4. Compute M(100) to six decimal places.
5. Prove that M(n) = (n + √(n² + 4))/2 satisfies the equation x² = nx + 1 for all n.

### Teacher's Notes

**Unifying Concept**: The metallic ratio family is a beautiful example of how a single idea (the quadratic equation x² = nx + 1) generates an infinite family of mathematical constants. Each member of the family has its own sequence, its own spiral, and its own geometric properties.

**Historical Note**: The metallic ratios have been studied since antiquity. The golden ratio was known to the ancient Greeks. The silver ratio was known to the ancient Indians. The bronze and higher metallic ratios were studied by Indian mathematicians in the 12th century.

**Assessment**: A good assessment for this chapter is to ask students to: (1) define the metallic ratio family, (2) compute M(n) for any given n, (3) explain the relationship between metallic ratios and metallic sequences, and (4) compare the golden, silver, and bronze spirals.

---

## Lesson 3.5: Metallic Ratios in Higher Dimensions

---

## Lesson 3.5: Metallic Ratios in Higher Dimensions

### Explanation

The metallic ratios are not just two-dimensional phenomena. They extend into higher dimensions in fascinating ways.

### The Metallic Ratios and Polyhedra

Just as the golden ratio is related to the icosahedron and dodecahedron (Platonic solids with 5-fold symmetry), the silver ratio is related to the octahedron and cube (Platonic solids with 4-fold symmetry), and the bronze ratio is related to structures with 3-fold symmetry.

The connection is through the symmetry groups:
- Golden ratio ↔ 5-fold symmetry (icosahedron, dodecahedron, Penrose tilings)
- Silver ratio ↔ 4-fold symmetry (octahedron, cube, square tilings)
- Bronze ratio ↔ 3-fold symmetry (tetrahedron, triangular tilings)

### The Silver Ratio and the Octahedron

The octahedron has 8 triangular faces, 12 edges, and 6 vertices. The ratio of the distance between opposite vertices to the edge length is √2, which is closely related to the silver ratio (δ = 1 + √2).

The octahedron can be constructed from three mutually perpendicular squares, just as the icosahedron can be constructed from three mutually perpendicular golden rectangles. The side length of these squares is related to √2.

### The Bronze Ratio and the Tetrahedron

The tetrahedron has 4 triangular faces, 6 edges, and 4 vertices. Its geometry is simpler than the octahedron or icosahedron, but the bronze ratio appears in certain proportions of the tetrahedron.

For example, the ratio of the distance from the center to a vertex to the edge length is √(3/8) ≈ 0.612, which is close to 1/B ≈ 0.303... actually, let me reconsider.

The connection between the bronze ratio and the tetrahedron is less direct than the golden ratio's connection to the icosahedron. The bronze ratio appears in the tetrahedron through the ratios of its diagonals and face heights.

### Metallic Ratios and Crystallography

In crystallography, the symmetry of a crystal is described by its **space group**. The 230 space groups in three dimensions correspond to different combinations of rotational, translational, and reflectional symmetry.

The golden ratio appears in quasicrystals (which have 5-fold symmetry). The silver ratio appears in some conventional crystals (which have 4-fold symmetry). The bronze ratio appears in crystals with 3-fold symmetry.

**Key Concept**: Different metallic ratios correspond to different crystal symmetries: golden = 5-fold, silver = 4-fold, bronze = 3-fold.

### Worked Example 3.5.1

An octahedron has edge length 1. What is the distance between opposite vertices?

**Solution**: The distance between opposite vertices of an octahedron with edge length 1 is:

d = √2 × 1 = √2 ≈ 1.414

This is related to the silver ratio: δ = 1 + √2, so √2 = δ - 1.

### Worked Example 3.5.2

Compare the vertex-to-vertex distances of the tetrahedron, octahedron, and icosahedron, all with edge length 1.

**Solution**:
- Tetrahedron: d = √(8/3) ≈ 1.633
- Octahedron: d = √2 ≈ 1.414
- Icosahedron: d = φ ≈ 1.618

The tetrahedron and icosahedron have similar vertex distances, while the octahedron's is smaller.

### Practice Problems

1. An octahedron has edge length 2. What is the distance between opposite vertices?
2. How is the silver ratio related to the geometry of the octahedron?
3. What symmetry group does a quasicrystal have?
4. What symmetry group does a conventional crystal have?
5. Why can't conventional crystals have 5-fold symmetry?

### Teacher's Notes

**3D Visualization**: If you have access to geometric models or 3D printing, show students the octahedron and tetrahedron. Point out the silver and bronze ratio proportions.

**Connection to Chapter 9**: The relationship between metallic ratios and crystal symmetry is explored in more detail in Chapter 9 (Phi-Geometry) and Chapter 10 (Phi-Chemistry).

---

---

## Lesson 3.7: The Metallic Ratios and Continued Fractions

### Explanation

The metallic ratios have beautiful continued fraction representations that reveal their mathematical structure.

### The Continued Fraction of the Golden Ratio

The golden ratio has the simplest continued fraction:

φ = 1 + 1/(1 + 1/(1 + 1/(1 + ...)))

All partial quotients are 1.

### The Continued Fraction of the Silver Ratio

The silver ratio has:

δ = 2 + 1/(2 + 1/(2 + 1/(2 + ...)))

All partial quotients are 2.

### The Continued Fraction of the Bronze Ratio

The bronze ratio has:

B = 3 + 1/(3 + 1/(3 + 1/(3 + ...)))

All partial quotients are 3.

### The General Pattern

The nth metallic ratio has continued fraction:

M(n) = n + 1/(n + 1/(n + 1/(n + ...)))

All partial quotients are n.

**Key Concept**: The metallic ratios have the simplest continued fractions: all partial quotients are equal to n.

### Convergents of the Metallic Ratios

The convergents (partial sums) of the continued fraction for the metallic ratio M(n) are ratios of terms from the metallic sequence a(k) = na(k-1) + a(k-2).

For the golden ratio (n=1):
Convergents: 1/1, 2/1, 3/2, 5/3, 8/5, 13/8, ... (Fibonacci ratios)

For the silver ratio (n=2):
Convergents: 2/1, 5/2, 12/5, 29/12, 70/29, ... (Pell ratios)

For the bronze ratio (n=3):
Convergents: 3/1, 10/3, 33/10, 109/33, 360/109, ... (bronze sequence ratios)

### Worked Example 3.7.1

Compute the first 5 convergents of the continued fraction for the silver ratio.

**Solution**: δ = 2 + 1/(2 + 1/(2 + 1/(2 + 1/(2 + ...))))

Convergent 1: 2
Convergent 2: 2 + 1/2 = 5/2 = 2.5
Convergent 3: 2 + 1/(2 + 1/2) = 2 + 1/(5/2) = 2 + 2/5 = 12/5 = 2.4
Convergent 4: 2 + 1/(2 + 1/(2 + 1/2)) = 2 + 1/(2 + 2/5) = 2 + 1/(12/5) = 2 + 5/12 = 29/12 ≈ 2.4167
Convergent 5: 70/29 ≈ 2.4138

These converge to δ ≈ 2.4142.

### Practice Problems

1. Compute the first 5 convergents of the continued fraction for the bronze ratio.
2. Verify that the convergents are ratios of the metallic sequence.
3. Why do the metallic ratios have the simplest continued fractions?
4. Which metallic ratio is the most difficult to approximate by rationals?
5. Compute the continued fraction for √3. How does it compare to the metallic ratios?

### Teacher's Notes

**Number Theory Connection**: The continued fraction representations of the metallic ratios are a beautiful example of how number theory connects different areas of mathematics.

**Extension**: Ask students to prove that the convergents of the continued fraction for M(n) are ratios of terms from the metallic sequence a(k) = na(k-1) + a(k-2).

---

## Summary of Chapter 3

### Key Concepts

1. The **bronze ratio** is B = (3 + √13)/2 ≈ 3.3027756377...
2. It is the positive solution of B² = 3B + 1.
3. The **metallic ratio family** is M(n) = (n + √(n² + 4))/2.
4. Each metallic ratio has an associated **metallic sequence**: a(n) = na(n-1) + a(n-2).
5. The ratios of consecutive terms in a metallic sequence approach the corresponding metallic ratio.
6. Each metallic ratio has an associated **metallic spiral**: r = a × M(n)^(2θ/π).
7. Removing n squares from an nth metallic rectangle leaves another metallic rectangle.

### Key Formulas

| Formula | Description |
|---------|-------------|
| B = (3 + √13)/2 | Definition of the bronze ratio |
| B² = 3B + 1 | Fundamental property |
| 1/B = B - 3 | Reciprocal property |
| M(n) = (n + √(n² + 4))/2 | General metallic ratio |
| a(n) = na(n-1) + a(n-2) | Metallic sequence recurrence |
| r = a × M(n)^(2θ/π) | Metallic spiral equation |

### Connections to Other Chapters

- **Chapter 1 (Golden Ratio)**: The golden ratio is M(1), the first metallic ratio.
- **Chapter 2 (Silver Ratio)**: The silver ratio is M(2), the second metallic ratio.
- **Chapter 5 (Fibonacci and Lucas Numbers)**: The Fibonacci sequence is the metallic sequence for n = 1.
- **Chapter 7 (Padovan and Kepler Ratios)**: The Padovan sequence has a different recurrence (P(n) = P(n-2) + P(n-3)) and approaches the plastic number, which is not a metallic ratio.

---

**End of Chapter 3**

*Next: Chapter 4 — Harmonic Mathematics*
