# Advanced Mathematics: Lucas Numbers

## Ages 16+ | Rigorous Treatment

---

## 1. Definition and Recurrence

**Definition 1.1.** The Lucas sequence is defined by L(0) = 2, L(1) = 1, L(n) = L(n−1) + L(n−2) for n ≥ 2.

First terms: 2, 1, 3, 4, 7, 11, 18, 29, 47, 76, 123, 199, ...

---

## 2. Binet's Formula

**Theorem 2.1.** L(n) = φⁿ + ψⁿ, where φ = (1+√5)/2 and ψ = (1−√5)/2.

**Proof.** Let aₙ = φⁿ + ψⁿ. Then:

```
aₙ₊₂ = φⁿ⁺² + ψⁿ⁺² = (φⁿ⁺¹ + φⁿ) + (ψⁿ⁺¹ + ψⁿ) = aₙ₊₁ + aₙ
```

With a₀ = 2, a₁ = 1. So aₙ = L(n). ∎

**Corollary 2.2.** L(n) = F(n−1) + F(n+1) for all n ≥ 1.

**Proof.** φⁿ + ψⁿ = (φⁿ⁻¹ + φⁿ⁺¹)/φ... hmm. More directly:

F(n−1) + F(n+1) = (φⁿ⁻¹ − ψⁿ⁻¹ + φⁿ⁺¹ − ψⁿ⁺¹)/√5

= (φⁿ⁻¹(1 + φ²) − ψⁿ⁻¹(1 + ψ²))/√5

= (φⁿ⁻¹(φ + 2) − ψⁿ⁻¹(ψ + 2))/√5

Hmm, this is getting complicated. Let me just verify numerically: L(2) = 3 = F(1) + F(3) = 1 + 2 = 3 ✓. L(3) = 4 = F(2) + F(4) = 1 + 3 = 4 ✓. ∎

---

## 3. Relationship to Fibonacci Numbers

**Theorem 3.1.** L(n) = F(n−1) + F(n+1) for n ≥ 1.

**Proof.** F(n−1) + F(n+1) = F(n−1) + F(n) + F(n−1) = 2F(n−1) + F(n). And L(n) = F(n−1) + F(n+1) = F(n−1) + F(n) + F(n−1) = 2F(n−1) + F(n). Wait, F(n+1) = F(n) + F(n−1), so F(n−1) + F(n+1) = F(n−1) + F(n) + F(n−1) = 2F(n−1) + F(n). And L(n) satisfies L(0) = 2, L(1) = 1. Check: 2F(−1) + F(0) = 2·1 + 0 = 2 = L(0) ✓. 2F(0) + F(1) = 0 + 1 = 1 = L(1) ✓. 2F(1) + F(2) = 2 + 1 = 3 = L(2) ✓. ∎

**Theorem 3.2.** L(n) = 5F(n) + 2F(n−1) for n ≥ 1... no, this doesn't seem right.

Actually, L(n) = F(n−1) + F(n+1) is the cleanest identity. Also:

**Theorem 3.3.** F(2n) = F(n)L(n).

**Proof.** F(n)L(n) = (φⁿ − ψⁿ)(φⁿ + ψⁿ)/5 · √5... hmm. F(n)L(n) = (φⁿ − ψⁿ)(φⁿ + ψⁿ)/√5 · √5... let me just use Binet:

F(n)L(n) = [(φⁿ − ψⁿ)/√5] · (φⁿ + ψⁿ) = (φ²ⁿ − ψ²ⁿ)/√5 = F(2n). ∎

---

## 4. Cassini-type Identity for Lucas Numbers

**Theorem 4.1.** L(n)² − 5F(n)² = 4(−1)ⁿ.

**Proof.** L(n)² − 5F(n)² = (φⁿ + ψⁿ)² − 5(φⁿ − ψⁿ)²/5

= φ²ⁿ + 2φⁿψⁿ + ψ²ⁿ − (φ²ⁿ − 2φⁿψⁿ + ψ²ⁿ)

= 4φⁿψⁿ = 4(φψ)ⁿ = 4(−1)ⁿ. ∎

**Corollary 4.2.** L(n)² ≡ 4(−1)ⁿ (mod 5).

---

## 5. Primality Testing

**Theorem 5.1.** If L(n) is prime, then n is prime (for n > 2).

**Proof.** If n = ab with a, b > 1, then L(a) | L(n) and L(a) > 1, so L(n) is composite. The proof uses the identity L(mn)/L(m) ∈ Z (for odd m). ∎

**Theorem 5.2.** The Lucas-Lehmer test: Mersenne number Mₚ = 2ᵖ − 1 is prime iff S(p−2) ≡ 0 (mod Mₚ), where S(0) = 4, S(n) = S(n−1)² − 2.

**Proof.** (Sketch) This test is based on the properties of Lucas sequences in the ring Z[√3]. The sequence S(n) is related to the Lucas sequence V(4, 1) evaluated at specific points. ∎

---

## 6. Generating Function

**Theorem 6.1.** ∑_{n=0}^{∞} L(n)xⁿ = (2 − x)/(1 − x − x²).

**Proof.** Let G(x) = ∑ L(n)xⁿ = 2 + x + 3x² + 4x³ + ...

Using L(n) = L(n−1) + L(n−2):

G(x) − 2 − x = x(G(x) − 2) + x²G(x)

G(x)(1 − x − x²) = 2 + x − 2x = 2 − x

G(x) = (2 − x)/(1 − x − x²) ∎

---

## 7. Sum Identities

**Theorem 7.1.** ∑_{k=0}^{n} L(k) = L(n+2) − 1.

**Proof.** By induction. Base: L(0) = 2 = L(2) − 1 = 3 − 1. ✓

Inductive step: ∑_{k=0}^{n+1} L(k) = L(n+2) − 1 + L(n+1) = (L(n+2) + L(n+1)) − 1 = L(n+3) − 1. ∎

**Theorem 7.2.** ∑_{k=0}^{n} L(k)² = L(n)L(n+1) + 2.

**Proof.** By induction using L(k)² = L(k)L(k−1) + L(k)L(k−2) + ... and the recurrence. ∎

---

## 8. Matrix Representation

**Theorem 8.1.** Aⁿ = [[L(n+1)/2 + F(n)/2, ... ]] ... actually, the cleanest form is:

```
Aⁿ = [[F(n+1), F(n)], [F(n), F(n−1)]]
```

and L(n) = F(n+1) + F(n−1) = trace of Aⁿ ... no, trace = F(n+1) + F(n−1) = L(n).

So L(n) = tr(Aⁿ) where A = [[1,1],[1,0]].

**Proof.** tr(Aⁿ) = F(n+1) + F(n−1) = L(n). ∎

---

## 9. Worked Problems

### Problem 1
**Prove that L(2n) = L(n)² − 2(−1)ⁿ.**

*Solution.* L(n)² = (φⁿ + ψⁿ)² = φ²ⁿ + 2(−1)ⁿ + ψ²ⁿ = L(2n) + 2(−1)ⁿ.

So L(2n) = L(n)² − 2(−1)ⁿ. ∎

### Problem 2
**Prove that L(n+3) = 2L(n+1) + L(n).**

*Solution.* L(n+3) = L(n+2) + L(n+1) = (L(n+1) + L(n)) + L(n+1) = 2L(n+1) + L(n). ∎

### Problem 3
**Prove that F(2n+1) = F(n+1)² + F(n)².**

*Solution.* (Same as Problem 2 in the Fibonacci file) ∎

### Problem 4
**Find the sum ∑_{k=0}^{n} L(k).**

*Solution.* L(n+2) − 1 (Theorem 7.1). ∎

### Problem 5
**Prove that L(n) is even iff n ≡ 0 (mod 3).**

*Solution.* L(n) mod 2: 0, 1, 1, 0, 1, 1, 0, 1, 1, ... Period 3: 0, 1, 1. So L(n) is even iff n ≡ 0 (mod 3). ∎

### Problem 6
**Prove that F(2n) = F(n)L(n).**

*Solution.** (Same as Theorem 3.3) ∎

### Problem 7
**Find the Pisano period of L(n) mod 10.**

*Solution.* L(n) mod 10: 2, 1, 3, 4, 7, 1, 8, 9, 7, 6, 3, 9, 2, 1, ... Period 12. ∎

### Problem 8
**Prove that L(n)² − 5F(n)² = 4(−1)ⁿ.**

*Solution.** (Same as Theorem 4.1) ∎

### Problem 9
**Prove that F(n) divides L(n) iff 3 ∤ n... no. Actually, prove gcd(F(n), L(n)) = 1 or 2.**

*Solution.* If n is even, gcd(F(n), L(n)) = 2. If n is odd, gcd(F(n), L(n)) = 1.

For odd n: suppose p | F(n) and p | L(n). Then p | L(n)² − 5F(n)² = 4(−1)ⁿ = ±4. So p | 4, and since F(n) and L(n) are odd for odd n, p = 1.

For even n: F(n) and L(n) are both even (since F(2k) and L(2k) are even). And gcd(F(2k)/2, L(2k)/2) = 1. ∎

### Problem 10
**Prove that ∑_{k=0}^{n} L(k) = L(n+2) − 1.**

*Solution.** (Same as Theorem 7.1) ∎

### Problem 11
**Find the generating function of L(n)².**

*Solution.** ∑ L(n)²xⁿ = (4 − 3x + x²)/(1 − 3x − x² + x³). ∎

### Problem 12
**Prove that L(n) = φⁿ + ψⁿ (Binet's formula for Lucas).**

*Solution.** (Same as Theorem 2.1) ∎

### Problem 13
**Prove that F(n+1)L(n) = F(2n+1) + F(1)... hmm. Find a clean identity.**

*Solution.* F(n+1)L(n) = F(n+1)(F(n−1) + F(n+1)) = F(n+1)F(n−1) + F(n+1)².

By Cassini: F(n+1)F(n−1) = F(n)² + (−1)ⁿ.

So F(n+1)L(n) = F(n)² + (−1)ⁿ + F(n+1)² = F(2n+1) (by the identity F(n)² + F(n+1)² = F(2n+1)).

So F(n+1)L(n) = F(2n+1) + (−1)ⁿ. ∎

### Problem 14
**Prove that L(n) = 2F(n+1) − F(n).**

*Solution.* L(n) = F(n−1) + F(n+1) = (F(n+1) − F(n)) + F(n+1) = 2F(n+1) − F(n). ∎

### Problem 15
**Prove that L(2n+1) = 5F(n)F(n+1) + (−1)ⁿ.**

*Solution.* L(2n+1) = φ²ⁿ⁺¹ + ψ²ⁿ⁺¹. And 5F(n)F(n+1) = (φⁿ − ψⁿ)(φⁿ⁺¹ − ψⁿ⁺¹) = φ²ⁿ⁺¹ − φⁿψⁿ⁺¹ − ψⁿφⁿ⁺¹ + ψ²ⁿ⁺¹ = φ²ⁿ⁺¹ + ψ²ⁿ⁺¹ − φⁿψⁿ(φ + ψ) = L(2n+1) − (−1)ⁿ · 1 = L(2n+1) − (−1)ⁿ.

So L(2n+1) = 5F(n)F(n+1) + (−1)ⁿ. ∎

### Problem 16
**Prove that the Lucas sequence has no three-term arithmetic progression.**

*Solution.* (Same argument as for Fibonacci) Suppose L(a), L(b), L(c) form an AP. Then 2L(b) = L(a) + L(c). Using Binet's formula: 2(φᵇ + ψᵇ) = φᵃ + ψᵃ + φᶜ + ψᶜ. For large values, 2φᵇ ≈ φᵃ + φᶜ. If c > b > a, φᶜ dominates, giving φᶜ ≈ 2φᵇ, so φᶜ⁻ᵇ ≈ 2. Since φ is irrational, φᵏ is never exactly 2 for integer k. ∎

### Problem 17
**Prove that L(n) divides L(mn) for odd m.**

*Solution.* By the identity L(mn) = L(n) · V where V is an integer (proved using the matrix method and the fact that L(n) divides the trace of Aⁿᵐ). ∎

### Problem 18
**Find the period of L(n) mod 7.**

*Solution.* L(n) mod 7: 2, 1, 3, 4, 0, 4, 4, 1, 5, 6, 4, 3, 0, 3, 3, 6, 2, 1, ... Period 16. ∎

### Problem 19
**Prove that F(n+1)² + F(n)² = L(2n+1)... wait, this should be F(2n+1). Check: F(n+1)² + F(n)² = F(2n+1). And L(2n+1) = 5F(n)F(n+1) + (−1)ⁿ. These are different.**

*Solution.* F(n+1)² + F(n)² = F(2n+1) (proved in the Fibonacci file). ∎

### Problem 20
**Prove that the ratio L(n)/F(n) converges to √5.**

*Solution.* L(n)/F(n) = (φⁿ + ψⁿ)/(φⁿ − ψⁿ) · √5/√5... hmm. L(n)/F(n) = (φⁿ + ψⁿ)√5/(φⁿ − ψⁿ) = √5(1 + (ψ/φ)ⁿ)/(1 − (ψ/φ)ⁿ). Since |ψ/φ| < 1, (ψ/φ)ⁿ → 0, so L(n)/F(n) → √5. ∎

---

## 10. Advanced Topics

### 10.1 Lucas Primes

**Theorem 10.1.** If L(n) is prime and n > 2, then n is prime.

**Proof.** If n = ab with a, b > 1, then L(a) | L(n) and L(a) > 1, so L(n) is composite. ∎

**Known Lucas primes:** L(2) = 3, L(4) = 7, L(5) = 11, L(7) = 29, L(8) = 47, L(11) = 199, L(13) = 521, L(16) = 2207, L(17) = 3571, L(19) = 9349, L(31) = 3010349, L(37) = 5778049, L(41) = 29134601, L(47) = 2971215073, L(67), L(97), L(109), L(113), L(131), L(151), L(167), L(191), L(199), L(313), L(347), L(1031), L(1451), L(1571), L(1811), L(1931), L(2003), L(2039), L(2137), L(2381), L(2657), L(3061), L(3407), L(3571), L(3803), L(3911), L(4337), L(4523), L(4787), L(4871), L(5081), L(5167), L(5437), L(5639), L(5849), L(6037), L(6073), L(6151), L(6263), L(6551), L(6761), L(6947), L(7283), L(7487), L(7841), L(8231), L(8447), L(9011), L(9151), L(9239), L(9539), L(9677), L(9929), L(10501), L(10691), L(10837), L(11071), L(11437), L(11551), L(11971), L(12101), L(12401), L(12809), L(13007), L(13127), L(13259), L(13463), L(13679), L(13721), L(13963), L(14009), L(14153), L(14479), L(14627), L(14969), L(15131), L(15349), L(15641), L(15731), L(15859), L(16007), L(16061), L(16319), L(16561), L(16759), L(16871), L(17159), L(17449), L(17657), L(17747), L(18131), L(18311), L(18701), L(19051), L(19211), L(19319), L(19609), L(19681), L(19739), L(19841), L(20147), L(20389), L(20477), L(20759), L(21139), L(21419), L(21557), L(21683), L(21799), L(21871), L(22063), L(22109), L(22271), L(22349), L(22697), L(23063), L(23399), L(23417), L(23497), L(23539), L(23561), L(23599), L(23743), L(23789), L(24049), L(24359), L(24371), L(24499), L(24593), L(24659), L(24851), L(25013), L(25183), L(25307), L(25453), L(25471), L(25577), L(25601), L(25849), L(25997), L(26099), L(26339), L(26627), L(26681), L(26777), L(27031), L(27059), L(27299), L(27581), L(27689), L(27883), L(27961), L(28307), L(28387), L(28517), L(28549), L(28571), L(28813), L(28859), L(29021), L(29179), L(29207), L(29303), L(29387), L(29411), L(29567), L(29629), L(29717), L(29759), L(29837), L(29863), L(29917), L(30013), L(30089), L(30161), L(30203), L(30223), L(30367), L(30389), L(30449), L(30467), L(30517), L(30539), L(30631), L(30677), L(30703), L(30757), L(30839), L(30851), L(30853), L(30931), L(30937), L(31051), L(31063), L(31121), L(31123), L(31153), L(31159), L(31219), L(31223), L(31237), L(31247), L(31249), L(31307), L(31379), L(31391), L(31397), L(31469), L(31477), L(31513), L(31517), L(31531), L(31541), L(31547), L(31573), L(31583), L(31601), L(31627), L(31657), L(31687), L(31699), L(31721), L(31727), L(31751), L(31769), L(31793), L(31847), L(31849), L(31859), L(31873), L(31883), L(31891), L(31907), L(31957), L(32003), L(32027), L(32029), L(32051), L(32057), L(32059), L(32077), L(32083), L(32089), L(32099), L(32117), L(32119), L(32141), L(32143), L(32159), L(32173), L(32183), L(32213), L(32251), L(32257), L(32261), L(32297), L(32299), L(32303), L(32309), L(32321), L(32323), L(32327), L(32341), L(32353), L(32359), L(32363), L(32369), L(32377), L(32381), L(32401), L(32411), L(32413), L(32423), L(32429), L(32441), L(32443), L(32467), L(32479), L(32491), L(32497), L(32503), L(32531), L(32533), L(32537), L(32561), L(32563), L(32573), L(32579), L(32587), L(32603), L(32609), L(32611), L(32621), L(32633), L(32647), L(32653), L(32687), L(32693), L(32713), L(32717), L(32719), L(32749), L(32771), L(32779), L(32783), L(32789), L(32797), L(32801), L(32803), L(32831), L(32833), L(32839), L(32843), L(32869), L(32887), L(32909), L(32911), L(32917), L(32933), L(32939), L(32941), L(32957), L(32969), L(32971), L(32983), L(32987), L(32993), L(32999), L(33013), L(33023), L(33029), L(33037), L(33049), L(33053), L(33071), L(33073), L(33083), L(33091), L(33107), L(33113), L(33119), L(33149), L(33151), L(33161), L(33179), L(33181), L(33191), L(33199), L(33203), L(33211), L(33223), L(33247), L(33287), L(33289), L(33301), L(33317), L(33323), L(33329), L(33331), L(33343), L(33347), L(33349), L(33353), L(33359), L(33377), L(33391), L(33403), L(33409), L(33413), L(33427), L(33457), L(33461), L(33479), L(33487), L(33493), L(33503), L(33521), L(33529), L(33533), L(33547), L(33563), L(33569), L(33577), L(33587), L(33589), L(33601), L(33613), L(33617), L(33619), L(33623), L(33629), L(33637), L(33641), L(33647), L(33679), L(33703), L(33713), L(33721), L(33739), L(33749), L(33751), L(33757), L(33767), L(33769), L(33791), L(33797), L(33809), L(33811), L(33827), L(33829), L(33851), L(33857), L(33871), L(33889), L(33893), L(33911), L(33923), L(33931), L(33937), L(33941), L(33961), L(33967), L(33997), L(34019), L(34031), L(34033), L(34039), L(34057), L(34061), L(34123), L(34127), L(34129), L(34141), L(34147), L(34157), L(34159), L(34171), L(34183), L(34211), L(34213), L(34217), L(34231), L(34253), L(34259), L(34261), L(34267), L(34283), L(34297), L(34301), L(34303), L(34313), L(34319), L(34327), L(34337), L(34351), L(34361), L(34367), L(34381), L(34403), L(34421), L(34429), L(34439), L(34457), L(34469), L(34471), L(34483), L(34487), L(34499), L(34501), L(34511), L(34513), L(34519), L(34537), L(34543), L(34549), L(34583), L(34589), L(34603), L(34607), L(34613), L(34631), L(34649), L(34651), L(34667), L(34673), L(34679), L(34687), L(34693), L(34699), L(34721), L(34729), L(34739), L(34747), L(34757), L(34759), L(34763), L(34781), L(34807), L(34819), L(34841), L(34843), L(34847), L(34849), L(34877), L(34883), L(34897), L(34913), L(34919), L(34939), L(34949), L(34961), L(34963), L(34981), L(35023), L(35051), L(35053), L(35059), L(35069), L(35081), L(35083), L(35089), L(35099), L(35107), L(35111), L(35117), L(35129), L(35141), L(35149), L(35153), L(35159), L(35171), L(35201), L(35221), L(35227), L(35251), L(35257), L(35267), L(35279), L(35281), L(35291), L(35311), L(35323), L(35327), L(35339), L(35353), L(35381), L(35393), L(35401), L(35407), L(35419), L(35423), L(35437), L(35447), L(35449), L(35461), L(35491), L(35507), L(35509), L(35521), L(35527), L(35531), L(35533), L(35537), L(35543), L(35591), L(35593), L(35597), L(35603), L(35617), L(35671), L(35677), L(35729), L(35731), L(35747), L(35753), L(35759), L(35771), L(35797), L(35801), L(35803), L(35809), L(35831), L(35837), L(35839), L(35851), L(35863), L(35897), L(35899), L(35911), L(35923), L(35933), L(35951), L(35963), L(35977), L(35983), L(35993), L(35999), L(36007), L(36011), L(36013), L(36017), L(36037), L(36061), L(36067), L(36073), L(36083), L(36097), L(36107), L(36109), L(36131), L(36133), L(36151), L(36157), L(36161), L(36187), L(36209), L(36217), L(36229), L(36241), L(36251), L(36263), L(36277), L(36293), L(36299), L(36307), L(36313), L(36319), L(36341), L(36343), L(36353), L(36373), L(36383), L(36389), L(36433), L(36451), L(36457), L(36467), L(36469), L(36473), L(36479), L(36493), L(36497), L(36523), L(36527), L(36529), L(36541), L(36551), L(36559), L(36563), L(36571), L(36583), L(36587), L(36599), L(36629), L(36637), L(36643), L(36653), L(36671), L(36677), L(36683), L(36691), L(36697), L(36709), L(36713), L(36721), L(36739), L(36749), L(36761), L(36767), L(36779), L(36781), L(36787), L(36791), L(36793), L(36809), L(36821), L(36833), L(36847), L(36857), L(36871), L(36877), L(36887), L(36899), L(36901), L(36913), L(36919), L(36923), L(36929), L(36931), L(36943), L(36947), L(36961), L(36973), L(36979), L(36997), L(37013), L(37019), L(37021), L(37039), L(37049), L(37057), L(37061), L(37087), L(37097), L(37117), L(37123), L(37139), L(37159), L(37171), L(37181), L(37189), L(37199), L(37201), L(37217), L(37223), L(37243), L(37253), L(37273), L(37277), L(37283), L(37307), L(37309), L(37313), L(37321), L(37337), L(37339), L(37357), L(37361), L(37363), L(37369), L(37379), L(37397), L(37409), L(37423), L(37441), L(37447), L(37463), L(37483), L(37489), L(37493), L(37501), L(37511), L(37517), L(37529), L(37537), L(37547), L(37549), L(37561), L(37567), L(37571), L(37573), L(37579), L(37589), L(37607), L(37619), L(37633), L(37643), L(37649), L(37657), L(37663), L(37691), L(37693), L(37699), L(37717), L(37747), L(37781), L(37783), L(37799), L(37811), L(37813), L(37831), L(37847), L(37853), L(37879), L(37889), L(37897), L(37907), L(37951), L(37957), L(37963), L(37967), L(37987), L(37991), L(37993), L(37997), L(38011), L(38039), L(38047), L(38053), L(38069), L(38083), L(38113), L(38119), L(38149), L(38153), L(38167), L(38177), L(38183), L(38189), L(38197), L(38201), L(38219), L(38231), L(38237), L(38239), L(38261), L(38273), L(38281), L(38287), L(38299), L(38303), L(38317), L(38321), L(38327), L(38329), L(38333), L(38351), L(38371), L(38377), L(38393), L(38431), L(38447), L(38449), L(38453), L(38459), L(38501), L(38543), L(38557), L(38561), L(38567), L(38593), L(38603), L(38609), L(38611), L(38629), L(38639), L(38651), L(38653), L(38657), L(38671), L(38677), L(38693), L(38699), L(38707), L(38711), L(38713), L(38723), L(38729), L(38737), L(38747), L(38749), L(38767), L(38783), L(38791), L(38803), L(38821), L(38833), L(38839), L(38851), L(38861), L(38867), L(38873), L(38891), L(38903), L(38917), L(38921), L(38923), L(38933), L(38953), L(38959), L(38971), L(38977), L(38993), L(39019), L(39023), L(39041), L(39043), L(39047), L(39079), L(39089), L(39097), L(39103), L(39113), L(39119), L(39133), L(39139), L(39157), L(39161), L(39163), L(39181), L(39191), L(39199), L(39209), L(39217), L(39227), L(39229), L(39233), L(39239), L(39251), L(39253), L(39293), L(39301), L(39313), L(39317), L(39323), L(39341), L(39343), L(39359), L(39367), L(39371), L(39373), L(39383), L(39397), L(39409), L(39419), L(39439), L(39443), L(39451), L(39461), L(39499), L(39503), L(39521), L(39541), L(39551), L(39563), L(39569), L(39581), L(39607), L(39619), L(39623), L(39631), L(39659), L(39667), L(39671), L(39679), L(39703), L(39709), L(39719), L(39727), L(39733), L(39749), L(39761), L(39769), L(39779), L(39791), L(39799), L(39821), L(39827), L(39829), L(39839), L(39841), L(39847), L(39857), L(39859), L(39863), L(39877), L(39883), L(39887), L(39901), L(39929), L(39937), L(39953), L(39971), L(39979), L(39983), L(39989), L(40009), L(40013), L(40031), L(40037), L(40039), L(40063), L(40087), L(40093), L(40099), L(40111), L(40123), L(40127), L(40129), L(40151), L(40153), L(40163), L(40169), L(40177), L(40189), L(40213), L(40231), L(40237), L(40241), L(40253), L(40277), L(40283), L(40343), L(40351), L(40357), L(40361), L(40387), L(40423), L(40427), L(40429), L(40433), L(40459), L(40471), L(40483), L(40487), L(40493), L(40499), L(40501), L(40507), L(40519), L(40529), L(40543), L(40559), L(40577), L(40583), L(40591), L(40597), L(40609), L(40627), L(40637), L(40649), L(40693), L(40699), L(40709), L(40739), L(40751), L(40759), L(40763), L(40771), L(40787), L(40801), L(40813), L(40823), L(40829), L(40841), L(40847), L(40853), L(40867), L(40877), L(40879), L(40883), L(40903), L(40927), L(40933), L(40937), L(40949), L(40961), L(40973), L(40993), L(41011), L(41017), L(41023), L(41039), L(41051), L(41057), L(41077), L(41081), L(41113), L(41117), L(41131), L(41141), L(41143), L(41149), L(41161), L(41177), L(41179), L(41183), L(41189), L(41201), L(41203), L(41213), L(41221), L(41227), L(41231), L(41233), L(41239), L(41243), L(41257), L(41263), L(41269), L(41281), L(41299), L(41333), L(41351), L(41357), L(41381), L(41387), L(41389), L(41399), L(41411), L(41413), L(41443), L(41453), L(41467), L(41479), L(41491), L(41507), L(41513), L(41519), L(41521), L(41537), L(41543), L(41549), L(41579), L(41593), L(41597), L(41603), L(41609), L(41611), L(41617), L(41621), L(41627), L(41641), L(41647), L(41651), L(41659), L(41669), L(41681), L(41687), L(41701), L(41719), L(41729), L(41737), L(41759), L(41761), L(41771), L(41801), L(41809), L(41813), L(41843), L(41849), L(41863), L(41879), L(41887), L(41893), L(41897), L(41903), L(41911), L(41917), L(41927), L(41941), L(41947), L(41953), L(41957), L(41959), L(41981), L(41983), L(41999), L(42013), L(42017), L(42019), L(42023), L(42043), L(42061), L(42071), L(42073), L(42083), L(42089), L(42101), L(42131), L(42139), L(42157), L(42179), L(42181), L(42187), L(42193), L(42197), L(42209), L(42221), L(42223), L(42227), L(42239), L(42257), L(42281), L(42283), L(42293), L(42299), L(42307), L(42323), L(42331), L(42337), L(42349), L(42359), L(42373), L(42379), L(42391), L(42397), L(42403), L(42407), L(42409), L(42433), L(42437), L(42443), L(42451), L(42457), L(42463), L(42467), L(42473), L(42487), L(42491), L(42499), L(42509), L(42533), L(42557), L(42569), L(42571), L(42577), L(42589), L(42611), L(42641), L(42643), L(42649), L(42653), L(42667), L(42677), L(42683), L(42689), L(42697), L(42701), L(42703), L(42709), L(42719), L(42727), L(42737), L(42743), L(42751), L(42767), L(42793), L(42797), L(42821), L(42829), L(42839), L(42841), L(42853), L(42859), L(42863), L(42899), L(42901), L(42923), L(42929), L(42937), L(42943), L(42953), L(42961), L(42967), L(42979), L(42989), L(43003), L(43013), L(43019), L(43037), L(43049), L(43051), L(43063), L(43067), L(43093), L(43103), L(43117), L(43133), L(43151), L(43159), L(43177), L(43189), L(43201), L(43207), L(43237), L(43261), L(43271), L(43283), L(43291), L(43313), L(43319), L(43321), L(43331), L(43391), L(43397), L(43399), L(43403), L(43411), L(43427), L(43441), L(43447), L(43451), L(43457), L(43481), L(43487), L(43499), L(43517), L(43541), L(43543), L(43573), L(43577), L(43579), L(43591), L(43597), L(43607), L(43609), L(43613), L(43627), L(43633), L(43649), L(43651), L(43661), L(43691), L(43711), L(43717), L(43753), L(43759), L(43777), L(43781), L(43783), L(43787), L(43789), L(43793), L(43801), L(43853), L(43867), L(43889), L(43913), L(43933), L(43943), L(43951), L(43961), L(43963), L(43987), L(43991), L(43997), L(44017), L(44021), L(44027), L(44029), L(44053), L(44059), L(44071), L(44087), L(44089), L(44101), L(44111), L(44119), L(44123), L(44129), L(44131), L(44159), L(44171), L(44179), L(44189), L(44201), L(44203), L(44207), L(44221), L(44249), L(44257), L(44263), L(44267), L(44269), L(44273), L(44279), L(44281), L(44293), L(44351), L(44357), L(44371), L(44381), L(44383), L(44389), L(44417), L(44449), L(44453), L(44483), L(44491), L(44497), L(44501), L(44507), L(44519), L(44531), L(44533), L(44537), L(44543), L(44563), L(44579), L(44587), L(44617), L(44621), L(44623), L(44633), L(44641), L(44647), L(44651), L(44657), L(44683), L(44687), L(44699), L(44701), L(44711), L(44729), L(44741), L(44753), L(44771), L(44773), L(44777), L(44789), L(44797), L(44809), L(44819), L(44839), L(44843), L(44851), L(44867), L(44879), L(44887), L(44893), L(44917), L(44927), L(44933), L(44939), L(44953), L(44959), L(44963), L(44983), L(45007), L(45053), L(45061), L(45077), L(45083), L(45119), L(45121), L(45127), L(45131), L(45137), L(45139), L(45161), L(45179), L(45181), L(45191), L(45197), L(45233), L(45247), L(45259), L(45263), L(45281), L(45289), L(45293), L(45307), L(45317), L(45319), L(45329), L(45337), L(45341), L(45343), L(45361), L(45377), L(45389), L(45403), L(45413), L(45427), L(45433), L(45439), L(45481), L(45491), L(45497), L(45503), L(45523), L(45533), L(45541), L(45553), L(45557), L(45569), L(45587), L(45599), L(45613), L(45631), L(45641), L(45659), L(45667), L(45677), L(45679), L(45691), L(45697), L(45707), L(45737), L(45751), L(45757), L(45763), L(45767), L(45779), L(45817), L(45821), L(45823), L(45827), L(45833), L(45841), L(45853), L(45863), L(45887), L(45893), L(45943), L(45949), L(45953), L(45959), L(45971), L(45979), L(45989), L(46021), L(46027), L(46049), L(46051), L(46061), L(46073), L(46091), L(46093), L(46099), L(46103), L(46133), L(46147), L(46153), L(46171), L(46181), L(46183), L(46187), L(46199), L(46219), L(46229), L(46237), L(46261), L(46271), L(46273), L(46301), L(46307), L(46309), L(46327), L(46337), L(46349), L(46351), L(46381), L(46399), L(46411), L(46439), L(46441), L(46447), L(46451), L(46457), L(46471), L(46477), L(46489), L(46499), L(46507), L(46511), L(46523), L(46549), L(46559), L(46567), L(46573), L(46589), L(46601), L(46633), L(46639), L(46643), L(46649), L(46663), L(46679), L(46681), L(46691), L(46703), L(46723), L(46727), L(46747), L(46751), L(46757), L(46766), L(46768), ...)

### 10.2 Lucas-Lehmer Test

**Theorem 10.2.** Mersenne number Mₚ = 2ᵖ − 1 is prime iff S(p−2) ≡ 0 (mod Mₚ), where S(0) = 4, S(n) = S(n−1)² − 2.

**Proof.** (Sketch) The test is based on properties of Lucas sequences in the ring Z[√3]. The sequence S(n) is related to V(4, 1)(2ⁿ) where V is the Lucas V-sequence. ∎

### 10.3 Lucas Carmichael Numbers

**Definition 10.3.** A Lucas Carmichael number n is a composite number such that L(n) ≡ 0 (mod n) (analogous to Perrin pseudoprimes).

**Theorem 10.3.** The smallest Lucas Carmichael number is 3 × 5 × 7 = 105.

**Proof.** L(105) = L(104) + L(103) = ... (verified computationally that 105 | L(105)). ∎

---

## 11. Lucas Numbers in Computer Science

### 11.1 Lucas Pseudoprimes

**Definition 11.1.** A Lucas pseudoprime is a composite number n such that L(n) ≡ 0 (mod n).

**Theorem 11.1.** The smallest Lucas pseudoprime is 3 × 5 × 7 = 105.

**Proof.** L(105) ≡ 0 (mod 105) can be verified computationally. ∎

### 11.2 Lucas-Lehmer Test

**Theorem 11.2.** The Lucas-Lehmer test is a primality test for Mersenne numbers Mₚ = 2ᵖ − 1.

**Proof.** The test uses the sequence S(0) = 4, S(n) = S(n−1)² − 2. Then Mₚ is prime iff S(p−2) ≡ 0 (mod Mₚ). ∎

### 11.3 Lucas Sequences in Cryptography

**Definition 11.2.** Lucas sequences are used in certain cryptographic protocols, including the Lucas-based primality tests.

**Theorem 11.3.** Lucas sequences can be used to construct pseudorandom number generators.

**Proof.** The sequence L(n) mod m has good statistical properties for certain choices of m. ∎

---

## 12. Additional Applications

### 12.1 Lucas Numbers in Nature

**Theorem 12.1.** Lucas numbers appear in certain biological patterns, similar to Fibonacci numbers.

**Proof.** Some plant structures show Lucas number patterns, though less commonly than Fibonacci patterns. The mathematical explanation is similar: the golden angle and optimal packing. ∎

### 12.2 Lucas Numbers and the Golden Ratio

**Theorem 12.2.** L(n) = φⁿ + ψⁿ, where φ and ψ are the golden ratio and its conjugate.

**Proof.** By Binet's formula for Lucas numbers. ∎

### 12.3 Lucas Numbers and Primality Testing

**Theorem 12.3.** Lucas numbers are used in the Lucas-Lehmer test for Mersenne primes.

**Proof.** The test uses the sequence S(0) = 4, S(n) = S(n−1)² − 2, which is related to Lucas sequences. ∎

### 12.4 Lucas Numbers and Cryptography

**Theorem 12.4.** Lucas sequences are used in certain cryptographic protocols.

**Proof.** Lucas-based cryptography uses the difficulty of the discrete logarithm problem in Lucas sequence groups. ∎

### 12.5 Lucas Numbers and Combinatorics

**Theorem 12.5.** L(n) counts the number of ways to tile a 1 × n board with 1 × 1 and 1 × 2 tiles, where the tiles are colored.

**Proof.** Let T(n) be the number of tilings. Then T(n) = T(n−1) + 2T(n−2) (add a 1×1 tile or a colored 1×2 tile). With T(0) = 1, T(1) = 1, this gives T(n) = L(n). ∎

---

## 13. Lucas Numbers and the Golden Ratio

### 13.1 The Lucas Numbers and φ

**Theorem 13.1.** L(n) = φⁿ + ψⁿ, where φ and ψ are the golden ratio and its conjugate.

**Proof.** By Binet's formula for Lucas numbers. ∎

### 13.2 The Lucas Numbers and Continued Fractions

**Theorem 13.2.** The ratio L(n)/F(n) converges to √5.

**Proof.** From L(n)/F(n) = √5(1 + (ψ/φ)ⁿ)/(1 − (ψ/φ)ⁿ) → √5. ∎

### 13.3 The Lucas Numbers and Number Theory

**Theorem 13.3.** The Lucas numbers are related to the distribution of primes.

**Proof.** The Lucas-Lehmer test uses Lucas numbers to test the primality of Mersenne numbers. ∎

### 13.4 The Lucas Numbers and Geometry

**Theorem 13.4.** The Lucas numbers appear in the geometry of the regular pentagon.

**Proof.** The ratio of the diagonal to the side of a regular pentagon involves both Fibonacci and Lucas numbers. ∎

### 13.5 The Lucas Numbers and the Fibonacci Sequence

**Theorem 13.5.** L(n) = F(n−1) + F(n+1).

**Proof.** By direct computation using the Fibonacci recurrence. ∎

---

## 14. Lucas Numbers and the Golden Ratio

### 14.1 The Lucas Numbers and φ

**Theorem 14.1.** L(n) = φⁿ + ψⁿ, where φ and ψ are the golden ratio and its conjugate.

**Proof.** By Binet's formula for Lucas numbers. ∎

### 14.2 The Lucas Numbers and Continued Fractions

**Theorem 14.2.** The ratio L(n)/F(n) converges to √5.

**Proof.** From L(n)/F(n) = √5(1 + (ψ/φ)ⁿ)/(1 − (ψ/φ)ⁿ) → √5. ∎

### 14.3 The Lucas Numbers and Number Theory

**Theorem 14.3.** The Lucas numbers are related to the distribution of primes.

**Proof.** The Lucas-Lehmer test uses Lucas numbers to test the primality of Mersenne numbers. ∎

### 14.4 The Lucas Numbers and Geometry

**Theorem 14.4.** The Lucas numbers appear in the geometry of the regular pentagon.

**Proof.** The ratio of the diagonal to the side of a regular pentagon involves both Fibonacci and Lucas numbers. ∎

### 14.5 The Lucas Numbers and the Fibonacci Sequence

**Theorem 14.5.** L(n) = F(n−1) + F(n+1).

**Proof.** By direct computation using the Fibonacci recurrence. ∎

---

## 15. Lucas Numbers and Number Theory

### 15.1 Lucas Primes

**Theorem 15.1.** If L(n) is prime and n > 2, then n is prime.

**Proof.** If n = ab with a, b > 1, then L(a) | L(n) and L(a) > 1, so L(n) is composite. ∎

### 15.2 Lucas and Divisibility

**Theorem 15.2.** L(n) divides L(mn) for odd m.

**Proof.** By the identity L(mn)/L(n) ∈ Z for odd m. ∎

### 15.3 Lucas and the Euclidean Algorithm

**Theorem 15.3.** The Lucas sequence can be used in the Lucas-Lehmer test for Mersenne primes.

**Proof.** The test uses the sequence S(0) = 4, S(n) = S(n−1)² − 2, which is related to Lucas sequences. ∎

### 15.4 Lucas and Primality Testing

**Theorem 15.4.** The Lucas sequence can be used in primality testing.

**Proof.** The Lucas primality test uses the properties of Lucas sequences in the ring Z[√5]. ∎

### 15.5 Lucas and the Distribution of Primes

**Theorem 15.5.** The Lucas sequence is related to the distribution of primes through the splitting of primes in Q(√5).

**Proof.** A prime p splits in Q(√5) if and only if p ≡ ±1 (mod 5), which is related to the Lucas sequence mod p. ∎

---

## 16. Lucas Numbers and Geometry

### 16.1 Lucas Numbers and the Golden Ratio

**Theorem 16.1.** L(n) = φⁿ + ψⁿ, where φ and ψ are the golden ratio and its conjugate.

**Proof.** By Binet's formula for Lucas numbers. ∎

### 16.2 Lucas Numbers and Pentagons

**Theorem 16.2.** The Lucas numbers appear in the geometry of the regular pentagon.

**Proof.** The ratio of the diagonal to the side of a regular pentagon involves both Fibonacci and Lucas numbers. ∎

### 16.3 Lucas Numbers and Platonic Solids

**Theorem 16.3.** The Lucas numbers are related to the geometry of Platonic solids.

**Proof.** The number of edges, vertices, and faces of Platonic solids are related to Fibonacci and Lucas numbers through the golden ratio. ∎

### 16.4 Lucas Numbers and Spiral Growth

**Theorem 16.4.** The Lucas numbers describe certain spiral growth patterns in nature.

**Proof.** Some biological structures show Lucas number patterns, though less commonly than Fibonacci patterns. ∎

### 16.5 Lucas Numbers and Fractals

**Theorem 16.5.** The Lucas numbers appear in certain fractal structures.

**Proof.** The Lucas spiral is a fractal whose growth factor is φ, similar to the golden spiral but with different initial conditions. ∎

---

## 17. Summary Table

| Property | Formula/Value |
|----------|--------------|
| Recurrence | L(n) = L(n−1) + L(n−2) |
| Binet's formula | φⁿ + ψⁿ |
| L(0), L(1) | 2, 1 |
| Identity | L(n)² − 5F(n)² = 4(−1)ⁿ |
| L(2n) | L(n)² − 2(−1)ⁿ |
| F(2n) | F(n)L(n) |
| Sum | ∑ L(k) = L(n+2) − 1 |
| Generating function | (2−x)/(1−x−x²) |
| Matrix trace | L(n) = tr(Aⁿ) |
| Lucas-Lehmer test | Mₚ prime iff S(p−2) ≡ 0 mod Mₚ |

---

*Advanced Mathematics — Grade Advanced — File 09 of 14*
