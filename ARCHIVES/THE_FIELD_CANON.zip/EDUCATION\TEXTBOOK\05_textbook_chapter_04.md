# Chapter 4: Harmonic Mathematics

## The Mathematics of Music, Vibration, and Resonance

---

### Overview

Harmonic mathematics is the study of ratios, frequencies, and vibrations. It is one of the oldest branches of mathematics, dating back to Pythagoras, who discovered that musical intervals correspond to simple ratios of string lengths.

The harmonic series — 1, 1/2, 1/3, 1/4, 1/5, ... — is the foundation of both music and number theory. It connects the physics of sound to the abstract properties of numbers, and it appears in contexts ranging from the design of musical instruments to the distribution of prime numbers.

In this chapter, we will study the harmonic series, its relationship to music, and its applications in physics and engineering.

---

## Lesson 4.1: The Harmonic Series

### Explanation

The **harmonic series** is the infinite sum:

H = 1 + 1/2 + 1/3 + 1/4 + 1/5 + 1/6 + ...

This series is one of the most important in all of mathematics. It was studied by the ancient Greeks, who discovered that it has a surprising property: even though each term gets smaller and smaller, the sum grows without bound.

In other words, the harmonic series **diverges**.

This is not obvious. After all, the terms approach zero, so you might expect the sum to converge to some finite value. But it does not. The sum grows slowly — very slowly — but it grows forever.

The proof of divergence is attributed to Nicole Oresme (c. 1350):

H = 1 + 1/2 + 1/3 + 1/4 + 1/5 + 1/6 + 1/7 + 1/8 + ...

Group the terms:

H = 1 + 1/2 + (1/3 + 1/4) + (1/5 + 1/6 + 1/7 + 1/8) + ...

Each group has a sum greater than 1/2:

1/3 + 1/4 > 1/4 + 1/4 = 1/2
1/5 + 1/6 + 1/7 + 1/8 > 1/8 + 1/8 + 1/8 + 1/8 = 1/2

So H > 1 + 1/2 + 1/2 + 1/2 + ... = ∞.

**Key Concept**: The harmonic series diverges, even though its terms approach zero.

### The nth Harmonic Number

The **nth harmonic number** is the partial sum of the harmonic series up to the nth term:

H(n) = 1 + 1/2 + 1/3 + ... + 1/n

The first few harmonic numbers are:

| n | H(n) |
|---|------|
| 1 | 1.000000 |
| 2 | 1.500000 |
| 3 | 1.833333 |
| 4 | 2.083333 |
| 5 | 2.283333 |
| 10 | 2.928968 |
| 100 | 5.187377 |
| 1000 | 7.485470 |
| 10000 | 9.787606 |
| 100000 | 12.090146 |

The harmonic numbers grow very slowly. H(1000) ≈ 7.49, and H(1000000) ≈ 14.39.

There is an approximation formula:

H(n) ≈ ln(n) + γ

where ln(n) is the natural logarithm of n and γ ≈ 0.5772156649 is the **Euler-Mascheroni constant**.

### Worked Example 4.1.1

Compute H(10) and compare it to ln(10) + γ.

**Solution**: H(10) = 1 + 1/2 + 1/3 + ... + 1/10

= 1 + 0.5 + 0.333333 + 0.25 + 0.2 + 0.166667 + 0.142857 + 0.125 + 0.111111 + 0.1

= 2.928968

ln(10) + γ = 2.302585 + 0.577216 = 2.879801

The approximation is close (error ≈ 0.049).

### Worked Example 4.1.2

For what value of n is H(n) first greater than 5?

**Solution**: We need H(n) > 5. Since H(n) ≈ ln(n) + γ, we need:

ln(n) + 0.577216 > 5
ln(n) > 4.422784
n > e^4.422784 ≈ 83.3

So H(83) ≈ 4.99 and H(84) ≈ 5.002. Let us verify: H(84) is the first harmonic number greater than 5.

Actually, let me compute more carefully. H(82) ≈ 4.989, H(83) ≈ 4.997, H(84) ≈ 5.005. So H(84) is the first harmonic number greater than 5.

### Practice Problems

1. Compute H(5) by hand.
2. Compute H(20) using the approximation H(n) ≈ ln(n) + γ.
3. For what value of n is H(n) first greater than 3?
4. For what value of n is H(n) first greater than 10?
5. Prove that H(2ⁿ) ≥ 1 + n/2 for all n ≥ 0. (Hint: use the grouping argument.)

### Teacher's Notes

**Surprise Factor**: The divergence of the harmonic series is one of the most counterintuitive facts in mathematics. Emphasize this surprise. Students expect the series to converge because the terms get so small so fast.

**Historical Note**: The harmonic series was one of the first infinite series to be studied. The proof of its divergence by Oresme (c. 1350) is one of the earliest results in the theory of infinite series.

**Physical Connection**: The harmonic series appears in the physics of vibrating strings. A vibrating string produces overtones at frequencies that are integer multiples of the fundamental frequency. The amplitudes of these overtones decrease roughly as 1/n, following the harmonic series.

---

## Lesson 4.2: Musical Intervals and Ratios

### Explanation

Music is mathematics made audible. The relationship between musical notes is determined by ratios of frequencies.

**Frequency** is the number of vibrations per second, measured in Hertz (Hz). When you pluck a string, it vibrates at a certain frequency. A higher frequency means a higher pitch.

The fundamental relationship between two notes is their **interval**, which is the ratio of their frequencies.

| Interval | Ratio | Example |
|----------|-------|---------|
| Unison | 1:1 | C to C |
| Octave | 2:1 | C to C (one octave higher) |
| Perfect fifth | 3:2 | C to G |
| Perfect fourth | 4:3 | C to F |
| Major third | 5:4 | C to E |
| Minor third | 6:5 | C to E♭ |
| Major second | 9:8 | C to D |
| Minor second | 16:15 | C to D♭ |

**Key Concept**: Musical intervals are ratios of frequencies. The simplest ratios produce the most consonant (pleasant-sounding) intervals.

### The Octave

The most fundamental interval in music is the **octave**: the ratio 2:1. When you double the frequency of a note, you get the same note one octave higher. A middle C has frequency approximately 261.6 Hz. The C one octave higher has frequency 523.3 Hz = 2 × 261.6 Hz.

This ratio is so fundamental that every musical system in the world uses it. An octave always sounds like "the same note, but higher."

### The Perfect Fifth

The next most consonant interval is the **perfect fifth**, with ratio 3:2. If middle C has frequency 261.6 Hz, then G (a perfect fifth above C) has frequency 261.6 × 3/2 = 392.4 Hz.

The perfect fifth is the basis of most musical tuning systems. When you tune a guitar, you typically tune the strings in fifths (or fourths, which are the inversion of fifths).

### The Pythagorean Scale

Pythagoras discovered that all musical intervals can be generated from the perfect fifth. Starting from C, you can generate all twelve notes of the chromatic scale by stacking perfect fifths:

C → G → D → A → E → B → F♯ → C♯ → G♯ → D♯ → A♯ → F → C

The ratios are:

C: 1
G: 3/2
D: 9/8
A: 27/16
E: 81/64
...

This is the **Pythagorean scale**, and it was the standard tuning system in Western music for over a thousand years.

**Key Concept**: The Pythagorean scale is generated by stacking perfect fifths (ratio 3:2).

### The Problem of Pythagorean Comma

There is a problem with the Pythagorean scale. After stacking twelve perfect fifths, you should arrive back at the same note (seven octaves higher). But the ratios do not quite work out:

(3/2)¹² = 531441/4096 ≈ 129.746

2⁷ = 128

The ratio 531441/4096 divided by 128 is:

531441 / (4096 × 128) = 531441 / 524288 ≈ 1.01364

This discrepancy is called the **Pythagorean comma**. It means that the Pythagorean scale cannot perfectly close — after going around the circle of fifths, you end up slightly sharp.

### Worked Example 4.2.1

A guitar string has a fundamental frequency of 82.4 Hz (the low E string). What is the frequency of the note one octave higher?

**Solution**: One octave higher means a ratio of 2:1. So the frequency is 82.4 × 2 = 164.8 Hz.

### Worked Example 4.2.2

A piano has 88 keys. The lowest key has frequency 27.5 Hz. What is the frequency of the highest key?

**Solution**: The 88 keys span 7 octaves plus a minor third. The total ratio is:

2⁷ × 6/5 = 128 × 1.2 = 153.6

So the highest key has frequency 27.5 × 153.6 = 4224 Hz.

(Actually, the highest key on a standard piano is C8, which has frequency 4186 Hz. The discrepancy is because the ratio 6/5 for the minor third is an approximation.)

### Practice Problems

1. A tuning fork vibrates at 440 Hz (the standard A note). What is the frequency of the note a perfect fifth above A?
2. What is the frequency of the note a perfect fourth above A (440 Hz)?
3. How many perfect fifths does it take to span approximately 4 octaves?
4. Compute the Pythagorean comma: (3/2)¹² / 2⁷.
5. Explain why the Pythagorean comma is a problem for musical tuning.

### Teacher's Notes

**Demonstration**: If you have access to a piano or guitar, demonstrate the intervals. Play a note, then play it an octave higher. Then play a perfect fifth. Then play a major third. Let students hear the relationship between the ratio and the sound.

**Cross-Curricular Connection**: This lesson connects music, physics, and mathematics. It is one of the best examples of how mathematics underlies the arts.

**Historical Note**: Pythagoras believed that the universe was governed by mathematical ratios, and that music was the clearest expression of this cosmic harmony. He called this the "music of the spheres."

---

## Lesson 4.3: The Harmonic Series in Music

### Explanation

The harmonic series appears in music in two ways:

**1. Overtones**

When a musical instrument produces a note, it does not produce a single frequency. It produces a **fundamental frequency** plus a series of **overtones** (also called harmonics) at integer multiples of the fundamental.

For example, if a guitar string vibrates at 100 Hz, it also produces overtones at 200 Hz, 300 Hz, 400 Hz, 500 Hz, and so on.

The amplitudes of these overtones typically decrease as 1/n, following the harmonic series. This is why a guitar sounds different from a flute — they produce different overtone spectra, even when playing the same note.

**2. String Lengths**

The length of a vibrating string is inversely proportional to its frequency. If a string of length L produces the fundamental frequency f, then:

- A string of length L/2 produces the octave (frequency 2f)
- A string of length L/3 produces the second octave (frequency 3f)
- A string of length L/4 produces the third octave (frequency 4f)

This means the lengths of strings that produce the overtone series are L, L/2, L/3, L/4, L/5, ... — the harmonic series!

**Key Concept**: The overtone series of a vibrating string follows the harmonic series: f, 2f, 3f, 4f, ...

### The Harmonic Series on a Guitar

On a guitar, you can produce overtones by lightly touching a string at a nodal point and plucking it. This suppresses the fundamental and emphasizes the overtones.

The most common overtone positions are:

| Overtone | Ratio to fundamental | Touch point | Fraction of string length |
|----------|---------------------|-------------|--------------------------|
| 1st (octave) | 2:1 | 12th fret | 1/2 |
| 2nd (octave + fifth) | 3:1 | 7th fret | 1/3 |
| 3rd (2 octaves) | 4:1 | 5th fret | 1/4 |
| 4th (2 octaves + third) | 5:1 | 4th fret | 1/5 |
| 5th (2 octaves + fifth) | 6:1 | — | 1/6 |

The 12th fret is at the midpoint of the string (1/2 the length). The 7th fret is at 1/3 the length. The 5th fret is at 1/4 the length.

### Worked Example 4.3.1

A guitar string has length 64 cm and fundamental frequency 82.4 Hz (low E). At what point should you touch the string to produce the 3rd overtone (frequency 4 × 82.4 = 329.6 Hz)?

**Solution**: The 3rd overtone has frequency 4f, so the string length should be L/4 = 64/4 = 16 cm from the bridge.

On a standard guitar, this corresponds to approximately the 5th fret.

### Worked Example 4.3.2

A pipe organ has a pipe of length 2 meters that produces the fundamental frequency 43.65 Hz (the lowest C on the piano). What is the frequency produced by a pipe that is 1 meter long?

**Solution**: The frequency is inversely proportional to the length. So a pipe of length 1 meter (half the length) produces a frequency of 2 × 43.65 = 87.3 Hz, which is one octave higher.

### Practice Problems

1. A guitar string has length 65 cm. Where is the nodal point for the 2nd overtone (frequency 3f)?
2. A pipe of length 3 meters produces a fundamental frequency of 57.2 Hz. What frequency does a pipe of length 1 meter produce?
3. Explain why the harmonics of a vibrating string follow the harmonic series.
4. A violin string is tuned to 440 Hz (A4). What are the frequencies of the first five overtones?
5. Why do different instruments sound different even when playing the same note?

### Teacher's Notes

**Demonstration**: If you have access to a guitar, demonstrate overtone production. Touch the string at the 12th fret (halfway) and pluck it — you hear the octave. Touch at the 7th fret (one-third) — you hear the second overtone. This is a powerful demonstration of the harmonic series in action.

**Physics Connection**: The harmonic series in music is a direct consequence of the physics of standing waves on a string or in a pipe. A standing wave on a string has nodes at both ends, and the possible wavelengths are L, L/2, L/3, L/4, ... This is the harmonic series.

---

## Lesson 4.4: Pythagorean Tuning and Equal Temperament

### Explanation

Musicians need to be able to play in different keys. This requires a tuning system in which all intervals are consistent. There are two main approaches: Pythagorean tuning and equal temperament.

### Pythagorean Tuning

As we saw in Lesson 4.2, the Pythagorean scale is generated by stacking perfect fifths (ratio 3:2). This produces a scale with pure, consonant fifths but problematic thirds.

The problem is the Pythagorean comma: twelve perfect fifths do not exactly equal seven octaves. This means that music tuned in Pythagorean tuning sounds different in different keys. Keys with many sharps or flats sound increasingly out of tune.

### Equal Temperament

**Equal temperament** solves this problem by dividing the octave into 12 equal semitones. Each semitone has a frequency ratio of:

2^(1/12) ≈ 1.059463094

This means that every interval is slightly out of tune compared to the pure ratio, but the discrepancy is the same in every key. Music sounds equally (imperfectly) good in all keys.

The twelve notes of the equal-tempered chromatic scale have frequencies:

| Note | Ratio from C | Frequency (C4 = 261.63 Hz) |
|------|-------------|---------------------------|
| C | 1 | 261.63 |
| C♯/D♭ | 2^(1/12) | 277.18 |
| D | 2^(2/12) | 293.66 |
| D♯/E♭ | 2^(3/12) | 311.13 |
| E | 2^(4/12) | 329.63 |
| F | 2^(5/12) | 349.23 |
| F♯/G♭ | 2^(6/12) | 369.99 |
| G | 2^(7/12) | 392.00 |
| G♯/A♭ | 2^(8/12) | 415.30 |
| A | 2^(9/12) | 440.00 |
| A♯/B♭ | 2^(10/12) | 466.16 |
| B | 2^(11/12) | 493.88 |
| C (octave) | 2 | 523.25 |

**Key Concept**: Equal temperament divides the octave into 12 equal semitones, each with ratio 2^(1/12).

### Comparison of Tuning Systems

| Interval | Pure ratio | Equal temperament | Difference |
|----------|-----------|-------------------|------------|
| Octave | 2.0000 | 2.0000 | 0.00% |
| Perfect fifth | 1.5000 | 1.4983 | -0.11% |
| Perfect fourth | 1.3333 | 1.3348 | +0.11% |
| Major third | 1.2500 | 1.2599 | +0.79% |
| Minor third | 1.2000 | 1.1892 | -0.90% |

The equal-tempered perfect fifth is very close to the pure ratio (only 0.11% flat). The major third is further off (0.79% sharp). This is why major thirds in equal temperament sound slightly less consonant than pure major thirds.

### Worked Example 4.4.1

What is the frequency of the note E4 in equal temperament, given that A4 = 440 Hz?

**Solution**: E4 is 4 semitones above A4 (going down: A, G♯, G, F♯, F, E — wait, that is 5 semitones down. Let me recalculate.

Actually, E4 is 3 semitones below A4. A4 = 440 Hz. The note a major third below A is F♯... no, let me think about this differently.

E4 is the E above middle C. A4 is the A above middle C. The interval from E4 to A4 is a perfect fourth, which is 5 semitones.

So E4 = A4 / 2^(5/12) = 440 / 1.4983 = 293.66 Hz.

Wait, that is D4. Let me recount.

From E4 to A4: E → F (1 semitone) → F♯ (2) → G (3) → G♯ (4) → A (5). So 5 semitones.

E4 = 440 / 2^(5/12) = 440 / 1.4983 ≈ 293.66 Hz.

But that should be D4, not E4. Let me check: D4 is 293.66 Hz, and E4 is 329.63 Hz. So E4 = 440 / 2^(3/12) = 440 / 1.2599 ≈ 349.23 Hz.

Hmm, that is F4. I am confusing myself. Let me just use the standard formula.

The frequency of the note n semitones above A4 is:
f = 440 × 2^(n/12)

E4 is 3 semitones below A4 (A, G♯, G, F♯, E — that is 5 semitones below, not 3).

Actually: from E4 up to A4: E, F, F♯, G, G♯, A = 5 semitones.

So E4 = 440 × 2^(-5/12) = 440 / 1.4983 ≈ 293.66 Hz.

But D4 is supposed to be 293.66 Hz and E4 is 329.63 Hz. So I am making an error.

Let me just look up the standard frequencies:
- C4 = 261.63 Hz
- D4 = 293.66 Hz
- E4 = 329.63 Hz
- F4 = 349.23 Hz
- G4 = 392.00 Hz
- A4 = 440.00 Hz
- B4 = 493.88 Hz

From E4 to A4: E4 is at 329.63, A4 is at 440.00. The ratio is 440/329.63 = 1.3348 ≈ 2^(5/12).

So E4 = 440 / 2^(5/12) = 440 / 1.3348... wait, 2^(5/12) = 1.3348, and 440/1.3348 = 329.63. Yes, that is correct!

So E4 = 440 / 2^(5/12) ≈ 329.63 Hz.

Wait, but 440/1.3348 = 329.63. Let me verify: 329.63 × 1.3348 = 440.00. Yes!

So E4 is 5 semitones below A4, and its frequency is 440 / 2^(5/12) ≈ 329.63 Hz.

### Practice Problems

1. What is the frequency of G4 in equal temperament, given A4 = 440 Hz?
2. What is the frequency of C5 in equal temperament?
3. How many semitones are there in an octave? Verify that 2^(12/12) = 2.
4. Compare the equal-tempered perfect fifth (2^(7/12)) to the pure perfect fifth (3/2). What is the percentage difference?
5. Explain why equal temperament replaced Pythagorean tuning in Western music.

### Teacher's Notes

**Demonstration**: If you have access to a piano, play a pure major third (5:4) and then an equal-tempered major third (2^(4/12)). Ask students which one sounds more "in tune." (The pure ratio sounds more consonant, but the equal-tempered version is close enough for most purposes.)

**Technology Connection**: Many modern keyboards and synthesizers use equal temperament. Explain that this is a practical compromise that allows musicians to play in any key without retuning.

---

## Lesson 4.5: Harmonic Proportions in Architecture

### Explanation

The same ratios that govern music also govern architecture. The ancient Greeks believed that buildings should be designed using the same harmonic ratios that make music pleasant. This idea — that beauty is governed by mathematical proportion — has influenced architecture for thousands of years.

### The Harmonic Ratios in Classical Architecture

The Parthenon in Athens (built 447-432 BC) uses the following ratios:

- The width-to-height ratio of the facade is approximately 4:3 (a perfect fourth).
- The spacing of the columns follows the ratio 9:8 (a major second).
- The overall proportions of the building approximate the golden ratio.

### Musical Proportions in Gothic Architecture

Gothic cathedrals used harmonic ratios in their design:

- The height of the nave is often a simple ratio of the width (e.g., 3:1 or 7:3).
- The spacing of the arches follows harmonic ratios.
- The proportions of the rose windows approximate musical intervals.

### Le Corbusier and the Modulor

In the 20th century, the architect Le Corbusier developed a system of proportions called the **Modulor**, which combined the golden ratio with human body proportions. The Modulor was based on:

1. The height of a man with arm raised (2.26 m)
2. The golden ratio dividing this height
3. The resulting proportions applied to building design

The Modulor was used in several buildings, including the Unité d'Habitation in Marseille.

### Worked Example 4.5.1

A room has width 4 m and height 3 m. What musical interval does this ratio correspond to?

**Solution**: The ratio 4:3 is the perfect fourth. This means the room has the proportions of a perfect fourth — one of the most consonant musical intervals.

### Worked Example 4.5.2

A window has width 5 m and height 3 m. What musical interval does this ratio correspond to?

**Solution**: The ratio 5:3 is a major sixth. This is a pleasant, consonant interval.

### Practice Problems

1. A room has width 6 m and height 4 m. What musical interval does this ratio correspond to?
2. A building facade has width 10 m and height 7 m. Is this close to any simple ratio?
3. Research the Modulor system of Le Corbusier. How does it use the golden ratio?
4. Measure the dimensions of your classroom. What musical ratios do the dimensions approximate?
5. Why might architects use musical ratios in building design?

### Teacher's Notes

**Cross-Curricular Connection**: This lesson connects music, architecture, and mathematics. It shows that the same mathematical principles govern both sound and space.

**Project Idea**: Have students measure the dimensions of several rooms in their school and compute the ratios. Do any of the rooms have dimensions that approximate musical intervals? Do the rooms with "pleasant" ratios actually sound better (less echo, better acoustics)?

---

## Lesson 4.6: The Harmonic Series in Nature and Engineering

### Explanation

The harmonic series appears in many natural and engineered systems:

### The Harmonic Series in Vibrating Strings

When a guitar string is plucked, it vibrates at multiple frequencies simultaneously. The fundamental frequency is the lowest frequency, and the overtones are integer multiples of the fundamental. The amplitudes of these overtones typically decrease as 1/n, following the harmonic series.

This is why different instruments sound different even when playing the same note — they produce different overtone spectra.

### The Harmonic Series in Acoustics

The harmonic series appears in room acoustics. When sound bounces off walls, it creates standing waves at specific frequencies. These frequencies are integer multiples of the fundamental frequency, which is determined by the room dimensions.

The acoustic properties of a room are determined by the harmonic series of its standing waves. This is why concert halls are designed with specific proportions — to create favorable harmonic series for music.

### The Harmonic Series in Electrical Engineering

The harmonic series appears in electrical engineering, particularly in the analysis of alternating current (AC) circuits. The Fourier transform of a square wave, for example, contains only odd harmonics: f, 3f, 5f, 7f, ...

The amplitudes of these harmonics decrease as 1/n, following the harmonic series.

### The Harmonic Series in Signal Processing

In signal processing, the harmonic series appears in the analysis of periodic signals. The Fourier series of a periodic signal decomposes it into a sum of sinusoids at harmonic frequencies. The coefficients of the Fourier series are related to the harmonic series.

### The Harmonic Series in Quantum Mechanics

The harmonic series appears in quantum mechanics, particularly in the quantum harmonic oscillator. The energy levels of the quantum harmonic oscillator are equally spaced:

E(n) = ℏω(n + 1/2)

This is the quantum version of the harmonic series.

### Worked Example 4.6.1

A square wave has amplitude 1 and period T. What is the amplitude of the third harmonic?

**Solution**: The Fourier series of a square wave is:

f(t) = (4/π)(sin(ωt) + (1/3)sin(3ωt) + (1/5)sin(5ωt) + ...)

The amplitude of the third harmonic is (4/π)(1/3) ≈ 0.424.

The amplitude of the fundamental is (4/π) ≈ 1.273.

The ratio is (1/3) = 0.333, which is 1/3 of the fundamental.

### Practice Problems

1. What are the first 5 overtones of a guitar string with fundamental 100 Hz?
2. Why do different instruments sound different even when playing the same note?
3. What is the Fourier series of a square wave?
4. How does the harmonic series appear in the quantum harmonic oscillator?
5. Why is the harmonic series important in electrical engineering?

### Teacher's Notes

**Physics Connection**: This lesson connects the harmonic series to physics and engineering. The harmonic series is not just an abstract mathematical concept — it has practical applications in acoustics, electrical engineering, and quantum mechanics.

**Demonstration**: If you have access to a spectrum analyzer or audio software, show students the overtone spectrum of different instruments. This is a powerful demonstration of the harmonic series in action.

---

## Lesson 4.7: The Golden Ratio in Music

### Explanation

The golden ratio appears in music in several ways:

### The Golden Ratio in Musical Composition

Many composers have intuitively or explicitly used the golden ratio in their compositions:

**1. Mozart**

Mozart's piano sonatas often have their climaxes at the golden section of the movement. For example, in the first movement of the Piano Sonata in C major (K. 545), the development section begins at the golden section of the exposition.

**2. Beethoven**

Beethoven's Fifth Symphony has its famous "fate motif" occurring at the golden section of the first movement. The transition from the exposition to the development also occurs at a golden-ratio point.

**3. Bartok**

Bartok was explicitly aware of the golden ratio and used it extensively in his compositions. His string quartets and concertos are structured around golden-ratio proportions.

**4. Debussy**

Debussy's "La Mer" (The Sea) has its climactic moment at the golden section of the total duration.

### The Golden Ratio in Musical Form

The golden ratio appears in the structure of musical forms:

**1. Sonata Form**

In sonata form, the exposition, development, and recapitulation are sometimes divided at golden-ratio points.

**2. Rondo Form**

In rondo form, the recurring theme (refrain) sometimes appears at golden-ratio intervals.

**3. Theme and Variations**

In theme and variations, the most elaborate variation sometimes occurs at the golden section of the set.

### The Golden Ratio in Tuning

Some alternative tuning systems use the golden ratio as a fundamental ratio. The "golden scale" is a musical scale where each step is related to the golden ratio.

### Worked Example 4.7.1

A symphony lasts 40 minutes. If the climax occurs at the golden section, at what time does it occur?

**Solution**: Climax time = 40/φ ≈ 40/1.618 ≈ 24.72 minutes ≈ 24 minutes 43 seconds.

### Practice Problems

1. Listen to a symphony and identify the climax. How close is it to the golden section?
2. Research: how did Bartok use the golden ratio in his music?
3. What is sonata form? How might the golden ratio apply?
4. Find a piece of music that uses the golden ratio in its structure.
5. Why might composers use the golden ratio?

### Teacher's Notes

**Music Connection**: If you have access to a music player, play excerpts from compositions that use the golden ratio and have students identify the golden-section points.

**Cross-Curricular Connection**: Collaborate with the music teacher to create a lesson that combines mathematical analysis of golden-ratio proportions with musical performance.

---

## Summary of Chapter 4

### Key Concepts

1. The **harmonic series** 1 + 1/2 + 1/3 + 1/4 + ... diverges, despite its terms approaching zero.
2. The **nth harmonic number** H(n) = 1 + 1/2 + ... + 1/n ≈ ln(n) + γ.
3. **Musical intervals** are ratios of frequencies: octave (2:1), fifth (3:2), fourth (4:3), major third (5:4).
4. The **overtone series** of a vibrating string follows the harmonic series: f, 2f, 3f, 4f, ...
5. **Equal temperament** divides the octave into 12 equal semitones, each with ratio 2^(1/12).
6. **Pythagorean tuning** generates the scale by stacking perfect fifths (ratio 3:2).
7. The **Pythagorean comma** is the discrepancy between 12 perfect fifths and 7 octaves.
8. **Harmonic proportions** appear in architecture, from the Parthenon to Le Corbusier's Modulor.

### Key Formulas

| Formula | Description |
|---------|-------------|
| H(n) = Σ 1/k for k=1 to n | nth harmonic number |
| H(n) ≈ ln(n) + γ | Approximation for harmonic number |
| γ ≈ 0.5772156649 | Euler-Mascheroni constant |
| f = f₀ × 2^(n/12) | Equal temperament frequency |
| Overtones: f, 2f, 3f, 4f, ... | Harmonic series in music |

### Connections to Other Chapters

- **Chapter 1 (Golden Ratio)**: The golden ratio appears in musical instrument design and in the Modulor system of architecture.
- **Chapter 5 (Fibonacci and Lucas Numbers)**: Some composers have used Fibonacci numbers in musical composition.
- **Chapter 8 (Living Mathematics)**: The harmonic series appears in the branching patterns of trees and the distribution of leaves.

---

**End of Chapter 4**

*Next: Chapter 5 — Fibonacci and Lucas Numbers*
