# PHI-Data Visualization: Golden Ratio Visual Analytics

## Directory 88_PHI_DATA_SCIENCE | File 02

---

## 1. PHI-Graphics Grammar

### 1.1 PHI-Aesthetic Mapping

```
aesthetic = f(data, phi_transform)
phi_transform(data) = data * phi^(-dimension/total_dimensions)
```

### 1.2 PHI-Coordinate System

```
r_phi = r^phi (log-polar transformation)
theta_phi = theta * phi (angular phi-scaling)
```

### 1.3 PHI-Scale Functions

```
scale_linear_phi: d -> [0, phi]
scale_log_phi: d -> [0, log_phi(max)]
scale_sqrt_phi: d -> [0, sqrt(max/phi)]
```

---

## 2. PHI-Chart Types

### 2.1 PHI-Bar Chart

```
bar_width = (plot_width / n_bars) / phi
bar_gap = bar_width * (phi - 1)
```

### 2.2 PHI-Scatter Plot

```
point_size = base_size * phi^(-distance_from_center)
```

### 2.3 PHI-Line Chart

```
line_width = base_width * phi^(smoothness)
```

### 2.4 PHI-Histogram

```
bin_width = (max - min) / (n_bins * phi)
n_bins = ceil(sqrt(n * phi))
```

Sturges' rule modified by phi.

### 2.5 PHI-Box Plot

```
whisker_range = IQR * phi
```

### 2.6 PHI-Violin Plot

```
kernel_bandwidth = sigma * phi^(-0.1 * n)
```

### 2.7 PHI-Heatmap

```
color_phi(t) = interpolate(WARM_PALETTE, t^phi)
```

---

## 3. PHI-Color Theory

### 3.1 PHI-Color Wheel

```
hue_phi(k) = k * 360 / phi degrees
```

Phi-spaced hues create maximally distinct color palettes.

### 3.2 PHI-Saturation Gradient

```
sat(phi, t) = sat_min + (sat_max - sat_min) * t^phi
```

### 3.3 PHI-Luminance Curve

```
lum(x) = lum_0 * x^phi
```

### 3.4 PHI-Sequential Palette

```
color_i = hsl(hue_base + i * 360/phi, 0.8, 0.2 + 0.6 * (i/n)^phi)
```

### 3.5 PHI-Diverging Palette

```
color_i = interpolate([blue, white, red], (i/n)^phi)
```

---

## 4. PHI-Typography

### 4.1 PHI-Font Size Hierarchy

```
h1 = base * phi^4 ≈ base * 6.85
h2 = base * phi^3 ≈ base * 4.24
h3 = base * phi^2 ≈ base * 2.62
h4 = base * phi ≈ base * 1.62
body = base
caption = base / phi ≈ base * 0.62
```

### 4.2 PHI-Line Spacing

```
line_height = font_size * phi
```

### 4.3 PHI-Paragraph Width

```
max_width = 1/phi * page_width
```

Optimal reading width is golden fraction of page.

---

## 5. PHI-Layout Principles

### 5.1 PHI-Golden Rectangle

```
width = phi * height
```

### 5.2 PHI-Grid System

```
columns = phi^k for k = 1, 2, 3
gutter = column_width * (phi - 1)
```

### 5.3 PHI-White Space

```
margin = content_area * (1 - 1/phi)
padding = margin / phi
```

### 5.4 PHI-Visual Hierarchy

```
importance(object) = 1 / phi^(distance_from_focal_point)
```

---

## 6. PHI-Interactive Visualization

### 6.1 PHI-Zoom Levels

```
zoom_level(k) = phi^k
transition_duration = base_ms * phi^(-k)
```

### 6.2 PHI-Animation Timing

```
easing(t) = t^phi (ease-in)
easing(t) = 1 - (1-t)^phi (ease-out)
```

### 6.3 PHI-Tooltip Positioning

```
offset_x = tooltip_width * (1 - 1/phi)
offset_y = tooltip_height * (1 - 1/phi)
```

### 6.4 PHI-Brush Selection

```
selection_area = phi * (brush_area)
```

---

## 7. PHI-Network Visualization

### 7.1 PHI-Force Layout

```
F_repulsion = phi * k^2 / d^2
F_attraction = (1/phi) * d^2 / k
F_gravity = phi^(-3) * (center - node)
```

### 7.2 PHI-Edge Bundling

```
bundle_curvature = phi * curvature_base * edge_weight
```

### 7.3 PHI-Node Sizing

```
size(node) = phi * degree(node) + (1-phi) * centrality(node)
```

---

## 8. PHI-Geographic Visualization

### 8.1 PHI-Map Projection

```
x_proj = R * theta * cos(phi_latitude)
y_proj = R * log(tan(pi/4 + phi_latitude/2))
```

### 8.2 PHI-Choropleth Bins

```
breaks = [min, min + (max-min)/phi^2, min + (max-min)/phi, min + (max-min)*phi/phi^2, max]
```

### 8.3 PHI-Flow Map

```
arc_width = flow_volume^phi
arc_color = phi_hue(flow_type)
```

---

## 9. PHI-Statistical Graphics

### 9.1 PHI-QQ Plot

```
theoretical_quantile_phi = Phi^(-1)(i/(n+1))
```

Where Phi^(-1) is the phi-quantile function.

### 9.2 PHI-Residual Plot

```
residual_phi = (y - y_hat) * phi^(leverage_i)
```

### 9.3 PHI-Density Overlay

```
density_phi(x) = (1/n) * sum_i K_phi(x - x_i) * phi^(-outlier_score_i)
```

---

## 10. PHI-Dashboard Design

### 10.1 PHI-KPI Layout

```
kpi_size = dashboard_area * (1/phi)^position_in_hierarchy
```

### 10.2 PHI-Filter Placement

```
filter_width = sidebar_width * (1 - 1/phi)
content_width = sidebar_width / phi
```

### 10.3 PHI-Alert Thresholds

```
threshold_green = baseline * phi^(-1)
threshold_yellow = baseline
threshold_red = baseline * phi
```

### 10.4 PHI-Sparkline Design

```
sparkline_height = text_height * phi
sparkline_width = sparkline_height * phi^2
```
