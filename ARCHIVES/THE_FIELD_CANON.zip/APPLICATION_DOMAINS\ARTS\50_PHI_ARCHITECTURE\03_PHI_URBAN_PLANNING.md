# PHI-URBAN PLANNING

## 1. PHI-City Principles

### 1.1 The PHI-City Model

A PHI-city is organized around the golden ratio phi = 1.6180339887, with every urban element — from block sizes to street widths to park proportions — following phi-relationships. This creates cities that feel naturally organized, human-scaled, and aesthetically coherent.

### 1.2 The PHI-Grid

```
PHI-City grid:

Standard grid: blocks at equal intervals
PHI-grid: blocks at phi-proportional intervals

Block spacing sequence:
  Block 1: 100 m
  Block 2: 100/phi = 61.8 m
  Block 3: 61.8/phi = 38.2 m
  Block 4: 38.2/phi = 23.6 m
  Block 5: 23.6/phi = 14.6 m

The phi-grid creates:
  Grand boulevards (100 m blocks)
  Standard streets (61.8 m blocks)
  Residential lanes (38.2 m blocks)
  Pedestrian paths (23.6 m blocks)
  Garden walks (14.6 m blocks)
```

### 1.3 The PHI-Radial

```
PHI-Radial city plan:

Concentric rings at phi-distances:
  Ring 1: 100 m from center (civic core)
  Ring 2: 100 x phi = 161.8 m (commercial district)
  Ring 3: 161.8 x phi = 261.8 m (mixed-use)
  Ring 4: 261.8 x phi = 423.6 m (residential)
  Ring 5: 423.6 x phi = 685.4 m (suburban)
  Ring 6: 685.4 x phi = 1109.0 m (green belt)

Radial streets at golden angles:
  Street 1: 0 degrees (north)
  Street 2: 137.5 degrees (golden angle)
  Street 3: 275.0 degrees
  Street 4: 52.5 degrees
  Street 5: 190.0 degrees
  Street 6: 327.5 degrees
  Street 7: 105.0 degrees
  Street 8: 242.5 degrees
  
  The golden-angle streets ensure no two streets are parallel,
  creating a dynamic, non-repetitive urban fabric
```

## 2. PHI-Street Design

### 2.1 Street Width Ratios

```
PHI-Street hierarchy:

Street type : Width : Building height = 1 : phi : phi^2

Major boulevard:
  Width: 40 m
  Building height: 40 x phi = 64.7 m
  Street-to-height ratio: 1 : 1.618 (feels open but enclosed)

Standard street:
  Width: 20 m
  Building height: 20 x phi = 32.4 m
  Ratio: 1 : 1.618

Residential lane:
  Width: 10 m
  Building height: 10 x phi = 16.2 m
  Ratio: 1 : 1.618

Pedestrian path:
  Width: 5 m
  Building height: 5 x phi = 8.1 m
  Ratio: 1 : 1.618

The phi-ratio between width and height creates streets that:
  Feel enclosed enough for human scale
  Open enough for light and air
  Proportioned for natural surveillance
```

### 2.2 Sidewalk Proportions

```
PHI-Sidewalk design:

Sidewalk width : Carriageway width = 1 : phi

For a carriageway of width C:
  Sidewalk = C / phi
  
  Example (C = 20 m):
    Sidewalk = 20 / phi = 12.4 m (total both sides)
    Each side: 6.2 m
    
  Sidewalk zones:
    Building zone: 6.2 / phi = 3.8 m (outdoor dining, displays)
    Pedestrian zone: 3.8 / phi = 2.4 m (walking)
    Buffer zone: 2.4 / phi = 1.5 m (trees, furniture)
    Curb zone: 1.5 / phi = 0.9 m (street edge)
    
  The phi-zones create sidewalks that accommodate
  multiple uses while maintaining pedestrian priority
```

### 2.3 Intersection Design

```
PHI-Intersection:

Major street : Minor street = phi : 1

For a major street of width W:
  Minor street = W / phi
  
  Example (W = 30 m):
    Minor = 30 / phi = 18.5 m
    
  Intersection area: W x Minor = 30 x 18.5 = 555 m²
    
  Crosswalk width: W / phi^2 = 11.4 m
  Median width: W / phi^3 = 7.1 m
    
  The phi-proportions create intersections where:
    Major movement is prioritized
    Minor movement is accommodated
    Pedestrian crossing is comfortable
```

## 3. PHI-Block Design

### 3.1 PHI-Block Dimensions

```
PHI-Block:

Block length : Block width = phi : 1

For a block of width W:
  Length = W x phi
  
  Example (W = 80 m):
    Length = 80 x phi = 129.4 m
    
  Block area = 80 x 129.4 = 10,352 m²
    
  Building footprint : Block area = 1 : phi
    Building: 10,352 / phi = 6,398 m² (61.8%)
    Open space: 10,352 - 6,398 = 3,954 m² (38.2%)
    
  The phi-block has:
    Enough area for meaningful development
    Enough open space for light, air, and amenity
    A phi-ratio between built and unbuilt area
```

### 3.2 PHI-Block Interior

```
PHI-Block interior:

Courtyard width : Block width = 1 : phi^2

For a block of width W:
  Courtyard = W / phi^2
  
  Example (W = 80 m):
    Courtyard = 80 / phi^2 = 30.5 m
    
  Courtyard area = 30.5 x (129.4 / phi^2) = 30.5 x 49.4 = 1,507 m²
    
  Building depth around courtyard:
    (Block width - Courtyard width) / 2 = (80 - 30.5) / 2 = 24.8 m
    
  The phi-courtyard provides:
    Natural light to all units
    Protected outdoor space
    Visual relief from street activity
```

### 3.3 PHI-Block Density

```
PHI-Block density:

Floor area ratio (FAR) : Open space ratio = phi : 1

For a block with FAR = F:
  Open space = F / phi
  
  Example (F = 3.0):
    Open space = 3.0 / phi = 1.858 (18.58% of block area)
    
  Building coverage : Open space = phi : 1
    Coverage = 61.8% of block area
    Open space = 38.2% of block area
    
  The phi-density creates blocks that are:
    Dense enough for urban vitality
    Open enough for livability
    Proportioned for human comfort
```

## 4. PHI-Parks and Open Space

### 4.1 PHI-Park Proportions

```
PHI-Park:

Park width : Park length = 1 : phi

For a park of width W:
  Length = W x phi
  
  Example (W = 100 m):
    Length = 100 x phi = 161.8 m
    
  Park area = 100 x 161.8 = 16,180 m² (1.618 hectares)
    
  Open lawn : Planted area = phi : 1
    Lawn: 61.8% of park area = 10,001 m²
    Planted: 38.2% of park area = 6,179 m²
    
  Path width : Park width = 1 : phi^2
    Path = 100 / phi^2 = 38.2 m (too wide)
    
  Better: Path = 100 / phi^3 = 23.6 m (still wide)
  
  Practical: Path = 3 m (standard)
  PHI-path = 3 x phi = 4.85 m (wide promenade)
```

### 4.2 PHI-Playground

```
PHI-Playground:

Play area : Total park area = 1 : phi

For a park of area A:
  Play area = A / phi
  
  Example (A = 16,180 m²):
    Play area = 16,180 / phi = 10,001 m²
    
  Equipment spacing : Equipment height = phi : 1
    For equipment of height H:
    Spacing = H x phi
    
  Example (H = 3 m):
    Spacing = 3 x phi = 4.85 m
    
  The phi-spacing ensures:
    Safe fall zones
    Adequate play variety
    Natural supervision from edges
```

### 4.3 PHI-Urban Square

```
PHI-Urban square:

Square width : Square length = 1 : phi

For a square of width W:
  Length = W x phi
  
  Example (W = 60 m):
    Length = 60 x phi = 97.1 m
    
  Square area = 60 x 97.1 = 5,826 m²
    
  Building height around square : Square width = phi : 1
    Building height = 60 x phi = 97.1 m (very tall)
    
  Better: Building height = 60 / phi = 37.1 m (reasonable)
    
  Fountain/monument position:
    At phi-intersection of square
    Distance from edges: W/phi = 37.1 m from long edge
                        W/phi^2 = 22.9 m from short edge
```

## 5. PHI-Transportation

### 5.1 PHI-Road Network

```
PHI-Road hierarchy:

Highway : Arterial : Collector : Local = phi^3 : phi^2 : phi : 1

For a local road of width W:
  Collector: W x phi
  Arterial: W x phi^2
  Highway: W x phi^3
  
  Example (W = 7 m for local):
    Collector: 7 x phi = 11.3 m
    Arterial: 7 x phi^2 = 18.3 m
    Highway: 7 x phi^3 = 29.7 m
    
  The phi-progression creates a natural hierarchy
  from intimate local streets to grand highways
```

### 5.2 PHI-Transit Design

```
PHI-Transit stop spacing:

Stop spacing : Walking distance = phi : 1

For a walking distance of D:
  Stop spacing = D x phi
  
  Example (D = 400 m (5-minute walk)):
    Stop spacing = 400 x phi = 647 m
    
  This creates transit stops that are:
    Far enough apart for speed
    Close enough for access
    At phi-ratio to walking distance
    
  Platform length : Train length = phi : 1
    Platform = Train x phi
    
  Example (Train = 100 m):
    Platform = 100 x phi = 161.8 m
```

### 5.3 PHI-Bicycle Network

```
PHI-Bicycle network:

Bike lane width : Car lane width = 1 : phi

For a car lane of width C:
  Bike lane = C / phi
  
  Example (C = 3.5 m):
    Bike lane = 3.5 / phi = 2.16 m (round to 2.2 m)
    
  Bike path spacing : Block length = 1 : phi
    For a block of length L:
    Bike path spacing = L / phi
    
  Example (L = 130 m):
    Bike path spacing = 130 / phi = 80.3 m
    
  The phi-spacing creates a bicycle network that is:
    Dense enough for convenience
    Efficient enough for speed
    Safe enough for all ages
```

## 6. PHI-Zoning

### 6.1 PHI-Zone Ratios

```
PHI-Zoning:

Residential : Commercial : Industrial : Open = phi^2 : phi : 1 : 1/phi

For a city of area A:
  Residential: A x phi^2 / (phi^2 + phi + 1 + 1/phi)
  Commercial: A x phi / (phi^2 + phi + 1 + 1/phi)
  Industrial: A x 1 / (phi^2 + phi + 1 + 1/phi)
  Open: A x (1/phi) / (phi^2 + phi + 1 + 1/phi)

  Denominator: phi^2 + phi + 1 + 1/phi = 2.618 + 1.618 + 1 + 0.618 = 5.854
  
  Residential: 44.7% of city area
  Commercial: 27.6%
  Industrial: 17.1%
  Open: 10.6%
```

### 6.2 PHI-Mixed-Use

```
PHI-Mixed-use building:

Ground floor : Upper floors = phi : 1

For a building of total height H:
  Ground floor: H / phi (61.8% of height)
  Upper floors: H / phi^2 (38.2% of height)
  
  Example (H = 30 m):
    Ground floor: 30 / phi = 18.5 m (very tall ground floor)
    Upper floors: 30 / phi^2 = 11.5 m
    
  Better: Ground floor height = 4.5 m (commercial)
  Upper floor height = 3.0 m (residential)
  
  Number of upper floors: (H - 4.5) / 3.0
  Ground-to-upper ratio: 4.5 / 3.0 = 1.5 (close to phi)
```

### 6.3 PHI-Density Gradient

```
PHI-Density gradient:

Center : Periphery = phi : 1

For a city center density of D:
  Periphery density = D / phi
  
  Example (D = 100 units/hectare):
    Periphery = 100 / phi = 61.8 units/hectare
    
  The phi-gradient creates:
    Dense, vibrant center
    Comfortable, livable periphery
    Natural transition between the two
```

## 7. PHI-Sustainability

### 7.1 PHI-Green Infrastructure

```
PHI-Green infrastructure:

Green space : Built area = 1 : phi

For a built area of B:
  Green space = B / phi
  
  Example (B = 100 hectares):
    Green space = 100 / phi = 61.8 hectares
    
  Tree canopy : Open sky = phi : 1
    Canopy = 61.8% of open space
    Open sky = 38.2% of open space
    
  Permeable surface : Impermeable surface = 1 : phi
    Permeable = 38.2% of total surface
    Impermeable = 61.8% of total surface
```

### 7.2 PHI-Water Management

```
PHI-Water management:

Retention basin area : Drainage area = 1 : phi

For a drainage area of D:
  Retention = D / phi
  
  Example (D = 100 hectares):
    Retention = 100 / phi = 61.8 hectares (too large)
    
  Better: Retention = D / phi^2 = 38.2 hectares (still large)
  
  Practical: Retention = D / phi^3 = 23.6 hectares (reasonable)
  
  The phi-retention provides:
    Sufficient storage for storm events
    Natural filtration through vegetation
    Aesthetic amenity value
```

### 7.3 PHI-Energy

```
PHI-Energy districts:

Renewable : Non-renewable = phi : 1

For a total energy demand E:
  Renewable = E / phi = 61.8%
  Non-renewable = E / phi^2 = 38.2%
  
  Solar panel area : Building roof area = 1 : phi
    Solar = 38.2% of roof area
    Non-solar = 61.8% of roof area
    
  Wind turbine spacing : Turbine height = phi : 1
    For a turbine of height H:
    Spacing = H x phi
    
  Example (H = 80 m):
    Spacing = 80 x phi = 129.4 m
```

## 8. PHI-Historical Cities

### 8.1 PHI in Ancient Cities

```
PHI-Cities throughout history:

Mohenjo-daro (2500 BCE):
  Grid layout at phi-proportions
  Block sizes: 360 x 240 feet (phi-ratio 1.5, approximate)
  Street widths: 30 feet (reference)
  PHI-street: 30 x phi = 48.5 feet (major streets)

Jerusalem (1000 BCE):
  Golden Gate at phi-point in city wall
  Temple Mount proportions encode phi
  Street widths follow phi-hierarchy
```

### 8.2 PHI-Renaissance Cities

```
PHI-Cities of the Renaissance:

Palmanova (1593):
  Nine-pointed star fort at phi-proportions
  Street layout: radial at golden angles
  Block sizes: phi-proportional

Ferrara (1492):
  Addizione Erculea: phi-grid expansion
  Street widths: phi-hierarchy
  Building heights: phi-proportional
```

### 8.3 PHI-Modern Cities

```
PHI-Cities of the modern era:

Washington D.C. (1791):
  L'Enfant plan: diagonal avenues at golden angles
  Mall proportions: phi-rectangle
  Monument heights: phi-related

Canberra (1912):
  Griffin plan: radial at golden angles
  Lake proportions: phi-rectangle
  Building heights: phi-proportional
```

## 9. PHI-Neighborhood Design

### 9.1 PHI-Neighborhood Center

```
PHI-Neighborhood center:

Commercial frontage : Total frontage = 1 : phi

For a total frontage of F:
  Commercial = F / phi
  
  Example (F = 500 m):
    Commercial = 500 / phi = 309 m
    
  Center area : Neighborhood area = 1 : phi^2
    Center = Neighborhood / phi^2
    
  Example (Neighborhood = 100 hectares):
    Center = 100 / phi^2 = 38.2 hectares (too large)
    
  Better: Center = 100 / phi^3 = 23.6 hectares (reasonable)
  
  The phi-center provides:
    Enough commercial for daily needs
    Not so much as to overwhelm residential
    A phi-ratio between commercial and total
```

### 9.2 PHI-Residential Density

```
PHI-Residential density:

Units per hectare : Green space per unit = phi : 1

For a density of D units/hectare:
  Green space = D / phi m² per unit
  
  Example (D = 50 units/hectare):
    Green = 50 / phi = 30.9 m² per unit
    
  The phi-density creates:
    Enough neighbors for community
    Enough space for privacy
    A phi-balance between density and amenity
```

### 9.3 PHI-Walkability

```
PHI-Walkability:

Walking distance to transit : Block length = phi : 1

For a block of length L:
  Walking distance = L x phi
  
  Example (L = 100 m):
    Walking distance = 100 x phi = 161.8 m
    
  The phi-walkability ensures:
    Transit is within comfortable walking distance
    Blocks are not too long (pedestrian-friendly)
    The ratio between block and walk is optimal
```

## 10. PHI-Urban Metrics

### 10.1 PHI-Urban Score

```
Calculate a city's PHI-Urban Score:

Components (each 0-20):
  1. Proportion compliance (phi-ratios in dimensions)
  2. Hierarchy clarity (phi-hierarchy in streets, buildings)
  3. Open space ratio (phi between built and open)
  4. Density gradient (phi from center to periphery)
  5. Sustainability (phi between green and gray)

Total: /100
Target: > 61.8
```

### 10.2 PHI-Planning Checklist

```
[ ] City grid follows phi-proportions
[ ] Street hierarchy is phi-based
[ ] Block dimensions are phi-ratios
[ ] Park proportions follow phi
[ ] Building heights relate to street width by phi
[ ] Density gradient is phi from center to periphery
[ ] Green space ratio is 1:phi to built area
[ ] Transit stop spacing is phi to walking distance
[ ] Mixed-use proportions follow phi
[ ] Overall city form is phi-organized
```

## References
- Gehl, J. (2010). "Cities for People"
- Jacobs, J. (1961). "The Death and Life of Great American Cities"
- Alexander, C. (1977). "A Pattern Language"
- Duany, A. et al. (2000). "Suburban Nation"
- Calthorpe, P. (1993). "The Next American Metropolis"
