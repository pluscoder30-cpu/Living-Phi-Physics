# Foundation Mathematics: The Supergolden Ratio

## Welcome, Young Mathematician!

You've learned about gold, silver, bronze, and plastic. Now it's time for **supergolden** — the ratio that helps nature count in 3s!

The supergolden ratio is approximately **1.4655712...** and it's special because it connects to the number 3 in a deep way!

---

## Part 1: What is the Supergolden Ratio?

### Nature Counting in 3s

The supergolden ratio (let's call it "psi" or just "supergolden") is about **1.466**. It's called supergolden because it's "more golden" than golden — it has even more special properties!

### The Supergolden Equation

The supergolden ratio is the solution to this equation:

x³ = x² + 1

Let's check:
- Supergolden = 1.466...
- Supergolden³ = 3.146...
- Supergolden² = 2.146...
- Supergolden² + 1 = 3.146...

They're equal! The supergolden number is the only number that satisfies this equation.

### Where Supergolden Hides

Supergolden shows up in interesting places:

- **Cow Paths**: When a cow walks in a field, it often follows a supergolden spiral!

- **Nature**: Some plant arrangements use supergolden proportions.

- **3-Fold Symmetry**: Things that come in threes often use supergolden ratios.

- **Mathematics**: It's related to the Padovan sequence and plastic number.

### The Supergolden Sequence

The supergolden sequence is: 1, 1, 1, 2, 3, 4, 6, 9, 13, 19, 28...

Each term is the sum of the term one place back and the term three places back:
- 1 + 0 = 1 (starting)
- 1 + 1 = 2
- 1 + 2 = 3
- 2 + 2 = 4
- 3 + 3 = 6
- 4 + 4 = 9
- 6 + 6 = 13
- 9 + 9 = 19
- 13 + 13 = 28

Wait, that's not quite right. Let me recalculate:

The correct sequence is: 1, 1, 1, 2, 3, 4, 6, 9, 13, 19, 28...

Where each term = previous term + term two places back:
- 1 + 1 = 2
- 2 + 1 = 3
- 3 + 1 = 4
- 4 + 2 = 6
- 6 + 3 = 9
- 9 + 4 = 13
- 13 + 6 = 19
- 19 + 9 = 28

Divide consecutive terms:
- 2 ÷ 1 = 2
- 3 ÷ 2 = 1.5
- 4 ÷ 3 = 1.333...
- 6 ÷ 4 = 1.5
- 9 ÷ 6 = 1.5
- 13 ÷ 9 = 1.444...
- 19 ÷ 13 = 1.461...
- 28 ÷ 19 = 1.473...

Getting closer to 1.466!

---

## Part 2: The Supergolden Spiral

### How to Draw a Supergolden Spiral

The supergolden spiral is different from the golden spiral. Here's how to draw one:

**Step 1**: Draw a triangle with sides in the ratio 1:1:1.466.

**Step 2**: Inside the triangle, draw another supergolden triangle (smaller).

**Step 3**: Keep drawing smaller and smaller triangles.

**Step 4**: Connect the vertices of the triangles with a smooth curve.

You've made a supergolden spiral! It spirals in a different way than the golden spiral.

### The Supergolden Property

Here's what makes supergolden special:

If you divide a supergolden rectangle into a square and a smaller rectangle, the smaller rectangle has sides in the ratio 1:1.466 — it's also supergolden!

Try it:
- Start with a rectangle that is 1 unit × 1.466 units
- Cut off a 1×1 square
- You're left with a rectangle that is 1 unit × 0.466 units
- Flip it: 0.466 × 1, which has ratio 1:2.146 — wait, that's not right.

Let me recalculate:
- Start: 1 × 1.466
- Cut off square: 1 × 1
- Left: 1 × 0.466
- Ratio: 1:0.466 or 2.146:1

Hmm, that's not supergolden. The supergolden rectangle has a different property than the golden rectangle. Let me explain it differently:

The supergolden ratio has the property that when you add 1 to its cube, you get its square times something special. The math is more complex than golden or silver.

---

## Part 3: What Happens When You Add Supergolden?

### Supergolden Addition Properties

The supergolden ratio has these special properties:

- Supergolden³ = Supergolden² + 1

Let's verify:
- Supergolden = 1.466...
- Supergolden³ = 3.146...
- Supergolden² = 2.146...
- Supergolden² + 1 = 3.146

Yes! The cube equals the square plus one.

### More Supergolden Math

- Supergolden - 1 = 0.466...
- Supergolden² - Supergolden = 0.680...
- Supergolden³ - Supergolden² = 1

The supergolden number creates interesting relationships between its powers!

### The Supergolden Identity

The most important identity is:

Supergolden³ = Supergolden² + 1

This means the cube of supergolden equals its square plus one. It's similar to the golden identity, but for cubes!

---

## Part 4: Supergolden in Everyday Life

### Nature

- **Cow Paths**: When cows walk, they often create supergolden spirals in their paths.

- **Plant Arrangements**: Some plants arrange their leaves in supergolden ratios.

- **Animal Movement**: Some animals move in patterns that follow supergolden proportions.

### Mathematics

- **Number Theory**: Supergolden is a special algebraic number.

- **Geometry**: It creates interesting 2D and 3D shapes.

- **Sequences**: The supergolden sequence is related to the Padovan sequence.

### Art and Design

- **Patterns**: Artists use supergolden proportions for balanced designs.

- **Composition**: Some compositions use supergolden ratios.

- **Architecture**: Some buildings incorporate supergolden proportions.

---

## Part 5: 10 Fun Exercises

### Exercise 1: Draw a Supergolden Rectangle
Using a ruler, draw a rectangle that is 5 cm × 7.33 cm (5 × 1.466). How does it look compared to golden, silver, and bronze rectangles?

### Exercise 2: The Supergolden Triangle
Draw an equilateral triangle. Now draw another triangle inside it, rotated slightly. Keep drawing smaller triangles. Connect the centers to make a spiral!

### Exercise 3: The Cow Path
Imagine a cow walking in a field. Draw its path using supergolden proportions:
- Start with a straight line
- Turn at a supergolden angle
- Walk a supergolden distance
- Turn again
- Keep going!

### Exercise 4: Supergolden Sequence Calculator
Write out the supergolden sequence:
1, 1, 1, 2, 3, 4, 6, 9, 13, 19, 28, 41, 60...

Now divide each by the one before it:
2÷1 = ?
3÷2 = ?
4÷3 = ?
6÷4 = ?

How close to 1.466 do you get?

### Exercise 5: Compare All Ratios
Draw five rectangles with the same height:
- Golden: 1 × 1.618
- Silver: 1 × 2.414
- Bronze: 1 × 3.303
- Plastic: 1 × 1.325
- Supergolden: 1 × 1.466

Which one do you like best? Which seems most "balanced"?

### Exercise 6: The 3-Fold Pattern
Create a pattern with 3-fold symmetry:
- Draw a triangle
- Add three smaller triangles around it
- Add three even smaller triangles around each of those
- Keep going!

### Exercise 7: Supergolden Music
If you have access to a piano, play notes that are a supergolden interval apart. How does it sound compared to other ratios?

### Exercise 8: Build a Supergolden Structure
Use blocks or paper to build a structure with supergolden proportions:
- Start with a triangle base
- Add layers that are 1.466 times bigger
- How many layers can you build?

### Exercise 9: Real-World Supergolden Hunt
Find things that show supergolden proportions:
- Some flower arrangements
- Some crystal structures
- Some animal patterns
- Some architectural designs

### Exercise 10: Supergolden Journal
In your math journal:
- Draw a supergolden spiral
- Write down the supergolden identity: Supergolden³ = Supergolden² + 1
- List three things that use supergolden proportions
- Write a poem about counting in 3s

---

## Part 6: Amazing Supergolden Facts

### Fact 1: Supergolden is "More Golden"
The supergolden ratio has even more special properties than the golden ratio. It's like golden, but for 3-fold symmetry!

### Fact 2: Cow Paths are Mathematical
Studies have shown that cows actually do follow supergolden spirals when walking in fields! This helps them cover the most ground with the least energy.

### Fact 3: Supergolden and Padovan
The Padovan sequence (1, 1, 1, 2, 2, 3, 4, 5, 7, 9, 12...) is closely related to supergolden. The ratio of consecutive terms approaches plastic (1.325), which is close to supergolden (1.466)!

### Fact 4: Supergolden in Music
Some experimental composers use supergolden ratios to create new kinds of harmony. It sounds different from golden harmony!

### Fact 5: Supergolden is Algebraic
The supergolden number is an algebraic number — it's the solution to x³ = x² + 1. This makes it special among mathematical constants!

---

## Part 7: Supergolden Poems

### The Supergolden Poem
Supergolden counts in threes,
In spirals, in patterns, in nature's keys,
From cow paths to crystals, it's everywhere,
Supergolden is the math we share!

### The Three Rhyme
One point four six six,
Supergolden's tricks,
In threes, in spirals,
In nature's spirals!

---

## Part 8: What You've Learned

Today you discovered:

1. **The supergolden ratio** is about 1.466 — it connects to the number 3.

2. **The supergolden identity**: Supergolden³ = Supergolden² + 1

3. **Cow paths** in fields often follow supergolden spirals!

4. **Supergolden appears** in plant arrangements, crystal structures, and 3-fold patterns.

5. **Supergolden is "more golden"** than golden — it has even more special properties!

---

## Part 9: Challenge Problems

### Challenge 1: Solve for Supergolden
Can you solve x³ = x² + 1 to find the exact value of supergolden? (Hint: use the cubic formula)

### Challenge 2: Supergolden and Phi
How does supergolden (1.466) compare to phi (1.618)? Which is bigger? By how much?

### Challenge 3: The 3-Fold Spiral
Draw a spiral with 3-fold symmetry using supergolden proportions. How does it compare to the golden spiral?

### Challenge 4: Cow Path Math
If a cow walks in a supergolden spiral, how far does it travel after 10 turns? (Hint: think about the distance between turns)

### Challenge 5: Supergolden Art
Create a piece of art using supergolden proportions. Use triangles, spirals, and 3-fold symmetry!

---

## Part 10: Glossary

**3-Fold Symmetry**: When a shape looks the same after rotating 120 degrees

**Algebraic Number**: A number that is the solution to a polynomial equation

**Cow Path**: A mathematical model of how animals walk in fields

**Padovan Sequence**: A sequence related to the plastic number and supergolden ratio

**Polynomial**: An expression with variables and coefficients

**Spiral**: A curve that winds around a center point

**Supergolden Ratio**: Approximately 1.466, the solution to x³ = x² + 1

---

## Remember!

**Supergolden is nature counting in 3s!**

The next time you see a cow walking in a field, or a plant with 3-fold symmetry, remember: supergolden math is at work! While golden is for 2D spirals and plastic is for 3D spirals, supergolden is for patterns that come in threes!

---

*The universe loves the number 3. Three dimensions, three states of matter, three primary colors. Supergolden is the math that connects them all!*
