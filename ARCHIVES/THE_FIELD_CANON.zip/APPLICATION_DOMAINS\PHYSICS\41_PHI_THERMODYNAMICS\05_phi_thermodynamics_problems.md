# PHI-THERMODYNAMICS: Practice Problems

---

## Problem 1: Phi-Carnot Efficiency
Calculate the phi-corrected Carnot efficiency for T_H = 700 K and T_C = 350 K.

## Problem 2: Phi-Entropy of Mixing
Find the phi-entropy of mixing for 2 mol helium + 3 mol neon.

## Problem 3: Phi-Boltzmann Distribution
Calculate the ratio of particles in energy states E₂ = 0.2 eV vs E₁ = 0 at T = 400 K using phi-Boltzmann.

## Problem 4: Phi-Partition Function
Calculate the phi-partition function for a three-level system with E = 0, 0.05, 0.1 eV at T = 300 K.

## Problem 5: Phi-Heat Capacity
What is the phi-corrected heat capacity of aluminum at T = 400 K (Θ_D = 428 K)?

## Problem 6: Phi-Stefan-Boltzmann
Calculate the phi-corrected power radiated by a blackbody at T = 3000 K.

## Problem 7: Phi-Critical Exponents
Find the phi-corrected β exponent for the 3D Ising model.

## Problem 8: Phi-Landauer Principle
Calculate the minimum energy to erase 10 bits at T = 350 K using phi-Landauer.

## Problem 9: Phi-Ideal Gas Entropy
Find the phi-entropy of 2 mol of argon at T = 400 K and V = 0.05 m³.

## Problem 10: Phi-Quantum Heat Engine
Calculate the work output of a phi-Otto engine with T_H = 500 K, T_C = 250 K.

## Problem 11: Phi-Fluctuation Theorem
Verify the phi-fluctuation theorem for a two-level system with ε = 0.15 eV at T = 300 K.

## Problem 12: Phi-Thermal Conductivity
What is the phi-corrected thermal conductivity of iron at T = 400 K (Θ_D = 470 K)?

## Problem 13: Phi-Entropy Production Rate
Calculate the phi-entropy production rate for heat conduction with q = 30,000 W/m² and ΔT = 100 K.

## Problem 14: Phi-Maxwell's Demon
How much work can a phi-demon extract sorting 10⁸ particles at T = 300 K?

## Problem 15: Phi-Ideal Gas Pressure
Calculate the phi-corrected pressure of 0.5 mol of CO₂ at T = 350 K and V = 0.01 m³.

## Problem 16: Phi-Stirling Efficiency
Find the efficiency of a phi-Stirling engine with T_H = 700 K and T_C = 350 K.

## Problem 17: Phi-Clausius-Clapeyron
Calculate the phi-corrected slope of the water-steam boundary at T = 373 K.

## Problem 18: Phi-Debye Model
What is the phi-corrected phonon density of states at ω = ω_D/3 for a Debye solid with Θ_D = 400 K?

## Problem 19: Phi-Channel Capacity
Calculate the phi-corrected channel capacity for a binary symmetric channel with p = 0.15.

## Problem 20: Phi-Steady State Temperature
What is the phi-corrected temperature at x = 0.3 in a rod with T(0) = 500 K and T(L) = 300 K?

## Problem 21: Phi-Brayton Efficiency
Find the phi-corrected Brayton efficiency for r_p = 8 and γ = 1.4.

## Problem 22: Phi-Magnetization Entropy
Calculate the phi-entropy change for magnetizing 10²² spins at T = 200 K with B = 2 T.

## Problem 23: Phi-Onsager Coefficients
Calculate the phi-corrected cross-coupling coefficient L₁₂ for a thermoelectric material with L₁₂ = 15.

## Problem 24: Phi-Diffusion Entropy
Find the phi-entropy production rate for diffusion with D = 5×10⁻⁶ m²/s and ∇c = 200 mol/m⁴.

## Problem 25: Phi-Bénard Convection
What is the phi-corrected critical Rayleigh number for Bénard convection?

---

*Part of the 32_PHI_PHYSICS / 06_EXPANDED_MATHEMATICS system.*
*Version 1.0 — Agent H of 26*
