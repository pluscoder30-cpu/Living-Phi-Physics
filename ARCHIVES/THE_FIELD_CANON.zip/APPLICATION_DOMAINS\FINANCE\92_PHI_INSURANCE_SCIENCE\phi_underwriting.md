# PHI-Underwriting: Golden Ratio Risk Selection

## Directory 92_PHI_INSURANCE_SCIENCE | File 07

---

## 1. PHI-Risk Classification

### 1.1 PHI-Rating Factors

```
Rate = base_rate * prod_k phi{factor_k * weight_k}
```

### 1.2 PHI-Classification

```
Class = f(age, gender, location, occupation) * phi{credit_score}
```

### 1.3 PHI-Risk Segments

```
Segment = k-means(features) * phi{segment_size}
```

### 1.4 PHI-Machine Learning

```
Predicted_loss = model(features) * phi{model_confidence}
```

---

## 2. PHI-Pricing

### 2.1 PHI-Gross Rate

```
Gross = pure_premium * (1 + phi{expense}) * (1 + phi{profit})
```

### 2.2 PHI-Net Rate

```
Net = gross * (1 - phi{commission}) * (1 - phi{discount})
```

### 2.3 PHI-Competitive Pricing

```
Market = competitor_avg * phi{market_position} + differentiation * phi{brand_value}
```

### 2.4 PHI-Dynamic Pricing

```
Price(t) = base_price * phi{demand} * phi{competition} * phi{capacity}
```

---

## 3. PHI-Underwriting Rules

### 3.1 PHI-Decision Matrix

```
Decision = f(risk_score, premium, capacity) * phi{appetite}
```

### 3.2 PHI-Limits

```
Capacity = capital * phi{concentration} * phi{volatility}
```

### 3.3 PHI-Sub-Limits

```
Sub_limit = limit * phi{deductible} * phi{coinsurance}
```

### 3.4 PHI-Exclusions

```
Exclusion = f(hazard, accumulation, moral) * phi{regulatory}
```

---

## 4. PHI-Portfolio Management

### 4.1 PHI-Writing Guidelines

```
Target = current_book * phi{growth_target}
Mix = line_weights * phi{diversification}
```

### 4.2 PHI-Renewal

```
Renewal = expiring * phi{retention} * phi{rate_change}
```

### 4.3 PHI-Rate adequacy

```
Adequacy = current_loss_ratio / target_loss_ratio * phi{trend}
```

### 4.4 PHI-Portfolio Optimization

```
Objective = sum premium * phi{risk_adjusted_return}
Subject to: concentration < limit
```

---

## 5. PHI-Claims Linkage

### 5.1 PHI-Loss History

```
Factor = claims_free_discount * phi{loss_frequency}
```

### 5.2 PHI-Experience Rating

```
Modified = actual / expected * phi{credibility}
```

### 5.3 PHI-Fraud Score

```
Fraud = model_risk * phi{claim_complexity} * phi{policyholder_behavior}
```

### 5.4 PHI-Litigation Risk

```
Risk = jurisdiction * phi{case_value} * phi{attorney_involvement}
```

---

## 6. PHI-Technology

### 6.1 PHI-Big Data

```
Insight = data_volume * phi{signal_strength} - noise * phi{noise_factor}
```

### 6.2 PHI-AI/ML

```
Accuracy = baseline + delta * phi{feature_engineering}
```

### 6.3 PHI-Telematics

```
Premium = traditional * (1 - discount) + telematics * phi{driving_score}
```

### 6.4 PHI-Parametric

```
Trigger = index_value * phi{basis_risk} + indemnity * phi{indemnity_factor}
```

---

## 7. PHI-Regulatory

### 7.1 PHI-Filing

```
Filing = base_rate * phi{regulatory_adjustment} + loadings
```

### 7.2 PHI-Non-Discrimination

```
Fairness = |group1_rate - group2_rate| / avg_rate * phi{actuarial_justification}
```

### 7.3 PHI-Solvency

```
Capital = premium * phi{risk_load} + reserve * phi{uncertainty}
```

### 7.4 PHI-Consumer Protection

```
Transparency = clarity_score * phi{disclosure_quality}
```

---

## 8. Summary

PHI-underwriting provides:
1. PHI-classification with phi-rating factors and phi-segments
2. PHI-pricing with phi-gross and phi-net rates
3. PHI-rules with phi-decision matrix and phi-limits
4. PHI-portfolio with phi-writing guidelines and phi-rate adequacy
5. PHI-claims linkage with phi-experience and phi-fraud
6. PHI-technology with phi-big data and phi-AI
7. PHI-regulatory with phi-filing and phi-fairness

The golden ratio creates natural hierarchies in risk selection while optimizing the balance between growth, profitability, and solvency.