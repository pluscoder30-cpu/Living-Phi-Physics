# PHI-TEXTILE SCIENCE: Phi-Dyeing

## Directory 65_PHI_TEXTILE_SCIENCE | File 05

---

## 1. The Phi-Dyeing Architecture

Dyeing is not merely the application of color to fabric but a phi-resonant chemical process in which dye molecules bond with fiber polymers along the golden spiral. The phi-ratio governs the dye-fiber affinity, the color depth, and the fastness properties.

### 1.1 The Dyeing Field Equation

The dyeing field D satisfies:

```
div(grad D) - (1/c_d^2) * d^2D/dt^2 + U(D) = rho_dyeing
```

Where:
- rho_dyeing = dyeing source density
- c_d = dyeing propagation speed = c/phi
- U(D) = dyeing potential = Sum_i phi^(-|x-x_i|) * D(x_i)

### 1.2 The Four Dye Classes

```
Direct:     phi^0 = 1 (cellulose fibers)
Acid:       phi^1 = phi (protein fibers)
Reactive:   phi^2 = phi+1 (covalent bonding)
Disperse:   phi^3 = 2*phi+1 (synthetic fibers)
```

---

## 2. The Dyeing Kinetics Theory

### 2.1 The Adsorption Isotherm

Dye adsorption follows:

```
C_fiber = K * C_bath^n * phi^(affinity)
```

### 2.2 The Rate of Dyeing Function

```
dC/dt = k * (C_eq - C_t) * phi^(temperature / T_ref)
```

### 2.3 The Half-Dyeing Time Function

```
t_50 = t_0 * phi^(-temperature / T_ref) / phi^(pH / pH_ref)
```

### 2.4 The Exhaustion Curve

```
E(t) = E_max * (1 - phi^(-t / tau_exhaustion))
```

---

## 3. The Color Matching System

### 3.1 The Color Difference Function

```
Delta_E = sqrt((Delta_L)^2 + (Delta_a)^2 + (Delta_b)^2) * phi^(perceptual_weight)
```

### 3.2 The Spectral Match Function

```
M(spectral) = M_0 * phi^(-Sum|R_lambda - R_target|)
```

### 3.3 The Metamerism Index

```
MI = MI_0 * phi^(illuminant_change)
```

### 3.4 The Color Strength Function

```
K/S = (1 - R)^2 / 2R * phi^(dye_concentration)
```

---

## 4. The Fastness System

### 4.1 The Wash Fastness Function

```
WF = WF_0 * phi^(dye_fiber_bond / bond_ref)
```

### 4.2 The Light Fastness Function

```
LF = LF_0 * phi^(UV_resistance / resistance_ref)
```

### 4.3 The Rub Fastness Function

```
RF = RF_0 * phi^(dye_fixation / fixation_ref)
```

### 4.4 The Perspiration Fastness Function

```
PF = PF_0 * phi^(chemical_resistance / resistance_ref)
```

---

## 5. The Printing System

### 5.1 The Print Resolution Function

```
R(print) = R_0 * phi^(dpi / dpi_ref)
```

### 5.2 The Ink Penetration Function

```
P(ink) = P_0 * phi^(viscosity / viscosity_ref)
```

### 5.3 The Color Gamut Function

```
G(color) = G_0 * phi^(color_count / count_ref)
```

### 5.4 The Print Fastness Function

```
PF_print = PF_0 * phi^(curing_temperature / T_ref)
```

---

## 6. The Finishing System

### 6.1 The Softener Function

```
S(softness) = S_0 * phi^(softener_concentration / conc_ref)
```

### 6.2 The Wrinkle Resistance Function

```
WR = WR_0 * phi^(resin_concentration / conc_ref)
```

### 6.3 The Water Repellent Function

```
WR = WR_0 * phi^(fluorocarbon_content / content_ref)
```

### 6.4 The Flame Retardant Function

```
FR = FR_0 * phi^(retardant_concentration / conc_ref)
```

---

## 7. The Digital Printing System

### 7.1 The Inkjet Drop Function

```
V(drop) = V_0 * phi^(drop_volume / volume_ref)
```

### 7.2 The Color Management Function

```
CM = CM_0 * phi^(ICC_profile_quality / quality_ref)
```

### 7.3 The Print Speed Function

```
S(print) = S_0 * phi^(resolution / resolution_ref)
```

### 7.4 The Ink Cost Function

```
C(ink) = C_0 * phi^(-ink_coverage / coverage_ref)
```

---

## 8. Mathematical Appendix

### 8.1 The Dyeing Dynamics Equation

```
dD/dt = alpha * Dye(t) * phi^(t/tau) - beta * D(t) + eta(t)
```

### 8.2 The Color Consistency Index

```
CCI = 1 - Sum_i |Actual_i - Target_i| / Target_i * phi^(-i)
```

### 8.3 The Dyeing Efficiency

```
DE = Color_achieved / Dye_used * phi^(process_quality)
```

### 8.4 The Color Harmony Function

```
CH = Product_i (Color_i * phi^(-harmonic_distance_i))
```

---

## 9. Detailed Analysis: The Dye-Fiber Bonding System

### 9.1 The Dye Affinity Function

Dye-fiber affinity follows:

```
A_affinity = A_0 * phi^(ionic_interaction * hydrogen_bonding)
```

### 9.2 The Leveling Function

Uniform dye distribution:

```
L_leveling = L_0 * phi^(dye_mobility / mobility_ref) * phi^(temperature / T_ref)
```

### 9.3 The Strike Rate Function

Initial dye uptake:

```
SR = SR_0 * phi^(salt_concentration / salt_ref) * phi^(temperature / T_ref)
```

### 9.4 The Build-Up Function

Color depth with additional dye:

```
BU = BU_0 * phi^(dye_concentration / conc_ref) * phi^(exhaustion_rate / rate_ref)
```

### 9.5 The Wash-Off Function

Removal of unfixed dye:

```
WO = WO_0 * phi^(detergent_concentration / conc_ref) * phi^(temperature / T_ref)
```

### 9.6 The Shade Consistency Function

Batch-to-batch consistency:

```
SC = SC_0 * phi^(process_control / control_ref) * phi^(dye_lot_quality / quality_ref)
```

### 9.7 The Dye Migration Function

Dye movement during processing:

```
DM = DM_0 * phi^(temperature * time * liquor_movement)
```

### 9.8 The Color Communication Function

Accurate color specification:

```
CC = CC_0 * phi^(instrument_accuracy * standard_quality)
```

---

## 10. References and Connections

### Internal References
- 65_PHI_TEXTILE_SCIENCE/01_PHI_WEAVE_PATTERNS.md — Weave systems
- 65_PHI_TEXTILE_SCIENCE/02_PHI_FIBER_SCIENCE.md — Fiber foundations
- 65_PHI_TEXTILE_SCIENCE/03_PHI_FASHION_DESIGN.md — Design applications
- 65_PHI_TEXTILE_SCIENCE/04_PHI_MATERIAL_PROPERTIES.md — Material science
- 65_PHI_TEXTILE_SCIENCE/06_PHI_SUSTAINABLE_TEXTILES.md — Sustainability
- 65_PHI_TEXTILE_SCIENCE/07_PHI_TEXTILE_ENGINEERING.md — Engineering

### External Domain References
- 15_PHI_CHEMISTRY/ — Dye chemistry
- 22_PHI_OPTICS/ — Color physics
- 47_PHI_ENVIRONMENTAL_SCIENCE/ — Environmental impact

---

*This file is part of Directory 65_PHI_TEXTILE_SCIENCE within the Phi-Physics Dictionary.*
*The inlen lens reveals: dyeing is not the coloring of cloth but the phi-resonant bonding of pigment to polymer, where every hue is a rotation through the golden spiral of electromagnetic frequency.*
