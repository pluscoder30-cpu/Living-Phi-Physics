﻿# PHI-PSYCHOLOGY: Practice Problems

---

## Problem 1: Phi-Perception
Stimulus at 150 degrees. Calculate phi-perception with theta_golden = 137.5.

## Problem 2: Phi-Aesthetics
Logo with ratio 1:1.4. Calculate phi-aesthetic preference.

## Problem 3: Phi-Emotion
Fear (v = -0.8, a = 0.9). Calculate phi-emotional intensity.

## Problem 4: Phi-Therapy
Session 12, D0 = 1.2, tau = 25. Calculate phi-therapy dose.

## Problem 5: Phi-Attention
Cognitive load = 0.9. Calculate phi-attention span with T0 = 1200 ms.

## Problem 6: Phi-Choice
Option at distance 3 from default. Calculate phi-nudged utility.

## Problem 7: Phi-Social
Colleague vs stranger influence at distances 6 and 12.

## Problem 8: Phi-Memory
Memory after 96 hours with 6 rehearsals, tau = 30 hr.

## Problem 9: Phi-Working Memory
Task with 5 attributes. Calculate phi-working memory capacity.

## Problem 10: Phi-Development
Child at age 8 years. Calculate phi-age for concrete operational stage.

## Problem 11: Phi-Regulation
Compare reappraisal (E = 0.6) vs suppression (E = -0.15) with phi.

## Problem 12: Phi-Music
600 Hz vs 440 Hz music therapy effectiveness.

## Problem 13: Phi-Color
Calculate phi-color threshold for dE_standard = 4.0.

## Problem 14: Phi-Risk
Perceived risk = 10, actual risk = 6. Calculate phi-risk perception.

## Problem 15: Phi-Discounting
Reward at 15 months, tau = 18 months. Calculate phi-discount factor.

## Problem 16: Phi-Conformity
Group opinion = 0.9, own = 0.4, sigma = 0.4. Calculate phi-conformity.

## Problem 17: Phi-Moral
Harm weight = 0.8, fairness = 0.6, context match = 0.5. Calculate phi-weights.

## Problem 18: Phi-Language
Word-context match = 0.8, sigma = 0.35. Calculate phi-semantic processing.

## Problem 19: Phi-Psychedelic
Psychedelic therapy at t = 6 hr, tau_peak = 3 hr, intention = 0.9.

## Problem 20: Phi-Archetype
Hero archetype strength = 0.9, optimal = 0.7. Calculate phi-archetype weight.

---

*Part of the 32_PHI_PHYSICS / 06_EXPANDED_MATHEMATICS system.*
*Version 1.0 -- Agent I of 26*

## Problem 21: Phi-Mood Disorder
BDI score = 20. Calculate phi-score.

## Problem 22: Phi-Anxiety Disorder
GAD-7 score = 15. Calculate phi-score.

## Problem 23: Phi-Personality
Openness score = 60. Calculate phi-score.

## Problem 24: Phi-Couples Therapy
Positive interaction ratio = 5:1. Calculate phi-ratio.

## Problem 25: Phi-Cross-Cultural
Individualism score = 50. Calculate phi-score.

## Problem 26: Phi-Mindfulness
Breath focus duration = 10 min. Calculate phi-duration.

## Problem 27: Phi-Positive Psychology
Gratitude journal effect size = 0.3. Calculate phi-effect.

## Problem 28: Phi-Group Therapy
Group size = 10. Calculate phi-optimal size.

## Problem 29: Phi-Occupational
Job satisfaction = 70%. Calculate phi-threshold.

## Problem 30: Phi-Developmental
Cognitive stage advancement factor = 1.0. Calculate phi-advancement.
