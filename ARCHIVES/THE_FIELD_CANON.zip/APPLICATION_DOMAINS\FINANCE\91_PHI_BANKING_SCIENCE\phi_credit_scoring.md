# PHI-Credit Scoring: Golden Ratio Default Prediction

## Directory 91_PHI_BANKING_SCIENCE | File 01

---

## 1. PHI-Credit Score Model

### 1.1 PHI-Logistic Regression Score

```
P(default) = 1 / (1 + e^{-z_phi})
z_phi = sum_{k=1}^{K} beta_k * x_k * phi^{variable_importance_k}
```

### 1.2 PHI-Scorecard Points

```
Points = sum_{k=1}^{K} w_k * score(x_k)
w_k = beta_k * phi^{category_weight_k} / sum_j |beta_j|
```

### 1.3 PHI-Score Bands

```
Band 1: Score > mean + phi*sigma -> AAA
Band 2: Score in [mean, mean + phi*sigma) -> AA
Band 3: Score in [mean - phi*sigma, mean) -> A
Band 4: Score in [mean - phi^2*sigma, mean - phi*sigma) -> BBB
Band 5: Score < mean - phi^2*sigma -> BB or below
```

---

## 2. PHI-Feature Engineering

### 2.1 PHI-Age of Credit

```
Age_phi = ln(age_years + 1) * phi^{oldest_account_ratio}
```

### 2.2 PHI-Utilization

```
Util_phi = (balance / limit) * phi^{balance_trend}
```

### 2.3 PHI-Payment History

```
Payment_phi = (on_time_payments / total_payments) * phi^{recent_weight}
```

### 2.4 PHI-Inquiry Count

```
Inquiry_phi = count(inquiries_6m) * phi^{-time_since_last}
```

---

## 3. PHI-PD Model

### 3.1 PHI-Structural Model

```
PD_phi = N(-d_2_phi)
d_2_phi = [ln(V/D) + (mu - sigma^2/2)*T] / (sigma*sqrt(T)) * phi^{leverage}
```

### 3.2 PHI-Reduced Form

```
h(t) = h_0(t) * exp(sum beta_k * x_k) * phi^{t/tau}
```

### 3.3 PHI-Survival Analysis

```
S(t) = S_0(t)^{exp(sum beta_k * x_k) * phi^{hazard_rate}}
```

### 3.4 PHI-Transition Matrix

```
P(i->j) = P_0(i->j) * phi^{rating_change_frequency}
```

---

## 4. PHI-Machine Learning Credit Scoring

### 4.1 PHI-Random Forest

```
Gini_phi = Gini * phi^{tree_depth}
Split_threshold = Gini * phi^{-n_samples/1000}
```

### 4.2 PHI-XGBoost

```
Obj = sum L(y_i, y_hat_i) + sum omega_j * phi^{complexity}
omega_j = gamma + phi * (1/2) * lambda * w_j^2
```

### 4.3 PHI-Neural Network

```
h_l = ReLU(W_l * h_{l-1} + b_l) * phi^{-l/L}
Output = softmax(W_L * h_L) * phi^{class_imbalance}
```

### 4.4 PHI-Ensemble

```
Score_ensemble = sum_{m=1}^{M} alpha_m * Score_m * phi^{model_accuracy_m}
```

---

## 5. PHI-Credit Grading

### 5.1 PHI-Internal Rating

```
Rating = f(PD, LGD, EAD) * phi^{systematic_risk}
```

### 5.2 PHI-Rating Migration

```
Migration_prob(i,j) = P_0(i,j) * phi^{|rating_i - rating_j|}
```

### 5.3 PHI-Watch List

```
Watch = 1 if (PD > threshold) OR (rating_outlook < 0) * phi
```

### 5.4 PHI-Sovereign Rating

```
Rating_sov = f(GDP_growth, debt/GDP, reserves/GDP) * phi^{political_stability}
```

---

## 6. PHI-Regulatory Requirements

### 6.1 PHI-IRB Approach

```
Capital_IRB = LGD * EAD * b(PD) * RW
b(PD) = (1 - (1-PD)^{1/n}) / (1 - (1-PD)^{1/(n*phi)})
```

### 6.2 PHI-Standardized

```
RW = risk_weight * phi^{regulatory_multiplier}
```

### 6.3 PHI-PD Backtesting

```
Brier_score = mean((PD_i - default_i)^2) * phi^{forecast_horizon}
```

### 6.4 PHI-Model Validation

```
KS_statistic = max|S_good(t) - S_bad(t)| * phi^{sample_size}
```

---

## 7. PHI-Application Process

### 7.1 PHI-Automated Decisioning

```
Decision = score * phi^{policy_adjustment}
Accept if: Score > Accept_threshold
Reject if: Score < Reject_threshold
Refer if: Accept_threshold > Score > Reject_threshold
```

### 7.2 PHI-Odds-Based Pricing

```
Interest_rate = base_rate + risk_premium * phi^{-odds_ratio}
```

### 7.3 PHI-Credit Limit

```
Limit = Income * phi^{debt_to_income} * phi^{credit_score/100}
```

### 7.4 PHI-Account Review

```
Review_frequency = 1 / (PD * phi^{portfolio_segment})
```

---

## 8. Summary

PHI-credit scoring provides:
1. PHI-logistic scorecard with phi-weighted coefficients
2. PHI-feature engineering with phi-age, phi-utilization, phi-payment
3. PHI-PD models with structural and reduced-form phi-methods
4. PHI-machine learning with phi-RF, phi-XGBoost, phi-NN
5. PHI-credit grading with phi-transition matrices
6. PHI-regulatory requirements with phi-IRB and phi-standardized
7. PHI-application process with phi-automated decisioning

The golden ratio creates natural separation between risk categories and optimizes the trade-off between Type I and Type II errors in credit decisions.