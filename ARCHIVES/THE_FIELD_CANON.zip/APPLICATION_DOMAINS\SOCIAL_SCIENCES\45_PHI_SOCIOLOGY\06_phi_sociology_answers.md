# PHI-SOCIOLOGY: Answer Key

---

## Problem 1: Network Topology Analysis

**(a) Normalization constant:**
```
Σ_k P(k) = 1
C × Σ_k k^(−1/φ) = 1
C × ζ(1/φ) = 1
ζ(0.618) ≈ 2.378
C = 1/2.378 ≈ 0.421
```

**(b) Average degree:**
```
⟨k⟩ = Σ_k k × P(k) = C × Σ_k k^(1−1/φ)
= C × Σ_k k^0.382
For N = 1000: ⟨k⟩ ≈ C × 1000^0.382/0.382 ≈ 0.421 × 15.8 ≈ 6.65
```

**(c) P(k > 50):**
```
P(k > 50) ≈ ∫₅₀^∞ C × k^(−0.618) dk
= C × [k^0.382/0.382]₅₀^∞
= 0.421 × 50^0.382/0.382
= 0.421 × 4.27/0.382
≈ 4.72 (normalized to probability: ≈ 0.047)
```

**(d) Clustering coefficient:**
```
C_φ = 1/φ = 0.618
```

---

## Problem 2: Information Cascade Prediction

**(a) P(d = 3):**
```
P_phi = p^d × φ^(−d) = 0.6^3 × φ^(−3)
= 0.216 × 0.236
= 0.051
```

**(b) Expected at d = 5:**
```
Expected = N_neighbors^d × P_phi
= 5^5 × (0.6^5 × φ^(−5))
= 3125 × (0.0778 × 0.0902)
= 3125 × 0.00702
= 21.9 ≈ 22 people
```

**(c) Cutoff distance:**
```
P_cascade < 0.01
p^d × φ^(−d) < 0.01
(0.6/φ)^d < 0.01
(0.371)^d < 0.01
d > ln(0.01)/ln(0.371)
d > −4.605/(−0.991)
d > 4.65
d* = 5 hops
```

**(d) Standard model:**
```
P_standard = 0.6^5 = 0.0778
P_phi = 0.6^5 × φ^(−5) = 0.00702
Ratio: P_phi/P_standard = 0.0902 = φ^(−5)
```

---

## Problem 3: Cultural Resonance Analysis

**(a) Harmonic number:**
```
ω_C/ω₀ = 4.236 = φ³
n = 3
```

**(b) Propagation time (resonant):**
```
τ_resonant = τ₀/|sin(π × ln(φ³)/ln(φ))|
= τ₀/|sin(π × 3)|
= τ₀/|sin(3π)|
= τ₀/0
→ ∞ (instantaneous propagation)
```

**(c) Non-resonant at ω_C = 1.5ω₀:**
```
τ_nonresonant = τ₀/|sin(π × ln(1.5)/ln(φ))|
= τ₀/|sin(π × 0.585)|
= τ₀/|sin(1.838)|
= τ₀/0.966
= 1.035 × τ₀
```

**(d) Speed ratio:**
```
v_resonant/v_nonresonant = τ_nonresonant/τ_resonant
= 1.035 × τ₀ / ∞
= 0 (resonant is infinitely faster)
```

---

## Problem 4: Organizational Design

**(a) Optimal depth:**
```
d_opt = log_φ(2000) = ln(2000)/ln(φ)
= 7.601/0.481
= 15.8 ≈ 16 levels
```

**(b) Average span:**
```
span = φ = 1.618
```

**(c) Level-by-level:**
```
Level 1: 1
Level 2: 2
Level 3: 3
Level 4: 5
Level 5: 8
Level 6: 13
Level 7: 21
Level 8: 34
Level 9: 55
Level 10: 89
Level 11: 144
Level 12: 233
Level 13: 377
Level 14: 610
Total: 1+2+3+5+8+13+21+34+55+89+144+233+377+610 = 1,595
(Levels 15-16: 405 more to reach 2,000)
```

**(d) Standard comparison:**
```
Standard: 6 levels, span ≈ 5.4 (2000^(1/6))
Phi-model: 16 levels, span = 1.618
Information flow: φ × faster per level
Total flow: 16 × ln(φ) = 7.7 vs 6 × ln(5.4) = 9.7 (phi is more efficient)
```

---

## Problem 5: Urban Scaling Prediction

**(a) Phi-model (exponent 1/φ = 0.618):**
```
Patents_B = Patents_A × (N_B/N_A)^(1/φ)
= 10,000 × (500,000/50,000)^0.618
= 10,000 × 10^0.618
= 10,000 × 4.151
= 41,510 patents
```

**(b) Standard model (exponent 1.2):**
```
Patents_B(std) = 10,000 × 10^1.2
= 10,000 × 15.85
= 158,500 patents
```

**(c) Difference:**
```
Difference = 158,500 − 41,510 = 116,990
Ratio = 41,510/158,500 = 0.262
```

**(d) Better model:**
The phi-model (exponent 0.618) better matches empirical innovation data, which shows sublinear scaling for patents (exponent 0.7-0.9).

---

## Problem 6: Social Field Calculation

**(a) Total potential:**
```
Φ_total = Σ q_i × φ^(−r_i/R₀)
= 10 × φ^(−1) + 20 × φ^(−2) + 30 × φ^(−3)
= 10 × 0.618 + 20 × 0.382 + 30 × 0.236
= 6.18 + 7.64 + 7.08
= 20.90
```

**(b) Equilibrium distance (equal charges):**
```
r_eq = R₀ × ln(q²)/ln(φ)
For q = 20: r_eq = R₀ × ln(400)/ln(φ) = R₀ × 5.991/0.481 = 12.46 × R₀
```

**(c) Force direction:**
```
F ∝ −∇Φ = positive direction (repulsive)
Because potential decreases with distance
```

**(d) Standard comparison:**
```
Φ_standard = 10/1² + 20/2² + 30/3² = 10 + 5 + 3.33 = 18.33
Phi-model: 20.90
Ratio: 20.90/18.33 = 1.14
```

---

## Problem 7: Collective Intelligence

**(a) Phi-model:**
```
I_group = I_individual × N^(1/φ) × η
= 120 × 25^0.618 × 0.8
= 120 × 6.813 × 0.8
= 653.6
```

**(b) Standard model:**
```
I_group(std) = I_individual × √N
= 120 × √25
= 120 × 5
= 600
```

**(c) Improvement ratio:**
```
653.6/600 = 1.089 ≈ φ^(1/8)
```

**(d) Minimum size for I > 500:**
```
500 = 120 × N^0.618 × 0.8
N^0.618 = 500/(120 × 0.8) = 5.208
N = 5.208^(1/0.618) = 5.208^1.618 = 14.3
N_min = 15 people
```

---

## Problem 8: Conflict Resolution

**(a) Resolution time:**
```
t_resolve = τ_resolve × ln(I₀/I_threshold)/ln(φ)
= τ_resolve × ln(500/25)/ln(φ)
= τ_resolve × ln(20)/ln(φ)
= τ_resolve × 2.996/0.481
= 6.23 × τ_resolve
```

**(b) For τ_resolve = 2 years:**
```
t = 6.23 × 2 = 12.46 years
```

**(c) If I₀ = 1,000:**
```
t = τ_resolve × ln(1000/25)/ln(φ)
= τ_resolve × ln(40)/ln(φ)
= τ_resolve × 3.689/0.481
= 7.67 × τ_resolve
= 15.34 years
```

**(d) Halve resolution time:**
```
t_new = t/2 = 3.115 × τ_resolve
ln(I₀_new/25)/ln(φ) = 3.115
I₀_new/25 = φ^3.115 = 4.89
I₀_new = 122.3
Reduction needed: (500 − 122.3)/500 = 75.5%
```

---

## Problem 9: Information Memory

**(a) Phi-decay (τ = 5 days):**
```
Day 1: 5000 × φ^(−1/5) = 5000 × 0.871 = 4,355
Day 3: 5000 × φ^(−3/5) = 5000 × 0.669 = 3,345
Day 7: 5000 × φ^(−7/5) = 5000 × 0.397 = 1,985
Day 14: 5000 × φ^(−14/5) = 5000 × 0.157 = 785
```

**(b) Exponential (same half-life):**
```
t_(1/2) = 5 × ln(2)/ln(φ) = 7.21 days
λ = ln(2)/7.21 = 0.0961
Day 1: 5000 × e^(−0.0961) = 4,543
Day 3: 5000 × e^(−0.288) = 3,647
Day 7: 5000 × e^(−0.673) = 2,562
Day 14: 5000 × e^(−1.345) = 1,291
```

**(c) Comparison at day 14:**
```
Phi: 785, Exponential: 1,291
Ratio: 785/1,291 = 0.608
```

**(d) Drop below 100:**
```
100 = 5000 × φ^(−t/5)
0.02 = φ^(−t/5)
ln(0.02) = −t/5 × ln(φ)
t = −5 × ln(0.02)/ln(φ)
= −5 × (−3.912)/0.481
= 40.7 days
```

---

## Problem 10: Institutional Effectiveness

**(a) Effectiveness at various times:**
```
Year 5: 100 × φ^(−5/15) = 100 × 0.786 = 78.6
Year 10: 100 × φ^(−10/15) = 100 × 0.618 = 61.8
Year 15: 100 × φ^(−15/15) = 100 × 0.382 = 38.2
Year 30: 100 × φ^(−30/15) = 100 × 0.146 = 14.6
```

**(b) Half-life:**
```
t_(1/2) = τ × ln(2)/ln(φ) = 15 × 1.443 = 21.6 years
```

**(c) Drop below 10:**
```
10 = 100 × φ^(−t/15)
0.1 = φ^(−t/15)
t = −15 × ln(0.1)/ln(φ) = 15 × 4.788 = 71.8 years
```

**(d) Steady-state with reforms:**
```
Reform boost: +50% every 20 years
Decay in 20 years: φ^(−20/15) = 0.382
Net change per cycle: 1.5 × 0.382 = 0.573
Steady-state: E₀ × 1/(1 − 0.573) = E₀ × 2.342
If E₀ = 100: E_ss = 234.2
```

---

*End of PHI-SOCIOLOGY Answers*
