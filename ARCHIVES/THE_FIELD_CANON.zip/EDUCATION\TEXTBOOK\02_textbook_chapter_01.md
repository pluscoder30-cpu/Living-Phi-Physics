# Chapter 1: The Golden Ratio (Phi)

## The Most Beautiful Number in Mathematics

---

### Overview

The golden ratio is a mathematical constant, usually denoted by the Greek letter φ (phi). It is approximately equal to 1.6180339887... and it has fascinated mathematicians, artists, architects, and scientists for over two thousand years.

The golden ratio is not just an abstract number. It appears in nature with remarkable frequency: in the spirals of sunflowers, the branching of trees, the spirals of shells, the proportions of the human body, and the structure of DNA. It appears in art and architecture, from the Parthenon to the works of Leonardo da Vinci. It appears in music, from the proportions of musical instruments to the structure of compositions.

In this chapter, we will learn what the golden ratio is, where it comes from, and how to compute with it. We will discover that the golden ratio is not just a curiosity — it is a fundamental constant of nature.

---

## Lesson 1.1: What Is a Ratio?

### Explanation

A **ratio** is a comparison of two quantities. It answers the question: "how many times as large is one quantity compared to the other?"

If you have 6 apples and 3 oranges, the ratio of apples to oranges is 6:3, which simplifies to 2:1. This means you have twice as many apples as oranges.

Ratios can be written in several ways:

- **Using a colon**: 6:3
- **Using the word "to"**: 6 to 3
- **As a fraction**: 6/3

All three notations mean the same thing. The fraction notation is the most useful for computation, because a fraction is just a division problem. The ratio 6:3 is the same as 6 ÷ 3 = 2.

**Key Concept**: A ratio is a single number. When we say the ratio of apples to oranges is 2:1, the ratio itself is the number 2.

### Worked Example 1.1.1

A rectangle has length 8 cm and width 4 cm. What is the ratio of length to width?

**Solution**: The ratio of length to width is 8:4 = 8/4 = 2.

This means the length is twice the width.

### Worked Example 1.1.2

A rectangle has length 6 cm and width 4 cm. What is the ratio of length to width?

**Solution**: The ratio of length to width is 6:4 = 6/4 = 3/2 = 1.5.

This means the length is one and a half times the width.

### Worked Example 1.1.3

A rectangle has length 5 cm and width 3 cm. What is the ratio of length to width?

**Solution**: The ratio of length to width is 5:3 = 5/3 ≈ 1.6667.

This means the length is about 1.6667 times the width.

Notice that this ratio — 5/3 — is close to the golden ratio (approximately 1.618). We will return to this observation later.

### Practice Problems

1. A rectangle has length 10 cm and width 5 cm. What is the ratio of length to width?
2. A rectangle has length 12 cm and width 8 cm. What is the ratio of length to width? Simplify your answer.
3. A rectangle has length 7 cm and width 4 cm. What is the ratio of length to width? Express your answer as a decimal.
4. A rectangle has length 13 cm and width 8 cm. What is the ratio of length to width? Express your answer as a decimal rounded to four places.
5. A rectangle has length 21 cm and width 13 cm. What is the ratio of length to width? Express your answer as a decimal rounded to four places.

### Teacher's Notes

**Common Misconception**: Students sometimes confuse "ratio" with "difference." The ratio of 8 to 4 is 2 (because 8 ÷ 4 = 2), not 4 (because 8 - 4 = 4). Emphasize that a ratio is a *multiplicative* comparison, not an *additive* one.

**Scaffolding**: If students struggle with the concept of ratio, start with physical objects. Line up 6 blocks and 3 blocks. Ask: "how many times as many blocks are in the first group compared to the second?" The answer is 2.

**Extension**: Ask students to measure the length and width of their desk, their textbook, and a sheet of paper. Compute the ratio for each. Do any of these ratios come close to 1.618?

---

## Lesson 1.2: The Golden Ratio in Nature

### Explanation

In the previous lesson, you computed the ratios of length to width for several rectangles:

| Rectangle | Ratio |
|-----------|-------|
| 8 × 4 | 2.0000 |
| 6 × 4 | 1.5000 |
| 5 × 3 | 1.6667 |
| 13 × 8 | 1.6250 |
| 21 × 13 | 1.6154 |

Notice something remarkable: as the numbers get larger, the ratio gets closer and closer to a specific value. That value is approximately 1.6180339887... and it is called the **golden ratio**, denoted by the Greek letter φ (phi).

The golden ratio is defined by a specific property. A rectangle has the golden ratio if, when you remove a square from it, the remaining rectangle has the same ratio as the original.

Let us see why this works. Suppose we have a golden rectangle with length L and width W, where L/W = φ. If we remove a W × W square, the remaining rectangle has length W and width L - W. For this remaining rectangle to also be golden, we need:

W / (L - W) = L / W = φ

This gives us the equation:

W² = L × (L - W)

W² = L² - L × W

Rearranging:

L² - L × W - W² = 0

Dividing both sides by W²:

(L/W)² - (L/W) - 1 = 0

Let φ = L/W. Then:

φ² - φ - 1 = 0

This is the **golden ratio equation**. Using the quadratic formula:

φ = (1 + √5) / 2 ≈ 1.6180339887...

(The other solution is negative, so we discard it.)

**Key Concept**: The golden ratio is the positive solution of the equation φ² = φ + 1.

### The Golden Ratio in Nature

The golden ratio appears in nature with extraordinary frequency. Here are some of the most striking examples:

**1. Sunflower Spirals**

A sunflower head contains two sets of spirals: one set turning clockwise, the other counterclockwise. The number of spirals in each direction is almost always a pair of consecutive Fibonacci numbers: 34 and 55, or 55 and 89, or 89 and 144. The ratio of consecutive Fibonacci numbers approaches φ.

**2. Leaf Arrangements (Phyllotaxis)**

Leaves on a stem are arranged so that each leaf gets maximum sunlight. The angle between consecutive leaves is often close to 137.5°, which is the **golden angle** — 360° × (1 - 1/φ) ≈ 137.5077...°

**3. Shell Spirals**

The nautilus shell grows in a spiral called the **golden spiral**, which is related to the golden ratio. Each chamber of the shell is approximately φ times larger than the previous one.

**4. Branching Patterns**

Trees branch in patterns that approximate the golden ratio. The main trunk divides into two branches. One branch is roughly φ times thicker than the other. This pattern repeats at each level of branching.

**5. The Human Body**

The proportions of the human body approximate the golden ratio. The ratio of the total height to the height of the navel is close to φ. The ratio of the forearm to the hand is close to φ. The ratio of the face width to face height is close to φ.

### Worked Example 1.2.1

A sunflower has 34 spirals turning clockwise and 55 spirals turning counterclockwise. What is the ratio of the larger to the smaller number of spirals?

**Solution**: 55/34 ≈ 1.6176...

This is very close to φ ≈ 1.6180...

### Worked Example 1.2.2

A nautilus shell has 8 chambers in one complete turn and 13 chambers in the next complete turn. What is the ratio of the larger to the smaller number of chambers?

**Solution**: 13/8 = 1.625

Again, this is close to φ ≈ 1.6180...

### Practice Problems

1. A sunflower has 21 spirals clockwise and 34 spirals counterclockwise. What is the ratio of the larger to the smaller? How close is this to φ?
2. A pinecone has 8 spirals in one direction and 13 in the other. What is the ratio? How close is this to φ?
3. A pineapple has 8 spirals, 13 spirals, and 21 spirals in three different directions. Compute the ratios of consecutive spiral counts. What do you notice?
4. Measure the distance from your shoulder to your elbow and from your elbow to your wrist. Compute the ratio. How close is it to φ?
5. Measure the width and height of your face (from hairline to chin). Compute the ratio. How close is it to φ?

### Teacher's Notes

**Classroom Activity**: Bring a sunflower, a pinecone, and a pineapple to class. Have students count the spirals and compute the ratios. This is a tactile, memorable activity that makes the mathematics concrete.

**Common Misconception**: Students sometimes think the golden ratio is "exactly" 1.618. Emphasize that φ is irrational — it goes on forever without repeating. 1.618 is an approximation.

**Cross-Curricular Connection**: Connect this lesson to biology (phyllotaxis, leaf arrangement), art (the golden ratio in painting and sculpture), and architecture (the golden ratio in building design).

---

## Lesson 1.3: Phi-Addition

### Explanation

One of the most remarkable properties of the golden ratio is that it is **self-replicating under addition**. This means:

φ + 1 = φ²

Let us verify this. We know φ = (1 + √5)/2. So:

φ + 1 = (1 + √5)/2 + 1 = (1 + √5 + 2)/2 = (3 + √5)/2

And:

φ² = ((1 + √5)/2)² = (1 + 2√5 + 5)/4 = (6 + 2√5)/4 = (3 + √5)/2

So φ + 1 = φ². This is remarkable because it means that adding 1 to φ is the same as squaring φ.

This property can be extended. What happens if we add φ to φ²?

φ + φ² = φ + (φ + 1) = 2φ + 1

And what is 2φ + 1? Let us compute:

2φ + 1 = 2 × (1 + √5)/2 + 1 = (1 + √5) + 1 = 2 + √5

And what is φ³?

φ³ = φ × φ² = φ × (φ + 1) = φ² + φ = (φ + 1) + φ = 2φ + 1 = 2 + √5

So φ + φ² = φ³.

**Key Concept**: φⁿ = φⁿ⁻¹ + φⁿ⁻² for all n ≥ 2.

This is the defining property of the golden ratio: each power of φ is the sum of the two preceding powers.

### The Fibonacci Connection

This property connects the golden ratio to the Fibonacci sequence. The Fibonacci sequence is:

1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, ...

Each number is the sum of the two preceding numbers. This is exactly the same rule that governs the powers of φ.

In fact, there is a beautiful formula (Binet's formula) that connects the Fibonacci numbers to the golden ratio:

F(n) = (φⁿ - ψⁿ) / √5

where ψ = (1 - √5)/2 ≈ -0.6180339887... is the "conjugate" of φ.

We will study this formula in detail in Chapter 5.

### Worked Example 1.3.1

Compute φ³ using the property φ² = φ + 1.

**Solution**: φ³ = φ × φ² = φ × (φ + 1) = φ² + φ = (φ + 1) + φ = 2φ + 1.

Numerically: 2 × 1.6180339887 + 1 = 3.2360679774 + 1 = 4.2360679774.

We can verify: φ³ = 1.6180339887³ ≈ 4.2360679774. ✓

### Worked Example 1.3.2

Compute φ⁴ using the property φⁿ = φⁿ⁻¹ + φⁿ⁻².

**Solution**: φ⁴ = φ³ + φ² = (2φ + 1) + (φ + 1) = 3φ + 2.

Numerically: 3 × 1.6180339887 + 2 = 4.8541019661 + 2 = 6.8541019661.

We can verify: φ⁴ = 1.6180339887⁴ ≈ 6.8541019661. ✓

### Worked Example 1.3.3

Compute φ⁵ using the same property.

**Solution**: φ⁵ = φ⁴ + φ³ = (3φ + 2) + (2φ + 1) = 5φ + 3.

Numerically: 5 × 1.6180339887 + 3 = 8.0901699435 + 3 = 11.0901699435.

We can verify: φ⁵ = 1.6180339887⁵ ≈ 11.0901699435. ✓

**Observation**: Notice that the coefficients in these expressions are Fibonacci numbers!

- φ² = 1φ + 1
- φ³ = 2φ + 1
- φ⁴ = 3φ + 2
- φ⁵ = 5φ + 3

The coefficients are 1,1, 2,1, 3,2, 5,3... — pairs of consecutive Fibonacci numbers!

### Practice Problems

1. Compute φ⁶ using the property φⁿ = φⁿ⁻¹ + φⁿ⁻². Express your answer in the form aφ + b.
2. Compute φ⁷ using the same property.
3. Verify that φ⁶ = 8φ + 5 by computing numerically.
4. What are the coefficients of φ⁸ in the form aφ + b? (Hint: they are Fibonacci numbers.)
5. Prove that φⁿ = F(n)φ + F(n-1), where F(n) is the nth Fibonacci number. (Hint: use induction.)

### Teacher's Notes

**Deep Insight**: The fact that φⁿ = F(n)φ + F(n-1) is one of the most beautiful identities in mathematics. It connects the golden ratio (an irrational number) to the Fibonacci sequence (a sequence of whole numbers) in a completely unexpected way.

**Common Misconception**: Students sometimes think φⁿ grows like φ × n (linear growth). In fact, φⁿ grows exponentially. φ¹⁰ ≈ 122.99, φ²⁰ ≈ 15,127, φ³⁰ ≈ 1,860,498.

**Extension**: Ask students to compute φⁿ for n = 1 through n = 10 and record the results. Then compute F(n) for n = 1 through n = 10. Compare the ratios φⁿ/F(n). What do they approach?

---

## Lesson 1.4: Phi-Multiplication

### Explanation

We have seen that adding 1 to φ gives φ². What happens when we multiply φ by itself?

φ × φ = φ² = φ + 1 ≈ 2.6180339887...

What about dividing by φ?

1/φ = φ - 1 ≈ 0.6180339887...

This is remarkable. The reciprocal of φ is exactly φ - 1. In other words:

1/φ = φ - 1

This can be rewritten as:

φ × (φ - 1) = 1

or:

φ² - φ = 1

which is just the golden ratio equation φ² - φ - 1 = 0 rearranged.

**Key Concept**: 1/φ = φ - 1 ≈ 0.6180339887...

This means that φ and 1/φ are related in a very special way: 1/φ = φ - 1. No other positive number has this property.

### Powers of φ and Their Reciprocals

Since 1/φ = φ - 1, we can compute powers of 1/φ:

- 1/φ = φ - 1 ≈ 0.6180339887
- 1/φ² = (φ - 1)² = φ² - 2φ + 1 = (φ + 1) - 2φ + 1 = 2 - φ ≈ 0.3819660113
- 1/φ³ = 1/φ × 1/φ² = (φ - 1)(2 - φ) = 2φ - φ² - 2 + φ = 3φ - (φ + 1) - 2 = 2φ - 3

Wait, let us recompute more carefully.

1/φ³ = 1/φ × 1/φ²

We know 1/φ = φ - 1 and 1/φ² = 2 - φ. So:

1/φ³ = (φ - 1)(2 - φ) = 2φ - φ² - 2 + φ = 3φ - φ² - 2

Since φ² = φ + 1:

1/φ³ = 3φ - (φ + 1) - 2 = 3φ - φ - 1 - 2 = 2φ - 3

Numerically: 2 × 1.6180339887 - 3 = 3.2360679774 - 3 = 0.2360679774.

**Key Concept**: The powers of 1/φ decrease geometrically: each power is approximately 0.618 times the previous one.

### Multiplication by φ in Geometry

When we multiply a length by φ, we get a new length that is φ times as large. In geometry, this operation is called **golden dilation**.

If we have a line segment of length 1 and multiply it by φ, we get a segment of length φ ≈ 1.618. If we multiply that by φ again, we get a segment of length φ² ≈ 2.618. And so on.

This is the basis of the **golden rectangle**: a rectangle whose length is φ times its width. If the width is 1, the length is φ. If we remove a 1 × 1 square, the remaining rectangle has width 1 and length φ - 1 = 1/φ. The ratio of length to width of the remaining rectangle is 1 / (1/φ) = φ. So the remaining rectangle is also a golden rectangle!

### Worked Example 1.4.1

A golden rectangle has width 10 cm. What is its length?

**Solution**: Length = φ × width = 1.6180339887 × 10 = 16.180339887 cm.

### Worked Example 1.4.2

A golden rectangle has length 10 cm. What is its width?

**Solution**: Width = length / φ = 10 / 1.6180339887 = 6.180339887 cm.

Alternatively: Width = length × (φ - 1) = 10 × 0.6180339887 = 6.180339887 cm.

### Worked Example 1.4.3

Starting with a square of side 1, we repeatedly multiply one side by φ and keep the other side fixed. What are the dimensions of the resulting rectangles?

**Solution**:
- Start: 1 × 1 square
- After first multiplication: φ × 1 = 1.618 × 1 (golden rectangle)
- After second multiplication: φ × φ = φ² × 1 = 2.618 × 1
- After third multiplication: φ × φ² = φ³ × 1 = 4.236 × 1

But this is not quite right. Let us think more carefully.

Starting with a 1 × 1 square, we form a golden rectangle by extending one side to length φ. So we have a φ × 1 rectangle. Now we remove a 1 × 1 square, leaving a 1 × (φ - 1) = 1 × 1/φ rectangle. This remaining rectangle is also golden (in the other orientation).

If we now remove a (1/φ) × (1/φ) square from this rectangle, we are left with a (1 - 1/φ) × (1/φ) = (1/φ²) × (1/φ) rectangle. This is also golden.

This process continues indefinitely, producing an infinite sequence of golden rectangles nested inside each other.

### Practice Problems

1. A golden rectangle has width 15 cm. What is its length? Round to two decimal places.
2. A golden rectangle has length 20 cm. What is its width? Round to two decimal places.
3. Compute 1/φ to six decimal places.
4. Compute 1/φ² to six decimal places.
5. Verify that φ × (φ - 1) = 1 by computing both sides numerically.

### Teacher's Notes

**Physical Activity**: Have students construct a golden rectangle using a ruler and compass. Start with a 10 cm square. Extend one side to 16.18 cm. The resulting rectangle is golden. Then remove a 10 × 10 cm square and verify that the remaining rectangle is also golden.

**Key Insight**: The property 1/φ = φ - 1 means that φ is the only positive number whose reciprocal is exactly 1 less than itself. This is a defining characteristic of the golden ratio.

**Historical Note**: The ancient Greeks called the golden ratio "extreme and mean ratio." They considered it the most aesthetically pleasing ratio, and used it extensively in architecture and art.

---

## Lesson 1.5: The Golden Rectangle

### Explanation

A **golden rectangle** is a rectangle whose length-to-width ratio is the golden ratio φ. In other words, if the width is W, the length is φW.

The golden rectangle has many remarkable properties:

**Property 1: Self-Similarity**

If you remove a square from a golden rectangle, the remaining rectangle is also golden. This process can be repeated indefinitely, producing an infinite sequence of golden rectangles nested inside each other.

**Property 2: The Golden Spiral**

If you draw a quarter-circle arc in each square that you remove, the arcs form a smooth spiral called the **golden spiral**. This spiral is a special case of a **logarithmic spiral**, and it appears frequently in nature.

**Property 3: Decomposition into Golden Triangles**

A golden rectangle can be divided into two golden triangles and a square. A golden triangle is an isosceles triangle whose sides are in the golden ratio.

**Property 4: Tiling**

Golden rectangles can tile the plane in certain patterns, related to **Penrose tilings**. These tilings have five-fold symmetry, which is impossible with regular polygons alone.

### Constructing a Golden Rectangle

There are several ways to construct a golden rectangle. Here is the simplest:

1. Start with a square of side length s.
2. Find the midpoint of one side.
3. Draw a line from this midpoint to an opposite corner.
4. Use a compass to transfer this distance to the base of the square.
5. Extend the base to this point. The resulting rectangle is golden.

Let us verify this construction. The square has side s. The midpoint of one side is at distance s/2 from the corner. The line from this midpoint to the opposite corner has length:

√(s² + (s/2)²) = √(s² + s²/4) = √(5s²/4) = s√5/2

When we transfer this distance to the base, the total length of the base becomes:

s + s√5/2 = s(1 + √5/2) = s(2 + √5)/2

Wait, that does not look right. Let me redo this.

Actually, the standard construction is:

1. Start with a square ABCD with side s.
2. Let M be the midpoint of side AB.
3. Draw the diagonal MC.
4. With center M and radius MC, draw an arc that intersects the extension of AB at point E.
5. Rectangle AECD is golden.

Let us verify. The square has vertices A(0,0), B(s,0), C(s,s), D(0,s). M is at (s/2, 0).

The distance MC is:

MC = √((s - s/2)² + (s - 0)²) = √(s²/4 + s²) = √(5s²/4) = s√5/2

The arc has center M(s/2, 0) and radius s√5/2. It intersects the extension of AB (the x-axis) at:

E = (s/2 + s√5/2, 0) = (s(1 + √5)/2, 0) = (sφ, 0)

So AE = sφ and AD = s. The ratio AE/AD = sφ/s = φ. ✓

### The Golden Spiral

The golden spiral is created by drawing quarter-circle arcs in the squares of a golden rectangle decomposition.

Start with a golden rectangle of dimensions φ × 1.
1. Remove a 1 × 1 square. Draw a quarter-circle arc in this square.
2. The remaining rectangle has dimensions 1 × (φ-1) = 1 × 1/φ. This is also golden.
3. Remove a (1/φ) × (1/φ) square. Draw a quarter-circle arc.
4. Continue indefinitely.

The result is a smooth spiral that gets wider by a factor of φ for every quarter turn. This spiral is self-similar: if you zoom in or out by a factor of φ, the spiral looks the same.

### Worked Example 1.5.1

A golden rectangle has width 10 cm. What is the area of the largest square that can be removed from it?

**Solution**: The largest square that can be removed has side equal to the width of the rectangle, which is 10 cm. So the area of the square is 10² = 100 cm².

The area of the golden rectangle is 10 × 10φ = 10 × 16.18 = 161.8 cm².
The area of the remaining rectangle is 161.8 - 100 = 61.8 cm².
The ratio of the remaining area to the original area is 61.8/161.8 = 1/φ² ≈ 0.382.

### Worked Example 1.5.2

What is the equation of the golden spiral in polar coordinates?

**Solution**: The golden spiral is a logarithmic spiral with the equation:

r = a × φ^(2θ/π)

where a is a constant that determines the starting radius, and θ is the angle in radians.

For every quarter turn (θ increases by π/2), the radius increases by a factor of φ:

r(θ + π/2) = a × φ^(2(θ + π/2)/π) = a × φ^(2θ/π + 1) = φ × a × φ^(2θ/π) = φ × r(θ)

This confirms that the golden spiral grows by a factor of φ for every quarter turn.

### Practice Problems

1. Construct a golden rectangle starting with a 6 cm square. What are the dimensions of the golden rectangle?
2. A golden rectangle has area 100 cm². What are its dimensions?
3. What fraction of a golden rectangle's area is removed when you take out the first square?
4. A golden spiral starts with radius 1 cm. What is its radius after one complete turn (360°)?
5. A golden spiral has equation r = φ^(2θ/π). What is r when θ = π/4 (one eighth turn)?

### Teacher's Notes

**Construction Activity**: The compass-and-straightedge construction of the golden rectangle is one of the most satisfying geometric constructions. Give each student a piece of paper, a ruler, and a compass. Walk them through the construction step by step. When they see the golden rectangle emerge from a simple square, it is a memorable moment.

**Art Connection**: Many artists have used the golden rectangle as a compositional tool. Show students examples from Mondrian, Seurat, and Le Corbusier. Ask them to identify the golden rectangles in these artworks.

**Nature Connection**: Show photographs of nautilus shells, hurricanes, and spiral galaxies. Point out that all of these are approximately logarithmic spirals, and some are close to golden spirals.

**Assessment**: A good assessment for this chapter is to ask students to: (1) define the golden ratio, (2) explain the property φ² = φ + 1, (3) construct a golden rectangle, and (4) identify three examples of the golden ratio in nature.

---

## Summary of Chapter 1

### Key Concepts

1. A **ratio** is a comparison of two quantities, expressed as a single number.
2. The **golden ratio** φ = (1 + √5)/2 ≈ 1.6180339887... is the positive solution of φ² = φ + 1.
3. The golden ratio is **self-replicating**: φ + 1 = φ².
4. The **reciprocal** of φ is φ - 1: 1/φ = φ - 1 ≈ 0.6180339887...
5. A **golden rectangle** has length-to-width ratio of φ.
6. Removing a square from a golden rectangle leaves another golden rectangle.
7. The **golden spiral** is formed by drawing arcs in the squares of a golden rectangle decomposition.
8. The golden ratio appears in nature: sunflower spirals, leaf arrangements, shell spirals, branching patterns, and human proportions.

### Key Formulas

| Formula | Description |
|---------|-------------|
| φ = (1 + √5)/2 | Definition of the golden ratio |
| φ² = φ + 1 | Fundamental property |
| 1/φ = φ - 1 | Reciprocal property |
| φⁿ = φⁿ⁻¹ + φⁿ⁻² | Recursive property of powers |
| φⁿ = F(n)φ + F(n-1) | Connection to Fibonacci numbers |
| Golden angle = 360°/φ² ≈ 137.5° | Angle used in phyllotaxis |
| r = a × φ^(2θ/π) | Equation of the golden spiral |

### Connections to Other Chapters

- **Chapter 5 (Fibonacci and Lucas Numbers)**: The Fibonacci sequence is intimately connected to the golden ratio through Binet's formula.
- **Chapter 7 (Padovan and Kepler Ratios)**: The Kepler triangle is a right triangle whose sides are in geometric progression with ratio φ.
- **Chapter 8 (Living Mathematics)**: Phyllotaxis uses the golden angle to arrange leaves and seeds.
- **Chapter 9 (Phi-Statistics and Phi-Geometry)**: The golden ratio appears in Penrose tilings and phi-statistics.
- **Chapter 10 (Phi-Chemistry and Phi-Physics)**: Quasicrystals use five-fold symmetry based on the golden ratio.
- **Chapter 11 (Phi-Biology and Phi-Medicine)**: DNA and neural oscillations use the golden ratio.
- **Chapter 12 (Phi-Economics and Phi-CS)**: Fibonacci trading and golden ratio search algorithms.

---

## Lesson 1.6: The Golden Ratio and Continued Fractions

### Explanation

The golden ratio has the simplest continued fraction representation of any irrational number. This is why it is called the "most irrational" number.

### What Is a Continued Fraction?

A **continued fraction** is an expression of the form:

a₀ + 1/(a₁ + 1/(a₂ + 1/(a₃ + ...)))

where a₀, a₁, a₂, a₃, ... are integers.

Every rational number has a finite continued fraction. Every irrational number has an infinite continued fraction.

### The Continued Fraction of the Golden Ratio

The golden ratio has the continued fraction:

φ = 1 + 1/(1 + 1/(1 + 1/(1 + ...)))

All the partial quotients are 1. This is the simplest possible infinite continued fraction.

The convergents (partial sums) are ratios of consecutive Fibonacci numbers:

1/1, 2/1, 3/2, 5/3, 8/5, 13/8, 21/13, ...

These are the worst possible rational approximations, which is why φ is the "most irrational" number.

### Worked Example 1.6.1

Compute the first 6 convergents of the continued fraction for φ.

**Solution**: 
Convergent 1: 1
Convergent 2: 1 + 1/1 = 2
Convergent 3: 1 + 1/(1 + 1/1) = 3/2 = 1.5
Convergent 4: 5/3 ≈ 1.6667
Convergent 5: 8/5 = 1.6
Convergent 6: 13/8 = 1.625

These converge to φ ≈ 1.618.

### Practice Problems

1. Compute the first 8 convergents of the continued fraction for φ.
2. Verify that the convergents are ratios of consecutive Fibonacci numbers.
3. Why is φ called the "most irrational" number?
4. Compute the continued fraction for √2. How does it differ from φ?
5. What is the continued fraction for e (Euler's number)?

### Teacher's Notes

**Number Theory Connection**: Continued fractions are a deep topic in number theory. The fact that φ has the simplest continued fraction is a beautiful result.

**Extension**: Ask students to prove that the convergents of the continued fraction for φ are ratios of consecutive Fibonacci numbers.

---

**End of Chapter 1**

*Next: Chapter 2 — The Silver Ratio*
