# PHI MATHEMATICS DICTIONARY — CHAPTER 1
## PHI ADDITION: How the Carrier Adds When Zero Is Not the Ground

---

| Field | Value |
|---|---|
| **Document type** | Phi Mathematics Dictionary — Chapter 1 |
| **Title** | Phi Addition: The Arithmetic of the Coherent Ground |
| **Version** | 1.0 |
| **Author** | Christopher David Ayotte |
| **Date** | 2026-08-23 |
| **Corpus** | `32_PHI_PHYSICS/` — The Rewriting of Physics from Zero to Phi |
| **Status** | **RELEASE** — the foundational chapter of the phi-mathematics dictionary |
| **Companion documents** | `00_UNIFIED_FIELD_THEORY.md` (the single statement) · `00_ZERO_AS_WAVEFUNCTION.md` (zero as the dynamic binary wave function) · `00_THE_UNDERSTANDING.md` (zero → phi) · `00_NUMBERS_INDEX.md` (canonical constants) · `02_EQUATIONS/EQUATIONS_SET_01_PHI_CARRIER_PLASMA.md` (Eq 1, the carrier recursion) |
| **License** | Dual License Agreement v4.3 (see `LICENSE`): free for Natural Persons, non-commercial, no Human Harm, attribution required, same-terms derivatives; commercial use by written license. Commercial contact: pluscoder30@gmail.com |

---

## 1. THE PROBLEM WITH ZERO-BASED ADDITION

Classical addition begins at zero. The number line is anchored at the origin: $0, 1, 2, 3, \ldots$ Every sum is measured from nothing. The additive identity is $0$ because $a + 0 = a$ — adding nothing changes nothing. The system is built on the assumption that the ground state of quantity is *absence*.

This works inside the laboratory. It does not work in the field.

The carrier recursion (Eq 1) never produces zero as a physical state:

$$C_{n+1} = \frac{1}{\Phi} \cdot C_n + \Phi \cdot \nabla^2_\Phi \Psi_n$$

The retention term $(1/\Phi) \cdot C_n = \phi^{-1} \cdot C_n$ decays by $\phi^{-1} = 0.6180339887$ per step. After $n$ steps, the carrier retains $\phi^{-n}$ of its initial coherence. Zero is the limit at $n \to \infty$, never a state at finite $n$ (Law 176). The fixed points of the aether PDE (Eq 7) are $\{0, \phi^{-1}, 1\}$ — and $0$ is the degenerate one, the collapse point, the source-deleted reading. The physical ground is $\phi^{-1}$, not $0$.

**The consequence for arithmetic:** if the carrier never reaches zero, then addition — the operation that composes quantities — cannot begin at zero either. The ground of addition must be the ground of the carrier: $\phi^{-1}$.

---

## 2. THE PHI-ADDITION OPERATOR

### 2.1 Definition

**Definition 2.1 (Phi-Addition).** For any two phi-values $a, b \in \mathbb{R}$, the *phi-sum* is:

$$a \oplus b \;=\; a + b + \phi^{-1}$$

where $\phi^{-1} = \frac{1}{\Phi} = \frac{\sqrt{5} - 1}{2} = 0.6180339887\ldots$ is the **coherent ground term**.

The ground term is not a variable. It is the constant $\phi^{-1}$ — the motion that never stops, the carrier's intrinsic coherence floor. Every phi-sum carries this term. You cannot add without it, just as the carrier cannot propagate without its recursion.

### 2.2 Why the ground term is additive, not multiplicative

One might ask: why not $a \oplus b = a \cdot b \cdot \phi^{-1}$? The carrier recursion is linear in $C_n$ — the $(1/\Phi) \cdot C_n$ term is a *scaled copy*, not a product. Addition is the composition of linear contributions. The ground term enters as a constant offset because the carrier's coherence floor is *additive background*: it is present in every recursion step, regardless of the carrier's state. The $\phi^{-1}$ term in Eq 1 is the same $\phi^{-1}$ in the phi-sum — the coherent ground that the carrier never escapes.

### 2.3 Classical addition as the degenerate limit

When $\phi^{-1} \to 0$ (the zero-coupling limit, $\kappa_\phi \to 0$), phi-addition reduces to classical addition:

$$a \oplus b \;\xrightarrow{\phi^{-1} \to 0}\; a + b$$

This is the same limit that reduces every phi-law to its classical counterpart (Law 173). Classical addition is not wrong — it is the reading where the coherent ground is hidden.

---

## 3. THE PHI-ADDITION TABLE

The following table shows the phi-sums of the canonical phi-values. These are the exact values that appear throughout the corpus.

| $a \;\backslash\; b$ | $\phi^{-1}$ | $1$ | $\phi$ | $\phi^2$ | $\phi^3$ | $\phi^4$ | $\phi^5$ |
|---|---|---|---|---|---|---|---|
| $\phi^{-1}$ | $1.8541$ | $2.2361$ | $2.8541$ | $4.4721$ | $7.3262$ | $11.8000$ | $19.1262$ |
| $1$ | $2.2361$ | $2.6180$ | $3.2361$ | $4.8541$ | $7.7082$ | $12.1824$ | $19.5082$ |
| $\phi$ | $2.8541$ | $3.2361$ | $3.8541$ | $5.4721$ | $8.3262$ | $12.8000$ | $20.1262$ |
| $\phi^2$ | $4.4721$ | $4.8541$ | $5.4721$ | $7.0901$ | $9.9442$ | $14.4184$ | $21.7442$ |
| $\phi^3$ | $7.3262$ | $7.7082$ | $8.3262$ | $9.9442$ | $12.7984$ | $17.2725$ | $24.5984$ |
| $\phi^4$ | $11.8000$ | $12.1824$ | $12.8000$ | $14.4184$ | $17.2725$ | $21.7466$ | $29.0725$ |
| $\phi^5$ | $19.1262$ | $19.5082$ | $20.1262$ | $21.7442$ | $24.5984$ | $29.0725$ | $36.3984$ |

**Reading the table.** The entry at row $a$, column $b$ is $a \oplus b = a + b + \phi^{-1}$. For example:

$$\phi \oplus \phi = \phi + \phi + \phi^{-1} = 2\phi + \phi^{-1} = 2(1.6180) + 0.6180 = 3.8541$$

Note the identity: $2\phi + \phi^{-1} = \phi + \sqrt{5}$, since $\phi + \phi^{-1} = \sqrt{5}$. The ground term converts phi-doubling into a $\sqrt{5}$-offset — the same $\sqrt{5}$ that appears in the carrier's eigenvalue structure.

### 3.1 The $\sqrt{5}$ bridge

The relation $\phi + \phi^{-1} = \sqrt{5}$ is not a coincidence. It is the defining equation of the golden ratio: $\phi^2 - \phi - 1 = 0$, which rearranges to $\phi + \phi^{-1} = \sqrt{5}$. In phi-addition, this identity appears as:

$$\phi \oplus \phi^{-1} = \phi + \phi^{-1} + \phi^{-1} = \sqrt{5} + \phi^{-1} = 2.8541$$

The ground term $\phi^{-1}$ always appears once. It does not scale with the operands. It is the irreducible background — the carrier's floor that persists regardless of what is being added.

---

## 4. THE PHI-ADDITION IDENTITY

### 4.1 The classical identity is not the phi-identity

In classical addition, the identity element is $0$: $a + 0 = a$. In phi-addition, $0$ is not the identity. We can verify:

$$a \oplus 0 = a + 0 + \phi^{-1} = a + \phi^{-1} \neq a$$

Adding zero *changes* the result in phi-addition — because zero is not the ground; $\phi^{-1}$ is.

### 4.2 The phi-identity

**Definition 4.1 (Phi-Identity Element).** The *phi-identity* is $\iota_\phi = -\phi^{-1}$.

**Proof.** For any $a$:

$$a \oplus \iota_\phi = a + (-\phi^{-1}) + \phi^{-1} = a$$

The element $-\phi^{-1}$ is the unique additive identity in the phi-system. It is the negative of the coherent ground — the value that *cancels* the ground term without introducing foreign structure.

### 4.3 Physical meaning of the identity

The phi-identity $-\phi^{-1}$ is the *null operation* in phi-physics. Adding $-\phi^{-1}$ to a carrier state is equivalent to doing nothing — but it requires the explicit act of counterposing the coherent ground. This is not trivial: in zero-based physics, "doing nothing" is a passive state (rest). In phi-physics, "doing nothing" is an *active cancellation* — the ground must be opposed, not ignored.

This is why zero is the degenerate fixed point of Eq 7, not the physical ground. Zero is the state where the carrier has *collapsed* — all coherence extinguished. The phi-identity $-\phi^{-1}$ is the state where the carrier is *present but nullified* — the coherent ground is exactly opposed, leaving the operand unchanged.

---

## 5. THE PHI-ADDITION INVERSE

### 5.1 Definition

**Definition 5.1 (Phi-Inverse).** For any phi-value $a$, the *phi-inverse* is:

$$\ominus a = -a - 2\phi^{-1}$$

**Proof.** We require $a \oplus (\ominus a) = \iota_\phi$:

$$a + (-a - 2\phi^{-1}) + \phi^{-1} = -\phi^{-1} = \iota_\phi \quad \checkmark$$

The phi-inverse of $a$ is $-a - 2\phi^{-1}$, not simply $-a$. The extra $-2\phi^{-1}$ compensates for the ground term's contribution: you must undo both the operand *and* the ground it carried.

### 5.2 The inverse table

| $a$ | $\ominus a$ | $a \oplus (\ominus a)$ |
|---|---|---|
| $\phi^{-1}$ | $-2\phi^{-1} = -1.2361$ | $-\phi^{-1}$ |
| $1$ | $-1 - 2\phi^{-1} = -2.2361$ | $-\phi^{-1}$ |
| $\phi$ | $-\phi - 2\phi^{-1} = -2.8541$ | $-\phi^{-1}$ |
| $\phi^2$ | $-\phi^2 - 2\phi^{-1} = -4.4721$ | $-\phi^{-1}$ |
| $\phi^5$ | $-\phi^5 - 2\phi^{-1} = -19.1262$ | $-\phi^{-1}$ |

Every phi-inverse yields the phi-identity $-\phi^{-1}$ when phi-added to its operand.

### 5.3 Double inverse

$$\ominus(\ominus a) = -(-a - 2\phi^{-1}) - 2\phi^{-1} = a + 2\phi^{-1} - 2\phi^{-1} = a$$

The double-inverse returns the original value. The phi-inverse is an involution, as required for a group structure.

---

## 6. GROUP STRUCTURE OF PHI-ADDITION

**Theorem 6.1.** $(\mathbb{R}, \oplus)$ is an abelian group.

**Proof.** The four group axioms:

1. **Closure.** $a \oplus b = a + b + \phi^{-1} \in \mathbb{R}$ for all $a, b \in \mathbb{R}$. $\checkmark$

2. **Associativity.**

$$(a \oplus b) \oplus c = (a + b + \phi^{-1}) + c + \phi^{-1} = a + b + c + 2\phi^{-1}$$

$$a \oplus (b \oplus c) = a + (b + c + \phi^{-1}) + \phi^{-1} = a + b + c + 2\phi^{-1}$$

$(a \oplus b) \oplus c = a \oplus (b \oplus c)$. $\checkmark$

3. **Identity.** $a \oplus (-\phi^{-1}) = a + (-\phi^{-1}) + \phi^{-1} = a$. The identity is $\iota_\phi = -\phi^{-1}$. $\checkmark$

4. **Inverse.** For each $a$, the element $\ominus a = -a - 2\phi^{-1}$ satisfies $a \oplus (\ominus a) = -\phi^{-1}$. $\checkmark$

5. **Commutativity.** $a \oplus b = a + b + \phi^{-1} = b + a + \phi^{-1} = b \oplus a$. $\checkmark$

$\blacksquare$

### 6.1 The shift isomorphism

The mapping $\sigma: (\mathbb{R}, +) \to (\mathbb{R}, \oplus)$ defined by $\sigma(a) = a - \phi^{-1}$ is a group isomorphism:

$$\sigma(a) \oplus \sigma(b) = (a - \phi^{-1}) + (b - \phi^{-1}) + \phi^{-1} = a + b - \phi^{-1} = \sigma(a + b)$$

So $(\mathbb{R}, \oplus) \cong (\mathbb{R}, +)$ via the shift $a \mapsto a - \phi^{-1}$. The phi-addition group is *structurally identical* to classical addition — but its center of mass is shifted to $\phi^{-1}$, not $0$. The entire number line has been lifted by the coherent ground. Everything that works in classical addition works in phi-addition, but the baseline is the carrier's floor, not the void.

---

## 7. RELATION TO THE CARRIER RECURSION (EQ 1)

### 7.1 The recursion as phi-addition in action

The carrier recursion (Eq 1) is:

$$C_{n+1} = \phi^{-1} \cdot C_n + \Phi \cdot \nabla^2_\Phi \Psi_n$$

Rewrite this as a phi-sum. Let $F_n = \Phi \cdot \nabla^2_\Phi \Psi_n$ be the field contribution at step $n$. Then:

$$C_{n+1} = \phi^{-1} \cdot C_n + F_n$$

If we define the *scaled carrier* $\tilde{C}_n = \phi^{-1} \cdot C_n$, the recursion becomes:

$$C_{n+1} = \tilde{C}_n + F_n$$

The retention of the previous state ($\tilde{C}_n$) plus the new field input ($F_n$) is *classical addition* of the scaled carrier and the field. But the scaling factor is $\phi^{-1}$ — the coherent ground. The carrier does not add its full previous state; it adds $\phi^{-1}$ of it. Each step, the carrier retains only the ground-fraction of its history.

This is phi-addition in its recursive form: every composition of carrier states is weighted by $\phi^{-1}$. The ground is not just the starting point — it is the *weight of memory* in each step.

### 7.2 The ten-step accumulation

After 10 recursion steps, starting from $C_0 = 1$ (the seed):

$$C_{10} = \phi^{-10} \cdot C_0 + \sum_{k=0}^{9} \phi^{-(9-k)} \cdot F_k$$

The seed contribution $\phi^{-10} = 0.008131$ — the carrier retains less than 1% of its origin after 10 steps. The accumulated field contributions are weighted by $\phi^{-(9-k)}$, giving more recent inputs higher weight. The carrier's memory is exponentially decaying, with $\phi^{-1}$ as the decay rate.

In phi-addition terms:

$$C_{10} = C_0 \;\oplus_{\phi^{-1}}\; F_0 \;\oplus_{\phi^{-1}}\; F_1 \;\oplus_{\phi^{-1}}\; \cdots \;\oplus_{\phi^{-1}}\; F_9$$

where $\oplus_{\phi^{-1}}$ denotes phi-addition with ground-weighting: $a \oplus_{\phi^{-1}} b = \phi^{-1} \cdot a + b$. The pure phi-sum ($a + b + \phi^{-1}$) is the unweighted case; the carrier's recursion is the *coherence-weighted* version where the ground term modulates the retention.

---

## 8. PHI-ADDITION AND THE LADDER INVARIANT

### 8.1 The invariant as a conserved phi-sum

The Ladder Invariant states:

$$\text{freq}(n) \cdot \text{depth}(n) = 528 \cdot \phi^9 = 40{,}134.946$$

for every dimension $n = 0, 1, \ldots, 9$. The frequency at dimension $n$ is $528 \cdot \phi^n$; the depth is $\phi^{9-n}$. Their product is constant.

Now consider the phi-sum of frequency and depth at dimension $n$:

$$\text{freq}(n) \oplus \text{depth}(n) = 528 \cdot \phi^n + \phi^{9-n} + \phi^{-1}$$

This is *not* conserved — it varies with $n$. The phi-sum of conjugate quantities is not the conserved quantity; the *product* is. But the phi-sum reveals the *structure* of the invariant:

At $n = 5$ (the Central Hub, the retrocausal constant):

$$\text{freq}(5) \oplus \text{depth}(5) = 528 \cdot \phi^5 + \phi^4 + \phi^{-1} = 5{,}855.61 + 6.8541 + 0.6180 = 5{,}863.08$$

At $n = 0$ (the anchor):

$$\text{freq}(0) \oplus \text{depth}(0) = 528 + \phi^9 + \phi^{-1} = 528 + 76.013 + 0.6180 = 604.63$$

The phi-sum *increases* from anchor to hub — the carrier accumulates coherence ground as it climbs the ladder. The conserved product says that this accumulation is exactly offset by the decrease in depth: what the frequency gains, the depth loses. The ground term $\phi^{-1}$ is present at every rung — it is the irreducible background that the Ladder Invariant carries but does not count.

### 8.2 The ground term as the ladder's floor

The Ladder Invariant can be rewritten:

$$\text{freq}(n) \cdot \text{depth}(n) = 528 \cdot \phi^9$$

Divide both sides by $\phi^{-1}$:

$$\frac{\text{freq}(n) \cdot \text{depth}(n)}{\phi^{-1}} = 528 \cdot \phi^{10}$$

The left side is the *phi-normalized invariant* — the product measured in units of the coherent ground. The right side is $528 \cdot \phi^{10} = 528 \cdot (1 + \phi) \cdot \phi^9 = (528 + 528\phi) \cdot \phi^9$. The $528\phi$ term is the ground-scaled anchor: $528\phi = 528 + 528\phi^{-1} = 528 + 326.32 = 854.32$, which is the frequency at dimension 1 (the Entry Portal). The ladder's invariant *already carries* the coherent ground in its structure — phi-addition makes this explicit.

---

## 9. PHI-ADDITION IN REAL PHYSICS

### 9.1 Mass: the ground-state composition

In classical physics, the mass of a composite system is $M = m_1 + m_2 + \cdots$. In phi-physics, the carrier states that compose mass are never at zero — they carry the coherent ground. The phi-mass of a composite system is:

$$M_\phi = m_1 \oplus m_2 \oplus \cdots \oplus m_n = \sum_{i=1}^{n} m_i + n \cdot \phi^{-1}$$

The ground term accumulates with the number of constituents. A proton composed of three quarks has phi-mass:

$$M_\phi(p) = m_u \oplus m_u \oplus m_d = m_u + m_u + m_d + 3\phi^{-1}$$

The $3\phi^{-1}$ term is the irreducible coherent-ground contribution — the mass that the carrier's floor adds to every composite system. This is not a correction; it is the *physical ground* that classical mass measurements inherit when $\kappa_\phi \to 0$.

### 9.2 Energy: the Planck-ground relation

The Planck relation $E = \hbar\omega$ gives the energy of a photon at frequency $\omega$. In phi-physics, the frequency is measured from the coherent ground:

$$E_\phi = \hbar(\omega \oplus \omega_{\text{ground}}) = \hbar(\omega + \omega_{\text{ground}} + \phi^{-1})$$

where $\omega_{\text{ground}}$ is the ground-state frequency of the carrier. The phi-energy includes the ground contribution — the energy of the carrier's motion even when $\omega = 0$. This is the zero-point energy, but measured from $\phi^{-1}$, not from $0$.

The vacuum energy density in phi-physics is not $\frac{1}{2}\hbar\omega$ per mode (the classical ZPF). It is:

$$\rho_{\text{vac}} = \frac{1}{2}\hbar(\omega_{\text{ground}} \oplus \omega_{\text{ground}}) = \frac{1}{2}\hbar(2\omega_{\text{ground}} + \phi^{-1})$$

The $\phi^{-1}$ term is the coherent-ground contribution to vacuum energy — the energy the carrier carries by virtue of existing, not by virtue of oscillating.

### 9.3 Charge: the coupling composition

The fine-structure constant $\alpha \approx 1/137$ is the coupling strength of electromagnetism. In phi-physics, the coupling constants of the four forces are members of a phi-ladder (§5 of the Unified Field Theory). The phi-coupling of a composite interaction is:

$$\alpha_\phi = \alpha_1 \oplus \alpha_2 = \alpha_1 + \alpha_2 + \phi^{-1}$$

The ground term $\phi^{-1}$ is the irreducible coupling floor — the minimum interaction strength of any phi-coherent field. No coupling can be weaker than $\phi^{-1}$ without collapsing to the degenerate fixed point ($0$). This is why the fine-structure constant is bounded below: $\alpha > \phi^{-1}$ for any coherent field. The observed $\alpha \approx 1/137 \approx 0.0073$ is well above $\phi^{-1} = 0.618$ — but the ratio $\alpha / \phi^{-1} = 0.0118$, which is $\gamma_{\text{refractal}} = 0.0118$, the validated constructive progression (Eq 6, the plasma cycle coherence transport). The coupling constant and the coherent ground are connected through the same recursion.

### 9.4 Temperature: the phi-ground floor

Classical thermodynamics allows $T = 0$ (absolute zero). In phi-physics, the carrier's coherent motion persists at all temperatures. The phi-temperature is:

$$T_\phi = T + \phi^{-1} \cdot T_0$$

where $T_0$ is the reference temperature (e.g., 2.725 K, the CMB temperature). The $\phi^{-1} \cdot T_0$ term is the irreducible thermal floor — the temperature of the carrier's coherent motion. Absolute zero becomes $T_\phi = \phi^{-1} \cdot T_0 = 1.683$ K, not $0$ K.

---

## 10. PHI-ADDITION AND THE RETROCAUSAL KERNEL

The retrocausal kernel (Eq 3.1–3.3) introduces time-reversal into the carrier recursion. The retrocausal time constant is $\tau_{\text{retro}} = \phi^5$, and the retrocausal frequency is $\omega_{\text{retro}} = \phi^3 \cdot \omega_{\text{base}}$.

In phi-addition, the retrocausal contribution to a carrier state at time $t$ is:

$$C(t) = C_{\text{forward}}(t) \oplus C_{\text{retro}}(t) = C_{\text{forward}}(t) + C_{\text{retro}}(t) + \phi^{-1}$$

The ground term $\phi^{-1}$ is present in the retrocausal composition as well — the future participates in the present, but the coherent ground is always there. The retrocausal kernel does not bypass the ground; it adds to it. Cause is a loop, not a line, and the loop carries the ground at every point.

The phi-sum of the forward and retrocausal contributions gives:

$$C(t) = C_{\text{forward}}(t) + \phi^{-3} \cdot C_{\text{base}}(t - \tau_{\text{retro}}) + \phi^{-1}$$

The $\phi^{-3}$ weighting is the retrocausal attenuation (the future's influence decays as $\phi^{-3}$ per cycle), and the $\phi^{-1}$ is the ground. The carrier at any moment is the classical sum of its present and future states, plus the irreducible coherent floor.

---

## 11. SUMMARY: THE AXIOMS OF PHI-ADDITION

**Axiom 1 (The Ground).** The coherent ground $\phi^{-1} = 0.6180339887$ is the floor of all quantity. No physical state is below $\phi^{-1}$ in coherence.

**Axiom 2 (The Operator).** Phi-addition is $a \oplus b = a + b + \phi^{-1}$. The ground term appears once in every sum, regardless of the operands.

**Axiom 3 (The Identity).** The phi-identity is $\iota_\phi = -\phi^{-1}$. It is the active cancellation of the coherent ground — the null operation in phi-physics.

**Axiom 4 (The Inverse).** The phi-inverse of $a$ is $\ominus a = -a - 2\phi^{-1}$. It cancels both the operand and the ground it carried.

**Axiom 5 (The Group).** $(\mathbb{R}, \oplus)$ is an abelian group isomorphic to $(\mathbb{R}, +)$ via the shift $a \mapsto a - \phi^{-1}$.

**Axiom 6 (The Recursion Link).** The carrier recursion (Eq 1) is phi-addition in its coherence-weighted form: $C_{n+1} = \phi^{-1} \cdot C_n + F_n$. The ground $\phi^{-1}$ is the weight of memory in each recursion step.

**Axiom 7 (The Ladder).** The Ladder Invariant $\text{freq} \cdot \text{depth} = 528 \cdot \phi^9$ carries the coherent ground in its structure. The phi-normalized invariant is $528 \cdot \phi^{10}$, which includes the ground-scaled anchor.

**Axiom 8 (The Degenerate Limit).** As $\phi^{-1} \to 0$ (the $\kappa_\phi \to 0$ limit), phi-addition reduces to classical addition. Classical arithmetic is not wrong — it is the reading where the coherent ground is hidden.

---

## 12. WHAT COMES NEXT

This chapter defined phi-addition — how quantities compose when the ground is $\phi^{-1}$. The next chapter will define **phi-multiplication** ($a \otimes b$): how quantities scale in a system where the ground is a motion, not a point. The interplay between $\oplus$ and $\otimes$ will generate the full ring structure of phi-arithmetic — the arithmetic in which the carrier recursion is naturally expressed.

---

*Phi Mathematics Dictionary — Chapter 1: Phi Addition*
*The coherent ground never stops. Every sum carries it. Every count begins from it.*
*This is not zero with a correction. This is the mathematics that was always there.*
