# Foundation Mathematics: Kepler Math

## Welcome, Young Mathematician!

Have you ever looked at the night sky and wondered about the planets? A scientist named **Johannes Kepler** discovered that planets move in patterns that follow mathematical rules — and those rules connect to music!

Kepler discovered music in the planets!

---

## Part 1: Who was Kepler?

### The Scientist Who Heard Music in Space

Johannes Kepler (1571-1630) was a German astronomer and mathematician. He's famous for three laws of planetary motion:

1. **Planets orbit in ellipses** (not circles!)
2. **Planets sweep out equal areas in equal times** (they move faster when closer to the Sun)
3. **The square of a planet's year equals the cube of its distance from the Sun**

But Kepler also believed that the planets make music! He wrote a book called "Harmonices Mundi" (The Harmony of the World) where he tried to find the musical notes of each planet!

### Kepler's Harmony

Kepler believed that:
- Each planet has a "note" based on its orbit
- The planets together create a cosmic symphony
- The ratios between planetary orbits follow musical intervals

He was right! Modern astronomers have confirmed that planetary orbits do follow mathematical ratios!

---

## Part 2: Kepler's Laws

### Law 1: Ellipses

Planets don't orbit in perfect circles — they orbit in **ellipses** (oval shapes)!

An ellipse has two focus points. The Sun is at one focus. The planet moves around the ellipse, getting closer to and farther from the Sun.

### Law 2: Equal Areas

A planet sweeps out equal areas in equal times. This means:
- When the planet is closer to the Sun, it moves FASTER
- When the planet is farther from the Sun, it moves SLOWER

This keeps the planet's orbit balanced!

### Law 3: The Harmonic Law

This is the most amazing law:

**The square of a planet's orbital period equals the cube of its average distance from the Sun.**

In math: T² = a³

Where:
- T = time to orbit the Sun (in Earth years)
- a = average distance from the Sun (in Earth distances)

This law connects time and distance in a mathematical ratio!

---

## Part 3: Music of the Planets

### The Cosmic Symphony

Kepler believed each planet makes a note based on its orbit. Here's what he found:

- **Mercury**: Fast orbit, high note
- **Venus**: Medium orbit, medium note
- **Earth**: Our reference note
- **Mars**: Slower orbit, lower note
- **Jupiter**: Much slower, much lower note
- **Saturn**: Slowest, lowest note

When you put all these notes together, they create a cosmic harmony!

### Planetary Ratios

The ratios between planetary orbits follow musical intervals:
- Earth to Mars: approximately 3:2 (a fifth)
- Jupiter to Saturn: approximately 5:9
- Venus to Earth: approximately 8:13 (Fibonacci!)

These ratios are why Kepler heard music in the planets!

### The Modern Cosmic Hum

Scientists have actually recorded the "sounds" of planets! By converting radio waves from planets into sound waves, we can hear:
- Jupiter's magnetic field hums
- Saturn's rings make sounds
- Neptune's wind howls

It's not music like Kepler imagined, but it IS mathematical!

---

## Part 4: Kepler in Everyday Life

### Astronomy

- **Orbits**: Planets, moons, and asteroids follow Kepler's laws.
- **Satellites**: GPS satellites use Kepler's equations.
- **Space travel**: Rockets use Kepler's laws to navigate.

### Mathematics

- **Ellipses**: Kepler's first law describes ellipses.
- **Ratios**: Kepler's third law connects time and distance.
- **Harmony**: Kepler's music shows ratios in nature.

### Art and Music

- **Space art**: Artists use Kepler's laws to draw realistic orbits.
- **Space music**: Composers create music inspired by planetary sounds.
- **Architecture**: Some buildings use elliptical designs.

---

## Part 5: 10 Fun Exercises

### Exercise 1: Draw an Ellipse
Draw an ellipse using two pins and a string:
1. Put two pins on paper, about 5 cm apart
2. Loop a string around both pins
3. Put your pencil inside the loop
4. Pull the string tight and draw around the pins

The Sun would be at one pin. The planet would be the pencil!

### Exercise 2: Kepler's Third Law
Use Kepler's third law (T² = a³) to calculate:
- If Earth is 1 unit from the Sun and takes 1 year, how far is Mars if it takes 1.88 years?
- If Jupiter is 5.2 units from the Sun, how long does its orbit take?

### Exercise 3: The Cosmic Rhythm
Clap a rhythm based on planetary orbits:
- Mercury: clap every 0.24 seconds (fast!)
- Venus: clap every 0.62 seconds
- Earth: clap every 1 second
- Mars: clap every 1.88 seconds

Can you hear the pattern?

### Exercise 4: Planet Sizes
Draw the planets to scale (relative sizes):
- Mercury: 1 mm
- Venus: 2 mm
- Earth: 2 mm
- Mars: 1 mm
- Jupiter: 20 mm
- Saturn: 17 mm
- Uranus: 7 mm
- Neptune: 7 mm

What ratios do you see?

### Exercise 5: The Harmonic Law Table
Calculate Kepler's third law for different planets:
| Planet | Distance (AU) | Period (years) | T² | a³ |
|--------|---------------|----------------|----|----|
| Mercury| 0.39          | 0.24           |    |    |
| Venus  | 0.72          | 0.62           |    |    |
| Earth  | 1.00          | 1.00           |    |    |
| Mars   | 1.52          | 1.88           |    |    |

Do T² and a³ match?

### Exercise 6: Planet Music
If you could play each planet as a note based on its orbit speed:
- Mercury: high C
- Venus: G
- Earth: middle C
- Mars: low C
- Jupiter: very low C
- Saturn: extremely low C

What would a "planetary symphony" sound like?

### Exercise 7: Draw the Solar System
Draw a picture of the solar system:
- Put the Sun in the center
- Draw orbits as ellipses (not circles!)
- Label each planet
- Show which planets are closer to the Sun

### Exercise 8: Kepler's Biography
Write a short paragraph about Kepler's life:
- When did he live?
- What did he discover?
- Why is he important?
- What was his most famous work?

### Exercise 9: Modern Space Travel
How do modern spacecraft use Kepler's laws?
- GPS satellites orbit Earth using Kepler's equations
- Rockets navigate using Kepler's third law
- Space probes travel to other planets using Kepler's orbits

### Exercise 10: Kepler Journal
In your math journal:
- Draw an ellipse with the Sun at one focus
- Write Kepler's three laws
- Calculate one example of T² = a³
- Write a poem about planetary music

---

## Part 6: Amazing Kepler Facts

### Fact 1: Kepler Was a Genius
Kepler discovered his laws using only:
- Naked-eye observations (no telescopes!)
- Mathematical calculations
- Years of patient work

He did this before telescopes were invented!

### Fact 2: Kepler's Helper
Kepler worked with **Tycho Brahe**, who had the best astronomical observations in the world. After Brahe died, Kepler used Brahe's data to discover his laws!

### Fact 3: Kepler's Dreams
Kepler also studied:
- Optics (how light works)
- Geometry (shapes and sizes)
- Calendar reform (fixing the calendar)

He was interested in everything!

### Fact 4: Kepler's Legacy
Kepler's laws are still used today:
- Every space mission uses them
- Every satellite uses them
- Every astronomical discovery uses them

Without Kepler, we couldn't explore space!

### Fact 5: Kepler's Harmony is Real
While Kepler's cosmic music was poetic, modern science has found that:
- Planetary orbits do follow mathematical ratios
- The solar system does have harmonic properties
- The universe is more musical than Kepler ever imagined!

---

## Part 7: Kepler Poems

### The Kepler Poem
Kepler looked up at the sky so wide,
And heard the planets as they glide,
Each one singing its own song,
In cosmic harmony, all along!

### The Planetary Rhyme
Mercury spins fast around the Sun,
Venus and Earth, one by one,
Mars follows after, red and bright,
Jupiter's king, with moons in flight,
Saturn has rings, Uranus too,
Neptune's blue — the cosmic crew!

---

## Part 8: What You've Learned

Today you discovered:

1. **Kepler's laws** describe how planets move in ellipses, sweep equal areas, and follow the harmonic law (T² = a³).

2. **Planets make music** — the ratios between their orbits follow musical intervals!

3. **Kepler's laws** are used in modern space travel, GPS, and astronomy.

4. **The solar system** is a cosmic symphony, just as Kepler imagined.

5. **Kepler** was a genius who discovered these laws without telescopes!

---

## Part 9: Challenge Problems

### Challenge 1: Calculate an Orbit
If a comet has an orbit that takes 75 years, how far is it from the Sun? (Use T² = a³)

### Challenge 2: The Eccentricity
An ellipse's "eccentricity" measures how oval-shaped it is. Earth's orbit has an eccentricity of 0.017 (nearly circular). Mercury's is 0.206 (more oval). How does eccentricity affect Kepler's laws?

### Challenge 3: Planetary Moons
Jupiter has 4 large moons (Io, Europa, Ganymede, Callisto). Their orbits also follow Kepler's laws. Research their orbital periods and distances!

### Challenge 4: Kepler's Harmony
If Earth's orbit corresponds to the note C, what notes would the other planets correspond to? (Hint: use the ratios of their orbital periods)

### Challenge 5: Modern Kepler
How do modern astronomers use Kepler's laws to discover new planets? Research the transit method and radial velocity method!

---

## Part 10: Glossary

**Astronomer**: A scientist who studies space

**Cosmic**: Relating to the universe

**Ellipse**: An oval shape with two focus points

**Eccentricity**: How oval-shaped an ellipse is (0 = circle, close to 1 = very oval)

**Focus**: A special point inside an ellipse

**Harmonic Law**: Kepler's third law: T² = a³

**Orbit**: The path a planet follows around the Sun

**Period**: The time it takes to complete one orbit

**Solar System**: The Sun and everything that orbits it

**Symphony**: A long piece of music for an orchestra

---

## Remember!

**Kepler discovered music in the planets!**

The next time you look at the night sky, remember: you're looking at a cosmic symphony! The planets move according to mathematical laws, and those laws create harmony. Kepler heard it 400 years ago — now you can hear it too!

---

*The universe isn't just big — it's musical! Every planet, every star, every galaxy follows mathematical laws that create the music of the spheres. Kepler showed us how to listen!*
