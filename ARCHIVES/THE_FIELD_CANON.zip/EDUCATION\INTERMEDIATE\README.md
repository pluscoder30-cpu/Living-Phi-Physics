# 24 — Grade Intermediate | Ages 13–16

## Unified Intermediate-Level Textbook for All Ratio-Systems

---

## Directory Structure

```
24_GRADE_INTERMEDIATE/
├── README.md                          (this file)
├── 01_intermediate_phi.md             (Golden Ratio)
├── 02_intermediate_silver.md          (Silver Ratio)
├── 03_intermediate_bronze.md          (Bronze Ratio)
├── 04_intermediate_harmonic.md        (Harmonic/Music Theory)
├── 05_intermediate_living.md          (Living Mathematics)
├── 06_intermediate_plastic.md         (Plastic Number)
├── 07_intermediate_supergolden.md     (Supergolden Ratio)
├── 08_intermediate_fibonacci.md       (Fibonacci Sequence)
├── 09_intermediate_lucas.md           (Lucas Numbers)
├── 10_intermediate_padovan.md         (Padovan Sequence)
├── 11_intermediate_kepler.md          (Kepler Ratio)
├── 12_intermediate_worksheet.md       (150 Practice Problems)
└── 13_intermediate_answer_key.md      (Complete Answers)
```

---

## Learning Progression

Each ratio-system file follows the same structure:

1. **Definition** — Algebraic definition and decimal value
2. **Proof** — Prove the key identity (e.g., phi^2 = phi + 1)
3. **Conjugate** — Complex/irrational conjugate properties
4. **Sequence Connection** — Associated integer sequence
5. **Special Properties** — Continued fractions, geometric significance
6. **Worked Problems** — 15 step-by-step solutions
7. **Summary Table** — Key properties at a glance
8. **Key Takeaways** — Core concepts for ages 13–16

---

## The 10 Ratio-Systems

| # | System | Symbol | Value | Key Identity | Sequence |
|---|--------|--------|-------|--------------|----------|
| 1 | Golden | phi | 1.618034 | phi^2 = phi + 1 | Fibonacci |
| 2 | Silver | delta_s | 2.414214 | delta_s^2 = 2*delta_s + 1 | Pell |
| 3 | Bronze | delta_b | 3.302776 | delta_b^2 = 3*delta_b + 1 | Narayana |
| 4 | Harmonic | H | 2^(1/12) | H^12 = 2 | Harmonic series |
| 5 | Living | various | various | Scaling laws | DLA, fractals |
| 6 | Plastic | psi | 1.324718 | psi^3 = psi + 1 | Padovan |
| 7 | Supergolden | psi_s | 1.465571 | psi_s^3 = psi_s^2 + 1 | Narayana cows |
| 8 | Fibonacci | F(n) | varies | F(n) = F(n-1) + F(n-2) | Fibonacci |
| 9 | Lucas | L(n) | varies | L(n) = L(n-1) + L(n-2) | Lucas |
| 10 | Padovan | P(n) | varies | P(n) = P(n-2) + P(n-3) | Padovan |

---

## Metallic Means Family

The golden, silver, and bronze ratios are part of the metallic means:

```
M_n = (n + sqrt(n^2 + 4)) / 2

n = 1: phi = (1 + sqrt(5))/2 = 1.618 (golden)
n = 2: delta_s = 1 + sqrt(2) = 2.414 (silver)
n = 3: delta_b = (3 + sqrt(13))/2 = 3.303 (bronze)
n = 4: M_4 = 2 + sqrt(5) = 4.236 (copper)
```

All satisfy: M_n^2 = n*M_n + 1

---

## Cubic Roots Family

The plastic, supergolden, and tribonacci constants are cubic analogues:

```
psi^3 = psi + 1          (plastic, 1.325)
psi_s^3 = psi_s^2 + 1    (supergolden, 1.466)
tau^3 = tau^2 + tau + 1   (tribonacci, 1.839)
```

---

## Fibonacci-like Sequences

| Sequence | Recurrence | Base | Starting Values |
|----------|------------|------|-----------------|
| Fibonacci | F(n) = F(n-1) + F(n-2) | phi | F(1)=1, F(2)=1 |
| Lucas | L(n) = L(n-1) + L(n-2) | phi | L(0)=2, L(1)=1 |
| Padovan | P(n) = P(n-2) + P(n-3) | psi | P(0)=P(1)=P(2)=1 |
| Narayana | N(n) = 3*N(n-1) + N(n-2) | delta_b | N(0)=0, N(1)=1 |
| Pell | P(n) = 2*P(n-1) + P(n-2) | delta_s | P(0)=0, P(1)=1 |

---

## Practice

1. Work through all 15 problems in each ratio-system file
2. Complete the 150-problem worksheet (12_intermediate_worksheet.md)
3. Check answers in the answer key (13_intermediate_answer_key.md)
4. Target score: 400+ out of 480 points

---

## Connections to Other Grades

- **Grade Elementary (23_):** Simpler versions of these topics
- **Grade Intermediate (24_):** This textbook
- **Grade Advanced (25_):** Deeper algebraic and proof-based treatment
- **Equations (02_EQUATIONS/):** Full mathematical derivations
- **Physics (17_PHYSICS_RESEARCH/):** Applications in physics

---

*Total lines: 4000+ across 14 files*
