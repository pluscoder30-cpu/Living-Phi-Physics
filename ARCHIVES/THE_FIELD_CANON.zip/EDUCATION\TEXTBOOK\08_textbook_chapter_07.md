# Chapter 7: Padovan and Kepler Ratios

## Geometric Structures from the Plastic Number

---

### Overview

The Padovan ratio and the Kepler ratio are geometric constants derived from the plastic number. The Padovan ratio governs the Padovan spiral, which is based on equilateral triangles rather than squares. The Kepler triangle is a right triangle whose sides are in geometric progression with ratio related to the plastic number.

These geometric structures extend the ideas of the golden rectangle and golden spiral into new territory, showing that the plastic number has its own rich geometric world.

---

## Lesson 7.1: The Padovan Spiral

### Explanation

The **Padovan spiral** is a spiral constructed from equilateral triangles, where each triangle has a side length equal to a Padovan number.

To construct the Padovan spiral:

1. Start with three equilateral triangles of side 1, arranged in a row.
2. The next triangle has side 2 (the next Padovan number), attached to the previous triangles.
3. Continue adding triangles, each with side length equal to the next Padovan number.
4. The triangles are arranged so that each new triangle shares a side with the previous structure.

The resulting spiral approximates an equilateral triangle spiral, which is different from the golden spiral (based on squares).

**Key Concept**: The Padovan spiral is constructed from equilateral triangles with side lengths following the Padovan sequence.

### Properties of the Padovan Spiral

**Property 1**: The spiral is self-similar. If you zoom in or out by a factor of ρ, the spiral looks the same.

**Property 2**: The spiral approximates an equilateral triangle spiral. The golden spiral approximates a square spiral. The Padovan spiral approximates a triangle spiral.

**Property 3**: The ratio of consecutive side lengths approaches the plastic number ρ ≈ 1.3247.

### Comparison: Golden Spiral vs. Padovan Spiral

| Property | Golden Spiral | Padovan Spiral |
|----------|--------------|----------------|
| Based on | Squares | Equilateral triangles |
| Growth factor per step | φ ≈ 1.618 | ρ ≈ 1.325 |
| Self-similarity ratio | φ | ρ |
| Symmetry | 4-fold (square) | 3-fold (triangle) |
| Nature examples | Nautilus shells, hurricanes | Pinecone spirals |

### Worked Example 7.1.1

Construct the first 6 triangles of the Padovan spiral. What are their side lengths?

**Solution**: The Padovan sequence starts: 1, 1, 1, 2, 2, 3, 4, 5, 7, ...

The first 6 triangles have side lengths: 1, 1, 1, 2, 2, 3.

### Worked Example 7.1.2

After 10 triangles, what is the ratio of the largest to the smallest side length?

**Solution**: The Padovan sequence: 1, 1, 1, 2, 2, 3, 4, 5, 7, 9, 12, ...

After 10 triangles, the side lengths are: 1, 1, 1, 2, 2, 3, 4, 5, 7, 9.

The ratio of largest to smallest: 9/1 = 9.

After 20 triangles, the side lengths go up to P(19) = 208. Ratio: 208/1 = 208.

The growth is slower than the golden spiral because ρ < φ.

### Practice Problems

1. Construct the first 8 triangles of the Padovan spiral. What are their side lengths?
2. What is the ratio of the 10th to the 5th Padovan number?
3. How does the Padovan spiral differ from the golden spiral?
4. Why might nature prefer the Padovan spiral (based on triangles) over the golden spiral (based on squares) in some cases?
5. Draw a Padovan spiral using graph paper and equilateral triangles.

### Teacher's Notes

**Construction Activity**: The Padovan spiral can be constructed using graph paper and a ruler. Have students draw equilateral triangles with side lengths following the Padovan sequence. The resulting spiral is beautiful and instructive.

**Comparison**: Have students compare the Padovan spiral to the golden spiral. Which one grows faster? Which one is more "compact"?

---

## Lesson 7.2: The Kepler Triangle

### Explanation

The **Kepler triangle** is a right triangle whose sides are in geometric progression. That is, if the sides are a, b, c (with c the hypotenuse), then:

b/a = c/b = r

for some ratio r. This means b = ar and c = ar².

By the Pythagorean theorem:

a² + b² = c²
a² + (ar)² = (ar²)²
a² + a²r² = a²r⁴
1 + r² = r⁴

This is the equation r⁴ - r² - 1 = 0, which is a quadratic in r²:

(r²)² - (r²) - 1 = 0

So r² = (1 + √5)/2 = φ.

Therefore r = √φ ≈ 1.2720196495...

**Key Concept**: The Kepler triangle has sides in geometric progression with ratio √φ ≈ 1.272.

### Properties of the Kepler Triangle

**Property 1**: The sides are in geometric progression with ratio √φ.

If the shortest side is 1, the sides are: 1, √φ, φ.

Numerically: 1, 1.2720196495, 1.6180339887.

**Property 2**: The Kepler triangle is the only right triangle whose sides are in geometric progression.

**Property 3**: The area of the Kepler triangle is:

Area = (1/2) × a × b = (1/2) × 1 × √φ = √φ/2 ≈ 0.6360098248

**Property 4**: The perimeter of the Kepler triangle is:

P = 1 + √φ + φ ≈ 1 + 1.2720196495 + 1.6180339887 ≈ 3.8900536382

### Worked Example 7.2.1

Verify that the Kepler triangle with sides 1, √φ, φ satisfies the Pythagorean theorem.

**Solution**: 
a² + b² = 1² + (√φ)² = 1 + φ = 1 + 1.6180339887 = 2.6180339887
c² = φ² = (1.6180339887)² = 2.6180339887

Since a² + b² = c², the Pythagorean theorem is satisfied. ✓

### Worked Example 7.2.2

A Kepler triangle has hypotenuse 10 cm. What are the lengths of the other two sides?

**Solution**: If the hypotenuse is c = 10, and the sides are in geometric progression with ratio √φ, then:

c = a × φ (since c = ar² = a × (√φ)² = a × φ)
a = c/φ = 10/1.6180339887 ≈ 6.180339887

b = a × √φ = 6.180339887 × 1.2720196495 ≈ 7.861513778

So the sides are approximately 6.18 cm, 7.86 cm, and 10 cm.

### Practice Problems

1. Verify that the Kepler triangle with sides 1, √φ, φ is a right triangle.
2. Compute the area of a Kepler triangle with shortest side 5 cm.
3. Compute the perimeter of a Kepler triangle with shortest side 3 cm.
4. A Kepler triangle has middle side 8 cm. What are the lengths of the other two sides?
5. Prove that the Kepler triangle is the only right triangle with sides in geometric progression.

### Teacher's Notes

**Historical Note**: Johannes Kepler (1571-1630) studied the Kepler triangle in connection with the geometry of the solar system. He believed that the orbits of the planets were related to Platonic solids, which in turn were related to the golden ratio.

**Geometric Construction**: The Kepler triangle can be constructed using the golden rectangle. If you draw the diagonal of a golden rectangle, you create two right triangles. One of these triangles is the Kepler triangle.

---

## Lesson 7.3: Padovan Geometry

### Explanation

The Padovan sequence generates several geometric structures beyond the Padovan spiral. Here are some of the most important:

**1. The Padovan Triangle**

The Padovan triangle is an equilateral triangle whose vertices are determined by the Padovan sequence. It is analogous to the golden triangle (an isosceles triangle with vertex angle 36° and base angles 72°).

**2. The Padovan Rectangle**

A Padovan rectangle has dimensions P(n) × P(n+1) for some n. Unlike the golden rectangle, the Padovan rectangle is not self-similar (removing a square does not leave another Padovan rectangle). However, the ratios of the sides approach ρ as n increases.

**3. The Plastic Number Tiling**

The plastic number can be used to create aperiodic tilings of the plane, similar to Penrose tilings. These tilings have three-fold symmetry (based on equilateral triangles) rather than five-fold symmetry (based on regular pentagons).

### The Padovan Triangle in Detail

The Padovan triangle is constructed as follows:

1. Start with an equilateral triangle of side 1.
2. Attach another equilateral triangle of side 1 to one side.
3. Attach a third equilateral triangle of side 1 to complete a larger triangle.
4. Attach an equilateral triangle of side 2 to one side of the larger triangle.
5. Continue, with each new triangle having side length equal to the next Padovan number.

The resulting structure approximates a self-similar fractal triangle.

### Worked Example 7.3.1

What is the area of the Padovan triangle after 6 triangles have been added?

**Solution**: The first 6 Padovan numbers are: 1, 1, 1, 2, 2, 3.

The areas of the equilateral triangles are:
- Side 1: area = √3/4 ≈ 0.4330 (three of these)
- Side 2: area = √3 ≈ 1.7321 (two of these)
- Side 3: area = 9√3/4 ≈ 3.8971 (one of these)

Total area = 3 × 0.4330 + 2 × 1.7321 + 1 × 3.8971 = 1.2990 + 3.4641 + 3.8971 = 8.6602

### Practice Problems

1. Compute the area of the first 4 Padovan triangles (sides 1, 1, 1, 2).
2. What is the total area after 8 triangles?
3. How does the total area grow as more triangles are added?
4. Compare the growth of the Padovan triangle to the growth of the golden rectangle.
5. Draw the first 5 triangles of the Padovan construction.

### Teacher's Notes

**Fractal Activity**: Have students construct the Padovan triangle using graph paper. As they add more triangles, they will see the self-similar structure emerge. This is a beautiful introduction to fractal geometry.

---

## Lesson 7.4: The Plastic Number in Three Dimensions

### Explanation

While the golden ratio governs two-dimensional geometry (golden rectangles, golden spirals), the plastic number has a natural connection to three-dimensional geometry.

**The Plastic Number and Cube Geometry**

Consider a cube with side length s. The plastic number appears in the ratio of the space diagonal to the face diagonal:

Space diagonal = s√3
Face diagonal = s√2

The ratio is √3/√2 = √(3/2) ≈ 1.2247...

This is not the plastic number. However, the plastic number appears in other cubic relationships.

**The Plastic Number and the Truncated Octahedron**

The truncated octahedron is an Archimedean solid with 14 faces (8 hexagons and 6 squares). Its geometry is related to the plastic number through the ratio of its edge lengths to its circumradius.

**The Plastic Number in Crystallography**

Some quasicrystals have structures based on the plastic number rather than the golden ratio. These crystals have three-fold symmetry rather than five-fold symmetry.

### Worked Example 7.4.1

A cube has side length 1. What is the ratio of the space diagonal to the face diagonal?

**Solution**: 
Space diagonal = √(1² + 1² + 1²) = √3 ≈ 1.7321
Face diagonal = √(1² + 1²) = √2 ≈ 1.4142

Ratio = √3/√2 = √(3/2) ≈ 1.2247

### Practice Problems

1. A cube has side length 2. What is the space diagonal?
2. A cube has face diagonal 5. What is the side length?
3. What is the ratio of the volume of a cube to the volume of its inscribed sphere?
4. Research: how does the plastic number appear in quasicrystal structures?
5. Compare the golden ratio in 2D geometry to the plastic number in 3D geometry.

### Teacher's Notes

**3D Visualization**: If you have access to a 3D printer or geometric model kits, show students the truncated octahedron and other Archimedean solids. Discuss how the plastic number appears in their geometry.

**Extension**: Ask students to research quasicrystals and their connection to the plastic number. This is an active area of research in mathematics and materials science.

---

## Lesson 7.5: Comparing the Golden, Silver, Bronze, and Plastic Geometries

### Explanation

We have now studied four major mathematical constants and their geometric manifestations:

| Constant | Value | Equation | Geometric Structure |
|----------|-------|----------|-------------------|
| Golden ratio (φ) | 1.618... | x² = x + 1 | Golden rectangle, golden spiral |
| Silver ratio (δ) | 2.414... | x² = 2x + 1 | Silver rectangle, silver spiral |
| Bronze ratio (B) | 3.303... | x² = 3x + 1 | Bronze rectangle, bronze spiral |
| Plastic number (ρ) | 1.325... | x³ = x + 1 | Padovan spiral, equilateral triangles |

Each constant generates its own geometric world:

**Golden**: Squares and the golden rectangle. The golden spiral is based on quarter-turn growth.
**Silver**: Two squares and the silver rectangle. The silver spiral has a different growth pattern.
**Bronze**: Three squares and the bronze rectangle. The bronze spiral grows much faster.
**Plastic**: Equilateral triangles and the Padovan spiral. The plastic spiral has 3-fold symmetry.

### Why Do Different Constants Appear in Different Geometries?

The key insight is that the equation x² = x + 1 (golden) has solutions related to the regular pentagon, which has 5-fold symmetry. The equation x³ = x + 1 (plastic) has solutions related to equilateral triangles, which have 3-fold symmetry.

Different symmetries in nature lead to different mathematical constants:
- 5-fold symmetry → golden ratio
- 3-fold symmetry → plastic number
- 4-fold symmetry → √2 (silver ratio minus 1)
- Higher-fold symmetry → higher metallic ratios

### The Self-Similarity Ratio

Each spiral has a self-similarity ratio: the factor by which you must scale the spiral to make it look the same.

- Golden spiral: self-similarity ratio = φ ≈ 1.618
- Silver spiral: self-similarity ratio = δ ≈ 2.414
- Bronze spiral: self-similarity ratio = B ≈ 3.303
- Plastic spiral: self-similarity ratio = ρ ≈ 1.325

The plastic spiral has the smallest self-similarity ratio, meaning it is the most "compact" spiral. The bronze spiral has the largest, meaning it is the most "spread out."

### Worked Example 7.5.1

Compare the growth of golden, silver, bronze, and plastic spirals after 10 quarter turns.

**Solution**:
- Golden spiral: φ¹⁰ ≈ 122.99
- Silver spiral: δ¹⁰ ≈ 6,725.6
- Bronze spiral: B¹⁰ ≈ 206,445.8
- Plastic spiral: ρ¹⁰ ≈ 17.0

The bronze spiral grows fastest, followed by silver, then golden, then plastic.

### Worked Example 7.5.2

If you want a spiral that grows by a factor of 100 in exactly 5 quarter turns, which constant should you use?

**Solution**: We need r⁵ = 100, so r = 100^(1/5) = 100^0.2 ≈ 2.512.

This is close to the silver ratio δ ≈ 2.414. So a silver spiral grows by approximately δ⁵ ≈ 79.2 in 5 quarter turns, which is close to 100.

More precisely, for exactly 100 in 5 quarter turns, we would need r = 2.512, which is between the silver ratio (2.414) and the bronze ratio (3.303).

### Practice Problems

1. Compute the growth of each spiral after 5 quarter turns.
2. Which spiral grows slowest? Why?
3. Which spiral grows fastest? Why?
4. In what contexts might you prefer a plastic spiral over a golden spiral?
5. Are there mathematical constants with 6-fold, 7-fold, or higher-fold symmetry?

### Teacher's Notes

**Synthesis**: This lesson brings together all the constants studied so far. Use it as a review and synthesis lesson. Ask students to compare and contrast the four geometric systems.

**Assessment**: A good assessment for this chapter is to ask students to: (1) construct a Padovan spiral, (2) verify the Kepler triangle, (3) compare the four types of spirals, and (4) explain why different constants appear in different geometries.

---

## Lesson 7.6: The Geometry of Metallic Spirals in Architecture

### Explanation

Architects have used metallic spirals in building design for centuries. While the golden spiral is the most famous, the silver and bronze spirals also appear in architectural structures.

### The Golden Spiral in Architecture

The golden spiral appears in:
- The Parthenon (Athens, Greece)
- The Great Pyramid of Giza (Egypt)
- Notre-Dame Cathedral (Paris, France)
- The United Nations Building (New York, USA)

In each case, the proportions of the building approximate the golden ratio, and the overall layout follows a golden spiral pattern.

### The Silver Spiral in Architecture

The silver spiral appears in:
- Some Islamic geometric patterns
- The proportions of certain Islamic mosques
- Some modern architectural designs

The silver spiral is less common than the golden spiral, but it has its own aesthetic appeal: it is more elongated and dramatic.

### The Bronze Spiral in Architecture

The bronze spiral is rare in architecture, but it appears in some:
- Tower designs (the ratio of height to base width)
- Staircase designs (the ratio of step width to step height)

### The Plastic Spiral in Architecture

The plastic spiral is very rare in architecture, but it appears in some:
- Triangular structures (roof trusses, geodesic domes)
- Three-fold symmetric designs

### Worked Example 7.6.1

A tower has a square base with side 10 m. If the height-to-base ratio is the bronze ratio, what is the height?

**Solution**: Height = B × base = 3.303 × 10 = 33.03 m.

### Practice Problems

1. Find a building that uses the golden ratio in its proportions.
2. Find a building that uses the silver ratio in its proportions.
3. Why might an architect choose the silver spiral over the golden spiral?
4. Design a building that uses the plastic number in its proportions.
5. What are the aesthetic differences between golden, silver, and bronze spirals?

### Teacher's Notes

**Architecture Connection**: This lesson connects the metallic ratios to architecture. Show photographs of buildings that use these ratios in their design.

**Design Activity**: Have students design a building that uses one of the metallic ratios. They should compute the proportions and explain why they chose that particular ratio.

---

## Summary of Chapter 7

### Key Concepts

1. The **Padovan spiral** is constructed from equilateral triangles with side lengths following the Padovan sequence.
2. The **Kepler triangle** is a right triangle with sides in geometric progression with ratio √φ.
3. The **plastic number** ρ governs the Padovan spiral, just as the golden ratio φ governs the golden spiral.
4. Different mathematical constants appear in different geometries because they are related to different symmetry groups.
5. The plastic number has connections to three-dimensional geometry and crystallography.

### Key Formulas

| Formula | Description |
|---------|-------------|
| P(n) = P(n-2) + P(n-3) | Padovan recurrence |
| r = √φ ≈ 1.272 | Kepler triangle ratio |
| 1, √φ, φ | Sides of the Kepler triangle |
| ρ ≈ 1.3247 | Plastic number |

### Connections to Other Chapters

- **Chapter 1 (Golden Ratio)**: The Kepler triangle is built from the golden ratio.
- **Chapter 6 (Plastic and Supergolden Ratios)**: The plastic number governs the Padovan sequence.
- **Chapter 8 (Living Mathematics)**: The Padovan spiral appears in some biological structures.
- **Chapter 10 (Phi-Chemistry and Phi-Physics)**: Quasicrystals use the plastic number.

---

**End of Chapter 7**

*Next: Chapter 8 — Living Mathematics*
