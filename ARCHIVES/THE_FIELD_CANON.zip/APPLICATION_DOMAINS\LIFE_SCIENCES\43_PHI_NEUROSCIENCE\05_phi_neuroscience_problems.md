﻿# PHI-NEUROSCIENCE: Practice Problems

---

## Problem 1: Phi-Firing Rate
Cortical neuron with f0 = 120 Hz, dV = 18 mV, V0 = 20 mV. Calculate phi-firing rate.

## Problem 2: Phi-Action Potential
Calculate V_phi at t = 0.8 ms for V_rest = -65 mV, V_peak = +35 mV.

## Problem 3: Phi-STDP
Pre-post pair with dt = +15 ms. Calculate phi-weight change with A+ = 0.012.

## Problem 4: Phi-Brain Waves
Calculate theta-gamma coupling for f_theta = 5 Hz, f_gamma = 35 Hz.

## Problem 5: Phi-Working Memory
Working memory under cognitive load = 0.8. Calculate phi-corrected capacity.

## Problem 6: Phi-Consciousness
Neural assembly with 8 regions, w = 0.6. Calculate consciousness threshold.

## Problem 7: Phi-Alpha Rhythm
Alpha oscillation at t = 75 ms with A = 45 muV, tau = 120 ms, f = 11 Hz.

## Problem 8: Phi-Memory
Memory after 72 hours with tau = 36 hr and 8 rehearsals. Calculate phi-strength.

## Problem 9: Phi-Learning Rate
Learning rate at epoch 80 with eta_0 = 0.005, tau = 150. Calculate phi-rate.

## Problem 10: Phi-NN Initialization
Layer with 512 inputs. Calculate phi-initialized weight standard deviation.

## Problem 11: Phi-STDP Window
dt = -20 ms. Calculate phi-LTD with A- = 0.015, tau- = 30 ms.

## Problem 12: Phi-Connectivity
PFC-hippocampus connection at distance 4. Calculate phi-weighted connectivity.

## Problem 13: Phi-Oscillator Sync
Two oscillators with K = 0.15, omega_diff = 0.8. Calculate phi-sync time.

## Problem 14: Phi-Attention
Stimulus with relevance 0.9, optimal = 0.7, sigma = 0.25. Calculate phi-attention.

## Problem 15: Phi-Gradient
Gradient = 0.7, sigma = 0.4, eta = 0.008. Calculate phi-adaptive update.

## Problem 16: Phi-Engram
4 learning events at t = 0, 3, 7, 12 min. Calculate phi-engram strength.

## Problem 17: Phi-Homeostasis
Firing rate 30% above target. Calculate phi-scaling factor.

## Problem 18: Phi-Metaplasticity
Recent activity = 180 Hz, r_target = 100 Hz. Calculate phi-threshold shift.

## Problem 19: Phi-BCI
BCI accuracy 0.9, channel noise 0.4. Calculate phi-corrected accuracy.

## Problem 20: Phi-Prosthetic
Prosthetic after 9 months, I_0 = 0.3, tau = 15 months. Calculate phi-integration.

---

*Part of the 32_PHI_PHYSICS / 06_EXPANDED_MATHEMATICS system.*
*Version 1.0 -- Agent I of 26*

## Problem 21: Phi-Neurotransmitter
Dopamine receptor affinity = 10 nM. Calculate phi-affinity.

## Problem 22: Phi-Brain Development
Neural tube closure at 28 days. Calculate phi-age.

## Problem 23: Phi-Sleep Architecture
N2 sleep duration = 25 min. Calculate phi-duration.

## Problem 24: Phi-Pain Processing
Sharp pain threshold = 10 muA. Calculate phi-threshold.

## Problem 25: Phi-Autonomic
Heart rate increase = +30 bpm. Calculate phi-effect.

## Problem 26: Phi-Neurological Biomarker
Alzheimer's Abeta42 = 500 pg/mL. Calculate phi-level.

## Problem 27: Phi-NN Hyperparameter
Learning rate search range [1e-5, 1e-1]. Calculate phi-range.

## Problem 28: Phi-Drug Effect
SSRI effect size = 0.4. Calculate phi-effect.

## Problem 29: Phi-Oscillation Coherence
Prefrontal-parietal coherence = 0.7. Calculate phi-coherence.

## Problem 30: Phi-Consciousness State
Normal wakefulness integrated info = 1.0. Calculate phi-threshold.
