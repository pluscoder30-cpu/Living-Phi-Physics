# PHI-SCULPTURE

## 1. PHI-Principles in Three Dimensions

### 1.1 Volumetric Proportions

PHI-sculpture applies the golden ratio phi = 1.6180339887 to three-dimensional form, governing the relationships between height, width, depth, and the volumes of component parts.

### 1.2 The PHI-Bounding Box

Every PHI-sculpture fits within a golden-ratio bounding box:

```
Height : Width : Depth = phi^2 : phi : 1

For a sculpture with depth D:
  Width = D x phi
  Height = D x phi^2

Example (D = 30 cm):
  Width = 30 x phi = 48.5 cm
  Height = 30 x phi^2 = 78.5 cm
  
  Bounding box: 78.5 x 48.5 x 30 cm
  Volume: 114,982.5 cm³
```

### 1.3 Negative Space in Sculpture

```
PHI-sculpture uses negative space at golden-ratio proportions:

Total volume: V
Solid volume: V/phi (61.8%)
Void volume: V/phi^2 (38.2%)

The void is not empty but shaped by the solid,
creating an interplay where the absence is as
important as the presence

Void placement:
  Primary void: at phi-point from base (V/phi from bottom)
  Secondary void: at phi-point from top (V/phi^2 from top)
  Tertiary void: at phi-point from center (V/phi^3 offset)
```

## 2. Classical PHI-Sculpture

### 2.1 The Contrapposto Ratio

```
Contrapposto pose phi-proportions:

Weight-bearing leg: vertical (0 degrees)
Free leg: extended at 180/phi = 111.3 degrees from vertical

Shoulder tilt: 180/phi^2 = 68.8 degrees from horizontal
Hip tilt: 180/phi^3 = 42.5 degrees from horizontal

Head turn: 180/phi^4 = 26.3 degrees from forward

The opposing tilts create an S-curve through the figure,
with the curve's inflection points at phi-divisions of height
```

### 2.2 The Canon of Polykleitos

```
Polykleitos' Canon (c. 450 BCE) used phi-proportions:

Doryphoros (Spear Bearer):
  Total height: 199 cm
  Navel height: 199/phi = 123 cm
  Shoulder height: 199 - 199/phi^2 = 123 cm (from top)
  
  Head : Body = 1 : phi
  Head height: 199/(1+phi) = 76 cm
  Body height: 199 - 76 = 123 cm
  
  Upper arm : Forearm : Hand = phi : 1 : 1/phi
  = 47 : 29 : 18 cm (approximate)
  
  Thigh : Calf : Foot = phi^2 : phi : 1
  = 55 : 34 : 21 cm (approximate)
```

### 2.3 Renaissance Sculpture

```
Michelangelo's David (1501-1504):
  Total height: 517 cm (with base)
  Figure height: 434 cm
  
  Head : Torso : Legs = 1 : phi : phi^2
  = 50 : 81 : 131 cm (approximate)
  
  Hand size: 50/phi = 31 cm (proportionally large for visual impact)
  
  The slight enlargement of the head and hands
  follows phi-variations from strict proportion,
  creating visual emphasis at the points of
  intellectual and physical action
```

## 3. Modern PHI-Sculpture

### 3.1 Brancusi's PHI-Forms

```
Constantin Brancusi used phi-proportions in abstract sculpture:

Bird in Space (1928):
  Height: 137 cm
  Width: 22 cm (at widest)
  Depth: 17 cm
  
  Height/Width = 137/22 = 6.23 (not phi)
  But: Height/Width = phi^3 = 4.236 (error: 46.7%)
  
  The sculpture elongates beyond phi, creating an
  aspirational quality that draws the eye upward

Fish (1926):
  Length: 48 cm
  Width: 18 cm
  Height: 21 cm
  
  Length/Width = 48/18 = 2.667 (close to phi^2 = 2.618, error: 1.9%)
  Width/Height = 18/21 = 0.857 (close to 1/phi = 0.618, error: 38.7%)
  
  The length-to-width ratio closely follows phi^2
```

### 3.2 Henry Moore's PHI-Openings

```
Henry Moore's reclining figures use phi for internal openings:

Reclining Figure (1951):
  Length: 210 cm
  Height: 80 cm
  Opening diameter: 80/phi = 49.4 cm
  
  The opening allows light to pass through,
  creating a void that is phi-proportioned to the solid

  Opening placement:
    Distance from left end: 210/phi = 130 cm
    Distance from right end: 210 - 130 = 80 cm
    Ratio: 130/80 = 1.625 (error from phi: 0.4%)
```

### 3.3 Barbara Hepworth's PHI-Holes

```
Hepworth's pierced sculptures:

Two Forms (1934):
  Total length: 58 cm
  Piercing diameter: 58/phi = 35.8 cm
  
  The two forms connected by the piercing:
    Form A: 58/phi = 35.8 cm
    Form B: 58/phi^2 = 22.1 cm
    Overlap: 58 - 35.8 - 22.1 = 0.1 cm (essentially touching)
    
  The phi-division creates two forms that are
  distinct yet unified through the piercing
```

## 4. PHI-Sculptural Materials

### 4.1 Stone Carving

```
PHI-Marble block selection:

Raw block dimensions:
  Height: 100 cm
  Width: 100/phi = 61.8 cm
  Depth: 61.8/phi = 38.2 cm

Waste ratio (material removed):
  Removed: 1 - 1/phi = 38.2%
  Remaining: 61.8%
  
  The phi-ratio of waste to kept material
  creates a natural efficiency in carving
```

### 4.2 Bronze Casting

```
PHI-Bronze patina layers:

Layer 1 (base): 61.8% of total thickness
  Material: copper-rich bronze
  Color: warm brown
  
Layer 2 (middle): 23.6% of total thickness
  Material: standard bronze
  Color: green-brown
  
Layer 3 (surface): 14.6% of total thickness
  Material: copper carbonate (patina)
  Color: verdigris green

The phi-layers create a natural depth of color
that reveals different tones as viewing angle changes
```

### 4.3 Mixed Media

```
PHI-Mixed media material ratios:

For a sculpture combining wood and metal:
  Wood volume : Metal volume = phi : 1
  
  Example:
    Wood: 1000 cm³
    Metal: 1000/phi = 618 cm³
    
  The phi-ratio ensures neither material dominates
  while maintaining clear material hierarchy
```

## 5. PHI-Sculptural Space

### 5.1 Installation Scale

```
PHI-Installation proportions:

Room dimensions for optimal PHI-sculpture display:
  Length: 1000 cm
  Width: 1000/phi = 618 cm
  Height: 618/phi = 382 cm

Sculpture placement:
  Distance from entrance: 1000/phi = 618 cm
  Distance from walls: 618/phi = 382 cm
  Viewing distance: sculpture_height x phi = 382 x phi = 618 cm
```

### 5.2 Gallery Lighting

```
PHI-Gallery lighting angles:

Key light: 45 degrees from horizontal (180/phi^2 = 68.8 degrees from vertical)
Fill light: 30 degrees from horizontal (180/phi^3 = 42.5 degrees from vertical)
Rim light: 60 degrees from horizontal (180/phi = 111.3 degrees from vertical)

Light intensity ratios:
  Key : Fill : Rim = phi^2 : phi : 1
  = 2.618 : 1.618 : 1
  
  Example (Rim = 100 lux):
    Fill = 162 lux
    Key = 262 lux
```

### 5.3 Pedestal Design

```
PHI-Pedestal proportions:

For a sculpture of height H:
  Pedestal height: H/phi (61.8% of sculpture height)
  Pedestal width: sculpture_width x phi
  Pedestal depth: sculpture_depth x phi

Example (sculpture: 100 x 40 x 30 cm):
  Pedestal height: 100/phi = 61.8 cm
  Pedestal width: 40 x phi = 64.7 cm
  Pedestal depth: 30 x phi = 48.5 cm
  
  Total display height: 100 + 61.8 = 161.8 cm = phi x 100 cm
  The total height is exactly phi times the sculpture height
```

## 6. PHI-Sculptural Series

### 6.1 Progression Series

```
A series of sculptures following phi-progression:

Sculpture 1: Height H
Sculpture 2: Height H x phi
Sculpture 3: Height H x phi^2
Sculpture 4: Height H x phi^3

Example (H = 30 cm):
  1: 30 cm
  2: 48.5 cm
  3: 78.5 cm
  4: 127.0 cm

The series creates a visual crescendo,
with each piece growing by the golden ratio
```

### 6.2 Modular PHI-Sculpture

```
Modular system with phi-connections:

Module dimensions: 20 x 20 x 20 cm (cube)
Connection: phi-ratio overlap
  Overlap: 20/phi = 12.4 cm
  Visible: 20 - 12.4 = 7.6 cm
  
Module arrangement:
  2 modules: 20 + 7.6 = 27.6 cm
  3 modules: 20 + 7.6 + 7.6 = 35.2 cm
  5 modules: 20 + 4 x 7.6 = 50.4 cm
  8 modules: 20 + 7 x 7.6 = 73.2 cm
  
  The total lengths follow Fibonacci sequence:
  27.6, 35.2, 50.4, 73.2, ... (approximately)
```

### 6.3 Ephemeral PHI-Sculpture

```
Ice sculpture with phi-melting:

Initial dimensions: 100 x 61.8 x 38.2 cm
Melting rate: uniform on all surfaces

After time T:
  Dimensions: (100-2r) x (61.8-2r) x (38.2-2r)
  Where r = melting rate x T

The sculpture maintains phi-proportions until:
  38.2 - 2r = 0
  r = 19.1 cm (at this point, depth = 0)
  
  At r = 19.1 cm:
    Height: 100 - 38.2 = 61.8 cm
    Width: 61.8 - 38.2 = 23.6 cm
    Depth: 0 cm
    
  The sculpture reduces to a phi-rectangle (61.8 x 23.6)
  before disappearing entirely
```

## 7. Digital PHI-Sculpture

### 7.1 3D Modeling

```
PHI-3D modeling parameters:

Base mesh: phi-subdivided icosahedron
  Icosahedron: 20 faces, 12 vertices
  PHI-subdivision: each face divided into phi^2 = 2.618 sub-faces
  Rounded: 3 sub-faces per original
  Total: 20 x 3 = 60 faces

Extrusion ratios:
  Primary extrusion: phi
  Secondary extrusion: phi^2
  Tertiary extrusion: phi^3
  
Smoothness parameter:
  Subdivision levels: 5 (Fibonacci number)
  Crease angle: 180/phi = 111.3 degrees
```

### 7.2 Generative PHI-Sculpture

```python
import math

PHI = (1 + 5**0.5) / 2

def phi_sphere(radius, resolution=8):
    """Generate a phi-subdivided sphere."""
    vertices = []
    faces = []
    
    # Golden spiral points on sphere
    for i in range(resolution):
        theta = 2 * math.pi * i / PHI  # Golden angle
        phi_angle = math.acos(1 - 2 * (i + 0.5) / resolution)
        
        x = radius * math.sin(phi_angle) * math.cos(theta)
        y = radius * math.sin(phi_angle) * math.sin(theta)
        z = radius * math.cos(phi_angle)
        
        vertices.append((x, y, z))
    
    return vertices

def phi_extrude(mesh, factor=PHI):
    """Extrude mesh by phi-factor."""
    new_vertices = []
    for v in mesh.vertices:
        # Extrude along normal
        normal = v.normalized()
        new_v = v + normal * factor
        new_vertices.append(new_v)
    return Mesh(new_vertices, mesh.faces)
```

### 7.3 Print Optimization

```
PHI-3D printing parameters:

Layer height: 0.1 mm (reference)
PHI-layer height: 0.1 x phi = 0.162 mm

Infill pattern: phi-honeycomb
  Cell size: 5 mm
  Wall thickness: 5/phi = 3.09 mm
  
Support structure:
  Support angle: 45 degrees (180/phi^2 = 68.8 degrees from vertical)
  Support density: 20% (1/phi^2 of solid)
  
Print time optimization:
  Phi-speed zones:
    High detail: 30 mm/s (at focal points)
    Medium detail: 30 x phi = 48.5 mm/s
    Low detail: 48.5 x phi = 78.5 mm/s
```

## 8. PHI-Sculptural Conservation

### 8.1 Display Conditions

```
Optimal PHI-sculpture display:

Temperature: 20 degrees C (phi x 12.35)
Humidity: 45% (phi x 27.8%)
Light level: 150 lux (phi x 92.7 lux)
UV exposure: < 75 microwatts/lumen

Viewing distance: sculpture_height x phi
  For 100 cm sculpture: 161.8 cm viewing distance
  For 200 cm sculpture: 323.6 cm viewing distance
```

### 8.2 Restoration Principles

```
PHI-Restoration ethics:

Original material : Restored material = phi : 1

  If original = 61.8% of surface
  Then restored = 38.2% of surface
  
  The phi-ratio ensures the original dominates
  while restoration is sufficient for structural integrity
  
  Color matching:
    Restored color = Original color x (1/phi)
    = 61.8% of original saturation
    
  The slight desaturation of restored areas
  makes them distinguishable from original upon close inspection
```

## References

- Boroditsky, L. (2011). "How Language Shapes Thought"
- Janson, H. (1986). "History of Art"
- Read, H. (1956). "The Art of Sculpture"
- Bancroft, G. (2012). "The Sculptor's Language"
- Neumayer, R. (2001). "Scienza: The Venus of Willendorf"
