# PHI-ANTHROPOLOGY: Problems and Exercises

---

## Problem 1: Civilizational Peak Timing

A civilization has growth rate α = 0.015/yr, crisis intensity β = 0.04/yr, and τ_crisis = 250 years.

(a) Find the time to peak complexity.
(b) Calculate the peak complexity relative to initial.
(c) Determine the complexity at t = 500 years.
(d) If crisis intensity doubles, find the new peak time.

---

## Problem 2: Migration Front Propagation

A migration wave starts with v₀ = 12 km/yr and R_front = 100 km.

(a) Find the velocity at 50 km, 100 km, and 200 km.
(b) Calculate the time to reach each distance.
(c) Determine the distance where velocity drops below 0.5 km/yr.
(d) Compare with standard exponential decay (same initial velocity).

---

## Problem 3: Language Branching

A proto-language splits at t = 0 with N₀ = 1 language. τ_branch = 250 years.

(a) Find the number of daughter languages after 500, 1000, and 2000 years.
(b) Calculate the time to reach 100 languages.
(c) Determine the branching rate at t = 1000 years.
(d) If τ_branch doubles to 500 years, find the time to reach 100 languages.

---

## Problem 4: Mythological Archetype Recurrence

The "Great Flood" archetype appeared in Sumerian myth around 3000 BCE. τ_myth = 400 years.

(a) List the next 5 predicted appearances.
(b) Find the recurrence period for n = 5.
(c) Determine the total number of recurrences over 5,000 years.
(d) Calculate the probability of appearance in any given century.

---

## Problem 5: Cultural Complexity Growth

A culture starts with K₀ = 50 at year 0. τ_culture = 200 years. K_max = 5,000.

(a) Find complexity at years 100, 300, and 600 (ignoring saturation).
(b) Calculate the same with saturation included.
(c) Determine when complexity reaches 50% of carrying capacity.
(d) Find the growth rate at t = 200 years.

---

## Problem 6: Settlement Pattern Analysis

An archaeological site shows ρ₀ = 200 artifacts/km² at center. R_artifact = 10 km.

(a) Find density at 5 km, 10 km, and 20 km.
(b) Calculate total artifacts in zone 0-5 km, 5-10 km, 10-20 km.
(c) Determine the distance where density drops below 10 artifacts/km².
(d) Compare with standard 1/r² density model.

---

## Problem 7: Trade Route Efficiency

Compare phi-spiral vs straight trade routes for cities 800 km apart.

(a) Find the phi-spiral route distance.
(b) Calculate the number of intermediate trading posts.
(c) Determine the total trade value if each post handles 61.8% of goods.
(d) Find the break-even distance where spiral becomes more efficient.

---

## Problem 8: Cultural Assimilation

Immigrants arrive with C₀ = 80. Host culture is C_host = 40. τ_assimilate = 25 years.

(a) Find assimilation at years 10, 25, and 50.
(b) Calculate the time to 50% assimilation.
(c) Determine the assimilation rate at t = 25 years.
(d) If host culture changes to C_host = 60, find the new equilibrium.

---

## Problem 9: Lexical Distance

Two languages diverged 800 years ago with τ_lang = 350 years. They had 2 contact events.

(a) Find the lexical distance relative to initial divergence.
(b) Calculate the same without contacts.
(c) Determine the contact effect ratio.
(d) Find the number of contacts needed to reduce distance by 90%.

---

## Problem 10: Civilization Memory Decay

Historical knowledge starts at 100% at year 0. τ_memory = 600 years.

(a) Find knowledge at years 200, 500, and 1000.
(b) Calculate the half-life.
(c) Determine when knowledge drops below 10%.
(d) If knowledge is reinforced every 300 years, find the long-term retention.

---

## Problem 11: Historical Cycle Analysis

A civilization cycles with τ_civ = 400 years. Current age is 300 years.

(a) Find the current phase position.
(b) Calculate the time to next renewal.
(c) Determine the cycle harmonic number.
(d) Predict the complexity at next peak.

---

## Problem 12: Language Vocabulary Drift

A language starts with v₀ = 10,000 words. τ_lang = 400 years.

(a) Find vocabulary at years 100, 200, and 500.
(b) Calculate the drift rate at t = 200 years.
(c) Determine when vocabulary changes by 50%.
(d) Compare with standard linear drift model.

---

## Problem 13: Archaeological Layer Depth

A site has D₀ = 0.5 m for the surface layer. τ_stratigraphy = 250 years.

(a) Find layer depths for layers 1-5.
(b) Calculate total depth for 10 layers.
(c) Determine the age of the deepest layer.
(d) Compare with standard linear depth model.

---

## Problem 14: Cultural Extinction Rate

A cultural trait has age 500 years. τ_obsolescence = 150 years.

(a) Find the extinction rate relative to baseline.
(b) Calculate the probability of extinction in the next 100 years.
(c) Determine the trait's expected remaining lifetime.
(d) If the trait is reinforced, find the new extinction rate.

---

## Problem 15: Urban Morphology

A city has ρ₀ = 10,000 people/km² at center. R_city = 20 km.

(a) Find density at 5 km, 10 km, and 15 km.
(b) Calculate total population in each zone.
(c) Determine the distance where density drops below 1,000/km².
(d) Find the city's total population.

---

*End of PHI-ANTHROPOLOGY Problems*
