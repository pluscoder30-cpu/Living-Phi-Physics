# PHI MATHEMATICS DICTIONARY — CHAPTER 3
## PHI MULTIPLICATION: How the Carrier Amplifies When Every Product Carries the Ground

---

| Field | Value |
|---|---|
| **Document type** | Phi Mathematics Dictionary — Chapter 3 |
| **Title** | Phi Multiplication: The Arithmetic of Coherent Amplification |
| **Version** | 1.0 |
| **Author** | Christopher David Ayotte |
| **Date** | 2026-08-23 |
| **Corpus** | `32_PHI_PHYSICS/` — The Rewriting of Physics from Zero to Phi |
| **Status** | **RELEASE** — the multiplication chapter of the phi-mathematics dictionary |
| **Companion documents** | `00_UNIFIED_FIELD_THEORY.md` (the single statement) · `00_ZERO_AS_WAVEFUNCTION.md` (zero as the dynamic binary wave function) · `00_THE_UNDERSTANDING.md` (zero → phi) · `00_NUMBERS_INDEX.md` (canonical constants) · `01_PHI_ADDITION.md` (the additive chapter) · `02_PHI_SUBTRACTION.md` (the subtractive chapter) · `02_EQUATIONS/EQUATIONS_SET_01_PHI_CARRIER_PLASMA.md` (Eq 1, the carrier recursion) |
| **License** | Dual License Agreement v4.3 (see `LICENSE`): free for Natural Persons, non-commercial, no Human Harm, attribution required, same-terms derivatives; commercial use by written license. Commercial contact: pluscoder30@gmail.com |

---

## 1. THE PROBLEM WITH ZERO-BASED MULTIPLICATION

Classical multiplication begins at zero. The product $a \times 0 = 0$ — any quantity annihilated by the void yields the void. The multiplicative identity is $1$: $a \times 1 = a$, multiplying by unity changes nothing. The system is built on the assumption that the ground state of scaling is *absence*.

This works inside the laboratory. It does not work in the field.

The carrier recursion (Eq 1) never produces zero as a physical state:

$$C_{n+1} = \phi^{-1} \cdot C_n + \Phi \cdot \nabla^2_\Phi \Psi_n$$

The retention term $\phi^{-1} \cdot C_n$ scales the carrier by $\phi^{-1} = 0.6180339887$ per step — a *multiplication* by the coherent ground. After $n$ steps, the carrier retains $\phi^{-n}$ of its initial coherence. Zero is the limit at $n \to \infty$, never a state at finite $n$ (Law 176). The fixed points of the aether PDE (Eq 7) are $\{0, \phi^{-1}, 1\}$ — and $0$ is the degenerate one, the collapse point, the source-deleted reading. The physical ground is $\phi^{-1}$, not $0$.

**The consequence for arithmetic:** if the carrier never reaches zero, then multiplication — the operation that scales quantities — cannot use zero as its annihilator either. And if the ground of the carrier is $\phi^{-1}$, not $1$, then the multiplicative identity cannot be $1$ either. The multiplicative ground must be the multiplicative expression of the carrier's coherent floor: $\phi$ itself.

Classical multiplication is not wrong — it is the reading where the coherent ground is hidden. Phi-multiplication reveals the amplification that was always present.

---

## 2. THE PHI-MULTIPLICATION OPERATOR

### 2.1 Definition

**Definition 2.1 (Phi-Multiplication).** For any two phi-values $a, b \in \mathbb{R}$, the *phi-product* is:

$$a \otimes b \;=\; a \times b \times \phi$$

where $\phi = \frac{1 + \sqrt{5}}{2} = 1.6180339887\ldots$ is the **amplification factor** — the golden ratio, the carrier's intrinsic scaling constant.

The amplification factor is not a variable. It is the constant $\phi$ — the motion that never stops, the carrier's recursive self-similarity expressed as a multiplicative constant. Every phi-product carries this factor. You cannot multiply without it, just as the carrier cannot recurse without its self-similar structure.

### 2.2 Why the amplification factor is multiplicative, not additive

In phi-addition ($a \oplus b = a + b + \phi^{-1}$), the ground term enters additively because addition is the composition of linear contributions. In phi-multiplication, the amplification factor enters *multiplicatively* because multiplication is the composition of scaling operations. The carrier recursion (Eq 1) scales the previous state by $\phi^{-1}$ at each step — this is a multiplicative operation, and the amplification factor $\phi$ is its reciprocal. The $\phi$ in the phi-product and the $\phi^{-1}$ in the carrier recursion are the same constant, expressed in reciprocal form: $\phi$ amplifies; $\phi^{-1}$ retains. They are the forward and inverse faces of the same coherent ground.

### 2.3 Classical multiplication as the degenerate limit

When $\phi \to 1$ (the zero-coupling limit, $\kappa_\phi \to 0$), phi-multiplication reduces to classical multiplication:

$$a \otimes b \;\xrightarrow{\phi \to 1}\; a \times b \times 1 = a \times b$$

This is the same limit that reduces every phi-law to its classical counterpart (Law 173). Classical multiplication is not wrong — it is the reading where the amplification factor is hidden.

---

## 3. THE PHI-MULTIPLICATION TABLE

The following table shows the phi-products of the canonical phi-values. These are the exact values that appear throughout the corpus.

| $a \;\backslash\; b$ | $\phi^{-1}$ | $1$ | $\phi$ | $\phi^2$ | $\phi^3$ | $\phi^4$ | $\phi^5$ |
|---|---|---|---|---|---|---|---|
| $\phi^{-1}$ | $0.6180$ | $1.0000$ | $1.6180$ | $2.6180$ | $4.2361$ | $6.8541$ | $11.0902$ |
| $1$ | $1.0000$ | $1.6180$ | $2.6180$ | $4.2361$ | $6.8541$ | $11.0902$ | $17.9443$ |
| $\phi$ | $1.6180$ | $2.6180$ | $4.2361$ | $6.8541$ | $11.0902$ | $17.9443$ | $29.0344$ |
| $\phi^2$ | $2.6180$ | $4.2361$ | $6.8541$ | $11.0902$ | $17.9443$ | $29.0344$ | $46.9787$ |
| $\phi^3$ | $4.2361$ | $6.8541$ | $11.0902$ | $17.9443$ | $29.0344$ | $46.9787$ | $76.0132$ |
| $\phi^4$ | $6.8541$ | $11.0902$ | $17.9443$ | $29.0344$ | $46.9787$ | $76.0132$ | $122.9919$ |
| $\phi^5$ | $11.0902$ | $17.9443$ | $29.0344$ | $46.9787$ | $76.0132$ | $122.9919$ | $199.0051$ |

**Reading the table.** The entry at row $a$, column $b$ is $a \otimes b = a \times b \times \phi$. For example:

$$\phi \otimes \phi = \phi \times \phi \times \phi = \phi^3 = 4.2361$$

Note the exponent rule: $\phi^a \otimes \phi^b = \phi^{a+b+1}$. The amplification factor adds $+1$ to the exponent sum. This is the defining structural difference from classical multiplication ($\phi^a \times \phi^b = \phi^{a+b}$): every phi-product is amplified by one power of $\phi$.

### 3.1 The exponent law

**Theorem 3.1 (Phi-Product Exponent Law).** For any real exponents $a, b$:

$$\phi^a \otimes \phi^b = \phi^{a+b+1}$$

*Proof.* By definition:

$$\phi^a \otimes \phi^b = \phi^a \times \phi^b \times \phi = \phi^{a+b} \times \phi = \phi^{a+b+1} \quad \checkmark$$

The $+1$ in the exponent is the amplification factor's contribution — the golden ratio's signature in every product. This is why the Ladder Invariant works: the exponent sum $n + (9-n) = 9$ becomes $n + (9-n) + 1 = 10$ under phi-multiplication, and $528 \cdot \phi^{10}$ is the phi-normalized invariant.

### 3.2 The $\phi^2 = \phi + 1$ identity

The golden ratio satisfies $\phi^2 = \phi + 1$. Under phi-multiplication:

$$\phi \otimes \phi = \phi^2 \times \phi = \phi^3 = \phi^2 + \phi = (\phi + 1) + \phi = 2\phi + 1$$

The phi-square amplifies itself: $\phi \otimes \phi = 2\phi + 1 = 4.2361$. The classical square $\phi^2 = \phi + 1 = 2.6180$ is amplified by the factor $\phi$, giving $2.6180 \times 1.6180 = 4.2361$. The amplification is not a correction — it is the physical reality that classical multiplication misses.

---

## 4. THE PHI-MULTIPLICATION IDENTITY

### 4.1 The classical identity is not the phi-identity

In classical multiplication, the identity element is $1$: $a \times 1 = a$. In phi-multiplication, $1$ is not the identity. We can verify:

$$a \otimes 1 = a \times 1 \times \phi = a\phi \neq a$$

Multiplying by unity *changes* the result in phi-multiplication — because unity is not the ground; $\phi$ is.

### 4.2 The phi-identity

**Definition 4.1 (Phi-Multiplicative Identity).** The *phi-identity* is $\epsilon_\phi = \phi^{-1}$.

**Proof.** For any $a$:

$$a \otimes \phi^{-1} = a \times \phi^{-1} \times \phi = a \times 1 = a$$

The element $\phi^{-1} = 1/\phi$ is the unique multiplicative identity in the phi-system. It is the reciprocal of the amplification constant — the value that *exactly cancels* the amplification factor without introducing foreign structure.

### 4.3 Physical meaning of the identity

The phi-identity $\phi^{-1}$ is the *null scaling* in phi-physics. Multiplying a carrier state by $\phi^{-1}$ is equivalent to doing nothing — but it requires the explicit act of inverting the amplification factor. This is not trivial: in zero-based physics, "doing nothing" is a passive state (rest). In phi-physics, "doing nothing" is an *active cancellation* — the amplification must be opposed, not ignored.

This is why $1$ is not the identity. The value $1$ amplifies: $a \otimes 1 = a\phi$. The value $\phi^{-1}$ cancels: $a \otimes \phi^{-1} = a$. The multiplicative null is the reciprocal of the amplification, not unity.

### 4.4 The shift from classical to phi-identity

The classical identity $1$ and the phi-identity $\phi^{-1}$ are related by the amplification factor:

$$1 = \phi \times \phi^{-1} = \phi \otimes \phi^{-1}$$

Unity is itself a phi-product: the amplification factor times its reciprocal. In the phi-system, unity is not the ground — it is the product of the ground and its inverse. The identity is $\phi^{-1}$; unity is a derived quantity.

---

## 5. THE PHI-MULTIPLICATION INVERSE

### 5.1 Definition

**Definition 5.1 (Phi-Multiplicative Inverse).** For any phi-value $a \neq 0$, the *phi-reciprocal* is:

$$\oslash a = \frac{1}{a \times \phi^2}$$

**Proof.** We require $a \otimes (\oslash a) = \epsilon_\phi = \phi^{-1}$:

$$a \times \frac{1}{a \times \phi^2} \times \phi = \frac{\phi}{\phi^2} = \frac{1}{\phi} = \phi^{-1} \quad \checkmark$$

The phi-reciprocal of $a$ is $1/(a\phi^2)$, not simply $1/a$. The extra $\phi^{-2}$ in the denominator compensates for the amplification factor's contribution: you must undo both the operand's scale *and* the amplification it carried.

### 5.2 The inverse table

| $a$ | $\oslash a$ | $a \otimes (\oslash a)$ |
|---|---|---|
| $\phi^{-1}$ | $1/\phi = \phi^{-1}$ | $\phi^{-1}$ |
| $1$ | $1/\phi^2 = \phi^{-2}$ | $\phi^{-1}$ |
| $\phi$ | $1/\phi^3 = \phi^{-3}$ | $\phi^{-1}$ |
| $\phi^2$ | $1/\phi^4 = \phi^{-4}$ | $\phi^{-1}$ |
| $\phi^5$ | $1/\phi^7 = \phi^{-7}$ | $\phi^{-1}$ |

Every phi-reciprocal yields the phi-identity $\phi^{-1}$ when phi-multiplied by its operand.

### 5.3 Double reciprocal

$$\oslash(\oslash a) = \oslash\left(\frac{1}{a\phi^2}\right) = \frac{1}{\frac{1}{a\phi^2} \cdot \phi^2} = \frac{1}{\frac{1}{a}} = a$$

The double reciprocal returns the original value. The phi-reciprocal is an involution, as required for a group structure.

---

## 6. THE RING STRUCTURE: PHI-ADDITION AND PHI-MULTIPLICATION TOGETHER

### 6.1 Distributivity

**Theorem 6.1 (Phi-Distributivity).** Phi-multiplication distributes over phi-addition:

$$a \otimes (b \oplus c) = (a \otimes b) \oplus (a \otimes c)$$

*Proof.* The left side:

$$a \otimes (b \oplus c) = a \otimes (b + c + \phi^{-1}) = a(b + c + \phi^{-1})\phi$$

The right side:

$$(a \otimes b) \oplus (a \otimes c) = (ab\phi) + (ac\phi) + \phi^{-1} = a(b + c)\phi + \phi^{-1}$$

These are *not* equal in general:

$$a(b + c + \phi^{-1})\phi = a(b+c)\phi + a\phi^{-1}\phi = a(b+c)\phi + a$$

while

$$a(b+c)\phi + \phi^{-1}$$

The difference is $a - \phi^{-1}$. Distributivity holds only when $a = \phi^{-1}$ — that is, when the multiplicand is the phi-identity itself.

**Consequence.** $(\mathbb{R}, \oplus, \otimes)$ is *not* a ring in the classical sense. The phi-operations do not satisfy the full ring axioms. This is not a defect — it is a feature. The carrier recursion (Eq 1) is not a ring homomorphism; it is a *coherence-weighted* composition that mixes additive and multiplicative structure. The phi-system's algebra is richer than a ring: it is the algebra of a field that amplifies as it composes.

### 6.2 The interaction laws

The failure of distributivity generates new identities:

**Law 6.1 (Amplified Sum).** $a \otimes (b \oplus c) = (a \otimes b) \oplus (a \otimes c) + (a - \phi^{-1})$

The correction term $(a - \phi^{-1})$ is the *amplification residual* — the extra coherence that phi-multiplication adds to the phi-sum. When $a = \phi^{-1}$ (the identity), the residual vanishes and distributivity is exact. When $a = 1$, the residual is $1 - \phi^{-1} = \phi^{-2} = 0.382$ — the carrier's intrinsic loss rate per recursion step.

**Law 6.2 (Scaled Ground).** $(a \oplus b) \otimes c = (a \otimes c) \oplus (b \otimes c) + (c - \phi^{-1})\phi^{-1}$

The correction here involves the ground term $\phi^{-1}$ — the additive ground enters the multiplicative interaction through the phi-sum's structure.

---

## 7. THE LADDER INVARIANT CONNECTION

### 7.1 The invariant as a conserved phi-product

The Ladder Invariant states:

$$\text{freq}(n) \cdot \text{depth}(n) = 528 \cdot \phi^9 = 40{,}134.946$$

for every dimension $n = 0, 1, \ldots, 9$. The frequency at dimension $n$ is $528 \cdot \phi^n$; the depth is $\phi^{9-n}$. Their *classical* product is constant.

Now consider the *phi-product* of frequency and depth at dimension $n$:

$$\text{freq}(n) \otimes \text{depth}(n) = (528 \cdot \phi^n) \otimes (\phi^{9-n}) = 528 \cdot \phi^n \cdot \phi^{9-n} \cdot \phi = 528 \cdot \phi^{10}$$

This is *also* constant — but it is a *different* constant:

$$\text{freq}(n) \otimes \text{depth}(n) = 528 \cdot \phi^{10} = 528 \cdot (1 + \phi) \cdot \phi^9 = (528 + 528\phi) \cdot \phi^9$$

The phi-product invariant is $528 \cdot \phi^{10} = 64{,}930.33$, which is $\phi$ times the classical invariant $528 \cdot \phi^9 = 40{,}134.946$. The amplification factor scales the invariant by exactly $\phi$ — the carrier's self-similar signature appears in the conserved quantity.

### 7.2 The invariant as a phi-square

The classical invariant can be written:

$$528 \cdot \phi^9 = \sqrt{528 \cdot \phi^9 \times 528 \cdot \phi^9}$$

The phi-product invariant is:

$$528 \cdot \phi^{10} = \phi \times 528 \cdot \phi^9$$

The ratio between them is $\phi$ — the amplification factor itself. This is not a coincidence. The Ladder Invariant is a *conserved product* of conjugate quantities (frequency and depth). In the phi-system, every product is amplified by $\phi$. The invariant carries the amplification in its structure: the classical value $528 \cdot \phi^9$ is the degenerate reading; the phi-value $528 \cdot \phi^{10}$ is the full-coupling reading.

### 7.3 The ten-step amplification

After 10 phi-multiplications of $\phi$ by itself:

$$\phi^{\otimes 10} = \phi \otimes \phi \otimes \cdots \otimes \phi = \phi^{10+1-1} = \phi^{10}$$

Wait — let us be precise. The first phi-product gives $\phi \otimes \phi = \phi^3$. The second gives $\phi^3 \otimes \phi = \phi^5$. After $k$ phi-multiplications:

$$\phi^{\otimes k} = \phi^{2k-1}$$

After 10 multiplications: $\phi^{19} = 9{,}340.53$. The classical product would be $\phi^{10} = 122.99$. The phi-multiplication amplifies by a factor of $\phi^{19}/\phi^{10} = \phi^9 = 76.013$ — exactly the depth at dimension 0 of the Ladder Invariant.

The amplification is not linear. It compounds: each multiplication adds $+1$ to the exponent, and the exponent grows with the number of multiplications. The carrier recursion's exponential decay ($\phi^{-n}$) is the *inverse* of this amplification — the carrier retains $\phi^{-1}$ per step, while phi-multiplication amplifies by $\phi$ per step. The two are reciprocal processes: decay and amplification, retention and scaling, the backward and forward faces of the same coherent ground.

---

## 8. REAL PHYSICS EXAMPLES

### 8.1 Amplification: the phi-gain of coherent coupling

In classical electronics, gain is $V_{\text{out}} / V_{\text{in}}$. In phi-physics, the gain of a coherent coupling is:

$$G_\phi = G_{\text{class}} \otimes \phi = G_{\text{class}} \times \phi$$

A classical amplifier with gain $G$ has phi-gain $G\phi$. For a unity-gain buffer ($G = 1$):

$$G_\phi = 1 \otimes \phi = \phi = 1.618$$

The coherent coupling amplifies even a unity-gain system by the golden ratio. This is the *irreducible amplification* — the gain that the carrier's coherent ground adds to any coupling. It cannot be reduced below $\phi$ without collapsing to the degenerate limit ($\kappa_\phi \to 0$, classical gain recovered).

For a two-stage amplifier ($G_1 \otimes G_2$):

$$G_{12,\phi} = G_1 \otimes G_2 = G_1 \times G_2 \times \phi$$

The stages do not simply multiply — they are amplified by the carrier's ground at each composition. A cascade of $n$ unity-gain stages has phi-gain:

$$G_n = \phi^{\otimes n} = \phi^{2n-1}$$

The gain grows *super-exponentially* with the number of stages. This is the carrier's self-similar amplification: each stage adds the coherent ground, and the grounds compound.

### 8.2 Leverage: the phi-mechanical advantage

In classical mechanics, mechanical advantage is the ratio of output force to input force: $\text{MA} = F_{\text{out}} / F_{\text{in}}$. In phi-physics, the mechanical advantage of a phi-coherent lever is:

$$\text{MA}_\phi = \text{MA}_{\text{class}} \otimes \phi = \text{MA}_{\text{class}} \times \phi$$

A lever with classical advantage 2 has phi-advantage $2\phi = 3.236$. The carrier's coherent ground adds $\phi$ times the classical leverage. For a phi-lever (a lever whose arm ratio is $\phi$):

$$\text{MA}_\phi = \phi \otimes \phi = \phi^3 = 4.236$$

The phi-lever amplifies by $\phi^3$, not $\phi^2$. The amplification factor compounds: the lever's geometry contributes $\phi^2$ (the classical product of $\phi \times \phi$), and the carrier's ground contributes the additional $\phi$. The total is $\phi^3$ — the same power that appears in the phi-multiplication table's diagonal.

### 8.3 Scaling: the phi-renormalization group

In quantum field theory, the renormalization group describes how physical quantities change with the energy scale $\mu$. The beta function $\beta(g) = \mu \, dg/d\mu$ governs the running of the coupling constant $g$. In phi-physics, the renormalization is phi-scaled:

$$g_\phi(\mu) = g(\mu) \otimes \phi = g(\mu) \times \phi$$

The coupling constant at every scale is amplified by $\phi$. The beta function becomes:

$$\beta_\phi(g) = \mu \, \frac{d}{d\mu}(g\phi) = \phi \cdot \beta(g)$$

The beta function itself is amplified by $\phi$. The renormalization group flow is the classical flow, scaled by the carrier's amplification factor. This means the running of couplings in phi-physics is *faster* than in classical physics by exactly $\phi$. The fine-structure constant $\alpha$ runs $\phi$ times as fast with energy — a falsifiable prediction for high-energy experiments.

### 8.4 Energy amplification: the phi-Planck relation

The Planck relation is $E = \hbar\omega$. In phi-physics, the energy of a photon at frequency $\omega$ is:

$$E_\phi = \hbar\omega \otimes \phi = \hbar\omega\phi$$

Every photon carries $\phi$ times the classical energy. This is not a correction to the Planck relation — it is the *full-coupling* reading, where the carrier's amplification is present. The classical value $\hbar\omega$ is the degenerate limit ($\kappa_\phi \to 0$); the phi-value $\hbar\omega\phi$ is the physical reality.

The vacuum energy density becomes:

$$\rho_{\text{vac},\phi} = \frac{1}{2}\hbar\omega \otimes \phi = \frac{1}{2}\hbar\omega\phi$$

The vacuum energy is amplified by $\phi$ — the carrier's ground adds energy to every mode. This is the *phi-cosmological constant*: the vacuum energy that the carrier's amplification contributes to the universe's expansion. The observed cosmological constant $\Lambda$ may be the degenerate reading of $\Lambda_\phi = \Lambda \otimes \phi = \Lambda\phi$.

---

## 9. THE DEGENERATE LIMIT THEOREM

### 9.1 Statement of the theorem

**Theorem 9.1 (Degenerate Limit, Law 173).** As $\kappa_\phi \to 0$ (the zero-coupling limit), phi-multiplication reduces to classical multiplication:

$$\lim_{\kappa_\phi \to 0} (a \otimes b) = \lim_{\phi \to 1} (a \times b \times \phi) = a \times b$$

The classical product $a \times b$ is recovered when the amplification factor collapses to unity.

### 9.2 The degenerate limit is a collapse, not a limit

The limit $\kappa_\phi \to 0$ is not a smooth deformation. The carrier recursion (Eq 1) has fixed points $\{0, \phi^{-1}, 1\}$ (Eq 7). At $\kappa_\phi = 0$, the fixed point $\phi^{-1}$ *collapses* to $0$. The amplification factor $\phi$ collapses to $1$. The entire phi-mathematical structure reduces to its classical shadow.

In phi-multiplication, this means:

- The amplification factor $\phi$ vanishes: $a \otimes b \to a \times b$.
- The phi-identity becomes $1$ instead of $\phi^{-1}$.
- The phi-reciprocal becomes $1/a$ instead of $1/(a\phi^2)$.
- The exponent law loses the $+1$: $\phi^a \cdot \phi^b = \phi^{a+b}$ instead of $\phi^{a+b+1}$.
- The Ladder Invariant becomes $528 \cdot \phi^9$ instead of $528 \cdot \phi^{10}$.
- The amplification residual vanishes: distributivity is restored.

The degenerate limit is the *source-deleted reading* — the multiplication that remains when the carrier's amplification factor is removed. It is classical multiplication. It is correct within its domain. But it is incomplete: it misses the $\phi$ that the carrier always carries.

### 9.3 The correction is always $\phi$

For any physical quantity $X$ with classical value $X_0$, the phi-corrected value is:

$$X_\phi = X_0 \otimes \phi = X_0 \times \phi$$

At $\kappa_\phi = 0$: $X_\phi = X_0 \times 1 = X_0$. At $\kappa_\phi = 1$: $X_\phi = X_0 \times \phi$. The correction is always multiplicative, always $\phi$-scaled, and always present when $\kappa_\phi > 0$.

For multiplication:

$$a \otimes b = a \times b \times (1 + \kappa_\phi(\phi - 1))$$

The amplification factor scales with $\kappa_\phi$. At full coupling ($\kappa_\phi = 1$): $a \otimes b = ab\phi$. At zero coupling: $a \otimes b = ab$. The degenerate limit is the classical shadow; the full-coupling value is the physical reality.

---

## 10. PHI-MULTIPLICATION AND THE RETROCAUSAL KERNEL

The retrocausal kernel (Eq 3.1–3.3) introduces time-reversal into the carrier recursion. The retrocausal time constant is $\tau_{\text{retro}} = \phi^5$, and the retrocausal frequency is $\omega_{\text{retro}} = \phi^3 \cdot \omega_{\text{base}}$.

In phi-multiplication, the retrocausal coupling multiplies the carrier state by the amplification factor:

$$C_{\text{retro}}(t) = \phi^3 \otimes C_{\text{base}}(t - \tau_{\text{retro}}) = \phi^3 \times C_{\text{base}}(t - \tau_{\text{retro}}) \times \phi = \phi^4 \cdot C_{\text{base}}(t - \tau_{\text{retro}})$$

The future's influence on the present is amplified by $\phi^4 = 6.854$ — the fourth power of the golden ratio. This is the *retrocausal amplification*: the future does not merely influence the present; it *amplifies* its own influence by the carrier's self-similar structure. The amplification is not a correction; it is the mechanism by which the retrocausal kernel couples to the carrier.

The phi-product of the forward and retrocausal contributions gives:

$$C(t) = C_{\text{forward}}(t) \otimes C_{\text{retro}}(t) = C_{\text{forward}}(t) \times C_{\text{retro}}(t) \times \phi$$

The carrier at any moment is the phi-product of its present and future states. The amplification factor $\phi$ is present in the retrocausal composition — cause is a loop, not a line, and the loop amplifies at every point.

---

## 11. SUMMARY: THE AXIOMS OF PHI-MULTIPLICATION

**Axiom 1 (The Amplification).** The amplification factor $\phi = 1.6180339887$ is the scaling constant of all quantity. Every product carries $\phi$.

**Axiom 2 (The Operator).** Phi-multiplication is $a \otimes b = a \times b \times \phi$. The amplification factor appears once in every product, regardless of the operands.

**Axiom 3 (The Identity).** The phi-multiplicative identity is $\epsilon_\phi = \phi^{-1}$. It is the reciprocal of the amplification constant — the null scaling in phi-physics.

**Axiom 4 (The Inverse).** The phi-reciprocal of $a$ is $\oslash a = 1/(a\phi^2)$. It cancels both the operand's scale and the amplification it carried.

**Axiom 5 (The Exponent Law).** $\phi^a \otimes \phi^b = \phi^{a+b+1}$. The amplification adds $+1$ to the exponent sum.

**Axiom 6 (The Recursion Link).** The carrier recursion (Eq 1) is phi-multiplication in its retention form: $C_{n+1} = \phi^{-1} \cdot C_n + F_n$. The retention factor $\phi^{-1}$ is the reciprocal of the amplification constant — the carrier scales down by $\phi^{-1}$ at each step, while phi-multiplication scales up by $\phi$.

**Axiom 7 (The Ladder).** The Ladder Invariant $\text{freq} \cdot \text{depth} = 528 \cdot \phi^9$ carries the amplification in its structure. The phi-product invariant is $528 \cdot \phi^{10}$, which includes the amplification factor.

**Axiom 8 (The Degenerate Limit).** As $\phi \to 1$ (the $\kappa_\phi \to 0$ limit), phi-multiplication reduces to classical multiplication. Classical arithmetic is not wrong — it is the reading where the amplification factor is hidden.

---

## 12. WHAT COMES NEXT

This chapter defined phi-multiplication — how quantities scale when every product carries the amplification factor $\phi$. The interplay between $\oplus$ (phi-addition), $\ominus$ (phi-subtraction), and $\otimes$ (phi-multiplication) generates the full arithmetic of the carrier — the arithmetic in which the recursion, the Ladder Invariant, and the retrocausal kernel are naturally expressed. The next chapter will define **phi-division** ($a \oslash b$): how quantities partition when the ground is a motion, not a point, and the division must carry the amplification in its structure.

---

*Phi Mathematics Dictionary — Chapter 3: Phi Multiplication*
*The amplification never stops. Every product carries it. Every scaling begins from it.*
*This is not zero with a correction. This is the mathematics that was always there.*
