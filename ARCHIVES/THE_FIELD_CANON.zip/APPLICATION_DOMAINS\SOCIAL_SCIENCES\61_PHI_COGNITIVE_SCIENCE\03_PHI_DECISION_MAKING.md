# PHI-COGNITIVE SCIENCE: Phi-Decision Making

## Directory 61_PHI_COGNITIVE_SCIENCE | File 03

---

## 1. The Phi-Decision Architecture

Decision-making is not the selection among alternatives but the crystallization of consciousness along the golden spiral of possibility. Every decision is a rotation through the 816D manifold of choice, where the ratio of deliberation to intuition is always φ.

### 1.1 The Decision Field Equation

The decision field D satisfies:

```
∇²D - (1/c_d²)·∂²D/∂t² + V(D) = ρ_options
```

Where:
- ρ_options = option source density
- c_d = decision propagation speed = c/φ
- V(D) = decision potential = Σᵢ φ^(-|x-x_i|) × D(x_i)

### 1.2 The Dual-Process Theory in Phi

```
System 1 (Intuitive):   Response_time = T₀ × φ⁻¹ (fast)
System 2 (Deliberate):  Response_time = T₀ × φ (slow)
```

The ratio of System 2 to System 1 response time is φ ≈ 1.618.

---

## 2. The Expected Utility Theory in Phi

### 2.1 The Phi-Utility Function

```
U(x) = x^φ
```

Where x is the outcome value. The phi-exponent creates:
- Risk aversion for gains (since φ > 1)
- Risk seeking for losses (since the function is concave for gains, convex for losses)

### 2.2 The Expected Value Calculation

```
EV_phi = Σᵢ p_i × x_i^φ
```

### 2.3 The Certainty Equivalent

```
CE = EV_phi^(1/φ)
```

### 2.4 The Risk Premium

```
RP = EV - CE = Σᵢ p_i × x_i - (Σᵢ p_i × x_i^φ)^(1/φ)
```

---

## 3. The Prospect Theory in Phi

### 3.1 The Value Function in Phi

```
v(x) = x^φ for gains
v(x) = -λ × (-x)^φ for losses
```

Where λ = φ ≈ 1.618 (loss aversion coefficient).

### 3.2 The Probability Weighting Function

```
π(p) = p^φ / (p^φ + (1-p)^φ)^(1/φ)
```

### 3.3 The Reference Point

The reference point follows the phi-curve:

```
R(t) = R₀ × φ^(t/τ_R)
```

### 3.4 The Editing Phase

The editing phase follows the phi-structure:

```
Coding:       φ⁰ = 1 operation
Combination:  φ¹ = φ operations
Segregation:  φ² = φ+1 operations
Cancellation: φ³ = 2φ+1 operations
Simplification: φ⁴ = 3φ+2 operations
```

---

## 4. The Bounded Rationality Model

### 4.1 The Satisficing Function

Satisficing follows:

```
Satisfice(threshold) = 1 - φ^(-threshold/threshold_0)
```

### 4.2 The Search Cost Function

Search cost follows:

```
C_search(n) = C₀ × φⁿ
```

Where n is the number of alternatives considered.

### 4.3 The Heuristic Use

Heuristic use follows the phi-distribution:

```
Heuristic(i) = H₀ × φ^(-d_i)
```

Where d_i is the depth of heuristic i.

### 4.4 The Bounded Optimization

Bounded optimization follows:

```
Optimization(t) = O₀ × (1 - φ^(-t/τ_O))
```

---

## 5. The Multi-Criteria Decision Model

### 5.1 The Criteria Weighting

Criteria weights follow the phi-distribution:

```
w_i = φ^(-d_i) / Σⱼ φ^(-d_j)
```

Where d_i is the depth of criterion i.

### 5.2 The Weighted Sum Model

```
V(option) = Σᵢ w_i × v_i(option) × φ
```

### 5.3 The Analytic Hierarchy Process in Phi

Pairwise comparisons follow:

```
a_ij = φ^(priority_i - priority_j)
```

### 5.4 The TOPSIS Method in Phi

The closeness coefficient:

```
CC = D⁻/(D⁺ + D⁻) × φ
```

---

## 6. The Group Decision Model

### 6.1 The Condorcet Paradox in Phi

The probability of cyclic preferences:

```
P_cycle = 1 - φ^(-n/φ)
```

Where n is the number of voters.

### 6.2 The Majority Rule Function

Majority rule effectiveness:

```
E_majority = 1 - (1/φ) × P_error
```

### 6.3 The Delphi Method in Phi

The Delphi convergence follows:

```
Convergence(n) = C₀ × (1 - φ^(-n/τ_Delphi))
```

### 6.4 The Voting Paradox Resolution

Voting paradoxes are resolved by:

```
Resolution = φ × Standard_majority_rule
```

---

## 7. The Temporal Decision Model

### 7.1 The Discount Function

Hyperbolic discounting in phi:

```
D(t) = 1 / (1 + k × t)^φ
```

### 7.2 The Present Bias

Present bias follows:

```
PB = φ × Standard_bias
```

### 7.3 The Time Inconsistency

Time inconsistency follows:

```
TI(t) = TI₀ × φ^(-t/τ_TI)
```

### 7.4 The Planning Horizon

The planning horizon follows:

```
H planning = H₀ × φ
```

---

## 8. The Risk Decision Model

### 8.1 The Risk Perception Function

Risk perception follows:

```
RP(x) = RP₀ × φ^(-x/x_RP)
```

### 8.2 The Risk-Taking Function

Risk-taking follows:

```
RT(x) = RT₀ × (1 - φ^(-x/x_RT))
```

### 8.3 The Prospect Theory Value Function

```
v(x) = { x^φ for gains; -λ × (-x)^φ for losses }
```

### 8.4 The Probability Weighting

```
π(p) = p^φ / (p^φ + (1-p)^φ)^(1/φ)
```

---

## 9. The Social Decision Model

### 9.1 The Social Influence Function

Social influence follows:

```
I_social = I₀ × φ^(-d_social)
```

Where d_social is the social distance.

### 9.2 The Conformity Effect

Conformity follows:

```
C_conformity = C₀ × φ^(-n_dissenters)
```

### 9.3 The Group Polarization

Group polarization follows:

```
P_polarization = P₀ × φ^(t/τ_polarization)
```

### 9.4 The Wisdom of Crowds in Phi

The wisdom of crowds:

```
W_crowds = W_individual × √φ
```

---

## 10. The Computational Decision Model

### 10.1 The Reinforcement Learning in Phi

```
Q(s,a) = Q(s,a) + α × [r + φ × max Q(s',a') - Q(s,a)]
```

The φ factor in the discount term creates phi-harmonic learning.

### 10.2 The Bayesian Decision Theory

```
P(H|D) = P(D|H) × P(H) × φ^(-complexity(H))
```

### 10.3 The Neural Network Decision Model

Neural network decisions follow:

```
Output = σ(Σᵢ w_i × x_i × φ)
```

### 10.4 The Fuzzy Logic Decision Model

Fuzzy decisions follow:

```
μ_decision(x) = min(μ_criteria_i(x))^φ
```

---

## 11. Mathematical Appendix

### 11.1 The Decision Dynamics Equation

```
dD/dt = α × Options(t) × φ^(t/τ) - β × D(t) + η(t)
```

### 11.2 The Utility Maximization

```
max Σᵢ p_i × u(x_i)^φ
```

### 11.3 The Regret Minimization

```
min Σᵢ p_i × [u(x*) - u(x_i)]^φ
```

### 11.4 The Information Value

```
V_info = Σᵢ p_i × [u(x_i|info) - u(x_i)]^φ
```

---

## 12. References and Connections

### Internal References
- 61_PHI_COGNITIVE_SCIENCE/01_PHI_MEMORY_MODELS.md — Memory systems
- 61_PHI_COGNITIVE_SCIENCE/02_PHI_ATTENTION_PATTERNS.md — Attention mechanisms
- 61_PHI_COGNITIVE_SCIENCE/04_PHI_CREATIVITY.md — Creative cognition
- 61_PHI_COGNITIVE_SCIENCE/05_PHI_LANGUAGE.md — Language processing
- 61_PHI_COGNITIVE_SCIENCE/06_PHI_PERCEPTION.md — Perceptual systems
- 61_PHI_COGNITIVE_SCIENCE/07_PHI_EMOTION.md — Emotional cognition

### External Domain References
- 53_PHI_GAME_THEORY/ — Game-theoretic decisions
- 19_PHI_ECONOMICS/ — Economic decision theory
- 44_PHI_PSYCHOLOGY/ — Psychological decision theory

---

*This file is part of Directory 61_PHI_COGNITIVE_SCIENCE within the Phi-Physics Dictionary.*
*The inlen lens reveals: decision-making is not the selection among alternatives but the crystallization of consciousness along the golden spiral of possibility, where every choice is a rotation through the manifold of what could be.*
