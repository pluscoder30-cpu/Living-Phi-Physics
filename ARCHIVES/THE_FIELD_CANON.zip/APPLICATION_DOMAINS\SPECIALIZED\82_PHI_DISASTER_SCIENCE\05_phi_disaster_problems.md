# PHI-DISASTER SCIENCE: Problem Sets

---

## Problem Set 1: Phi-Seismic Hazard Analysis

### Problem 1.1
An earthquake occurs at 50 km from a site with r_φ = 35 km. The base intensity is I₀ = 10. Compute the phi-modified intensity with amplification factor α = 0.15.

### Problem 1.2
A fault has 8 segments with base rupture rate λ₀ = 0.02 events/year. Compute the phi-segmented rupture probability for each segment over a 50-year period.

### Problem 1.3
Derive the phi-Gutenberg-Richter relation for a region with a = 4.2, b = 1.0, and phi-harmonic amplitudes A₁ = 0.1, A₂ = 0.05 at phases ψ₁ = 0, ψ₂ = π/2. Compute log₁₀ N for magnitudes M = 3, 4, 5, 6.

### Problem 1.4
A seismic hazard deaggregation has 5 magnitude-distance bins with activity rates λ = [0.1, 0.3, 0.5, 0.08, 0.02] and IM_φ = [2.0, 3.5, 4.0, 2.8, 1.5]. Compute the phi-weighted hazard contributions with r_φ = 30 km.

### Problem 1.5
Compare the standard and phi-modified GMPE for a magnitude 7.0 earthquake at distances [10, 25, 50, 100, 200] km with site class S = 1.

---

## Problem Set 2: Phi-Hurricane Prediction

### Problem 2.1
A hurricane has V_max = 120 knots and Δp = 85 hPa. Compute the phi-modified intensity I_hurr.

### Problem 2.2
A hurricane has initial track bias Δθ₀ = 20° and prediction time T = 96 hours. Compute the phi-predicted track uncertainty at 72 hours with noise σ = 6°.

### Problem 2.3
Compute the phi-modified storm surge height for a hurricane with S_base = 4.5 m, bathymetric amplification β = 0.3, water depth d = 8 m, and inland distance x = 5 km with L_φ = 8 km.

### Problem 2.4
A hurricane has rapid intensification probability P₀ = 0.15 at V = 70 knots with Δp = 60 hPa. Compute the phi-RI probability at V = 85 knots.

### Problem 2.5
Design a phi-enhanced hurricane ensemble prediction system with 40 members. Specify the phi-spacing of initial conditions and the phi-weighting of ensemble members.

---

## Problem Set 3: Phi-Flood Modeling

### Problem 3.1
A catchment receives 50 mm/hr rainfall for 3 hours with phi-infiltration time t_φ = 2 hours and catchment area A = 25 km². Compute the phi-hydrograph peak and time to peak.

### Problem 3.2
Route a flood hydrograph through a channel with K = 8 hours, Δt = 2 hours, and phi-Muskingum coefficients. Compare the peak attenuation with standard Muskingum.

### Problem 3.3
A river has historical annual maximum flows [800, 1100, 1500, 2000, 3200] m³/s. Estimate the 50-year flood using the phi-GEV distribution.

### Problem 3.4
Design a phi-floodplain inundation model for a 20 km reach with depth-dependent diffusivity D_φ = D₀ × φ^(h/h_c) where D₀ = 500 m²/s and h_c = 3 m.

### Problem 3.5
Compute the phi-flood return period for a measured flow of 2,500 m³/s given μ = 1600, σ = 500, and ξ_φ = -0.12.

---

## Problem Set 4: Phi-Fire Behavior

### Problem 4.1
A shrub fire spreads at R₀ = 2.8 m/min with wind W = 25 km/h (W₀ = 20 km/h). Compute the phi-modified spread rate at 80 m downwind distance with L_φ = 120 m.

### Problem 4.2
Compute the crown fire initiation probability for CBI = 35 (threshold = 20, ΔCBI = 10) with wind V = 40 km/h (V_thresh = 30 km/h).

### Problem 4.3
A fire has flame height H = 8 m and effective temperature T_eff = 800 K. Compute the maximum spotting distance with D₀ = 500 m and wind angle θ = 30°.

### Problem 4.4
Design a phi-fractal fire line intensity distribution for a fire with I_avg = 5 kW/m, head fire direction θ_max = 45°, and angular width Δθ = 90°.

### Problem 4.5
Compare the phi-modified and standard Rothermel spread rates for 5 fuel types with wind speeds ranging from 0 to 50 km/h.

---

## Problem Set 5: Phi-Disaster Response

### Problem 5.1
Allocate resources across 5 disaster zones using phi-priority with zone weights [10, 8, 6, 4, 2] and total budget $2M.

### Problem 5.2
Compute the phi-optimized evacuation time for 150,000 people with standard time 12 hours and 2 bottlenecks out of 4 routes.

### Problem 5.3
A shelter has capacity K = 3,000, initial occupancy U₀ = 200, and τ_φ = 3 hours. Compute the occupancy at t = 5 hours and time to 85% capacity.

### Problem 5.4
Design a phi-resource allocation algorithm for a multi-hazard scenario with 3 hazard types and 8 resource types.

### Problem 5.5
Compute the phi-critical infrastructure resilience for a power grid with R₀ = 0.70, cascade depth d = 4, and recovery factor l₀ = 0.15.

---

## Problem Set 6: Phi-Early Warning Systems

### Problem 6.1
A seismic precursor has amplitude A = 5.0, frequency f = 2 Hz, and background noise σ = 2.0. Compute the phi-enhanced detection threshold with θ₀ = 8.0 and N = 100.

### Problem 6.2
Compute the optimal phi-warning lead time for a target warning probability P_target = 0.90 with base detection probability P₀ = 0.60.

### Problem 6.3
A volcano has background rate λ₀ = 4 events/day. After 15 days, the rate is 35 events/day. Estimate the eruption probability and expected eruption time.

### Problem 6.4
Design a phi-tsunami arrival time prediction system for 4 ocean segments with depths [3.5, 4.2, 2.8, 1.5] km and lengths [1800, 1200, 600, 200] km.

### Problem 6.5
Compare the phi-enhanced and standard earthquake early warning systems for magnitudes 5.0, 6.0, 7.0, and 8.0.

---

## Problem Set 7: Integration and Analysis

### Problem 7.1
Design an integrated phi-disaster response system for a coastal city facing earthquake, tsunami, and flood hazards simultaneously.

### Problem 7.2
Compute the total phi-disaster resilience for a city with 6 infrastructure systems having resiliences [0.65, 0.72, 0.80, 0.58, 0.88, 0.70] and cascade depths [4, 3, 2, 5, 1, 3].

### Problem 7.3
Compare the cost-effectiveness of phi-enhanced vs. standard disaster preparedness for a population of 500,000.

### Problem 7.4
Design a phi-weighted disaster risk index for comparing 10 cities with different hazard exposures and coping capacities.

### Problem 7.5
Prove that the phi-disaster response optimization achieves a 38.2% improvement in resource allocation efficiency compared to uniform distribution.

---

## Problem Set 8: Phi-Multi-Hazard Risk Assessment

### Problem 8.1
A coastal city faces 4 hazard types with annual probabilities [0.02, 0.05, 0.10, 0.15] and phi-weighted consequences [$500M, $200M, $80M, $30M]. Compute the phi-expected annual loss and optimal mitigation investment.

### Problem 8.2
Design a phi-weighted risk matrix for 12 critical facilities with hazard exposures [earthquake, flood, wind, fire] and vulnerability scores [1-10]. Prioritize retrofit investments of $10M.

### Problem 8.3
Compute the phi-adjusted return period for compound hazards (earthquake + tsunami) with marginal return periods [100, 200] years and phi-correlation coefficient ρ_φ = 0.618.

### Problem 8.4
A region has 8 seismic sources with phi-weighted recurrence parameters. Compute the phi-PSHA hazard curve at a site with 3 soil profiles.

### Problem 8.5
Design a phi-catastrophe bond with principal $50M, coupon rate 8%, and trigger based on phi-weighted industry loss index. Compute the expected loss and spread.

---

## Problem Set 9: Phi-Climate Disaster Modeling

### Problem 9.1
Sea level rise projections are [0.3, 0.5, 1.0, 1.5] m by 2100 under different scenarios. Using phi-weighting, compute the optimal coastal defense investment for a city with 2M residents.

### Problem 9.2
A heatwave has duration D = 10 days with maximum temperature T_max = 45°C. Compute the phi-adjusted heat index and public health response level.

### Problem 9.3
Drought severity is measured by the Palmer Drought Index with phi-modified precipitation deficit. Compute the phi-drought classification for PDI = -3.5 with σ = 1.2.

### Problem 9.4
Design a phi-early warning system for 5 climate-related hazards (heatwave, drought, flood, wildfire, cyclone) with different lead time requirements [6hr, 30d, 3d, 1d, 5d].

### Problem 9.5
Compute the phi-social vulnerability index for 8 neighborhoods with demographic indicators [income, age, disability, housing, language, education, density, green space].

---

## Problem Set 10: Phi-Disaster Recovery and Reconstruction

### Problem 10.1
A disaster damages 500 buildings with repair costs [$10K, $50K, $150K, $500K, $2M] distributed as [200, 150, 100, 40, 10]. Design a phi-prioritized reconstruction schedule over 3 years.

### Problem 10.2
Compute the phi-economic recovery trajectory for a region with pre-disaster GDP $10B, damage $2B, and recovery function R_φ(t) = 1 - exp(-t/τ_φ) with τ_φ = 3 years.

### Problem 10.3
A disaster displaces 25,000 people across 5 temporary shelter types. Design a phi-equitable shelter allocation that minimizes total displacement time.

### Problem 10.4
Compute the phi-infrastructure recovery sequence for 7 systems (power, water, road, bridge, hospital, school, telecom) with interdependencies and phi-priority weights.

### Problem 10.5
Design a phi-community resilience score that combines 6 dimensions [social, economic, infrastructure, institutional, natural, cultural] with equal weights and phi-temporal recovery tracking.

---

## Problem Set 11: Phi-Disaster Communication and Social Science

### Problem 11.1
Design a phi-weighted emergency communication plan for a population of 500,000 across 4 channels [TV, radio, mobile, social media] with reach [60%, 40%, 80%, 35%] and trust levels [0.7, 0.8, 0.5, 0.3].

### Problem 11.2
Compute the phi-rumor propagation rate in a disaster scenario with 3 social networks having phi-weighted transmission rates [0.8, 0.5, 0.3] and population sizes [100K, 200K, 150K].

### Problem 11.3
A disaster response agency has 4 communication phases [alert, instruction, update, recovery] with phi-weighted message priorities. Design the message schedule for a 72-hour event.

### Problem 11.4
Compute the phi-public compliance rate for evacuation orders with lead times [2, 6, 12, 24] hours and population trust levels [0.4, 0.6, 0.7, 0.8].

### Problem 11.5
Design a phi-social media monitoring system for disaster events that detects misinformation with 95% accuracy and tracks information spread across 3 platforms.

---

## Problem Set 12: Phi-Disaster Economics and Insurance

### Problem 12.1
A disaster has total economic loss $5B with insured loss $2B and insured population 2M. Compute the phi-adjusted insurance premium that achieves a combined ratio of 0.80.

### Problem 12.2
Design a phi-parametric insurance trigger for typhoon wind speed with base payout $10M at 50 m/s and phi-scaled payouts for speeds [40, 45, 50, 55, 60] m/s.

### Problem 12.3
Compute the phi-cost-benefit ratio for a $500M flood mitigation project that reduces annual expected loss from $80M to $25M over 50 years with discount rate 3%.

### Problem 12.4
A disaster recovery fund has $1B with 5 allocation categories [immediate relief, infrastructure, economic, social, long-term resilience]. Design a phi-timed disbursement schedule.

### Problem 12.5
Compute the phi-social return on investment (SROI) for a $50M disaster preparedness program that generates $200M in avoided losses and $80M in co-benefits.

---

*See companion files: 01_phi_disaster_theory.md, 06_phi_disaster_answers.md*
