# PHI-PHOTOGRAPHY

## 1. PHI-Photography Principles

### 1.1 The Golden Ratio in Lens Design

Camera lenses encode phi in their optical design. The relationship between focal length and sensor size, the arrangement of lens elements, and the geometry of light paths all benefit from golden-ratio proportions.

### 1.2 PHI-Sensor Dimensions

```
Standard sensor sizes:
  Full frame: 36 x 24 mm (ratio 1.500)
  APS-C: 23.5 x 15.6 mm (ratio 1.506)
  Micro Four Thirds: 17.3 x 13 mm (ratio 1.331)
  
PHI-sensor dimensions:
  Width = H x phi
  For H = 24 mm: W = 38.8 mm
  For H = 15.6 mm: W = 25.3 mm
  For H = 13 mm: W = 21.0 mm
  
  The phi-sensor captures images with inherent phi-proportions
```

### 1.3 PHI-Focal Length Relationships

```
The "normal" focal length approximates the sensor diagonal:
  Full frame diagonal: sqrt(36^2 + 24^2) = 43.3 mm
  Standard "normal": 50 mm (close to diagonal)
  
PHI-focal lengths:
  Normal: 43.3 mm (sensor diagonal)
  Wide: 43.3/phi = 26.8 mm
  Tele: 43.3 x phi = 70.1 mm
  Super tele: 43.3 x phi^2 = 113.4 mm
  
  Each step multiplies by phi, creating a natural
  progression from wide to telephoto
```

## 2. PHI-Composition Techniques

### 2.1 The PHI-Grid

```
Standard rule of thirds:
  Lines at 1/3 and 2/3 of frame
  = 0.333 and 0.667 of frame
  
PHI-grid:
  Lines at 1/phi and 1/phi^2 of frame
  = 0.618 and 0.382 of frame

For a 3:2 frame (36 x 24 cm):
  Rule of thirds: lines at 12 and 24 cm from left
  PHI-grid: lines at 22.3 and 13.7 cm from left
  
  The PHI-lines are offset toward the center,
  creating a more centralized composition
```

### 2.2 The PHI-Spiral

```
Applying the golden spiral to a photograph:

1. Start with the phi-rectangle of the frame
2. Remove a square from one end
3. Continue removing squares, each time from the remaining rectangle
4. Draw quarter-circle arcs through each square's corners
5. The resulting spiral guides the eye through the composition

Placement along spiral:
  Subject: at the spiral's terminus (smallest square)
  Leading elements: along the spiral's curve
  Background: follows the spiral's direction
```

### 2.3 PHI-Diagonal Method

```
The PHI-diagonal creates dynamic compositions:

Diagonal from corner to corner:
  Angle = arctan(H/W) = arctan(24/36) = 33.7 degrees

Parallel PHI-diagonals:
  Start from each corner
  Draw lines at 33.7 degrees
  These create phi-triangles within the frame
  
Subject placement:
  On the diagonal: creates movement
  At diagonal intersection: creates focus
  Off the diagonal: creates tension
```

## 3. Landscape PHI-Photography

### 3.1 Horizon Placement

```
Standard horizon: at center (50% of frame)
Rule of thirds horizon: at 33% or 67% of frame
PHI-horizon: at 38.2% or 61.8% of frame

For a frame with sky and ground:
  Sky-dominant: horizon at 38.2% from bottom
    (sky occupies 61.8% of frame)
  Ground-dominant: horizon at 61.8% from bottom
    (ground occupies 61.8% of frame)
```

### 3.2 Foreground Interest

```
PHI-Foreground placement:

Foreground element distance from camera:
  Near: 1/phi of total scene depth
  Mid: 1/phi^2 of total scene depth
  Far: 1/phi^3 of total scene depth

Example (scene depth = 100 m):
  Near foreground: 61.8 m from camera
  Mid-ground: 38.2 m from camera
  Far background: 23.6 m from camera
  
  These distances create natural depth layers
  that the eye can distinguish and appreciate
```

### 3.3 Golden Hour Timing

```
PHI-Golden hour timing:

Sunrise to sunset: approximately 12 hours
Golden hour: 1/phi of total daylight = 12/phi = 7.4 hours

But the "photographic golden hour" is shorter:
  Best light: 1/phi^2 of golden hour = 7.4/phi = 4.6 hours
  
  Divided into:
    Morning golden: sunrise to sunrise + 4.6 hours
    Evening golden: sunset - 4.6 hours to sunset
    
  The phi-division creates two windows of optimal light
  rather than one continuous period
```

## 4. Portrait PHI-Photography

### 4.1 Head Position

```
PHI-Portrait head placement:

Face center: at phi-intersection (61.8% from left, 38.2% from top)

Eyes at phi-lines:
  Eye line: 38.2% from top of frame
  (Standard: 33% from top — the phi-position is slightly lower)

Chin position: 
  Chin to eye line : Eye line to top = 1 : phi
  = 38.2% : 61.8% of face height
  
  The face occupies the upper phi-portion of the frame,
  with the body extending below
```

### 4.2 Body Proportions

```
PHI-Portrait body framing:

Head-to-waist (medium shot): 61.8% of frame height
Head-to-knees (cowboy shot): 100% of frame height (full figure)

For a medium shot (frame height = 100 cm):
  Head position: 38.2 cm from top (face centered here)
  Waist position: 100 cm from top (bottom of frame)
  
  Head-to-waist = 61.8 cm
  Head-to-top = 38.2 cm
  Ratio: 61.8/38.2 = 1.618 = phi
```

### 4.3 Eye Contact and PHI

```
Direct eye contact creates connection;
phi-positioned eyes create optimal connection:

Eye separation: 6.3 cm (average)
Face width: 14.5 cm (average)
Eye separation/Face width = 6.3/14.5 = 0.434

For phi-proportioned face:
  Face width: W
  Eye separation: W/phi = 0.618W
  (Wider than natural — creates an alien, captivating look)
  
  Or: Eye separation: W/phi^2 = 0.382W
  (Narrower than natural — creates a concentrated, intense look)
```

## 5. Street PHI-Photography

### 5.1 Decisive Moment

```
PHI-Decisive moment timing:

Action sequence duration: T seconds
Optimal capture moment: T/phi seconds into sequence

Example:
  Person walking through frame: 2-second window
  Optimal capture: 2/phi = 1.24 seconds after entry
  
  The phi-moment is past the midpoint but before the end,
  capturing the peak of action while maintaining context
```

### 5.2 Layering

```
PHI-Street layering:

Layer 1 (foreground): 38.2% of frame depth
  Subject or framing element
  
Layer 2 (middle): 23.6% of frame depth
  Main action or secondary subject
  
Layer 3 (background): 38.2% of frame depth
  Context and environment

The phi-layers create depth without clutter,
with the middle layer being the narrowest
(highest concentration of interest)
```

### 5.3 Geometry

```
PHI-Street geometry:

Leading lines: streets, sidewalks, building edges
  Converge at phi-point in frame
  
Frame within frame: doorways, windows, arches
  Inner frame : Outer frame = 1 : phi
  
  Example:
    Outer frame (doorway): 200 cm
    Inner frame (person in doorway): 200/phi = 123.6 cm
    The person fits naturally within the phi-frame
```

## 6. PHI-Macro Photography

### 6.1 Magnification Ratios

```
PHI-Macro magnification:

Standard macro: 1:1 (life-size)
PHI-macro: phi:1 = 1.618:1 (magnified)
PHI-micro: phi^2:1 = 2.618:1 (highly magnified)

For a subject of 2 cm:
  Standard: 2 cm fills frame
  PHI-macro: 2/phi = 1.24 cm fills frame (more detail visible)
  PHI-micro: 2/phi^2 = 0.76 cm fills frame (maximum detail)
```

### 6.2 Focus Stacking

```
PHI-Focus stacking:

Number of focus layers: F(n) (Fibonacci number)
  Minimum: 5 layers
  Optimal: 8 or 13 layers
  
Focus increment: 1/phi mm = 0.618 mm per layer

For 8 layers:
  Layer 1: 0.000 mm (nearest)
  Layer 2: 0.618 mm
  Layer 3: 1.236 mm
  Layer 4: 1.854 mm
  Layer 5: 2.472 mm
  Layer 6: 3.090 mm
  Layer 7: 3.708 mm
  Layer 8: 4.326 mm (furthest)
  
  Total depth: 4.326 mm (phi^2 mm)
```

### 6.3 Subject Placement

```
PHI-Macro subject placement:

Subject center: at phi-intersection
Subject size: 61.8% of frame (phi/total)
Negative space: 38.2% of frame (1/phi of total)

For a flower filling 61.8% of frame:
  Flower width: 61.8% of frame width
  Stem and leaves: remaining 38.2%
  
  The phi-division ensures the subject dominates
  while background provides context
```

## 7. PHI-Black and White Photography

### 7.1 Tonality

```
PHI-Tonal distribution:

Total tonal range: 0 (black) to 255 (white)
PHI-tonal points:
  Black: 0
  Shadow: 255/phi^3 = 59.5
  Dark mid: 255/phi^2 = 96.5
  Light mid: 255/phi = 157.8
  Highlight: 255 - 255/phi^3 = 195.5
  White: 255

The phi-tonal points create natural zones:
  Deep shadows: 0-59.5 (23.3% of range)
  Shadows: 59.5-96.5 (14.5% of range)
  Mids: 96.5-157.8 (24.0% of range)
  Highlights: 157.8-195.5 (14.8% of range)
  Brights: 195.5-255 (23.3% of range)
```

### 7.2 Contrast

```
PHI-Contrast settings:

Standard contrast: linear
PHI-contrast: S-curve with phi-inflection

S-curve inflection points:
  Lower inflection: 255/phi^2 = 96.5
  Upper inflection: 255 - 255/phi^2 = 158.5
  
  Below lower inflection: shadows compressed
  Between inflections: midtones expanded (maximum contrast)
  Above upper inflection: highlights compressed
  
  The phi-inflection creates a natural contrast
  that emphasizes midtones while preserving detail
```

### 7.3 Zone System PHI

```
Ansel Adams' Zone System with phi:

10 zones (0-IX):
  Zone 0: Black (0)
  Zone I: Near black (25)
  Zone II: Dark tone (51)
  Zone III: Dark shadow (77)
  Zone IV: Middle shadow (102)
  Zone V: Middle gray (128)
  Zone VI: Light skin (153)
  Zone VII: Light tone (179)
  Zone VIII: Near white (204)
  Zone IX: White (230)

PHI-Zones (compressed to 7):
  Zone 0: Black (0)
  Zone I: Dark (255/phi^3 = 59)
  Zone II: Shadow (255/phi^2 = 97)
  Zone III: Mid (128)
  Zone IV: Light (255 - 255/phi^2 = 158)
  Zone V: Highlight (255 - 255/phi^3 = 195)
  Zone VI: White (255)
  
  The 7 PHI-zones (Fibonacci number) create a natural
  tonal scale that is denser in the midtones
```

## 8. PHI-Digital Processing

### 8.1 Crop Ratios

```
PHI-Crop ratios:

Original: 3:2 (standard DSLR)
PHI-crop 1: 5:3 = 1.667 (error from phi: 3.0%)
PHI-crop 2: 8:5 = 1.600 (error from phi: 1.1%)
PHI-crop 3: 13:8 = 1.625 (error from phi: 0.4%)
PHI-crop 4: 21:13 = 1.615 (error from phi: 0.2%)

For a 6000 x 4000 pixel image:
  PHI-crop 1: 6000 x 3600 pixels (5:3)
  PHI-crop 2: 6000 x 3750 pixels (8:5)
  PHI-crop 3: 6000 x 3692 pixels (13:8)
  PHI-crop 4: 6000 x 3714 pixels (21:13)
```

### 8.2 Resolution and Output

```
PHI-Print sizes:

Standard print: 8 x 10 inches (ratio 1.250)
PHI-print: 8 x 12.94 inches (ratio 1.618)

For A4 paper (210 x 297 mm):
  PHI-A4: 210 x 340 mm (ratio 1.619)
  
  Printable area with margins:
    Top: 210/phi^2 = 80 mm
    Bottom: 210/phi^3 = 49 mm
    Left: 340/phi = 210 mm (full width)
    Right: 340/phi^2 = 80 mm
    Print area: 210 - 80 - 49 = 81 mm wide (too narrow)
    
  Better approach:
    Margins: 20 mm all sides
    Print area: 170 x 300 mm
    Ratio: 300/170 = 1.765 (not phi)
    
  PHI-margins:
    Top/bottom: 20 mm
    Left/right: 20 x phi = 32.4 mm
    Print area: 210 - 64.8 = 145.2 x 297 - 40 = 257 mm
    Ratio: 257/145.2 = 1.770 (not phi)
```

### 8.3 File Organization

```
PHI-File naming convention:

Project folder: PROJECT_NAME
  01_RAW/ (Fibonacci number: 1 folder)
  02_SELECTS/ (phi of 01_RAW count)
  03_EDITED/ (phi of 02_SELECTS count)
  04_FINAL/ (phi of 03_EDITED count)

Example:
  01_RAW: 100 images
  02_SELECTS: 100/phi = 62 images
  03_EDITED: 62/phi = 38 images
  04_FINAL: 38/phi = 23 images
  
  The phi-filtering creates a natural curation process
```

## 9. PHI-Camera Settings

### 9.1 Exposure Triangle

```
PHI-Exposure settings:

Aperture: f-numbers at phi-intervals
  Standard: f/1.4, f/2, f/2.8, f/4, f/5.6, f/8, f/11, f/16
  PHI: f/1.4, f/2.3, f/3.7, f/5.9, f/9.6, f/15.5, f/25.1
  
  Where each f-number = previous x phi
  
  PHI-aperture creates a natural progression of depth-of-field

Shutter speed: phi-intervals
  Standard: 1/30, 1/60, 1/125, 1/250, 1/500, 1/1000
  PHI: 1/30, 1/49, 1/79, 1/128, 1/207, 1/335
  
  Where each speed = previous / phi

ISO: phi-intervals
  Standard: 100, 200, 400, 800, 1600, 3200
  PHI: 100, 162, 262, 424, 686, 1109
  
  Where each ISO = previous x phi
```

### 9.2 White Balance

```
PHI-White balance:

Color temperature scale:
  Candle: 1800 K
  Tungsten: 3200 K
  Fluorescent: 4000 K
  Daylight: 5500 K
  Shade: 7000 K
  Cloudy: 8000 K
  Overcast: 10000 K

PHI-color temperatures:
  Warm: 3200 K
  Neutral: 3200 x phi = 5178 K
  Cool: 5178 x phi = 8378 K
  
  The phi-temperatures create three natural white balance settings
```

## References

- Freeman, M. (2007). "The Photographer's Eye"
-aura, B. (2010). "Understanding Composition"
- Barnbaum, B. (2010). "The Art, Science, and Craft of Great Landscape Photography"
- Hedgecoe, J. (2009). "The New Complete Guide to Photography"
- Johnson, H. (2012). "Mastering Composition"
