# PHI-Market Microstructure: Golden Ratio Order Flow

## Directory 90_PHI_FINANCIAL_ENGINEERING | File 05

---

## 1. PHI-Order Book Dynamics

### 1.1 PHI-Order Arrivals

```
lambda_phi = lambda_base * phi^{price_distance/S_ref}
```

### 1.2 PHI-Order Size Distribution

```
P(size = s) ~ s^{-alpha} * phi^{-s/s_phi}
s_phi = s_ref * phi^{market_cap/mcap_ref}
```

### 1.3 PHI-Order Lifetime

```
P(lifetime > t) = phi^{-t/t_phi}
t_phi = t_ref * phi^{spread/spread_ref}
```

### 1.4 PHI-Cancellation Rates

```
cancel_rate = cancel_base * phi^{profit_loss_ratio}
```

---

## 2. PHI-Price Impact

### 2.1 PHI-Almgren-Chriss

```
Permanent_impact = sigma * sqrt(volume) * phi^{trade_size/ADV}
Temporary_impact = gamma * (trade_rate)^(2/phi)
```

### 2.2 PHI-Kyle's Lambda

```
lambda_kyle = sigma * phi^{-1/2} / sqrt(volume)
```

### 2.3 PHI-Impact Decay

```
Impact(t) = Impact_0 * phi^{-t/tau_impact}
```

### 2.4 PHI-Nonlinear Impact

```
Impact = gamma * sign(trade) * |trade|^{1/phi}
```

---

## 3. PHI-Spread Decomposition

### 3.1 PHI-Adverse Selection Component

```
Spread_adv = alpha_phi * sigma * sqrt(omega)
alpha_phi = alpha * phi^{informed_trader_fraction}
```

### 3.2 PHI-Inventory Component

```
Spread_inv = gamma * phi^{inventory/position_limit} * (2*inventory)
```

### 3.3 PHI-Order Processing Component

```
Spread_fixed = cost_fixed * phi^{-competition/comp_ref}
```

### 3.4 PHI-Optimal Spread

```
Spread* = Spread_adv + Spread_inv + Spread_fixed
```

---

## 4. PHI-Liquidity Measures

### 4.1 PHI-Amihud Illiquidity

```
ILLIQ_phi = (1/D) * sum_{d=1}^{D} |r_d| / volume_d * phi^{|r_d|/sigma}
```

### 4.2 PHI-Bid-Ask Spread

```
Spread_phi = (Ask - Bid) / Mid * phi^{volatility}
```

### 4.3 PHI-Market Depth

```
Depth_phi = sum_{k=1}^{K} size_k * phi^{-k}
```

### 4.4 PHI-Resilience

```
Resilience_phi = 1 / tau_recovery * phi^{spread/spread_ref}
```

---

## 5. PHI-Information Asymmetry

### 5.1 PHI-VPIN

```
VPIN_phi = (volume_buy - volume_sell) / volume_total * phi^{trade_imbalance}
```

### 5.2 PHI-Kyle's Lambda

```
lambda_phi = Cov(Delta p, trade_sign) * phi^{information_ratio}
```

### 5.3 PHI-Probability of Informed Trading

```
PIN_phi = (alpha * mu) / (alpha * mu + 2*epsilon) * phi^{arrival_rate}
```

### 5.4 PHI-Toxicity Measure

```
Toxicity = |signed_volume| / total_volume * phi^{price_move}
```

---

## 6. PHI-Market Making Models

### 6.1 PHI-Avellaneda-Stoikov

```
Optimal_quote = mid + gamma * sigma^2 * (T-t) * phi^{inventory}
Spread = gamma * sigma^2 * (T-t) + (2/gamma) * ln(1 + gamma/kappa)
```

### 6.2 PHI-Gueant-Lehalle

```
Optimal_bid = q + gamma * sigma^2 * phi^{position} * (T-t)
Optimal_ask = q + gamma * sigma^2 * phi^{-position} * (T-t) + spread
```

### 6.3 PHI-Ho-Stoll

```
Spread = (2 / (k-1)) * phi^{inventory_cost}
Quotation_size = base_size * phi^{-inventory/position_limit}
```

---

## 7. PHI-Trade Classification

### 7.1 PHI-Buy-Sell Classification

```
Buy = trade if (price > prev_price) OR (price == prev_price AND size > prev_size * phi)
Sell = trade if (price < prev_price) OR (price == prev_price AND size < prev_size / phi)
```

### 7.2 PHI-Volume Clock

```
Volume_clock(t) = sum_{s=1}^{t} volume_s / ADV * phi^{volume_s/ADV}
```

### 7.3 PHI-Tick Data Processing

```
Aggregation_interval = 1 second * phi^{tick_frequency}
```

---

## 8. PHI-Cross-Market Dynamics

### 8.1 PHI-Lead-Lag

```
Lead_lag = argmax_tau Cov(r_t^A, r_{t+tau}^B) * phi^{|tau|}
```

### 8.2 PHI-Arbitrage Bounds

```
|Price_A - Price_B| <= transaction_cost + phi^{settlement_risk}
```

### 8.3 PHI-Market Contagion

```
Contagion = 1 - phi^{-cross_market_correlation}
```

---

## 9. PHI-Regulatory Impact

### 9.1 PHI-Market Maker Obligations

```
Quoting_obligation = 1 / phi^{spread_limit}
```

### 9.2 PHI-HFT Regulation

```
Tax_HFT = fee * phi^{trade_frequency}
```

### 9.3 PHI-Market Structure

```
Competition = phi^{-concentration_ratio}
```

---

## 10. Summary

PHI-market microstructure provides:
1. PHI-order book with phi-arrival rates and phi-size distributions
2. PHI-price impact with nonlinear phi-scaling
3. PHI-spread decomposition with phi-components
4. PHI-liquidity measures with phi-illiquidity
5. PHI-information asymmetry with phi-PIN and phi-VPIN
6. PHI-market making with phi-optimal quotes
7. PHI-trade classification with phi-volume clock
8. PHI-cross-market dynamics with phi-lead-lag

The golden ratio captures the fractal nature of order flow and the self-similar structure of price impact across time scales.