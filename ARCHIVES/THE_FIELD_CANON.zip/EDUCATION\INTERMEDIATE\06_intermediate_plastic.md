# 06 — The Plastic Number (ψ) | Intermediate Level

## Ages 13–16 | Algebraic Foundations

---

## 1. Definition

The plastic number ψ (psi) is defined as the real root of:

```
x³ − x − 1 = 0
```

Its decimal value is:

```
ψ ≈ 1.3247179572...
```

The plastic number was named by Dom Hans van der Laan in 1928. It is the
smallest Pisot number and plays a role in three-dimensional geometry
analogous to the golden ratio's role in two dimensions.

---

## 2. Algebraic Properties

**The plastic number is the unique real root of x³ − x − 1 = 0.**

Unlike φ (quadratic), ψ satisfies a cubic equation, making it algebraically
more complex.

The three roots of x³ − x − 1 = 0 are:

```
x₁ = ψ ≈ 1.3247179572  (real)
x₂ ≈ −0.6624 + 0.5623i  (complex)
x₃ ≈ −0.6624 − 0.5623i  (complex conjugate)
```

---

## 3. The Minimal Polynomial: x³ = x + 1

**Claim:** ψ³ = ψ + 1

**Proof:**

Since ψ satisfies x³ − x − 1 = 0:

```
ψ³ − ψ − 1 = 0
ψ³ = ψ + 1  ✓
```

This is the defining identity, analogous to φ² = φ + 1.

---

## 4. Powers of ψ

Using ψ³ = ψ + 1, we can reduce higher powers:

```
ψ⁴ = ψ · ψ³ = ψ(ψ + 1) = ψ² + ψ

ψ⁵ = ψ · ψ⁴ = ψ(ψ² + ψ) = ψ³ + ψ² = (ψ + 1) + ψ² = ψ² + ψ + 1

ψ⁶ = ψ · ψ⁵ = ψ(ψ² + ψ + 1) = ψ³ + ψ² + ψ
   = (ψ + 1) + ψ² + ψ = ψ² + 2ψ + 1
```

General pattern: ψⁿ can be expressed as aₙψ² + bₙψ + cₙ.

---

## 5. Padovan Sequence Connection

The Padovan sequence is defined by:

```
P(0) = P(1) = P(2) = 1
P(n) = P(n−2) + P(n−3)  for n ≥ 3
```

First few terms:

```
P(0) = 1
P(1) = 1
P(2) = 1
P(3) = P(1) + P(0) = 2
P(4) = P(2) + P(1) = 2
P(5) = P(3) + P(2) = 3
P(6) = P(4) + P(3) = 4
P(7) = P(5) + P(4) = 5
P(8) = P(6) + P(5) = 7
P(9) = P(7) + P(6) = 9
P(10) = P(8) + P(7) = 12
P(11) = P(9) + P(8) = 16
P(12) = P(10) + P(9) = 21
```

**Theorem:** P(n+1)/P(n) → ψ as n → ∞.

**Proof sketch:** Assume P(n+1)/P(n) → L. Then:

```
P(n+1) = P(n−1) + P(n−2)

P(n+1)/P(n) = P(n−1)/P(n) + P(n−2)/P(n)

As n → ∞: L = 1/L + 1/L²

Multiply by L²: L³ = L + 1
               L³ − L − 1 = 0

Positive root: L = ψ  ✓
```

---

## 6. Plastic Number and 3D Geometry

The plastic number governs the proportions of the "plastic solid" (a
three-dimensional analogue of the golden rectangle):

```
Plastic solid: a cube with two square faces and four rectangular faces
The ratio of dimensions involves ψ:
  Width : Height : Depth = ψ : 1 : 1/ψ
```

The plastic solid has the property that removing a cube from it leaves
a smaller plastic solid, just as removing a square from a golden rectangle
leaves a smaller golden rectangle.

---

## 7. Pisot Number Property

The plastic number is the smallest Pisot number. A Pisot number is a real
algebraic integer > 1 whose other conjugate roots all have absolute value < 1.

For ψ:

```
|ψ| ≈ 1.3247  (> 1)
|x₂| ≈ |x₃| ≈ 0.8688  (< 1)
```

This means ψⁿ approaches integers as n grows:

```
ψ¹ ≈ 1.3247
ψ² ≈ 1.7549
ψ³ ≈ 2.3247
ψ⁴ ≈ 3.0796
ψ⁵ ≈ 4.0796
ψ⁶ ≈ 5.4043
```

The nearest integers are: 1, 2, 2, 3, 4, 5, 7, 9, 12, 16, 21, ... — the
Padovan sequence!

---

## 8. Continued Fraction of ψ

```
ψ = [1; 3, 12, 1, 1, 3, 2, 3, 2, 4, ...]
```

Unlike φ and δₛ, the continued fraction of ψ is NOT periodic. This reflects
the fact that ψ satisfies a cubic (not quadratic) equation.

---

## 9. Binet-like Formula for Padovan Numbers

```
P(n) = a·ψⁿ + b·x₂ⁿ + c·x₃ⁿ
```

where a, b, c are constants determined by the initial conditions, and x₂, x₃
are the complex conjugate roots.

Since |x₂|, |x₃| < 1, the terms b·x₂ⁿ and c·x₃ⁿ → 0 as n → ∞. So:

```
P(n) ≈ a·ψⁿ for large n
```

The Padovan sequence grows exponentially with base ψ.

---

## 10. Worked Problems

### Problem 1: Verify ψ³ = ψ + 1

**Question:** Compute ψ³ and ψ + 1 to 6 decimal places.

**Solution:**

```
ψ ≈ 1.324718

ψ³ = (1.324718)³ ≈ 2.324718

ψ + 1 = 1.324718 + 1 = 2.324718

ψ³ = ψ + 1 ≈ 2.324718  ✓
```

---

### Problem 2: Compute ψ⁴

**Question:** Express ψ⁴ in terms of lower powers.

**Solution:**

```
ψ⁴ = ψ · ψ³
   = ψ(ψ + 1)
   = ψ² + ψ
   ≈ (1.324718)² + 1.324718
   ≈ 1.754878 + 1.324718
   ≈ 3.079596
```

---

### Problem 3: Padovan sequence ratio

**Question:** Compute P(10)/P(9) and compare to ψ.

**Solution:**

```
P(10) = 12,  P(9) = 9
P(10)/P(9) = 12/9 = 4/3 ≈ 1.333333

ψ ≈ 1.324718

Difference: |1.333333 − 1.324718| ≈ 0.008615
```

---

### Problem 4: Solve x³ − x − 1 = 0 numerically

**Question:** Use Newton's method to find ψ to 4 decimal places, starting
with x₀ = 1.5.

**Solution:**

```
f(x) = x³ − x − 1
f'(x) = 3x² − 1

Newton iteration: x_{n+1} = x_n − f(x_n)/f'(x_n)

x₀ = 1.5
f(1.5) = 3.375 − 1.5 − 1 = 0.875
f'(1.5) = 6.75 − 1 = 5.75
x₁ = 1.5 − 0.875/5.75 ≈ 1.3478

x₁ = 1.3478
f(1.3478) = 2.448 − 1.3478 − 1 = 0.1002
f'(1.3478) = 5.449 − 1 = 4.449
x₂ = 1.3478 − 0.1002/4.449 ≈ 1.3252

x₂ = 1.3252
f(1.3252) = 2.327 − 1.3252 − 1 = 0.0018
f'(1.3252) = 5.267 − 1 = 4.267
x₃ = 1.3252 − 0.0018/4.267 ≈ 1.3247

ψ ≈ 1.3247
```

---

### Problem 5: The plastic solid

**Question:** A plastic solid has dimensions ψ × 1 × 1/ψ. Compute its volume.

**Solution:**

```
Volume = ψ × 1 × 1/ψ = 1

The volume is exactly 1, regardless of the value of ψ.
```

---

### Problem 6: Compare ψ and φ

**Question:** Which is larger, ψ or φ?

**Solution:**

```
ψ ≈ 1.324718
φ ≈ 1.618034

ψ < φ

The plastic number is smaller than the golden ratio.
```

---

### Problem 7: Padovan number via recurrence

**Question:** Compute P(13) using the recurrence P(n) = P(n−2) + P(n−3).

**Solution:**

```
P(10) = 12
P(11) = 16
P(12) = 21
P(13) = P(11) + P(10) = 16 + 12 = 28
```

---

### Problem 8: The minimal polynomial

**Question:** Find a polynomial equation satisfied by ψ².

**Solution:**

```
Let y = ψ². Then ψ = √y.

From ψ³ = ψ + 1:
(√y)³ = √y + 1
y√y = √y + 1
y^(3/2) = y^(1/2) + 1

Let z = y^(1/2) = ψ:
z³ = z + 1  (which we know)

To find a polynomial for y = ψ²:
From ψ³ = ψ + 1: ψ³ − ψ = 1
ψ(ψ² − 1) = 1
y − 1 = 1/ψ
ψ = 1/(y − 1)

Substituting back: (1/(y−1))³ = 1/(y−1) + 1
1/(y−1)³ = 1/(y−1) + 1
1 = (y−1)² + (y−1)³
1 = (y² − 2y + 1) + (y³ − 3y² + 3y − 1)
1 = y³ − 2y² + y
y³ − 2y² + y − 1 = 0

So ψ² satisfies y³ − 2y² + y − 1 = 0.
```

---

### Problem 9: Plastic ratio vs golden ratio

**Question:** For the golden ratio, 1/φ = φ − 1. Does an analogous identity
hold for ψ?

**Solution:**

```
For φ: 1/φ = φ − 1  (exactly)

For ψ: From ψ³ = ψ + 1, divide by ψ:
ψ² = 1 + 1/ψ
1/ψ = ψ² − 1

Check: ψ² − 1 = (1.324718)² − 1 = 1.754878 − 1 = 0.754878
       1/ψ = 1/1.324718 ≈ 0.754878  ✓

So: 1/ψ = ψ² − 1
```

This is the plastic analogue of 1/φ = φ − 1.

---

### Problem 10: Growth rate comparison

**Question:** Compare the growth rates of Fibonacci (base φ) and Padovan
(base ψ) sequences.

**Solution:**

```
Fibonacci grows as φⁿ where φ ≈ 1.618
Padovan grows as ψⁿ where ψ ≈ 1.325

φ > ψ, so Fibonacci grows faster.

After 20 terms:
F(20) = 6765  (≈ φ²⁰/√5 ≈ 6765)
P(20) = 186   (≈ a·ψ²⁰ ≈ 186)

The Fibonacci sequence grows about 36× faster.
```

---

### Problem 11: Plastic number and fractals

**Question:** The plastic number is connected to the "plastic tree" fractal.
If each branch splits into two branches of lengths proportional to 1/ψ and
1/ψ², what is the total length after 5 levels?

**Solution:**

```
Level 0: length = 1
Level 1: 1/ψ + 1/ψ² = (ψ + 1)/ψ² = ψ³/ψ² = ψ ≈ 1.325
Level 2: ψ × (1/ψ + 1/ψ²) = ψ² ≈ 1.755
Level 3: ψ³ ≈ 2.325
Level 4: ψ⁴ ≈ 3.080
Level 5: ψ⁵ ≈ 4.080

The total length grows as ψⁿ.
```

---

### Problem 12: Express ψ⁶

**Question:** Compute ψ⁶ in the form aψ² + bψ + c.

**Solution:**

```
ψ⁶ = ψ² + 2ψ + 1 (from the power reduction pattern)
   = (1.324718)² + 2(1.324718) + 1
   ≈ 1.754878 + 2.649436 + 1
   ≈ 5.404314
```

---

### Problem 13: The plastic constant

**Question:** The plastic number is sometimes called the "plastic constant."
Verify that ψ ≈ 1.3247 satisfies the defining equation to 6 decimal places.

**Solution:**

```
ψ ≈ 1.324718

ψ³ = (1.324718)³
   = 1.324718 × 1.324718 × 1.324718
   = 1.754878 × 1.324718
   ≈ 2.324718

ψ + 1 = 2.324718

ψ³ − ψ − 1 = 2.324718 − 1.324718 − 1 = 0.000000  ✓
```

---

### Problem 14: Why "plastic"?

**Question:** Dom Hans van der Laan named the plastic number after the Greek
"plastos" (formed). How does this relate to its geometric significance?

**Solution:**

```
The plastic number governs the proportions of 3D forms:
- The plastic solid (a cube with specific face ratios)
- The ratio of dimensions for 3D packing
- The growth factor for 3D spirals

Just as φ governs 2D forms (golden rectangles, pentagons),
ψ governs 3D forms.

Van der Laan was an architect who used ψ to design buildings
with harmonious 3D proportions.
```

---

### Problem 15: Pisot number convergence

**Question:** Compute ψⁿ for n = 1, 2, ..., 10 and compare with the nearest
integers.

**Solution:**

```
n  | ψⁿ      | Nearest int | Difference
---|---------|-------------|----------
1  | 1.3247  | 1           | 0.3247
2  | 1.7549  | 2           | −0.2451
3  | 2.3247  | 2           | 0.3247
4  | 3.0796  | 3           | 0.0796
5  | 4.0796  | 4           | 0.0796
6  | 5.4043  | 5           | 0.4043
7  | 7.1592  | 7           | 0.1592
8  | 9.4839  | 9           | 0.4839
9  | 12.563  | 13          | −0.437
10 | 16.642  | 17          | −0.358

The differences do NOT converge to 0 (unlike the golden ratio, where
φⁿ approaches integers more slowly). This is because ψ is a Pisot number:
the other roots have magnitude < 1, but the convergence is to the Padovan
sequence, not to integers in general.
```

---

## 11. Summary Table

| Property | Value |
|----------|-------|
| Definition | Root of x³ − x − 1 = 0 |
| Decimal | 1.3247179572... |
| Identity | ψ³ = ψ + 1 |
| Reciprocal | 1/ψ = ψ² − 1 |
| Padovan base | P(n+1)/P(n) → ψ |
| Geometric role | 3D proportions |
| Pisot property | Smallest Pisot number |
| Conjugate magnitude | ≈ 0.8688 < 1 |

---

## 12. Key Takeaways for Ages 13–16

1. **ψ is algebraic:** It satisfies x³ − x − 1 = 0 (cubic, not quadratic).
2. **ψ³ = ψ + 1:** The defining identity, like φ² = φ + 1.
3. **Padovan sequence:** The bronze-ratio analogue, growing as ψⁿ.
4. **3D geometry:** ψ governs proportions of three-dimensional forms.
5. **Pisot number:** ψⁿ approaches integers (the Padovan sequence).
6. **Smaller than φ:** ψ ≈ 1.325 < φ ≈ 1.618.

---

*Next: 07_intermediate_supergolden.md — The Supergolden Ratio*
