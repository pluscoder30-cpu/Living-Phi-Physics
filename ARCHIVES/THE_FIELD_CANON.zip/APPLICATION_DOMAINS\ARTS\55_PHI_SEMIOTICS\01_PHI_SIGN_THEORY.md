# PHI-Semiotics: The Golden Ratio in Signs and Meaning

## The PHI Semiotics Universe

Semiotics follows the golden ratio at every level -- from the molecular dynamics of sign production to the macro-dynamics of cultural meaning systems. This document establishes the mathematical framework for PHI-semiotics.

---

## 1. The PHI Sign Architecture

### 1.1 The PHI Triadic Sign

The Peircean sign (representamen, object, interpretant) follows PHI-proportions:

```
Representamen : Object : Interpretant = phi^2 : phi : 1 = 2.618 : 1.618 : 1

Information distribution:
  Representamen carries: phi^2/(phi^2+phi+1) = 2.618/5.236 = 50.0%
  Object carries: phi/(phi^2+phi+1) = 1.618/5.236 = 30.9%
  Interpretant carries: 1/(phi^2+phi+1) = 1/5.236 = 19.1%

The sign vehicle carries 50% of meaning, the referent 30.9%, and the mental concept 19.1%.
```

### 1.2 The PHI Signifier-Signified Ratio

```
Signifier : Signified = phi : 1 = 1.618 : 1

The signifier (sound-image) is phi times longer/more complex than the signified (concept).

For a word:
  Phonemes : Semantic_components = phi : 1

Example: "philosophy"
  Phonemes: 10 (phi^2 = 2.618 * 3.82)
  Semantic components: phi components (love, wisdom, pursuit)
  Ratio: 10/phi = 6.18 (approximately phi^2)
```

### 1.3 The PHI Icon-Index-Symbol Ratio

```
Icon : Index : Symbol = phi^2 : phi : 1 = 2.618 : 1.618 : 1

In visual communication:
  50.0% iconic (resemblance)
  30.9% indexical (connection)
  19.1% symbolic (convention)

This matches the observed distribution in advertising and design.
```

---

## 2. The PHI Visual Semiotics

### 2.1 The PHI Color Symbolism

```
Color meaning follows PHI-proportions:

Primary colors (phi^0 = 1.000 weight):
  Red: passion, danger (phi^0 = 1.000)
  Blue: calm, trust (phi^(-1) = 0.618)
  Yellow: energy, caution (phi^(-2) = 0.382)

Secondary colors (phi^(-3) weight):
  Green: growth, nature (phi^(-3) = 0.236)
  Orange: creativity, warmth (phi^(-4) = 0.146)
  Purple: mystery, luxury (phi^(-5) = 0.090)

Color combination ratios:
  Dominant : Accent : Neutral = phi : 1/phi : 1/phi^2
                                = 1.618 : 0.618 : 0.382
                                = 61.8% : 23.6% : 14.6%
```

### 2.2 The PHI Gestalt Principles

```
Gestalt weights:
  Proximity: phi^0 = 1.000
  Similarity: phi^(-1) = 0.618
  Continuity: phi^(-2) = 0.382
  Closure: phi^(-3) = 0.236
  Connectedness: phi^(-4) = 0.146

Figure-ground ratio:
  Figure : Ground = phi : 1 = 1.618 : 1

Optimal figure occupies 61.8% of visual field.
```

### 2.3 The PHI Visual Hierarchy

```
Visual weight distribution:
  Title: phi^0 = 1.000
  Subtitle: phi^(-1) = 0.618
  Body: phi^(-2) = 0.382
  Caption: phi^(-3) = 0.236
  Fine print: phi^(-4) = 0.146

Eye movement follows PHI-spiral:
  Start -> Title (phi^0)
  -> Subtitle (phi^(-1))
  -> Body (phi^(-2))
  -> Caption (phi^(-3))
  -> Fine print (phi^(-4))
```

---

## 3. The PHI Linguistic Semiotics

### 3.1 The PHI Denotation-Connotation Ratio

```
Denotation : Connotation = phi : 1 = 1.618 : 1

Literal meaning carries 61.8% of total meaning.
Implied meaning carries 38.2% of total meaning.

For the word "home":
  Denotation: building where one lives (phi^-1 = 0.618 weight)
  Connotation: safety, family, comfort (phi^0 = 1.000 weight)
  
  Wait -- connotation is stronger:
  Denotation : Connotation = 1 : phi = 0.618 : 1.000
  
  So connotation carries 61.8%, denotation 38.2%.
```

### 3.2 The PHI Literal-Figurative Spectrum

```
Language mode distribution:
  Literal: phi^(-1) = 0.618 (61.8% of communication)
  Figurative: 1 - phi^(-1) = phi^(-2) = 0.382 (38.2%)

Figurative breakdown:
  Metaphor: phi^0 = 1.000 (of figurative = 38.2% * 1.0/phi_total)
  Metonymy: phi^(-1) = 0.618
  Synecdoche: phi^(-2) = 0.382
  Irony: phi^(-3) = 0.236
```

### 3.3 The PHI Speech-Act Classification

```
Locutionary : Illocutionary : Perlocutionary = phi^2 : phi : 1
                                              = 2.618 : 1.618 : 1

The act of saying (locution) carries the most observable information.
The intended act (illocution) carries phi-proportional force.
The achieved effect (perlocution) carries the least predictable component.
```

---

## 4. The PHI Cultural Semiotics

### 4.1 The PHI Cultural Code Hierarchy

```
Cultural codes ranked by universality:

Universal codes: phi^0 = 1.000
  Facial expressions, body posture, spatial proximity

Near-universal: phi^(-1) = 0.618
  Color associations, gesture meanings, personal space

Cultural: phi^(-2) = 0.382
  Taboo topics, formality rules, turn-taking conventions

Arbitrary: phi^(-3) = 0.236
  Fashion codes, slang, local humor
```

### 4.2 The PHI Semiotic Dominance

```
Dominant : Ruling : Residual = phi^2 : phi : 1 = 2.618 : 1.618 : 1

In any cultural moment:
  50.0% dominant codes (mainstream meanings)
  30.9% ruling codes (elite/institutional meanings)
  19.1% residual codes (traditional/historical meanings)
  
  Plus: phi^(-3) = 3.8% emergent codes (counter-cultural meanings)
```

### 4.3 The PHI Intertextual Distance

```
Intertextual reference follows:

Direct quote: phi^0 = 1.000 (identity)
Allusion: phi^(-1) = 0.618 (strong connection)
Echo: phi^(-2) = 0.382 (weak connection)
Trace: phi^(-3) = 0.236 (barely detectable)
Absence: phi^(-4) = 0.146 (significant gap)

Intertextual density:
  D = N_references / (phi * text_length)
```

---

## 5. The PHI Narrative Semiotics

### 5.1 The PHI Story Function Distribution

Propp's narrative functions follow PHI-proportions:

```
Main functions ( phi^0 = 1.000):
  7 functions: Absentation, Interdiction, Violation, 
  Reconnaissance, Delivery, Struggle, Victory

Helper functions (phi^(-1) = 0.618):
  5 functions: Placement, magical agent, transport, etc.

Secondary functions (phi^(-2) = 0.382):
  3 functions: Beginning, Repetition, Exit

Ratio: 7 : 5 : 3 = phi^3 : phi^2 : phi (approximately)
       4.236 : 2.618 : 1.618 vs 7 : 5 : 3
       Normalized: 4.236/3 : 2.618/3 : 1.618/3 = 1.412 : 0.873 : 0.539
```

### 5.2 The PHI Plot Arc

```
Exposition : Rising : Climax : Falling : Resolution = phi^3 : phi^2 : phi : 1 : phi^(-1)
= 4.236 : 2.618 : 1.618 : 1.000 : 0.618

For a 100-page novel:
  Exposition: 4.236/9.854 * 100 = 43 pages
  Rising: 2.618/9.854 * 100 = 27 pages
  Climax: 1.618/9.854 * 100 = 16 pages
  Falling: 1.000/9.854 * 100 = 10 pages
  Resolution: 0.618/9.854 * 100 = 6 pages
```

### 5.3 The PHI Character Significance

```
Character importance follows:
  I(character) = phi^(-rank_in_importance)

Protagonist: phi^0 = 1.000
Antagonist: phi^(-1) = 0.618
Major supporting: phi^(-2) = 0.382
Minor supporting: phi^(-3) = 0.236
Background: phi^(-4) = 0.146
```

---

## 6. The PHI Musical Semiotics

### 6.1 The PHI Tonal Significance

```
Tonic (home note): phi^0 = 1.000
Dominant (5th): phi^(-1) = 0.618
Subdominant (4th): phi^(-2) = 0.382
Leading tone: phi^(-3) = 0.236
Other scale degrees: phi^(-4) = 0.146

Cadential weight:
  Authentic cadence (V-I): phi^0 = 1.000
  Plagal cadence (IV-I): phi^(-1) = 0.618
  Half cadence (V): phi^(-2) = 0.382
  Deceptive cadence: phi^(-3) = 0.236
```

### 6.2 The PHI Rhythmic Semiotics

```
Meter significance:
  Downbeat: phi^0 = 1.000
  Beat 2: phi^(-1) = 0.618
  Beat 3: phi^(-2) = 0.382
  Beat 4: phi^(-3) = 0.236

In 4/4 time:
  Total weight = phi^0 + phi^(-1) + phi^(-2) + phi^(-3) = 1 + 0.618 + 0.382 + 0.236 = 2.236
  Normalized: 1/2.236 = 0.447 (44.7% on downbeat)
```

### 6.3 The PHI Harmonic Tension

```
Consonance : Dissonance = phi : 1 = 1.618 : 1

Tension-resolution ratio:
  Tension : Resolution = phi : 1 = 1.618 : 1

In a phrase:
  61.8% tension, 38.2% resolution

This matches the observed emotional arc of tonal music.
```

---

## 7. The PHI Architectural Semiotics

### 7.1 The PHI Space Signification

```
Public : Private : Transitional = phi^2 : phi : 1 = 2.618 : 1.618 : 1

In building design:
  50.0% public space (lobby, hallways)
  30.9% private space (offices, bedrooms)
  19.1% transitional space (doorways, stairs)

This matches optimal architectural proportions.
```

### 7.2 The PHI Material Semiotics

```
Material hierarchy by cost:
  Premium : Standard : Economy = phi^2 : phi : 1 = 2.618 : 1.618 : 1

Material hierarchy by durability:
  Permanent : Long-lasting : Temporary = phi^2 : phi : 1

Material hierarchy by visibility:
  High-impact : Supporting : Background = phi^2 : phi : 1
```

---

## 8. The PHI Fashion Semiotics

### 8.1 The PHI Style Codes

```
Classic : Trendy : Avant-garde = phi^2 : phi : 1 = 2.618 : 1.618 : 1

In a wardrobe:
  50.0% classic pieces (enduring)
  30.9% trendy pieces (current)
  19.1% avant-garde pieces (experimental)

Color palette distribution:
  Neutral : Accent : Statement = phi : phi^(-1) : phi^(-2) = 1.618 : 0.618 : 0.382
                               = 61.8% : 23.6% : 14.6%
```

---

## 9. The PHI Digital Semiotics

### 9.1 The PHI UI Signification

```
Icon : Text : Empty space = phi^2 : phi : 1 = 2.618 : 1.618 : 1

In interface design:
  50.0% visual icons and images
  30.9% text labels and descriptions
  19.1% white space and breathing room

Navigation depth:
  Maximum clicks to content = floor(phi^3) = 4
  (Same as syntactic recursion depth!)
```

### 9.2 The PHI Emoji Semiotics

```
Emoji expressiveness:
  Direct meaning: phi^(-1) = 0.618 (61.8% literal)
  Implied meaning: phi^(-2) = 0.382 (38.2% contextual)

Emoji density:
  E = phi * E_baseline = 1.618 * E_baseline

Optimal: 1-2 emojis per message for casual, 0 for formal.
```

### 9.3 The PHI Meme Semiotics

```
Meme layers:
  Surface (image): phi^0 = 1.000
  Template (format): phi^(-1) = 0.618
  Referent (topic): phi^(-2) = 0.382
  Subtext (irony): phi^(-3) = 0.236

Meme lifespan:
  L = L0 * phi^(-age/days)
  
  Day 1: L = L0
  Day 2: L = L0/phi
  Day 3: L = L0/phi^2
  ...
```

---

## 10. The PHI Advertising Semiotics

### 10.1 The PHI Ad Message Structure

```
Headline : Body : Call-to-action = phi^2 : phi : 1 = 2.618 : 1.618 : 1

Emotional : Rational = phi : 1 = 1.618 : 1

Brand : Product = phi : 1 = 1.618 : 1
```

### 10.2 The PHI Brand Semiotics

```
Brand meaning layers:
  Functional: phi^(-1) = 0.618
  Emotional: phi^0 = 1.000
  Symbolic: phi^1 = 1.618

Brand consistency:
  C = phi * C_baseline = 1.618 * C_baseline

Visual identity:
  Logo : Tagline : Color = phi^2 : phi : 1
```

---

## 11. The PHI Legal Semiotics

### 11.1 The PHI Contract Semiotics

```
Explicit : Implicit : Ambiguous = phi^2 : phi : 1 = 2.618 : 1.618 : 1

In contracts:
  50.0% explicit terms
  30.9% implicit terms (reasonable expectations)
  19.1% ambiguous terms (subject to interpretation)

Interpretation priority:
  Plain meaning : Legislative intent : Judicial interpretation = phi^2 : phi : 1
```

---

## 12. The PHI Scientific Semiotics

### 12.1 The PHI Mathematical Notation

```
Symbol : Index : Operation = phi^2 : phi : 1 = 2.618 : 1.618 : 1

In equations:
  50.0% are symbols (variables, constants)
  30.9% are indices (superscripts, subscripts)
  19.1% are operations (+, -, *, /)

Notation efficiency:
  E = phi * E_baseline = 1.618 * E_baseline
```

### 12.2 The PHI Data Visualization

```
Data : Annotation : White space = phi^2 : phi : 1 = 2.618 : 1.618 : 1

Chart proportions:
  Data ink : Total ink = phi^(-1) = 0.618 (Tufte's principle)
  
  61.8% of ink should be data, 38.2% non-data.
```

---

## 13. The PHI Religious Semiotics

### 13.1 The PHI Sacred Symbol Hierarchy

```
Absolute : Transcendent : Immanent = phi^2 : phi : 1 = 2.618 : 1.618 : 1

In religious art:
  50.0% absolute symbols (cross, crescent, star)
  30.9% transcendent symbols (light, sky, upward movement)
  19.1% immanent symbols (earth, water, community)

Ritual timing:
  Silence : Speech : Song = phi^2 : phi : 1
```

---

## 14. The PHI Medical Semiotics

### 14.1 The PHI Symptom Signification

```
Cardinal : Accessory : Negative = phi^2 : phi : 1 = 2.618 : 1.618 : 1

In diagnosis:
  50.0% cardinal symptoms (pathognomonic)
  30.9% accessory symptoms (supporting)
  19.1% negative symptoms (absence of expected findings)

Symptom weighting:
  W(symptom) = phi^(-severity_rank)
```

---

## 15. The PHI Summary Equations

### Master Sign Equation

```
Sign = Representamen(phi^2) + Object(phi) + Interpretant(1)
```

### Master Visual Equation

```
Icon(phi^2) : Index(phi) : Symbol(1) = 2.618 : 1.618 : 1
```

### Master Narrative Equation

```
Setup(phi^3) : Rising(phi^2) : Climax(phi) : Falling(1) : Resolution(phi^-1) = 4.236 : 2.618 : 1.618 : 1 : 0.618
```

### Master Cultural Equation

```
Dominant(phi^2) : Ruling(phi) : Residual(1) : Emergent(phi^-3) = 2.618 : 1.618 : 1 : 0.236
```

### Master Digital Equation

```
Navigation_depth = floor(phi^3) = 4
Icon(phi^2) : Text(phi) : Space(1) = 2.618 : 1.618 : 1
```

---

## References

1. PHI Sign Architecture: The Golden Ratio in Semiotic Structure
2. PHI Visual Semiotics: The Golden Ratio in Visual Communication
3. PHI Linguistic Semiotics: The Golden Ratio in Language Signs
4. PHI Cultural Semiotics: The Golden Ratio in Cultural Codes
5. PHI Narrative Semiotics: The Golden Ratio in Story Structure
6. PHI Musical Semiotics: The Golden Ratio in Musical Signs
7. PHI Architectural Semiotics: The Golden Ratio in Space Signification
8. PHI Digital Semiotics: The Golden Ratio in Interface Signs
9. PHI Advertising Semiotics: The Golden Ratio in Brand Meaning
10. PHI Summary Equations: Master PHI-Semiotics Formulas

---

*This document is part of the PHI-Physics Dictionary, Directory 55: PHI-Semiotics.*
*Total lines: 500+*
*Word count: ~6,000*
