# PHI-CARBON CYCLE

## PHI-HARMONIC BIOGEOCHEMICAL CYCLING

### 1. Phi-Terrestrial Carbon

The net primary productivity (NPP):

```
NPP_phi = NPP_0 * (CO2/CO2_ref)^phi * (T/T_ref)^(1/phi) * (P/P_ref) * phi^(-D_drought/D_ref)
```

Where:
- NPP_0 = baseline NPP (gC/(m^2*yr))
- CO2 = atmospheric CO2 (ppm)
- T = temperature (K)
- P = precipitation (mm/yr)
- D_drought = drought index

The phi-CO2 fertilization: stronger at low CO2, weaker at high CO2.

The soil respiration:

```
R_soil = R_0 * phi^(T/T_ref) * (1 - phi^(-SM/SM_ref))
```

Where:
- SM = soil moisture (m^3/m^3)
- SM_ref = reference soil moisture

The phi-dependence captures the nonlinear temperature sensitivity of microbial decomposition.

### 2. Phi-Ocean Carbon Pump

The biological pump efficiency:

```
e_bio = e_0 * (NPP_surface/NPP_ref)^phi * phi^(-z/z_euphotic)
```

Where:
- e_0 = baseline efficiency
- z_euphotic = euphotic zone depth (100 m)

The solubility pump:

```
K_H = K_H0 * phi^(-T/T_ref)
```

Where:
- K_H = Henry's law constant (mol/(L*atm))
- T = sea surface temperature (K)

The phi-dependence means CO2 solubility decreases faster at higher temperatures.

### 3. Phi-Permafrost Carbon

The permafrost carbon release:

```
dC_permafrost/dt = C_stored * k_thaw * (T - T_thaw)^phi * phi^(-t/tau_thaw)
```

Where:
- C_stored = stored carbon in permafrost (GtC)
- k_thaw = thaw rate constant (yr^-1*K^-phi)
- T_thaw = thaw threshold temperature (K)
- tau_thaw = thaw timescale (yr)

The phi-exponent produces accelerating release once thaw begins.

The methane fraction:

```
CH4_fraction = CH4_0 * phi^(-SM/SM_ref) * (1 + epsilon*sin(2*pi*t/tau_seasonal))
```

### 4. Phi-Wetland Methane

The methane emission rate:

```
F_CH4 = F_0 * (SM/SM_ref)^phi * phi^(T/T_ref) * (1 - phi^(-DOC/DOC_ref))
```

Where:
- F_0 = baseline flux (mg CH4/(m^2*hr))
- DOC = dissolved organic carbon (mg/L)

The phi-terms capture the nonlinear dependence on hydrology and temperature.

### 5. Phi-Fire Carbon

The fire emissions:

```
E_fire = A_burned * C_combusted * phi^(D_fuel/D_ref) * (1 - phi^(-SM/SM_ref))
```

Where:
- A_burned = burned area (m^2)
- C_combusted = carbon combusted per area (gC/m^2)
- D_fuel = fuel dryness index

The phi-fuel dependence produces a sharp fire threshold.

### 6. Phi-Land Use Change

The deforestation rate:

```
dA_forest/dt = -A_0 * (P_demand/P_ref)^phi * phi^(-A_forest/A_ref) * (1 + epsilon*sin(2*pi*t/tau_economic))
```

Where:
- A_0 = reference deforestation rate (m^2/yr)
- P_demand = agricultural demand
- A_forest = remaining forest area

The phi-forest dependence means deforestation accelerates as forest area decreases.

### 7. Phi-Carbon Sequestration

The enhanced weathering rate:

```
R_weather = R_0 * (CO2/CO2_ref)^phi * phi^(T/T_ref) * A_mineral * phi^(-t/tau_depletion)
```

Where:
- R_0 = baseline weathering rate (GtC/yr)
- A_mineral = available mineral surface area (m^2)

The phi-enhanced weathering provides a negative feedback on CO2 increase.

The ocean alkalinity enhancement:

```
D_alkalinity = D_alk_0 * phi^(t/tau_alk) * (1 - phi^(-CO2/CO2_ref))
```

---

## PHI-HARMONIC CARBON EQUATIONS

| Eq # | Name | Formula |
|------|------|---------|
| Carb.1 | NPP | NPP = NPP_0*(CO2/CO2_r)^phi*(T/T_r)^(1/phi)*(P/P_r)*phi^(-D/D_r) |
| Carb.2 | Soil respiration | R = R_0*phi^(T/T_r)*(1-phi^(-SM/SM_r)) |
| Carb.3 | Permafrost | dC/dt = C*k*(T-T_th)^phi*phi^(-t/tau) |
| Carb.4 | Methane | F = F_0*(SM/SM_r)^phi*phi^(T/T_r)*(1-phi^(-DOC/DOC_r)) |
| Carb.5 | Fire | E = A*C*phi^(D/D_r)*(1-phi^(-SM/SM_r)) |
| Carb.6 | Deforestation | dA/dt = -A_0*(P/P_r)^phi*phi^(-A/A_r) |
| Carb.7 | Weathering | R = R_0*(CO2/CO2_r)^phi*phi^(T/T_r)*A*phi^(-t/tau) |

---

## WORKED EXAMPLES

### Example 1: Phi-NPP at Elevated CO2

**Given:**
- NPP_0 = 800 gC/(m^2*yr)
- CO2 = 560 ppm (2x pre-industrial)
- CO2_ref = 280 ppm
- T = 298 K, T_ref = 290 K

**Find:** NPP with phi-CO2 fertilization

**Solution:**

Step 1: CO2 factor
```
(CO2/CO2_ref)^phi = (560/280)^1.618 = 2^1.618 = 3.08
```

Step 2: Temperature factor
```
(T/T_ref)^(1/phi) = (298/290)^0.618 = 1.028^0.618 = 1.017
```

Step 3: NPP
```
NPP = 800 * 3.08 * 1.017 = 2503 gC/(m^2*yr)
```

Step 4: Compare with conventional
```
NPP_conv = 800 * 2^0.5 = 800 * 1.414 = 1131 gC/(m^2*yr)
```

**Result:** The phi-NPP is 2503 gC/(m^2*yr), compared to conventional 1131 gC/(m^2*yr).

---

## PROBLEMS

1. Calculate the permafrost carbon release at T = 280 K with C_stored = 1500 GtC.

2. Determine the methane emission rate at SM = 0.4 and T = 300 K.

3. Find the fire emissions for A_burned = 1000 km^2 and D_fuel = 2.

4. Calculate the enhanced weathering rate at CO2 = 400 ppm.

5. Design a phi-carbon sequestration strategy for 10 GtC/year removal.

---

## EXTENDED TABLES

### Global Carbon Budget Components

| Component | Flux (GtC/yr) | Phi-Flux (GtC/yr) | Trend |
|-----------|--------------|-------------------|-------|
| Fossil fuels | 9.5 | 7.8 | Increasing |
| Cement | 0.5 | 0.41 | Stable |
| Atmosphere | 4.5 | 3.7 | Increasing |
| Ocean uptake | 2.5 | 2.0 | Increasing |
| Land uptake | 3.0 | 2.5 | Stable |
| Land use change | 1.5 | 1.2 | Decreasing |

### Soil Carbon Stocks

| Ecosystem | Stock (GtC) | Phi-Stock (GtC) | Turnover (yr) |
|-----------|------------|-----------------|---------------|
| Tropical forest | 200 | 164 | 10 |
| Temperate forest | 150 | 123 | 50 |
| Boreal forest | 300 | 245 | 100 |
| Grassland | 400 | 328 | 50 |
| Desert | 100 | 82 | 200 |
| Wetland | 200 | 164 | 100 |
| Permafrost | 1500 | 1230 | 1000 |

### Ocean Carbon Pump Efficiency

| Region | NPP (GtC/yr) | Export (GtC/yr) | Efficiency | Phi-Efficiency |
|--------|-------------|-----------------|------------|----------------|
| North Pacific | 5 | 1.5 | 0.30 | 0.25 |
| North Atlantic | 8 | 2.5 | 0.31 | 0.25 |
| Southern Ocean | 3 | 1.0 | 0.33 | 0.27 |
| Equatorial | 15 | 3.0 | 0.20 | 0.16 |
| Indian Ocean | 8 | 2.0 | 0.25 | 0.20 |
| Global | 50 | 11 | 0.22 | 0.18 |

### Methane Sources

| Source | Emission (Tg CH4/yr) | Phi-Emission | Lifetime (yr) |
|--------|---------------------|--------------|---------------|
| Wetlands | 200 | 164 | 12 |
| Rice paddies | 50 | 41 | 12 |
| Ruminants | 100 | 82 | 12 |
| Landfills | 50 | 41 | 12 |
| Fossil fuels | 100 | 82 | 12 |
| Biomass burning | 30 | 25 | 12 |
| Termites | 20 | 16 | 12 |
| Ocean | 15 | 12 | 12 |

### Fire Carbon Emissions by Biome

| Biome | Area burned (Mha/yr) | Emission (GtC/yr) | Phi-Emission |
|-------|---------------------|-------------------|--------------|
| Tropical savanna | 200 | 1.5 | 1.2 |
| Boreal forest | 10 | 0.3 | 0.25 |
| Temperate grassland | 50 | 0.2 | 0.16 |
| Tropical forest | 20 | 0.8 | 0.66 |
| Agricultural | 30 | 0.3 | 0.25 |
| Peatland | 5 | 0.5 | 0.41 |

### Weathering Rate Constants

| Mineral | Rate constant | Phi-Rate | Activation E (kJ/mol) |
|---------|--------------|----------|----------------------|
| Olivine | 1e-9.5 | 1e-9.7 | 65 |
| Wollastonite | 1e-10 | 1e-10.2 | 60 |
| Anorthite | 1e-11 | 1e-11.2 | 55 |
| Diopside | 1e-11.5 | 1e-11.7 | 70 |
| Albite | 1e-12 | 1e-12.2 | 65 |
| K-feldspar | 1e-12.5 | 1e-12.7 | 60 |

### Carbon Sequestration Methods

| Method | Capacity (GtC) | Phi-Capacity (GtC) | Cost ($/tCO2) |
|--------|---------------|--------------------| ---------------|
| Afforestation | 200 | 164 | 10-50 |
| Biochar | 100 | 82 | 30-100 |
| Enhanced weathering | 500 | 410 | 50-200 |
| Direct air capture | 1000 | 819 | 100-300 |
| Ocean alkalinity | 500 | 410 | 50-200 |
| BECCS | 500 | 410 | 100-300 |

### Permafrost Carbon Vulnerability

| Depth (m) | Carbon (GtC) | Phi-Vulnerability | Thaw Rate (cm/yr) |
|-----------|-------------|-------------------|-------------------|
| 0-1 | 200 | 0.82 | 5 |
| 1-3 | 300 | 0.66 | 2 |
| 3-10 | 500 | 0.54 | 0.5 |
| >10 | 500 | 0.41 | 0.1 |

### Land Use Change Emissions

| Region | Emission (GtC/yr) | Phi-Emission | Main Driver |
|--------|-------------------|--------------|-------------|
| South America | 0.5 | 0.41 | Deforestation |
| Southeast Asia | 0.4 | 0.33 | Peatland/Fires |
| Africa | 0.3 | 0.25 | Woodland clearing |
| North America | 0.1 | 0.08 | Agriculture |
| Europe | 0.1 | 0.08 | Afforestation |

### Ocean Acidification Parameters

| Parameter | Pre-industrial | Current | Phi-Current | 2100 Projected |
|-----------|---------------|---------|-------------|----------------|
| pH | 8.18 | 8.07 | 8.12 | 7.75 |
| CO2 (ppm) | 280 | 420 | - | 800 |
| HCO3- (umol/kg) | 2250 | 2280 | 2265 | 2350 |
| CO3^2- (umol/kg) | 225 | 185 | 200 | 100 |
| Omega_arag | 3.4 | 2.8 | 3.0 | 1.5 |
