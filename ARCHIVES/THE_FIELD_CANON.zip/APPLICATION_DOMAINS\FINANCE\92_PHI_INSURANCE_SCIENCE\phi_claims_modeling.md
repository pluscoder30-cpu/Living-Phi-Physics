# PHI-Claims Modeling: Golden Ratio Loss Development

## Directory 92_PHI_INSURANCE_SCIENCE | File 03

---

## 1. PHI-Claims Frequency

### 1.1 PHI-Poisson

```
P(X=k) = e^{-lambda} * lambda^k / k! * phi^{overdispersion}
```

### 1.2 PHI-Negative Binomial

```
P(X=k) = C(k+r-1,k) * p^r * (1-p)^k * phi^{r}
```

### 1.3 PHI-Zero-Inflated

```
P(X=0) = pi + (1-pi)*e^{-lambda}
P(X=k) = (1-pi) * e^{-lambda} * lambda^k / k! * phi^{zero_inflation}
```

### 1.1 PHI-Hurdle Model

```
P(X=0) = 1 - phi * p
P(X=k) = phi * p * (1-p)^{k-1} * phi^{-k}
```

---

## 2. PHI-Claims Severity

### 2.1 PHI-Lognormal

```
f(x) = 1/(x*sigma*sqrt(2*pi)) * exp(-(ln(x)-mu)^2/(2*sigma^2)) * phi^{tail}
```

### 2.2 PHI-Pareto

```
f(x) = alpha * x_m^alpha / x^{alpha+1} * phi^{-x/x_m}
```

### 2.3 PHI-Gamma

```
f(x) = x^{k-1} * e^{-x/theta} / (Gamma(k)*theta^k) * phi^{k}
```

### 2.4 PHI-Weibull

```
f(x) = k/lambda * (x/lambda)^{k-1} * e^{-(x/lambda)^k} * phi^{k}
```

---

## 3. PHI-Loss Development

### 3.1 PHI-Chain Ladder

```
C_{i,j+k} = C_{i,j} * f_k * phi^{calendar_effect}
f_k = sum C_{i,k} / sum C_{i,k-1} * phi^{volume_weight}
```

### 3.2 PHI-Bornhuetter-Ferguson

```
C_{i,j} = E_i * (1 - a_j) * phi^{-timing}
```

### 3.3 PHI-Expected Bootstrap

```
C_{i,j} = sampled * phi^{parameter_uncertainty}
```

### 3.4 PHI-Mack Model

```
f_k = sum_{i} w_i * C_{i,k} / sum_{i} w_i * C_{i,k-1}
Var(f_k) = 1/(sum C_{i,k-1}) * phi^{estimation_error}
```

---

## 4. PHI-Claims Triangles

### 4.1 PHI-Incremental Triangle

```
Delta C_{i,j} = C_{i,j} - C_{i,j-1} * phi^{development_pattern}
```

### 4.2 PHI-Cumulative Triangle

```
C_{i,j} = sum_{k=1}^{j} Delta C_{i,k} * phi^{-k}
```

### 4.3 PHI-Diagonal

```
Ultimate = C_{i,n-i+1} * f_{n-i+1:n} * phi^{remaining_development}
```

### 4.4 PHI-Ultimate Loss

```
Ultimate = Reported * development_factor * phi{tail_factor}
```

---

## 5. PHI-IBNR

### 5.1 PHI-IBNR Reserve

```
IBNR = Ultimate - Paid - Case_Reserves * phi^{development}
```

### 5.2 PHI-IBNR Factors

```
f_k = observed_factor * phi^{parameter_estimation}
```

### 5.3 PHI-Past Origins

```
IBNR_past = sum (Ultimate - Reported)_i * phi^{-age}
```

### 5.4 PHI-Future Origins

```
IBNR_future = expected_premium * expected_loss_ratio * phi{unreported}
```

---

## 6. PHI-Claims Investigation

### 6.1 PHI-Investigation Priority

```
Priority = claim_amount * phi^{fraud_score} * phi^{-complexity}
```

### 6.2 PHI-Subrogation Potential

```
Potential = loss_amount * phi^{liability_strength} * phi^{-recovery_cost}
```

### 6.3 PHI-Litigation

```
Litigation_cost = base_cost * phi^{jurisdiction} * phi^{case_complexity}
```

### 6.4 PHI-Settlement

```
Settlement = expected_trial * phi^{-settlement_probability}
```

---

## 7. PHI-Claims Analytics

### 7.1 PHI-Severity Trend

```
Trend = CAGR * phi^{inflation_adjustment}
```

### 7.2 PHI-Frequency Trend

```
Trend = growth_rate * phi^{exposure_change}
```

### 7.3 PHI-Loss Ratio

```
LR = paid / earned * phi^{seasonality}
```

### 7.4 PHI-Pure Premium

```
PP = frequency * severity * phi{mix_adjustment}
```

---

## 8. Summary

PHI-claims modeling provides:
1. PHI-frequency with phi-Poisson, phi-negative binomial, phi-zero-inflated
2. PHI-severity with phi-lognormal, phi-Pareto, phi-gamma
3. PHI-development with phi-chain ladder and phi-BF
4. PHI-triangles with phi-incremental and phi-cumulative
5. PHI-IBNR with phi-reserve and phi-factors
6. PHI-investigation with phi-priority and phi-subrogation
7. PHI-analytics with phi-trend and phi-loss ratio

The golden ratio captures the self-similar patterns in claims development and the natural decay of loss estimates over time.