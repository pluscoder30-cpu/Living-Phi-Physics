# PHI-COLOR THEORY

## 1. The PHI-Color Wheel

### 1.1 Construction

The PHI-color wheel is constructed by dividing the visible spectrum at golden-ratio intervals rather than the standard 30-degree increments:

```
Standard wheel: 12 colors at 30-degree intervals
PHI-wheel: 8 colors at 45-degree intervals

The 8 PHI-colors:
  0 deg: Red (pure)
  45 deg: Orange-Red
  90 deg: Yellow
  135 deg: Chartreuse (yellow-green)
  180 deg: Cyan (complement of red)
  225 deg: Azure (blue-cyan)
  270 deg: Violet
  315 deg: Rose (red-magenta)
```

### 1.2 The Golden Angle

The golden angle = 360/phi^2 = 137.507764 degrees determines the most efficient spacing of colors around the wheel:

```
Starting from red (0 deg):
  Color 1: 0 deg (red)
  Color 2: 137.5 deg (green-cyan)
  Color 3: 275.0 deg (violet-red)
  Color 4: 52.5 deg (yellow-orange)
  Color 5: 190.0 deg (blue-green)
  Color 6: 327.5 deg (red-magenta)
  Color 7: 105.0 deg (yellow-green)
  Color 8: 242.5 deg (blue)
  Color 9: 20.0 deg (orange-red)
  Color 10: 157.5 deg (cyan-green)
  
The golden angle ensures that no two colors are adjacent,
creating maximum contrast and minimum repetition
```

### 1.3 PHI-Color Harmony Schemes

```
Triadic PHI-harmony (3 colors):
  Colors at 0, 120, 240 degrees (standard)
  PHI-triadic: 0, 137.5, 275 degrees
  
  The PHI-triadic has more complex relationships than
  standard triadic, with each pair creating different
  contrast levels

Tetradic PHI-harmony (4 colors):
  Colors at 0, 137.5, 275, 52.5 degrees
  
  Two pairs of near-complements:
    Red (0) - Green-Cyan (137.5): contrast ratio phi
    Violet-Red (275) - Yellow-Orange (52.5): contrast ratio phi
```

## 2. PHI-Color Mixing

### 2.1 Additive PHI-Mixing (Light)

```
PHI-primary light colors:
  Red: 0 deg, 100% intensity
  Green: 137.5 deg, 100% intensity
  Blue: 275 deg, 100% intensity

PHI-secondary (pairs):
  Red + Green = Yellow (at 68.75 deg, halfway between)
  Green + Blue = Cyan (at 206.25 deg)
  Blue + Red = Magenta (at 327.5 deg)

PHI-tertiary (all three):
  Red + Green + Blue = White (at 137.5 deg average)
  
  The mixing ratios follow phi:
    To get white: R:G:B = 1:1:1
    To get yellow: R:G = phi:1 (or 1.618:1)
    To get cyan: G:B = phi:1
    To get magenta: B:R = phi:1
```

### 2.2 Subtractive PHI-Mixing (Pigment)

```
PHI-primary pigments:
  Cyan: absorbs red
  Magenta: absorbs green
  Yellow: absorbs blue

PHI-mixing ratios for balanced neutral:
  Cyan : Magenta : Yellow = 1 : 1/phi : 1/phi^2
  = 1 : 0.618 : 0.382

  The unequal ratios compensate for the different
  strengths of pigment absorption, creating a true neutral

PHI-complementary mixing:
  A color mixed with its complement at phi-ratio:
    Color : Complement = phi : 1
    
  Red (0 deg) + Cyan (180 deg):
    Red : Cyan = phi : 1
    = 1.618 : 1
    
  Result: slightly warm neutral (toward red)
  The phi-bias prevents the deadness of exact complement mixing
```

### 2.3 PHI-Color Temperature Mixing

```
Warm + Cool mixing at phi-ratio:

Warm color area : Cool color area = phi : 1

For a balanced composition:
  If warm area = 618 cm², cool area = 382 cm²
  
  Total chromatic area = 1000 cm²
  
  The phi-ratio ensures the warm colors dominate
  without overwhelming, creating a vibrant equilibrium
```

## 3. PHI-Value Relationships

### 3.1 The PHI-Value Scale

```
10-step value scale from black (0) to white (10):

Standard (linear): 0, 1.1, 2.2, 3.3, 4.4, 5.6, 6.7, 7.8, 8.9, 10
PHI-scale: 0, 0.6, 1.0, 1.6, 2.6, 4.2, 6.8, 7.4, 8.0, 10

The PHI-scale clusters values around the golden sections:
  Dark values: 0-2.6 (38.2% of range)
  Mid values: 2.6-6.8 (42.4% of range)
  Light values: 6.8-10 (32% of range)

  The mid-range is widest, reflecting the human eye's
  greatest sensitivity to middle values
```

### 3.2 PHI-Contrast Ratios

```
Luminance contrast between two values:

Maximum contrast: white/black = 21:1 (Weber ratio)
PHI-contrast: white/dark-gray = 21/13 = 1.618:1 (phi)
Subtle contrast: white/medium-gray = 21/8 = 2.625:1 (phi^2)
Whisper contrast: white/light-gray = 21/5 = 4.2:1 (phi^3)

For readability:
  PHI-contrast (1.618:1): minimum for decorative text
  phi^2 contrast (2.625:1): minimum for body text
  phi^3 contrast (4.2:1): recommended for body text
  phi^4 contrast (6.8:1): recommended for small text
```

### 3.3 PHI-Value Distribution

```
In a balanced composition:

Dark values (0-3): 38.2% of area
Mid values (3-7): 38.2% of area
Light values (7-10): 23.6% of area

The phi-distribution creates:
  Enough dark for grounding
  Enough mid for body and form
  Enough light for highlights and air
```

## 4. PHI-Saturation

### 4.1 The PHI-Saturation Scale

```
Saturation from 0% (gray) to 100% (pure):

PHI-saturation points:
  0% (gray)
  23.6% (1/phi^2 of range)
  38.2% (1/phi of range)
  61.8% (phi/phi^2 of range)
  100% (pure)

The PHI-scale creates natural groupings:
  Neutral: 0-23.6% (almost gray)
  Muted: 23.6-38.2% (desaturated)
  Moderate: 38.2-61.8% (balanced)
  Vivid: 61.8-100% (saturated)
  Pure: 100% (maximum saturation)
```

### 4.2 PHI-Saturation Harmony

```
Color pairs at phi-saturation:

Pair 1: 100% saturated + 61.8% saturated (phi-ratio)
  Example: Pure red + dusty red
  
Pair 2: 61.8% saturated + 38.2% saturated (phi-ratio)
  Example: Dusty red + muted red
  
Pair 3: 38.2% saturated + 23.6% saturated (phi-ratio)
  Example: Muted red + near-gray red

The phi-ratio between saturations creates visual interest
without the chaos of random saturation variation
```

### 4.3 Saturation and Space

```
Saturation as depth cue:

Foreground elements: 100% saturation
Middleground elements: 100/phi = 61.8% saturation
Background elements: 61.8/phi = 38.2% saturation
Far background: 38.2/phi = 23.6% saturation

The phi-decrease in saturation creates atmospheric depth
with a more natural gradient than linear decrease
```

## 5. PHI-Color Interaction

### 5.1 Simultaneous Contrast

```
A color's appearance changes based on its neighbor:

PHI-simultaneous contrast:
  Color A on neutral background: appears as is
  Color A on complement background: appears more vivid
  Color A on phi-similar background: appears shifted away
  
  The phi-shift formula:
    Perceived_hue = Actual_hue + (Background_hue - Actual_hue) / phi
    
  Example:
    Red (0 deg) on Green (137.5 deg) background:
    Perceived = 0 + (137.5 - 0)/phi = 0 + 85 = 85 deg
    The red appears to shift toward orange (85 deg)
```

### 5.2 Successive Contrast

```
After viewing a color, its complement appears:

PHI-successive contrast:
  View color for T seconds
  Afterimage duration: T/phi seconds
  
  Example:
    View red for 10 seconds
    Afterimage (cyan) persists for 10/phi = 6.18 seconds
    
  The phi-ratio between stimulus and afterimage creates
  a natural fading that matches visual persistence
```

### 5.3 Color Constancy

```
PHI-color constancy:
  The perceived color of an object remains constant
  under varying illumination, up to a phi-threshold
  
  Illumination change factor: phi (61.8% change)
  Below this: color appears constant
  Above this: color begins to shift
  
  This explains why objects look "the same" under
  slightly different lighting but change under
  dramatically different lighting
```

## 6. PHI-Color in Nature

### 6.1 Flower Petal Arrangement

```
Flower petals follow Fibonacci numbers:

Lilies: 3 petals (F(4))
Buttercups: 5 petals (F(5))
Delphiniums: 8 petals (F(6))
Marigolds: 13 petals (F(7))
Asters: 21 petals (F(8))
Daisies: 34, 55, or 89 petals (F(9), F(10), F(11))

The petal count follows Fibonacci because each petal
is positioned at the golden angle (137.5 deg) from the previous,
ensuring maximum sunlight exposure and minimum overlap
```

### 6.2 Butterfly Wing Patterns

```
Butterfly wing color patterns exhibit phi-proportions:

  Wing sections divided at golden ratios
  Color bands at phi-intervals
  Spot sizes in phi-proportion to each other
  
  Example: Morpho butterfly
    Blue area : Brown area = phi : 1
    Spot diameter sequence: 1, 1.6, 2.6, 4.2 mm (phi-progression)
```

### 6.3 Bird Plumage

```
Peacock tail feather colors:
  Central eye: 100% saturation
  First ring: 61.8% saturation
  Second ring: 38.2% saturation
  Outer fringe: 23.6% saturation
  
  The phi-decrease in saturation from center to edge
  creates the shimmering, iridescent quality
```

## 7. PHI-Color for Emotion

### 7.1 Emotional Color Mapping

```
PHI-emotional spectrum:

Warm emotions (phi-biased toward warm):
  Joy: Yellow at 61.8% saturation
  Love: Red at 100% saturation
  Passion: Red-Orange at 80.9% saturation (phi x 50%)
  Energy: Orange at 100% saturation

Cool emotions (phi-biased toward cool):
  Calm: Blue at 61.8% saturation
  Sadness: Blue-Violet at 38.2% saturation
  Mystery: Violet at 61.8% saturation
  Growth: Green at 61.8% saturation

Neutral emotions (phi-balanced):
  Peace: Gray-Green at 38.2% saturation
  Wisdom: Gray-Violet at 38.2% saturation
  Balance: Gray at 0% saturation
```

### 7.2 Color Temperature and Mood

```
PHI-temperature mood scale:

Very warm: 0-30 deg hue, 100% saturation
  Mood: energetic, aggressive, passionate
  
Warm: 30-60 deg hue, 80% saturation
  Mood: friendly, inviting, comfortable
  
Neutral warm: 60-90 deg hue, 60% saturation
  Mood: balanced, stable, natural
  
Neutral: 90-120 deg hue, 40% saturation
  Mood: calm, peaceful, harmonious
  
Neutral cool: 120-150 deg hue, 60% saturation
  Mood: fresh, clean, spacious
  
Cool: 150-180 deg hue, 80% saturation
  Mood: professional, trustworthy, deep
  
Very cool: 180-210 deg hue, 100% saturation
  Mood: mysterious, spiritual, infinite
```

### 7.3 PHI-Color for Advertising

```
PHI-Advertising color strategy:

Product type -> PHI-color choice:
  Food: warm PHI-colors (orange at 61.8% sat)
  Technology: cool PHI-colors (blue at 61.8% sat)
  Luxury: deep PHI-colors (violet at 38.2% sat)
  Health: natural PHI-colors (green at 61.8% sat)
  Youth: bright PHI-colors (yellow at 100% sat)
  
Background : Product = phi : 1 in area
Contrast ratio: phi : 1 minimum
Accent color: complement of dominant at 1/phi saturation
```

## 8. PHI-Color for Interior Design

### 8.1 Room Color Proportions

```
PHI-Room color distribution:

Ceiling: 23.6% of visible surface (lightest value)
Walls: 61.8% of visible surface (mid value)
Floor: 14.6% of visible surface (darkest value)

Furniture colors:
  Major pieces: 61.8% of furniture area (dominant color)
  Secondary pieces: 23.6% (subordinate color)
  Accents: 14.6% (accent color)
```

### 8.2 Color Flow

```
PHI-color flow through rooms:

Room 1 (entry): Warm, saturated (welcoming)
Room 2 (living): PHI-balanced (comfortable)
Room 3 (kitchen): Warm, high-value (energetic)
Room 4 (bedroom): Cool, low-saturation (calming)
Room 5 (bathroom): Cool, high-value (clean)

The phi-transition between rooms:
  Room 1 -> 2: warm to balanced (shift of 1/phi in temperature)
  Room 2 -> 3: balanced to warm (shift of 1/phi in energy)
  Room 3 -> 4: warm to cool (shift of phi in temperature)
  Room 4 -> 5: cool to clean (shift of 1/phi in saturation)
```

## 9. PHI-Color Digital Implementation

### 9.1 HSL Values

```python
def phi_hsl(base_hue, base_sat=100, base_lit=50):
    """Generate PHI-color palette from base hue."""
    PHI = (1 + 5**0.5) / 2
    
    colors = []
    for i in range(5):
        hue = (base_hue + i * 137.5) % 360
        sat = base_sat * (1 / PHI**i)
        lit = base_lit * (1 / PHI**(i-2))
        colors.append((round(hue, 1), round(min(100, max(0, sat)), 1), 
                       round(min(100, max(0, lit)), 1)))
    return colors

# Example: Red-based palette
# [(0, 100, 50), (137.5, 61.8, 30.9), (275, 38.2, 19.1), 
#  (52.5, 23.6, 11.8), (190, 14.6, 7.3)]
```

### 9.2 RGB Values

```python
def phi_rgb_palette(base_r, base_g, base_b):
    """Generate PHI-color palette from base RGB."""
    PHI = (1 + 5**0.5) / 2
    
    colors = []
    for i in range(5):
        factor = 1 / PHI**i
        r = min(255, int(base_r * factor))
        g = min(255, int(base_g * factor))
        b = min(255, int(base_b * factor))
        colors.append((r, g, b))
    return colors
```

### 9.3 CSS Implementation

```css
:root {
  /* PHI-Color palette */
  --phi-red: hsl(0, 100%, 50%);
  --phi-orange: hsl(45, 80.9%, 50%);
  --phi-yellow: hsl(90, 61.8%, 50%);
  --phi-green: hsl(135, 38.2%, 50%);
  --phi-cyan: hsl(180, 23.6%, 50%);
  --phi-blue: hsl(225, 14.6%, 50%);
  --phi-violet: hsl(270, 9%, 50%);
  --phi-magenta: hsl(315, 5.5%, 50%);
  
  /* PHI-Value scale */
  --phi-dark: hsl(0, 0%, 14.6%);
  --phi-shadow: hsl(0, 0%, 23.6%);
  --phi-mid: hsl(0, 0%, 38.2%);
  --phi-light: hsl(0, 0%, 61.8%);
  --phi-highlight: hsl(0, 0%, 85.4%);
}
```

## References

- Itten, J. (1961). "The Art of Color"
- Albers, J. (1963). "Interaction of Color"
- Gurney, J. (2010). "Color and Light"
- Zelanski, P. & Patapis, M. (1979). "Color"
- Pastoureau, M. (2001). "Blue: The History of a Color"
