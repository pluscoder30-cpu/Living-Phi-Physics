# Phi-Psychology

## The Complete System

**Phi-Weighted Psychology:** Phi-perception (golden angle in vision), phi-emotion models, phi-behavioral patterns, phi-therapy approaches, and consciousness-field psychological coupling.

---

### Files

| # | File | Description | Lines |
|---|------|-------------|-------|
| 1 | [01_phi_psychology_theory.md](01_phi_psychology_theory.md) | Complete theory: phi-perception, phi-emotion, phi-behavior, phi-therapy | ~400 |
| 2 | [02_phi_psychology_tables.md](02_phi_psychology_tables.md) | Phi-visual angles, phi-emotion weights, phi-behavioral pattern tables | ~350 |
| 3 | [03_phi_psychology_examples.md](03_phi_psychology_examples.md) | 20 worked examples: phi-visual perception to phi-cognitive load | ~350 |
| 4 | [04_phi_psychology_applications.md](04_phi_psychology_applications.md) | Phi-UX design, phi-therapy protocols, phi-aesthetics, phi-music therapy | ~300 |
| 5 | [05_phi_psychology_problems.md](05_phi_psychology_problems.md) | 20 practice problems | ~150 |
| 6 | [06_phi_psychology_answers.md](06_phi_psychology_answers.md) | Complete answer key with solutions | ~300 |
| 7 | [README.md](README.md) | This index | ~80 |

**Total: ~1,930 lines across 7 files**

---

### Quick Reference

```
Phi-perception threshold:
  P_φ = P₀ × φ^(-d/eccentricity)

Phi-aesthetic preference:
  A_φ = Σ w_i × φ^(-|r_i - φ|)

Phi-emotional intensity:
  I_φ = I₀ × φ^(arousal/valence)

Phi-attention span:
  T_φ = T₀ × φ^(-cognitive_load/max_load)

Phi-learning rate:
  L_φ = L₀ × φ^(-n_trials/τ_adaptation)

Phi-behavioral entropy:
  H_φ = -Σ p_i × log_φ(p_i)

Phi-therapy dosage:
  D_φ = D₀ × φ^(-session_number/τ_progress)

Phi-cognitive load:
  CL_φ = Σ task_i × φ^(-priority/φ)

Phi-memory retrieval:
  R_φ = R₀ × φ^(-t/τ_decay) × φ^(rehearsal_count/10)
```

**Key constants:**
```
φ          = 1.6180339887...  [golden ratio]
θ_golden   = 137.5°           [golden angle in vision]
A_φ,max    = log_φ(N_choices) [phi-aesthetic capacity]
I_φ,base   = I₀/φ            [base emotional intensity]
T_φ,base   = T₀ × φ          [base attention span]
H_φ,max    = log_φ(S)        [max behavioral entropy]
D_φ,crit   = D₀ × φ^(-5)    [critical therapy dose]
CL_φ,max   = CL_max × φ     [max cognitive load capacity]
```

---

### What This System Covers

1. **Phi-Perception** — Golden angle in visual field, phi-aesthetic preference curves, phi-motion detection
2. **Phi-Emotion** — Valence-arousal with phi-weighting, phi-emotional dynamics, phi-mood oscillations
3. **Phi-Behavior** — Choice architecture with phi-nudging, phi-habit formation, phi-decision-making
4. **Phi-Cognition** — Working memory phi-capacity, phi-attention allocation, phi-problem solving
5. **Phi-Therapy** — CBT with phi-dosing, phi-exposure therapy, phi-mindfulness protocols
6. **Phi-Social** — Group dynamics with phi-influence, phi-conformity thresholds, phi-leadership scaling

---

### Connection to Other Phi-Systems

| System | Key Formula | Connection |
|--------|-------------|------------|
| Phi-Physics Core | φ = 1.618... | Foundation constant |
| Phi-Neuroscience | f_φ = f₀ × φ^(-ΔV/V₀) | Neural perception bridge |
| Phi-Biology | r_φ = r/φ | Evolutionary psychology |
| Phi-Music | f_n = f₀ × φ^n | Music therapy frequencies |
| Phi-Art | θ = 137.5° | Aesthetic perception |
| Void Mathematics | v(a,b) = φ⁻¹ min | Psychological void |

---

*Part of the 32_PHI_PHYSICS / 06_EXPANDED_MATHEMATICS system.*
*Version 1.0 — Agent I of 26*
