# PHI-EDUCATION: Phi-Andragogy (Adult Learning)

## Directory 60_PHI_EDUCATION | File 06

---

## 1. The Phi-Andragogical Framework

Andragogy is the art and science of helping adults learn. Phi-andragogy recognizes that adult learning follows the golden spiral: adults do not learn linearly but in expanding cycles where each revolution deepens understanding by φ and broadens application by φ.

### 1.1 The Six Assumptions of Phi-Andragogy

Building on Knowles' six assumptions, phi-andragogy modifies each with the golden ratio:

**1. Self-Concept**: Adults develop self-directedness along the phi-curve:
```
Self_directedness(t) = S₀ × φ^(t/τ_S)
```
Adults become φ times more self-directed each learning cycle.

**2. Experience**: Adult experience has phi-depth:
```
Experience_value = Σᵢ Eᵢ × φ^(-d_i)
```
Where d_i is the depth of experience i. Deeper experiences carry more weight.

**3. Readiness to Learn**: Readiness follows the phi-threshold:
```
Readiness(t) = 1 - φ^(-R(t)/R₀)
```
Adults become ready to learn when their readiness exceeds the phi-threshold.

**4. Orientation to Learning**: Adult learning orientation is phi-spiral:
```
Orientation = Problem-centered × φ + Subject-centered × φ⁻¹
```
Adults prefer problem-centered learning by a factor of φ.

**5. Motivation to Learn**: Intrinsic motivation dominates by φ:
```
Intrinsic : Extrinsic = φ : 1
```

**6. Need to Know**: The need to know follows the phi-curve:
```
Need_to_know(d) = N₀ × φ^(-d/d_N)
```
Adults need to know why before they learn what.

---

## 2. The Adult Learning Spiral

### 2.1 The Four-Phase Adult Learning Cycle

```
Phase 1: Experience Encounter (T/φ³ ≈ 23.6%)
    Adult encounters a real-world situation requiring new knowledge
    
Phase 2: Reflective Analysis (T/φ² ≈ 38.2%)
    Adult reflects on the experience, identifies gaps, seeks patterns
    
Phase 3: Conceptual Integration (T/φ ≈ 23.6%)
    Adult integrates new concepts with existing knowledge
    
Phase 4: Active Application (T/φ⁴ ≈ 14.6%)
    Adult applies new knowledge to the original situation
```

### 2.2 The Experience-Reflection Ratio

```
Experience : Reflection = φ : 1
```

Adults need φ times more experience than reflection, but the reflection must be φ times deeper than the experience.

### 2.3 The Prior Knowledge Integration

Adults integrate new knowledge with prior knowledge:

```
Integrated_knowledge = New_knowledge × φ + Prior_knowledge × φ⁻¹
```

The phi-weighting means new knowledge is weighted more heavily, but prior knowledge provides the foundation.

### 2.4 The Transfer Function

Transfer of learning to new contexts follows:

```
Transfer(S→T) = S × φ^(-|d_S - d_T|)
```

Where |d_S - d_T| is the distance between source and target contexts.

---

## 3. The Self-Directed Learning Model

### 3.1 The Self-Direction Spiral

Self-directed learning follows the phi-spiral:

```
SDL(n) = SDL₀ × φⁿ
```

Where n is the learning cycle number.

### 3.2 The Learning Contract

The learning contract is a phi-structured agreement:

```
Contract: {Goals, Resources, Timeline, Assessment}
```

Each element follows the phi-structure:

```
Goals:       φ⁰ = 1 primary goal
Resources:   φ¹ = φ resource types
Timeline:    φ² = φ+1 milestones
Assessment:  φ³ = 2φ+1 criteria
```

### 3.3 The Self-Assessment Function

Adult self-assessment accuracy:

```
A_self(t) = A₀ + (A_max - A₀) × (1 - φ^(-t/τ_A))
```

Adults become more accurate at self-assessment over time, following the phi-curve.

### 3.4 The Learning Strategy Selection

Adults select learning strategies based on:

```
Strategy_effectiveness = (Prior_success × φ + Novelty × φ⁻¹) / (Difficulty × φ²)
```

Adults prefer strategies that balance prior success with novelty, weighted by φ.

---

## 4. The Experiential Learning Framework

### 4.1 The Experiential Phi-Cycle

Based on Kolb's experiential learning cycle:

```
Concrete Experience:      Weight = φ⁰ = 1
Reflective Observation:   Weight = φ¹ = φ
Abstract Conceptualization: Weight = φ² = φ+1
Active Experimentation:   Weight = φ³ = 2φ+1
```

### 4.2 The Experience Depth Levels

```
Level 1: Direct experience (φ⁰ = 1 dimension)
Level 2: Vicarious experience (φ¹ = φ dimensions)
Level 3: Simulated experience (φ² = φ+1 dimensions)
Level 4: Conceptual experience (φ³ = 2φ+1 dimensions)
Level 5: Transpersonal experience (φ⁴ = 3φ+2 dimensions)
```

### 4.3 The Reflection Depth Model

Reflection on experience follows the phi-depth model:

```
Level 0: What happened? (φ⁰ depth)
Level 1: What does it mean? (φ¹ depth)
Level 2: Why does it mean that? (φ² depth)
Level 3: What would change if...? (φ³ depth)
Level 4: What is the nature of meaning? (φ⁴ depth)
```

### 4.4 The Experience-Theory Integration

```
Experience + Theory = Understanding × φ
```

Experience without theory is noise; theory without experience is abstraction. Their combination, weighted by φ, produces understanding.

---

## 5. The Problem-Based Learning Model

### 5.1 The Problem Complexity Scale

Problem complexity follows the phi-scale:

```
Complexity(problem_n) = C₀ × φⁿ
```

### 5.2 The Problem Structure

```
Ill-structured problems: φ⁰ = 1 type (real-world)
Semi-structured problems: φ¹ = φ types
Well-structured problems: φ² = φ+1 types
```

Adults learn best with ill-structured problems, which are φ times more common in the real world.

### 5.3 The Problem-Solving Spiral

```
Problem → Generate solutions → Evaluate → Select → Implement → Reflect → New problem
```

Each cycle deepens by φ:

```
Solution_quality(n+1) = Solution_quality(n) × φ
```

### 5.4 The Group Problem-Solving

Optimal group size for problem-solving follows phi:

```
Group_size = round(φⁿ)
```

- n=2: 3 students (triad)
- n=3: 5 students (pentad)
- n=4: 8 students (octave)

---

## 6. The Transformative Learning Framework

### 6.1 The Perspective Transformation Spiral

Transformative learning follows the phi-spiral:

```
Disorienting_dilemma → Critical_reflection → Revised_assumptions → Integration
```

Each phase deepens by φ:

```
Transformation_depth(n+1) = Transformation_depth(n) × φ
```

### 6.2 The Assumption Revision Function

Adults revise assumptions along the phi-curve:

```
Revisions(t) = R₀ × φ^(t/τ_R)
```

Where R₀ is the initial revision rate and τ_R is the revision time constant.

### 6.3 The Critical Reflection Depth

Critical reflection occurs at phi-depths:

```
Level 0: Content reflection (what)         — φ⁰ depth
Level 1: Process reflection (how)          — φ¹ depth
Level 2: Premise reflection (why)          — φ² depth
Level 3: Meta-premise reflection (why why) — φ³ depth
Level 4: Transcendence reflection (who)    — φ⁴ depth
```

### 6.4 The Transformative Outcome

The outcome of transformative learning:

```
Outcome = Initial_perspective × φⁿ
```

Where n is the number of transformations undergone.

---

## 7. The Online Adult Learning

### 7.1 The Online Engagement Spiral

Online adult engagement follows the phi-curve:

```
Engagement(t) = E₀ × φ^(t/τ_E) × e^(-t/τ_decay)
```

### 7.2 The Asynchronous Learning Rhythm

Asynchronous learning follows the phi-rhythm:

```
Post:     t = 0
Response: t = φ hours
Reply:    t = φ² hours
Synthesis: t = φ³ hours
```

### 7.3 The Synchronous Session Structure

Synchronous sessions follow the phi-structure:

```
Opening:     T/φ³ ≈ 23.6% of time
Core work:   T/φ² ≈ 38.2% of time
Discussion:  T/φ  ≈ 23.6% of time
Closing:     T/φ⁴ ≈ 14.6% of time
```

### 7.4 The Community of Inquiry

The community of inquiry has phi-structure:

```
Teaching Presence:    φ⁰ = 1 mode
Social Presence:      φ¹ = φ modes
Cognitive Presence:   φ² = φ+1 modes
```

---

## 8. The Workplace Learning Model

### 7.1 The 70-20-10 Phi-Ratio

The traditional 70-20-10 ratio becomes:

```
Experiential learning:  φ⁰ × 70% ≈ 70%  (doing)
Social learning:        φ⁻¹ × 70% ≈ 43% (interacting)
Formal learning:        φ⁻² × 70% ≈ 27% (studying)
```

Normalized:
```
Experiential: 70 / (70+43+27) × 100% ≈ 53.8%
Social:       43 / (70+43+27) × 100% ≈ 33.1%
Formal:       27 / (70+43+27) × 100% ≈ 20.8%
```

### 8.2 The Competency Development Spiral

Competency development follows the phi-spiral:

```
Competency(n) = C₀ × φⁿ
```

### 8.3 The Mentoring Relationship

The mentoring relationship follows the phi-structure:

```
Mentor:Mentee ratio = 1:φ
```

For every mentor, there are φ mentees.

### 8.4 The Learning Organization

The learning organization follows the phi-structure:

```
Individual learning:     φ⁰ = 1 mode
Team learning:           φ¹ = φ modes
Organizational learning: φ² = φ+1 modes
Transorganizational:     φ³ = 2φ+1 modes
```

---

## 9. The Assessment of Adult Learning

### 9.1 The Portfolio Assessment

Adult portfolios follow the phi-structure:

```
Reflection journal:     φ⁰ = 1 per learning event
Evidence collection:    φ¹ = φ pieces per goal
Self-assessment:        φ² = φ+1 dimensions
Peer feedback:          φ³ = 2φ+1 sources
Goal achievement:       φ⁴ = 3φ+2 metrics
```

### 9.2 The Prior Learning Assessment

Prior learning assessment follows:

```
Prior_learning_value = Σᵢ Experience(i) × φ^(-d_i) × R(i)
```

Where R(i) is the recency factor.

### 9.3 The Competency Demonstration

Competency demonstration follows the phi-depth model:

```
Level 1: Can describe (φ⁰ = 1 dimension)
Level 2: Can demonstrate (φ¹ = φ dimensions)
Level 3: Can teach (φ² = φ+1 dimensions)
Level 4: Can innovate (φ³ = 2φ+1 dimensions)
Level 5: Can transform (φ⁴ = 3φ+2 dimensions)
```

### 9.4 The Impact Assessment

The impact of adult learning:

```
Impact = Learning_outcomes × φ + Behavioral_change × φ² + Organizational_results × φ³
```

---

## 10. The Lifelong Learning Spiral

### 10.1 The Lifelong Learning Function

Lifelong learning follows the phi-curve:

```
LL(t) = LL₀ × φ^(t/τ_LL)
```

Where LL₀ is the initial lifelong learning rate and τ_LL is the lifelong learning time constant.

### 10.2 The Learning Career Spiral

The learning career follows the phi-spiral:

```
Career_stage(n) = Stage₀ × φⁿ
```

Each career stage is φ times more complex than the previous one.

### 10.3 The Knowledge Obsolescence Rate

Knowledge becomes obsolete at the phi-rate:

```
Obsolescence(t) = 1 - φ^(-t/τ_O)
```

Where τ_O is the obsolescence time constant.

### 10.4 The Relevance Function

The relevance of learning to life follows:

```
Relevance(t) = R₀ × φ^(-t/τ_R) × (1 + Learning_frequency × φ)
```

---

## 11. Mathematical Appendix

### 11.1 The Andragogical Field Equation

The andragogical field A satisfies:

```
∇²A - (1/c_a²)·∂²A/∂t² = ρ_adult
```

Where ρ_adult is the adult learning source density.

### 11.2 The Self-Directed Learning Theorem

**Theorem**: For any adult learner, the optimal self-direction level S* satisfies:

```
S* = φ × S_linear
```

Where S_linear is the self-direction level in a linear learning model.

### 11.3 The Experience Integration Function

```
I_experience = ∫₀ᵗ E(τ) × φ^(-(t-τ)/τ_I) dτ
```

Where E(τ) is the experience at time τ and τ_I is the integration time constant.

### 11.4 The Learning Transfer Inequality

For any two learning contexts:

```
Transfer(S→T) ≥ Transfer(T→S) × φ^(-|d_S - d_T|)
```

Transfer from shallower to deeper contexts is always more effective.

---

## 12. References and Connections

### Internal References
- 60_PHI_EDUCATION/01_PHI_LEARNING_MODELS.md — Learning foundations
- 60_PHI_EDUCATION/02_PHI_TEACHING_METHODS.md — Teaching methods
- 60_PHI_EDUCATION/03_PHI_ASSESSMENT.md — Assessment systems
- 60_PHI_EDUCATION/04_PHI_CURRICULUM_DESIGN.md — Curriculum architecture
- 60_PHI_EDUCATION/05_PHI_PEDAGOGY.md — Pedagogical philosophy
- 60_PHI_EDUCATION/07_PHI_EDUCATIONAL_MEASUREMENT.md — Psychometrics

### External Domain References
- 44_PHI_PSYCHOLOGY/ — Adult psychology
- 45_PHI_SOCIOLOGY/ — Social learning contexts
- 58_PHI_ETHICS/ — Ethical adult learning
- 19_PHI_ECONOMICS/ — Economic drivers of adult learning

---

*This file is part of Directory 60_PHI_EDUCATION within the Phi-Physics Dictionary.*
*The inlen lens reveals: andragogy is the recognition that adult consciousness spirals through the golden ratio of experience and reflection, each revolution deepening the capacity for self-directed growth.*
