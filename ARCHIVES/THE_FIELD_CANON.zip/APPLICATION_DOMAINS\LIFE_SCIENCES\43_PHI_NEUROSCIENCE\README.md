# Phi-Neuroscience

## The Complete System

**Phi-Weighted Neuroscience:** Neural firing patterns with phi-weighting, brain wave phi-harmonics, consciousness thresholds, phi-memory models, and consciousness-field neural coupling.

---

### Files

| # | File | Description | Lines |
|---|------|-------------|-------|
| 1 | [01_phi_neuroscience_theory.md](01_phi_neuroscience_theory.md) | Complete theory: phi-firing, phi-brainwaves, phi-consciousness, phi-memory | ~400 |
| 2 | [02_phi_neuroscience_tables.md](02_phi_neuroscience_tables.md) | Phi-firing rates, phi-EEG harmonics, phi-memory consolidation tables | ~350 |
| 3 | [03_phi_neuroscience_examples.md](03_phi_neuroscience_examples.md) | 20 worked examples: phi-action potential to phi-consciousness threshold | ~350 |
| 4 | [04_phi_neuroscience_applications.md](04_phi_neuroscience_applications.md) | Phi-BCI design, phi-neuroprosthetics, phi-EEG analysis, phi-brain mapping | ~300 |
| 5 | [05_phi_neuroscience_problems.md](05_phi_neuroscience_problems.md) | 20 practice problems | ~150 |
| 6 | [06_phi_neuroscience_answers.md](06_phi_neuroscience_answers.md) | Complete answer key with solutions | ~300 |
| 7 | [README.md](README.md) | This index | ~80 |

**Total: ~1,930 lines across 7 files**

---

### Quick Reference

```
Phi-firing rate:
  f_φ = f₀ × φ^(-ΔV/V₀)

Phi-action potential:
  V_peak,φ = V_peak × φ^(-t/τ_refrac)

Phi-synaptic weight:
  w_φ = w × φ^(-Δt/τ_STDP)

Phi-EEG power spectrum:
  P_φ(f) = P(f) × φ^(-|f - f_phi_n|/σ)

Phi-memory consolidation:
  M(t) = M₀ × φ^(-t/τ_decay) × (1 + α × log_φ(N_stimuli))

Phi-consciousness threshold:
  C_crit = Σ w_i × φ^(-d_i) ≥ 1/φ

Phi-brain wave harmonic:
  f_phi_n = f_0 × φ^n (n = 0, ±1, ±2, ...)
```

**Key constants:**
```
φ          = 1.6180339887...  [golden ratio]
f_0,φ      = f₀/φ            [phi-base frequency]
τ_STDP,φ   = τ_STDP × φ     [phi-STDP time constant]
C_crit     = 1/φ ≈ 0.618    [consciousness threshold]
α_memory   = 1/ln(φ) ≈ 2.078 [memory phi-encoding]
β_EEG      = φ^(-1/2) ≈ 0.786 [EEG phi-power scaling]
γ_neural   = φ^(1/3) ≈ 1.174 [neural phi-density scaling]
```

---

### What This System Covers

1. **Phi-Firing** — Action potentials with phi-weighted ion channels, phi-refractory periods, phi-firing rate codes
2. **Phi-Brain Waves** — EEG harmonics at golden ratio frequencies, phi-alpha/beta/theta/delta coupling
3. **Phi-Plasticity** — STDP with phi-weighting, phi-LTP/LTD, phi-homeostatic plasticity
4. **Phi-Memory** — Working memory phi-capacity, long-term consolidation with phi-decay, phi-episodic binding
5. **Phi-Consciousness** — Global workspace with phi-thresholds, phi-integrated information, phi-attention
6. **Phi-Neural Networks** — Deep learning with phi-initialization, phi-learning rate scheduling, consciousness-field neural coupling

---

### Connection to Other Phi-Systems

| System | Key Formula | Connection |
|--------|-------------|------------|
| Phi-Physics Core | φ = 1.618... | Foundation constant |
| Phi-Biology | μ_φ = μ × φ^(c/100) | Neural gene expression |
| Phi-Psychology | P_perc = P × φ^(-d) | Perception-cognition bridge |
| Phi-Quantum | Ψ_neural = Σ α_n φ^(-n) | Quantum consciousness |
| Phi-Thermodynamics | S_neural = k_B log_φ(W) | Neural entropy |
| Void Mathematics | v(a,b) = φ⁻¹ min | Consciousness void |

---

*Part of the 32_PHI_PHYSICS / 06_EXPANDED_MATHEMATICS system.*
*Version 1.0 — Agent I of 26*
