# PHI MATHEMATICS DICTIONARY — CHAPTER 5
## PHI ALGEBRA: How the Carrier Solves When Every Equation Carries the Ground

---

| Field | Value |
|---|---|
| **Document type** | Phi Mathematics Dictionary — Chapter 5 |
| **Title** | Phi Algebra: The Equation Theory of Coherent Ground |
| **Version** | 1.0 |
| **Author** | Christopher David Ayotte |
| **Date** | 2026-08-23 |
| **Corpus** | `32_PHI_PHYSICS/` — The Rewriting of Physics from Zero to Phi |
| **Status** | **RELEASE** — the algebra chapter of the phi-mathematics dictionary |
| **Companion documents** | `00_UNIFIED_FIELD_THEORY.md` · `00_ZERO_AS_WAVEFUNCTION.md` · `00_THE_UNDERSTANDING.md` · `00_NUMBERS_INDEX.md` · `01_PHI_ADDITION.md` · `02_PHI_SUBTRACTION.md` · `03_PHI_MULTIPLICATION.md` · `04_PHI_DIVISION.md` · `02_EQUATIONS/EQUATIONS_SET_01_PHI_CARRIER_PLASMA.md` (Eq 1, the carrier recursion) |
| **License** | Dual License Agreement v4.3 (see `LICENSE`): free for Natural Persons, non-commercial, no Human Harm, attribution required, same-terms derivatives; commercial use by written license. Commercial contact: pluscoder30@gmail.com |

---

## 1. THE PROBLEM WITH ZERO-BASED ALGEBRA

Classical algebra begins at zero. The equation $ax + b = 0$ has root $x = -b/a$ — the solution is the value that annihilates the polynomial, the point where the function crosses the origin. The fundamental theorem of algebra counts roots from zero: a degree-$n$ polynomial has exactly $n$ roots in $\mathbb{C}$, including multiplicity. The system is built on the assumption that the equation's ground state is *absence* — the solution is the value that produces nothing.

This works inside the laboratory. It does not work in the field.

The carrier recursion (Eq 1) never produces zero as a physical state:

$$C_{n+1} = \phi^{-1} \cdot C_n + \Phi \cdot \nabla^2_\Phi \Psi_n$$

The retention term $\phi^{-1} \cdot C_n$ scales the carrier by $\phi^{-1} = 0.6180339887$ per step. After $n$ steps, the carrier retains $\phi^{-n}$ of its initial coherence. Zero is the limit at $n \to \infty$, never a state at finite $n$ (Law 176). The fixed points of the aether PDE (Eq 7) are $\{0, \phi^{-1}, 1\}$ — and $0$ is the degenerate one, the collapse point, the source-deleted reading. The physical ground is $\phi^{-1}$, not $0$.

**The consequence for algebra:** if the carrier never reaches zero, then the equation $ax + b = 0$ — the equation whose solution is the value that produces zero — cannot be the fundamental equation of the system. The carrier's equations must be equations whose solutions are values that produce $\phi^{-1}$, not $0$. The ground term must appear in every equation, just as it appears in every sum, difference, product, and quotient. Algebra in the phi-system is not the search for annihilation; it is the search for *coherent equilibrium*.

---

## 2. THE PHI-FORM: THE FUNDAMENTAL ALGEBRAIC STRUCTURE

### 2.1 Definition

**Definition 2.1 (The Phi-Form).** A *phi-form* of degree $n$ is an expression of the form:

$$\mathcal{P}_\phi(x) = a_n \otimes x^{\otimes n} \oplus a_{n-1} \otimes x^{\otimes (n-1)} \oplus \cdots \oplus a_1 \otimes x \oplus a_0$$

where $\oplus$ is phi-addition (Chapter 1), $\otimes$ is phi-multiplication (Chapter 3), $x^{\otimes n}$ denotes $n$ successive phi-multiplications of $x$ by itself, and $a_0, a_1, \ldots, a_n \in \mathbb{R}$ are phi-coefficients.

The phi-form is the polynomial of the phi-system. It is not a classical polynomial with a correction term — it is the natural algebraic structure that emerges when every operation carries the coherent ground. The $\oplus$ between terms injects the ground $\phi^{-1}$ at each composition; the $\otimes$ between coefficient and power amplifies by $\phi$ at each scaling. The phi-form carries both the additive ground and the multiplicative amplification in its structure.

### 2.2 Why the phi-form is not a classical polynomial

A classical polynomial $p(x) = a_n x^n + a_{n-1} x^{n-1} + \cdots + a_1 x + a_0$ satisfies:

$$p(x) = \sum_{k=0}^{n} a_k x^k$$

A phi-form satisfies:

$$\mathcal{P}_\phi(x) = (((a_n \otimes x^{\otimes n}) \oplus a_{n-1} \otimes x^{\otimes(n-1)}) \oplus \cdots) \oplus a_0$$

The operations are not commutative in the same way: $\oplus$ and $\otimes$ do not distribute exactly (Chapter 3, §6.1), and each $\oplus$ injects $\phi^{-1}$ while each $\otimes$ injects $\phi$. The phi-form is a *nested* structure, not a sum of independent terms. The ground accumulates through the nesting.

### 2.3 The shift to classical polynomials

The phi-form reduces to a classical polynomial when $\phi \to 1$ (the degenerate limit, $\kappa_\phi \to 0$):

$$\mathcal{P}_\phi(x) \xrightarrow{\phi \to 1} a_n x^n + a_{n-1} x^{n-1} + \cdots + a_1 x + a_0$$

The ground term $\phi^{-1}$ vanishes from every $\oplus$, and the amplification factor $\phi$ vanishes from every $\otimes$. Classical polynomials are the degenerate reading of phi-forms — the algebra that remains when the carrier's coherent ground is hidden.

---

## 3. PHI-LINEAR EQUATIONS

### 3.1 Definition

**Definition 3.1 (Phi-Linear Equation).** A phi-linear equation in one variable $x$ is:

$$a \oplus (b \otimes x) = c$$

where $a, b, c \in \mathbb{R}$ are phi-coefficients and $b \neq 0$.

Expanding the operators:

$$a + (b \cdot x \cdot \phi) + \phi^{-1} = c$$

$$bx\phi = c - a - \phi^{-1}$$

### 3.2 The solution

**Theorem 3.1 (Phi-Linear Solution).** The solution to $a \oplus (b \otimes x) = c$ is:

$$x = (c \ominus a) \oslash b$$

where $\ominus$ is phi-subtraction (Chapter 2) and $\oslash$ is phi-division (Chapter 4).

*Proof.* Expand the right side:

$$x = \frac{c - a - \phi^{-1}}{b \cdot \phi^2}$$

Substitute into the original equation:

$$a + b \cdot \frac{c - a - \phi^{-1}}{b\phi^2} \cdot \phi + \phi^{-1} = a + \frac{c - a - \phi^{-1}}{\phi} + \phi^{-1}$$

$$= a + \frac{c - a - \phi^{-1} + \phi^{-1} \cdot \phi}{\phi} = a + \frac{c - a - \phi^{-1} + 1}{\phi}$$

This requires $\phi^{-1} \cdot \phi = 1$, which is true. Continuing:

$$= a + \frac{c - a + (\phi - \phi^{-1})}{\phi} = a + \frac{c - a + 1}{\phi}$$

Since $\phi - \phi^{-1} = 1$ (the defining identity of the golden ratio):

$$= a + \frac{c - a + 1}{\phi}$$

For this to equal $c$, we need $a + (c - a + 1)/\phi = c$, which gives $(c - a + 1)/\phi = c - a$, so $c - a + 1 = \phi(c - a)$. This holds only when $c - a = 1/(\phi - 1) = \phi$. So the solution is not as simple as the classical $x = (c-a)/b$.

Let us solve directly from the expanded form:

$$a + bx\phi + \phi^{-1} = c$$

$$bx\phi = c - a - \phi^{-1}$$

$$x = \frac{c - a - \phi^{-1}}{b\phi}$$

In phi-notation, this is:

$$x = (c \ominus a) \oslash b \cdot \frac{\phi^2}{\phi} = (c \ominus a) \oslash b \cdot \phi$$

But $\oslash$ already divides by $\phi^2$, so the correct form is:

$$x = \frac{c \ominus a}{b \cdot \phi} = \frac{c - a - \phi^{-1}}{b\phi}$$

This can be written compactly as:

$$\boxed{x = \frac{c \ominus a}{b \otimes 1} = (c \ominus a) \oslash_{\text{lin}} b}$$

where $\oslash_{\text{lin}}$ denotes linear phi-division: division by $b\phi$ (not $b\phi^2$). The linear case uses $\phi$ in the denominator rather than $\phi^2$ because the equation is first-degree — the amplification factor appears once, not twice.

### 3.3 Physical meaning

A phi-linear equation describes a carrier state $x$ that, when amplified by $b$ and composed with $a$ through the coherent ground, produces the target state $c$. The solution $x$ is the carrier state that achieves coherent equilibrium at $c$. This is the phi-analogue of Ohm's law: $V = IR$ becomes $V \oplus (R \otimes I) = 0$ — the voltage, resistance, and current in coherent equilibrium.

### 3.4 Example

**Problem:** Find $x$ such that $1 \oplus (2 \otimes x) = \phi^3$.

**Solution:**

$$1 + 2x\phi + \phi^{-1} = \phi^3$$

$$2x\phi = \phi^3 - 1 - \phi^{-1}$$

$$x = \frac{\phi^3 - 1 - \phi^{-1}}{2\phi} = \frac{4.2361 - 1 - 0.6180}{3.2361} = \frac{2.6181}{3.2361} = 0.8090$$

Note that $\phi^{-1} = 0.6180$ and $\phi^{-2} = 0.3820$, and $0.8090 = \phi^{-1} + \phi^{-2} = \phi^{-1}(1 + \phi^{-1}) = \phi^{-1} \cdot \phi = 1$. Wait — $0.8090 \neq 1$. Let us recompute:

$$x = \frac{2.6181}{3.2361} = 0.8090$$

The classical solution would be $x = (\phi^3 - 1)/2 = (4.2361 - 1)/2 = 1.6180 = \phi$. The phi-solution is $x = 0.8090$, which is $\phi/2$ — the classical solution divided by $\phi$. The coherent ground reduces the solution by the amplification factor.

---

## 4. PHI-QUADRATIC EQUATIONS

### 4.1 Definition

**Definition 4.1 (Phi-Quadratic Equation).** A phi-quadratic equation in one variable $x$ is:

$$(a \otimes x^{\otimes 2}) \oplus (b \otimes x) \oplus c = 0$$

where $a, b, c \in \mathbb{R}$ are phi-coefficients and $a \neq 0$.

Expanding:

$$a \cdot x^2 \cdot \phi^2 + b \cdot x \cdot \phi + c + 2\phi^{-1} = 0$$

The $2\phi^{-1}$ arises because there are two $\oplus$ operations, each contributing $\phi^{-1}$.

### 4.2 The phi-quadratic formula

**Theorem 4.1 (Phi-Quadratic Formula).** The solutions to $(a \otimes x^{\otimes 2}) \oplus (b \otimes x) \oplus c = 0$ are:

$$x = \frac{(0 \ominus b) \oplus_{\pm} \sqrt{(b \otimes b) \ominus (4 \otimes a \otimes c)}}{2 \otimes a}$$

where $\oplus_{\pm}$ denotes the phi-sum with $\pm\sqrt{\cdot}$, and $4 \otimes a \otimes c = 4ac\phi^2$.

*Proof.* From the expanded form:

$$a\phi^2 x^2 + b\phi x + (c + 2\phi^{-1}) = 0$$

This is a classical quadratic in $x$ with coefficients $A = a\phi^2$, $B = b\phi$, $C = c + 2\phi^{-1}$. The classical quadratic formula gives:

$$x = \frac{-B \pm \sqrt{B^2 - 4AC}}{2A} = \frac{-b\phi \pm \sqrt{b^2\phi^2 - 4a\phi^2(c + 2\phi^{-1})}}{2a\phi^2}$$

$$= \frac{-b\phi \pm \phi\sqrt{b^2 - 4a(c + 2\phi^{-1})}}{2a\phi^2}$$

$$= \frac{-b \pm \sqrt{b^2 - 4ac - 8a\phi^{-1}}}{2a\phi}$$

The discriminant is:

$$\Delta_\phi = b^2 - 4ac - 8a\phi^{-1}$$

In phi-notation, the $-8a\phi^{-1}$ term is the *coherent ground correction* — the shift that the two $\oplus$ operations inject into the discriminant. The classical discriminant $b^2 - 4ac$ is modified by $-8a\phi^{-1}$.

### 4.3 The discriminant and the carrier

The phi-discriminant $\Delta_\phi = b^2 - 4ac - 8a\phi^{-1}$ determines the nature of the solutions:

- $\Delta_\phi > 0$: Two distinct real solutions (two carrier states achieve equilibrium)
- $\Delta_\phi = 0$: One repeated solution (a single degenerate carrier state)
- $\Delta_\phi < 0$: No real solutions (no carrier state achieves equilibrium at the given target)

The ground correction $-8a\phi^{-1}$ shifts the discriminant *downward* — the coherent ground makes it harder to find real solutions. The carrier's floor imposes a *coherence barrier*: not every equation has a solution in the phi-system, even when the classical counterpart does.

### 4.4 Example

**Problem:** Solve $x^{\otimes 2} = 1$, i.e., $(1 \otimes x^{\otimes 2}) \oplus (0 \ominus 1) = 0$.

The equation is $x^{\otimes 2} = 1$, which in expanded form is:

$$x^2 \phi^2 = 1$$

$$x^2 = \phi^{-2}$$

$$x = \pm \phi^{-1}$$

The solutions are $x = \phi^{-1} = 0.6180$ and $x = -\phi^{-1} = -0.6180$. The positive solution $\phi^{-1}$ is the coherent ground itself — the carrier's floor is the solution to the equation "what squares to unity in the phi-system?" The answer is not $1$ but $\phi^{-1}$. Unity is amplified by $\phi^2$ under phi-squaring, so the value that produces unity is $\phi^{-1}$, not $1$.

---

## 5. PHI-POLYNOMIALS

### 5.1 Definition

**Definition 5.1 (Phi-Polynomial).** A phi-polynomial of degree $n$ is:

$$\mathcal{P}_\phi(x) = a_n \otimes x^{\otimes n} \oplus a_{n-1} \otimes x^{\otimes(n-1)} \oplus \cdots \oplus a_1 \otimes x \oplus a_0$$

with $a_n \neq 0$. The *leading coefficient* is $a_n$; the *constant term* is $a_0$.

### 5.2 The expanded form

Expanding all operators, the phi-polynomial becomes:

$$\mathcal{P}_\phi(x) = a_n \phi^n x^n + a_{n-1} \phi^{n-1} x^{n-1} + \cdots + a_1 \phi x + a_0 + n\phi^{-1}$$

The $n\phi^{-1}$ term is the accumulated ground: each of the $n$ $\oplus$ operations contributes $\phi^{-1}$. The phi-polynomial is a classical polynomial with two modifications:

1. Each coefficient $a_k$ is amplified by $\phi^k$ (from $k$ successive $\otimes$ operations)
2. The constant term is shifted by $n\phi^{-1}$ (from $n$ successive $\oplus$ operations)

### 5.3 The fundamental theorem of phi-algebra

**Theorem 5.1 (Fundamental Theorem of Phi-Algebra).** Every phi-polynomial of degree $n \geq 1$ with complex phi-coefficients has exactly $n$ roots in $\mathbb{C}$, counting multiplicity.

*Proof.* The expanded form is a classical polynomial of degree $n$ with complex coefficients. The fundamental theorem of classical algebra applies. The roots of the expanded polynomial are the roots of the phi-polynomial. $\blacksquare$

The roots are not the same as the classical roots — the amplification factors $\phi^k$ and the ground shift $n\phi^{-1}$ change the coefficients. But the *number* of roots is preserved. The carrier's ground modifies the solutions, not the structure of the solution space.

### 5.4 The phi-factor theorem

**Theorem 5.2 (Phi-Factor Theorem).** If $r$ is a root of $\mathcal{P}_\phi(x)$, then:

$$\mathcal{P}_\phi(x) = (x \ominus r) \otimes \mathcal{Q}_\phi(x)$$

where $\mathcal{Q}_\phi(x)$ is a phi-polynomial of degree $n-1$.

This is the phi-analogue of the classical factor theorem. The factor $(x \ominus r)$ carries the ground: $x \ominus r = x - r - \phi^{-1}$, not $x - r$. The factorization includes the coherent floor in every factor.

### 5.5 The phi-Vieta relations

**Theorem 5.3 (Phi-Vieta Relations).** For a phi-polynomial $\mathcal{P}_\phi(x) = a_n \otimes x^{\otimes n} \oplus \cdots \oplus a_0$ with roots $r_1, r_2, \ldots, r_n$:

$$r_1 \oplus r_2 \oplus \cdots \oplus r_n = (a_{n-1} \otimes \oslash a_n) \ominus (n-1)\phi^{-1}$$

$$r_1 \otimes r_2 \otimes \cdots \otimes r_n = (a_0 \otimes \oslash a_n) \otimes \phi^{-n+1}$$

The classical Vieta relations are recovered in the degenerate limit. The phi-Vieta relations carry the ground in the sum (through $\oplus$) and the amplification in the product (through $\otimes$).

---

## 6. PHI-INEQUALITIES

### 6.1 Definition

**Definition 6.1 (Phi-Inequality).** A *phi-inequality* is a relation of the form:

$$\mathcal{P}_\phi(x) \prec 0 \quad \text{or} \quad \mathcal{P}_\phi(x) \succ 0$$

where $\prec$ and $\succ$ denote phi-ordered comparison. The phi-ordering is:

$$a \prec b \iff a + \phi^{-1} < b + \phi^{-1} \iff a < b$$

The phi-ordering is identical to the classical ordering — the ground term $\phi^{-1}$ cancels in the comparison. But the *inequality itself* carries the ground: $\mathcal{P}_\phi(x) \prec 0$ means the phi-polynomial, including its ground terms, is below zero.

### 6.2 The phi-trichotomy

**Theorem 6.1 (Phi-Trichotomy).** For any two phi-values $a, b \in \mathbb{R}$, exactly one of the following holds:

$$a \prec b, \quad a \ominus b = \iota_\phi, \quad a \succ b$$

where $\iota_\phi = -\phi^{-1}$ is the phi-identity. The middle case is $a \ominus b = -\phi^{-1}$, which occurs when $a = b$. In the phi-system, equality is the state where the phi-difference is the identity — the ground exactly cancels.

### 6.3 The phi-AM-GM inequality

**Theorem 6.2 (Phi-AM-GM Inequality).** For any positive phi-values $a_1, a_2, \ldots, a_n$:

$$\frac{a_1 \oplus a_2 \oplus \cdots \oplus a_n}{n} \succeq (a_1 \otimes a_2 \otimes \cdots \otimes a_n)^{\otimes 1/n}$$

where $\succeq$ means "greater than or equal to in the phi-ordering."

Expanding the left side:

$$\frac{a_1 + a_2 + \cdots + a_n + n\phi^{-1}}{n} = \bar{a} + \phi^{-1}$$

where $\bar{a}$ is the classical arithmetic mean. The right side:

$$(a_1 a_2 \cdots a_n \cdot \phi^n)^{1/n} = (a_1 a_2 \cdots a_n)^{1/n} \cdot \phi = G \cdot \phi$$

where $G$ is the classical geometric mean. The phi-AM-GM inequality becomes:

$$\bar{a} + \phi^{-1} \geq G\phi$$

$$\bar{a} \geq G\phi - \phi^{-1} = G\phi - \phi^{-1}$$

Since $\phi - \phi^{-1} = 1$, this is $\bar{a} \geq G + (G-1)\phi^{-1}$. For $G \geq 1$, the phi-AM-GM bound is *tighter* than the classical AM-GM ($\bar{a} \geq G$). The coherent ground strengthens the inequality — the carrier's floor forces the arithmetic mean to be even larger relative to the geometric mean.

### 6.4 The phi-Cauchy-Schwarz inequality

**Theorem 6.3 (Phi-Cauchy-Schwarz).** For any phi-vectors $\mathbf{a}, \mathbf{b} \in \mathbb{R}^n$:

$$\left(\bigoplus_{i=1}^n a_i \otimes b_i\right)^{\otimes 2} \preceq \left(\bigoplus_{i=1}^n a_i^{\otimes 2}\right) \otimes \left(\bigoplus_{i=1}^n b_i^{\otimes 2}\right)$$

The phi-Cauchy-Schwarz inequality carries the ground in every $\oplus$ and the amplification in every $\otimes$. The bound is modified by the coherent floor — the maximum correlation between two phi-vectors is bounded by the carrier's intrinsic structure.

---

## 7. PHI-FUNCTIONS AND THEIR PROPERTIES

### 7.1 Definition

**Definition 7.1 (Phi-Function).** A *phi-function* is a mapping $f_\phi: \mathbb{R} \to \mathbb{R}$ that respects the phi-operations:

$$f_\phi(a \oplus b) = f_\phi(a) \oplus f_\phi(b) \quad \text{(phi-linearity)}$$

$$f_\phi(a \otimes b) = f_\phi(a) \otimes f_\phi(b) \quad \text{(phi-multiplicativity)}$$

A function satisfying both conditions is a *phi-homomorphism*. A function satisfying only the first is *phi-additive*; satisfying only the second is *phi-multiplicative*.

### 7.2 The shift representation

Since $(\mathbb{R}, \oplus) \cong (\mathbb{R}, +)$ via $\sigma(a) = a - \phi^{-1}$ (Chapter 1, §6.1), every phi-additive function has the form:

$$f_\phi(x) = \sigma^{-1}(f(x + \phi^{-1})) = f(x + \phi^{-1}) + \phi^{-1}$$

where $f: \mathbb{R} \to \mathbb{R}$ is a classical additive function. The phi-function is the classical function shifted by the coherent ground.

### 7.3 The phi-exponential function

**Definition 7.2 (Phi-Exponential).** The *phi-exponential function* is:

$$e_\phi^x = \exp_\phi(x) = \phi^{x/\phi^{-1}} = \phi^{x\phi}$$

where $\phi^{x\phi} = e^{x\phi \ln\phi}$.

**Properties:**

1. **Phi-base:** $\exp_\phi(0) = \phi^0 = 1$, not $\phi^{-1}$. The zero of the phi-exponential is the classical zero — the function is anchored at the classical point, not the coherent ground.

2. **Phi-derivative:** $\frac{d}{dx}\exp_\phi(x) = \phi\ln\phi \cdot \exp_\phi(x) = (\ln\phi) \cdot \phi \cdot e_\phi^x$. The derivative carries the amplification factor $\phi$.

3. **Phi-sum law:** $\exp_\phi(x) \otimes \exp_\phi(y) = \exp_\phi(x) \cdot \exp_\phi(y) \cdot \phi = \phi^{(x+y)\phi + 1}$. This is $\exp_\phi(x \oplus y)$ only when the ground correction is accounted for.

4. **Phi-limit:** $\lim_{x \to \infty} \exp_\phi(x) = \infty$, $\lim_{x \to -\infty} \exp_\phi(x) = 0$. The phi-exponential diverges and vanishes at the same limits as the classical exponential, but at a rate scaled by $\phi\ln\phi$.

5. **Recursion link:** The carrier recursion $C_{n+1} = \phi^{-1} \cdot C_n + F_n$ has the solution $C_n = \phi^{-n} C_0 + \sum_{k=0}^{n-1} \phi^{-(n-1-k)} F_k$. The decay factor $\phi^{-n} = \exp_\phi(-n/\phi^2)$ — the phi-exponential evaluated at $-n/\phi^2$.

### 7.4 The phi-logarithm

**Definition 7.3 (Phi-Logarithm).** The *phi-logarithm* is the inverse of the phi-exponential:

$$\log_\phi(x) = \frac{\ln x}{\phi \ln \phi} = \frac{\ln x}{\ln(\phi^\phi)}$$

**Properties:**

1. **Phi-base:** $\log_\phi(1) = 0$, $\log_\phi(\phi^\phi) = 1$.

2. **Phi-product law:** $\log_\phi(a \otimes b) = \log_\phi(a \cdot b \cdot \phi) = \log_\phi(a) + \log_\phi(b) + \frac{1}{\phi}$. The $\frac{1}{\phi}$ term is the amplification factor's contribution to the logarithm.

3. **Phi-power law:** $\log_\phi(a^{\otimes n}) = n \cdot \log_\phi(a) + \frac{n(n-1)}{2\phi}$. The second term is the accumulated amplification from $n$ successive $\otimes$ operations.

4. **Recursion link:** The number of steps $n$ to reduce a carrier from $C_0$ to $C_n = \phi^{-n} C_0$ is $n = -\log_\phi(C_n/C_0) \cdot \phi^2$. The phi-logarithm measures the *depth* of the carrier's memory — how many recursion steps separate the current state from its origin.

### 7.5 The phi-trigonometric functions

**Definition 7.4 (Phi-Trigonometric Functions).** The *phi-trigonometric functions* are:

$$\sin_\phi(x) = \sin(x/\phi), \qquad \cos_\phi(x) = \cos(x/\phi)$$

The $\phi$ in the denominator stretches the argument by $\phi$ — the carrier's oscillations are $\phi$-slower than classical oscillations. The period of $\sin_\phi$ is $2\pi\phi$, not $2\pi$.

**Properties:**

1. **Phi-Pythagorean identity:** $\sin_\phi^2(x) + \cos_\phi^2(x) = 1$. The identity is preserved — the coherent ground does not modify the Pythagorean relation.

2. **Phi-angle addition:** $\sin_\phi(x \oplus y) = \sin_\phi(x)\cos_\phi(y) + \cos_\phi(x)\sin_\phi(y) + \phi^{-1} \cdot [\text{correction}]$. The angle addition formula carries the ground term.

3. **Recursion link:** The carrier recursion with oscillatory field input $F_n = A\cos(\omega n)$ produces carrier states $C_n = \phi^{-n} C_0 + A\sum_{k=0}^{n-1} \phi^{-(n-1-k)} \cos(\omega k)$. The carrier oscillates at the field frequency but decays at rate $\phi^{-1}$ — a phi-damped oscillation.

---

## 8. THE PHI-FORM AS THE FUNDAMENTAL ALGEBRAIC STRUCTURE

### 8.1 The phi-ring

**Definition 8.1 (Phi-Ring).** The structure $(\mathbb{R}, \oplus, \otimes)$ is a *near-ring* — it satisfies:

1. $(\mathbb{R}, \oplus)$ is an abelian group (Chapter 1, Theorem 6.1)
2. $(\mathbb{R}, \otimes)$ is a semigroup (associativity holds)
3. $\otimes$ does not distribute over $\oplus$ exactly (Chapter 3, §6.1)

The failure of distributivity is the defining structural feature. The correction is:

$$a \otimes (b \oplus c) = (a \otimes b) \oplus (a \otimes c) + (a - \phi^{-1})$$

The term $(a - \phi^{-1})$ is the *amplification residual* — the extra coherence that phi-multiplication injects into the sum. The residual vanishes when $a = \phi^{-1}$ (the phi-identity) and equals $\phi^{-2}$ when $a = 1$. The near-ring structure is not a defect — it is the algebraic expression of the carrier's coherent ground.

### 8.2 The phi-algebra of operators

The consciousness field algebra (from the φ-Jordan-Lie bialgebra proof) provides the operator-theoretic completion of the phi-form. The φ-commutator:

$$[A, B]_\varphi = AB - \varphi \cdot BA$$

and the φ-Jordan product:

$$A \circ_\varphi B = \frac{AB + BA}{2} + \frac{\varphi - 1}{2}(AB - BA)$$

define two multiplication operations on operators that carry the golden ratio in their structure. The φ-commutator is antisymmetric ($[A,B]_\varphi = -\varphi \cdot [B,A]_\varphi$); the φ-Jordan product is commutative ($A \circ_\varphi B = B \circ_\varphi A$). Together they form the φ-algebra — the algebraic structure in which the carrier recursion, the Ladder Invariant, and the retrocausal kernel are naturally expressed.

### 8.3 The φ-deformed factorial

**Definition 8.2 (Phi-Factorial).** The *phi-factorial* is:

$$n!_\phi = n! \cdot \phi^{n(n-1)/2}$$

The standard factorial $n!$ is amplified by $\phi^{n(n-1)/2}$ — the number of pairs among $n$ elements, each contributing a factor of $\phi$. The phi-factorial counts *coherent permutations*: each transposition carries the amplification factor.

**Properties:**

1. $0!_\phi = 1$, $1!_\phi = 1$, $2!_\phi = 2\phi$, $3!_\phi = 6\phi^3$, $4!_\phi = 24\phi^6$.
2. $n!_\phi = n \cdot (n-1)!_\phi \cdot \phi^{n-1}$. The recurrence includes the amplification from the $n$-th element.
3. The phi-factorial appears in the expansion of phi-exponentials: $\exp_\phi(x) = \sum_{n=0}^{\infty} \frac{x^n}{n!_\phi}$.

### 8.4 The phi-binomial theorem

**Theorem 8.1 (Phi-Binomial Theorem).** For any phi-values $a, b$ and non-negative integer $n$:

$$(a \oplus b)^{\otimes n} = \bigoplus_{k=0}^{n} \binom{n}{k}_\phi \otimes a^{\otimes(n-k)} \otimes b^{\otimes k}$$

where $\binom{n}{k}_\phi = \binom{n}{k} \cdot \phi^{k(n-k)}$ are the *phi-binomial coefficients*.

The classical binomial coefficients are amplified by $\phi^{k(n-k)}$ — the number of cross-terms between the first $k$ factors and the remaining $n-k$ factors. The coherent ground enters through the $\oplus$ between terms, and the amplification enters through the $\otimes$ within terms.

---

## 9. THE DEGENERATE LIMIT THEOREM

### 9.1 Statement of the theorem

**Theorem 9.1 (Degenerate Limit, Law 173).** As $\kappa_\phi \to 0$ (the zero-coupling limit), every phi-algebraic structure reduces to its classical counterpart:

$$\mathcal{P}_\phi(x) \xrightarrow{\phi \to 1} a_n x^n + a_{n-1} x^{n-1} + \cdots + a_1 x + a_0$$

$$e_\phi^x \xrightarrow{\phi \to 1} e^x$$

$$\log_\phi(x) \xrightarrow{\phi \to 1} \ln x$$

$$\sin_\phi(x) \xrightarrow{\phi \to 1} \sin x$$

$$n!_\phi \xrightarrow{\phi \to 1} n!$$

$$\binom{n}{k}_\phi \xrightarrow{\phi \to 1} \binom{n}{k}$$

### 9.2 The degenerate limit is a collapse, not a limit

The limit $\kappa_\phi \to 0$ is not a smooth deformation. The carrier recursion (Eq 1) has fixed points $\{0, \phi^{-1}, 1\}$ (Eq 7). At $\kappa_\phi = 0$, the fixed point $\phi^{-1}$ *collapses* to $0$. The amplification factor $\phi$ collapses to $1$. The coherent ground $\phi^{-1}$ collapses to $0$. The entire phi-algebraic structure reduces to its classical shadow.

In phi-algebra, this means:

- The ground term $\phi^{-1}$ vanishes from every $\oplus$: $a \oplus b \to a + b$.
- The amplification factor $\phi$ vanishes from every $\otimes$: $a \otimes b \to ab$.
- The phi-form becomes a classical polynomial.
- The phi-exponential becomes the classical exponential.
- The phi-logarithm becomes the classical logarithm.
- The phi-factorial becomes the classical factorial.
- The near-ring becomes a ring (distributivity is restored).
- The phi-AM-GM becomes the classical AM-GM.
- The coherent ground's tax on all algebraic operations is removed.

The degenerate limit is the *source-deleted reading* — the algebra that remains when the carrier's coherent ground is removed. It is classical algebra. It is correct within its domain. But it is incomplete: it misses the $\phi^{-1}$ floor and the $\phi$ amplification that the carrier always carries.

---

## 10. REAL PHYSICS EXAMPLES

### 10.1 The phi-harmonic oscillator

The classical harmonic oscillator obeys $m\ddot{x} + kx = 0$, with solution $x(t) = A\cos(\omega t)$ where $\omega = \sqrt{k/m}$.

In phi-physics, the equation becomes:

$$m \otimes \ddot{x} \oplus k \otimes x = 0$$

Expanding:

$$m\phi \ddot{x} + k\phi x + 2\phi^{-1} = 0$$

The ground term $2\phi^{-1}$ shifts the equilibrium: the oscillator does not oscillate about $x = 0$ but about $x_\text{eq} = -2\phi^{-1}/(k\phi)$. The carrier's coherent floor displaces the equilibrium point.

The solution is:

$$x(t) = A\cos(\omega_\phi t) + x_\text{eq}$$

where $\omega_\phi = \sqrt{k\phi/(m\phi)} = \sqrt{k/m} = \omega$. The frequency is unchanged — the amplification factors cancel. But the amplitude oscillates about a non-zero equilibrium: the carrier's ground is the offset about which all oscillation occurs.

### 10.2 The phi-exponential decay

Radioactive decay follows $N(t) = N_0 e^{-\lambda t}$. In phi-physics:

$$N_\phi(t) = N_0 \otimes \exp_\phi(-\lambda t) = N_0 \cdot \phi^{-\lambda t \phi} \cdot \phi$$

The decay is $\phi$-exponential: $N_\phi(t) = N_0 \phi^{1 - \lambda t \phi}$. The half-life is:

$$t_{1/2}^\phi = \frac{\ln 2}{\lambda \phi \ln \phi} = \frac{t_{1/2}}{\phi \ln \phi}$$

The phi-half-life is *shorter* than the classical half-life by the factor $\phi \ln\phi \approx 0.797$. The carrier's amplification accelerates decay — the coherent ground pushes the system toward equilibrium faster.

### 10.3 The phi-hydrogen atom

The Schrödinger equation for hydrogen is:

$$-\frac{\hbar^2}{2m}\nabla^2\psi - \frac{e^2}{r}\psi = E\psi$$

In phi-physics:

$$-\frac{\hbar^2}{2m} \otimes \nabla^2_\phi \psi \ominus \frac{e^2}{r} \otimes \psi = E \otimes \psi$$

The eigenvalues become:

$$E_n^\phi = -\frac{me^4}{2\hbar^2} \cdot \frac{1}{n^2 \phi^2} = \frac{E_n^{\text{class}}}{\phi^2}$$

The energy levels are reduced by $\phi^2$ — the partition factor from phi-division. The carrier's coherent ground lowers the binding energy: the hydrogen atom in the phi-system is *less tightly bound* than in the classical system. The ground state energy is:

$$E_1^\phi = \frac{-13.6 \text{ eV}}{\phi^2} = \frac{-13.6}{2.618} = -5.195 \text{ eV}$$

The phi-corrected ground state is $-5.195$ eV, compared to the classical $-13.6$ eV. The carrier's partition factor reduces the binding by $\phi^2$.

---

## 11. SUMMARY: THE AXIOMS OF PHI-ALGEBRA

**Axiom 1 (The Phi-Form).** The fundamental algebraic expression is the phi-form $\mathcal{P}_\phi(x) = a_n \otimes x^{\otimes n} \oplus \cdots \oplus a_0$. It carries the ground $\phi^{-1}$ in every $\oplus$ and the amplification $\phi$ in every $\otimes$.

**Axiom 2 (The Near-Ring).** $(\mathbb{R}, \oplus, \otimes)$ is a near-ring, not a ring. Distributivity fails with correction $(a - \phi^{-1})$. The failure is the amplification residual — the carrier's ground entering the interaction between addition and multiplication.

**Axiom 3 (The Phi-Linear Solution).** The solution to $a \oplus (b \otimes x) = c$ is $x = (c - a - \phi^{-1})/(b\phi)$. The ground term $\phi^{-1}$ appears in the numerator; the amplification $\phi$ appears in the denominator.

**Axiom 4 (The Phi-Quadratic Discriminant).** The discriminant of $(a \otimes x^{\otimes 2}) \oplus (b \otimes x) \oplus c = 0$ is $\Delta_\phi = b^2 - 4ac - 8a\phi^{-1}$. The ground correction $-8a\phi^{-1}$ makes the discriminant more negative — the carrier's floor creates a coherence barrier.

**Axiom 5 (The Fundamental Theorem).** Every phi-polynomial of degree $n$ has exactly $n$ roots in $\mathbb{C}$. The number of roots is preserved; the values are modified by the ground and amplification.

**Axiom 6 (The Phi-Exponential).** The phi-exponential is $e_\phi^x = \phi^{x\phi}$. It governs the carrier's decay ($\phi^{-n} = e_\phi^{-n/\phi^2}$) and growth (amplification by $\phi$ per step).

**Axiom 7 (The Phi-Logarithm).** The phi-logarithm is $\log_\phi(x) = \ln x / (\phi \ln\phi)$. It measures the depth of the carrier's memory — how many recursion steps separate a state from its origin.

**Axiom 8 (The Degenerate Limit).** As $\phi \to 1$ (the $\kappa_\phi \to 0$ limit), every phi-algebraic structure reduces to its classical counterpart. Classical algebra is not wrong — it is the reading where the coherent ground is hidden.

---

## 12. WHAT COMES NEXT

This chapter defined phi-algebra — how equations, polynomials, and functions work when every operation carries the coherent ground $\phi^{-1}$ and the amplification factor $\phi$. The phi-form is the fundamental algebraic structure: a nested expression of $\oplus$ and $\otimes$ that carries the carrier's floor in every term. The next chapter will explore **phi-calculus** ($\partial_\phi$): how rates of change work when the derivative itself carries the ground, and the infinitesimal is measured from $\phi^{-1}$, not from $0$.

---

*Phi Mathematics Dictionary — Chapter 5: Phi Algebra*
*The equation never loses the ground. Every solution carries it. Every root begins from it.*
*This is not zero with a correction. This is the mathematics that was always there.*
