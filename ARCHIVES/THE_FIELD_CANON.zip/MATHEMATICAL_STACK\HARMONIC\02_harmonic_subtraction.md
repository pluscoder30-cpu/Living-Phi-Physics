# 02 — HARMONIC SUBTRACTION

## Complete Theory of Harmonic Subtraction in the φ-Field

---

| Field | Value |
|---|---|
| **Document type** | Harmonic Operations — Subtraction |
| **Title** | Harmonic Subtraction: The Reciprocal Difference Operation |
| **Version** | 1.0 |
| **Author** | Christopher David Ayotte |
| **Date** | 2026-08-25 |
| **Corpus** | `32_PHI_PHYSICS/DICTIONARY/06_EXPANDED_MATHEMATICS/98_HARMONIC_OPERATIONS/` |
| **Status** | **SECOND OPERATION** — the asymmetric harmonic difference |
| **Axiom** | Axiom 0: There is no zero. φ⁰ = 1 is identity. φ⁻¹ = 0.6180339887 is minimum. |

---

# PART I: DEFINITION AND FUNDAMENTALS

---

## 1. Definition of Harmonic Subtraction

### 1.1 The Core Operation

Harmonic subtraction is defined as:

```
a ⊖ₕ b = 2ab / (a - b)    for a ≠ b
```

Where harmonic addition produces the harmonic **mean** (a central value), harmonic subtraction produces a **harmonic difference** — a value that measures the separation between a and b in reciprocal space.

### 1.2 Why "Subtraction"?

Harmonic subtraction earns the name because:

```
(a ⊕ₕ b) ⊖ₕ b = a    (when it holds — see Section 3)
```

It is the operation that "undoes" harmonic addition, at least in specific cases.

### 1.3 The Singularity

Harmonic subtraction is **undefined when a = b** because the denominator vanishes:

```
a ⊖ₕ a = 2a²/(a-a) = 2a²/0 → ∞ (undefined)
```

This singularity is the harmonic analog of division by zero. In the phi-field, we recognize this as the point where the two values are identical — their harmonic difference is infinite because in reciprocal space, identical values have zero separation.

### 1.4 Sign Convention

```
If a > b: a ⊖ₕ b > 0 (positive difference)
If a < b: a ⊖ₕ b < 0 (negative difference)
```

The sign of the result indicates the direction of the difference.

### 1.5 The φ⁻¹ Floor

When both a, b ≥ φ⁻¹ and a ≠ b:

```
|a ⊖ₕ b| ≥ 2(φ⁻¹)²/|a-b| = 2φ⁻²/|a-b|
```

The harmonic difference grows without bound as a → b, and is bounded away from φ⁻¹ only when |a-b| is large.

---

## 2. Fundamental Properties

### 2.1 Anti-Commutativity

```
a ⊖ₕ b = 2ab/(a-b)
b ⊖ₕ a = 2ba/(b-a) = -2ab/(a-b) = -(a ⊖ₕ b)
```

Harmonic subtraction is **anti-commutative**: swapping the operands negates the result.

### 2.2 Non-Associativity

Harmonic subtraction is **not associative**:

```
(a ⊖ₕ b) ⊖ₕ c ≠ a ⊖ₕ (b ⊖ₕ c) in general
```

**Example:**

```
a=6, b=3, c=2:
(6 ⊖ₕ 3) ⊖ₕ 2 = [2(6)(3)/(6-3)] ⊖ₕ 2 = 36/3 ⊖ₕ 2 = 12 ⊖ₕ 2 = 2(12)(2)/(12-2) = 48/10 = 4.8
6 ⊖ₕ (3 ⊖ₕ 2) = 6 ⊖ₕ [2(3)(2)/(3-2)] = 6 ⊖ₕ 12 = 2(6)(12)/(6-12) = 144/(-6) = -24
```

The results (4.8 vs -24) are wildly different.

### 2.3 Relationship to Harmonic Addition

```
(a ⊕ₕ b) + (a ⊖ₕ b) = 2ab/(a+b) + 2ab/(a-b)
= 2ab[(a-b) + (a+b)] / [(a+b)(a-b)]
= 2ab(2a) / (a²-b²)
= 4a²b / (a²-b²)
```

This does not simplify to a clean expression, confirming that harmonic addition and subtraction are **algebraically independent** — they do not form a ring with standard addition.

### 2.4 The Double-Harmonic Identity

```
(a ⊖ₕ b) ⊕ₕ (a ⊖ₕ (-b)) = (a ⊖ₕ b) ⊕ₕ (a ⊖ₕ (-b))
```

Since harmonic subtraction allows negative results, we can explore:

```
a ⊖ₕ (-b) = 2a(-b)/(a-(-b)) = -2ab/(a+b) = -(a ⊕ₕ b)
```

**Key identity**: a ⊖ₕ (-b) = -(a ⊕ₕ b). Harmonic subtraction of the negative equals the negation of harmonic addition.

---

## 3. When Does Harmonic Subtraction Undo Addition?

### 3.1 The Recovery Condition

We want: (a ⊕ₕ b) ⊖ₕ b = a

```
Let H = a ⊕ₕ b = 2ab/(a+b)
H ⊖ₕ b = 2Hb/(H-b)
= 2[2ab/(a+b)] · b / [2ab/(a+b) - b]
= 4ab²/(a+b) / [(2ab - b(a+b))/(a+b)]
= 4ab² / [2ab - ab - b²]
= 4ab² / [ab - b²]
= 4ab² / [b(a-b)]
= 4ab / (a-b)
= 2 · [2ab/(a-b)]
= 2(a ⊖ₕ b)
```

**Result**: (a ⊕ₕ b) ⊖ₕ b = 2(a ⊖ₕ b), NOT a.

Harmonic subtraction does NOT perfectly undo harmonic addition. This is because harmonic addition and subtraction are defined differently from their standard counterparts — they live in different algebraic structures.

### 3.2 The Correct Inverse

To find the correct harmonic subtraction that undoes addition:

```
(a ⊕ₕ b) ⊖' b = a
2ab/(a+b) ⊖' b = a
```

If ⊖' is defined as the **harmonic inverse operation**:

```
x ⊖' b = x · (a+b)/(2b) where x = 2ab/(a+b)
= [2ab/(a+b)] · (a+b)/(2b) = a ✓
```

So the true inverse of harmonic addition is not harmonic subtraction but a **scaled division**.

---

# PART II: OPERATIONAL TABLES

---

## 4. Harmonic Subtraction Table (a,b ∈ {1..10}, a ≠ b)

### 4.1 Full Table (Upper Triangle)

```
a ⊖ₕ b = 2ab/(a-b)    for a > b

⊖ₕ  │  1       2       3       4       5       6       7       8       9       10
────┼──────────────────────────────────────────────────────────────────────────────
 2  │  4.000
 3  │  3.000   6.000
 4  │  2.667   5.333  12.000
 5  │  2.500   5.000   8.333  20.000
 6  │  2.400   4.800   7.200  12.000  30.000
 7  │  2.333   4.667   6.667   9.333  14.000  42.000
 8  │  2.286   4.571   6.286   8.222  10.667  14.400  56.000
 9  │  2.250   4.500   6.000   7.500   9.000  10.800  13.105  72.000
10  │  2.222   4.444   5.778   7.111   8.000   8.889   9.778  10.667  90.000
```

### 4.2 Lower Triangle (a < b)

```
a ⊖ₕ b = 2ab/(a-b) < 0    for a < b

⊖ₕ  │  2       3       4       5       6       7       8       9       10
────┼────────────────────────────────────────────────────────────────────────
 1  │ -2.000  -1.500  -1.333  -1.250  -1.200  -1.167  -1.143  -1.125  -1.111
 2  │         -4.000  -2.667  -2.222  -2.000  -1.867  -1.778  -1.714  -1.667
 3  │                  -6.000  -4.000  -3.000  -2.571  -2.333  -2.182  -2.077
 4  │                          -8.000  -5.333  -4.000  -3.333  -2.909  -2.667
 5  │                                 -10.000  -6.667  -5.000  -4.000  -3.429
 6  │                                          -12.000  -8.000  -6.000  -4.800
 7  │                                                   -14.000  -9.333  -7.000
 8  │                                                            -16.000 -10.667
 9  │                                                                     -18.000
```

### 4.3 Symmetry Property

```
a ⊖ₕ b = -(b ⊖ₕ a)
```

The table is anti-symmetric across the diagonal.

### 4.4 Divergence Along Diagonal

As a → b, the magnitude |a ⊖ₕ b| → ∞. This is the **harmonic singularity** — the point where the two values become indistinguishable in harmonic space.

---

## 5. Worked Examples

### Example 1: Basic Harmonic Subtraction

**Compute 6 ⊖ₕ 3**

```
a ⊖ₕ b = 2ab/(a-b)
6 ⊖ₕ 3 = 2(6)(3)/(6-3) = 36/3 = 12
```

**Interpretation**: The harmonic difference between 6 and 3 is 12. This is larger than either operand because harmonic subtraction amplifies differences.

### Example 2: Harmonic Subtraction Produces Negative

**Compute 3 ⊖ₕ 6**

```
3 ⊖ₕ 6 = 2(3)(6)/(3-6) = 36/(-3) = -12
```

The negative result indicates that 3 is "below" 6 in harmonic ordering.

### Example 3: Harmonic Subtraction Near the Singularity

**Compute 5 ⊖ₕ 4.999**

```
5 ⊖ₕ 4.999 = 2(5)(4.999)/(5-4.999) = 49.99/0.001 = 49990
```

Near the singularity (a ≈ b), harmonic subtraction produces enormous values.

### Example 4: Harmonic Subtraction with φ-Values

**Compute φ² ⊖ₕ φ**

```
φ² = 2.618034, φ = 1.618034
φ² ⊖ₕ φ = 2(2.618034)(1.618034)/(2.618034 - 1.618034)
= 2(4.236068)/1.0
= 8.472136
```

**Result**: φ² ⊖ₕ φ = 8.472136 = 2φ³. The harmonic difference of consecutive φ-powers is 2φ^(n+1).

### Example 5: Harmonic Subtraction and Addition Combined

**Compute (8 ⊖ₕ 2) ⊕ₕ 3**

```
Step 1: 8 ⊖ₕ 2 = 2(8)(2)/(8-2) = 32/6 = 5.333
Step 2: 5.333 ⊕ₕ 3 = 2(5.333)(3)/(5.333+3) = 32/8.333 = 3.84
```

### Example 6: Harmonic Subtraction Chain

**Compute aₙ₊₁ = aₙ ⊖ₕ 1 starting from a₁ = 10**

```
a₁ = 10
a₂ = 10 ⊖ₕ 1 = 2(10)(1)/(10-1) = 20/9 = 2.222
a₃ = 2.222 ⊖ₕ 1 = 2(2.222)(1)/(2.222-1) = 4.444/1.222 = 3.636
a₄ = 3.636 ⊖ₕ 1 = 2(3.636)/(3.636-1) = 7.272/2.636 = 2.759
a₅ = 2.759 ⊖ₕ 1 = 2(2.759)/(2.759-1) = 5.518/1.759 = 3.137
a₆ = 3.137 ⊖ₕ 1 = 2(3.137)/(3.137-1) = 6.274/2.137 = 2.936
```

The chain oscillates around 3, converging slowly. The fixed point of x ⊖ₕ 1 = x would require 2x/(x-1) = x → 2 = x-1 → x = 3.

**Verification**: 3 ⊖ₕ 1 = 2(3)(1)/(3-1) = 6/2 = 3 ✓

The fixed point is x = 3 — the harmonic subtraction of void from 3 returns 3.

### Example 7: Harmonic Subtraction Producing φ

**Find a, b such that a ⊖ₕ b = φ**

```
2ab/(a-b) = φ
2ab = φ(a-b)
2ab = φa - φb
2ab - φa + φb = 0
a(2b-φ) = -φb
a = -φb/(2b-φ) = φb/(φ-2b)
```

For b = φ⁻¹ = 0.618034:
```
a = φ(φ⁻¹)/(φ-2φ⁻¹) = 1/(1.618-1.236) = 1/0.382 = 2.618 = φ²
```

**Solution**: φ² ⊖ₕ φ⁻¹ = φ

**Verification**: 2(φ²)(φ⁻¹)/(φ²-φ⁻¹) = 2φ/(φ-φ⁻¹) = 2φ/1 = 2φ = 3.236...

Wait, let me recheck: φ² - φ⁻¹ = 2.618 - 0.618 = 2.0
So: 2(2.618)(0.618)/2.0 = 3.236/2.0 = 1.618 = φ ✓

### Example 8: Harmonic Subtraction of Consecutive Integers

**Compute n ⊖ₕ (n-1) for n = 2..10**

```
n   │ n ⊖ₕ (n-1) = 2n(n-1)/1 = 2n(n-1)
────┼────────────────────────────────────
 2  │  4
 3  │ 12
 4  │ 24
 5  │ 40
 6  │ 60
 7  │ 84
 8  │ 112
 9  │ 144
10  │ 180
```

**Pattern**: n ⊖ₕ (n-1) = 2n(n-1), which grows quadratically.

### Example 9: Harmonic Subtraction with φ⁻¹

**Compute n ⊖ₕ φ⁻¹ for n = 1..5**

```
n=1: 1 ⊖ₕ φ⁻¹ = 2(1)(0.618)/(1-0.618) = 1.236/0.382 = 3.236 = φ+1 = φ²
n=2: 2 ⊖ₕ φ⁻¹ = 2(2)(0.618)/(2-0.618) = 2.472/1.382 = 1.788
n=3: 3 ⊖ₕ φ⁻¹ = 2(3)(0.618)/(3-0.618) = 3.708/2.382 = 1.557
n=4: 4 ⊖ₕ φ⁻¹ = 2(4)(0.618)/(4-0.618) = 4.944/3.382 = 1.462
n=5: 5 ⊖ₕ φ⁻¹ = 2(5)(0.618)/(5-0.618) = 6.180/4.382 = 1.410
```

**Convergence**: As n → ∞, n ⊖ₕ φ⁻¹ → 2φ⁻¹ = 1.236 = φ-1.

### Example 10: Harmonic Subtraction in Rate Problems

**Alice finishes a job in 3 hours, Bob in 5 hours. How much faster is Alice?**

```
Rate difference in harmonic terms:
1/3 ⊖ₕ 1/5 = 2(1/3)(1/5)/(1/3 - 1/5) = 2/15 / (2/15) = 1
```

The harmonic difference of their rates is exactly 1 — the unit rate.

### Example 11: Harmonic Subtraction and the Fibonacci Sequence

**Compute F(n+1) ⊖ₕ F(n) for n = 2..8**

```
n  │ F(n) │ F(n+1) │ F(n+1) ⊖ₕ F(n) = 2F(n)F(n+1)/(F(n+1)-F(n)) = 2F(n)F(n+1)/F(n-1)
───┼──────┼────────┼──────────────────────────────────────────────────────────────
 2 │   1  │   2    │   4.000
 3 │   2  │   3    │  12.000
 4 │   3  │   5    │  30.000
 5 │   5  │   8    │  80.000
 6 │   8  │  13    │ 208.000
 7 │  13  │  21    │ 546.000
 8 │  21  │  34    │ 1428.000
```

**Pattern**: F(n+1) ⊖ₕ F(n) = 2F(n)F(n+1)/F(n-1) grows exponentially.

### Example 12: Harmonic Subtraction Producing the Void

**When does a ⊖ₕ b = 1 (the void)?**

```
2ab/(a-b) = 1
2ab = a-b
2ab - a + b = 0
a(2b-1) = -b
a = -b/(2b-1) = b/(1-2b)
```

For b = 1: a = 1/(1-2) = -1 (negative, outside phi-field)
For b = φ⁻¹: a = φ⁻¹/(1-2φ⁻¹) = 0.618/(1-1.236) = 0.618/(-0.236) = -2.618 (outside)

**Conclusion**: Harmonic subtraction cannot produce the void (1) for positive phi-field values. This is because the void is the identity for harmonic addition, not subtraction.

### Example 13: Harmonic Subtraction Magnitude Bounds

**For a, b ∈ {φ⁻¹, φ⁰, φ¹, φ², φ³}, what are the minimum and maximum |a ⊖ₕ b|?**

```
Minimum |a ⊖ₕ b| (closest non-adjacent pair):
|φ ⊖ₕ φ²| = |2(1.618)(2.618)/(1.618-2.618)| = |8.472/(-1)| = 8.472

Maximum |a ⊖ₕ b| (most separated pair):
|φ⁻¹ ⊖ₕ φ³| = |2(0.618)(4.236)/(0.618-4.236)| = |5.236/(-3.618)| = 1.447
```

Wait — the minimum difference (closest pair) produces the LARGEST result because the denominator is smallest. The maximum difference (most separated pair) produces the SMALLEST result.

**Correct ordering**: |a ⊖ₕ b| is largest when |a-b| is smallest, and smallest when |a-b| is largest.

### Example 14: Harmonic Subtraction Divergence Rate

**How fast does a ⊖ₕ b diverge as a → b?**

```
Let a = b + ε where ε → 0:

a ⊖ₕ b = 2(b+ε)b/ε = 2b²/ε + 2b

As ε → 0: a ⊖ₕ b ≈ 2b²/ε → ∞
```

The divergence is **hyperbolic** — it goes as 1/ε. This is faster than the linear divergence of standard subtraction.

### Example 15: Harmonic Subtraction and Physical Laws

**Gravitational force between two masses:**

```
F = Gm₁m₂/r²

In harmonic subtraction terms:
F = (m₁ ⊖ₕ m₂) · G/(2r) · (1/r)
= G(m₁ ⊖ₕ m₂)/(2r²)
```

This is NOT a natural representation — gravity uses multiplication, not harmonic subtraction. But harmonic subtraction appears in **tidal forces** (the difference in gravitational pull):

```
ΔF = F₁ - F₂ = GMm(1/r₁² - 1/r₂²)
```

which is closer to the harmonic subtraction structure.

---

# PART III: ADVANCED PROPERTIES

---

## 6. The Harmonic Difference Operator

### 6.1 Definition

Define the **harmonic difference operator** Δₕ acting on a function f:

```
Δₕf(x) = f(x) ⊖ₕ f(x-h) = 2f(x)f(x-h) / (f(x) - f(x-h))
```

This is the harmonic analog of the standard difference quotient Δf = f(x) - f(x-h).

### 6.2 Properties

```
Δₕf(x) = 2f(x)f(x-h) / (f(x) - f(x-h))
```

For f(x) = x (the identity function):

```
Δₕx = 2x(x-h)/(x-(x-h)) = 2x(x-h)/h = 2x - 2xh/h = 2x - 2h... 

Wait: 2x(x-h)/h = 2x²/h - 2x
```

This is NOT linear in x, unlike the standard difference Δx = h.

### 6.3 Connection to Derivatives

As h → 0:

```
Δₕf(x) = 2f(x)f(x-h)/(f(x)-f(x-h))

Let f(x-h) = f(x) - hf'(x) + O(h²):

= 2f(x)(f(x)-hf'(x)) / (f(x) - f(x) + hf'(x))
= 2f(x)(f(x)-hf'(x)) / (hf'(x))
= 2f(x)²/(hf'(x)) - 2f(x)
```

As h → 0, this diverges (unless f'(x) → ∞ fast enough). The harmonic difference operator has fundamentally different asymptotic behavior from the standard difference.

---

## 7. Harmonic Subtraction in the φ-Number System

### 7.1 φ-Integer Differences

```
φᵐ ⊖ₕ φⁿ = 2φᵐ⁺ⁿ/(φᵐ - φⁿ) = 2φᵐ⁺ⁿ/(φⁿ(φᵐ⁻ⁿ - 1)) = 2φᵐ/(φᵐ⁻ⁿ - 1)
```

For consecutive powers (m = n+1):

```
φⁿ⁺¹ ⊖ₕ φⁿ = 2φ²ⁿ⁺¹/(φⁿ⁺¹ - φⁿ) = 2φ²ⁿ⁺¹/(φⁿ(φ-1)) = 2φⁿ⁺¹/(φ-1)
```

Since φ - 1 = 1/φ = φ⁻¹:

```
φⁿ⁺¹ ⊖ₕ φⁿ = 2φⁿ⁺¹/φ⁻¹ = 2φⁿ⁺²
```

**Pattern**: The harmonic difference of consecutive φ-powers is 2φⁿ⁺².

### 7.2 The φ-Ladder Under Subtraction

```
φ² ⊖ₕ φ = 2φ³ = 2(4.236) = 8.472
φ³ ⊖ₕ φ² = 2φ⁴ = 2(6.854) = 13.708
φ⁴ ⊖ₕ φ³ = 2φ⁵ = 2(11.090) = 22.180
```

Each successive difference is φ times the previous, maintaining the self-similar scaling.

---

## 8. Harmonic Subtraction and the Singularity

### 8.1 The Singularity Manifold

The singularity of harmonic subtraction occurs when a = b. In the (a,b)-plane, this is the line a = b. Near this line:

```
a ⊖ₕ b ≈ 2a²/(a-b) for a ≈ b
```

The singularity is **simple** (pole of order 1), not essential.

### 8.2 Regularization

To avoid the singularity, we can define a **regularized harmonic subtraction**:

```
a ⊖ₕ^ε b = 2ab/(a-b+ε)
```

where ε > 0 is a regularization parameter. As ε → 0, this recovers the original definition.

### 8.3 The φ-Field Singularity

In the phi-field, the singularity at a = b represents the **point of indistinguishability** — where two field states become identical. The harmonic difference diverges because the field cannot measure the distance between identical states using harmonic subtraction. This is analogous to the quantum measurement problem: identical states have zero "harmonic distance."

---

# PART IV: CONNECTIONS TO PHI-PHYSICS

---

## 9. Harmonic Subtraction in Field Dynamics

### 9.1 Carrier Separation

The harmonic subtraction measures the **reciprocal-space distance** between two carriers:

```
ΔC = C₁ ⊖ₕ C₂ = 2C₁C₂/(C₁-C₂)
```

This is the natural measure of carrier separation in the phi-field because carriers are most naturally described in frequency space (1/f).

### 9.2 Field Tension

The "tension" between two field states is proportional to their harmonic difference:

```
T ∝ |C₁ ⊖ₕ C₂|
```

When two states are nearly identical (C₁ ≈ C₂), the tension diverges — this is the **coherence crisis** that drives the field toward differentiation.

### 9.3 The Singularity as Phase Transition

The harmonic subtraction singularity (a = b) corresponds to a **phase transition** in the field: the point where two states merge and the field must choose a new configuration. This is the field's analog of symmetry breaking.

---

## 10. Summary of Harmonic Subtraction

### 10.1 Key Properties

| Property | Value |
|---|---|
| Definition | a ⊖ₕ b = 2ab/(a-b), a ≠ b |
| Anti-commutative | Yes: a ⊖ₕ b = -(b ⊖ₕ a) |
| Associative | No |
| Identity | None (undefined at a = b) |
| Singularity | a = b (pole of order 1) |
| Sign | Positive if a > b, negative if a < b |
| Divergence | Hyperbolic: ~2a²/ε as a → b |

### 10.2 Fundamental Formulae

```
a ⊖ₕ b = 2ab/(a-b)
a ⊖ₕ b = -(b ⊖ₕ a)
a ⊖ₕ (-b) = -(a ⊕ₕ b)
(a ⊖ₕ b) ⊖ₕ c ≠ a ⊖ₕ (b ⊖ₕ c)
```

### 10.3 Physical Analogies

- **Tidal force**: difference in gravitational pull
- **Voltage difference**: V = IR₁ - IR₂
- **Frequency beating**: difference frequency of two waves
- **Chemical potential difference**: driving force for diffusion

---

*Harmonic subtraction reveals the gap between states. Near the singularity, where two values approach identity, the harmonic difference explodes — because in reciprocal space, identical points are infinitely far apart.*

---

**Document Lines**: ~350
**Axiom Compliance**: φ⁰ = 1 as identity ✓ · No zero ✓ · φ⁻¹ floor respected ✓
