# Foundation Mathematics: The Silver Ratio

## Welcome, Young Mathematician!

Have you ever wondered why your notebook paper fits perfectly inside a bigger piece of paper? Or why the windows on some buildings look so balanced? There's a special number called the **Silver Ratio** that makes these things work!

The silver ratio is approximately **2.41421356...** — and it's the ratio that makes paper fit inside paper!

---

## Part 1: What is the Silver Ratio?

### The Paper Fitting Number

The silver ratio (let's call it "sigma" or just "silver") is about **2.414**. It's called the silver ratio because it's the "next" ratio after the golden ratio, just like silver comes after gold in a medal ranking!

### Where Silver Hides

The silver ratio shows up in surprising places:

- **Paper Sizes**: An A4 sheet of paper has a special property. When you fold it in half, the folded piece has the same proportions as the original!

- **Octagons**: The ratio of the diagonal of a regular octagon to its side is the silver ratio!

- **Silver Rectangles**: A silver rectangle has a ratio of 1:2.414. If you cut off a square, you're left with another silver rectangle!

- **Music**: Some musical scales use silver ratio intervals.

### The Silver Sequence

Just like Fibonacci numbers lead to phi, there's a special sequence that leads to silver:

Start with: 2, 2

Then keep adding:
- 2 + 2 = 4
- 4 + 2 = 6
- 6 + 4 = 10
- 10 + 6 = 16
- 16 + 10 = 26
- 26 + 16 = 42

When you divide consecutive numbers, you get closer to silver:
- 4 ÷ 2 = 2
- 6 ÷ 4 = 1.5
- 10 ÷ 6 = 1.667
- 16 ÷ 10 = 1.6
- 26 ÷ 16 = 1.625
- 42 ÷ 26 = 1.615...

Wait, that's approaching phi, not silver! The silver sequence is different. Let me correct that:

The silver sequence is: 2, 2, 6, 14, 34, 82...

Where each term is twice the previous plus the one before:
- 2×2 + 2 = 6
- 2×6 + 2 = 14
- 2×14 + 6 = 34
- 2×34 + 14 = 82

When you divide consecutive terms:
- 6 ÷ 2 = 3
- 14 ÷ 6 = 2.333
- 34 ÷ 14 = 2.428...
- 82 ÷ 34 = 2.411...

Getting closer to 2.414!

---

## Part 2: The Silver Rectangle

### How to Draw a Silver Rectangle

A silver rectangle has the ratio 1:2.414. Here's how to make one:

**Step 1**: Draw a square that is 8 cm on each side.

**Step 2**: On the bottom side, measure 8 cm from the left corner. Mark that point.

**Step 3**: From that point, measure another 8 cm to the right. You now have a rectangle that is 8 cm × 16 cm.

**Step 4**: But wait — that's 1:2, not 1:2.414! The silver rectangle is a bit longer.

**Step 5**: To be precise, the long side should be 8 × 2.414 = 19.3 cm.

**Step 6**: Draw the rectangle 8 cm × 19.3 cm. That's a silver rectangle!

### The Silver Property

Here's what makes silver special:

If you cut off a square from a silver rectangle, you're left with ANOTHER silver rectangle!

Try it:
- Start with a rectangle that is 1 unit × 2.414 units
- Cut off a 1×1 square
- You're left with a rectangle that is 1 unit × 1.414 units
- The ratio is 1:1.414 — which is the same as 1.414:2 = 1:1.414

It works! Silver rectangles are "self-similar" just like golden rectangles!

---

## Part 3: What Happens When You Add Silver?

### Silver Addition is Cool

The silver ratio has its own special addition property:

Silver + 1 = Silver × Silver ÷ 2

Let's check:
- Silver = 2.414...
- Silver + 1 = 3.414...
- Silver × Silver = 5.828...
- Silver × Silver ÷ 2 = 2.914...

Hmm, that's not quite right. Let me share the actual property:

Silver² = 2 × Silver + 1

Let's verify:
- Silver² = 2.414² = 5.828...
- 2 × Silver + 1 = 2 × 2.414 + 1 = 4.828 + 1 = 5.828

Yes! That's the silver identity!

### More Silver Math

- Silver - 1 = 1.414... (which is √2!)
- Silver = 1 + √2
- 1 ÷ Silver = Silver - 2 = 0.414...

The silver ratio is deeply connected to the square root of 2!

---

## Part 4: Silver in Everyday Life

### Paper That Fits

The international paper standard (A4, A3, A2, etc.) uses a ratio close to silver:
- A4: 210 × 297 mm (ratio ≈ 1.414)
- Fold it in half: you get A5 (148 × 210 mm)
- Same ratio!

This is why paper sizes work so well — they're based on √2, which is closely related to silver!

### Architecture and Design

- **Windows**: Many traditional windows use silver proportions
- **Picture frames**: Silver rectangles are pleasing to the eye
- **Book covers**: Some books use silver proportions

### Music and Sound

- The **silver tuning** divides the octave into equal parts based on silver
- Some experimental music uses silver intervals

---

## Part 5: 10 Fun Exercises

### Exercise 1: The Paper Fold
Take a piece of A4 paper (or any rectangular paper). Fold it in half. Measure both pieces. Do they have the same proportions? Write down the ratios.

### Exercise 2: Draw a Silver Rectangle
Using a ruler, draw a rectangle that is 5 cm × 12.07 cm (5 × 2.414). Is it pleasing to look at? Compare it to a golden rectangle (5 cm × 8.09 cm).

### Exercise 3: Cut the Square
Draw a silver rectangle. Cut off a square from one end. What's left? Measure the remaining rectangle. Is it also silver? (Hint: it should be!)

### Exercise 4: The Octagon Connection
Draw a regular octagon (8-sided shape). Measure the distance across (through the center) and the length of one side. Divide the distance by the side length. What do you get?

### Exercise 5: Silver vs Gold
Draw both a golden rectangle and a silver rectangle with the same height. Which one is longer? By how much?

### Exercise 6: Paper Chain
Start with an A4 sheet. Fold it in half to get A5. Fold that to get A6. Keep going! Write down the dimensions of each piece. What pattern do you notice?

### Exercise 7: Build a Silver Spiral
Using the same method as the golden spiral, draw a silver spiral:
1. Draw a silver rectangle
2. Cut off a square
3. Draw another square in the remaining silver rectangle
4. Keep going!
5. Connect the corners with a smooth curve

### Exercise 8: Silver Shapes
Create a pattern using silver rectangles:
- Draw a silver rectangle
- Divide it into a square and a smaller silver rectangle
- Repeat in the smaller rectangle
- Color each section a different shade of blue

### Exercise 9: Real-World Silver Hunt
Find five things in your house that have silver proportions:
- A door
- A window
- A book
- A picture frame
- A tile

Measure each one. Which is closest to 2.414?

### Exercise 10: Silver Music
If you have access to a piano or keyboard, play notes that are a silver interval apart. How does it sound compared to notes a golden interval apart?

---

## Part 6: Amazing Silver Facts

### Fact 1: Silver and Diagonals
The diagonal of a square is √2 times its side. The silver ratio is 1 + √2. So silver connects squares to their diagonals!

### Fact 2: Silver Tiles
The octagonal tiling pattern (used in many floors) uses silver proportions. The octagons and squares fit together because of silver!

### Fact 3: Silver in Nature
Some crystal structures have silver proportions. The way atoms arrange themselves in certain minerals follows silver ratios!

### Fact 4: Silver Geometry
In a regular octagon:
- The ratio of the long diagonal to the short diagonal is silver
- The ratio of the long diagonal to the side is silver
- The ratio of the short diagonal to the side is √2

### Fact 5: Silver Paper Fold
When you fold a silver rectangle in half (parallel to the short side), you get TWO rectangles, each with the same proportions as the original! This is why A-series paper works so well.

---

## Part 7: Silver Poems

### The Silver Poem
Silver is the number that makes paper fold,
In rectangles that fit, stories to be told,
From A4 to A3, they all relate,
Silver is the ratio that makes paper great!

### The Metallic Rhyme
Two point four one four,
Silver shines right through,
Paper fits in paper,
Thanks to this ratio true!

---

## Part 8: What You've Learned

Today you discovered:

1. **The silver ratio** is about 2.414 — it's connected to √2 and makes paper folding work.

2. **Silver rectangles** have a special property: cut off a square and you get another silver rectangle.

3. **Paper sizes** (A4, A3, etc.) use ratios related to silver, which is why they fold so perfectly.

4. **Silver appears** in octagons, architecture, music, and crystal structures.

5. **The silver identity**: Silver² = 2 × Silver + 1

---

## Part 9: Challenge Problems

### Challenge 1: Prove the Silver Identity
Can you show that if Silver = 1 + √2, then Silver² = 2 × Silver + 1?

### Challenge 2: The Paper Problem
If you have an A0 sheet (841 × 1189 mm), how many A4 sheets can you cut from it? (Hint: think about how many times you can fold!)

### Challenge 3: Octagon Math
If a regular octagon has side length 1, what is its area? (Hint: think about the square it fits inside.)

### Challenge 4: Silver Fractions
The silver ratio can be written as a continued fraction:
Silver = 2 + 1/(2 + 1/(2 + 1/(2 + ...)))

Can you see why this works?

### Challenge 5: Silver Patterns
Create a tiling pattern using only silver rectangles and squares. How many different patterns can you make?

---

## Part 10: Glossary

**Continued Fraction**: A fraction that goes on forever, like a + 1/(b + 1/(c + ...))

**Irrational Number**: A number that can't be written as a simple fraction

**Octagon**: An eight-sided polygon

**Ratio**: A comparison of two numbers by division

**Rectangle**: A four-sided shape with four right angles

**Self-Similar**: A shape that looks the same at different scales

**Silver Ratio**: Approximately 2.414, equal to 1 + √2

**√2 (Square Root of 2)**: The number that, when multiplied by itself, gives 2. About 1.414

---

## Remember!

**Silver is the ratio that makes paper fit inside paper!**

The next time you fold a piece of paper, remember: you're working with a ratio that architects and artists have loved for centuries. Silver may not be as famous as gold (phi), but it's just as beautiful and useful!

---

*Math connects everything — from the paper you write on to the buildings you live in. Silver is one of those connecting numbers!*
