# 45_PHI_SOCIOLOGY — Phi-Harmonic Social Science

## Directory Contents

This directory contains the complete phi-harmonic sociology framework: mathematical models where the golden ratio φ = 1.6180339887 governs social network topology, information diffusion, cultural dynamics, demographic transitions, institutional scaling, urban morphology, and collective intelligence.

### Files

| # | File | Lines | Content |
|---|------|-------|---------|
| 01 | `01_phi_sociology_theory.md` | 250+ | Core axioms, phi-network topology, information cascade theory, cultural resonance |
| 02 | `02_phi_sociology_tables.md` | 220+ | Phi-sociological constants, network dimension tables, cascade thresholds, cultural metrics |
| 03 | `03_phi_sociology_examples.md` | 250+ | Worked examples: viral spread, community formation, urban scaling, institutional decay |
| 04 | `04_phi_sociology_applications.md` | 250+ | Real-world applications: social media optimization, policy design, urban planning |
| 05 | `05_phi_sociology_problems.md` | 250+ | Exercises: network analysis, cascade prediction, cultural metric computation |
| 06 | `06_phi_sociology_answers.md` | 280+ | Complete solutions with step-by-step derivations |
| 07 | `README.md` | 50+ | This file |

**Total: ~1,550 lines**

### Core Insight

Social systems exhibit phi-harmonic structure at every scale:
- **Networks**: Degree distributions follow φ-power laws, clustering coefficients approach 1/φ
- **Information**: Cascade probabilities decay as φ^(−d) where d is network distance
- **Culture**: Cultural trait resonance frequencies are integer multiples of φ
- **Demographics**: Population transitions phase-lock at golden ratio intervals
- **Institutions**: Optimal organizational depth = log_φ(N) for N members

### Phi-Social Constants

| Symbol | Value | Meaning |
|--------|-------|---------|
| φ | 1.6180339887... | Golden ratio, base of social scaling |
| λ_c | 1/φ² = 0.381966... | Critical cascade threshold |
| η_opt | φ^(−1) = 0.618034... | Optimal information retention |
| d_phi | log_φ(N) | Natural organizational depth |
| κ_c | 1/φ = 0.618034... | Network connectivity critical point |

### Relationship to Other Domains

```
45_PHI_SOCIOLOGY
    ├── 43_PHI_NEUROSCIENCE (individual cognition → group behavior)
    ├── 44_PHI_PSYCHOLOGY (personality → social roles)
    ├── 46_PHI_ANTHROPOLOGY (cultural evolution, civilizational cycles)
    └── 47_PHI_ENVIRONMENTAL_SCIENCE (societal-ecological coupling)
```
