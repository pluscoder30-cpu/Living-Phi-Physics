# PHI-ANTHROPOLOGY: Reference Tables

---

## Table 1: Phi-Anthropological Constants

| Symbol | Value | Meaning | Units |
|--------|-------|---------|-------|
| τ_civ | ~500 years | Civilizational time constant | years |
| τ_memory | ~500 years | Civilizational memory decay | years |
| τ_lang | ~300 years | Language drift time constant | years |
| τ_myth | ~400 years | Mythological cycle period | years |
| τ_branch | ~200 years | Language branching time | years |
| τ_stability | ~150 years | Cultural stability time | years |
| τ_obsolescence | ~100 years | Cultural trait obsolescence | years |
| D_c | φ × 10 ≈ 16.18 km²/yr | Cultural diffusivity | km²/yr |
| v_migrate | φ × 5 ≈ 8.09 km/yr | Migration velocity | km/yr |
| R_settle | φ × 50 ≈ 80.9 km | Settlement range | km |
| R_artifact | φ × 2 ≈ 3.24 km | Archaeological detection radius | km |
| τ_stratigraphy | ~200 years | Stratigraphic time constant | years |

---

## Table 2: Civilizational Cycle Periods

### 2a. Phi-Harmonic Civilizational Cycles

| Cycle (n) | Period (τ_civ × φ^n) | Duration (years) | Historical Examples |
|-----------|----------------------|------------------|---------------------|
| 0 | τ_civ × 1 | 500 | Local kingdom cycles |
| 1 | τ_civ × φ | 809 | Regional empire cycles |
| 2 | τ_civ × φ² | 1,309 | Continental empire cycles |
| 3 | τ_civ × φ³ | 2,118 | Global civilization cycles |
| 4 | τ_civ × φ⁴ | 3,427 | Species-level cycles |
| 5 | τ_civ × φ⁵ | 5,545 | Cosmic awareness cycles |

### 2b. Civilizational Rise and Fall Timing

| Phase | Standard Model | Phi-Model | Ratio |
|-------|---------------|-----------|-------|
| Rise | 1.0 × τ_rise | 0.618 × τ_rise | 0.618 |
| Peak | 1.0 × τ_peak | 1.0 × τ_peak | 1.000 |
| Fall | 1.0 × τ_fall | 1.618 × τ_fall | 1.618 |
| Recovery | 1.0 × τ_recovery | 0.382 × τ_recovery | 0.382 |

---

## Table 3: Migration Dynamics

### 3a. Migration Front Velocity

| Distance (r/R_front) | v/v₀ (phi) | v/v₀ (standard) | Speed Class |
|----------------------|------------|-----------------|-------------|
| 0 | 1.000 | 1.000 | Maximum |
| 0.5 | 0.786 | 0.607 | Fast |
| 1.0 | 0.618 | 0.368 | Moderate |
| 1.5 | 0.487 | 0.223 | Slow |
| 2.0 | 0.382 | 0.135 | Very Slow |
| 3.0 | 0.236 | 0.050 | Crawling |
| 5.0 | 0.090 | 0.007 | Negligible |

### 3b. Settlement Density

| Distance (r/R_settle) | ρ/ρ₀ (phi) | ρ/ρ₀ (standard) | Density Class |
|------------------------|------------|-----------------|---------------|
| 0 | 1.000 | 1.000 | Urban core |
| 0.5 | 0.786 | 0.607 | Inner suburb |
| 1.0 | 0.618 | 0.368 | Outer suburb |
| 1.5 | 0.487 | 0.223 | Peri-urban |
| 2.0 | 0.382 | 0.135 | Rural fringe |
| 3.0 | 0.236 | 0.050 | Rural |
| 5.0 | 0.090 | 0.007 | Remote |

### 3c. Migration Resistance

| Distance (r/R_resist) | R/R₀ (phi) | R/R₀ (standard) | Difficulty |
|------------------------|------------|-----------------|------------|
| 0 | 1.000 | 1.000 | Easy |
| 0.5 | 1.272 | 1.221 | Moderate |
| 1.0 | 1.618 | 1.649 | Difficult |
| 1.5 | 2.058 | 2.460 | Very Difficult |
| 2.0 | 2.618 | 3.694 | Extreme |
| 3.0 | 4.236 | 8.265 | Nearly Impossible |

---

## Table 4: Language Evolution

### 4a. Vocabulary Drift Rate

| Time (t/τ_lang) | Δv/v₀ (phi) | Δv/v₀ (standard) | Change Rate |
|-----------------|-------------|-------------------|-------------|
| 0 | 1.000 | 1.000 | Maximum drift |
| 0.5 | 0.786 | 0.607 | Fast change |
| 1.0 | 0.618 | 0.368 | Moderate |
| 2.0 | 0.382 | 0.135 | Slow |
| 3.0 | 0.236 | 0.050 | Very slow |
| 5.0 | 0.090 | 0.007 | Near-stable |

### 4b. Language Family Branching

| Time (t/τ_branch) | N/N₀ (phi) | N/N₀ (standard) | Diversity |
|--------------------|------------|-----------------|-----------|
| 0 | 1.000 | 1.000 | Monolingual |
| 1 | 1.618 | 1.000 | Bilingual |
| 2 | 2.618 | 1.000 | Trilingual |
| 5 | 11.089 | 1.000 | Multilingual |
| 10 | 122.99 | 1.000 | Hyperdiverse |
| 20 | 15127 | 1.000 | Extreme |

### 4c. Lexical Distance Growth

| Contacts | D/D₀ (phi) | D/D₀ (no contact) | Assimilation |
|----------|------------|--------------------|--------------|
| 0 | 1.000 | 1.000 | None |
| 1 | 0.618 | 1.000 | 38.2% |
| 2 | 0.382 | 1.000 | 61.8% |
| 3 | 0.236 | 1.000 | 76.4% |
| 5 | 0.090 | 1.000 | 91.0% |
| 10 | 0.009 | 1.000 | 99.1% |

---

## Table 5: Mythological Archetypes

### 5a. Archetype Frequency Hierarchy

| Depth (n) | P = φ^(−n) | Percentage | Examples |
|-----------|-----------|------------|----------|
| 0 | 1.000 | 100% | Hero, Trickster, Creator |
| 1 | 0.618 | 61.8% | Mentor, Shadow, Ally |
| 2 | 0.382 | 38.2% | Threshold Guardian, Herald |
| 3 | 0.236 | 23.6% | Shapeshifter, Refusal |
| 4 | 0.146 | 14.6% | Crossing Threshold |
| 5 | 0.090 | 9.0% | Atonement, Freedom |

### 5b. Mythological Cycle Periods

| Cycle (n) | Period (τ_myth × φ^n) | Duration | Examples |
|-----------|------------------------|----------|----------|
| 0 | 400 | 400 yr | Local myths |
| 1 | 647 | 647 yr | Regional epics |
| 2 | 1,067 | 1,067 yr | Cross-cultural myths |
| 3 | 1,727 | 1,727 yr | Civilizational myths |
| 4 | 2,794 | 2,794 yr | Species myths |
| 5 | 4,521 | 4,521 yr | Cosmic myths |

### 5c. Narrative Complexity Growth

| Time (τ_narrative) | K/K₀ (oral) | K/K₀ (written) | K/K₀ (digital) |
|--------------------|-------------|-----------------|-----------------|
| 1 | 1.618 | 1.618 | 1.618 |
| 5 | 11.089 | 11.089 | 11.089 |
| 10 | 122.99 | 122.99 | 122.99 |
| 50 | 1.5e11 | 1.5e11 | 1.5e11 |
| 100 | 1.6e22 | 1.6e22 | 1.6e22 |

---

## Table 6: Archaeological Patterns

### 6a. Settlement Layer Depth

| Layer (n) | D/D₀ (phi) | D/D₀ (linear) | Age (yr) |
|-----------|-----------|---------------|----------|
| 1 | 1.000 | 1.000 | 0-100 |
| 2 | 1.272 | 2.000 | 100-200 |
| 3 | 1.618 | 3.000 | 200-300 |
| 5 | 2.618 | 5.000 | 400-500 |
| 10 | 6.854 | 10.000 | 900-1000 |
| 20 | 29.03 | 20.000 | 1900-2000 |

### 6b. Artifact Density Distribution

| Distance (r/R) | ρ/ρ₀ (phi) | ρ/ρ₀ (standard) | Artifact Class |
|-----------------|-----------|-----------------|----------------|
| 0 | 1.000 | 1.000 | Core |
| 0.5 | 0.786 | 0.607 | Domestic |
| 1.0 | 0.618 | 0.368 | Industrial |
| 1.5 | 0.487 | 0.223 | Agricultural |
| 2.0 | 0.382 | 0.135 | Trade goods |
| 3.0 | 0.236 | 0.050 | Exotic imports |

### 6c. Trade Route Optimization

| Route Length | Efficiency (phi) | Efficiency (straight) | Advantage |
|-------------|------------------|----------------------|-----------|
| Short | 1.000 | 1.000 | Equal |
| Medium | 1.272 | 1.000 | +27.2% |
| Long | 1.618 | 1.000 | +61.8% |
| Very Long | 2.618 | 1.000 | +161.8% |
| Intercontinental | 4.236 | 1.000 | +323.6% |

---

## Table 7: Cultural Evolution

### 7a. Cultural Complexity Growth

| Time (t/τ) | K/K₀ (phi) | K/K₀ (standard) | Complexity |
|------------|-----------|-----------------|------------|
| 0 | 1.000 | 1.000 | Simple |
| 1 | 1.618 | 1.000 | Basic |
| 2 | 2.618 | 1.000 | Intermediate |
| 5 | 11.089 | 1.000 | Advanced |
| 10 | 122.99 | 1.000 | Complex |
| 20 | 15127 | 1.000 | Hyper-complex |

### 7b. Cultural Trait Selection

| Trait Distance | Fitness (phi) | Fitness (standard) | Pressure |
|---------------|--------------|--------------------|----------|
| 0 | 1.000 | 1.000 | None |
| 0.5Δτ | 0.786 | 0.882 | Moderate |
| 1.0Δτ | 0.618 | 0.607 | Strong |
| 1.5Δτ | 0.487 | 0.368 | Very Strong |
| 2.0Δτ | 0.382 | 0.135 | Extreme |
| 3.0Δτ | 0.236 | 0.011 | Lethal |

### 7c. Cultural Extinction Rate

| Age (τ/τ_obs) | E/E₀ (phi) | E/E₀ (standard) | Risk |
|---------------|-----------|-----------------|------|
| 0 | 1.000 | 1.000 | Baseline |
| 1 | 1.618 | 1.000 | +61.8% |
| 2 | 2.618 | 1.000 | +161.8% |
| 5 | 11.089 | 1.000 | +1009% |
| 10 | 122.99 | 1.000 | +12199% |

---

## Table 8: Historical Cycles

### 8a. Four-Fold Historical Cycles

| Cycle (n) | Period (years) | Pattern |
|-----------|---------------|---------|
| 0 | 400 | Foundation |
| 1 | 451 | Expansion |
| 2 | 509 | Consolidation |
| 3 | 574 | Decline |
| 4 | 647 | Renewal |
| 5 | 730 | New foundation |

### 8b. Technology Adoption S-Curve

| Time (t/τ) | A/A_max (phi) | A/A_max (standard) | Phase |
|------------|--------------|--------------------|-------|
| −3 | 0.002 | 0.000 | Innovation |
| −2 | 0.009 | 0.012 | Early adopters |
| −1 | 0.036 | 0.119 | Early majority |
| 0 | 0.146 | 0.500 | Inflection |
| 1 | 0.382 | 0.881 | Late majority |
| 2 | 0.618 | 0.988 | Laggards |
| 3 | 0.854 | 0.999 | Saturation |

### 8c. Historical Contingency Decay

| Time Between Events | P(B\|A) (phi) | P(B\|A) (standard) | Strength |
|--------------------|--------------|--------------------|----------|
| 1 τ | 0.618 | 0.368 | Strong |
| 2 τ | 0.382 | 0.135 | Moderate |
| 3 τ | 0.236 | 0.050 | Weak |
| 5 τ | 0.090 | 0.007 | Very Weak |
| 10 τ | 0.009 | 0.000 | Negligible |

---

## Table 9: Urban Morphology

### 9a. Street Network Branching

| Level | N/N₀ (phi) | N/N₀ (standard) | Street Type |
|-------|-----------|-----------------|-------------|
| 0 | 1.000 | 1.000 | Highways |
| 1 | 1.618 | 3.000 | Arterials |
| 2 | 2.618 | 9.000 | Collectors |
| 3 | 4.236 | 27.000 | Local streets |
| 4 | 6.854 | 81.000 | Alleys |

### 9b. Population Density Profile

| Distance (r/R) | ρ/ρ₀ (phi) | ρ/ρ₀ (standard) | Density Class |
|-----------------|-----------|-----------------|---------------|
| 0 | 1.000 | 1.000 | CBD |
| 0.2 | 0.871 | 0.819 | Inner city |
| 0.4 | 0.757 | 0.670 | Near suburb |
| 0.6 | 0.657 | 0.549 | Middle suburb |
| 0.8 | 0.571 | 0.449 | Outer suburb |
| 1.0 | 0.497 | 0.368 | Urban fringe |
| 1.5 | 0.352 | 0.223 | Peri-urban |
| 2.0 | 0.250 | 0.135 | Rural |

### 9c. Land Use Diversity

| Distance (r/R) | D/D₀ (phi) | D/D₀ (standard) | Mix Level |
|-----------------|-----------|-----------------|-----------|
| 0 | 1.000 | 1.000 | Maximum |
| 0.5 | 0.786 | 0.607 | High |
| 1.0 | 0.618 | 0.368 | Moderate |
| 1.5 | 0.487 | 0.223 | Low |
| 2.0 | 0.382 | 0.135 | Single-use |

---

## Table 10: Master Reference

### 10a. Dimensionless Groups

| Group | Definition | Value | Meaning |
|-------|-----------|-------|---------|
| π₁ | τ_civ/τ_memory | 1.0 | Civilizational coupling |
| π₂ | v × τ_civ / R_settle | 50.0 | Migration Peclet |
| π₃ | D × τ_lang / R_settle² | 0.74 | Cultural Fourier |
| π₄ | τ_myth/τ_lang | 2.157 | Myth-lang ratio |
| π₅ | τ_branch/τ_stability | 2.157 | Branch-stability |

### 10b. Prediction Accuracy

| Prediction | Phi Accuracy | Standard | Improvement |
|-----------|-------------|----------|-------------|
| Civilizational timing | ±15% | ±30% | +50% |
| Migration patterns | ±20% | ±35% | +43% |
| Language drift | ±10% | ±25% | +60% |
| Archetype recurrence | ±25% | ±40% | +37.5% |
| Settlement patterns | ±18% | ±32% | +43.75% |

---

*End of PHI-ANTHROPOLOGY Tables*
