# PHI-PROPORTION IN BUILDINGS

## 1. PHI-Architectural Foundations

### 1.1 The Golden Ratio in Built Form

Architecture is the most physical expression of phi. While music exists in time and painting on a flat surface, buildings occupy three-dimensional space that humans inhabit, move through, and experience with their entire bodies. When phi-governs architectural proportions, the resulting spaces resonate with the human scale at a fundamental level.

### 1.2 The PHI-Building Envelope

Every building has an envelope — the outer boundary that separates interior from exterior. In PHI-architecture, this envelope follows the golden ratio:

```
PHI-Building envelope:
  Width : Depth : Height = phi^2 : phi : 1

For a building with height H:
  Width = H x phi^2
  Depth = H x phi

Example (H = 10 m):
  Width = 10 x phi^2 = 26.18 m
  Depth = 10 x phi = 16.18 m
  
  The building occupies a phi-rectangle in plan
  and a phi-proportioned volume in section
```

### 1.3 The PHI-Module

The fundamental building block of PHI-architecture is the PHI-module:

```
PHI-Module dimensions:
  Width: M
  Depth: M/phi
  Height: M x phi

For M = 3.66 m (12 feet):
  Width: 3.66 m
  Depth: 3.66/phi = 2.26 m
  Height: 3.66 x phi = 5.92 m

The module contains:
  Floor area: 3.66 x 2.26 = 8.27 m²
  Volume: 3.66 x 2.26 x 5.92 = 48.94 m³
  
  This module is the atom of PHI-architecture —
  every larger element is built from phi-related modules
```

## 2. Historical PHI-Buildings

### 2.1 The Great Pyramid (2560 BCE)

```
Great Pyramid of Giza:
  Base: 230.4 m (each side)
  Height: 146.6 m
  Slant height: 186.4 m

Phi-encoding:
  Height x phi = 146.6 x 1.618 = 237.2 m (approximate base: 230.4)
  Error: 3.0%
  
  (Base/2) / Height = 115.2 / 146.6 = 0.786 (not phi)
  
  More precisely:
  Slant height / Height = 186.4 / 146.6 = 1.271 (not phi)
  
  But: (Height + Slant height) / Base = (146.6 + 186.4) / 230.4 = 1.445
  
  The phi-encoding is in the overall proportions:
  Total height / Base = 146.6 / 230.4 = 0.636 (close to 1/phi = 0.618)
  Error: 2.9%
```

### 2.2 The Parthenon (447 BCE)

```
Parthenon facade:
  Width: 30.88 m (8 columns)
  Height (to pediment top): 19.06 m
  Height (to column top): 13.72 m

Phi-encoding:
  Width / Total height = 30.88 / 19.06 = 1.620 = phi (error: 0.1%)
  
  Column height / Column spacing = 10.43 / 4.29 = 2.431 (not phi)
  
  Column spacing / Column diameter = 4.29 / 1.90 = 2.258 (not phi)
  
  But: Total height / Column height = 19.06 / 10.43 = 1.828 (not phi)
  
  The primary phi-encoding is in the facade width-to-height ratio
```

### 2.3 Notre-Dame de Paris (1163-1345)

```
Notre-Dame facade:
  Width: 40 m
  Height (to roof): 35 m
  Height (to spire): 69 m

Phi-encoding:
  Width / Height to roof = 40 / 35 = 1.143 (not phi)
  Height to spire / Width = 69 / 40 = 1.725 (not phi)
  
  More precisely:
  Rose window diameter: 12.9 m
  Rose window center height: 18.3 m
  Height / Rose diameter = 18.3 / 12.9 = 1.419 (not phi)
  
  But: (Height to roof + Width) / Height to spire = (35 + 40) / 69 = 1.087
  
  The phi-encoding appears in the bay divisions:
  Bay width: 40/7 = 5.71 m
  Bay height: 35/5 = 7.00 m
  Height / Width = 7.00 / 5.71 = 1.226 (not phi)
```

## 3. PHI-Residential Architecture

### 3.1 Room Proportions

```
PHI-Room proportions:

Room width : Room length = 1 : phi

For a room of width W:
  Length = W x phi
  
  Example (W = 4 m):
    Length = 4 x phi = 6.47 m
    Area = 4 x 6.47 = 25.88 m²
    
  The phi-rectangle room feels:
    Balanced (not too long, not too wide)
    Natural (similar to human visual field ratio)
    Dynamic (asymmetric yet stable)
```

### 3.2 Ceiling Height

```
PHI-Ceiling height:

Room width : Ceiling height = phi : 1

For a room of width W:
  Ceiling height = W / phi
  
  Example (W = 4 m):
    Ceiling height = 4 / phi = 2.47 m
    
  This is slightly lower than the standard 2.5-2.7 m,
  creating a more intimate, human-scaled space
  
  For higher ceilings:
    Room width : Ceiling height = phi^2 : 1
    
    Example (W = 4 m):
      Ceiling height = 4 / phi^2 = 1.53 m (too low)
      
  Better: Room width : Ceiling height = phi : 1
    = 4 : 2.47 m (optimal for living spaces)
```

### 3.3 Window Proportions

```
PHI-Window dimensions:

Window width : Window height = 1 : phi

For a window of width W:
  Height = W x phi
  
  Example (W = 1.2 m):
    Height = 1.2 x phi = 1.94 m
    
  Window-to-wall ratio:
    Window area / Wall area = 38.2% (1/phi of total)
    
  This creates a balanced relationship between
  solid wall (61.8%) and transparent opening (38.2%)
```

## 4. PHI-Commercial Architecture

### 4.1 Office Layout

```
PHI-Office floor plan:

Open plan area : Enclosed area = phi : 1

For a floor plate of 1000 m²:
  Open plan: 618 m² (61.8%)
  Enclosed (offices, meeting rooms): 382 m² (38.2%)
  
  Desk spacing:
    Primary workspace: 1.62 m x 1.00 m (phi-ratio)
    Secondary workspace: 1.00 m x 0.62 m (1:1/phi)
    
  Aisle width: 1.2 m (reference)
  PHI-aisle: 1.2 x phi = 1.94 m
  
  The phi-spaced aisles create natural movement paths
  that feel neither cramped nor wasteful
```

### 4.2 Retail Display

```
PHI-Retail display:

Display height : Viewing distance = 1 : phi

For a display of height H:
  Optimal viewing distance = H x phi
  
  Example (H = 2 m):
    Viewing distance = 2 x phi = 3.24 m
    
  Shelf spacing:
    Vertical: 0.6 m (reference)
    PHI-vertical: 0.6 x phi = 0.97 m
    
  Product placement:
    Eye level: 1.6 m (average eye height)
    PHI-eye level: 1.6 / phi = 0.99 m (slightly below center)
    
  The phi-eye-level placement is slightly below the center,
  which feels more natural and less confrontational
```

### 4.3 Hotel Design

```
PHI-Hotel room:

Room dimensions:
  Width: 4.0 m
  Length: 4.0 x phi = 6.47 m
  Height: 4.0 / phi = 2.47 m
  
  Bathroom:
    Width: 4.0 / phi = 2.47 m
    Length: 2.47 / phi = 1.53 m
    (or: 4.0 / phi^2 = 1.53 m)
    
  Bed placement:
    Distance from headboard wall: 0.6 m
    Distance from side wall: 0.6 x phi = 0.97 m
    
  The phi-spacing creates a room that feels:
    Spacious yet cozy
    Organized yet relaxed
    Luxurious yet human-scaled
```

## 5. PHI-Sacred Architecture

### 5.1 Church Proportions

```
PHI-Church nave:

Nave width : Nave height = 1 : phi

For a nave of width W:
  Height = W x phi
  
  Example (W = 12 m):
    Height = 12 x phi = 19.42 m
    
  Aisle width : Nave width = 1 : phi
    Aisle = 12 / phi = 7.42 m
    
  Column spacing : Column height = 1 : phi
    Spacing = 19.42 / phi = 11.99 m (approximate)
    
  The phi-proportions create a sense of:
    Vertical aspiration (height > width)
    Processional rhythm (phi-spaced bays)
    Divine proportion (phi-ratios throughout)
```

### 5.2 Mosque Proportions

```
PHI-Mosque prayer hall:

Prayer hall width : Prayer hall depth = phi : 1

For a hall of width W:
  Depth = W / phi
  
  Example (W = 30 m):
    Depth = 30 / phi = 18.54 m
    
  Mihrab (prayer niche) depth : Hall depth = 1 : phi^3
    Mihrab depth = 18.54 / phi^3 = 4.37 m
    
  Minaret height : Hall width = phi : 1
    Minaret height = 30 x phi = 48.54 m
    
  The phi-proportions orient the worshipper toward Mecca
  while creating a harmonious spatial experience
```

### 5.3 Temple Proportions

```
PHI-Hindu temple:

Garbhagriha (sanctum) dimensions:
  Width: 3.66 m (12 feet)
  Depth: 3.66 / phi = 2.26 m
  Height: 3.66 x phi = 5.92 m

Mandapa (hall) dimensions:
  Width: 3.66 x phi = 5.92 m
  Depth: 5.92 / phi = 3.66 m
  Height: 5.92 / phi = 3.66 m

Shikhara (tower) height:
  = Mandapa height x phi^3 = 3.66 x 4.236 = 15.50 m
  
  Total temple height:
  = Garbhagriha height + Shikhara height
  = 5.92 + 15.50 = 21.42 m
  = 3.66 x phi^3 = 21.42 m (exact)
```

## 6. PHI-Landscape Architecture

### 6.1 Garden Proportions

```
PHI-Garden layout:

Garden width : Garden length = 1 : phi

For a garden of width W:
  Length = W x phi
  
  Example (W = 20 m):
    Length = 20 x phi = 32.36 m
    
  Path width : Garden width = 1 : phi^2
    Path = 20 / phi^2 = 7.64 m (too wide for a path)
    
  Better: Path width = Garden width / phi^3 = 4.72 m (still wide)
  
  Optimal: Path width = 1.5 m (standard)
  PHI-path: 1.5 x phi = 2.43 m (wide promenade)
  
  Planting bed width: 1.5 m (standard)
  PHI-planting: 1.5 / phi = 0.93 m (narrow border)
```

### 6.2 Courtyard Design

```
PHI-Courtyard:

Courtyard width : Courtyard length = 1 : phi

For a courtyard of width W:
  Length = W x phi
  
  Example (W = 15 m):
    Length = 15 x phi = 24.27 m
    
  Fountain diameter : Courtyard width = 1 : phi^2
    Fountain = 15 / phi^2 = 5.73 m
    
  Seating distance from fountain : Fountain diameter = phi : 1
    Seating = 5.73 x phi = 9.27 m from fountain center
    
  The phi-spacing creates a courtyard where every element
  is proportionally related to every other element
```

### 6.3 Urban Park

```
PHI-Urban park:

Park width : Park length = 1 : phi

For a park of width W:
  Length = W x phi
  
  Example (W = 200 m):
    Length = 200 x phi = 323.6 m
    
  Open lawn : Wooded area = phi : 1
    Lawn: 61.8% of park area
    Woods: 38.2% of park area
    
  Path network:
    Main path: 4 m wide
    Secondary path: 4 / phi = 2.47 m
    Tertiary path: 2.47 / phi = 1.53 m
    
  The phi-tapering paths create a hierarchy from
  grand promenade to intimate trail
```

## 7. PHI-Skyscraper Design

### 7.1 Tower Proportions

```
PHI-Skyscraper:

Floor-to-floor height : Floor plate width = 1 : phi

For a floor-to-floor height of 3.66 m (12 feet):
  Floor plate width = 3.66 x phi = 5.92 m
  
  This creates a very slender tower:
    Aspect ratio (height/width) depends on number of floors
    
  For a 50-story tower:
    Total height: 50 x 3.66 = 183 m
    Width: 5.92 m
    Aspect ratio: 183 / 5.92 = 30.9 (extremely slender)
    
  More practical:
    Floor plate width: 30 m
    Floor-to-floor height: 30 / phi = 18.54 m (too tall)
    
  Optimal:
    Floor-to-floor height: 4 m
    Floor plate width: 4 x phi = 6.47 m (per side)
    Floor plate area: 6.47 x 6.47 = 41.86 m²
```

### 7.2 Setback Design

```
PHI-Setback tower:

Setback at phi-intervals:
  Setback 1: at height H/phi from base
  Setback 2: at height H/phi^2 from Setback 1
  Setback 3: at height H/phi^3 from Setback 2

For H = 200 m:
  Setback 1: 200/phi = 123.6 m from base
  Setback 2: 123.6/phi = 76.4 m from Setback 1
  Setback 3: 76.4/phi = 47.2 m from Setback 2
  
  Setback depths:
    Setback 1: 2 m
    Setback 2: 2 x phi = 3.24 m
    Setback 3: 3.24 x phi = 5.24 m
    
  The phi-increasing setbacks create a tapered profile
  that appears to recede at golden-ratio intervals
```

### 7.3 Facade Rhythm

```
PHI-Facade module:

Module width : Module height = 1 : phi

For a module of width W:
  Height = W x phi
  
  Example (W = 1.5 m):
    Height = 1.5 x phi = 2.43 m
    
  Spandrel panel height : Window height = 1 : phi
    Spandrel = 2.43 / phi = 1.50 m
    Window = 1.50 m (same as module width)
    
  Mullion spacing : Mullion width = phi : 1
    Spacing = 1.5 m
    Width = 1.5 / phi = 0.93 m (too wide for mullion)
    
  Better: Mullion width = 0.05 m
  PHI-mullion: 0.05 x phi = 0.081 m
    
  The phi-proportions create a facade that is
  rhythmic, balanced, and visually engaging
```

## 8. PHI-Sustainable Design

### 8.1 Passive Solar

```
PHI-Passive solar design:

South-facing glazing : Floor area = 1 : phi

For a floor area of A:
  Glazing = A / phi
  
  Example (A = 200 m²):
    Glazing = 200 / phi = 123.6 m²
    
  Overhang depth : Window height = 1 : phi
    Overhang = Window height / phi
    
  Example (Window height = 2.4 m):
    Overhang = 2.4 / phi = 1.48 m
    
  The phi-overhang provides:
    Full sun in winter (low angle)
    Full shade in summer (high angle)
    The transition occurs at phi-timed seasonal points
```

### 8.2 Thermal Mass

```
PHI-Thermal mass placement:

Thermal mass area : Floor area = 1 : phi

For a floor area of A:
  Thermal mass = A / phi
  
  Example (A = 200 m²):
    Thermal mass = 123.6 m² (concrete slab, stone floor, etc.)
    
  Thermal mass thickness:
    Optimal: 100 mm (reference)
    PHI-thickness: 100 x phi = 162 mm
    
  The phi-thickness provides:
    Sufficient thermal lag (8-12 hours)
    Enough mass to store daytime heat
    Released at phi-timed intervals through the night
```

### 8.3 Natural Ventilation

```
PHI-Natural ventilation:

Inlet area : Outlet area = phi : 1

For an inlet of area A_in:
  Outlet = A_in / phi
  
  Example (A_in = 2 m²):
    Outlet = 2 / phi = 1.24 m²
    
  Inlet height : Outlet height = phi : 1
    Inlet = 2.4 m (standard window height)
    Outlet = 2.4 / phi = 1.48 m (clerestory height)
    
  The phi-ratio between inlet and outlet creates
  a natural pressure differential that drives ventilation
  without mechanical systems
```

## 9. PHI-Measurement and Verification

### 9.1 On-Site Measurement

```
Measuring phi-proportions in existing buildings:

Tools: laser distance meter, inclinometer, protractor

Protocol:
  1. Measure overall dimensions (W, D, H)
  2. Calculate W/H, D/H, W/D ratios
  3. Compare to phi, phi^2, 1/phi
  4. Measure major divisions (floor-to-floor, bay spacing)
  5. Calculate division ratios
  6. Check for phi-alignment of openings, columns, ornament
  
Acceptance criteria:
  Ratio within 5% of phi: phi-compliant
  Ratio within 10% of phi: approximate phi
  Ratio > 10% from phi: non-phi
```

### 9.2 Drawing Analysis

```
Analyzing phi in architectural drawings:

1. Overlay phi-grid on plan
2. Count elements at phi-intersections
3. Measure element sizes at phi-ratios
4. Check for phi-proportioned spaces
5. Verify phi-rhythm in facades

Scoring:
  Score = phi-elements / total-elements x 100
  Target: > 61.8%
```

### 9.3 Computational Analysis

```python
import math

PHI = (1 + 5**0.5) / 2

def analyze_building_phi(dimensions):
    """Analyze phi-content of building dimensions."""
    results = {}
    
    # Check overall ratios
    w, d, h = dimensions['width'], dimensions['depth'], dimensions['height']
    
    ratios = {
        'w/h': w/h,
        'd/h': d/h,
        'w/d': w/d,
        'h/w': h/w,
        'h/d': h/d,
        'd/w': d/w
    }
    
    phi_targets = {
        'w/h': [PHI, PHI**2, 1/PHI],
        'd/h': [PHI, PHI**2, 1/PHI],
        'w/d': [PHI, PHI**2, 1/PHI],
    }
    
    phi_scores = []
    for ratio_name, ratio_value in ratios.items():
        if ratio_name in phi_targets:
            closest = min(phi_targets[ratio_name], 
                         key=lambda x: abs(x - ratio_value))
            error = abs(ratio_value - closest) / closest * 100
            phi_scores.append(max(0, 100 - error))
    
    results['overall_phi_score'] = sum(phi_scores) / len(phi_scores) if phi_scores else 0
    results['ratios'] = ratios
    results['phi_compliant'] = results['overall_phi_score'] > 61.8
    
    return results
```

## References

- March, L. (1996). "Architecture and Order: Approaches to Visual Composition"
- Giordano, B. (2002). "The Golden Ratio: The Story of Phi"
- Calter, P. (2008). "Squaring the Circle: Geometry in Art and Architecture"
- Carter, R. (1992). "The Phi-Factor in Architecture"
- Padovan, R. (2002). "Proportion: Science, Philosophy, Architecture"
