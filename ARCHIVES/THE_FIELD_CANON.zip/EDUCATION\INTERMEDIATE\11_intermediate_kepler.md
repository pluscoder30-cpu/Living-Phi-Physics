# 11 — The Kepler Ratio | Intermediate Level

## Ages 13–16 | The Golden Ratio in Astronomy

---

## 1. Definition

The Kepler ratio refers to connections between the golden ratio and planetary
orbits. Kepler discovered that the "harmony of the world" involves mathematical
ratios related to phi.

The most famous connection:

```
The ratio of consecutive planetary orbital periods
approximates powers of the golden ratio for certain planet pairs.
```

---

## 2. Kepler's Mysterium Cosmographicum

In 1596, Kepler proposed that planetary orbits are nested inside Platonic solids.
The dodecahedron and icosahedron both have the golden ratio in their geometry.

```
Dodecahedron: 12 pentagonal faces, each with golden ratio proportions
Icosahedron: 20 triangular faces, vertices related by golden ratio
```

---

## 3. Golden Ratio in Platonic Solids

**Dodecahedron:**

```
Edge length: a
Distance between opposite faces: a * sqrt(25 + 11*sqrt(5)) / 2
Diagonal of pentagonal face: a * phi

The ratio of diagonal to edge in each pentagonal face is exactly phi.
```

**Icosahedron:**

```
Edge length: a
Circumradius: a * phi^2 / 2
Inradius: a * phi^2 / (2*sqrt(3))

The ratio of circumradius to inradius involves phi^2.
```

---

## 4. Planetary Spacing and the Titius-Bode Law

The Titius-Bode law predicts planetary distances:

```
d = 0.4 + 0.3 * 2^n  (in AU)

Mercury (n=-inf): 0.4 AU (actual: 0.39)
Venus (n=0): 0.7 AU (actual: 0.72)
Earth (n=1): 1.0 AU (actual: 1.00)
Mars (n=2): 1.6 AU (actual: 1.52)
Jupiter (n=3): 2.8 AU (actual: 5.20) -- breaks down
Saturn (n=4): 5.2 AU (actual: 9.54)
```

While not directly involving phi, the geometric progression resembles
the exponential growth seen in golden ratio systems.

---

## 5. Kepler's Second Law and Areas

Kepler's second law states that a planet sweeps equal areas in equal times:

```
dA/dt = constant

For an ellipse with semi-major axis a and eccentricity e:
Area swept per unit time = (pi * a * b) / T

where b = a * sqrt(1 - e^2) and T is the orbital period.
```

The golden ratio appears in certain orbital resonances where the period
ratios approach phi-related values.

---

## 6. Orbital Resonances

Some planetary pairs have orbital period ratios close to simple fractions
related to phi:

```
Earth/Venus: 8/13 = 0.615... ~ 1/phi = 0.618...
Jupiter/Saturn: 2/5 = 0.400 (not directly phi-related)

The Earth-Venus resonance is notable:
8 Earth orbits = 13 Venus orbits (approximately)
8/13 approximates 1/phi
```

---

## 7. The Golden Angle and Orbits

If we map planetary positions to a circle, the golden angle (137.508 degrees)
provides optimal spacing:

```
Mercury: 0 deg
Venus: 137.5 deg
Earth: 275.0 deg
Mars: 52.5 deg (mod 360)
...

This is the same phyllotaxis angle used in plant growth!
```

---

## 8. Worked Problems

### Problem 1: Dodecahedron diagonal

**Question:** A dodecahedron has edge length 5 cm. What is the diagonal of
one pentagonal face?

**Solution:**

```
Diagonal = phi * edge = phi * 5
        = 5 * 1.618034
        = 8.090 cm
```

---

### Problem 2: Icosahedron circumradius

**Question:** An icosahedron has edge length 3 cm. Find its circumradius.

**Solution:**

```
Circumradius = a * phi^2 / 2
            = 3 * (2.618034) / 2
            = 3 * 1.309017
            = 3.927 cm
```

---

### Problem 3: Earth-Venus resonance

**Question:** If Earth's orbital period is 365.25 days, estimate Venus's
period using the 8:13 resonance.

**Solution:**

```
8 * T_Earth = 13 * T_Venus
T_Venus = 8 * T_Earth / 13
        = 8 * 365.25 / 13
        = 2922 / 13
        = 224.8 days

Actual: 224.7 days  (very close!)
```

---

### Problem 4: Golden angle computation

**Question:** A planet orbits at the golden angle relative to another. If the
first is at 45 degrees, where is the second?

**Solution:**

```
Golden angle = 137.508 degrees

Second planet position = 45 + 137.508 = 182.508 degrees
```

---

### Problem 5: Platonic solid faces

**Question:** How many total faces do all Platonic solids have?

**Solution:**

```
Tetrahedron: 4 faces
Cube: 6 faces
Octahedron: 8 faces
Dodecahedron: 12 faces
Icosahedron: 20 faces

Total: 4 + 6 + 8 + 12 + 20 = 50 faces
```

---

### Problem 6: Kepler's third law

**Question:** If Planet A has orbital period 2 years and semi-major axis 1.5 AU,
what is the semi-major axis of Planet B with period 8 years?

**Solution:**

```
Kepler's third law: T^2 proportional to a^3

T_A^2 / a_A^3 = T_B^2 / a_B^3
a_B^3 = a_A^3 * T_B^2 / T_A^2
a_B^3 = (1.5)^3 * (8)^2 / (2)^2
a_B^3 = 3.375 * 64 / 4
a_B^3 = 54
a_B = 54^(1/3) = 3.78 AU
```

---

### Problem 7: Dihedral angle of dodecahedron

**Question:** The dihedral angle of a regular dodecahedron is approximately
116.565 degrees. Show that this involves the golden ratio.

**Solution:**

```
cos(dihedral) = -1/sqrt(5)
             = -0.4472

dihedral = arccos(-0.4472)
         = 116.565 degrees

Note: 1/sqrt(5) = 1/(phi*sqrt(5)/phi) = 1/(phi + 1/phi)
This involves phi through the identity phi^2 = phi + 1.
```

---

### Problem 8: Edge ratio in icosahedron

**Question:** In an icosahedron, the ratio of the circumradius to the edge
length involves phi. Compute this ratio.

**Solution:**

```
Circumradius R = a * phi^2 / 2

R/a = phi^2 / 2
    = (phi + 1) / 2     [using phi^2 = phi + 1]
    = (1.618034 + 1) / 2
    = 2.618034 / 2
    = 1.309017
```

---

### Problem 9: Planetary distance ratios

**Question:** The ratio of Saturn's orbital radius (9.54 AU) to Jupiter's
(5.20 AU) is approximately 1.835. How does this compare to phi^2 = 2.618?

**Solution:**

```
Saturn/Jupiter = 9.54/5.20 = 1.835

phi^2 = 2.618
phi = 1.618
sqrt(phi) = 1.272

1.835 is between phi and phi^2.
It is closest to phi^1.5 = phi * sqrt(phi) = 2.058.
```

---

### Problem 10: Golden rectangle in orbit

**Question:** If a planet's orbit can be approximated by a golden rectangle
(width 2 AU, length 2*phi AU), what is the area?

**Solution:**

```
Width = 2 AU
Length = 2 * phi = 3.236 AU

Area = 2 * 3.236 = 6.472 square AU
```

---

### Problem 11: Vertex coordinates

**Question:** The 12 vertices of an icosahedron with circumradius 1 can be
placed at (0, +/-1, +/-phi) and cyclic permutations. Verify the distance
from origin is 1.

**Solution:**

```
Vertex: (0, 1, phi)
Distance = sqrt(0^2 + 1^2 + phi^2)
        = sqrt(1 + 2.618)
        = sqrt(3.618)
        = 1.902

Hmm, that's not 1. The correct normalization uses vertices at:
(0, +/-1/phi, +/-1) etc.

Distance = sqrt(0 + 1/phi^2 + 1)
        = sqrt(1/1.618^2 + 1)
        = sqrt(0.382 + 1)
        = sqrt(1.382)
        = 1.176

Still not 1. The actual icosahedron vertices are at:
(0, +/-1, +/-phi) / sqrt(1+phi^2)
= (0, +/-1, +/-phi) / sqrt(1+2.618)
= (0, +/-1, +/-phi) / 1.902
```

---

### Problem 12: Kepler's harmony

**Question:** Kepler believed the 5 Platonic solids corresponded to the 5
planetary intervals between Mercury and Saturn. How many intervals are there?

**Solution:**

```
Planets: Mercury, Venus, Earth, Mars, Jupiter, Saturn (6 planets)
Intervals between them: 5

Kepler proposed each interval was "filled" by a Platonic solid:
Mercury-Venus: tetrahedron
Venus-Earth: cube
Earth-Mars: octahedron
Mars-Jupiter: dodecahedron (uses phi)
Jupiter-Saturn: icosahedron (uses phi)
```

---

### Problem 13: Eccentricity and phi

**Question:** Some comets have orbital eccentricities close to 1/phi. If a
comet has eccentricity 0.618, what is the ratio of perihelion to aphelion?

**Solution:**

```
Perihelion distance: q = a(1-e)
Aphelion distance: Q = a(1+e)

q/Q = (1-e)/(1+e)
    = (1-0.618)/(1+0.618)
    = 0.382/1.618
    = 1/phi^2
    = 0.236

So q/Q = 1/phi^2 = (3-sqrt(5))/2
```

---

### Problem 14: Golden ratio in moon phases

**Question:** The synodic period of the Moon is 29.53 days. The ratio of this
to the human gestation period (266 days) is approximately 9. What is the
ratio 266/29.53?

**Solution:**

```
266 / 29.53 = 9.007

Not directly related to phi. But note:
phi^4 = 6.854
phi^5 = 11.090

The ratio 9 is between phi^4 and phi^5.
```

---

### Problem 15: Constructing a Kepler solid

**Question:** If you inscribe a cube inside a dodecahedron, what is the ratio
of the cube's edge to the dodecahedron's edge?

**Solution:**

```
For a dodecahedron with edge a:
The inscribed cube has edge length = a * phi^2 / sqrt(2)
= a * 2.618 / 1.414
= a * 1.851

Ratio = 1.851
phi^2 / sqrt(2) = 1.851
```

---

## 9. Summary Table

| Property | Value |
|----------|-------|
| Golden angle | 137.508 degrees |
| Dodecahedron diagonal/edge | phi |
| Icosahedron R/a | phi^2 / 2 |
| Earth/Venus resonance | 8/13 ~ 1/phi |
| Platonic solids | 5 total, 50 faces |
| Kepler's third law | T^2 = k * a^3 |

---

## 10. Key Takeaways for Ages 13-16

1. **Kepler discovered** the golden ratio in planetary geometry.
2. **Platonic solids** have golden ratio proportions in dodecahedra and icosahedra.
3. **Planetary resonances** like Earth-Venus approximate phi-related ratios.
4. **Kepler's laws** describe orbital mechanics using mathematical ratios.
5. **The golden angle** provides optimal spacing in orbital systems.
6. **Geometry connects** the abstract golden ratio to physical orbits.

---

*Next: 12_intermediate_worksheet.md — Practice Problems*
