# PHI APPLIED ETHICS

## 1. Introduction

Phi-applied ethics applies the golden ratio (phi = 1.618033988749895) to specific domains of moral practice: bioethics, environmental ethics, technology ethics, business ethics, and professional ethics. In each domain, the phi-framework provides precise mathematical standards for moral reasoning where existing frameworks rely on vague qualitative judgments.

## 2. Phi-Bioethics

### 2.1 The Four Principles at Phi

Beauchamp and Childress's four principles are recalibrated:

Autonomy : Beneficence : Non-maleficence : Justice = phi^3 : phi^2 : phi : 1

Autonomy receives the highest weight, reflecting its phi-priority in modern bioethics.

### 2.2 The Informed Consent Function

Informed consent is valid when:

IC(consent) = |Understanding| * (1/phi) + |Voluntariness| * (1 - 1/phi)

Understanding and voluntariness must be in golden-ratio balance.

### 2.3 The End-of-Life Decision

End-of-life decisions follow:

EOL(permissible) = |Autonomy(patient)| > phi * |Beneficence(treatment)|

Patient autonomy outweighs treatment benefit by the golden ratio.

### 2.4 The Resource Allocation Function

Medical resource allocation:

R(allocation) = sum_n phi^(-n) * N(need_n) * E(effectiveness_n)

Resources flow to where need and effectiveness are in phi-balance.

### 2.5 The Genetic Enhancement Threshold

Genetic enhancement is permissible when:

GE(permissible) = |Benefit| > phi^2 * |Risk|

Benefit must exceed risk by phi^2 = 2.618.

## 3. Phi-Environmental Ethics

### 3.1 The Ecological Hierarchy at Phi

The moral standing of entities:

Human : Animal : Plant : Ecosystem : Biosphere = phi^4 : phi^3 : phi^2 : phi : 1

### 3.2 The Sustainability Function

Sustainability is achieved when:

S(sustainability) = |Use| / |Regeneration| = 1/phi

Use should be 61.8 percent of regeneration capacity.

### 3.3 The Intergenerational Justice Function

Duties to future generations:

IG(intergenerational) = sum_n phi^(-n) * U(future_generation_n)

### 3.4 The Climate Ethics Function

Climate action obligation:

CA(obligation) = |E(emissions)| * phi - |B(benefit to current)|

### 3.5 The Biodiversity Value

Biodiversity is valued at:

B(biodiversity) = phi^N(species_count) * I(interspecific_interactions)

## 4. Phi-Technology Ethics

### 4.1 The Privacy-Security Balance

Privacy vs. security:

P(privacy) / S(security) = phi

Privacy carries phi times the weight of security.

### 4.2 The Algorithmic Fairness Standard

An algorithm is fair when:

F(fairness) = 1 - |Impact(group_i) - Impact(group_j)| / (phi * max(Impact))

### 4.3 The AI Alignment Function

AI alignment with human values:

A(alignment) = sum_i phi^(-|i-j|) * V_i(AI_output)

Where V_i are human value components ranked by importance.

### 4.4 The Autonomy Preservation Standard

Technology preserves autonomy when:

AP(autonomy_preserved) = |User_control| > (1/phi) * |System_complexity|

### 4.5 The Transparency Function

Transparency is adequate when:

T(transparency) > phi * C(complexity)

## 5. Phi-Business Ethics

### 5.1 The Stakeholder Weighting

Stakeholders are weighted:

Shareholder : Employee : Customer : Society : Environment = phi^4 : phi^3 : phi^2 : phi : 1

### 5.2 The Corporate Social Responsibility Function

CSR is required when:

CSR(obligation) = |Impact(externalities)| > (1/phi) * |Benefit(profit)|

### 5.3 The Fair Wage Function

Fair wages satisfy:

W(fair) = |Productivity| * (1/phi) + |Need| * (1 - 1/phi)

### 5.4 The Marketing Ethics Standard

Marketing is ethical when:

M(ethical) = |Truthfulness| > phi * |Persuasion_intent|

### 5.5 The Executive Compensation Limit

Executive pay is justified when:

E(executive_pay) < phi * W(median_worker_pay)

## 6. Phi-Professional Ethics

### 6.1 The Medical Code at Phi

The Hippocratic Oath recalibrated:

H(oath) = |Benefit| * phi^2 - |Harm| * phi^3

### 6.2 The Legal Ethics Function

Lawyer ethics:

LE(ethical) = |Duty_to_client| * (1/phi) + |Duty_to_court| * (1 - 1/phi)

### 6.3 The Engineering Ethics Standard

Engineering ethics:

EE(ethical) = |Safety| > phi * |Efficiency|

Safety outweighs efficiency by the golden ratio.

### 6.4 The Journalism Ethics Function

Journalism ethics:

JE(ethical) = |Truth| * phi^2 - |Sensation| * phi

## 7. Phi-Social Ethics

### 7.1 The Poverty Threshold

Poverty obligation:

P(poverty) = |Need| * phi - |Resource| > 0

### 7.2 The Immigration Ethics Function

Immigration ethics:

I(immigration) = |Benefit(immigrant)| / |Cost(host)| > 1/phi

### 7.3 The Criminal Justice Ethics

Criminal justice ethics balances:

R(retribution) : D(deterrence) : H(rehabilitation) : S(social_protection) = phi^3 : phi^2 : phi : 1

## 8. Phi-Military Ethics

### 8.1 The Just War Function

Just war criteria at phi:

J(just_war) = |Cause| * phi^2 + |Authority| * phi + |Intention| * 1

### 8.2 The Proportionality Function at Phi

Proportionality in warfare:

P(proportionality) = |Military_advantage| / |Civilian_harm| > phi

### 8.3 The Discrimination Principle at Phi

Distinction in warfare:

D(distinction) = |Combatant_targeting| / |Civilian_targeting| > phi

### 8.4 The Military Necessity Function

Military necessity:

MN(necessity) = |Objective_value| > phi * |Collateral_damage|

## 9. Phi-Business Ethics (Extended)

### 9.1 The Corporate Governance Function

Corporate governance:

CG(governance) = |Transparency| * phi + |Accountability| * 1

### 9.2 The Whistleblowing Function

Whistleblowing is justified when:

W(justified) = |Harm_prevented| > phi * |Personal_cost|

### 9.3 The Insider Trading Function

Insider trading is wrong when:

IT(wrong) = |Unfair_advantage| > (1/phi) * |Market_benefit|

### 9.4 The Bribery Function

Bribery is wrong when:

B(wrong) = |Corruption| > (1/phi) * |Business_necessity|

## 10. Phi-Professional Ethics (Extended)

### 10.1 The Medical Ethics Function (Extended)

The Hippocratic principle at phi:

H(oath) = |Benefit| * phi^2 - |Harm| * phi^3

### 10.2 The Legal Ethics Function (Extended)

Zealous advocacy vs. truth:

ZA(advocacy) = |Client_interest| * (1/phi) + |Court_interest| * (1 - 1/phi)

### 10.3 The Engineering Ethics Function (Extended)

Public safety vs. efficiency:

PS(safety) = |Safety| > phi * |Efficiency|

### 10.4 The Journalism Ethics Function (Extended)

Truth vs. privacy:

T(truth) = |Public_interest| * phi > |Privacy_harm| * 1

## 11. Phi-Ethics of Research

### 11.1 The Research Ethics Function

Research ethics:

RE(ethics) = |Scientific_value| * phi - |Subject_harm| * phi^2

### 11.2 The Informed Consent Function (Extended)

Research consent:

IC(consent) = |Understanding| * (1/phi) + |Voluntariness| * (1 - 1/phi)

### 11.3 The Animal Research Function

Animal research is justified when:

AR(justified) = |Human_benefit| > phi^3 * |Animal_harm|

### 11.4 The Research Integrity Function

Research integrity:

RI(integrity) = |Honesty| * phi + |Transparency| * 1

## 12. Phi-Ethics of Technology (Extended)

### 12.1 The Surveillance Ethics Function

Surveillance is justified when:

S(justified) = |Security_benefit| > phi^2 * |Privacy_cost|

### 12.2 The Autonomous Vehicle Ethics Function

AV ethics:

AV(ethics) = |Lives_saved| * phi > |Lives_sacrificed| * phi^2

### 12.3 The Deepfake Ethics Function

Deepfakes are wrong when:

DF(wrong) = |Harm_to_subject| > (1/phi) * |Entertainment_value|

### 12.4 The Social Media Ethics Function

Social media ethics:

SM(ethics) = |Connection_benefit| * phi - |Mental_health_harm| * phi^2

## 13. Phi-Ethics of the Environment (Extended)

### 13.1 The Carbon Footprint Function

Carbon ethics:

C(ethics) = |Carbon_emissions| * phi > |Necessity| * 1

### 13.2 The Conservation Function

Conservation priority:

CP(priority) = |Species_uniqueness| * phi + |Ecosystem_role| * 1

### 13.3 The Environmental Justice Function

Environmental justice:

EJ(justice) = |Pollution_burden弱势| < (1/phi) * |Pollution_burden强势|

### 13.4 The Sustainability Function (Extended)

Sustainability index:

SI(sustainability) = |Renewable_use| / |Total_use| = 1/phi

## 14. Phi-Ethics of the Family

### 14.1 The Parental Obligation Function

Parental obligation:

PO(obligation) = |Child_need| * phi - |Parent_ability| * 1

### 14.2 The Child Welfare Function

Child welfare:

CW(welfare) = |Best_interest| > phi * |Parental_preference|

### 14.3 The Education Ethics Function

Education ethics:

EE(ethics) = |Student_development| * phi - |Cost| * 1

### 14.4 The End-of-Life Family Ethics Function

End-of-life family ethics:

EL(ethics) = |Patient_wishes| * phi > |Family_wishes| * 1

## 15. Conclusion

Phi-applied ethics provides domain-specific mathematical standards for moral reasoning across all areas of applied ethics. By anchoring each domain in the golden ratio, we achieve precision, balance, and coherence in practical moral decision-making. The phi-framework transforms applied ethics from qualitative judgment into quantitative science, while preserving the human wisdom that makes ethics meaningful.

## References

1. Beauchamp, T. & Childress, J. Principles of Biomedical Ethics.
2. Singer, P. Practical Ethics.
3. Harris, J. The Oxford Handbook of Bioethics.
4. Arnold, D. Ethics and the Conduct of Business.
5. Martin, M. & Schinzinger, R. Introduction to Engineering Ethics.
6. Stark, A. Business Ethics: A Managerial Approach.
7. Emanuel, E. et al. Ethical Aspects of Clinical Research.
8. Caplan, A. & McCartney, J. The Cambridge Textbook of Bioethics.
9. Ashford, E. & Fried, C. (eds). The Oxford Handbook of International Human Rights Law.
10. Dworkin, R. Sovereign Virtue.
