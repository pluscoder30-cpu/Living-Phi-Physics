# PHI-Communication: Worked Examples

---

## Example 1: PHI Channel Capacity Calculation

**Problem:** Calculate the effective capacity of a communication channel with 61.8% signal ratio.

**Given:**
- Raw bandwidth: 1000 bits/second
- Signal:Noise ratio = phi:1 = 1.618:1

**Solution:**

```
Signal capacity = 1000 * phi/(phi+1) = 1000 * 1.618/2.618 = 618 bits/second
Noise capacity = 1000 * 1/(phi+1) = 1000 * 1/2.618 = 382 bits/second

Effective capacity = 618 bits/second (signal only)

Verification: 618/1000 = 0.618 = phi^(-1) = 61.8% of raw capacity
```

---

## Example 2: PHI Optimal Group Size

**Problem:** Determine the optimal group size for a brainstorming session.

**Given:**
- PHI formula: N = phi^4 for creative brainstorming

**Solution:**

```
N = phi^4 = 6.854 -> 7 members

Communication channels:
  C = N(N-1)/2 = 7(6)/2 = 21 channels

For comparison:
  Decision-making: N = phi^2 = 3 members, C = 3 channels
  Problem-solving: N = phi^3 = 5 members, C = 10 channels
  Creative: N = phi^4 = 7 members, C = 21 channels

The PHI-group size scales with task complexity.
```

---

## Example 3: PHI Meeting Time Allocation

**Problem:** Design a 90-minute meeting using PHI-proportions.

**Given:**
- Total time: 90 minutes
- PHI structure: Agenda:Discussion:Action = phi^2:phi:1

**Solution:**

```
Total weight = phi^2 + phi + 1 = 5.236

Agenda: 2.618/5.236 * 90 = 45.0 minutes
Discussion: 1.618/5.236 * 90 = 27.7 minutes
Action: 1.000/5.236 * 90 = 17.2 minutes

Verification: 45.0 + 27.7 + 17.2 = 89.9 minutes (rounding)

Optimal group size: phi^3 = 4.236 -> 5 people
```

---

## Example 4: PHI Email Response Time

**Problem:** Calculate response times for different urgency levels.

**Given:**
- Baseline: 60 minutes
- PHI urgency: Urgent:Normal:Low = phi^(-1):phi^0:phi^1

**Solution:**

```
Urgent: 60 * phi^(-1) = 60 * 0.618 = 37.1 minutes
Normal: 60 * phi^0 = 60 minutes
Low: 60 * phi^1 = 60 * 1.618 = 97.1 minutes

Optimal email length:
  L = phi * 50 = 80.9 words -> 80 words

Response priority queue:
  1. Urgent (< 37 min)
  2. Normal (37-97 min)
  3. Low (> 97 min)
```

---

## Example 5: PHI Conversation Flow

**Problem:** Analyze a 6-turn conversation for PHI-patterns.

**Given:**
- Turn lengths: 30s, 18s, 12s, 8s, 5s, 3s

**Solution:**

```
Ratios between turns:
  30/18 = 1.667 (close to phi = 1.618, error 3.0%)
  18/12 = 1.500 (close to phi, error 7.3%)
  12/8 = 1.500 (close to phi, error 7.3%)
  8/5 = 1.600 (close to phi, error 1.1%)
  5/3 = 1.667 (close to phi, error 3.0%)

Average ratio: (1.667+1.500+1.500+1.600+1.667)/5 = 1.587
Deviation from phi: |1.587 - 1.618| / 1.618 = 1.9%

The conversation follows PHI-turn-taking.
```

---

## Example 6: PHI Proxemics Analysis

**Problem:** Determine optimal conversation distance in a business setting.

**Given:**
- Personal distance: 120 cm
- PHI formula: D = phi * personal_distance

**Solution:**

```
D = phi * 120 = 194.2 cm -> 194 cm (1.94 meters)

Zone classification:
  0-45 cm: Intimate (close relationships)
  45-120 cm: Personal (friends, family)
  120-300 cm: Social (acquaintances, business)
  300+ cm: Public (presentations, strangers)

194 cm falls in the social zone (120-300 cm)
This is optimal for business conversations.
```

---

## Example 7: PHI Persuasive Essay Structure

**Problem:** Structure a 1000-word persuasive essay.

**Given:**
- Ethos:Pathos:Logos = phi^2:phi:1

**Solution:**

```
Total weight = phi^2 + phi + 1 = 5.236

Ethos (credibility): 2.618/5.236 * 1000 = 500 words
Pathos (emotion): 1.618/5.236 * 1000 = 309 words
Logos (logic): 1.000/5.236 * 1000 = 191 words

CTA placement:
  Position = phi^(-1) * 1000 = 618th word

Structure:
  Words 1-500: Build credibility (ethos)
  Words 500-809: Emotional appeal (pathos)
  Words 809-1000: Logical argument (logos)
  Word 618: Call-to-action (within pathos section)
```

---

## Example 8: PHI Social Media Post Design

**Problem:** Design a social media post with PHI-structure.

**Given:**
- Post length: 200 characters
- Hook:Content:CTA = phi^2:phi:1

**Solution:**

```
Total weight = 5.236

Hook: 2.618/5.236 * 200 = 100 characters
Content: 1.618/5.236 * 200 = 62 characters
CTA: 1.000/5.236 * 200 = 38 characters

Example post:
  Hook (100 chars): "Did you know that 73% of people struggle with productivity? Here's what the research says..."
  Content (62 chars): "Studies show that the golden ratio applies to time management too."
  CTA (38 chars): "Try the PHI-method and share your results!"

Engagement prediction:
  E = phi * E_baseline = 1.618 * E_baseline
```

---

## Example 9: PHI Crisis Response Plan

**Problem:** Design a crisis response timeline.

**Given:**
- Crisis event: Product recall
- PHI timeline: Acknowledge:Investigate:Resolve:Follow-up = phi^3:phi^2:phi:1

**Solution:**

```
Total weight = phi^3 + phi^2 + phi + 1 = 9.472

Acknowledge: 4.236/9.472 * total_time
Investigate: 2.618/9.472 * total_time
Resolve: 1.618/9.472 * total_time
Follow-up: 1.000/9.472 * total_time

Absolute timeline:
  Acknowledge: 4 hours (issue public statement)
  Investigate: 3 days (internal investigation)
  Resolve: 2 weeks (recall and fix)
  Follow-up: 1 month (status update)

Transparency ratio:
  Released : Withheld = phi : 1 = 1.618 : 1
  = 61.8% transparent, 38.2% protected
```

---

## Example 10: PHI Team Communication Audit

**Problem:** Audit team communication effectiveness.

**Given:**
- Team of 6 members
- Communication data: 50 top-down, 30 lateral, 20 bottom-up messages

**Solution:**

```
PHI-ratio check:
  Top-down:Lateral:Bottom-up = 50:30:20 = 2.5:1.5:1
  PHI = 2.618:1.618:1

Deviation:
  Top-down: |2.5 - 2.618| / 2.618 = 4.5%
  Lateral: |1.5 - 1.618| / 1.618 = 7.3%
  Bottom-up: |1.0 - 1.0| / 1.0 = 0%

The team is slightly top-heavy and laterally deficient.
Recommendation: Increase lateral communication by 4.5%.

Communication channels:
  C = 6(5)/2 = 15 channels
  Active channels: 10 (66.7%)
  Optimal: phi^(-1) * 15 = 9.3 -> 9 channels
```

---

## Example 11: PHI Lecture Design

**Problem:** Design a 75-minute lecture.

**Given:**
- PHI structure: Explain:Example:Practice = phi^2:phi:1

**Solution:**

```
Total weight = 5.236

Explain: 2.618/5.236 * 75 = 37.5 minutes
Example: 1.618/5.236 * 75 = 23.1 minutes
Practice: 1.000/5.236 * 75 = 14.4 minutes

Verification: 37.5 + 23.1 + 14.4 = 75 minutes

Student engagement:
  E = phi * E_baseline = 1.618 * E_baseline

Feedback timing:
  After every phi^2 = 3 assignments
  Detailed feedback every phi^3 = 4 weeks
```

---

## Example 12: PHI Body Language Analysis

**Problem:** Analyze nonverbal cues in a negotiation.

**Given:**
- Posture signals: 20
- Gesture signals: 12
- Facial signals: 8

**Solution:**

```
Total signals: 40

PHI-check:
  Posture:Gesture:Facial = 20:12:8 = 2.5:1.5:1
  PHI = 2.618:1.618:1

Deviation:
  Posture: |2.5 - 2.618| / 2.618 = 4.5%
  Gesture: |1.5 - 1.618| / 1.618 = 7.3%
  Facial: 0%

Interpretation:
  Posture signals dominate (most reliable)
  Facial signals are least frequent (most variable)
  
This matches the PHI-nonverbal hierarchy.
```

---

## Example 13: PHI News Story Analysis

**Problem:** Analyze the lifecycle of a news story.

**Given:**
- Story published: Day 1
- Peak coverage: Day 2
- Follow-up stories: Days 3-7

**Solution:**

```
PHI-lifecycle:
  Breaking: Day 1 (phi^0 = 1.000)
  Developing: Days 2-3 (phi^1 = 1.618 days)
  Follow-up: Days 4-7 (phi^2 = 2.618 days)

Total cycle: phi^3 = 4.236 days -> approximately 4 days

Coverage decay:
  Day 1: 100%
  Day 2: 61.8% (phi^-1)
  Day 3: 38.2% (phi^-2)
  Day 4: 23.6% (phi^-3)
  Day 5: 14.6% (phi^-4)
```

---

## Example 14: PHI Cross-Cultural Adaptation

**Problem:** Adapt communication for a high power-distance culture.

**Given:**
- Power distance index: 70
- Baseline formality: 0.5 (neutral)

**Solution:**

```
Formal:Informal = phi^(PD/100) : 1
= phi^0.7 : 1
= 1.524 : 1

Formality score = 1.524/(1.524+1) = 0.604 (slightly formal)

Adaptation:
  Formal: 60.4% of communication
  Informal: 39.6% of communication

Compared to low power-distance (PD=30):
  Formal:Informal = phi^0.3 : 1 = 1.197 : 1
  Formality = 1.197/2.197 = 0.545 (neutral)
```

---

## Example 15: PHI Therapeutic Communication

**Problem:** Design a therapy session structure.

**Given:**
- Session length: 50 minutes
- Empathic:Directive = phi:1

**Solution:**

```
Total weight = phi + 1 = 2.618

Empathic: 1.618/2.618 * 50 = 30.9 minutes
Directive: 1.000/2.618 * 50 = 19.1 minutes

Session flow:
  0-31 min: Empathic responses (reflection, validation)
  31-50 min: Directive responses (advice, guidance)

Client:Therapist disclosure ratio:
  Client: 61.8% of talk time
  Therapist: 38.2% of talk time

Self-disclosure timing:
  After phi^3 = 4 sessions minimum
```

---

## Example 16: PHI Digital Content Strategy

**Problem:** Design a content calendar.

**Given:**
- Platforms: Blog, Social, Email
- PHI frequency: Daily:Weekly:Monthly = phi^2:phi:1

**Solution:**

```
Blog (Monthly): 1 post/month (phi^0 = 1.000)
Social (Weekly): phi = 1.618 -> 2 posts/week
Email (Daily): phi^2 = 2.618 -> 3 emails/week

Wait -- let me reconsider:
  Blog: Monthly (phi^0)
  Social: Weekly (phi^-1 * monthly = 4.236 posts/month)
  Email: Daily (phi^-2 * monthly = 18.5 posts/month)

Content distribution per month:
  Blog: 1 post (long-form)
  Social: 4 posts (medium-form)
  Email: 18 posts (short-form)

Total: 23 pieces/month

Content ratio:
  Blog:Social:Email = 1:4:18 = phi^0:phi^2:phi^4 (approximately)
```

---

## Example 17: PHI Presentation Design

**Problem:** Design a 20-minute presentation.

**Given:**
- Structure: Opening:Body:Closing = phi^2:phi:1

**Solution:**

```
Total weight = 5.236

Opening: 2.618/5.236 * 20 = 10.0 minutes
Body: 1.618/5.236 * 20 = 6.2 minutes
Closing: 1.000/5.236 * 20 = 3.8 minutes

Slide count (at 1 slide/minute):
  Opening: 10 slides
  Body: 6 slides
  Closing: 4 slides
  Total: 20 slides

Audience engagement:
  E = phi * E_baseline = 1.618 * E_baseline

Optimal audience size:
  N = phi^3 = 4.236 -> 5 people (discussion)
  N = phi^5 = 11.09 -> 11 people (seminar)
  N = phi^7 = 29.03 -> 29 people (lecture)
```

---

## Example 18: PHI Conflict Resolution

**Problem:** Structure a conflict resolution meeting.

**Given:**
- Parties: 2 (in conflict)
- PHI structure: Listen:Understand:Agree:Act = phi^3:phi^2:phi:1

**Solution:**

```
Total weight = 9.472

Listen: 4.236/9.472 * 60 = 26.8 minutes
Understand: 2.618/9.472 * 60 = 16.6 minutes
Agree: 1.618/9.472 * 60 = 10.2 minutes
Act: 1.000/9.472 * 60 = 6.3 minutes

Consensus threshold:
  C >= phi/(phi+1) = 0.618 = 61.8% agreement

Resolution time:
  R = phi * R_baseline = 1.618 * R_baseline
```

---

## Example 19: PHI Media Mix Strategy

**Problem:** Design an advertising media mix.

**Given:**
- Budget: $100,000
- PHI media ratio: Text:Image:Video = phi^2:phi:1

**Solution:**

```
Total weight = 5.236

Text (blogs, articles): 2.618/5.236 * 100,000 = $50,000
Image (display, social): 1.618/5.236 * 100,000 = $30,900
Video (YouTube, TikTok): 1.000/5.236 * 100,000 = $19,100

Verification: 50,000 + 30,900 + 19,100 = 100,000

Reach estimation:
  Text reach: $50,000 / CPM_5 = 10,000 impressions
  Image reach: $30,900 / CPM_10 = 3,090 impressions
  Video reach: $19,100 / CPM_20 = 955 impressions

Total reach: 14,045 impressions
```

---

## Example 20: PHI Feedback System Design

**Problem:** Design a feedback system for a team.

**Given:**
- Team size: 8 people
- PHI feedback structure: Immediate:Delayed:Scheduled = phi^2:phi:1

**Solution:**

```
Total weight = 5.236

Immediate feedback: 2.618/5.236 * 100 = 50% of feedback
Delayed feedback: 1.618/5.236 * 100 = 30.9% of feedback
Scheduled feedback: 1.000/5.236 * 100 = 19.1% of feedback

Feedback frequency:
  Immediate: After every task (phi^0)
  Delayed: After every phi = 2 tasks
  Scheduled: After every phi^2 = 3 weeks

Team communication channels:
  C = 8(7)/2 = 28 channels
  Optimal active: phi^(-1) * 28 = 17.3 -> 17 channels

Feedback ratio:
  Positive : Constructive = phi : 1 = 1.618 : 1
  = 61.8% positive, 38.2% constructive
```

---

## Summary Table: PHI Communication Examples

| # | Domain | PHI-concept | Result |
|---|--------|-------------|--------|
| 1 | Channel capacity | Signal ratio | 61.8% of bandwidth |
| 2 | Group size | Optimal members | phi^3 = 4-5 people |
| 3 | Meeting design | Time allocation | 50:30.9:19.1% |
| 4 | Email | Response time | 37:60:97 minutes |
| 5 | Conversation | Turn-taking | phi-decaying lengths |
| 6 | Proxemics | Distance | phi * personal_zone |
| 7 | Persuasion | Essay structure | 50:30.9:19.1% |
| 8 | Social media | Post design | Hook:Content:CTA |
| 9 | Crisis | Response timeline | 4hr:3day:2wk:1mo |
| 10 | Team audit | Communication | phi-ratio check |
| 11 | Education | Lecture design | Explain:Example:Practice |
| 12 | Body language | Signal analysis | Posture dominates |
| 13 | News | Story lifecycle | phi^3 = 4-day cycle |
| 14 | Cross-cultural | Adaptation | phi^(PD/100) ratio |
| 15 | Therapy | Session structure | 61.8% empathic |
| 16 | Content | Calendar design | Blog:Social:Email |
| 17 | Presentation | Slide design | 10:6:4 slides |
| 18 | Conflict | Resolution meeting | Listen:Understand:Agree:Act |
| 19 | Advertising | Media mix | 50:30.9:19.1% budget |
| 20 | Feedback | System design | 50:30.9:19.1% timing |

---

*This document is part of the PHI-Physics Dictionary, Directory 56: PHI-Communication.*
*Total lines: 500+*
