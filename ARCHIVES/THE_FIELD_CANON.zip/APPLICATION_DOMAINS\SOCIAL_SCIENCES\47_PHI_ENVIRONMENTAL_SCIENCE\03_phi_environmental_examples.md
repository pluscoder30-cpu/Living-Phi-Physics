# PHI-ENVIRONMENTAL SCIENCE: Worked Examples

---

## Example 1: Climate Oscillation Decomposition

**Problem:** A region's temperature record shows oscillations with periods of 162, 262, and 424 years. Find the amplitude of each phi-harmonic mode if the total temperature variation is ±2°C.

**Solution:**

Step 1: Phi-harmonic amplitudes
```
B_k = B₁ × φ^(−(k−1))  for k = 1, 2, 3
```

Step 2: Total variation
```
ΔT_total = 2 × Σ_k B_k = 2 × B₁ × (1 + 1/φ + 1/φ²)
= 2 × B₁ × (1 + 0.618 + 0.382)
= 2 × B₁ × 2.0
= 4 × B₁
```

Step 3: Solve for B₁
```
4 × B₁ = 2°C
B₁ = 0.5°C
```

Step 4: Individual amplitudes
```
B₁ = 0.500°C (162-year cycle)
B₂ = 0.500/φ = 0.309°C (262-year cycle)
B₃ = 0.500/φ² = 0.191°C (424-year cycle)
```

**Interpretation:** The 162-year cycle dominates, with each successive phi-harmonic contributing 1/φ times less, creating a convergent temperature decomposition.

---

## Example 2: Biodiversity Prediction

**Problem:** A nature reserve has area A = 100 km² and currently supports S = 500 species. Predict the species count for a 500 km² reserve using the phi-biodiversity law.

**Solution:**

Step 1: Phi-biodiversity formula
```
S_φ(A) = S₀ × (A/A₀)^(1/φ)
```

Step 2: Find S₀/A₀ from current data
```
500 = S₀ × (100/A₀)^0.618
```
Assume A₀ = 1 km² (reference area):
```
500 = S₀ × 100^0.618
500 = S₀ × 25.12
S₀ = 500/25.12 = 19.9
```

Step 3: Predict for 500 km²
```
S(500) = 19.9 × 500^0.618
= 19.9 × 52.48
= 1,044 species
```

Step 4: Standard model comparison (exponent 0.25)
```
S_std(500) = 500 × (500/100)^0.25
= 500 × 5^0.25
= 500 × 1.495
= 748 species
```

**Difference:** Phi-model predicts 1,044 species vs standard 748 (39.6% more biodiversity).

---

## Example 3: Carbon Cycle Modeling

**Problem:** Atmospheric CO₂ is currently 420 ppm. Predict CO₂ in 100 and 200 years using the phi-carbon model with τ_carbon = 300 years and K_carbon = 1000 ppm.

**Solution:**

Step 1: Phi-carbon formula
```
CO₂(t) = CO₂₀ × φ^(t/τ) × (1 − CO₂/K)
```

Step 2: For t = 100 years (ignoring saturation first)
```
CO₂(100) = 420 × φ^(100/300)
= 420 × φ^0.333
= 420 × 1.189
= 499 ppm
```

Step 3: With saturation
```
CO₂(100) = 420 × 1.189 × (1 − 420/1000)
= 420 × 1.189 × 0.580
= 290 ppm (saturation slows growth)
```

Step 4: For t = 200 years
```
CO₂(200) = 420 × φ^(200/300)
= 420 × φ^0.667
= 420 × 1.414
= 594 ppm (without saturation)
With saturation:
= 420 × 1.414 × (1 − 420/1000)
= 420 × 1.414 × 0.580
= 345 ppm
```

**Interpretation:** CO₂ growth is bounded by the carbon carrying capacity, creating a logistic-type trajectory with phi-exponential growth.

---

## Example 4: Pollution Dispersion

**Problem:** A factory emits pollutants at concentration C₀ = 100 units. Find the concentration at 5 km, 10 km, and 20 km, with R_atm = 15 km.

**Solution:**

Step 1: Dispersion formula
```
C(r) = C₀ × φ^(−r/R_atm)
```

Step 2: Calculate
```
r = 5 km: C = 100 × φ^(−5/15) = 100 × φ^(−0.333) = 100 × 0.794 = 79.4 units
r = 10 km: C = 100 × φ^(−10/15) = 100 × φ^(−0.667) = 100 × 0.630 = 63.0 units
r = 20 km: C = 100 × φ^(−20/15) = 100 × φ^(−1.333) = 100 × 0.397 = 39.7 units
```

Step 3: Standard model comparison (1/r decay)
```
r = 5 km: C_std = 100 × 5/5 = 100 (normalized)
r = 10 km: C_std = 100 × 5/10 = 50
r = 20 km: C_std = 100 × 5/20 = 25
```

**Interpretation:** The phi-dispersion decays faster than 1/r initially but has heavier tails at long range, matching observed pollution patterns near industrial sources.

---

## Example 5: Sustainability Assessment

**Problem:** A fishery has regeneration rate R = 1000 tons/year. Current extraction is E = 800 tons/year. Find the sustainability index and optimal extraction rate.

**Solution:**

Step 1: Optimal extraction rate
```
E_opt = R/φ = 1000/1.618 = 618 tons/year
```

Step 2: Current extraction ratio
```
E/E_opt = 800/618 = 1.294
```

Step 3: Ecological footprint
```
EF = φ^(−E/E_opt) = φ^(−1.294) = 0.413
```

Step 4: Sustainability index
```
SI = E × φ^(−E/E_opt) / (E_opt × φ^(−1))
= 800 × 0.413 / (618 × 0.618)
= 330.4 / 382.0
= 0.865
```

Step 5: Interpretation
```
SI = 0.865 (out of 1.0 maximum)
Status: Moderately sustainable
Recommendation: Reduce extraction by 22.2% to reach E_opt = 618 tons/year
```

---

## Example 6: Ecosystem Stability

**Problem:** An ecosystem has 5 species with growth rates r = [1.0, 0.8, 0.6, 0.4, 0.2] and r_max = 1.0. Check the ecosystem balance condition.

**Solution:**

Step 1: Balance condition
```
Π_i (r_i/r_max)^(1/φ^i) = 1
```

Step 2: Calculate each term
```
i=1: (1.0/1.0)^(1/φ^1) = 1.0^0.618 = 1.000
i=2: (0.8/1.0)^(1/φ^2) = 0.8^0.382 = 0.920
i=3: (0.6/1.0)^(1/φ^3) = 0.6^0.236 = 0.901
i=4: (0.4/1.0)^(1/φ^4) = 0.4^0.146 = 0.917
i=5: (0.2/1.0)^(1/φ^5) = 0.2^0.090 = 0.934
```

Step 3: Product
```
Product = 1.000 × 0.920 × 0.901 × 0.917 × 0.934 = 0.716
```

Step 4: Deviation from balance
```
|Product − 1| = |0.716 − 1| = 0.284 = 28.4% deviation
```

**Interpretation:** The ecosystem is 28.4% from perfect balance, indicating moderate instability. The phi-weighted condition predicts species 3-5 need adjustment to restore balance.

---

## Example 7: Ocean Acidification

**Problem:** Ocean pH dropped from 8.1 to 8.0 in 50 years. Find the pH in 100 and 200 years, with τ_acidification = 200 years.

**Solution:**

Step 1: Acidification formula
```
pH(t) = pH₀ − ΔpH × (1 − φ^(−t/τ))
```

Step 2: Find ΔpH from current data
```
8.0 = 8.1 − ΔpH × (1 − φ^(−50/200))
0.1 = ΔpH × (1 − φ^(−0.25))
0.1 = ΔpH × (1 − 0.871)
0.1 = ΔpH × 0.129
ΔpH = 0.1/0.129 = 0.775
```

Step 3: Predict pH at t = 100
```
pH(100) = 8.1 − 0.775 × (1 − φ^(−100/200))
= 8.1 − 0.775 × (1 − φ^(−0.5))
= 8.1 − 0.775 × (1 − 0.786)
= 8.1 − 0.775 × 0.214
= 8.1 − 0.166
= 7.934
```

Step 4: Predict pH at t = 200
```
pH(200) = 8.1 − 0.775 × (1 − φ^(−200/200))
= 8.1 − 0.775 × (1 − φ^(−1))
= 8.1 − 0.775 × (1 − 0.618)
= 8.1 − 0.775 × 0.382
= 8.1 − 0.296
= 7.804
```

**Interpretation:** pH declines slowly at first (φ^(−t) ≈ 1), then accelerates, reaching 7.804 after 200 years—a 28% decline from pre-industrial levels.

---

## Example 8: Renewable Energy Adoption

**Problem:** Renewable energy currently provides 15% of electricity. Predict adoption in 10, 20, and 30 years using the phi-logistic model, with F_max = 95% and τ_adopt = 15 years.

**Solution:**

Step 1: Phi-logistic formula
```
F(t) = F_max / (1 + φ^(−(t−t₀)/σ))
```

Step 2: Find t₀ from current data
```
0.15 = 0.95 / (1 + φ^(−(0−t₀)/σ))
1 + φ^(t₀/σ) = 0.95/0.15 = 6.333
φ^(t₀/σ) = 5.333
t₀/σ = ln(5.333)/ln(φ) = 1.674/0.481 = 3.48
```

Step 3: Predict at t = 10, 20, 30
```
t = 10: F = 0.95 / (1 + φ^(−(10−3.48×15)/15))
= 0.95 / (1 + φ^(−(10−52.2)/15))
= 0.95 / (1 + φ^(2.813))
= 0.95 / (1 + 3.762)
= 0.95 / 4.762
= 19.9%

t = 20: F = 0.95 / (1 + φ^(−(20−52.2)/15))
= 0.95 / (1 + φ^(2.147))
= 0.95 / (1 + 2.536)
= 0.95 / 3.536
= 26.9%

t = 30: F = 0.95 / (1 + φ^(−(30−52.2)/15))
= 0.95 / (1 + φ^(1.48))
= 0.95 / (1 + 1.819)
= 0.95 / 2.819
= 33.7%
```

**Interpretation:** Renewable adoption grows from 15% to 34% over 30 years, with phi-logistic predicting faster early growth than standard logistic.

---

## Example 9: Water Quality Assessment

**Problem:** A river receives pollutants with total load Σ C/C_th = 2.0. Find the water quality index and determine if it's safe for drinking.

**Solution:**

Step 1: Water quality formula
```
WQ = WQ₀ × φ^(−Σ C/C_th)
```

Step 2: Calculate
```
WQ = 1.0 × φ^(−2.0) = 0.382
```

Step 3: Quality classification
```
WQ > 0.8: Excellent
0.6 < WQ < 0.8: Good
0.4 < WQ < 0.6: Moderate
0.2 < WQ < 0.4: Fair
WQ < 0.2: Poor
```

Step 4: Classification
```
WQ = 0.382 → Fair quality
Status: Not safe for drinking without treatment
Recommendation: Reduce pollutant load to Σ C/C_th < 1.0 for good quality
```

---

## Example 10: Planetary Boundary Assessment

**Problem:** Three planetary boundaries are at 60%, 80%, and 100% of their critical values. Find the safe operating space and overall risk.

**Solution:**

Step 1: Safe operating space formula
```
SOS = Π_i [1 − (B_i/B_crit_i)^(φ)]
```

Step 2: Calculate each term
```
Boundary 1 (60%): (1 − 0.6^1.618) = 1 − 0.461 = 0.539
Boundary 2 (80%): (1 − 0.8^1.618) = 1 − 0.697 = 0.303
Boundary 3 (100%): (1 − 1.0^1.618) = 1 − 1.000 = 0.000
```

Step 3: Product
```
SOS = 0.539 × 0.303 × 0.000 = 0.000
```

Step 4: Interpretation
```
SOS = 0.000 → Critical state
One boundary at 100% means the system is at the edge of collapse
Action: Immediately reduce Boundary 3 below critical level
```

---

*End of PHI-ENVIRONMENTAL SCIENCE Examples*
