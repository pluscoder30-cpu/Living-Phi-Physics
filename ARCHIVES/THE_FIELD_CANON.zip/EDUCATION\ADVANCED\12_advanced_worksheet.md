# Advanced Mathematics: Worksheet — 200 Problems

## Ages 16+ | Mixed Topics Across All 11 Ratio-Systems

---

## Section A: The Golden Ratio (Problems 1–20)

1. Prove that φ² = φ + 1 using the quadratic formula.

2. Prove that φⁿ = F(n)φ + F(n−1) by strong induction.

3. Find the norm N(a + bφ) in Z[φ].

4. Prove that φ is the most irrational number (Hurwitz's theorem).

5. Prove that F(n+1)F(n−1) − F(n)² = (−1)ⁿ (Cassini's identity).

6. Find the continued fraction expansion of φ².

7. Prove that φ = [1; 1, 1, 1, ...].

8. Prove that the units of Z[φ] are ±φⁿ.

9. Find the generating function G(x) = ∑ F(n)xⁿ.

10. Prove that ∑_{k=0}^{n} F(k) = F(n+2) − 1.

11. Prove that F(2n) = F(n)L(n).

12. Prove that F(n) divides F(mn) for all m.

13. Find the Galois conjugate of φ.

14. Prove that the ring of integers of Q(√5) is Z[φ].

15. Prove that φ is a unit in Z[φ].

16. Find the discriminant of the minimal polynomial of φ.

17. Prove that the Fibonacci sequence has no three-term arithmetic progression.

18. Prove that F(p) ≡ (5/p) (mod p) for prime p ≠ 5.

19. Find the exact value of the infinite product ∏(1 + 1/F(2n)).

20. Prove that the golden section search converges at rate 1/φ.

---

## Section B: The Silver Ratio (Problems 21–40)

21. Prove that δₛ² = 2δₛ + 1.

22. Prove that δₛ = 1 + √2 is irrational.

23. Find the continued fraction of δₛ.

24. Prove that the Pell numbers satisfy P(n+1)² − 2P(n)² = (−1)ⁿ.

25. Find the norm N(a + bδₛ) in Z[δₛ].

26. Prove that δₛ · δₛ* = −1.

27. Prove that the Pell equation x² − 2y² = ±1 has infinitely many solutions.

28. Find the generating function of Pell numbers.

29. Prove that P(n) divides P(mn) for all m.

30. Prove that the ratio P(n+1)/P(n) converges to δₛ.

31. Prove that the silver ratio is the second metallic mean.

32. Find the minimal polynomial of δₛ.

33. Prove that the ring of integers of Q(√2) is Z[√2].

34. Prove that Z[√2] is a Euclidean domain.

35. Find the period of Pell numbers mod 5.

36. Prove that the regular octagon has diagonal/side ratio = δₛ.

37. Prove that P(2n) = P(n)Q(n) where Q(n) is the Pell-Lucas number.

38. Find the continued fraction of √2.

39. Prove that 1/δₛ = δₛ − 2.

40. Prove that the silver ratio is the second most irrational number.

---

## Section C: The Bronze Ratio (Problems 41–60)

41. Prove that δᵦ² = 3δᵦ + 1.

42. Find the minimal polynomial of δᵦ.

43. Prove that δᵦ is the third metallic mean.

44. Find the continued fraction of δᵦ.

45. Prove that B(n) = 3B(n−1) + B(n−2) (bronze recurrence).

46. Find the Binet formula for the bronze sequence.

47. Prove that δᵦ · δᵦ* = −1.

48. Find the norm N(a + bδᵦ) in Z[δᵦ].

49. Prove that the class number of Q(√13) is 1.

50. Prove that B(n) is even iff n ≡ 0 (mod 3).

51. Find the generating function of the bronze sequence.

52. Prove that B(3n) is divisible by B(n).

53. Prove that the ratio B(n+1)/B(n) converges to δᵦ.

54. Find the discriminant of x² − 3x − 1.

55. Prove that the units of Z[δᵦ] are ±δᵦⁿ.

56. Prove that B(n+1)B(n−1) − B(n)² = (−1)ⁿ⁺¹.

57. Find the period of B(n) mod 7.

58. Prove that δᵦ = 3 + 1/(3 + 1/(3 + ...)).

59. Prove that B(n) divides B(mn) for all m.

60. Find the continued fraction of √13.

---

## Section D: Harmonic Mathematics (Problems 61–80)

61. Prove that the harmonic series diverges (Oresme's proof).

62. Prove that ζ(2) = π²/6 (Basel problem).

63. Find the Euler-Mascheroni constant γ.

64. Prove that the p-series converges iff p > 1.

65. Prove that ζ(3) is irrational (Apéry's theorem).

66. Find the sum ∑_{n=1}^{∞} 1/(n(n+1)).

67. Prove that ∑_{n=1}^{∞} (−1)ⁿ⁺¹/n = ln(2).

68. Prove that H(n) = ∑_{k=1}^{n} 1/k ~ ln(n) + γ.

69. Prove that H(n) is never an integer for n > 1.

70. Prove that the Euler product formula holds: ζ(s) = ∏ 1/(1 − p⁻ˢ).

71. Find ∑_{n=1}^{∞} 1/n⁴.

72. Prove that the alternating harmonic series converges conditionally.

73. Prove that the harmonic mean ≤ geometric mean ≤ arithmetic mean.

74. Find ∑_{n=1}^{∞} 1/(4n²−1).

75. Prove that the product ∏ p/(p−1) diverges.

76. Find the Ramanujan summation: 1 + 2 + 3 + ... = −1/12.

77. Prove that ∑_{n=1}^{∞} H(n)/n² = 2ζ(3).

78. Prove that ζ(s) has a simple pole at s = 1 with residue 1.

79. Prove that ∑_{n=1}^{∞} 1/(n² + n) = 1.

80. Prove that ζ(0) = −1/2.

---

## Section E: Living Mathematics (Problems 81–100)

81. Find the fractal dimension of the Koch curve.

82. Prove that the Koch curve has infinite length.

83. Find the Hausdorff dimension of the Sierpinski triangle.

84. Prove that a straight line has fractal dimension 1.

85. Find the fractal dimension of the Sierpinski carpet.

86. Prove that the Cantor set is uncountable.

87. Prove that self-similar sets are compact (Hutchinson's theorem).

88. Find the fractal dimension of the Menger sponge.

89. Prove that the Sierpinski triangle has area 0.

90. Find the fractal dimension of the Vicsek fractal.

91. Prove that the Hausdorff dimension is monotone.

92. Prove that the box-counting dimension exists for the Koch curve.

93. Find the fractal dimension of a Brownian motion path in 2D.

94. Prove that the Hausdorff dimension of a countable set is 0.

95. Find the fractal dimension of the Apollonian gasket.

96. Prove that the Mandelbrot set is connected.

97. Find the fractal dimension of the Mandelbrot boundary.

98. Prove that the Koch curve is a Jordan curve.

99. Find the fractal dimension of a random walk in 1D.

100. Prove that the Gosper island has dimension 2.

---

## Section F: The Plastic Number (Problems 101–120)

101. Prove that ψ³ = ψ + 1.

102. Find the minimal polynomial of ψ.

103. Prove that ψ is a Pisot number.

104. Find the continued fraction of ψ.

105. Prove that the Padovan sequence satisfies P(n) = P(n−2) + P(n−3).

106. Find the generating function of the Padovan sequence.

107. Prove that P(n) ~ Aψⁿ.

108. Prove that the discriminant of x³ − x − 1 is −23.

109. Prove that Q(ψ) has class number 1.

110. Prove that the Galois group of x³ − x − 1 is S₃.

111. Find the Binet formula for the Padovan sequence.

112. Prove that P(n+1)/P(n) → ψ.

113. Find the period of P(n) mod 2.

114. Prove that the ring of integers of Q(ψ) is Z[ψ].

115. Prove that N(ψ) = 1.

116. Find the minimal polynomial of ψ².

117. Prove that the Perrin sequence has the property p | P(p) for prime p.

118. Find the Perrin pseudoprime 271441.

119. Prove that ∑_{k=0}^{n} P(k) = P(n+5) − 2.

120. Prove that the Padovan spiral approaches ψ.

---

## Section G: The Supergolden Ratio (Problems 121–140)

121. Prove that ψₛ³ = ψₛ² + 1.

122. Find the minimal polynomial of ψₛ.

123. Prove that ψₛ is a Pisot number.

124. Find the continued fraction of ψₛ.

125. Prove that the Narayana cows sequence satisfies N(n) = N(n−1) + N(n−3).

126. Find the generating function of the Narayana sequence.

127. Prove that N(n) ~ Aψₛⁿ.

128. Prove that the discriminant of x³ − x² − 1 is −31.

129. Prove that Q(ψₛ) has class number 1.

130. Prove that the Galois group of x³ − x² − 1 is S₃.

131. Find the Binet formula for the Narayana sequence.

132. Prove that N(n+1)/N(n) → ψₛ.

133. Find the period of N(n) mod 2.

134. Prove that the ring of integers of Q(ψₛ) is Z[ψₛ].

135. Prove that N(ψₛ) = 1.

136. Find the minimal polynomial of ψₛ².

137. Prove that 1/ψₛ = ψₛ² − ψₛ.

138. Prove that the Narayana sequence mod 2 has period 7.

139. Prove that N(n) divides N(mn) for all m.

140. Prove that the supergolden spiral has growth factor ψₛ.

---

## Section H: Fibonacci Sequence (Problems 141–160)

141. Prove Binet's formula for F(n).

142. Prove that F(n) is even iff 3 | n.

143. Prove that F(2n) = F(n)(2F(n+1) − F(n)).

144. Find all n such that F(n) = n.

145. Prove that ∑_{k=1}^{n} F(2k−1) = F(2n).

146. Prove that gcd(F(m), F(n)) = F(gcd(m,n)).

147. Find the Pisano period π(10).

148. Prove that F(n+1)² + F(n)² = F(2n+1).

149. Prove that F(n) divides F(nk) for all k.

150. Prove that F(n) mod m is periodic.

151. Prove that F(n+3) = 2F(n+1) + F(n).

152. Find the exact value of F(100).

153. Prove that the Fibonacci sequence has no three-term AP.

154. Prove that ∑ C(n,k)F(k) = F(2n).

155. Prove that F(n)² + F(n+1)² = F(2n+1).

156. Find the generating function of F(n)².

157. Prove that F(n) divides F(mn).

158. Prove that the number of compositions of n using 1's and 2's is F(n+1).

159. Prove that F(n−1)F(n+1) − F(n)² = (−1)ⁿ.

160. Prove that ∑_{k=0}^{n} F(k)² = F(n)F(n+1).

---

## Section I: Lucas Numbers (Problems 161–180)

161. Prove Binet's formula for L(n).

162. Prove that L(n) = F(n−1) + F(n+1).

163. Prove that F(2n) = F(n)L(n).

164. Prove that L(n)² − 5F(n)² = 4(−1)ⁿ.

165. Prove that L(n) is even iff 3 | n.

166. Prove that L(2n) = L(n)² − 2(−1)ⁿ.

167. Find the generating function of L(n).

168. Prove that ∑_{k=0}^{n} L(k) = L(n+2) − 1.

169. Prove that if L(n) is prime, then n is prime.

170. Find the period of L(n) mod 10.

171. Prove that L(n+3) = 2L(n+1) + L(n).

172. Prove that L(n)² − 5F(n)² = 4(−1)ⁿ.

173. Prove that L(n) = 2F(n+1) − F(n).

174. Prove that L(2n+1) = 5F(n)F(n+1) + (−1)ⁿ.

175. Find the generating function of L(n)².

176. Prove that gcd(F(n), L(n)) is 1 or 2.

177. Prove that L(n) divides L(mn) for odd m.

178. Find the period of L(n) mod 7.

179. Prove that F(n+1)L(n) = F(2n+1) + (−1)ⁿ.

180. Prove that L(n)/F(n) → √5.

---

## Section J: Padovan Sequence (Problems 181–190)

181. Prove that P(n+3) = P(n+1) + P(n).

182. Find the generating function of the Padovan sequence.

183. Prove that P(n) ~ Aψⁿ.

184. Prove that ∑_{k=0}^{n} P(k) = P(n+5) − 2.

185. Prove that P(n+1)/P(n) → ψ.

186. Prove that P(n) divides P(mn).

187. Find the period of P(n) mod 2.

188. Prove that the discriminant of x³ − x − 1 is −23.

189. Prove that the Galois group of x³ − x − 1 is S₃.

190. Prove that the Padovan sequence has no clean Cassini-type identity.

---

## Section K: Kepler Mathematics (Problems 191–200)

191. Prove Kepler's third law for circular orbits.

192. Solve Kepler's equation M = E − e sin(E) for M = π/2, e = 0.5.

193. Prove that the area of an ellipse is πab.

194. Find the eccentricity given semi-major axis a and perihelion q.

195. Prove that orbital energy is −GMm/(2a).

196. Find the orbital period at altitude h above Earth.

197. Prove that the FCC packing density is π/(3√2).

198. Prove that the golden ratio appears in the regular dodecahedron.

199. Find the escape velocity from Earth.

200. Prove that the Titius-Bode law fails for Neptune.

---

## Section L: Mixed Topics (Problems 191–200)

191. Prove that the golden ratio and silver ratio are both roots of quadratic equations with integer coefficients.

192. Compare the continued fractions of φ, δₛ, and δᵦ.

193. Prove that the plastic number ψ is not a quadratic irrational.

194. Find the relationship between the Padovan sequence and the Fibonacci sequence.

195. Prove that the metallic means form a strictly increasing sequence.

196. Find the discriminant of the minimal polynomial of the supergolden ratio.

197. Prove that the golden ratio is transcendental... no, prove it is algebraic.

198. Find the period of the Padovan sequence mod 3.

199. Prove that the bronze ratio is irrational.

200. Find the continued fraction of the plastic number to 5 terms.

---

*Total: 200 problems across 11 ratio-systems*
