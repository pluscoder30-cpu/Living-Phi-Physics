# Chapter 11: Phi-Biology and Phi-Medicine

## The Golden Ratio in Living Systems and Health

---

### Overview

The golden ratio pervades biology at every scale, from the molecular structure of DNA to the proportions of the human body. In medicine, the golden ratio appears in diagnostic imaging, drug design, and the analysis of biological signals.

This chapter explores these connections, showing that the golden ratio is not just an abstract constant but a practical tool for understanding life.

---

## Lesson 11.1: DNA and the Golden Ratio

### Explanation

DNA, the molecule of life, has a structure that is intimately connected to the golden ratio.

### The DNA Double Helix

DNA is a double helix with the following dimensions:

- The width of the helix: 2 nm = 20 Å
- The length of one complete turn: 34 Å
- The distance between base pairs: 3.4 Å

The ratio of the length of one turn to the width is:

34 Å / 20 Å = 1.7

This is close to φ ≈ 1.618.

The ratio of the length of one turn to the distance between base pairs is:

34 Å / 3.4 Å = 10

And the ratio of the width to the distance between base pairs is:

20 Å / 3.4 Å ≈ 5.88

This is close to φ³ ≈ 4.236, though not exactly equal.

**Key Concept**: The dimensions of the DNA double helix approximate the golden ratio.

### The Base Pairing Rule

DNA has four bases: adenine (A), thymine (T), guanine (G), and cytosine (C). A pairs with T, and G pairs with C.

The number of possible codons (three-base sequences) is 4³ = 64. The number of amino acids encoded by these codons is 20 (plus stop codons). The ratio 64/20 = 3.2, which is close to the bronze ratio B ≈ 3.303.

### The Golden Ratio in Protein Structure

Proteins are built from amino acids, and the ratios of the sizes of different amino acids often approximate the golden ratio. For example:

- The ratio of the volume of the largest amino acid (tryptophan) to the smallest (glycine) is approximately φ²
- The ratio of the lengths of the α-helix and β-sheet structures in proteins is approximately φ

### Worked Example 11.1.1

The DNA double helix has a width of 20 Å and a pitch (length of one turn) of 34 Å. What is the ratio of pitch to width? How close is this to φ?

**Solution**: Ratio = 34/20 = 1.7

φ ≈ 1.618

The ratio is close to φ, but not exactly equal. The discrepancy is about 5%.

### Worked Example 11.1.2

A protein has an α-helix of length 54 Å and a β-sheet of length 33 Å. What is the ratio? How close is this to φ?

**Solution**: Ratio = 54/33 ≈ 1.636

This is close to φ ≈ 1.618. The discrepancy is about 1.1%.

### Practice Problems

1. Compute the ratio of the DNA pitch to the width. How close is it to φ?
2. What is the ratio of the number of codons to the number of amino acids? Is this close to any metallic ratio?
3. Research: what are the dimensions of the α-helix and β-sheet in proteins?
4. Why might the golden ratio appear in protein structure?
5. Measure the dimensions of a DNA model (if available). Do the ratios approximate φ?

### Teacher's Notes

**Molecular Biology Connection**: This lesson connects the golden ratio to molecular biology. The dimensions of DNA are precisely known, making this a good quantitative example.

**Caveat**: Emphasize that the golden ratio in DNA is approximate, not exact. The dimensions of DNA are determined by the chemistry of the bases, not by a mathematical design principle.

---

## Lesson 11.2: Neural Oscillations and the Golden Ratio

### Explanation

The brain produces electrical oscillations (brain waves) at various frequencies. These frequencies are organized in a hierarchy, and the ratios between consecutive frequencies often approximate the golden ratio.

### Brain Wave Frequencies

| Wave Type | Frequency Range | Ratio to Previous |
|-----------|----------------|-------------------|
| Delta | 0.5-4 Hz | — |
| Theta | 4-8 Hz | 2-8 |
| Alpha | 8-13 Hz | 1-1.625 |
| Beta | 13-30 Hz | 1.625-2.3 |
| Gamma | 30-100 Hz | 2.3-3.3 |

The ratio of the upper bound of alpha (13 Hz) to the lower bound of alpha (8 Hz) is 13/8 = 1.625, which is very close to φ ≈ 1.618.

The ratio of the upper bound of theta (8 Hz) to the lower bound of theta (4 Hz) is 8/4 = 2, which is not close to φ. But the ratio of the center of alpha (10.5 Hz) to the center of theta (6 Hz) is 10.5/6 = 1.75, which is somewhat close to φ.

**Key Concept**: The ratios of brain wave frequencies approximate the golden ratio, suggesting that the brain may use golden-ratio-based timing.

### The Phi-Oscillation

Some researchers have proposed that the brain has a "phi-oscillation" at a frequency of approximately φ Hz ≈ 1.618 Hz. This oscillation would be too slow to measure directly (it is in the delta range), but it would influence the timing of faster oscillations.

### Neural Synchrony and the Golden Ratio

When different parts of the brain synchronize their oscillations, they can communicate more effectively. Some researchers have found that the frequencies at which neural synchrony occurs are related to the golden ratio.

For example, if one brain region oscillates at 10 Hz and another at 16 Hz, their ratio is 16/10 = 1.6, which is close to φ. This may allow the two regions to synchronize more easily.

### Worked Example 11.2.1

The alpha wave frequency range is 8-13 Hz. What is the ratio of the upper to the lower bound? How close is this to φ?

**Solution**: Ratio = 13/8 = 1.625

φ ≈ 1.618

The ratio is very close to φ. The discrepancy is only 0.4%.

### Worked Example 11.2.2

If the brain uses golden-ratio-based timing, what frequency would correspond to a 5:3 ratio with the alpha wave center frequency (10.5 Hz)?

**Solution**: 5/3 = 1.6667

Frequency = 10.5 × (5/3) = 17.5 Hz

This is in the beta range (13-30 Hz).

### Practice Problems

1. Compute the ratio of the gamma wave upper bound to the alpha wave upper bound.
2. What is the ratio of the beta wave center frequency to the theta wave center frequency?
3. How close are these ratios to φ?
4. Research: what is neural synchrony? How is it measured?
5. Why might the brain use golden-ratio-based timing?

### Teacher's Notes

**Neuroscience Connection**: This lesson connects the golden ratio to neuroscience. The frequencies of brain waves are precisely measured, making this a good quantitative example.

**Caveat**: The connections between the golden ratio and brain wave frequencies are approximate. Not all frequency ratios are close to φ, and the significance of the close ratios is not fully understood.

---

## Lesson 11.3: The Golden Ratio in Medical Imaging

### Explanation

The golden ratio appears in several areas of medical imaging:

**1. MRI and CT Scan Analysis**

When analyzing MRI or CT scans, radiologists sometimes use the golden ratio to assess the proportions of organs. For example:

- The ratio of the length to the width of the liver is approximately φ
- The ratio of the diameter of the aorta to the diameter of the inferior vena cava is approximately φ

**2. Tumor Growth**

Some researchers have found that the growth patterns of certain tumors approximate logarithmic spirals with golden ratio proportions. This may be related to the way tumor cells divide and migrate.

**3. Bone Fractures**

The golden ratio appears in the analysis of bone fractures. The angle at which a bone fractures is sometimes related to the golden ratio, because the internal structure of bone has golden-ratio-based proportions.

**4. Dental Proportions**

The proportions of teeth, particularly the ratio of the width of the central incisor to the width of the lateral incisor, often approximate the golden ratio.

### The Golden Ratio in the Heart

The heart has several golden-ratio-based proportions:

- The ratio of the length to the width of the left ventricle is approximately φ
- The ratio of the circumference to the diameter of the aorta is approximately φ
- The ratio of the systolic to the diastolic blood pressure is sometimes close to φ

### Worked Example 11.3.1

A liver has length 20 cm and width 12.5 cm. What is the ratio? How close is this to φ?

**Solution**: Ratio = 20/12.5 = 1.6

φ ≈ 1.618

The ratio is close to φ. The discrepancy is about 1.1%.

### Worked Example 11.3.2

A dental x-ray shows that the central incisor has width 8.5 mm and the lateral incisor has width 5.2 mm. What is the ratio? How close is this to φ?

**Solution**: Ratio = 8.5/5.2 ≈ 1.635

φ ≈ 1.618

The ratio is close to φ. The discrepancy is about 1.0%.

### Practice Problems

1. Measure the length and width of your own liver (if you have an ultrasound image) or use average values. Compute the ratio.
2. Research: what is the normal ratio of the left ventricle length to width?
3. Why might dental proportions approximate the golden ratio?
4. How can the golden ratio be used in medical diagnosis?
5. What are the limitations of using the golden ratio in medicine?

### Teacher's Notes

**Medical Application**: This lesson connects the golden ratio to medical imaging. This is a practical application that shows the golden ratio is not just an abstract constant.

**Caution**: Emphasize that the golden ratio is not a diagnostic tool by itself. Medical diagnosis requires many factors, and the golden ratio is just one of many measurements.

---

## Lesson 11.4: The Golden Ratio in Pharmacology

### Explanation

The golden ratio appears in pharmacology in several ways:

**1. Drug Dosing**

Some drug dosing protocols use ratios that approximate the golden ratio. For example, the ratio of the maximum safe dose to the minimum effective dose for some drugs is close to φ.

**2. Drug Design**

In rational drug design, the proportions of drug molecules are sometimes optimized using golden-ratio-based geometry. This is particularly true for drugs that interact with biological receptors, which often have golden-ratio-based proportions.

**3. Clinical Trials**

In clinical trial design, the ratio of the treatment group to the control group is sometimes chosen to be close to φ. This can optimize the statistical power of the trial.

### The Golden Ratio in Receptor Binding

Many biological receptors have binding sites with golden-ratio-based proportions. When a drug molecule fits into a binding site, its shape should match the shape of the site. If the binding site has golden-ratio-based proportions, the drug molecule should also have golden-ratio-based proportions.

**Key Concept**: Drug molecules with golden-ratio-based proportions may bind more effectively to biological receptors with golden-ratio-based binding sites.

### Worked Example 11.4.1

A clinical trial has a treatment group of 162 patients and a control group of 100 patients. What is the ratio? How close is this to φ?

**Solution**: Ratio = 162/100 = 1.62

φ ≈ 1.618

The ratio is very close to φ. The discrepancy is only 0.1%.

### Practice Problems

1. Research: what is the typical ratio of treatment to control group sizes in clinical trials?
2. How might golden-ratio-based drug design improve drug efficacy?
3. What is rational drug design?
4. Why might biological receptors have golden-ratio-based proportions?
5. What are the limitations of using the golden ratio in drug design?

### Teacher's Notes

**Pharmaceutical Connection**: This lesson connects the golden ratio to pharmaceutical science. This is a practical application that shows the golden ratio has real-world consequences.

**Ethical Note**: Discuss the ethics of clinical trial design. The ratio of treatment to control groups should be chosen based on scientific considerations, not aesthetic preferences.

---

## Lesson 11.5: The Golden Ratio in Traditional Medicine

### Explanation

The golden ratio has been used in traditional medicine systems for centuries:

**1. Traditional Chinese Medicine**

In traditional Chinese Medicine, the body is viewed as a system of energy channels (meridians) with golden-ratio-based proportions. The acupuncture points are located at positions that approximate golden sections of the body.

**2. Ayurvedic Medicine**

In Ayurvedic medicine, the proportions of the body are used to determine the individual's constitution (dosha). The ratios of the three doshas (vata, pitta, kapha) are sometimes related to the golden ratio.

**3. Homeopathy**

In homeopathy, the dilution ratios used in remedy preparation sometimes approximate the golden ratio. For example, a 30C dilution has a ratio of 10⁻⁶⁰ to the original substance, and 60 is close to φ⁸ ≈ 46.98 (not very close), or φ⁹ ≈ 76.01 (also not very close).

**Key Concept**: Traditional medicine systems have used golden-ratio-based proportions for centuries, though the scientific basis for these practices is not fully understood.

### The Golden Ratio in Acupuncture

Acupuncture points are located along meridians (energy channels) that run through the body. The positions of these points often approximate golden sections of the body:

- The point on the forearm is located at approximately 1/φ of the distance from the elbow to the wrist
- The point on the lower leg is located at approximately 1/φ of the distance from the knee to the ankle

**Key Concept**: Acupuncture points may be located at golden sections of the body, though this hypothesis is not universally accepted.

### Worked Example 11.5.1

The distance from the elbow to the wrist is 25 cm. If an acupuncture point is located at 1/φ of this distance from the elbow, what is the distance from the elbow to the point?

**Solution**: Distance = 25/φ ≈ 25/1.618 ≈ 15.45 cm

### Practice Problems

1. Research: where are the major acupuncture points on the forearm?
2. Do the positions of these points approximate golden sections?
3. How does traditional Chinese Medicine view the body?
4. What is the scientific evidence for acupuncture?
5. How might the golden ratio be used in traditional medicine?

### Teacher's Notes

**Cultural Connection**: This lesson connects the golden ratio to traditional medicine systems from different cultures. This shows that the golden ratio has been recognized and used by many different civilizations.

**Critical Thinking**: Encourage students to think critically about the scientific basis for traditional medicine practices. The golden ratio may appear in these practices, but this does not necessarily mean that the practices are effective.

---

## Lesson 11.6: The Golden Ratio in Exercise and Sports Science

### Explanation

The golden ratio appears in exercise science and sports performance.

### The Golden Ratio in Running Strides

The ideal running stride has a ratio of stride length to stride frequency that approximates the golden ratio. Runners who maintain this ratio are more efficient and less prone to injury.

### The Golden Ratio in Weight Training

The ideal ratio of work to rest during weight training approximates the golden ratio. For example, if a set takes 30 seconds, the rest period should be approximately 30 × φ ≈ 49 seconds.

### The Golden Ratio in Swimming

The ideal ratio of stroke length to stroke frequency in swimming approximates the golden ratio. Swimmers who maintain this ratio are more efficient.

### The Golden Ratio in Basketball

The ideal trajectory of a basketball free throw follows a path that approximates a golden spiral. The angle of release and the arc of the ball are related to the golden ratio.

### The Golden Ratio in Gymnastics

The proportions of a gymnast's body often approximate the golden ratio. Gymnasts with golden proportions may have a natural advantage in terms of balance and flexibility.

### Worked Example 11.6.1

A runner has a stride length of 1.5 m and a stride frequency of 2.4 Hz. What is the ratio? How close is this to φ?

**Solution**: Ratio = 2.4/1.5 = 1.6

φ ≈ 1.618

The ratio is close to φ. The discrepancy is about 1.1%.

### Practice Problems

1. Measure your own stride length and frequency. Compute the ratio.
2. Research: what is the ideal work-to-rest ratio in weight training?
3. How does the golden ratio apply to swimming strokes?
4. What is the ideal trajectory for a basketball free throw?
5. How might golden proportions give gymnasts an advantage?

### Teacher's Notes

**Physical Education Connection**: This lesson connects the golden ratio to physical education. It shows that the golden ratio is not just an abstract constant but a practical tool for improving athletic performance.

**Activity**: Have students measure their own stride length and frequency, and compute the ratio. Discuss how they might adjust their running form to approach the golden ratio.

---

## Lesson 11.7: The Golden Ratio in Aging and Longevity

### Explanation

The golden ratio appears in some aspects of aging and longevity research.

### The Golden Ratio and Telomeres

Telomeres are protective caps on the ends of chromosomes. They shorten with each cell division, and their length is related to biological aging.

Some researchers have found that the ratio of telomere length to chromosome length approximates the golden ratio in young cells. As cells age, this ratio changes, which may be related to the aging process.

### The Golden Ratio and the Aging Face

As humans age, the proportions of the face change. The golden ratio can be used to quantify these changes:

- In young faces, the ratio of the upper face to the lower face is close to φ
- As the face ages, this ratio changes, with the lower face becoming relatively larger
- The deviation from the golden ratio may be a quantitative measure of facial aging

### The Golden Ratio and Longevity

Some researchers have proposed that individuals with golden-ratio-based body proportions may have a longevity advantage. The theory is that golden proportions indicate optimal developmental efficiency, which may be correlated with overall health and longevity.

This hypothesis is not well-supported by evidence, but it illustrates the persistent appearance of the golden ratio in biological research.

### The Golden Ratio and Exercise

As discussed in Lesson 11.6, the golden ratio appears in exercise science. Some researchers have proposed that exercising at golden-ratio-based intervals (e.g., work:rest ratio of 1:φ) may be optimal for health and longevity.

### Worked Example 11.7.1

A young face has upper face height 6 cm and lower face height 9.7 cm. What is the ratio? How close is this to φ?

**Solution**: Ratio = 9.7/6 = 1.617

φ ≈ 1.618

The ratio is very close to φ. The discrepancy is only 0.06%.

### Practice Problems

1. Measure the upper and lower face heights of a young person. Compute the ratio.
2. Measure the same ratios for an older person. How do they differ?
3. What are telomeres? How do they relate to aging?
4. Is there evidence that golden proportions relate to longevity?
5. How might exercise at golden-ratio intervals affect health?

### Teacher's Notes

**Health Connection**: This lesson connects the golden ratio to health and aging. This is a practical application that shows the golden ratio has implications for human health.

**Caution**: Emphasize that the connections between the golden ratio and aging are speculative. The golden ratio is not a medical diagnostic tool.

---

## Summary of Chapter 11

### Key Concepts

1. The **DNA double helix** has dimensions that approximate the golden ratio.
2. **Brain wave frequencies** are organized in a hierarchy with ratios approximating the golden ratio.
3. The golden ratio appears in **medical imaging**, including liver, heart, and dental proportions.
4. **Drug design** and **clinical trial** ratios sometimes approximate the golden ratio.
5. **Traditional medicine** systems have used golden-ratio-based proportions for centuries.
6. Many of the connections between the golden ratio and biology are approximate, not exact.

### Key Formulas

| Formula | Description |
|---------|-------------|
| DNA: 34 Å / 20 Å ≈ 1.7 ≈ φ | DNA double helix proportions |
| Alpha waves: 13/8 = 1.625 ≈ φ | Brain wave frequency ratios |
| Liver: length/width ≈ φ | Organ proportions |
| Drug dosing: max/min ≈ φ | Pharmaceutical ratios |

### Connections to Other Chapters

- **Chapter 1 (Golden Ratio)**: The golden ratio underlies all the biological structures in this chapter.
- **Chapter 8 (Living Mathematics)**: Phyllotaxis and body proportions are related to the molecular and medical applications in this chapter.
- **Chapter 12 (Phi-Economics and Phi-CS)**: The golden ratio appears in human-generated systems, just as it appears in biological systems.

---

**End of Chapter 11**

*Next: Chapter 12 — Phi-Economics and Phi-Computer Science*
