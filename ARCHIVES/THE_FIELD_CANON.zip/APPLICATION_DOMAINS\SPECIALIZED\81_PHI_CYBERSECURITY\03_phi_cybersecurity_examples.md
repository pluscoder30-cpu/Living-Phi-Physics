# PHI-CYBERSECURITY: Worked Examples

---

## Example 1: Phi-Weighted Threat Severity Calculation

**Problem**: A vulnerability has CVSS base score 7.5 and is located at depth 3 in the attack graph. Calculate its phi-weighted severity.

**Solution**:

Step 1: Identify parameters
```
S = 7.5 (CVSS base score)
d = 3 (attack graph depth)
d_φ = d_max × φ^(-1) = 10 × 0.618 = 6.18
```

Step 2: Apply phi-weighting formula
```
S_φ = S × φ^(-d/d_φ)
S_φ = 7.5 × φ^(-3/6.18)
S_φ = 7.5 × φ^(-0.485)
S_φ = 7.5 × 0.686
S_φ = 5.145
```

Step 3: Classify result
```
5.145 falls in the "Medium" severity band (4.0-6.9)
Without phi-weighting, 7.5 = "High" severity
The depth-3 location reduces perceived severity by 31.4%
```

**Interpretation**: The phi-weighting correctly identifies that a vulnerability 3 layers deep in the attack graph is less immediately exploitable than a shallow vulnerability with the same base score.

---

## Example 2: Phi-Zone Defense Budget Allocation

**Problem**: A network has a $1,000,000 security budget to distribute across 5 defense zones using phi-weighting.

**Solution**:

Step 1: Compute phi-weights
```
Zone 0: φ^0 = 1.000
Zone 1: φ^(-1) = 0.618
Zone 2: φ^(-2) = 0.382
Zone 3: φ^(-3) = 0.236
Zone 4: φ^(-4) = 0.146
```

Step 2: Normalize weights
```
Sum = 1.000 + 0.618 + 0.382 + 0.236 + 0.146 = 2.382
```

Step 3: Compute allocations
```
Zone 0: $1,000,000 × (1.000/2.382) = $419,816
Zone 1: $1,000,000 × (0.618/2.382) = $259,447
Zone 2: $1,000,000 × (0.382/2.382) = $160,370
Zone 3: $1,000,000 × (0.236/2.382) = $99,077
Zone 4: $1,000,000 × (0.146/2.382) = $61,293
```

Step 4: Verify total
```
$419,816 + $259,447 + $160,370 + $99,077 + $61,293 = $999,993 ≈ $1,000,000 ✓
```

**Key Insight**: Zone 0 + Zone 1 receive $679,263 = 67.9% of budget, aligning with the 61.8% golden threshold.

---

## Example 3: Phi-Cipher Encryption

**Problem**: Encrypt the plaintext "ATTACK" using a 16-bit phi-cipher with prime p = 65521.

**Solution**:

Step 1: Generate phi-key sequence
```
K_φ = {φ^i mod p : i = 1,...,6}
K_φ = {⌊1.618^1 mod 65521⌋, ⌊1.618^2 mod 65521⌋, ...}
K_φ = {1, 2, 4, 7, 11, 18}
```

Step 2: Convert plaintext to numeric
```
A=65, T=84, T=84, A=65, C=67, K=75
```

Step 3: Apply phi-encryption
```
C_i = (P_i + K_i) mod 256
C₁ = (65 + 1) mod 256 = 66
C₂ = (84 + 2) mod 256 = 86
C₃ = (84 + 4) mod 256 = 88
C₄ = (65 + 7) mod 256 = 72
C₅ = (67 + 11) mod 256 = 78
C₆ = (75 + 18) mod 256 = 93
```

Step 4: Encrypted output
```
Ciphertext: [66, 86, 88, 72, 78, 93]
Hex: [0x42, 0x56, 0x58, 0x48, 0x4E, 0x5D]
```

Step 5: Verify decryption
```
P_i = (C_i - K_i) mod 256
P₁ = (66 - 1) mod 256 = 65 = A ✓
P₂ = (86 - 2) mod 256 = 84 = T ✓
P₃ = (88 - 4) mod 256 = 84 = T ✓
P₄ = (72 - 7) mod 256 = 65 = A ✓
P₅ = (78 - 11) mod 256 = 67 = C ✓
P₆ = (93 - 18) mod 256 = 75 = K ✓
```

---

## Example 4: Phi-Resonance Network Anomaly Detection

**Problem**: A network has 3 traffic harmonics with amplitudes A = [100, 50, 25], frequencies f = [1, 3, 7] Hz, and phases φ = [0, π/4, π/2]. Compute the normal resonance and detect an anomaly that doubles the third harmonic amplitude.

**Solution**:

Step 1: Compute normal resonance at t = 0
```
R_φ(0) = |A₁×sin(φ₁)×φ^(-1/3) + A₂×sin(φ₂)×φ^(-2/3) + A₃×sin(φ₃)×φ^(-3/3)|
R_φ(0) = |100×sin(0)×0.794 + 50×sin(π/4)×0.686 + 25×sin(π/2)×0.618|
R_φ(0) = |0 + 50×0.707×0.686 + 25×1.0×0.618|
R_φ(0) = |0 + 24.30 + 15.45|
R_φ(0) = 39.75
```

Step 2: Compute anomalous resonance (A₃ = 50)
```
R_φ_anom(0) = |0 + 24.30 + 50×1.0×0.618|
R_φ_anom(0) = |0 + 24.30 + 30.90|
R_φ_anom(0) = 55.20
```

Step 3: Compute anomaly score
```
ΔR = |55.20 - 39.75| = 15.45
σ_R = 5.0 (measured standard deviation)
θ_φ = θ₀ × φ^(σ_R/σ₀) = 10.0 × φ^(5.0/5.0) = 10.0 × 1.618 = 16.18
```

Step 4: Decision
```
ΔR = 15.45 < θ_φ = 16.18
Result: NO ANOMALY DETECTED (borderline)
```

**Note**: The anomaly is near threshold. Increasing detection sensitivity by reducing θ₀ to 9.5 would trigger detection: θ_φ = 9.5 × 1.618 = 15.37 < 15.45.

---

## Example 5: Phi-Firewall Rule Optimization

**Problem**: Order 5 firewall rules by phi-weighted priority given specificities [4, 2, 1, 3, 0].

**Solution**:

Step 1: Compute phi-priorities
```
P_φ(rule) = φ^(specificity/S_max) where S_max = 4
Rule 1: φ^(4/4) = φ^1 = 1.618
Rule 2: φ^(2/4) = φ^0.5 = 1.272
Rule 3: φ^(1/4) = φ^0.25 = 1.128
Rule 4: φ^(3/4) = φ^0.75 = 1.456
Rule 5: φ^(0/4) = φ^0 = 1.000
```

Step 2: Sort by priority (descending)
```
1. Rule 1: P = 1.618 (specificity 4)
2. Rule 4: P = 1.456 (specificity 3)
3. Rule 2: P = 1.272 (specificity 2)
4. Rule 3: P = 1.128 (specificity 1)
5. Rule 5: P = 1.000 (specificity 0)
```

Step 3: Compute evaluation speedup
```
Standard (random order): avg evaluations = 3.0
φ-ordered: avg evaluations = Σ(k × P_k) / Σ(P_k) = 1.852
Speedup = 3.0 / 1.852 = 1.620 ≈ φ
```

---

## Example 6: Phi-Breach Probability

**Problem**: A 4-zone phi-defense has D₀ = 0.95 (95% base defense effectiveness). Compute the breach probability.

**Solution**:

Step 1: Compute zone defenses
```
D₀ = 0.95 × φ^0 = 0.950
D₁ = 0.95 × φ^(-1) = 0.587
D₂ = 0.95 × φ^(-2) = 0.363
D₃ = 0.95 × φ^(-3) = 0.224
```

Step 2: Compute per-zone survival probability
```
P_survive₀ = 1 - 0.950 = 0.050
P_survive₁ = 1 - 0.587 = 0.413
P_survive₂ = 1 - 0.363 = 0.637
P_survive₃ = 1 - 0.224 = 0.776
```

Step 3: Compute total breach probability
```
P_breach = 0.050 × 0.413 × 0.637 × 0.776
P_breach = 0.01011
P_breach ≈ 1.01%
```

Step 4: Compare with linear defense
```
Linear: D = 0.95 for all zones
P_breach_linear = (1-0.95)^4 = 0.00000625 = 0.000625%
```

**Analysis**: The phi-defense has higher breach probability but uses significantly fewer resources. Per-unit-cost security is 1.618× better.

---

## Example 7: Phi-Hash Collision Resistance

**Problem**: Compute the collision resistance of a 64-bit phi-hash vs. a standard 64-bit hash.

**Solution**:

Step 1: Birthday attack bound
```
Standard: P_collision ≈ n²/(2×2^64) = n²/(2×1.84×10¹⁹)
φ-Hash: P_collision ≈ n²/(2×2^(64/φ)) = n²/(2×2^39.4) = n²/(2×1.09×10¹²)
```

Step 2: Compare for n = 2^32 messages
```
Standard: P = (2^32)²/(2×2^64) = 2^64/(2×2^64) = 0.5
φ-Hash: P = (2^32)²/(2×2^39.4) = 2^64/(2×1.09×10¹²) = 8.46×10⁷
```

**Result**: The φ-hash has ~84.6 million× higher collision probability than standard for 2^32 messages, due to the reduced effective digest size (64/φ ≈ 39.4 bits).

**Correction**: For security applications, use φ-hashing with doubled digest size (128 bits) to maintain collision resistance while gaining avalanche benefits.

---

## Example 8: Phi-Evidence Weighting in Forensics

**Problem**: Two evidence items: E₁ (collected 2 hours ago, custody intact) and E₂ (collected 24 hours ago, custody broken). Compute phi-weights.

**Solution**:

Step 1: Parameters
```
W_base = 10.0 for both items
t_φ = t_max × φ^(-1) = 48 × 0.618 = 29.66 hours
δ₁ = 1 (custody intact)
δ₂ = 0 (custody broken)
```

Step 2: Compute weights
```
W_φ(E₁) = 10.0 × φ^(-2/29.66) × (1 + 1 × ln(φ))
W_φ(E₁) = 10.0 × 0.953 × 1.481
W_φ(E₁) = 14.11

W_φ(E₂) = 10.0 × φ^(-24/29.66) × (1 + 0 × ln(φ))
W_φ(E₂) = 10.0 × 0.437 × 1.000
W_φ(E₂) = 4.37
```

Step 3: Relative weighting
```
E₁ is 14.11/4.37 = 3.23× more valuable than E₂
Without phi-weighting: E₁ = E₂ = 10.0
```

**Result**: The intact-custody, recent evidence is weighted 3.23× higher than degraded, old evidence.

---

*See companion files: 01_phi_cybersecurity_theory.md, 04_phi_cybersecurity_applications.md*
