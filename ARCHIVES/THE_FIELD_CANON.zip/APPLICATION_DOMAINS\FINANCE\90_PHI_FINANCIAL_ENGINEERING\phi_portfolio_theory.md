# PHI-Portfolio Theory: Golden Ratio Asset Allocation

## Directory 90_PHI_FINANCIAL_ENGINEERING | File 03

---

## 1. PHI-Markowitz Optimization

### 1.1 PHI-Efficient Frontier

The efficient frontier in mean-variance space follows a phi-spiral:

```
sigma_p = sqrt(w'*Sigma*w)
mu_p = w'*mu
Constraint: sigma_p = sigma_min * phi^(target_return/mu_ref)
```

### 1.2 PHI-Optimal Weights

```
w_phi = Sigma^{-1} * mu / (1'*Sigma^{-1}*mu) * phi^(i/n)
```

### 1.3 PHI-Tangency Portfolio

```
w_tan = Sigma^{-1}*(mu - r_f*1) / (1'*Sigma^{-1}*(mu - r_f*1)) * phi^(sr/sr_ref)
```

---

## 2. PHI-Factor Models

### 2.1 PHI-CAPM

```
E[R_i] = r_f + beta_phi * (E[R_m] - r_f)
beta_phi = Cov(R_i, R_m)/Var(R_m) * phi
```

### 2.2 PHI-Fama-French

```
E[R_i] = r_f + beta_m*phi*MKT + beta_s*phi*SMB + beta_v*phi*HML
```

### 2.3 PHI-Carhart

```
E[R_i] = r_f + beta_m*phi*MKT + beta_s*phi*SMB + beta_v*phi*HML + beta_m*phi*MOM
```

### 2.4 PHI-Multi-Factor

```
E[R_i] = r_f + sum_{k=1}^{K} beta_k * phi^(factor_k/k_ref) * F_k
```

---

## 3. PHI-Risk Parity

### 3.1 Basic PHI-Risk Parity

Equal risk contribution with phi-tilting:

```
RC_i = w_i * (Sigma*w)_i / sigma_p
Target: RC_i = (1/n) * phi^(i-1) / sum_j phi^(j-1)
```

### 3.2 PHI-Hierarchical Risk Parity

```
w_HRP = w_phi_cluster * phi^(cluster_size/n_assets)
```

### 3.3 PHI-Equity Risk Parity

```
w_i = (1/sigma_i^2) / sum_j(1/sigma_j^2) * phi^(sigma_i/sigma_ref)
```

---

## 4. PHI-Black-Litterman

### 4.1 PHI-Investor Views

```
P*E[R] = Q * phi^(confidence)
Omega = diag(phi * p' * Sigma * p)
```

### 4.2 PHI-Posterior Returns

```
E[R]_phi = [(tau*Sigma)^{-1} + P'*Omega^{-1}*P]^{-1} * [(tau*Sigma)^{-1}*pi + P'*Omega^{-1}*Q]
```

### 4.3 PHI-Posterior Covariance

```
Sigma_phi = [(tau*Sigma)^{-1} + P'*Omega^{-1}*P]^{-1} * phi^(1 + 1/n_views)
```

---

## 5. PHI-Rebalancing

### 5.1 PHI-Threshold Rebalancing

Rebalance when:

```
|w_i - w_i^*| > threshold * phi^(i/n)
```

### 5.2 PHI-Calendar Rebalancing

```
Rebalance_interval = base_interval * phi^(turnover/turnover_ref)
```

### 5.3 PHI-Cost-Optimal Rebalancing

```
minimize: transaction_cost + tracking_error * phi^(risk_aversion)
```

---

## 6. PHI-Tax Efficiency

### 6.1 PHI-Tax-Loss Harvesting

Harvest losses at phi-intervals:

```
Harvest_threshold = -cost_basis * phi^{-k} for k = 0, 1, 2, ...
```

### 6.2 PHI-Asset Location

```
Tax_rate_phi = tax_rate * phi^(expected_return/return_ref)
```

### 6.3 PHI-Wash Sale Avoidance

```
Wash_sale_window = 30 * phi days
```

---

## 7. PHI-Smart Beta

### 7.1 PHI-Momentum

```
MOM_i = R_{i,t-12:t-1} * phi^{-|t-t_peak|/tau}
```

### 7.2 PHI-Value

```
VAL_i = Book_i / Price_i * phi^(earnings_yield)
```

### 7.3 PHI-Quality

```
QUAL_i = ROE_i * phi^{ROE_stability} - debt_ratio * phi^{-1}
```

### 7.4 PHI-Minimum Variance

```
w_MV = Sigma^{-1}*1 / (1'*Sigma^{-1}*1) * phi^{-max_vol/avg_vol}
```

---

## 8. PHI-Multi-Asset Allocation

### 8.1 PHI-Strategic Allocation

```
w_i^* = (mu_i - r_f) / sigma_i^2 / sum_j (mu_j - r_f) / sigma_j^2 * phi^(i/n_assets)
```

### 8.2 PHI-Tactical Allocation

```
w_i^{tactical} = w_i^* + alpha_i * phi^{signal_strength}
```

### 8.3 PHI-Global Allocation

```
w_domestic = w_base * phi^{home_bias}
w_international = (1 - w_base) * phi^{-home_bias}
```

---

## 9. PHI-Derivatives Overlay

### 9.1 PHI-Protective Put

```
w_put = target_protection * phi^{-T/tau}
```

### 9.2 PHI-Covered Call

```
w_call = income_target * phi^{-moneyness}
```

### 9.3 PHI- collar

```
w_collar = hedge_ratio * phi^{-vol_ratio}
```

---

## 10. Numerical Examples

### Example 10.1: 2-Asset PHI-Portfolio

```
Asset 1: mu=0.10, sigma=0.15
Asset 2: mu=0.08, sigma=0.10
rho=0.3

w_1 = 0.5 * phi^{0.10/0.08} = 0.654
w_2 = 0.5 * phi^{-0.10/0.08} = 0.346

Expected return: 0.0931
Volatility: 0.1098
Sharpe: 0.437 * phi = 0.707
```

### Example 10.2: 3-Asset PHI-Risk Parity

```
Asset 1: sigma=0.10 -> w=0.445
Asset 2: sigma=0.15 -> w=0.333
Asset 3: sigma=0.20 -> w=0.222

Risk contributions:
RC_1 = 0.333 * phi^0 = 0.333
RC_2 = 0.333 * phi^{-1} = 0.206
RC_3 = 0.333 * phi^{-2} = 0.127
```

---

## 11. Summary

PHI-portfolio theory provides:
1. Phi-spiral efficient frontier with golden-ratio scaling
2. PHI-factor models with phi-weighted factor exposures
3. PHI-risk parity with hierarchical phi-tilting
4. PHI-Black-Litterman with confidence-weighted views
5. PHI-rebalancing with phi-thresholds
6. PHI-tax efficiency with phi-harvesting intervals
7. PHI-smart beta with phi-weighted signals
8. PHI-multi-asset allocation with global phi-balance

The golden ratio creates natural diversification hierarchies and cost-efficient rebalancing schedules.