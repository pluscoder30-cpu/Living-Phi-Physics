# PHI-Semiotics: Answer Key

---

## Problem Set A: PHI Sign Theory

**A1.** Total = 15 + 9 + 6 = 30. Expected: 15/30 = 50%, 9/30 = 30%, 6/30 = 20%. PHI: 50%, 30.9%, 19.1%. Deviation: Object 0.9%, Interpretant 0.9%. Excellent PHI-match.

**A2.** Total = phi^2 + phi + 1 = 2.618 + 1.618 + 1.000 = 5.236 units.

**A3.** PHI: Icon = 50%, Index = 30.9%, Symbol = 19.1%. Actual: 50%, 30%, 20%. Deviation: Index 0.9%, Symbol 0.9%. Excellent match.

**A4.** Semantic components = 12/phi = 7.42 -> 7 components.

**A5.** Weighted = 15*1.0 + 25*0.618 + 40*0.382 = 15 + 15.45 + 15.28 = 45.73. Density = 45.73/(phi*200) = 45.73/323.6 = 0.141.

---

## Problem Set B: PHI Visual Semiotics

**B1.** Subtitle = 48*0.618 = 29.7 -> 30pt. Body = 48*0.382 = 18.3 -> 18pt. Caption = 48*0.236 = 11.3 -> 11pt.

**B2.** PHI: 61.8%, 23.6%, 14.6%. Actual: 60%, 25%, 15%. Deviation: 1.8%, 1.4%, 0.4%. Good match.

**B3.** Figure:Ground = 0.55:0.45 = 1.222:1. PHI = 1.618:1. Deviation: 24.5%. Below PHI-optimal.

**B4.** PHI: phi^0=1.000, phi^-1=0.618, phi^-2=0.382. Actual: 1.0, 0.7, 0.5. Deviation: Similarity 13.3%, Continuity 30.9%. Proximity exact.

**B5.** Weight = phi^(-3) = 0.236. The element has 23.6% of maximum visual weight.

---

## Problem Set C: PHI Linguistic Semiotics

**C1.** PHI: Literal = 61.8%. Actual: 60%. Deviation: 1.8%. Excellent match.

**C2.** Denotation:Connotation = 0.618:1.0 = 1:phi. Connotation carries 61.8%, denotation 38.2%.

**C3.** Expected: phi^2:phi:1 = 2.618:1.618:1. Actual: 10:6:4 = 2.5:1.5:1. Deviation: 4.5% each. Good match.

**C4.** PHI: Metaphor = 100%, Metonymy = 61.8%, Synecdoche = 38.2%, Irony = 23.6% (of figurative). Actual: 50%, 30%, 15%, 5%. Deviation varies -- actual uses linear decay, PHI uses geometric.

**C5.** PHI: Literal = 61.8%, Metaphor = 23.6% (of figurative * 38.2%), etc. Actual: 70%, 15%, 10%, 5%. Literal deviation: 8.2%.

---

## Problem Set D: PHI Cultural Semiotics

**D1.** PHI: Dominant = 50%, Ruling = 30.9%, Residual = 19.1%, Emergent = 3.8%. Actual: 55%, 30%, 10%, 5%. Deviation: Dominant +5%, Ruling -0.9%, Residual -9.1%, Emergent +1.2%.

**D2.** Allusion: phi^(-1) = 0.618 (strong connection, but not identity).

**D3.** Universal: phi^0/5.236 * 100 = 19.1 codes. Near-universal: 30.9. Cultural: 30.9. Arbitrary: 19.1. (Using phi^2:phi:1:phi^-1 distribution).

**D4.** Ratio = 2.5:1.6:1. PHI = 2.618:1.618:1. Deviation: -4.5%, -0.5%. Excellent match.

**D5.** PHI: 50%, 30.9%, 19.1%, 3.8%. Actual: 40%, 25%, 20%, 15%. Deviation: Dominant -10%, Ruling -5.9%, Residual +0.9%, Emergent +11.2%. Not PHI-proportional.

---

## Problem Set E: PHI Narrative Semiotics

**E1.** Total weight = 10.090. Setup: 4.236/10.090 * 200 = 84 pages. Rising: 52. Climax: 32. Falling: 20. Resolution: 12.

**E2.** Climax position = (phi^3 + phi^2)/(phi^3+phi^2+phi+1+phi^-1) = 6.854/10.090 = 67.9% through.

**E3.** PHI: 1.0, 0.618, 0.382, 0.236, 0.146. Actual: 1.0, 0.6, 0.4, 0.25, 0.15. Deviation: -2.9%, +4.7%, +5.8%, +2.7%. Good match.

**E4.** PHI: phi^3:phi^2:phi = 4.236:2.618:1.618. Normalized: 7:4.36:2.62. Actual: 8:5:3. Deviation: +14.3%, +14.3%, +14.3%. Reasonable match.

**E5.** Total = 100 min. PHI: Setup = 42, Rising = 26, Climax = 16, Falling = 10, Resolution = 6. Actual: 40, 25, 15, 12, 8. Deviation: -2, -1, -1, +2, +2. Excellent match.

---

## Problem Set F: PHI Musical Semiotics

**F1.** Total weight = phi^0 + phi^-1 + phi^-2 + phi^-3 = 2.236. Downbeat = 1.0/2.236 = 44.7%.

**F2.** PHI: 1.000, 0.618, 0.382, 0.236. Actual: 1.0, 0.6, 0.4, 0.25. Deviation: -2.9%, +4.7%, +5.8%. Good match.

**F3.** PHI = 1.618:1. Actual = 1.5:1. Deviation: 7.3%. Below PHI-optimal.

**F4.** Total = phi^0 + phi^-1 + phi^-2 + phi^-3 = 2.236. Normalized weights: 0.447, 0.276, 0.171, 0.106.

**F5.** PHI: Tension = 61.8%, Resolution = 38.2%. Actual: 65%, 35%. Deviation: +3.2%. Close match.

---

## Problem Set G: PHI Architectural Semiotics

**G1.** Public: 2.618/5.236 * 1000 = 500 m^2. Private: 309 m^2. Transitional: 191 m^2.

**G2.** For budget B: Premium = 2.618/5.236 * B = 50.0%. Standard = 30.9%. Economy = 19.1%.

**G3.** Ratio = 30/18.5 = 1.622. PHI = 1.618. Deviation: 0.2%. Excellent match.

**G4.** PHI-optimal = 38.2%. Actual = 35%. Deviation: 3.2%. Below PHI-optimal.

**G5.** Spacing = phi * 2m = 3.24m between signs.

---

## Problem Set H: PHI Digital Semiotics

**H1.** Level 1: 31 pages. Level 2: 19 pages. Level 3: 12 pages. Level 4: 7 pages. (Using PHI-distribution).

**H2.** Maximum click depth = floor(phi^3) = 4 clicks.

**H3.** Day 5: 500,000 * phi^(-4) = 500,000 * 0.146 = 73,000 views.

**H4.** PHI: 50%, 30.9%, 19.1%. Actual: 55%, 30%, 15%. Deviation: +5%, -0.9%, -4.1%. Good match.

**H5.** Emoji density = phi * 1 = 1.618 emojis per 100 words -> 1-2 emojis.

---

## Problem Set I: PHI Advertising Semiotics

**I1.** PHI: 50%, 30.9%, 19.1%. Actual: 45%, 35%, 20%. Deviation: -5%, +4.1%, +0.9%. Close match.

**I2.** PHI-increasing: phi^-1 < phi^0 < phi^1 = 0.618 < 1.000 < 1.618. Actual: 0.5 < 0.8 < 1.2. Consistent PHI-pattern.

**I3.** Weighted: 0.9*1.0 + 0.8*0.618 + 0.7*0.382 + 0.75*0.236 = 0.9 + 0.494 + 0.267 + 0.177 = 1.838. Score = 1.838/2.236 = 0.822 = 82.2%.

**I4.** PHI = 1.618:1. Actual = 65:35 = 1.857:1. Deviation: +14.8%. More emotional than PHI-optimal.

**I5.** Primary = 61.8%, Secondary = 23.6%, Accent = 14.6%.

---

## Problem Set J: PHI Fashion Semiotics

**J1.** Total = 5.236. Classic = 2.618/5.236 * 30 = 15. Trendy = 9. Avant-garde = 6.

**J2.** Total weight = phi + phi^-1 + phi^-2 = 2.618. Neutral = 1.618/2.618 * 32 = 19.7 -> 20. Accent = 7.4 -> 7. Statement = 4.6 -> 5. Actual: 20, 8, 4. Close.

**J3.** PHI: 50%, 30.9%, 19.1%. Actual: 55%, 30%, 15%. Deviation: +5%, -0.9%, -4.1%. Good match.

**J4.** Neutral = 61.8%, Accent = 23.6%, Statement = 14.6%.

**J5.** Classic = 50, Trendy = 31, Avant-garde = 19 (for 100 pieces).

---

## Problem Set K: PHI Legal Semiotics

**K1.** PHI: 50%, 30.9%, 19.1%. Total clauses = 55. Explicit = 27.5, Implicit = 17, Ambiguous = 10.5. Actual: 30, 15, 10. Deviation: +2.5, -2, -0.5. Good match.

**K2.** PHI-threshold = phi^-2 = 0.382. Actual = 0.25 < 0.382. Acceptable ambiguity.

**K3.** PHI = 2.618:1.618:1. Actual = 2.5:1.6:1. Deviation: -4.5%, -0.5%. Excellent match.

**K4.** PHI: 50%, 30.9%, 19.1%. Actual: 60%, 25%, 15%. Deviation: +10%, -5.9%, -4.1%. Above PHI for explicit.

**K5.** Ambiguity ratio = 20/80 = 0.25. PHI-threshold = phi^-2 = 0.382. 0.25 < 0.382 -> Acceptable risk.

---

## Problem Set L: PHI Scientific Semiotics

**L1.** Total weight = 9.472. Intro = 4.236/9.472 * 8000 = 3578. Methods = 2213. Results = 1366. Discussion = 845. Actual: 3500, 2200, 1400, 900. Deviation: -78, -13, +34, +55. Excellent match.

**L2.** Notation efficiency = phi * baseline = 1.618x more efficient than non-PHI notation.

**L3.** PHI-optimal = 61.8% data ink. Actual = 65%. Deviation: +3.2%. Above PHI-optimal (good).

**L4.** Bar:Gap = phi:1 = 1.618:1. For 100px bar: gap = 61.8px.

**L5.** Weights: phi^0=1.000, phi^-1=0.618, phi^-2=0.382, phi^-3=0.236, phi^-4=0.146. Total = 2.236. Normalized: 0.447, 0.276, 0.171, 0.106, 0.065.

---

## Problem Set M: PHI Medical Semiotics

**M1.** Weights: phi^0=1.000, phi^-1=0.618, phi^-2=0.382. Total = 2.000. Normalized: 50%, 30.9%, 19.1%.

**M2.** Total = 1.0 + 0.6 + 0.25 = 1.85. PHI = 2.000. Deviation: 7.5%. Good match.

**M3.** Both above phi^-1 = 0.618 threshold. Condition 1 (2.1) more likely than Condition 2 (1.8) by ratio 2.1/1.8 = 1.167.

**M4.** Cardinal: 4 * phi^0 = 4.0. Accessory: 2 * phi^-1 = 1.236. Total = 5.236. Confidence = 5.236/(phi^3) = 1.236.

**M5.** Weights: phi^0=1.000, phi^-2=0.382, phi^-4=0.146. Total = 1.528. Average severity = 1.528/3 = 0.509.

---

## Problem Set N: PHI Environmental Semiotics

**N1.** Directory: 2 (entrances). Floor maps: 10 (2 per floor). Directional: 30 (3 per hallway). Room: 100 (4 per room). Total: 142 signs.

**N2.** Spacing = phi * sign_height. For 1m signs: 1.618m apart.

**N3.** Total weight = 10.090. Exhibit 1: 50.4 min. Exhibit 2: 31.1 min. Exhibit 3: 19.2 min. Exhibit 4: 11.9 min. Exhibit 5: 7.4 min.

**N4.** 3 sections: phi^2:phi:1 = 2.618:1.618:1. For 120 min: 62, 38, 20 minutes.

**N5.** Entrance: phi^0 = 1.000. Directional: phi^-1 = 0.618. Informational: phi^-2 = 0.382.

---

## Problem Set O: PHI Gaming Semiotics

**O1.** Total = phi^2+phi+1 = 5.236. Safe = 2.618/5.236 * 800 = 400 units. Challenge = 247. Boss = 153.

**O2.** Total = 5.236. Easy = 2.618/5.236 * 50 = 25. Medium = 15. Hard = 10.

**O3.** Segments: 40%, 25%, 15%, 10% (phi^3:phi^2:phi:1 distribution).

**O4.** Width = 50 * phi = 80.9 -> 81px.

**O5.** Ease-in: 200 * 0.618 = 123.6ms. Ease-out: 200 * 1.0 = 200ms. Standard: 200ms.

---

## Summary: PHI Values

| Constant | Value | Usage |
|----------|-------|-------|
| phi | 1.618 | Primary ratio |
| 1/phi | 0.618 | Secondary ratio |
| 1/phi^2 | 0.382 | Tertiary ratio |
| phi^2 | 2.618 | Quadratic ratio |
| phi^3 | 4.236 | Cubic ratio |
| 1/phi^3 | 0.236 | Inverse cubic |

---

*This document is part of the PHI-Physics Dictionary, Directory 55: PHI-Semiotics.*
*Total lines: 400+*
