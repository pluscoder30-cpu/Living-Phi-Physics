# Chapter 2: The Silver Ratio

## The Second Metallic Ratio

---

### Overview

The silver ratio, denoted by δ (delta) or sometimes by S, is the second member of the **metallic ratio** family. Just as the golden ratio is defined by the equation φ² = φ + 1, the silver ratio is defined by the equation δ² = 2δ + 1.

The silver ratio is approximately 2.4142135623..., and it appears in geometry, architecture, and the study of paper sizes. It is less famous than the golden ratio, but it is equally beautiful and equally important.

---

## Lesson 2.1: Definition of the Silver Ratio

### Explanation

The **silver ratio** is defined as the positive solution of the equation:

δ² = 2δ + 1

This can be rewritten as:

δ² - 2δ - 1 = 0

Using the quadratic formula:

δ = (2 + √(4 + 4)) / 2 = (2 + √8) / 2 = (2 + 2√2) / 2 = 1 + √2

So:

δ = 1 + √2 ≈ 2.4142135623...

The other solution is 1 - √2 ≈ -0.414..., which is negative and is discarded.

**Key Concept**: The silver ratio is δ = 1 + √2 ≈ 2.4142135623...

### The Metallic Ratio Family

The golden ratio and silver ratio are both members of the **metallic ratio** family. The nth metallic ratio, denoted M(n), is defined as the positive solution of:

x² = nx + 1

or equivalently:

x² - nx - 1 = 0

Using the quadratic formula:

M(n) = (n + √(n² + 4)) / 2

The first few metallic ratios are:

| n | Name | Formula | Approximate Value |
|---|------|---------|-------------------|
| 1 | Golden ratio | (1 + √5)/2 | 1.6180339887... |
| 2 | Silver ratio | (2 + √8)/2 = 1 + √2 | 2.4142135623... |
| 3 | Bronze ratio | (3 + √13)/2 | 3.3027756377... |
| 4 | Copper ratio | (4 + √20)/2 = 2 + √5 | 4.2360679774... |
| 5 | Nickel ratio | (5 + √29)/2 | 5.1925824035... |

**Key Concept**: All metallic ratios satisfy the equation M(n)² = n × M(n) + 1. The golden ratio has n = 1; the silver ratio has n = 2.

### Worked Example 2.1.1

Verify that δ = 1 + √2 satisfies the equation δ² = 2δ + 1.

**Solution**: 
δ² = (1 + √2)² = 1 + 2√2 + 2 = 3 + 2√2
2δ + 1 = 2(1 + √2) + 1 = 2 + 2√2 + 1 = 3 + 2√2

Since both sides equal 3 + 2√2, the equation is satisfied. ✓

### Worked Example 2.1.2

Compute the bronze ratio and verify it satisfies the equation x² = 3x + 1.

**Solution**: 
Bronze ratio = (3 + √13)/2 ≈ (3 + 3.6055512754)/2 ≈ 6.6055512754/2 ≈ 3.3027756377

Check: (3.3027756377)² ≈ 10.908326...
3 × 3.3027756377 + 1 ≈ 9.908326... + 1 = 10.908326...

Since both sides are approximately equal, the equation is satisfied. ✓

### Practice Problems

1. Compute δ = 1 + √2 to six decimal places.
2. Verify that δ² = 2δ + 1 by computing both sides numerically.
3. Compute the copper ratio (n = 4) to six decimal places.
4. Compute the nickel ratio (n = 5) to six decimal places.
5. What is the limit of M(n) as n approaches infinity? Justify your answer.

### Teacher's Notes

**Scaffolding**: If students are not comfortable with the quadratic formula, review it before this lesson. The quadratic formula is x = (-b ± √(b² - 4ac)) / (2a), where ax² + bx + c = 0.

**Extension**: Ask students to prove that M(n) > n for all n ≥ 1. This is a simple but instructive proof.

**Historical Note**: The silver ratio was studied by the ancient Greeks, who called it the "silver ratio" because it is the ratio of the diagonal of a regular octagon to its side, just as the golden ratio is related to the regular pentagon.

---

## Lesson 2.2: The Silver Rectangle

### Explanation

A **silver rectangle** is a rectangle whose length-to-width ratio is the silver ratio δ = 1 + √2 ≈ 2.414.

Just as the golden rectangle has the remarkable property that removing a square leaves another golden rectangle, the silver rectangle has a similar property: removing two squares leaves another silver rectangle.

Let us verify this. Suppose we have a silver rectangle with length L and width W, where L/W = δ. If we remove two W × W squares, the remaining rectangle has length W and width L - 2W.

For this remaining rectangle to also be silver (in the other orientation), we need:

W / (L - 2W) = L / W = δ

This gives us:

W² = L(L - 2W)

W² = L² - 2LW

Rearranging:

L² - 2LW - W² = 0

Dividing by W²:

(L/W)² - 2(L/W) - 1 = 0

Let δ = L/W. Then:

δ² - 2δ - 1 = 0

This is the silver ratio equation! So the property holds.

**Key Concept**: Removing two squares from a silver rectangle leaves another silver rectangle.

### Constructing a Silver Rectangle

1. Start with a square of side s.
2. The silver rectangle has dimensions δs × s = (1 + √2)s × s.
3. To construct this, you need to add √2 × s to one side of the square.
4. √2 × s is the diagonal of an s × s square.

So the construction is:
1. Draw a square of side s.
2. Draw the diagonal of the square. Its length is s√2.
3. Transfer this diagonal to one side of the square using a compass.
4. The resulting rectangle has dimensions (s + s√2) × s = s(1 + √2) × s, which is silver.

### Worked Example 2.2.1

A silver rectangle has width 10 cm. What is its length?

**Solution**: Length = δ × width = 2.4142135623 × 10 = 24.142135623 cm.

### Worked Example 2.2.2

A silver rectangle has width 10 cm. What is the area of the two squares that can be removed from it?

**Solution**: Each square has side 10 cm, so each has area 100 cm². Two squares have total area 200 cm².

The area of the silver rectangle is 10 × 24.142 = 241.42 cm².
The remaining area is 241.42 - 200 = 41.42 cm².
The ratio of remaining area to original area is 41.42/241.42 = 1/δ² ≈ 0.172.

### Practice Problems

1. A silver rectangle has width 8 cm. What is its length? Round to two decimal places.
2. A silver rectangle has length 30 cm. What is its width? Round to two decimal places.
3. Verify that removing two squares from a silver rectangle leaves another silver rectangle (numerically).
4. A silver rectangle has area 200 cm². What are its dimensions?
5. Construct a silver rectangle starting with a 5 cm square. What are the dimensions?

### Teacher's Notes

**Construction Activity**: The construction of a silver rectangle is simpler than the golden rectangle because it only requires the diagonal of a square. Have students construct it and verify the ratio.

**Comparison**: Ask students to compare the golden rectangle and the silver rectangle. Which one is "more elongated"? Why?

**Paper Sizes**: The silver ratio is related to paper sizes. The standard ISO paper size (A4, A3, etc.) has the property that folding it in half preserves the aspect ratio. This property is related to √2, which is closely connected to the silver ratio.

---

## Lesson 2.3: The Silver Spiral

### Explanation

Just as the golden spiral is created by drawing arcs in the squares of a golden rectangle decomposition, the **silver spiral** is created by drawing arcs in the squares of a silver rectangle decomposition.

The silver spiral is a logarithmic spiral with the equation:

r = a × δ^(2θ/π)

where δ = 1 + √2 is the silver ratio. For every quarter turn (θ increases by π/2), the radius increases by a factor of δ.

However, because the silver rectangle requires removing *two* squares at each step (not one), the silver spiral makes two quarter turns between each "zoom" by a factor of δ. This means the silver spiral has a different growth rate than the golden spiral.

The silver spiral is sometimes called the **silver logarithmic spiral** or the **secondary Fibonacci spiral** (because it is related to the Pell sequence, which is the "silver" analogue of the Fibonacci sequence).

### The Pell Sequence

The **Pell sequence** is defined by:

P(0) = 0, P(1) = 1, P(n) = 2P(n-1) + P(n-2) for n ≥ 2

The first few terms are:

0, 1, 2, 5, 12, 29, 70, 169, 408, 985, ...

The ratio of consecutive Pell numbers approaches the silver ratio:

P(2)/P(1) = 2/1 = 2.0000
P(3)/P(2) = 5/2 = 2.5000
P(4)/P(3) = 12/5 = 2.4000
P(5)/P(4) = 29/12 ≈ 2.4167
P(6)/P(5) = 70/29 ≈ 2.4138
P(7)/P(6) = 169/70 ≈ 2.4143
P(8)/P(7) = 408/169 ≈ 2.4142
P(9)/P(8) = 985/408 ≈ 2.4142

The ratios approach δ ≈ 2.4142135623...

**Key Concept**: The Pell sequence is the silver analogue of the Fibonacci sequence, just as the silver ratio is the silver analogue of the golden ratio.

### Worked Example 2.3.1

Compute the first 10 terms of the Pell sequence and verify that the ratios approach the silver ratio.

**Solution**: P(0) = 0, P(1) = 1.
P(2) = 2(1) + 0 = 2
P(3) = 2(2) + 1 = 5
P(4) = 2(5) + 2 = 12
P(5) = 2(12) + 5 = 29
P(6) = 2(29) + 12 = 70
P(7) = 2(70) + 29 = 169
P(8) = 2(169) + 70 = 408
P(9) = 2(408) + 169 = 985

Ratios: 2.000, 2.500, 2.400, 2.417, 2.414, 2.414, 2.414, 2.414

These approach δ ≈ 2.4142135623. ✓

### Practice Problems

1. Compute P(10) and P(11) using the Pell recurrence.
2. Compute P(10)/P(9) and compare it to δ.
3. Compute P(11)/P(10) and compare it to δ.
4. Write out the first 12 terms of the Pell sequence.
5. The Lucas-Pell sequence is defined by L(0) = 2, L(1) = 2, L(n) = 2L(n-1) + L(n-2). Compute the first 8 terms and verify that L(n)/P(n) approaches δ + 1/δ.

### Teacher's Notes

**Analogy**: The relationship between the silver ratio and the Pell sequence is exactly analogous to the relationship between the golden ratio and the Fibonacci sequence. Use this analogy to help students understand both concepts simultaneously.

**Extension**: Ask students to find a Binet-like formula for the Pell sequence using the silver ratio. The formula is:

P(n) = (δⁿ - δ'ⁿ) / (δ - δ')

where δ' = 1 - √2 is the conjugate of δ.

---

## Lesson 2.4: The Silver Spiral in Nature

### Explanation

While the golden spiral is more famous, the silver spiral also appears in nature, though less frequently. The silver spiral is related to the Pell sequence, just as the golden spiral is related to the Fibonacci sequence.

### The Pell Sequence in Nature

The Pell sequence appears in some natural structures:

**1. Shell Growth**

Some shells grow in patterns that approximate the silver spiral rather than the golden spiral. The growth ratio is approximately δ ≈ 2.414 per quarter turn, compared to φ ≈ 1.618 for the golden spiral.

**2. Crystal Structures**

Some crystal structures have silver-ratio-based proportions. The unit cell of these crystals has dimensions related to δ.

**3. Paper Sizes**

As we discussed, the ISO paper size standard uses √2, which is closely related to the silver ratio. This is a human-designed system, but it shows that the silver ratio has practical applications.

### Comparison of Golden and Silver Spirals

The golden spiral and silver spiral have different growth rates:

- Golden spiral: grows by factor φ per quarter turn
- Silver spiral: grows by factor δ per quarter turn

Since δ > φ, the silver spiral grows faster than the golden spiral. After one complete turn (4 quarter turns):

- Golden spiral: φ⁴ ≈ 6.85 times larger
- Silver spiral: δ⁴ ≈ 34.0 times larger

The silver spiral is much more "open" than the golden spiral.

### Worked Example 2.4.1

A golden spiral and a silver spiral both start with radius 1 cm. After two complete turns, what are their radii?

**Solution**: 
Golden spiral: φ⁸ = (φ⁴)² ≈ 6.854² ≈ 46.98 cm
Silver spiral: δ⁸ = (δ⁴)² ≈ 33.97² ≈ 1154 cm

The silver spiral is about 24.6 times larger than the golden spiral after two turns.

### Practice Problems

1. A silver spiral starts with radius 3 cm. What is its radius after one complete turn?
2. A golden spiral starts with radius 3 cm. What is its radius after one complete turn?
3. After how many quarter turns does a silver spiral reach 100 times its original radius?
4. After how many quarter turns does a golden spiral reach 100 times its original radius?
5. Why might nature prefer the golden spiral over the silver spiral?

### Teacher's Notes

**Nature Connection**: The golden spiral is much more common in nature than the silver spiral. This is because the golden ratio is the "most irrational" number, which makes it optimal for packing and spacing. The silver ratio, while beautiful, is not as optimal for natural processes.

---

## Lesson 2.5: The Silver Ratio in Architecture and Design

### Explanation

The silver ratio has been used in architecture and design for centuries, though less explicitly than the golden ratio. Here are some notable examples:

**1. A-Series Paper Sizes**

The ISO 216 standard (A4, A3, A2, etc.) uses the silver ratio. An A4 sheet has dimensions 210 × 297 mm. The ratio 297/210 ≈ 1.414 = √2. When you fold an A4 sheet in half, you get an A5 sheet with the same aspect ratio. This property is a consequence of √2 being the silver ratio minus 1 (since δ = 1 + √2, we have √2 = δ - 1).

**2. The Silver Spiral in Architecture**

Some architects have used the silver spiral in building design. The spiral is less common than the golden spiral, but it has its own aesthetic appeal: it is more elongated and dramatic.

**3. Musical Instruments**

The proportions of some musical instruments approximate the silver ratio. The body of a guitar, for instance, sometimes has dimensions that are close to silver rectangles.

**4. Typography**

Some typographers have used the silver ratio to determine the proportions of text blocks and margins on a page.

### The Silver Ratio in Islamic Geometry

Islamic geometric art makes extensive use of the silver ratio. The intricate geometric patterns found in mosques and palaces often use √2 as a fundamental proportion. This is because the regular octagon (which is related to the silver ratio) is one of the most common shapes in Islamic geometric art.

The relationship between the silver ratio and the octagon is:
- The diagonal of a regular octagon is δ times its side length.
- The ratio of the area of a regular octagon to the area of the square it is inscribed in is related to δ.

**Key Concept**: The silver ratio appears in Islamic geometric art through the regular octagon.

### The Silver Ratio in Modern Design

Modern designers use the silver ratio in several ways:

**1. Logo Design**

Some logos use the silver ratio to determine proportions. The ratio √2 appears in the proportions of the logo, creating a balanced and harmonious design.

**2. Packaging Design**

The proportions of some product packages use the silver ratio. The ratio of the height to the width of the package is √2, which creates a pleasing visual effect.

**3. Web Design**

Some web designers use the silver ratio to determine the proportions of page elements. The ratio of the main content area to the sidebar is √2.

### Worked Example 2.5.1

An A4 sheet has dimensions 210 mm × 297 mm. What is the aspect ratio?

**Solution**: 297/210 = 1.4142857...

This is close to √2 ≈ 1.4142135...

The slight discrepancy is because the actual A4 dimensions are rounded to the nearest millimeter.

### Worked Example 2.5.2

If you have an A4 sheet and you want to find the dimensions of an A3 sheet (which is twice as large), what are the dimensions?

**Solution**: An A3 sheet is two A4 sheets placed side by side along the short edge. So the dimensions are:

Width: 297 mm (the long edge of A4)
Height: 2 × 210 = 420 mm

The aspect ratio is 420/297 ≈ 1.414, which is again close to √2.

### Practice Problems

1. An A3 sheet has dimensions 297 mm × 420 mm. What is the aspect ratio? How close is it to √2?
2. An A5 sheet has dimensions 148 mm × 210 mm. What is the aspect ratio? How close is it to √2?
3. If an A0 sheet has an area of 1 m², what are its dimensions? (Hint: it is 16 times the area of an A4 sheet.)
4. A silver rectangle has width 15 cm. What is its length?
5. A poster has dimensions 60 cm × 144.85 cm. Is this approximately a silver rectangle?

### Teacher's Notes

**Hands-On Activity**: Give each student an A4 sheet of paper. Have them fold it in half and measure the dimensions. Verify that the aspect ratio is preserved. Then have them tear off a square and verify that the remaining rectangle is not golden (it is still a √2 rectangle, not a silver rectangle).

**Real-World Connection**: The A-series paper sizes are used worldwide (except in North America). This is a practical application of the silver ratio that students encounter every day.

**Assessment**: Ask students to find three real-world examples of the silver ratio (or √2 ratios) and report on them.

---

## Lesson 2.6: The Silver Ratio and Continued Fractions

### Explanation

The silver ratio, like the golden ratio, has a beautiful continued fraction representation.

### Continued Fractions

A **continued fraction** is an expression of the form:

a₀ + 1/(a₁ + 1/(a₂ + 1/(a₃ + ...)))

where a₀, a₁, a₂, a₃, ... are integers.

Every real number can be represented as a continued fraction. The continued fraction representation is unique if we require that all the aᵢ (except possibly a₀) are positive integers.

### The Continued Fraction of the Golden Ratio

The golden ratio has the simplest possible continued fraction:

φ = 1 + 1/(1 + 1/(1 + 1/(1 + ...)))

All the partial quotients are 1. This is why the golden ratio is the "most irrational" number — it is the hardest number to approximate by rationals.

### The Continued Fraction of the Silver Ratio

The silver ratio has a slightly more complex continued fraction:

δ = 2 + 1/(2 + 1/(2 + 1/(2 + ...)))

All the partial quotients are 2. This means the silver ratio is the second most irrational number.

### The Continued Fraction of the Bronze Ratio

The bronze ratio has:

B = 3 + 1/(3 + 1/(3 + 1/(3 + ...)))

All the partial quotients are 3.

### The General Metallic Ratio

The nth metallic ratio has continued fraction:

M(n) = n + 1/(n + 1/(n + 1/(n + ...)))

All the partial quotients are n.

**Key Concept**: The metallic ratios have the simplest continued fractions: all partial quotients are equal to n.

### Worked Example 2.6.1

Compute the first 5 convergents of the continued fraction for the silver ratio.

**Solution**: δ = 2 + 1/(2 + 1/(2 + 1/(2 + 1/(2 + ...))))

Convergent 1: 2
Convergent 2: 2 + 1/2 = 5/2 = 2.5
Convergent 3: 2 + 1/(2 + 1/2) = 2 + 1/(5/2) = 2 + 2/5 = 12/5 = 2.4
Convergent 4: 2 + 1/(2 + 1/(2 + 1/2)) = 2 + 1/(2 + 2/5) = 2 + 1/(12/5) = 2 + 5/12 = 29/12 ≈ 2.4167
Convergent 5: 2 + 1/(2 + 1/(2 + 1/(2 + 1/2))) = 2 + 1/(2 + 5/12) = 2 + 1/(29/12) = 2 + 12/29 = 70/29 ≈ 2.4138

These convergents approach δ ≈ 2.4142.

### Practice Problems

1. Compute the first 6 convergents of the continued fraction for the golden ratio.
2. Compute the first 6 convergents of the continued fraction for the bronze ratio.
3. Why does the golden ratio have all partial quotients equal to 1?
4. Which metallic ratio is the most difficult to approximate by rationals?
5. Compute the continued fraction for √2. How does it compare to the silver ratio?

### Teacher's Notes

**Number Theory Connection**: Continued fractions are a deep topic in number theory. The fact that the metallic ratios have the simplest continued fractions is a beautiful connection between different areas of mathematics.

**Extension**: Ask students to prove that the continued fraction for the silver ratio has all partial quotients equal to 2. (Hint: use the defining equation δ² = 2δ + 1.)

---

## Summary of Chapter 2

### Key Concepts

1. The **silver ratio** is δ = 1 + √2 ≈ 2.4142135623...
2. It is the positive solution of δ² = 2δ + 1.
3. The silver ratio is the second member of the **metallic ratio** family.
4. A **silver rectangle** has length-to-width ratio of δ.
5. Removing two squares from a silver rectangle leaves another silver rectangle.
6. The **silver spiral** is a logarithmic spiral with growth factor δ per quarter turn.
7. The **Pell sequence** is the silver analogue of the Fibonacci sequence.
8. The silver ratio appears in A-series paper sizes, architecture, and design.

### Key Formulas

| Formula | Description |
|---------|-------------|
| δ = 1 + √2 | Definition of the silver ratio |
| δ² = 2δ + 1 | Fundamental property |
| M(n) = (n + √(n² + 4))/2 | General metallic ratio |
| P(n) = 2P(n-1) + P(n-2) | Pell sequence recurrence |
| r = a × δ^(2θ/π) | Equation of the silver spiral |

### Connections to Other Chapters

- **Chapter 1 (Golden Ratio)**: The silver ratio is the n = 2 member of the metallic ratio family, with the golden ratio as the n = 1 member.
- **Chapter 3 (Bronze Ratio)**: The bronze ratio is the n = 3 member of the metallic ratio family.
- **Chapter 5 (Fibonacci and Lucas Numbers)**: The Pell sequence is the silver analogue of the Fibonacci sequence.
- **Chapter 7 (Padovan and Kepler Ratios)**: The Padovan sequence is related to the plastic number, which is another metallic-like constant.

---

**End of Chapter 2**

*Next: Chapter 3 — The Bronze Ratio*
