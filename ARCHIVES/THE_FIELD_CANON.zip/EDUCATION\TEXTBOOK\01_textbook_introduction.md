# 01 — Textbook Introduction

## Why These Mathematics Matter

---

### A Letter to the Student

Dear Student,

You are holding something unusual. This is not a typical mathematics textbook. It will not ask you to memorize formulas and regurgitate them on an exam. It will not present mathematics as a dead subject — a collection of rules invented by old men in powdered wigs, to be learned under duress and forgotten immediately after the test.

This textbook presents mathematics as something alive.

Every mathematical system you will study here — and there are more than thirty-five of them — was either discovered in nature or has found its way into nature. The golden ratio appears in sunflowers. The silver ratio appears in the silver rectangle. The harmonic series underlies every piece of music ever written. These are not coincidences. They are evidence that mathematics is not something humans invented. It is something humans *found*.

We are going to rebuild your understanding of mathematics from the ground up. We will start with the simplest possible concept — a ratio — and from that single seed, we will grow an entire forest of mathematical knowledge.

---

### What Is a Mathematical System?

Before we begin, we need to agree on what we mean by a "mathematical system."

A mathematical system is any collection of objects, rules, and relationships that can be studied using the tools of mathematics. Some mathematical systems are very small. The system of whole numbers — 1, 2, 3, 4, and so on — is a mathematical system. Some are very large. The system of all real numbers is enormous. But every mathematical system, no matter how large or small, has three things:

1. **Objects**: The things the system is about. Numbers, shapes, functions, or more abstract entities.
2. **Operations**: The things you can do with the objects. Addition, multiplication, comparison, transformation.
3. **Properties**: The rules that govern how the operations behave. Commutativity, associativity, distributivity.

When we say there are "35 or more" mathematical systems in this textbook, we mean that we will study 35 or more distinct collections of objects, each with its own operations and properties. Some of these systems are closely related. The golden ratio, the Fibonacci sequence, and the golden rectangle are three aspects of the same underlying mathematical reality. Others are more distant. The harmonic series and the Padovan sequence seem unrelated at first, but they are connected through deeper structures.

---

### The Philosophy of Learning Mathematics as "Rebuilding Society from the Ground Up"

There is a metaphor that runs through this textbook, and it is this: learning mathematics is like rebuilding a society from the ground up.

Imagine that all human knowledge has been lost. You are starting from scratch. You have nothing but your mind and the physical world around you. What is the first thing you would need?

You would need to count.

Counting leads to whole numbers. Whole numbers lead to fractions. Fractions lead to ratios. Ratios lead to the discovery that some ratios are more natural than others — that the golden ratio, for instance, appears again and again in the shapes of leaves, the spirals of shells, and the proportions of the human body.

This is not a fairy tale. This is literally how mathematics developed in human history. The ancient Egyptians discovered the golden ratio in architecture. The ancient Greeks proved it was irrational. The medieval Indians discovered the Fibonacci sequence. The Renaissance Europeans discovered the golden rectangle. Each discovery built on the previous one, just as a society builds on its own history.

When you study this textbook, you are retracing that journey. You are rebuilding the edifice of mathematical knowledge, one brick at a time. And when you finish, you will understand not just the formulas, but *why* those formulas exist, *what* they describe, and *how* they connect to everything else.

---

### How to Use This Textbook

This textbook is organized into twelve chapters and three appendices.

**Part I (Chapters 1-7)** covers the foundational ratios and sequences: the golden ratio, the silver ratio, the bronze ratio, harmonic mathematics, Fibonacci and Lucas numbers, the plastic and supergolden ratios, and the Padovan and Kepler ratios. These are the building blocks. Study them carefully.

**Part II (Chapters 8-12)** covers the applications of these mathematical systems to the real world: living mathematics (biology), statistics and geometry, chemistry and physics, biology and medicine, economics and computer science. These chapters show you *why* the foundational ratios matter.

**Part III (Appendices A-C)** provides reference material: a formula sheet, a complete problem set of 200 problems, and an answer key.

#### For Each Lesson

Every lesson in this textbook follows the same structure:

1. **Explanation**: A clear, step-by-step explanation of the concept.
2. **Worked Examples**: Problems solved in full detail, showing every step.
3. **Practice Problems**: Problems for you to solve on your own.
4. **Teacher's Notes**: Guidance for instructors (and insight for self-learners).

**The Golden Rule of This Textbook**: Never move on from a lesson until you can solve every practice problem without looking at the answer key. If you cannot solve a problem, re-read the explanation and the worked examples. Mathematics is not a spectator sport.

---

### What You Will Learn

By the time you finish this textbook, you will understand:

- **The Golden Ratio (Phi)**: What it is, where it appears, and how to compute with it.
- **The Silver Ratio and Bronze Ratio**: How they relate to the golden ratio, and what makes them distinct.
- **Harmonic Mathematics**: The mathematics of music, vibration, and resonance.
- **Fibonacci and Lucas Numbers**: The most famous sequences in mathematics, and their deep connection to the golden ratio.
- **The Plastic Number and Supergolden Ratio**: Less famous but equally beautiful mathematical constants.
- **Padovan Sequences and Kepler Triangles**: Geometric structures built from the plastic number.
- **Phyllotaxis**: How plants use mathematics to arrange leaves, seeds, and petals.
- **Phi-Statistics**: How the golden ratio appears in probability and statistics.
- **Phi-Chemistry**: How quasicrystals use five-fold symmetry based on the golden ratio.
- **Phi-Physics**: How the golden ratio appears in the fundamental constants of nature.
- **Phi-Biology**: How DNA, neural oscillations, and the human body use the golden ratio.
- **Phi-Economics**: How traders use Fibonacci ratios to predict markets.
- **Phi-Computer Science**: How the golden ratio appears in algorithms, data structures, and cryptography.

This is not a complete list. There is much more. But these are the major topics.

---

### A Note on Prerequisites

This textbook assumes you can add, subtract, multiply, and divide. That is all. If you can do those four things, you can learn everything in this book.

You do *not* need to know algebra before you start. Algebra will be introduced gradually, as needed. You do *not* need to know geometry. Geometry will be introduced in the chapters that need it. You do *not* need to know calculus. Calculus is not required for any chapter in this book.

What you *do* need is willingness to think. Mathematics is not about memorizing formulas. It is about understanding relationships. If you can think clearly about relationships between numbers, you can do mathematics.

---

### A Note on Notation

Mathematics uses a special language of symbols. This language exists for a good reason: it makes complex ideas concise. But it can also be intimidating if you have never seen it before.

In this textbook, every symbol is explained the first time it appears. If you encounter a symbol you do not recognize, look it up in Appendix A (Formula Reference Sheet). If it is not there, ask your teacher.

The most important symbols in this textbook are:

| Symbol | Name | Meaning |
|--------|------|---------|
| φ (phi) | Golden ratio | (1 + √5) / 2 ≈ 1.6180339887... |
| δ (delta) | Silver ratio | 1 + √2 ≈ 2.4142135623... |
| ρ (rho) | Plastic number | ≈ 1.3247179572... |
| √ | Square root | The number which, when multiplied by itself, gives the original |
| Σ (sigma) | Sum | Add up all the terms |
| ∏ (pi) | Product | Multiply all the terms |
| ∈ | Element of | "is contained in" |
| ⊂ | Proper subset of | "is a part of" |
| ∀ | For all | "for every" |
| ∃ | There exists | "there is at least one" |

---

### A Note on the History of Mathematics

Throughout this textbook, you will encounter boxes labeled "Historical Note." These boxes provide context for the mathematical ideas you are learning. Mathematics did not spring fully formed from the brain of any single person. It was built over millennia, by thousands of people, in dozens of civilizations.

The ancient Babylonians knew about the Pythagorean theorem a thousand years before Pythagoras. The ancient Indians discovered the Fibonacci sequence twelve centuries before Fibonacci. The golden ratio was known to the ancient Egyptians, long before Euclid wrote about it.

Mathematics is a universal human achievement. It belongs to no single culture, no single era, no single person. When you study mathematics, you are participating in the oldest and most universal of human activities.

---

### Historical Note: The Word "Mathematics"

The word "mathematics" comes from the Greek *mathema*, meaning "learning" or "knowledge." The Greeks did not distinguish between what we now call "mathematics" and what we now call "philosophy." For them, both were branches of the same pursuit: understanding the nature of reality.

This textbook returns to that broader vision. When we study the golden ratio, we are not just doing arithmetic. We are asking: what is the relationship between number and nature? When we study harmonic mathematics, we are not just computing frequencies. We are asking: what is the relationship between vibration and beauty?

These are not idle questions. They have practical answers, and those answers have changed the world.

---

### How This Textbook Is Different

Most mathematics textbooks present mathematics as a finished product. Here are the theorems. Here are the proofs. Memorize them.

This textbook presents mathematics as a living process. Here is a question. Here is how we might approach it. Here is what we find. Here is what it means.

Most mathematics textbooks separate "pure" mathematics from "applied" mathematics. This textbook does not. The golden ratio is a pure mathematical constant, but it also appears in sunflowers. The harmonic series is a pure mathematical sequence, but it also underlies music. There is no wall between pure and applied mathematics. There is only mathematics.

Most mathematics textbooks treat each topic in isolation. This textbook shows connections. The golden ratio connects to Fibonacci numbers. Fibonacci numbers connect to phyllotaxis. Phyllotaxis connects to biology. Biology connects to medicine. Everything connects to everything else. This is not a flaw in mathematics. It is its greatest strength.

---

### How to Read This Book as a Teacher

If you are a teacher using this textbook, here are some suggestions:

**Pacing**: Each chapter is designed for 2-4 weeks of instruction. The foundational chapters (1-3) should be covered more slowly, because they introduce the core concepts that the rest of the book builds on. The applied chapters (8-12) can be covered more quickly, as they review and apply concepts already learned.

**Assessment**: After each chapter, assign a selection of problems from the chapter's practice problems. The complete problem set in Appendix B can be used for midterm and final exams. The answer key in Appendix C provides complete solutions.

**Classroom Activities**: Many lessons include "Teacher's Notes" sections with suggestions for classroom activities. These activities are designed to make the mathematics tangible and memorable. Use them whenever possible.

**Differentiation**: For advanced students, the Challenge Problems in Appendix B (Problems 176-200) provide additional depth. For struggling students, the worked examples in each lesson provide a model for problem-solving.

**Cross-Curricular Connections**: This textbook naturally connects to music (Chapter 4), biology (Chapters 8, 11), physics (Chapter 10), art (Chapters 1, 7, 9), and computer science (Chapter 12). Collaborate with teachers in these subjects to create interdisciplinary lessons.

---

### A Roadmap for Self-Learners

If you are studying this textbook on your own, here is a suggested roadmap:

**Week 1-2**: Chapters 1-2 (Golden Ratio and Silver Ratio). These are the foundation. Take your time.

**Week 3-4**: Chapters 3-4 (Bronze Ratio and Harmonic Mathematics). Notice how the metallic ratio family extends the golden ratio.

**Week 5-6**: Chapter 5 (Fibonacci and Lucas Numbers). This is the most important chapter after Chapter 1.

**Week 7-8**: Chapters 6-7 (Plastic/Supergolden and Padovan/Kepler). These extend the ideas of Chapters 1-5.

**Week 9-12**: Chapters 8-12 (Applied chapters). These show why the mathematics matters in the real world.

**Week 13-16**: Appendices. Work through the complete problem set. Check your answers.

Total study time: approximately 4 months at 10 hours per week.

---

### The Thirty-Five Mathematical Systems

Here is a complete list of the mathematical systems covered in this textbook:

1. The Golden Ratio (phi)
2. The Silver Ratio (delta)
3. The Bronze Ratio (B)
4. The Copper Ratio (M(4))
5. The Nickel Ratio (M(5))
6. The Metallic Ratio Family (M(n))
7. The Golden Rectangle
8. The Silver Rectangle
9. The Bronze Rectangle
10. The Golden Spiral
11. The Silver Spiral
12. The Bronze Spiral
13. The Harmonic Series
14. Harmonic Numbers
15. The Overtone Series
16. Pythagorean Tuning
17. Equal Temperament
18. The Fibonacci Sequence
19. The Lucas Sequence
20. Binet's Formula
21. Zeckendorf's Theorem
22. The Padovan Sequence
23. The Perrin Sequence
24. The Narayana Cows Sequence
25. The Plastic Number
26. The Supergolden Ratio
27. The Kepler Triangle
28. The Padovan Spiral
29. Phyllotaxis
30. The Golden Angle
31. Penrose Tilings
32. The Icosahedron (golden geometry)
33. The Dodecahedron (golden geometry)
34. Quasicrystals
35. Fibonacci Trading Ratios

And there are more: the golden ratio search, Fibonacci heaps, Fibonacci coding, the Fibonacci anyon, and many others.

---

### Let Us Begin

We are going to start with the simplest possible idea: a ratio. A comparison between two numbers. From that single seed, we will grow an entire forest of mathematical knowledge.

Turn to Chapter 1. Let us begin.

---

*"In the beginning, there was a ratio. And the ratio was golden. And the ratio was with mathematics, and the ratio was mathematics."*

---

**End of Introduction**

*Next: Chapter 1 — The Golden Ratio (Phi)*
