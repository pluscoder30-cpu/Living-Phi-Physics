# PHI-PROPORTION IN VISUAL ART

## 1. The Golden Ratio in Visual Composition

### 1.1 Definition and Application

The golden ratio phi = 1.6180339887 serves as the fundamental proportional system in visual art, governing the relationship between elements within a composition. When applied to canvas dimensions, figure placement, and spatial divisions, phi creates a sense of natural harmony that the human eye perceives as aesthetically optimal.

### 1.2 The Phi-Rectangle

The most fundamental application is the phi-rectangle, where width and height share the golden ratio:

```
Width : Height = phi : 1
Height : Width = 1 : phi

For a canvas of height H:
  Width = H x phi = 1.618H
  
Example:
  Height = 100 cm
  Width = 161.8 cm
  Area = 16,180 cm²
```

The phi-rectangle has the unique property that when a square is removed from one end, the remaining rectangle is also a phi-rectangle. This self-similar property allows infinite subdivision while maintaining proportional harmony.

### 1.3 The Phi-Grid

Overlaying the canvas with a phi-grid creates natural focal points:

```
Vertical divisions at: W/phi, W/phi², W/phi³
Horizontal divisions at: H/phi, H/phi², H/phi³

For a 161.8 x 100 cm canvas:
  Vertical lines at: 100 cm, 61.8 cm, 38.2 cm from left
  Horizontal lines at: 61.8 cm, 38.2 cm, 23.6 cm from top

Intersection points (phi-focal points):
  (100, 61.8) — primary focus
  (61.8, 38.2) — secondary focus
  (38.2, 23.6) — tertiary focus
```

These intersections are where the eye naturally rests, making them ideal positions for the subject, focal detail, or point of highest contrast.

## 2. Historical Application

### 2.1 Ancient Egyptian Proportions

The Great Pyramid of Giza (c. 2560 BCE) encodes phi in its dimensions:

```
Base: 230.4 m (each side)
Height: 146.6 m
Slant height: 186.4 m

Ratios:
  Slant/Height = 186.4/146.6 = 1.271 (not phi)
  (Base/2)/Height = 115.2/146.6 = 0.786 (not phi)
  
  But: (Height + Slant)/Base = (146.6 + 186.4)/230.4 = 333/230.4 = 1.445 (not phi)
  
  Correct phi encoding:
  Height x phi = 146.6 x 1.618 = 237.2 m (approximate base: 230.4)
  The pyramid's proportions approximate phi within 3% error
```

### 2.2 Greek Temple Design

The Parthenon (447-432 BCE) fits within a phi-rectangle:

```
Facade dimensions:
  Width: 30.88 m (8 x 3.86 m columns)
  Height: 13.72 m (column height: 10.43 m)
  
  Width/Height = 30.88/13.72 = 2.251 (not phi)
  
  However, including the pediment:
  Total height with pediment: 19.06 m
  Width/Total height = 30.88/19.06 = 1.620 = phi (error: 0.1%)
  
  The facade fits a phi-rectangle when the triangular pediment is included
```

### 2.3 Medieval Manuscript Illumination

Illuminated manuscripts used phi-grids for page layout:

```
Page size (vellum): 330 x 210 mm
Phi-rectangle: 330/210 = 1.571 (error from phi: 2.9%)

Adjusted page: 340 x 210 mm = 1.619 (error: 0.06%)

Text block placement:
  Top margin: 340/phi² = 130 mm
  Bottom margin: 340/phi³ = 80 mm
  Left margin: 210/phi = 130 mm
  Right margin: 210/phi² = 80 mm
  
  Text block: 140 x 130 mm (centered)
```

## 3. Renaissance Master Proportions

### 3.1 Leonardo da Vinci's Application

Leonardo explicitly used phi in several works:

```
Vitruvian Man (c. 1490):
  Total height: 34.6 cm
  Navel height: 21.4 cm
  Ratio: 34.6/21.4 = 1.617 = phi (error: 0.06%)
  
  Arm span: 34.2 cm
  Height/Arm span = 34.6/34.2 = 1.012 (not phi)
  
  But: Navel to ground / Navel to top of head = 21.4/13.2 = 1.621 = phi
  
The Last Supper (1495-1498):
  Canvas: 460 x 880 cm
  Christ figure position: 
    Horizontal: 460/phi = 284 cm from left edge
    Vertical: 880/phi = 544 cm from top
    
  The twelve apostles arranged in four groups of three,
  with each group occupying phi-proportioned space
```

### 3.2 Michelangelo's Sistine Chapel

```
Creation of Adam (1508-1512):
  Panel dimensions: 570 x 280 cm
  Ratio: 570/280 = 2.036 (not phi)
  
  But the gap between Adam and God's fingers:
  Adam's fingertip: 230 cm from left
  God's fingertip: 340 cm from left
  Gap center: 285 cm from left = 570/2 (center of panel)
  
  The focal point (the gap) divides the panel at the golden section:
  Left section: 285 cm
  Right section: 285 cm
  (Equal division, but the energy flows at phi-ratio from edges)
  
  More precisely:
  Adam's body occupies left 230 cm
  God's group occupies right 230 cm
  Gap: 570 - 230 - 230 = 110 cm
  230/110 = 2.091 (not phi)
  
  The phi-application is in the figure-to-space ratio:
  Figure height: 280 cm (full panel height)
  Head-to-waist: 280/phi = 173 cm
  Waist-to-knee: 173/phi = 107 cm
  Knee-to-foot: 107/phi = 66 cm
```

### 3.3 Raphael's School of Athens

```
School of Athens (1509-1511):
  Wall: 770 x 500 cm (Stanza della Segnatura)
  
  Central vanishing point:
    Horizontal: 770/2 = 385 cm (center)
    Vertical: 500/phi = 309 cm from top
    
  Plato and Aristotle positioned at:
    Plato: 385 - 60 = 325 cm from left (phi-offset from center)
    Aristotle: 385 + 60 = 445 cm from left
    
  The arch framing the scene:
    Arch apex at: 500/phi = 309 cm from top
    Arch width: 770/phi = 476 cm
    Arch spring line: 500/phi² = 191 cm from top
```

## 4. PHI in Figure Drawing

### 4.1 Human Body Proportions

The human body exhibits phi-proportions at multiple scales:

```
Total height: H
Navel height: H/phi (from ground)
Shoulder height: H - H/phi² = H(1 - 1/phi²) = H/phi (from top)
Knee height: H/phi² (from ground)
Elbow height: H/phi² (from shoulder)

Arm segments:
  Upper arm : Forearm : Hand = phi : 1 : 1/phi
  = 1.618 : 1 : 0.618

Finger segments:
  Each segment is 1/phi of the previous:
  Palm : Middle finger : Middle phalanx : Distal phalanx
  = phi³ : phi² : phi : 1
  = 4.236 : 2.618 : 1.618 : 1
```

### 4.2 Face Proportions

```
Face phi-proportions:
  Face width : Face height = 1 : phi
  Eye spacing : Face width = 1 : phi
  Nose length : Face height = 1 : phi²
  Mouth width : Nose width = phi : 1
  Forehead height : Face height = 1 : phi²
  Chin length : Face height = 1 : phi³

Classic "ideal" face:
  Total height: 210 mm
  Width: 210/phi = 130 mm
  Eyes at: 210/phi = 130 mm from top
  Nose at: 130/phi = 80 mm from eyes
  Mouth at: 80/phi = 50 mm from nose
```

### 4.3 Dynamic Figure Poses

```
Contrapposto pose (phi-tilted):
  Weight-bearing leg: straight (vertical axis)
  Free leg: extended at angle = 180/phi = 111.3 degrees from vertical
  
  Shoulder tilt: 180/phi² = 68.8 degrees
  Hip tilt: 180/phi³ = 42.5 degrees
  
  The opposing tilts create a phi-curve through the figure:
    S-curve with phi-ratio curvature
    Maximum displacement from vertical: body_height/phi³
```

## 5. PHI-Color Theory

### 5.1 The PHI-Color Wheel

```
Standard color wheel: 12 colors at 30-degree intervals
PHI-color wheel: 8 colors at 45-degree intervals

Phi-spacing on the wheel:
  Red: 0 degrees
  Orange: 45 degrees
  Yellow: 90 degrees
  Green: 135 degrees
  Cyan: 180 degrees
  Blue: 225 degrees
  Purple: 270 degrees
  Magenta: 315 degrees

Complementary pairs (180 degrees apart):
  Red - Cyan
  Orange - Blue
  Yellow - Purple
  Green - Magenta
  
Phi-analogous groups (45-degree spacing):
  Red-Orange-Yellow (warm)
  Green-Cyan-Blue (cool)
  Purple-Magenta-Red (transitional)
```

### 5.2 PHI-Harmony Formulas

```
Phi-harmony color scheme:
  Base color: Hue H
  Phi-colors: H, H + 137.5, H + 275, H + 52.5, H + 190
  
  Where 137.5 degrees = 360/phi^2 (golden angle)
  
  This creates 5 colors evenly distributed around the wheel
  at phi-optimized intervals, ensuring maximum contrast
  with minimum visual tension
```

### 5.3 Value and Saturation

```
Value (lightness) scale:
  10 steps from black (0) to white (100)
  Phi-values: 0, 6.2, 10, 16.2, 26.2, 42.4, 68.6, 74.8, 81, 100
  
  The phi-sequence of values:
    0, 6.2, 10, 16.2, 26.2, 42.4, 68.6, ...
    Each value = previous + phi^(n-2) x 6.2
    
Saturation scale:
  0% (gray) to 100% (pure color)
  Phi-saturation points: 0, 23.6, 38.2, 61.8, 100
  
  The phi-saturation scale creates natural groupings:
    Low saturation: 0-23.6% (muted)
    Medium-low: 23.6-38.2% (dusty)
    Medium: 38.2-61.8% (balanced)
    Medium-high: 61.8-100% (vibrant)
    High: 61.8-100% (pure)
```

## 6. PHI in Photography

### 6.1 Composition Rules

```
Rule of thirds (approximation to phi):
  Standard: grid at 1/3 and 2/3 of frame
  Phi: grid at 1/phi and 1/phi² of frame
  = 0.618 and 0.382 of frame
  
  For a 3:2 frame (36 x 24 cm):
    Rule of thirds lines: 12 cm and 24 cm from left
    Phi lines: 22.3 cm and 13.7 cm from left
    
  The phi-lines are closer together, creating a more
  centralized composition than rule-of-thirds
```

### 6.2 Focal Length and phi

```
"Natural" focal length: 50 mm (approximately human field of view)
Phi-focal lengths: 50, 50 x phi = 81, 50 x phi^2 = 131 mm

Field of view at these focal lengths:
  50 mm: 39.6 degrees (normal)
  81 mm: 25.0 degrees (short telephoto)
  131 mm: 15.6 degrees (telephoto)
  
  The phi-ratio between focal lengths creates a natural
  progression from normal to telephoto vision
```

### 6.3 Crop Ratios

```
Phi-crop ratios:
  Original: 3:2 (1.500)
  Phi-crop 1: 5:3 (1.667, error from phi: 3.0%)
  Phi-crop 2: 8:5 (1.600, error from phi: 1.1%)
  Phi-crop 3: 13:8 (1.625, error from phi: 0.4%)
  Phi-crop 4: 21:13 (1.615, error from phi: 0.2%)
  
  As Fibonacci numbers increase, the crop ratio
  approaches phi exactly
```

## 7. Digital Art and PHI

### 7.1 Pixel Grid PHI

```
Canvas dimensions in pixels:
  Standard: 1920 x 1080 (16:9 = 1.778)
  Phi: 1920/phi = 1187 pixels height
  Or: 1080 x phi = 1747 pixels width
  
  Recommended phi-canvases:
    1187 x 734 (F(10) x F(9) pixels)
    1920 x 1187 (16:phi)
    2560 x 1582 (16:phi)
```

### 7.2 Typography on PHI-Grid

```
PHI-Typography system:
  Base font size: 12 pt
  Heading sizes: 12, 19.4, 31.4, 50.8 pt (x phi each)
  Line height: 12 x phi = 19.4 pt
  Paragraph spacing: 19.4 x phi = 31.4 pt
  
  Column widths:
    Single column: 55 characters (optimal reading width)
    Two columns: 55/phi = 34 characters each
    Three columns: 55/phi^2 = 21 characters each
```

### 7.3 UI Design PHI

```
PHI-UI layout:
  Header height: 60 px
  Content width: 60 x phi = 97 px (or 960 px for full-width)
  Sidebar width: 960/phi = 593 px
  Main content: 960 - 593 = 367 px (or 960/phi = 593 px with sidebar at 367)
  
  Button sizes:
    Primary: 48 x 48 px
    Secondary: 48/phi = 30 x 30 px
    Tertiary: 30/phi = 18 x 18 px
    
  Spacing:
    Between elements: 8 px
    Between sections: 8 x phi = 13 px
    Between major sections: 13 x phi = 21 px
```

## 8. PHI in Print Design

### 8.1 Book Design

```
Standard book size: 6 x 9 inches (ratio 1.500)
PHI-book size: 6 x 9.71 inches (ratio 1.618)

Page layout:
  Margins: 
    Top: 9.71/phi² = 3.71 inches
    Bottom: 9.71/phi³ = 2.29 inches
    Inner: 6/phi = 3.71 inches
    Outer: 6/phi² = 2.29 inches
    
  Text block:
    Width: 6 - 3.71 - 2.29 = 0 inches (problematic)
    
  Better approach:
    Top: 1.5 inches
    Bottom: 1.5 x phi = 2.43 inches
    Inner: 1.5 inches
    Outer: 1.5 x phi = 2.43 inches
    Text block: 6 - 1.5 - 2.43 = 2.07 inches wide
                9.71 - 1.5 - 2.43 = 5.78 inches tall
```

### 8.2 Poster Design

```
PHI-Poster (24 x 36 inches):
  Image area: 24/phi = 14.84 inches from top
  Text area: 36 - 14.84 = 21.16 inches
  
  Headline: 72 pt (reference)
  Subheadline: 72/phi = 44.5 pt
  Body text: 44.5/phi = 27.5 pt
  
  Image placement:
    Subject at: 24/phi = 14.84 inches from left edge
    Background: remaining space
```

### 8.3 Business Card Design

```
Standard business card: 3.5 x 2 inches (ratio 1.750)
PHI-business card: 3.5 x 2.16 inches (ratio 1.618)

Layout zones (phi-divided):
  Zone 1 (name): top 2.16/phi = 1.34 inches
  Zone 2 (title): next 1.34/phi = 0.83 inches
  Zone 3 (contact): remaining 2.16 - 1.34 - 0.83 = -0.01 inches (too tight)
  
  Better:
    Name zone: top 40% (0.86 inches)
    Title zone: next 24% (0.52 inches)
    Contact zone: bottom 36% (0.78 inches)
    Ratios: 40:24:36 = phi:1:phi (approximately)
```

## 9. PHI in Sculpture

### 9.1 Three-Dimensional Proportions

```
PHI-Sculpture bounding box:
  Width: W
  Height: W x phi
  Depth: W/phi

  Example (figure sculpture):
    Width (shoulder-to-shoulder): 40 cm
    Height: 40 x phi = 64.7 cm
    Depth (front-to-back): 40/phi = 24.7 cm
```

### 9.2 Volume Distribution

```
PHI-Volume allocation for abstract sculpture:
  Total volume: V
  
  Component 1: V/phi (61.8% of volume)
  Component 2: V/phi² (23.6% of volume)
  Component 3: V/phi³ (14.6% of volume)
  
  The phi-distribution ensures that no single element
  dominates, while maintaining clear visual hierarchy
```

### 9.3 Surface Treatment

```
Surface texture zones:
  Smooth zone: 61.8% of surface area (phi/total)
  Textured zone: 23.6% (1/phi² of total)
  Detail zone: 14.6% (1/phi³ of total)
  
  The smooth majority provides visual rest,
  the textured area creates interest,
  and the detail zone rewards close inspection
```

## 10. PHI-Composition Checklists

### 10.1 Painting Checklist

```
[ ] Canvas ratio is phi (1.618:1)
[ ] Focal point at phi-intersection of grid
[ ] Major elements at phi-divisions
[ ] Color wheel uses phi-harmony (137.5-degree spacing)
[ ] Value range spans phi (light to dark)
[ ] Brush stroke sizes follow Fibonacci sequence
[ ] Negative space : Positive space = 1 : phi
[ ] Edges: 61.8% soft, 38.2% hard
[ ] Details: concentrated in 38.2% of canvas
[ ] Overall impression: balanced, natural, inevitable
```

### 10.2 Photography Checklist

```
[ ] Subject at phi-intersection
[ ] Horizon at phi-line (not center)
[ ] Leading lines follow phi-spiral
[ ] Depth of field creates phi-gradient
[ ] Exposure: highlights and shadows in phi-ratio
[ ] Color palette: phi-harmony scheme
[ ] Crop to phi-ratio if possible
[ ] Timing: decisive moment at phi-point in sequence
```

### 10.3 Digital Art Checklist

```
[ ] Canvas dimensions are Fibonacci numbers (pixels)
[ ] Grid overlay active at phi-divisions
[ ] Font sizes in phi-ratio
[ ] Spacing follows Fibonacci sequence
[ ] Color palette verified against phi-wheel
[ ] Layer opacity values are phi-related
[ ] Symmetry broken at phi-ratio
[ ] Final export at phi-crop ratio
```

## References

- Livio, M. (2002). "The Golden Ratio: The Story of Phi"
- doczi, G. (1981). "The Power of Limits: Proportional Harmonies in Nature, Art, and Architecture"
- Bouleau, C. (1963). "The Painter's Secret Geometry"
- Ghyka, M. (1931). "The Geometry of Art and Life"
- Padovan, R. (2002). "Proportion: Science, Philosophy, Architecture"
