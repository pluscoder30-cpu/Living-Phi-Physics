# Appendix B: Complete Problem Set

## 200 Graded Problems Covering All Chapters

---

### Part I: Foundational Ratios (Problems 1-50)

**Chapter 1: The Golden Ratio (Problems 1-15)**

1. Compute phi to six decimal places.
2. Verify that phi^2 = phi + 1 numerically.
3. Compute 1/phi to six decimal places.
4. Verify that 1/phi = phi - 1 numerically.
5. A golden rectangle has width 12 cm. What is its length?
6. A golden rectangle has length 20 cm. What is its width?
7. A sunflower has 34 spirals clockwise and 55 counterclockwise. What is the ratio? How close to phi?
8. Compute phi^3 using the property phi^n = phi^(n-1) + phi^(n-2).
9. Express phi^4 in the form a x phi + b.
10. What is the golden angle in degrees?
11. A golden spiral starts with radius 2 cm. What is its radius after one quarter turn?
12. Remove a square from a golden rectangle with width 10 cm. What are the dimensions of the remaining rectangle?
13. Verify that the remaining rectangle is also golden.
14. Compute phi^6.
15. What is the ratio of phi^10 to the nearest Fibonacci number?

**Chapter 2: The Silver Ratio (Problems 16-25)**

16. Compute delta = 1 + sqrt(2) to six decimal places.
17. Verify that delta^2 = 2 x delta + 1 numerically.
18. Compute 1/delta to six decimal places.
19. A silver rectangle has width 10 cm. What is its length?
20. Remove two squares from a silver rectangle. What are the dimensions of the remaining rectangle?
21. Compute the first 8 Pell numbers.
22. Compute P(8)/P(7) and compare to delta.
23. A silver spiral starts with radius 3 cm. What is its radius after one complete turn?
24. What is the aspect ratio of an A4 sheet? How close to sqrt(2)?
25. Express M(4) (the copper ratio) in closed form.

**Chapter 3: The Bronze Ratio (Problems 26-35)**

26. Compute B = (3 + sqrt(13))/2 to six decimal places.
27. Verify that B^2 = 3B + 1 numerically.
28. Compute 1/B to six decimal places.
29. Compute the first 8 terms of the bronze sequence.
30. A bronze rectangle has width 8 cm. What is its length?
31. Remove three squares from a bronze rectangle. What fraction of the area remains?
32. Compute B^3 in terms of B.
33. Express B^4 in the form aB + b.
34. A bronze spiral starts with radius 1 cm. What is its radius after one complete turn?
35. Compare the growth of golden, silver, and bronze spirals after 5 quarter turns.

**Chapter 4: Harmonic Mathematics (Problems 36-50)**

36. Compute H(5) = 1 + 1/2 + 1/3 + 1/4 + 1/5.
37. Compute H(10) to four decimal places.
38. Approximate H(100) using H(n) ≈ ln(n) + gamma.
39. For what n is H(n) first greater than 4?
40. A guitar string has fundamental frequency 82.4 Hz. What is the frequency of the second overtone?
41. A pipe of length 2 m produces 87.2 Hz. What frequency does a 1 m pipe produce?
42. Compute the ratio of the equal-tempered perfect fifth to the pure perfect fifth.
43. What is the frequency of E4 in equal temperament (A4 = 440 Hz)?
44. A room has width 6 m and height 4 m. What musical interval does this correspond to?
45. Prove that the harmonic series diverges using the grouping argument.
46. Compute H(20) using the approximation.
47. What is the Pythagorean comma?
48. How many semitones are in an octave?
49. A guitar string is 64 cm long. Where is the nodal point for the 3rd overtone?
50. What is the Euler-Mascheroni constant?

---

### Part II: Sequences and Advanced Ratios (Problems 51-100)

**Chapter 5: Fibonacci and Lucas Numbers (Problems 51-70)**

51. Compute F(0) through F(15).
52. Compute F(15)/F(14) and compare to phi.
53. Compute L(0) through L(10).
54. Use Binet's formula to compute F(10).
55. Use Binet's formula to compute L(10).
56. Verify Cassini's identity for n = 6.
57. Find the Zeckendorf representation of 50.
58. Find the Zeckendorf representation of 200.
59. Verify that L(n) = F(n-1) + F(n+1) for n = 5.
60. Compute F(20) using the approximation F(n) ≈ phi^n/sqrt(5).
61. Prove that F(n) is even iff n is a multiple of 3 for n up to 15.
62. Count the petals on 3 flowers. Are they Fibonacci numbers?
63. A pinecone has 8 and 13 spirals. What is the ratio?
64. Compute the sum F(1)^2 + F(2)^2 + ... + F(6)^2.
65. Verify the sum equals F(6) x F(7).
66. For which n is F(n) first greater than 1000?
67. Compute F(0) + F(1) + ... + F(10).
68. What is the formula for the sum of the first n Fibonacci numbers?
69. Verify the formula for n = 5.
70. Research: what is the Pisano period for mod 10?

**Chapter 6: Plastic and Supergolden Ratios (Problems 71-80)**

71. Compute rho to six decimal places.
72. Verify that rho^3 = rho + 1 numerically.
73. Compute the first 12 Padovan numbers.
74. Compute P(12)/P(11) and compare to rho.
75. Compute psi (supergolden ratio) to six decimal places.
76. Verify that psi^3 = psi^2 + 1 numerically.
77. Compute the first 12 Narayana cows numbers.
78. Compute N(12)/N(11) and compare to psi.
79. Compute the first 12 Perrin numbers.
80. Verify that 7 divides P(7) for the Perrin sequence.

**Chapter 7: Padovan and Kepler Ratios (Problems 81-90)**

81. Construct the first 6 triangles of the Padovan spiral.
82. What are the side lengths of the Kepler triangle?
83. Verify that the Kepler triangle satisfies the Pythagorean theorem.
84. Compute the area of a Kepler triangle with shortest side 4 cm.
85. Compute the perimeter of a Kepler triangle with shortest side 5 cm.
86. How does the Padovan spiral differ from the golden spiral?
87. What is the ratio of the longest to shortest side in the first 8 Padovan triangles?
88. Draw a Padovan spiral on graph paper.
89. A Kepler triangle has hypotenuse 15 cm. What are the other sides?
90. Why is the Kepler triangle unique among right triangles?

**Chapter 8: Living Mathematics (Problems 91-100)**

91. What is the golden angle? Why is it optimal for phyllotaxis?
92. A plant produces leaves at 137.5° intervals. What are the angles of the first 6 leaves?
93. Why do Fibonacci numbers appear in flower petals?
94. Count spirals on a pinecone. Are they Fibonacci numbers?
95. A nautilus shell has growth ratio 1.33 per quarter turn. What is the growth per full turn?
96. How does the nautilus spiral differ from the golden spiral?
97. Measure your height and navel height. Compute the ratio.
98. Measure your face width and height. Compute the ratio.
99. Why does the golden angle produce Fibonacci spirals?
100. Find a real-world example of a logarithmic spiral.

---

### Part III: Applied Phi-Mathematics (Probs 101-150)

**Chapter 9: Phi-Statistics and Phi-Geometry (Problems 101-115)**

101. Perform 2 steps of golden ratio search on f(x) = -(x-5)^2 + 25 on [0, 10].
102. After 10 steps of golden ratio search, what fraction remains?
103. A regular pentagon has side 10 cm. What is the diagonal?
104. A regular pentagon has diagonal 15 cm. What is the side?
105. In a Penrose tiling, there are 89 thick rhombi. How many thin rhombi?
106. Verify the ratio is close to phi.
107. An icosahedron has edge length 2. What is the vertex-to-vertex distance?
108. A dodecahedron has edge length 1. What is the face-to-face distance?
109. What is the symmetry of a Penrose tiling?
110. Why can't ordinary crystals have 5-fold symmetry?
111. Draw a small Penrose tiling.
112. What is a phi-normal distribution?
113. Compute the FWHM of a phi-normal with sigma = 1/phi.
114. How many thick and thin tiles in a Penrose tiling with 144 thin tiles?
115. What is the area of a golden rectangle with width 1?

**Chapter 10: Phi-Chemistry and Phi-Physics (Problems 116-125)**

116. What are the dimensions of the DNA double helix?
117. What is the ratio of DNA pitch to width? How close to phi?
118. What is a quasicrystal?
119. Why can't quasicrystals have periodic structure?
120. Compute phi^5 and compare to 11.
121. What is the fine structure constant?
122. Is 1/phi^5 close to alpha?
123. What is a Fibonacci anyon?
124. How many states for 6 Fibonacci anyons?
125. What is the orbital resonance between Jupiter and Saturn?

**Chapter 11: Phi-Biology and Phi-Medicine (Problems 126-140)**

126. What are the dimensions of the DNA double helix in Angstroms?
127. What is the ratio of alpha wave upper to lower bound?
128. How close is this to phi?
129. What is the normal liver length-to-width ratio?
130. How is the golden ratio used in dental proportions?
131. What is the ratio of tryptophan to glycine volume? Is it close to phi^2?
132. How might golden ratio be used in drug design?
133. What is the ratio of treatment to control groups in a phi-optimized trial?
134. Where are acupuncture points located relative to golden sections?
135. What is the 61.8% Fibonacci retracement of a $100-$150 rally?
136. What is the 38.2% retracement of a $200-$120 drop?
137. How is the golden ratio used in medical imaging?
138. What is the cardiac output ratio related to phi?
139. Why might biological receptors have golden proportions?
140. What is the scientific evidence for phi in traditional medicine?

**Chapter 12: Phi-Economics and Phi-CS (Problems 141-150)**

141. A stock rallies from $50 to $80. What is the 61.8% retracement?
142. What is the 161.8% extension of a $10-$25 rally?
143. Perform 2 steps of golden ratio search on f(x) = -(x-3)^2 + 9 on [0, 6].
144. How many steps for 0.01% precision in golden search?
145. What is the amortized decrease-key time in a Fibonacci heap?
146. Find the Zeckendorf representation of 100.
147. Compute x1 through x5 from x0 = 0.3 using x_{n+1} = (phi x x_n) mod 1.
148. Fibonacci search on [1,2,3,4,5,6,7,8] for value 6.
149. What is the maximum degree in a Fibonacci heap with 50 nodes?
150. How does Fibonacci search compare to binary search?

---

### Part IV: Synthesis and Challenge (Problems 151-200)

**Cross-Chapter Problems (Problems 151-175)**

151. Prove that phi is irrational.
152. Prove that the golden ratio is the most irrational number.
153. Derive Binet's formula from the Fibonacci recurrence.
154. Prove that F(n) is the nearest integer to phi^n/sqrt(5).
155. Prove that the metallic ratios satisfy M(n) = (n + sqrt(n^2+4))/2.
156. Prove that the Padovan sequence ratios approach rho.
157. Prove that the Kepler triangle is the only right triangle with sides in geometric progression.
158. Prove that the golden angle is 360°/phi^2.
159. Prove that the golden ratio search eliminates 38.2% of the interval per step.
160. Prove that the Penrose tiling ratio of thick to thin tiles approaches phi.
161. Prove that the harmonic series diverges.
162. Prove Cassini's identity by induction.
163. Prove that gcd(F(m), F(n)) = F(gcd(m,n)).
164. Prove that every positive integer has a Zeckendorf representation.
165. Prove that the Zeckendorf representation is unique.
166. Prove that the metallic ratio M(n) satisfies 1/M(n) = M(n) - n.
167. Prove that the icosahedron can be constructed from three golden rectangles.
168. Prove that phi^4 = 3phi + 2.
169. Prove that phi^n = F(n)phi + F(n-1).
170. Prove that the Padovan sequence satisfies P(n) = P(n-2) + P(n-3).
171. Prove that the golden spiral is self-similar.
172. Prove that the silver ratio is 1 + sqrt(2).
173. Prove that the bronze ratio is (3 + sqrt(13))/2.
174. Prove that the plastic number is the smallest Pisot number.
175. Prove that the Fibonacci sequence grows like phi^n/sqrt(5).

**Challenge Problems (Problems 176-200)**

176. Compute F(100) mod 1000 (last three digits).
177. Find the continued fraction representation of phi.
178. Find the continued fraction representation of e. How does it compare to phi?
179. Compute the first 20 Padovan numbers and plot them.
180. Construct a golden rectangle with compass and straightedge.
181. Construct a Kepler triangle with compass and straightedge.
182. Compute the eigenvalues of the Fibonacci matrix [[1,1],[1,0]].
183. Find the generating function for the Fibonacci sequence.
184. Find the generating function for the Padovan sequence.
185. Compute the golden ratio of a Penrose tiling with 1000 tiles.
186. Prove that the golden ratio is a Pisot number.
187. Prove that the plastic number is a Pisot number.
188. Find all right triangles with integer sides and area equal to a Fibonacci number.
189. Prove that no Fibonacci number (except 1, 1, 2) is a perfect square.
190. Prove that F(n) divides F(kn) for all k.
191. Find the period of the Fibonacci sequence modulo 7.
192. Find the period of the Padovan sequence modulo 7.
193. Prove that the golden ratio appears in the dodecahedron.
194. Compute the volume of an icosahedron with edge length 1.
195. Prove that the golden angle maximizes uniformity of leaf arrangement.
196. Find the relationship between the golden ratio and the Mandelbrot set.
197. Prove that the Fibonacci numbers satisfy F(n)^2 + F(n+1)^2 = F(2n+1).
198. Find the closed form for the sum of the first n Padovan numbers.
199. Prove that the metallic ratios are dense in [1, infinity).
200. Write an essay connecting the golden ratio to the philosophy of mathematics.

---

*End of Appendix B*
