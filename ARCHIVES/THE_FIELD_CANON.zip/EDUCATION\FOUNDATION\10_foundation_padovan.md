# Foundation Mathematics: The Padovan Sequence

## Welcome, Young Mathematician!

You've learned about Fibonacci and Lucas numbers. Now it's time for the **Padovan sequence** — triangles making spirals!

The Padovan sequence is: 1, 1, 1, 2, 2, 3, 4, 5, 7, 9, 12, 16, 21, 28, 37...

It creates beautiful spiral patterns using triangles!

---

## Part 1: What is the Padovan Sequence?

### Triangles Making Spirals

The Padovan sequence was discovered by **Patrick Padovan** in 1994. It's similar to Fibonacci but uses a different rule:

**Each term is the sum of the term two places back and the term three places back.**

Not: each term = sum of previous two (that's Fibonacci)
But: each term = sum of term before the previous and term three back

Let's calculate:
- P(0) = 1
- P(1) = 1
- P(2) = 1
- P(3) = P(1) + P(0) = 1 + 1 = 2
- P(4) = P(2) + P(1) = 1 + 1 = 2
- P(5) = P(3) + P(2) = 2 + 1 = 3
- P(6) = P(4) + P(3) = 2 + 2 = 4
- P(7) = P(5) + P(4) = 3 + 2 = 5
- P(8) = P(6) + P(5) = 4 + 3 = 7
- P(9) = P(7) + P(6) = 5 + 4 = 9
- P(10) = P(8) + P(7) = 7 + 5 = 12
- P(11) = P(9) + P(8) = 9 + 7 = 16
- P(12) = P(10) + P(9) = 12 + 9 = 21
- P(13) = P(11) + P(10) = 16 + 12 = 28
- P(14) = P(12) + P(11) = 21 + 16 = 37

### The Plastic Connection

When you divide consecutive Padovan numbers, you get closer to the **plastic number** (1.325...)!

- 2 ÷ 1 = 2
- 3 ÷ 2 = 1.5
- 4 ÷ 3 = 1.333...
- 5 ÷ 4 = 1.25
- 7 ÷ 5 = 1.4
- 9 ÷ 7 = 1.286...
- 12 ÷ 9 = 1.333...
- 16 ÷ 12 = 1.333...
- 21 ÷ 16 = 1.3125
- 28 ÷ 21 = 1.333...
- 37 ÷ 28 = 1.321...

Getting closer to 1.325!

### Where Padovan Hides

The Padovan sequence shows up in interesting places:

- **Triangle Spirals**: When you arrange equilateral triangles according to the Padovan sequence, they spiral outward!

- **3D Shapes**: The Padovan sequence is related to 3D geometry.

- **Plastic Number**: It's the sequence that approaches the plastic number.

- **Architecture**: Some buildings use Padovan proportions.

---

## Part 2: The Padovan Spiral

### How to Draw a Padovan Spiral

The Padovan spiral is made of equilateral triangles:

**Step 1**: Draw a small equilateral triangle (side length 1).

**Step 2**: Draw another triangle of the same size, attached to one side.

**Step 3**: Draw a third triangle of the same size, attached to the previous one.

**Step 4**: Now draw a triangle with side length 2, attached to the previous triangle.

**Step 5**: Draw another triangle with side length 2, attached to that.

**Step 6**: Draw a triangle with side length 3, attached to the previous one.

**Step 7**: Keep going with side lengths 4, 5, 7, 9, 12, 16, 21...

**Step 8**: Connect the centers of the triangles with a smooth curve.

You've made a Padovan spiral! It spirals outward using triangles!

### The Padovan Property

Here's what makes Padovan special:

When you arrange triangles according to the Padovan sequence, they naturally spiral outward at the plastic ratio (1.325...)!

The spiral gets bigger by a factor of 1.325 for each full turn!

---

## Part 3: What Happens When You Add Padovan?

### Padovan Addition Properties

The Padovan sequence has these special properties:

- P(n) = P(n-2) + P(n-3)

This means each term is the sum of the term two places back and three places back.

### The Plastic Identity

The Padovan sequence approaches the plastic number because:

Plastic³ = Plastic + 1

This is similar to how Fibonacci approaches phi because phi² = phi + 1!

### More Padovan Math

- P(0) + P(1) + P(2) = 1 + 1 + 1 = 3
- P(3) + P(4) + P(5) = 2 + 2 + 3 = 7
- P(6) + P(7) + P(8) = 4 + 5 + 7 = 16
- P(9) + P(10) + P(11) = 9 + 12 + 16 = 37

The sums of three consecutive terms follow a pattern!

---

## Part 4: Padovan in Everyday Life

### Architecture

- **Spiral staircases**: Some follow Padovan proportions.
- **Building designs**: Some use Padovan ratios.
- **Floor plans**: Some rooms are laid out in Padovan patterns.

### Nature

- **Shell spirals**: Some shells spiral according to Padovan.
- **Crystal structures**: Some minerals have Padovan proportions.
- **Plant arrangements**: Some plants use Padovan patterns.

### Mathematics

- **Number theory**: Padovan numbers have interesting properties.
- **Geometry**: They create beautiful triangle spirals.
- **3D math**: They're related to 3D shapes and volumes.

---

## Part 5: 10 Fun Exercises

### Exercise 1: Padovan Calculator
Write out the Padovan sequence up to 100:
1, 1, 1, 2, 2, 3, 4, 5, 7, 9, 12, 16, 21, 28, 37, 49, 65, 86

Now divide each by the one before it:
2÷1 = ?
3÷2 = ?
4÷3 = ?
5÷4 = ?

How close to 1.325 do you get?

### Exercise 2: Draw the Padovan Spiral
Using graph paper, draw the Padovan spiral:
- Draw equilateral triangles with side lengths: 1, 1, 1, 2, 2, 3, 4, 5, 7...
- Arrange them so they spiral outward
- Connect the centers with a smooth curve

### Exercise 3: Triangle Count
Draw the first 10 triangles of the Padovan spiral. Count:
- How many triangles did you draw?
- What are their side lengths?
- How many triangles have side length 1? 2? 3?

### Exercise 4: Padovan vs Fibonacci
Compare the two sequences:
| n | Fibonacci | Padovan |
|---|-----------|---------|
| 0 | 0         | 1       |
| 1 | 1         | 1       |
| 2 | 1         | 1       |
| 3 | 2         | 2       |
| 4 | 3         | 2       |
| 5 | 5         | 3       |
| 6 | 8         | 4       |
| 7 | 13        | 5       |
| 8 | 21        | 7       |

What differences do you notice?

### Exercise 5: Build a Padovan Tower
Use blocks to build a tower with Padovan proportions:
- Start with a 1 cm block
- Add another 1 cm block
- Add a 1 cm block
- Add a 2 cm block
- Add a 2 cm block
- Add a 3 cm block
- Keep going!

### Exercise 6: Padovan Art
Create a picture using Padovan triangles:
- Draw 3 small triangles (side 1)
- Draw 2 medium triangles (side 2)
- Draw 1 large triangle (side 3)
- Draw 1 larger triangle (side 4)
- Arrange them in a spiral pattern!

### Exercise 7: Padovan Music
If you have access to a piano, play notes that correspond to Padovan numbers:
- Play note 1
- Play note 1
- Play note 1
- Play note 2
- Play note 2
- Play note 3
- Play note 4
- Play note 5

Does it create a pattern?

### Exercise 8: The Padovan Pattern
Draw a repeating pattern using Padovan triangles:
- Start with 3 small triangles
- Add 2 medium triangles
- Add 1 large triangle
- Repeat this pattern

### Exercise 9: Real-World Padovan Hunt
Find things that show Padovan proportions:
- Some spiral staircases
- Some crystal structures
- Some shell spirals
- Some architectural designs

### Exercise 10: Padovan Journal
In your math journal:
- Write the Padovan sequence up to 100
- Draw the Padovan spiral
- List 3 differences between Padovan and Fibonacci
- Write a poem about triangle spirals

---

## Part 6: Amazing Padovan Facts

### Fact 1: Padovan is Recent
The Padovan sequence was discovered in 1994 — much more recent than Fibonacci (1202)!

### Fact 2: Triangles, Not Squares
While Fibonacci uses squares to create spirals, Padovan uses triangles! This makes it perfect for 3D shapes.

### Fact 3: Plastic Number Connection
The Padovan sequence is the sequence that approaches the plastic number (1.325...), just like Fibonacci approaches phi (1.618...)!

### Fact 4: 3D Geometry
The Padovan sequence is related to 3D geometry and volumes. It's used in mathematical models of 3D shapes!

### Fact 5: Padovan Spirals in Art
Artists use Padovan spirals to create beautiful triangle-based artwork. The spirals have a unique look that's different from golden spirals!

---

## Part 7: Padovan Poems

### The Padovan Poem
Triangles spiraling, one, two, three,
Padovan sequence, mathematically free,
Each term sum of two before,
Triangle spirals, evermore!

### The Triangle Rhyme
One, one, one, two, two,
Three, four, five — that's the clue,
Padovan counts in triangles so neat,
Making spirals, a mathematical treat!

---

## Part 8: What You've Learned

Today you discovered:

1. **The Padovan sequence** uses triangles to create spirals, unlike Fibonacci which uses squares.

2. **Each term** is the sum of the term two places back and three places back.

3. **The Padovan sequence** approaches the plastic number (1.325...).

4. **Padovan spirals** are perfect for 3D shapes and geometric designs.

5. **The Padovan sequence** was discovered in 1994 — it's a modern mathematical discovery!

---

## Part 9: Challenge Problems

### Challenge 1: The Padovan Formula
Can you find a formula that gives the nth Padovan number directly? (Hint: it's related to the plastic number, similar to Binet's formula for Fibonacci)

### Challenge 2: Padovan and Plastic
How does the Padovan sequence relate to the plastic number? Can you prove that the ratio of consecutive terms approaches 1.325?

### Challenge 3: The 3D Padovan
How would you extend the Padovan sequence to 3D? What would a 3D Padovan spiral look like?

### Challenge 4: Padovan Patterns
Find at least 5 different patterns in the Padovan sequence. (Hint: look at every other term, every third term, sums, etc.)

### Challenge 5: Padovan in Code
Write a program (or pseudocode) that generates Padovan numbers up to 1000.

---

## Part 10: Glossary

**Equilateral Triangle**: A triangle with all three sides equal

**Plastic Number**: Approximately 1.325, the number that Padovan approaches

**Sequence**: A list of numbers that follows a pattern

**Spiral**: A curve that winds around a center point

**3D**: Three-dimensional — having height, width, and depth

---

## Remember!

**Padovan makes triangle spirals!**

The next time you see a spiral made of triangles, or a 3D structure with triangular patterns, remember: Padovan math is at work! While Fibonacci uses squares, Padovan uses triangles to create beautiful spirals!

---

*Triangles are one of the strongest shapes in nature. The Padovan sequence shows us how triangles can spiral outward in the most efficient and beautiful way possible!*
