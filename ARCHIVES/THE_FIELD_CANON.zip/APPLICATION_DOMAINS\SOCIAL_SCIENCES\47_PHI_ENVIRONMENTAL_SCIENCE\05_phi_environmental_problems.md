# PHI-ENVIRONMENTAL SCIENCE: Problems and Exercises

---

## Problem 1: Climate Oscillation Decomposition

A region's temperature record shows phi-harmonic modes with B₁ = 0.8°C, B₂ = 0.5°C, B₃ = 0.3°C.

(a) Find the periods of each mode if T₀ = 120 years.
(b) Calculate the total temperature variation.
(c) Determine the temperature at t = 200 years.
(d) Find when the modes constructively interfere.

---

## Problem 2: Biodiversity Prediction

A reserve has S = 300 species in A = 50 km². Use phi-biodiversity law S = S₀ × A^(1/φ).

(a) Find S₀/A₀.
(b) Predict species count for 200 km².
(c) Calculate the standard model prediction (exponent 0.25).
(d) Determine the area needed for 1,000 species.

---

## Problem 3: Carbon Cycle Modeling

CO₂ is currently 410 ppm. τ_carbon = 350 years. K_carbon = 1200 ppm.

(a) Find CO₂ in 100 years (without saturation).
(b) Calculate with saturation included.
(c) Determine when CO₂ reaches 600 ppm.
(d) Find the equilibrium CO₂ level.

---

## Problem 4: Pollution Dispersion

A source emits at C₀ = 80 units. R_atm = 12 km.

(a) Find concentration at 4 km, 8 km, and 16 km.
(b) Calculate the total mass in zone 0-8 km.
(c) Determine the distance where C drops below 5 units.
(d) Compare with 1/r decay model.

---

## Problem 5: Sustainability Assessment

A fishery has R = 800 tons/year. Current extraction E = 600 tons/year.

(a) Find the optimal extraction rate E_opt.
(b) Calculate the sustainability index SI.
(c) Determine the extraction reduction needed for SI = 1.0.
(d) Find the depletion time if E = 900 tons/year.

---

## Problem 6: Ecosystem Balance

An ecosystem has 4 species with r = [0.9, 0.7, 0.5, 0.3] and r_max = 0.9.

(a) Check the phi-balance condition.
(b) Calculate the product Π (r_i/r_max)^(1/φ^i).
(c) Determine the deviation from balance.
(d) Find which species adjustment would most improve balance.

---

## Problem 7: Ocean Acidification

pH dropped from 8.12 to 8.05 in 40 years. τ_acidification = 250 years.

(a) Find ΔpH.
(b) Predict pH in 80 years.
(c) Determine when pH drops below 7.8.
(d) Calculate the acidification rate at t = 100 years.

---

## Problem 8: Renewable Energy Adoption

Renewables provide 20% of electricity. F_max = 90%. τ_adopt = 12 years.

(a) Find adoption in 10, 20, and 30 years.
(b) Determine when adoption reaches 50%.
(c) Calculate the adoption rate at t = 15 years.
(d) Compare with standard logistic model.

---

## Problem 9: Water Quality

A river has Σ C/C_th = 1.5 total pollutant load.

(a) Find the water quality index WQ.
(b) Classify the water quality.
(c) Determine the pollutant load for "Good" quality.
(d) Find the WQ if load doubles to 3.0.

---

## Problem 10: Planetary Boundaries

Four boundaries are at 50%, 70%, 90%, and 110% of critical values.

(a) Calculate each boundary's contribution to SOS.
(b) Find the total safe operating space.
(c) Determine which boundary is most critical.
(d) Find the reduction needed in the worst boundary for SOS > 0.5.

---

## Problem 11: Energy Return on Investment

Energy input E_in = 1.5 × E_optimal. Output E_out = 5 × E_in.

(a) Find the phi-EROI.
(b) Calculate the standard EROI.
(c) Determine the efficiency ratio.
(d) Find the breakeven E_in/E_optimal ratio.

---

## Problem 12: Air Quality Index

A city has pollutant load = 2.0 (relative to standard).

(a) Find the AQI using phi-model.
(b) Classify the air quality.
(c) Determine the load for "Moderate" quality.
(d) Calculate the health impact ratio.

---

## Problem 13: Aquifer Depletion

An aquifer starts at h₀ = 100 m. τ_aquifer = 80 years.

(a) Find water level at years 20, 40, and 80.
(b) Calculate the depletion rate at t = 40 years.
(c) Determine when the aquifer drops below 20 m.
(d) Find the recharge rate needed for sustainability.

---

## Problem 14: Particulate Dispersion

PM₂.₅ at source is 150 μg/m³. R_PM = 8 km.

(a) Find PM at 2 km, 4 km, and 8 km.
(b) Determine the WHO limit exceedance zone.
(c) Calculate the total population exposed (if density = 5,000/km²).
(d) Find the R_PM needed for WHO compliance at 4 km.

---

## Problem 15: Climate Adaptation

Sea level rise is 0.3m by 2050. Phi-design level = 0.3 × φ.

(a) Find the phi-design protection level.
(b) Calculate the standard protection level.
(c) Determine the cost ratio (phi vs standard).
(d) Find the additional risk reduction from phi-protection.

---

*End of PHI-ENVIRONMENTAL SCIENCE Problems*
