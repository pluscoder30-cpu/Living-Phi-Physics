# 07 — The Supergolden Ratio (ψ_s) | Intermediate Level

## Ages 13–16 | Algebraic Foundations

---

## 1. Definition

The supergolden ratio ψ_s is defined as the real root of:

```
x³ − x² − 1 = 0
```

Its decimal value is:

```
ψ_s ≈ 1.4655712318...
```

The supergolden ratio is the three-dimensional analogue of the golden ratio
in a different sense from the plastic number. While the plastic number satisfies
x³ − x − 1 = 0, the supergolden ratio satisfies x³ − x² − 1 = 0.

---

## 2. Algebraic Proof: ψ_s³ = ψ_s² + 1

**Claim:** ψ_s³ = ψ_s² + 1

**Proof:**

Since ψ_s satisfies x³ − x² − 1 = 0:

```
ψ_s³ − ψ_s² − 1 = 0
ψ_s³ = ψ_s² + 1  ✓
```

This is analogous to:
- φ² = φ + 1 (golden)
- ψ³ = ψ + 1 (plastic)
- ψ_s³ = ψ_s² + 1 (supergolden)

---

## 3. The Narayana Cows Sequence

The supergolden ratio is connected to the Narayana cows sequence:

```
N_c(0) = N_c(1) = N_c(2) = 1
N_c(n) = N_c(n−1) + N_c(n−3)  for n ≥ 3
```

First few terms:

```
N_c(0) = 1
N_c(1) = 1
N_c(2) = 1
N_c(3) = N_c(2) + N_c(0) = 2
N_c(4) = N_c(3) + N_c(1) = 3
N_c(5) = N_c(4) + N_c(2) = 4
N_c(6) = N_c(5) + N_c(3) = 6
N_c(7) = N_c(6) + N_c(4) = 9
N_c(8) = N_c(7) + N_c(5) = 13
N_c(9) = N_c(8) + N_c(6) = 19
N_c(10) = N_c(9) + N_c(7) = 28
N_c(11) = N_c(10) + N_c(8) = 41
N_c(12) = N_c(11) + N_c(9) = 60
```

**Theorem:** N_c(n+1)/N_c(n) → ψ_s as n → ∞.

**Proof sketch:** Assume N_c(n+1)/N_c(n) → L. Then:

```
N_c(n+1) = N_c(n) + N_c(n−2)

N_c(n+1)/N_c(n) = 1 + N_c(n−2)/N_c(n)

As n → ∞: L = 1 + 1/L²

Multiply by L²: L³ = L² + 1
               L³ − L² − 1 = 0

Positive root: L = ψ_s  ✓
```

---

## 4. Conjugate Roots

The three roots of x³ − x² − 1 = 0 are:

```
x₁ = ψ_s ≈ 1.465571  (real)
x₂ ≈ −0.2328 + 0.7926i  (complex)
x₃ ≈ −0.2328 − 0.7926i  (complex conjugate)
```

The complex roots have magnitude:

```
|x₂| = |x₃| ≈ 0.8263
```

Since |x₂|, |x₃| < 1, ψ_s is also a Pisot number.

---

## 5. Powers of ψ_s

Using ψ_s³ = ψ_s² + 1:

```
ψ_s⁴ = ψ_s · ψ_s³ = ψ_s(ψ_s² + 1) = ψ_s³ + ψ_s
     = (ψ_s² + 1) + ψ_s = ψ_s² + ψ_s + 1

ψ_s⁵ = ψ_s · ψ_s⁴ = ψ_s(ψ_s² + ψ_s + 1) = ψ_s³ + ψ_s² + ψ_s
     = (ψ_s² + 1) + ψ_s² + ψ_s = 2ψ_s² + ψ_s + 1

ψ_s⁶ = ψ_s · ψ_s⁵ = ψ_s(2ψ_s² + ψ_s + 1) = 2ψ_s³ + ψ_s² + ψ_s
     = 2(ψ_s² + 1) + ψ_s² + ψ_s = 3ψ_s² + ψ_s + 2
```

General pattern: ψ_sⁿ = aₙψ_s² + bₙψ_s + cₙ.

---

## 6. Reciprocal Identity

From ψ_s³ = ψ_s² + 1, divide by ψ_s³:

```
1 = 1/ψ_s + 1/ψ_s³
```

Or: 1/ψ_s = 1 − 1/ψ_s³.

Also: 1/ψ_s = ψ_s² − ψ_s = ψ_s(ψ_s − 1).

**Proof:**

```
ψ_s³ = ψ_s² + 1
ψ_s³ − ψ_s² = 1
ψ_s²(ψ_s − 1) = 1
1/ψ_s² = ψ_s − 1
1/ψ_s = ψ_s²(ψ_s − 1)/ψ_s = ψ_s(ψ_s − 1)  ✓
```

---

## 7. Continued Fraction

The supergolden ratio has the continued fraction:

```
ψ_s = [1; 2, 3, 1, 5, 1, 1, 1, 1, 1, 1, 13, ...]
```

This is not periodic, reflecting the cubic minimal polynomial.

---

## 8. Connection to Fibonacci and Padovan

The supergolden ratio sits between φ and ψ in several ways:

```
φ  ≈ 1.618034  (golden)
ψ_s ≈ 1.465571  (supergolden)
ψ  ≈ 1.324718  (plastic)

Fibonacci base: φ² = φ + 1
Supergolden:    ψ_s³ = ψ_s² + 1
Plastic:        ψ³ = ψ + 1
```

The supergolden ratio interpolates between the golden and plastic ratios.

---

## 9. Geometric Significance

The supergolden ratio governs the proportions of a "supergolden rectangle":
a rectangle where removing a square leaves a rectangle similar to the original
but with a different similarity ratio than the golden rectangle.

```
Golden rectangle: length/width = φ, removing square leaves 1/φ × 1
Supergolden rectangle: length/width = ψ_s, removing square leaves 
                      a rectangle with ratio related to ψ_s
```

---

## 10. Worked Problems

### Problem 1: Verify ψ_s³ = ψ_s² + 1

**Question:** Compute ψ_s³ and ψ_s² + 1 to 6 decimal places.

**Solution:**

```
ψ_s ≈ 1.465571

ψ_s² = (1.465571)² ≈ 2.147899

ψ_s² + 1 ≈ 3.147899

ψ_s³ = (1.465571)³ ≈ 3.147899

ψ_s³ = ψ_s² + 1 ≈ 3.147899  ✓
```

---

### Problem 2: Compute ψ_s⁴

**Question:** Express ψ_s⁴ in terms of lower powers.

**Solution:**

```
ψ_s⁴ = ψ_s² + ψ_s + 1
     ≈ 2.147899 + 1.465571 + 1
     ≈ 4.613470
```

---

### Problem 3: Narayana cows ratio

**Question:** Compute N_c(10)/N_c(9) and compare to ψ_s.

**Solution:**

```
N_c(10) = 28,  N_c(9) = 19
N_c(10)/N_c(9) = 28/19 ≈ 1.473684

ψ_s ≈ 1.465571

Difference: |1.473684 − 1.465571| ≈ 0.008113
```

---

### Problem 4: Solve x³ − x² − 1 = 0 numerically

**Question:** Use Newton's method to find ψ_s to 4 decimal places, starting
with x₀ = 1.5.

**Solution:**

```
f(x) = x³ − x² − 1
f'(x) = 3x² − 2x

x₀ = 1.5
f(1.5) = 3.375 − 2.25 − 1 = 0.125
f'(1.5) = 6.75 − 3 = 3.75
x₁ = 1.5 − 0.125/3.75 ≈ 1.4667

x₁ = 1.4667
f(1.4667) = 3.155 − 2.151 − 1 = 0.004
f'(1.4667) = 6.452 − 2.933 = 3.519
x₂ = 1.4667 − 0.004/3.519 ≈ 1.4656

ψ_s ≈ 1.4656
```

---

### Problem 5: Compare ψ_s and φ

**Question:** Which is larger, ψ_s or φ?

**Solution:**

```
ψ_s ≈ 1.465571
φ  ≈ 1.618034

ψ_s < φ

The supergolden ratio is smaller than the golden ratio.
```

---

### Problem 6: Express 1/ψ_s

**Question:** Find 1/ψ_s in terms of ψ_s.

**Solution:**

```
From ψ_s³ = ψ_s² + 1:
ψ_s³ − ψ_s² = 1
ψ_s²(ψ_s − 1) = 1
1/ψ_s² = ψ_s − 1

Also: 1/ψ_s = ψ_s² − ψ_s (dividing ψ_s³ = ψ_s² + 1 by ψ_s²)
```

Check: ψ_s² − ψ_s ≈ 2.148 − 1.466 ≈ 0.682
       1/ψ_s ≈ 0.682 ✓

---

### Problem 7: Supergolden spiral

**Question:** If a spiral grows by factor ψ_s every quarter turn, what is the
growth factor after a full turn?

**Solution:**

```
Growth per quarter turn: ψ_s
Growth per full turn (4 quarter turns): ψ_s⁴

ψ_s⁴ = ψ_s² + ψ_s + 1 ≈ 4.613
```

Compare: golden spiral grows by φ⁴ ≈ 6.854 per full turn.

---

### Problem 8: Narayana cows number

**Question:** Use the Binet-like formula concept to estimate N_c(15).

**Solution:**

```
N_c(n) ≈ a · ψ_sⁿ for large n

N_c(12) = 60
ψ_s³ ≈ 3.148

N_c(15) ≈ N_c(12) × ψ_s³ ≈ 60 × 3.148 ≈ 189

Exact: N_c(15) = N_c(14) + N_c(12)
       N_c(13) = 60 + 28 = 88
       N_c(14) = 88 + 41 = 129
       N_c(15) = 129 + 60 = 189  ✓
```

---

### Problem 9: Product of conjugate magnitudes

**Question:** The conjugate roots of x³ − x² − 1 = 0 have magnitude ≈ 0.8263.
What is the product of all three roots?

**Solution:**

```
By Vieta's formulas for x³ − x² − 1 = 0:
Product of roots = −(constant term)/(leading coefficient) = −(−1)/1 = 1

ψ_s × |x₂| × |x₃| = 1
1.4656 × (0.8263)² ≈ 1.4656 × 0.6828 ≈ 1.000  ✓
```

---

### Problem 10: Pisot convergence

**Question:** Compute ψ_sⁿ for n = 1, ..., 8 and compare with nearest integers.

**Solution:**

```
n  | ψ_sⁿ     | Nearest int | Difference
---|----------|-------------|----------
1  | 1.4656   | 1           | 0.4656
2  | 2.1479   | 2           | 0.1479
3  | 3.1479   | 3           | 0.1479
4  | 4.6135   | 5           | −0.3865
5  | 6.7619   | 7           | −0.2381
6  | 9.9104   | 10          | −0.0896
7  | 14.524   | 15          | −0.476
8  | 21.287   | 21          | 0.287
```

The Pisot property means ψ_sⁿ is close to integers but converges to the
Narayana cows sequence, not to integers in general.

---

### Problem 11: The minimal polynomial for ψ_s²

**Question:** Find a polynomial satisfied by y = ψ_s².

**Solution:**

```
ψ_s³ = ψ_s² + 1
y^(3/2) = y + 1

Let z = y^(1/2) = ψ_s:
z³ = z² + 1  (known)

From ψ_s³ − ψ_s² = 1:
ψ_s²(ψ_s − 1) = 1
y(√y − 1) = 1
y^(3/2) − y = 1
y^(3/2) = y + 1

Square both sides: y³ = y² + 2y + 1
y³ − y² − 2y − 1 = 0

So ψ_s² satisfies y³ − y² − 2y − 1 = 0.
```

---

### Problem 12: Compare all three cubic roots

**Question:** For the equations x³ − x − 1 = 0 (plastic) and x³ − x² − 1 = 0
(supergolden), which has the larger real root?

**Solution:**

```
Plastic: ψ ≈ 1.324718
Supergolden: ψ_s ≈ 1.465571

ψ_s > ψ

The supergolden ratio is larger than the plastic number.
```

---

### Problem 13: A supergolden identity

**Question:** Prove that ψ_s⁴ = ψ_s³ + ψ_s.

**Solution:**

```
ψ_s⁴ = ψ_s · ψ_s³
     = ψ_s(ψ_s² + 1)
     = ψ_s³ + ψ_s
     = (ψ_s² + 1) + ψ_s
     = ψ_s² + ψ_s + 1

Wait, that gives ψ_s² + ψ_s + 1, not ψ_s³ + ψ_s.

Let me recheck:
ψ_s³ + ψ_s = (ψ_s² + 1) + ψ_s = ψ_s² + ψ_s + 1

And ψ_s⁴ = ψ_s² + ψ_s + 1 (from the power reduction)

So ψ_s⁴ = ψ_s³ + ψ_s ✓
```

---

### Problem 14: Geometric interpretation

**Question:** If a rectangle has length ψ_s and width 1, and you remove a
1×1 square, what are the dimensions of the remaining rectangle?

**Solution:**

```
Original: ψ_s × 1 ≈ 1.466 × 1
Remove 1×1 square from the left.

Remaining: (ψ_s − 1) × 1 ≈ 0.466 × 1

The ratio of the remaining rectangle: 1/(ψ_s − 1)
From ψ_s²(ψ_s − 1) = 1: 1/(ψ_s − 1) = ψ_s² ≈ 2.148

So the remaining rectangle has ratio ψ_s² : 1, not ψ_s : 1.
This is different from the golden rectangle, where removing a square
leaves a rectangle with the SAME ratio.
```

---

### Problem 15: Connection to tribonacci

**Question:** The tribonacci sequence T(n) = T(n−1) + T(n−2) + T(n−3) has
a characteristic equation x³ − x² − x − 1 = 0. How does this relate to
the supergolden ratio?

**Solution:**

```
Tribonacci: x³ − x² − x − 1 = 0, real root ≈ 1.839
Supergolden: x³ − x² − 1 = 0, real root ≈ 1.466

They are different equations with different roots.

The tribonacci constant (≈ 1.839) is larger than ψ_s (≈ 1.466).

Both are Pisot numbers satisfying cubic equations, but they govern
different sequences:
- Tribonacci: each term is sum of ALL three previous terms
- Narayana cows: each term is sum of the FIRST and THIRD previous terms
```

---

## 11. Summary Table

| Property | Value |
|----------|-------|
| Definition | Root of x³ − x² − 1 = 0 |
| Decimal | 1.4655712318... |
| Identity | ψ_s³ = ψ_s² + 1 |
| Reciprocal | 1/ψ_s = ψ_s² − ψ_s |
| Sequence | Narayana cows |
| Pisot | Yes, conjugate magnitude ≈ 0.826 |
| Position | ψ < ψ_s < φ |

---

## 12. Key Takeaways for Ages 13–16

1. **ψ_s is algebraic:** It satisfies x³ − x² − 1 = 0.
2. **ψ_s³ = ψ_s² + 1:** The defining identity.
3. **Narayana cows sequence:** Grows as ψ_sⁿ.
4. **Pisot number:** ψ_sⁿ approaches integers (the Narayana cows sequence).
5. **Between ψ and φ:** 1.325 < 1.466 < 1.618.
6. **Different from tribonacci:** Tribonacci satisfies x³ − x² − x − 1 = 0.

---

*Next: 08_intermediate_fibonacci.md — The Fibonacci Ratio*
