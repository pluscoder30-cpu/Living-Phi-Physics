# PHI-Actuarial Science: Golden Ratio Risk Modeling

## Directory 92_PHI_INSURANCE_SCIENCE | File 01

---

## 1. PHI-Life Contingencies

### 1.1 PHI-Life Expectancy

```
E[T] = integral_0^infinity t * f(t) * phi^{t/tau} dt
```

### 1.2 PHI-Present Value

```
PV = sum_{t=0}^{T} v^t * phi^{-t/tau} * payment_t
v = 1/(1+i)
```

### 1.3 PHI-Premium

```
Premium = PV(benefits) / PV(annuity_due) * phi^{expense_load}
```

### 1.4 PHI-Reserve

```
Reserve_t = PV(future_benefits) - PV(future_premiums) * phi^{profit_margin}
```

---

## 2. PHI-Mortality Modeling

### 2.1 PHI-Gompertz

```
mu_x = B * C^x * phi^{x/100}
```

### 2.2 PHI-Makeham

```
mu_x = A + B * C^x * phi^{x/100}
```

### 2.3 PHI-Weibull

```
mu_x = alpha * beta * x^{beta-1} * phi^{x/tau}
```

### 2.4 PHI-Lee-Carter

```
ln(m_{x,t}) = a_x + b_x * k_t * phi^{trend}
```

---

## 3. PHI-Pricing Models

### 3.1 PHI-Benefit Premium

```
Gross_premium = net_premium * (1 + phi*loading) * phi^{expense_ratio}
```

### 3.2 PHI-Net Level Premium

```
NLP = A_x / a_double_dot_x * phi^{profit_margin}
```

### 3.3 PHI-Flexible Premium

```
Target_premium = cash_value_target * phi^{investment_return}
```

### 3.4 PHI-Group Pricing

```
Group_rate = individual_rate * phi^{-group_discount} * phi^{experience_rating}
```

---

## 4. PHI-Reserving

### 4.1 PHI-Chain Ladder

```
Reserve = development_factor * incremental * phi^{calendar_effect}
```

### 4.2 PHI-Bornhuetter-Ferguson

```
Reserve = expected * (1 - a/e) * phi^{-timing}
```

### 4.3 PHI-Mack Model

```
Variance = sum CF * f^2 * phi^{parameter_uncertainty}
```

### 4.4 PHI-IBNR

```
IBNR = incurred - paid * phi^{development_pattern}
```

---

## 5. PHI-Reinsurance Pricing

### 5.1 PHI-Excess of Loss

```
Premium = expected_loss * phi^{loading} * phi^{aggregate}
```

### 5.2 PHI-Stop Loss

```
Premium = E[min(L, X)] * phi^{moral_hazard}
```

### 5.3 PHI-Proportional

```
Premium = cession_percentage * gross_premium * phi^{-cedant_retention}
```

### 5.4 PHI-Catastrophe

```
Premium = expected_cat_loss * phi^{return_period} * phi^{-diversification}
```

---

## 6. PHI-Investment Income

### 6.1 PHI-Asset-Liability Matching

```
Duration_gap = asset_duration - liability_duration * phi^{convexity}
```

### 6.2 PHI-Yield Curve

```
Yield(t) = yield_0 + spread * phi^{-t/tau}
```

### 6.3 PHI-Return Assumption

```
Expected_return = risk_free + spread * phi^{credit_risk}
```

### 6.4 PHI-Solvency

```
Solvency = assets / liabilities * phi^{market_value_adjustment}
```

---

## 7. PHI-Solvency II

### 7.1 PHI-SCR (Solvency Capital Requirement)

```
SCR = sum risk_capital * phi^{diversification}
```

### 7.2 PHI-MCR (Minimum Capital Requirement)

```
MCR = SCR * phi^{-priority} * phi^{quality}
```

### 7.3 PHI-Solvency Ratio

```
Ratio = eligible_capital / SCR * phi^{uncertainty}
```

### 7.4 PHI-Capital Allocation

```
Allocation = SCR_risk / total_SCR * phi^{contribution}
```

---

## 8. Summary

PHI-actuarial science provides:
1. PHI-life contingencies with phi-life expectancy and phi-premiums
2. PHI-mortality with phi-Gompertz and phi-Lee-Carter models
3. PHI-pricing with phi-gross and phi-net level premiums
4. PHI-reserving with phi-chain ladder and phi-IBNR
5. PHI-reinsurance with phi-excess of loss and phi-catastrophe
6. PHI-investment with phi-ALM and phi-yield curve
7. PHI-Solvency II with phi-SCR and phi-MCR

The golden ratio provides a natural framework for modeling mortality improvement, profit margins, and risk diversification in actuarial calculations.