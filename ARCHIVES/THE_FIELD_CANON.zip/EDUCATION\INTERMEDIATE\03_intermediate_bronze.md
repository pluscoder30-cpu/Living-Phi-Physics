# 03 — The Bronze Ratio (δ_b) | Intermediate Level

## Ages 13–16 | Algebraic Foundations

---

## 1. Definition

The bronze ratio δ_b is defined as:

```
δ_b = (3 + √13) / 2 ≈ 3.3027756377...
```

It is the third metallic mean, after the golden (φ) and silver (δₛ) ratios.
The metallic means are a family: each one is the positive root of
x² − nx − 1 = 0 for n = 1, 2, 3, ...

```
n = 1: x² − x − 1 = 0  →  φ = (1 + √5)/2   (golden)
n = 2: x² − 2x − 1 = 0  →  δₛ = 1 + √2      (silver)
n = 3: x² − 3x − 1 = 0  →  δ_b = (3 + √13)/2 (bronze)
```

---

## 2. Algebraic Proof: δ_b² = 3δ_b + 1

**Claim:** δ_b² = 3δ_b + 1

**Proof:**

Let δ_b = (3 + √13) / 2.

```
δ_b² = ((3 + √13) / 2)²
     = (9 + 6√13 + 13) / 4
     = (22 + 6√13) / 4
     = (11 + 3√13) / 2
```

Now compute 3δ_b + 1:

```
3δ_b + 1 = 3(3 + √13)/2 + 1
         = (9 + 3√13)/2 + 1
         = (9 + 3√13 + 2) / 2
         = (11 + 3√13) / 2
```

Since both sides equal (11 + 3√13)/2, we have δ_b² = 3δ_b + 1. ∎

---

## 3. The Conjugate

The conjugate of δ_b is:

```
δ_b* = (3 − √13) / 2 ≈ −0.3027756377...
```

Key properties:

```
δ_b · δ_b* = (3 + √13)(3 − √13) / 4
           = (9 − 13) / 4
           = −4/4 = −1

δ_b + δ_b* = (3 + √13 + 3 − √13) / 2 = 6/2 = 3

δ_b − δ_b* = (3 + √13 − 3 + √13) / 2 = 2√13/2 = √13
```

Also: δ_b* = −1/δ_b, since δ_b · δ_b* = −1.

---

## 4. The Narayana Sequence

The bronze ratio is connected to the Narayana sequence (sometimes called the
"bronze Fibonacci"):

```
N(0) = 0,  N(1) = 1
N(n) = 3·N(n−1) + N(n−2)
```

First few terms:

```
N(0) = 0
N(1) = 1
N(2) = 3·1 + 0 = 3
N(3) = 3·3 + 1 = 10
N(4) = 3·10 + 3 = 33
N(5) = 3·33 + 10 = 109
N(6) = 3·109 + 33 = 360
N(7) = 3·360 + 109 = 1189
N(8) = 3·1189 + 360 = 3927
```

**Theorem:** N(n+1)/N(n) → δ_b as n → ∞.

**Proof sketch:**

```
N(n+1) = 3·N(n) + N(n−1)
N(n+1)/N(n) = 3 + N(n−1)/N(n)

As n → ∞: L = 3 + 1/L
            L² = 3L + 1
            L² − 3L − 1 = 0

By the quadratic formula: L = (3 ± √(9+4)) / 2 = (3 ± √13) / 2

Taking positive root: L = (3 + √13)/2 = δ_b  ✓
```

---

## 5. Binet-like Formula for Narayana Numbers

The nth Narayana number can be computed directly:

```
N(n) = (δ_bⁿ − (δ_b*)ⁿ) / √13
     = (δ_bⁿ − (−1/δ_b)ⁿ) / √13
```

**Example: N(5)**

```
δ_b⁵ ≈ 3.3028⁵ ≈ 393.6
(δ_b*)⁵ ≈ (−0.3028)⁵ ≈ −0.0026

N(5) = (393.6 − (−0.0026)) / √13
     = 393.6026 / 3.6056
     ≈ 109  ✓
```

---

## 6. Continued Fraction of δ_b

The bronze ratio has a continued fraction:

```
δ_b = 3 + 1/(1 + 1/(1 + 1/(6 + 1/(1 + 1/(1 + 1/(6 + ...))))))
```

The pattern of partial quotients is [3; 1, 1, 6, 1, 1, 6, ...], repeating
with period 3.

This is more complex than the continued fractions of φ ([1; 1, 1, ...])
and δₛ ([2; 2, 2, ...]).

---

## 7. Powers of δ_b

Using δ_b² = 3δ_b + 1, we reduce powers:

```
δ_b³ = δ_b · δ_b² = δ_b(3δ_b + 1) = 3δ_b² + δ_b
     = 3(3δ_b + 1) + δ_b = 9δ_b + 3 + δ_b = 10δ_b + 3

δ_b⁴ = δ_b · δ_b³ = δ_b(10δ_b + 3) = 10δ_b² + 3δ_b
     = 10(3δ_b + 1) + 3δ_b = 30δ_b + 10 + 3δ_b = 33δ_b + 10
```

Pattern: δ_bⁿ = N(n)·δ_b + N(n−1), where N(n) is the nth Narayana number.

```
δ_b² = 3δ_b + 1      (N(2)=3, N(1)=1)
δ_b³ = 10δ_b + 3     (N(3)=10, N(2)=3)
δ_b⁴ = 33δ_b + 10    (N(4)=33, N(3)=10)
```

---

## 8. The Metallic Means Family

| Mean | Symbol | n | Equation | Value |
|------|--------|---|----------|-------|
| Golden | φ | 1 | x² − x − 1 = 0 | 1.618... |
| Silver | δₛ | 2 | x² − 2x − 1 = 0 | 2.414... |
| Bronze | δ_b | 3 | x² − 3x − 1 = 0 | 3.303... |

General metallic mean: M_n = (n + √(n² + 4)) / 2

All satisfy: M_n² = n·M_n + 1

All have conjugate: M_n* = (n − √(n² + 4)) / 2 = −1/M_n

---

## 9. Connection to √13

Since δ_b = (3 + √13)/2:

```
√13 = 2δ_b − 3
```

**Proof:**
```
2δ_b − 3 = 2(3 + √13)/2 − 3
         = (3 + √13) − 3
         = √13  ✓
```

---

## 10. Worked Problems

### Problem 1: Find δ_b²

**Question:** Compute δ_b² exactly.

**Solution:**

```
δ_b² = 3δ_b + 1
     = 3(3 + √13)/2 + 1
     = (9 + 3√13)/2 + 1
     = (9 + 3√13 + 2) / 2
     = (11 + 3√13) / 2
     ≈ (11 + 3(3.6056)) / 2
     ≈ (11 + 10.8168) / 2
     ≈ 10.9084
```

---

### Problem 2: Find 1/δ_b

**Question:** Express 1/δ_b in simplest form.

**Solution:**

```
1/δ_b = 2/(3 + √13)
      = 2(3 − √13) / ((3 + √13)(3 − √13))
      = 2(3 − √13) / (9 − 13)
      = 2(3 − √13) / (−4)
      = (√13 − 3) / 2
      ≈ (3.6056 − 3) / 2
      ≈ 0.3028
```

Note: 1/δ_b = δ_b − 3.

---

### Problem 3: Narayana number ratio

**Question:** Compute N(5)/N(4) and compare to δ_b.

**Solution:**

```
N(5) = 109,  N(4) = 33
N(5)/N(4) = 109/33 ≈ 3.303030

δ_b ≈ 3.302776

Difference: |3.303030 − 3.302776| ≈ 0.000254
```

---

### Problem 4: Solve x² − 3x − 1 = 0

**Question:** Find both roots.

**Solution:**

```
x = (3 ± √(9 + 4)) / 2
  = (3 ± √13) / 2

x₁ = (3 + √13)/2 ≈ 3.303  (bronze ratio)
x₂ = (3 − √13)/2 ≈ −0.303
```

---

### Problem 5: Compute δ_b³

**Question:** Express δ_b³ in the form aδ_b + b.

**Solution:**

```
δ_b³ = 10δ_b + 3
     = 10(3 + √13)/2 + 3
     = 5(3 + √13) + 3
     = 15 + 5√13 + 3
     = 18 + 5√13
     ≈ 18 + 5(3.6056)
     ≈ 36.028
```

---

### Problem 6: Express √13 using δ_b

**Question:** Write √13 in terms of δ_b.

**Solution:**

```
δ_b = (3 + √13)/2
2δ_b = 3 + √13
√13 = 2δ_b − 3
```

---

### Problem 7: The conjugate relationship

**Question:** Verify that δ_b − 1/δ_b = 3.

**Solution:**

```
δ_b − 1/δ_b = δ_b − (δ_b − 3)    [since 1/δ_b = δ_b − 3]
            = 3  ✓
```

Alternatively:
```
δ_b − 1/δ_b = (3 + √13)/2 − (√13 − 3)/2
            = (3 + √13 − √13 + 3) / 2
            = 6/2 = 3  ✓
```

---

### Problem 8: Bronze rectangle

**Question:** A bronze rectangle has width 6. What is its length?

**Solution:**

```
Length = δ_b × width
       = (3 + √13)/2 × 6
       = 3(3 + √13)
       = 9 + 3√13
       ≈ 9 + 10.817
       ≈ 19.817
```

---

### Problem 9: Narayana number via formula

**Question:** Use the Binet-like formula to compute N(3).

**Solution:**

```
N(3) = (δ_b³ − (δ_b*)³) / √13

δ_b³ ≈ 36.028
(δ_b*)³ ≈ (−0.3028)³ ≈ −0.0278

N(3) = (36.028 + 0.0278) / √13
     = 36.056 / 3.6056
     ≈ 10  ✓
```

---

### Problem 10: Compare δ_b with φ and δₛ

**Question:** Order φ, δₛ, and δ_b from smallest to largest.

**Solution:**

```
φ  ≈ 1.618034
δₛ ≈ 2.414214
δ_b ≈ 3.302776

Order: φ < δₛ < δ_b
```

Each metallic mean increases as n increases: M_n = (n + √(n² + 4))/2 grows
with n.

---

### Problem 11: Bronze ratio and the number 13

**Question:** The bronze ratio involves √13. What is special about the equation
x² − 3x − 1 = 0 compared to x² − x − 1 = 0?

**Solution:**

```
x² − x − 1 = 0  → discriminant = 1 + 4 = 5   → φ = (1 + √5)/2
x² − 2x − 1 = 0 → discriminant = 4 + 4 = 8   → δₛ = (2 + √8)/2
x² − 3x − 1 = 0 → discriminant = 9 + 4 = 13  → δ_b = (3 + √13)/2

General: x² − nx − 1 = 0 → discriminant = n² + 4
```

The discriminants are 5, 8, 13, 20, 29, ... following n² + 4.

---

### Problem 12: Continued fraction convergents

**Question:** Find the first 3 convergents of δ_b = [3; 1, 1, 6, ...].

**Solution:**

```
[3] = 3/1 = 3.000

[3; 1] = 3 + 1/1 = 4/1 = 4.000

[3; 1, 1] = 3 + 1/(1 + 1/1) = 3 + 1/2 = 7/2 = 3.500

δ_b ≈ 3.303

Convergents: 3, 4, 3.5, ...
```

---

### Problem 13: The general metallic mean formula

**Question:** For n = 4 (the "copper" mean), find the value.

**Solution:**

```
M_4 = (4 + √(16 + 4)) / 2
    = (4 + √20) / 2
    = (4 + 2√5) / 2
    = 2 + √5
    ≈ 2 + 2.236
    ≈ 4.236
```

Check: M_4² = (2 + √5)² = 4 + 4√5 + 5 = 9 + 4√5
       4M_4 + 1 = 4(2 + √5) + 1 = 8 + 4√5 + 1 = 9 + 4√5 ✓

---

### Problem 14: Product of metallic means

**Question:** Compute φ · δₛ.

**Solution:**

```
φ · δₛ = ((1 + √5)/2)(1 + √2)
       = (1 + √5)(1 + √2) / 2
       = (1 + √2 + √5 + √10) / 2
       ≈ (1 + 1.4142 + 2.2361 + 3.1623) / 2
       ≈ 7.8126 / 2
       ≈ 3.906
```

This is NOT one of the standard metallic means.

---

### Problem 15: A bronze spiral

**Question:** Starting with a rectangle of dimensions 1 × δ_b, add squares
to create a spiral. What are the dimensions after 2 additions?

**Solution:**

```
Start: 1 × δ_b rectangle (≈ 1 × 3.303)

Add a square of side δ_b:
New dimensions: δ_b × (1 + δ_b)
             = δ_b × (1 + (3 + √13)/2)
             = δ_b × (5 + √13)/2
             ≈ 3.303 × 4.303
             ≈ 14.211

Add a square of side (1 + δ_b):
New dimensions: (1 + δ_b) × (δ_b + 1 + δ_b)
             = (1 + δ_b) × (1 + 2δ_b)
             ≈ 4.303 × 7.606
             ≈ 32.735
```

The spiral grows faster than the golden spiral because δ_b > φ.

---

## 11. Summary Table

| Property | Value |
|----------|-------|
| Definition | δ_b = (3 + √13)/2 |
| Decimal | 3.3027756377... |
| Polynomial | x² − 3x − 1 = 0 |
| Identity | δ_b² = 3δ_b + 1 |
| Conjugate | δ_b* = (3 − √13)/2 |
| Reciprocal | 1/δ_b = δ_b − 3 |
| Subtraction | δ_b − 1/δ_b = 3 |
| Narayana seq. | N(n+1)/N(n) → δ_b |
| √13 | √13 = 2δ_b − 3 |

---

## 12. Key Takeaways for Ages 13–16

1. **δ_b is algebraic:** Positive root of x² − 3x − 1 = 0.
2. **δ_b² = 3δ_b + 1:** Same pattern as φ and δₛ but with n = 3.
3. **Narayana numbers:** The bronze-ratio analogue of Fibonacci numbers.
4. **Metallic means family:** φ (n=1), δₛ (n=2), δ_b (n=3), and beyond.
5. **1/δ_b = δ_b − 3:** Each metallic mean satisfies 1/M = M − n.
6. **√13 appears:** The bronze ratio is the "n = 3" case with discriminant 13.

---

*Next: 04_intermediate_harmonic.md — The Harmonic Ratio*
