# 13 — Intermediate Answer Key

## Complete Solutions to 150 Practice Problems

---

## Problems 1–15: Basic Definitions

1. [PHI] phi^2 = phi + 1 = 1.618 + 1 = 2.618
2. [SIL] delta_s^2 = 2*delta_s + 1 = 2(2.414) + 1 = 5.828
3. [BRZ] delta_b^2 = 3*delta_b + 1 = 3(3.303) + 1 = 10.908
4. [HAR] Perfect fifth = 2^(7/12) = 1.498
5. [LIV] B'/B = (1000/10)^(3/4) = 100^(3/4) = 31.62
6. [PLA] psi^3 = (1.324718)^3 = 2.324718 = psi + 1 (check)
7. [SUP] psi_s^3 = (1.465571)^3 = 3.147899 = psi_s^2 + 1 (check)
8. [FIB] F(10) = 55
9. [LUC] L(10) = 123
10. [PAD] P(10) = 12
11. [KEP] Golden angle = 360/phi^2 = 137.508 degrees
12. [PHI] x = (1+sqrt(5))/2 = phi = 1.618
13. [SIL] x = (2+sqrt(8))/2 = 1+sqrt(2) = 2.414
14. [BRZ] x = (3+sqrt(13))/2 = 3.303
15. [HAR] 12 semitones

---

## Problems 16–30: Identities and Proofs

16. [PHI] 1/phi = (sqrt(5)-1)/2 = phi - 1
17. [SIL] 1/delta_s = sqrt(2)-1 = delta_s - 2
18. [BRZ] 1/delta_b = (sqrt(13)-3)/2 = delta_b - 3
19. [HAR] 2^(6/12) = 2^(1/2) = sqrt(2)
20. [LIV] A/V = 3/r, which decreases as r increases
21. [PLA] 1/psi = psi^2 - 1
22. [SUP] 1/psi_s = psi_s^2 - psi_s
23. [FIB] F(n-1)*F(n+1) - F(n)^2 = (-1)^n
24. [LUC] L(n) = F(n-1) + F(n+1)
25. [PAD] P(n) = P(n-2) + P(n-3)
26. [KEP] T^2 = k*a^3
27. [PHI] phi - 1/phi = phi - (phi-1) = 1
28. [SIL] delta_s - 1/delta_s = delta_s - (delta_s-2) = 2
29. [BRZ] delta_b - 1/delta_b = delta_b - (delta_b-3) = 3
30. [HAR] H = 2*2*8/(2+8) = 32/10 = 3.2

---

## Problems 31–45: Sequences

31. [FIB] After 89: 144, 233, 377, 610, 987
32. [LUC] After 47: 76, 123, 199, 322, 521
33. [PAD] After 28: 37, 49, 65, 86, 114
34. [PHI] F(12)/F(11) = 144/89 = 1.61798
35. [SIL] P_ell(8)/P_ell(7) = 408/169 = 2.41420
36. [BRZ] N(6)/N(5) = 360/109 = 3.30275
37. [LIV] P(5) = 1000/(1+9*e^(-1.5)) = 1000/(1+9*0.2231) = 1000/3.008 = 332
38. [PLA] psi^6 = psi^2 + 2*psi + 1 = 5.404
39. [SUP] psi_s^5 = 2*psi_s^2 + psi_s + 1 = 6.762
40. [FIB] F(8) = (phi^8 - psi^8)/sqrt(5) = (46.979 - 0.021)/2.236 = 21
41. [LUC] L(8) = phi^8 + psi^8 = 46.979 + 0.021 = 47
42. [PAD] P(20) = a*psi^20 = 200 (exact: 200)
43. [HAR] C4=261.63, D4=293.66, E4=329.63, F4=349.23, G4=392.00, A4=440.00, B4=493.88, C5=523.25
44. [KEP] T_Venus = 8*365.25/13 = 224.8 days
45. [LIV] D = log(1000)/log(100) = 3/2 = 1.5

---

## Problems 46–60: Algebra

46. [PHI] phi^5 = 5*phi + 3
47. [SIL] delta_s^4 = 12*delta_s + 5
48. [BRZ] delta_b^4 = 33*delta_b + 10
49. [PLA] psi^5 = psi^2 + psi + 1
50. [SUP] psi_s^5 = 2*psi_s^2 + psi_s + 1
51. [PHI] phi^4 - 3*phi^2 + 1 = (3*phi+2) - 3*(phi+1) + 1 = 0
52. [SIL] delta_s^3 - 4*delta_s - 2 = (5*delta_s+2) - 4*delta_s - 2 = delta_s = 2.414
53. [FIB] Verified for n=1,2,3 (check)
54. [LUC] Verified for n=1,2,3 (check)
55. [PAD] P(20) = 200
56. [HAR] 440 * 2^(7/12) = 659.26 Hz (G4)
57. [KEP] Diagonal = phi * 4 = 6.472 cm
58. [LIV] N = epsilon^(-D) = 0.1^(-1.25) = 17.78
59. [PHI] x = 5*phi/(1+phi) = 5*phi/phi^2 = 5/phi = 3.090, y = 5/phi^2 = 1.910
60. [SIL] x = 7*delta_s/(1+delta_s) = 7*delta_s/(1+delta_s), y = 7/(1+delta_s)

---

## Problems 61–75: Geometry

61. [PHI] Length = 8*phi = 12.944
62. [SIL] Length = 6*delta_s = 14.485
63. [BRZ] Length = 5*delta_b = 16.514
64. [PHI] Diagonal = 10*phi = 16.180
65. [KEP] Face diagonal = 3*phi = 4.854
66. [KEP] Circumradius = 2*phi^2/2 = phi^2 = 2.618
67. [PLA] Dimensions: psi x 1 x 1/psi = 1.325 x 1 x 0.755
68. [LIV] A/V = 3/5 = 0.6 micrometers^(-1)
69. [HAR] Length = 100/2 = 50 cm (half the string for octave)
70. [PHI] Area = 1 * phi = 1.618
71. [SIL] Area = 1 * delta_s = 2.414
72. [FIB] Total area = 1+1+4+9+25+64 = 104
73. [PAD] Total area = 1+1+1+4+4+9 = 20
74. [BRZ] Area = 2 * (2*delta_b) = 4*delta_b = 13.211
75. [LIV] Tips = 2^6 = 64

---

## Problems 76–90: Number Theory

76. [FIB] gcd(F(12), F(18)) = F(gcd(12,18)) = F(6) = 8
77. [FIB] 50 = 34 + 13 + 3 = F(9) + F(7) + F(4)
78. [LUC] Primes: L(0)=2, L(2)=3, L(4)=7, L(5)=11, L(7)=29, L(8)=47, L(11)=199
79. [FIB] Pattern: O,O,E,O,O,E,... (period 3)
80. [PAD] Pattern: O,O,O,E,E,O,E,O,... (period 8)
81. [PHI] phi = [1; 1, 1, 1, 1, ...]
82. [SIL] delta_s = [2; 2, 2, 2, 2, ...]
83. [BRZ] delta_b = [3; 1, 1, 6, ...]
84. [PLA] psi = [1; 3, 12, 1, ...]
85. [HAR] |2^(4/12) - 5/4| * 1200/log(2) = 14 cents
86. [FIB] Primes: F(3)=2, F(4)=3, F(5)=5, F(7)=13, F(11)=89, F(13)=233
87. [LUC] S(0)=4, S(1)=14, S(2)=194 mod 127 = 67, S(3)=67^2-2=4487 mod 127 = 0 (prime)
88. [PAD] Primes: P(3)=2, P(4)=2, P(5)=3, P(7)=5, P(8)=7, P(14)=37
89. [LIV] D = 1.3
90. [KEP] cos(dihedral) = -1/sqrt(5) = -0.447

---

## Problems 91–105: Comparisons

91. psi(1.325) < psi_s(1.466) < phi(1.618) < delta_s(2.414) < delta_b(3.303)
92. Fibonacci grows faster: phi > psi (1.618 > 1.325)
93. Lucas grows faster by factor sqrt(5) = 2.236
94. Golden angle 137.508 is closer to 150
95. sqrt(2) = 1.414, phi = 1.618, 1.5 = 1.5; closest to 1.5
96. 2^n > Lucas > Fibonacci for large n
97. Icosahedron (20 faces)
98. Mouse has ~22x higher metabolic rate per kg
99. psi = 1.325, closer to 1.3
100. psi_s = 1.466, closer to 1.5
101. L(10)=123 > F(10)=55 > P(10)=12
102. phi is simpler (periodic [1;1,1,...]) vs psi (non-periodic)
103. F(10)=55 > L(8)=47
104. F(7)=13 > P(10)=12
105. 8/13=0.615, 1/phi=0.618, 1/2=0.5; closest to 1/phi

---

## Problems 106–120: Applications

106. [PHI] Width = sqrt(10/phi) = 2.472, Length = phi*width = 3.999
107. [SIL] Width = sqrt(12/delta_s) = 2.229, Length = delta_s*width = 5.382
108. [HAR] 330 * 2^(5/12) = 440 Hz (A4)
109. [LIV] N = 0.1^(-1.71) = 51.29
110. [PLA] Growth = psi^8 = (psi^3)^2 * psi^2 = (2.325)^2 * 1.755 = 9.48
111. [KEP] Position = 30 + 137.508 = 167.508 degrees
112. [FIB] Ratio = 55/34 = 1.6176 ~ phi
113. [LUC] F(10) = F(5)*L(5) = 5*11 = 55
114. [PAD] Perimeter = sum(1..5) + 2 = 1+1+1+2+2+3+4+5+2 = 21
115. [BRZ] Width = sqrt(20/delta_b) = 2.463, Length = delta_b*width = 8.129
116. [SUP] Growth = psi_s^12 = (psi_s^3)^4 = (3.148)^4 = 97.5
117. [LIV] Ratio = 2^10 = 1024
118. [HAR] A4=440, B4=493.88, C#5=554.37, D#5=622.25, E5=659.26, F#5=739.99, G#5=830.61, A5=880
119. [KEP] Volume = (5/12)*(3+sqrt(5))*a^3 = 55.63 (approx)
120. [PHI] Total area = 1+1+4+9+25+64+169 = 273

---

## Problems 121–135: Advanced

121. [PHI] F(1) = (phi-psi)/sqrt(5) = sqrt(5)/sqrt(5) = 1; F(2) = (phi^2-psi^2)/sqrt(5) = sqrt(5)/sqrt(5) = 1
122. [SIL] P(n) = ((1+sqrt(2))^n - (1-sqrt(2))^n) / (2*sqrt(2))
123. [BRZ] N(n) = (delta_b^n - delta_b*^n) / sqrt(13)
124. [PLA] psi^2 satisfies y^3 - 2y^2 + y - 1 = 0
125. [SUP] psi_s^2 satisfies y^3 - y^2 - 2y - 1 = 0
126. [FIB] gcd(F(6), F(9)) = gcd(8, 34) = 2 = F(3) = F(gcd(6,9))
127. [LUC] F(8) = F(4)*L(4) = 3*7 = 21
128. [PAD] Sum(P(0)..P(4)) = 7 = P(7)+P(6)-2 = 5+4-2 = 7
129. [HAR] 12-TET approximates 5-limit just intonation within 2 cents for most intervals
130. [LIV] Heat loss ~ A ~ M^(2/3), heat production ~ V ~ M; ratio ~ M^(-1/3); fractal correction gives M^(-1/4)
131. [KEP] F = GMm/r^2, centripetal = mv^2/r, Kepler's law follows
132. [PHI] M = [[1,1],[1,0]], M^n = [[F(n+1),F(n)],[F(n),F(n-1)]]
133. [SIL] M = [[2,1],[1,0]], M^n = [[P(n+1),P(n)],[P(n),P(n-1)]]
134. [BRZ] M = [[3,1],[1,0]], M^n = [[N(n+1),N(n)],[N(n),N(n-1)]]
135. [PLA] M = [[0,1,0],[0,0,1],[1,1,0]], M^n gives Padovan numbers

---

## Problems 136–150: Challenge

136. [PHI] phi's continued fraction [1;1,1,...] has the slowest convergence, making it hardest to approximate by rationals
137. [SIL] delta_s = [2;2,2,...] is the simplest periodic CF after phi
138. [BRZ] M_n^2 = n*M_n + 1 follows from x^2 - nx - 1 = 0
139. [HAR] 12-TET provides the best compromise across all keys within the 5-limit
140. [LIV] Fractal branching optimizes distribution; 3/4 power follows from space-filling networks
141. [PLA] psi is the smallest algebraic integer > 1 with all conjugates inside the unit circle
142. [SUP] Both are Pisot; psi has conjugates |x|~0.869, psi_s has |x|~0.826
143. [FIB] F(p) prime implies p prime (except F(4)=3); proof uses gcd property
144. [LUC] Direct substitution: (phi^n+psi^n) = (phi^(n-1)+psi^(n-1)) + (phi^(n-2)+psi^(n-2))
145. [PAD] P(n) ~ a*psi^n because |x2|,|x3| < 1 terms vanish
146. [KEP] Pentagon faces have diagonal/edge = phi; vertex coordinates use (0, +/-1, +/-phi)
147. [PHI] Fibonacci spiral arcs have radii F(n); golden spiral has constant ratio phi
148. [HAR] 2^(6/12) = sqrt(2); 12/2 = 6 semitones divides octave exactly in half
149. [LIV] Coastlines are curves (D between 1 and 2), never fill a 2D region
150. [SUP] Growth rates: phi(1.618) > delta_s(2.414) > tau(1.839) > psi_s(1.466) > psi(1.325); each sequence has distinct recurrence

---

## Detailed Solutions: Problems 1–15

### Problem 1: phi^2
```
phi^2 = phi + 1 = 1.618034 + 1 = 2.618034
Exact: (3 + sqrt(5))/2 = 2.618034
```

### Problem 2: delta_s^2
```
delta_s^2 = 2*delta_s + 1 = 2(2.414214) + 1 = 5.828427
Exact: 3 + 2*sqrt(2) = 5.828427
```

### Problem 3: delta_b^2
```
delta_b^2 = 3*delta_b + 1 = 3(3.302776) + 1 = 10.908327
Exact: (11 + 3*sqrt(13))/2 = 10.908327
```

### Problem 4: Perfect fifth
```
Perfect fifth = 7 semitones = 2^(7/12) = 1.498307
Just intonation: 3/2 = 1.500000
Difference: 2 cents
```

### Problem 5: Metabolic scaling
```
B'/B = (M'/M)^(3/4) = (1000/10)^(3/4) = 100^(3/4)
100^(3/4) = (100^(1/4))^3 = (3.1623)^3 = 31.623
```

### Problem 6: psi^3
```
psi = 1.324718
psi^3 = 1.324718^3 = 2.324718
psi + 1 = 1.324718 + 1 = 2.324718
Match: psi^3 = psi + 1
```

### Problem 7: psi_s^3
```
psi_s = 1.465571
psi_s^3 = 1.465571^3 = 3.147899
psi_s^2 + 1 = 2.147899 + 1 = 3.147899
Match: psi_s^3 = psi_s^2 + 1
```

### Problem 8: F(10)
```
F(1)=1, F(2)=1, F(3)=2, F(4)=3, F(5)=5
F(6)=8, F(7)=13, F(8)=21, F(9)=34, F(10)=55
```

### Problem 9: L(10)
```
L(0)=2, L(1)=1, L(2)=3, L(3)=4, L(4)=7
L(5)=11, L(6)=18, L(7)=29, L(8)=47, L(9)=76, L(10)=123
```

### Problem 10: P(10)
```
P(0)=1, P(1)=1, P(2)=1, P(3)=2, P(4)=2
P(5)=3, P(6)=4, P(7)=5, P(8)=7, P(9)=9, P(10)=12
```

### Problem 11: Golden angle
```
Golden angle = 360/phi^2 = 360/(phi+1) = 360/2.618 = 137.508 degrees
```

### Problem 12: x^2 - x - 1 = 0
```
x = (1 + sqrt(1+4))/2 = (1 + sqrt(5))/2 = phi = 1.618034
```

### Problem 13: x^2 - 2x - 1 = 0
```
x = (2 + sqrt(4+4))/2 = (2 + sqrt(8))/2 = 1 + sqrt(2) = 2.414214
```

### Problem 14: x^2 - 3x - 1 = 0
```
x = (3 + sqrt(9+4))/2 = (3 + sqrt(13))/2 = 3.302776
```

### Problem 15: Semitones in octave
```
2^(n/12) = 2 => n/12 = 1 => n = 12 semitones
```

---

## Detailed Solutions: Problems 16–30

### Problem 16: 1/phi = phi - 1
```
1/phi = 2/(1+sqrt(5)) = 2(sqrt(5)-1)/((1+sqrt(5))(sqrt(5)-1))
      = 2(sqrt(5)-1)/(5-1) = (sqrt(5)-1)/2
phi - 1 = (1+sqrt(5))/2 - 1 = (sqrt(5)-1)/2
Therefore 1/phi = phi - 1
```

### Problem 17: 1/delta_s = delta_s - 2
```
1/delta_s = 1/(1+sqrt(2)) = (sqrt(2)-1)/((1+sqrt(2))(sqrt(2)-1))
          = (sqrt(2)-1)/(2-1) = sqrt(2)-1
delta_s - 2 = 1+sqrt(2) - 2 = sqrt(2)-1
Therefore 1/delta_s = delta_s - 2
```

### Problem 18: 1/delta_b = delta_b - 3
```
1/delta_b = 2/(3+sqrt(13)) = 2(3-sqrt(13))/((3+sqrt(13))(3-sqrt(13)))
          = 2(3-sqrt(13))/(9-13) = (sqrt(13)-3)/2
delta_b - 3 = (3+sqrt(13))/2 - 3 = (sqrt(13)-3)/2
Therefore 1/delta_b = delta_b - 3
```

### Problem 19: 2^(6/12) = sqrt(2)
```
2^(6/12) = 2^(1/2) = sqrt(2) = 1.414214
```

### Problem 20: A/V ratio
```
For sphere: A = 4*pi*r^2, V = (4/3)*pi*r^3
A/V = 4*pi*r^2 / ((4/3)*pi*r^3) = 3/r
As r increases, A/V decreases as 1/r
```

### Problem 21: 1/psi
```
psi^3 = psi + 1
Divide by psi: psi^2 = 1 + 1/psi
1/psi = psi^2 - 1
Check: 1.324718^2 - 1 = 1.754878 - 1 = 0.754878
       1/1.324718 = 0.754878
```

### Problem 22: 1/psi_s
```
psi_s^3 = psi_s^2 + 1
Divide by psi_s^2: psi_s = 1 + 1/psi_s^2
1/psi_s^2 = psi_s - 1
Also: 1/psi_s = psi_s^2 - psi_s (dividing by psi_s)
Check: 1.465571^2 - 1.465571 = 2.147899 - 1.465571 = 0.682328
       1/1.465571 = 0.682328
```

### Problem 23: Cassini's Identity
```
F(n-1)*F(n+1) - F(n)^2 = (-1)^n

Example n=5: F(4)*F(6) - F(5)^2 = 3*8 - 25 = -1 = (-1)^5
```

### Problem 24: L(n) = F(n-1) + F(n+1)
```
Example n=4: L(4) = 7, F(3) + F(5) = 2 + 5 = 7
Example n=5: L(5) = 11, F(4) + F(6) = 3 + 8 = 11
```

### Problem 25: Padovan recurrence
```
P(n) = P(n-2) + P(n-3)
P(3) = P(1) + P(0) = 1 + 1 = 2
P(4) = P(2) + P(1) = 1 + 1 = 2
```

### Problem 26: Kepler's third law
```
T^2 = k*a^3
where T is orbital period and a is semi-major axis
k is the same for all planets orbiting the same star
```

### Problem 27: phi - 1/phi = 1
```
1/phi = phi - 1 (from Problem 16)
phi - (phi - 1) = 1
```

### Problem 28: delta_s - 1/delta_s = 2
```
1/delta_s = delta_s - 2 (from Problem 17)
delta_s - (delta_s - 2) = 2
```

### Problem 29: delta_b - 1/delta_b = 3
```
1/delta_b = delta_b - 3 (from Problem 18)
delta_b - (delta_b - 3) = 3
```

### Problem 30: Harmonic mean
```
H = 2ab/(a+b) = 2*2*8/(2+8) = 32/10 = 3.2
```

---

## Detailed Solutions: Problems 31–45

### Problem 31: Next Fibonacci numbers
```
After 89: F(12)=144, F(13)=233, F(14)=377, F(15)=610, F(16)=987
```

### Problem 32: Next Lucas numbers
```
After 47: L(9)=76, L(10)=123, L(11)=199, L(12)=322, L(13)=521
```

### Problem 33: Next Padovan numbers
```
After 28: P(14)=37, P(15)=49, P(16)=65, P(17)=86, P(18)=114
```

### Problem 34: F(12)/F(11)
```
F(12)=144, F(11)=89
144/89 = 1.617978
phi = 1.618034
Difference: 0.000056
```

### Problem 35: P(8)/P(7) for Pell
```
P_ell(8)=408, P_ell(7)=169
408/169 = 2.414201
delta_s = 2.414214
Difference: 0.000013
```

### Problem 36: N(6)/N(5)
```
N(6)=360, N(5)=109
360/109 = 3.302752
delta_b = 3.302776
Difference: 0.000024
```

### Problem 37: Logistic growth
```
P(5) = K/(1+((K-P_0)/P_0)*e^(-r*5))
     = 1000/(1+((1000-100)/100)*e^(-1.5))
     = 1000/(1+9*0.223130)
     = 1000/(1+2.008170)
     = 1000/3.008170
     = 332.4
```

### Problem 38: psi^6
```
psi^3 = psi + 1
psi^6 = (psi+1)^2 = psi^2 + 2*psi + 1
     = (psi^2) + 2*psi + 1
psi^2 = psi + 1 - 1 + psi^2... wait
psi^6 = psi^3 * psi^3 = (psi+1)^2 = psi^2 + 2*psi + 1
psi^2 = psi + 1 (from psi^3 = psi+1, multiply by psi: psi^4 = psi^2+psi)
Actually psi^2 = psi + 1 is wrong. Let me recalculate.
psi^3 = psi + 1
psi^2 = psi^3/psi = (psi+1)/psi = 1 + 1/psi
1/psi = psi^2 - 1 (from earlier)
So psi^2 = 1 + psi^2 - 1... that's circular.

Let me just compute: psi^6 = (1.324718)^6 = 5.404
And psi^2 + 2*psi + 1 = 1.7549 + 2.6494 + 1 = 5.404
```

### Problem 39: psi_s^5
```
psi_s^3 = psi_s^2 + 1
psi_s^5 = psi_s^2 * psi_s^3 = psi_s^2*(psi_s^2+1) = psi_s^4 + psi_s^2
psi_s^4 = psi_s * psi_s^3 = psi_s*(psi_s^2+1) = psi_s^3 + psi_s = psi_s^2+1+psi_s
psi_s^5 = psi_s^2+1+psi_s + psi_s^2 = 2*psi_s^2 + psi_s + 1
= 2(2.1479) + 1.4656 + 1 = 4.2958 + 1.4656 + 1 = 6.761
```

### Problem 40: F(8) via Binet
```
F(8) = (phi^8 - psi^8)/sqrt(5)
phi^8 = 46.9787
psi^8 = 0.0213
F(8) = (46.9787 - 0.0213)/2.2361 = 46.9574/2.2361 = 21
```

### Problem 41: L(8) via Binet
```
L(8) = phi^8 + psi^8 = 46.9787 + 0.0213 = 47.000
```

### Problem 42: P(20) estimate
```
P(n) ~ a*psi^n
P(10) = 12
psi^10 = 16.642
P(20) ~ P(10) * psi^10 = 12 * 16.642 = 199.7 ~ 200
Exact: P(20) = 200
```

### Problem 43: C major scale
```
C4=261.63, D4=293.66, E4=329.63, F4=349.23
G4=392.00, A4=440.00, B4=493.88, C5=523.25
```

### Problem 44: Venus period
```
8*T_Earth = 13*T_Venus
T_Venus = 8*365.25/13 = 224.77 days
Actual: 224.70 days
```

### Problem 45: Fractal dimension
```
D = log(N)/log(1/epsilon) = log(1000)/log(100)
= log(10^3)/log(10^2) = 3/2 = 1.5
```

---

## Detailed Solutions: Problems 46–60

### Problem 46: phi^5
```
phi^2 = phi+1
phi^3 = phi^2+phi = 2*phi+1
phi^4 = 2*phi^2+phi = 3*phi+2
phi^5 = 3*phi^2+2*phi = 5*phi+3
```

### Problem 47: delta_s^4
```
delta_s^2 = 2*delta_s+1
delta_s^3 = 2*delta_s^2+delta_s = 5*delta_s+2
delta_s^4 = 5*delta_s^2+2*delta_s = 12*delta_s+5
```

### Problem 48: delta_b^4
```
delta_b^2 = 3*delta_b+1
delta_b^3 = 3*delta_b^2+delta_b = 10*delta_b+3
delta_b^4 = 10*delta_b^2+3*delta_b = 33*delta_b+10
```

### Problem 49: psi^5
```
psi^3 = psi+1
psi^4 = psi^2+psi
psi^5 = psi^3+psi^2 = psi^2+psi+1
```

### Problem 50: psi_s^5
```
psi_s^3 = psi_s^2+1
psi_s^4 = psi_s^3+psi_s = psi_s^2+psi_s+1
psi_s^5 = psi_s^4+psi_s = 2*psi_s^2+psi_s+1
```

---

## Scoring Guide

- 450-480: Excellent (A)
- 400-449: Very Good (B)
- 350-399: Good (C)
- 300-349: Satisfactory (D)
- Below 300: Needs Improvement (F)

---

*Return to: 12_intermediate_worksheet.md*
