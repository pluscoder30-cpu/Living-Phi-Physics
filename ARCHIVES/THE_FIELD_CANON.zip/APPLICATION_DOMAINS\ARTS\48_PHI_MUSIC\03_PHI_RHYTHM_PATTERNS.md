# PHI-RHYTHM PATTERNS

## 1. Foundational Phi-Rhythm Concepts

### 1.1 The Golden Beat

A phi-rhythm is a rhythmic pattern where consecutive durations follow the golden ratio:

```
d₂ / d₁ = φ ≈ 1.6180339887
```

Or equivalently, where the ratio of a duration to the sum of it and the preceding duration equals 1/φ:

```
d_n / (d_n + d_{n-1}) = 1/φ ≈ 0.6180339887
```

This creates a rhythmic pattern that is neither regular (isochronous) nor random, but follows the same self-similar proportion found throughout nature.

### 1.2 Fibonacci Rhythmic Cells

The basic building blocks of phi-rhythm are Fibonacci-duration cells:

```
Cell-1: [1]                    = 1 beat
Cell-2: [1, 1]                 = 2 beats
Cell-3: [1, 1, 2]              = 4 beats
Cell-4: [1, 1, 2, 3]           = 7 beats
Cell-5: [1, 1, 2, 3, 5]        = 12 beats
Cell-6: [1, 1, 2, 3, 5, 8]     = 20 beats
Cell-7: [1, 1, 2, 3, 5, 8, 13] = 33 beats
```

Each cell contains the two preceding cells as sub-patterns, creating a recursive rhythm structure.

### 1.3 Tempo-Phi Relationship

In phi-rhythm, the tempo itself can follow the golden ratio:

```
Tempo_n = Tempo_{n-1} × φ
```

Or inversely:

```
Tempo_n = Tempo_{n-1} / φ
```

This creates an accelerating or decelerating tempo that maintains the φ-relationship between successive tempo levels. The perceptual effect is a natural, organic tempo change that feels neither abrupt nor mechanical.

## 2. PHI-POLYRHYTHM

### 2.1 Basic Phi-Polyrhythm

Two simultaneous rhythmic streams with φ-ratio period:

```
Stream A: period = P beats
Stream B: period = P × φ beats
```

The polyrhythmic ratio is φ:1, creating a complex interaction pattern that never exactly repeats (since φ is irrational). The beats align approximately at:

```
Alignment points: n × P × φ (rounded to nearest integer)
```

### 2.2 Phi-Polyrhythm Table

| Stream A Period | Stream B Period | Ratio    | Beats Between Alignments |
|----------------|----------------|----------|--------------------------|
| 5              | 8              | 1:1.600  | 8                        |
| 8              | 13             | 1:1.625  | 13                       |
| 13             | 21             | 1:1.615  | 21                       |
| 21             | 34             | 1:1.619  | 34                       |
| 34             | 55             | 1:1.618  | 55                       |

As the periods increase, the polyrhythm approaches the true φ-ratio, with alignment points becoming increasingly rare.

### 2.3 Cross-Rhythm Pattern

In a φ-cross-rhythm, the off-beats of one stream fall at φ-divisions of the other stream's beats:

```
Stream A: |X . . . . . . . X . . . . . . . X . . . . . . . X . . . . . . .|
          1                 17                33                49

Stream B: |X . . . X . X . . . . X . . X . . . . . X . X . . . . X . . X . |
          1     6   10       16    21       28  31      37  40       47  51
```

The inter-onset intervals of Stream B (6, 4, 6, 5, 5, 6, 4, 6, 5, 5...) follow a quasi-φ pattern.

## 3. PHI-SYNCOPATION

### 3.1 The Golden Syncopation

A syncopation occurs when a note falls on a weak beat or between beats. In phi-syncopation, the syncopated note falls at the φ-division of the beat:

```
Beat position: φ⁻¹ × Beat_duration = 0.618 × Beat_duration
```

For a beat of 500ms:
```
Normal accent: 0ms, 500ms, 1000ms, 1500ms
Phi-syncopated: 309ms, 809ms, 1309ms, 1809ms
```

The syncopation falls at 61.8% of the beat, creating a "swing" feel that is more extreme than standard swing (which typically falls at 66.7%, the 2:1 triplet ratio).

### 3.2 Phi-Swing Ratio

Standard jazz swing uses a 2:1 ratio (long:short = 2:1). Phi-swing uses:

```
Long : Short = φ : 1 = 1.618 : 1
```

For eighth notes at 120 BPM (beat = 500ms):

```
Standard swing: Long = 333ms, Short = 167ms
Phi-swing:      Long = 309ms, Short = 191ms
Triplet swing:  Long = 333ms, Short = 167ms
Even:           Long = 250ms, Short = 250ms
```

Phi-swing creates a more relaxed, flowing feel compared to the "bouncy" quality of triplet swing.

### 3.3 Phasing Syncopation

Two instruments playing the same rhythm but phasing at φ-ratio:

```
Instrument A: |X . . X . X . . X . X . . X . X . . X . X . . X . X . . X . X|
Instrument B: |X . X . . X . X . . X . X . . X . X . . X . X . . X . X . . X|
Phase shift: φ⁻¹ × beat_duration
```

The phase relationship between the instruments creates a constantly shifting pattern of unisons and cross-rhythms that evolves over φ-revolution cycles.

## 4. PHI-METER

### 4.1 The Golden Meter

A phi-meter is a time signature based on Fibonacci numbers:

```
φ-meter: F(n) / F(n-1)
```

Examples:
```
2/1 meter  (F(3)/F(2))  — Duple
3/2 meter  (F(4)/F(3))  — Hemiola
5/3 meter  (F(5)/F(4))  — Complex
8/5 meter  (F(6)/F(5))  — Hyper-complex
13/8 meter (F(7)/F(6))  — Ultra-complex
```

### 4.2 Phi-Meter Notation

In phi-meter, beats are subdivided according to the φ-series:

```
8/5 meter:
  |1 . . . . 2 . . . . 3 . . . . 4 . . . . 5 . . . .|  (5 beats)
  |1 . . . 2 . . 3 . 4 . 5 . 6 . 7 . 8 .|              (8 subdivisions)

  Beat 1: 3 subdivisions (F(4))
  Beat 2: 2 subdivisions (F(3))
  Beat 3: 3 subdivisions (F(4))
  Beat 4: 5 subdivisions (F(5))
  Beat 5: 5 subdivisions (F(5))
```

### 4.3 Metric Modulation

Phi-metric modulation transforms from one meter to another using φ-ratio:

```
Tempo₁ × Beat₁ = Tempo₂ × Beat₂
Beat₂ / Beat₁ = φ
Therefore: Tempo₂ = Tempo₁ / φ
```

Example:
```
Starting: 120 BPM in 5/4 (beat = 500ms)
Modulate: beat becomes 500 × φ = 809ms
New tempo: 120/φ = 74.16 BPM in 8/5
```

The modulation creates a seamless transition where the listener perceives a natural acceleration or deceleration.

## 5. PHI-OSTINATO

### 5.1 Golden Ostinato Pattern

An ostinato (repeating rhythmic pattern) with φ-durations:

```
Pattern: [5, 3, 2, 3, 5, 8, 5, 3, 2, 3, 5, 8, ...]
Length:  8 beats (F(6))
Repeat: every 8 beats
```

The pattern contains Fibonacci durations that sum to a Fibonacci total, creating a self-similar rhythm at every level of analysis.

### 5.2 Recursive Ostinato

A recursive ostinato where each iteration is φ times the previous:

```
Iteration 1: [1, 1, 2] = 4 beats
Iteration 2: [1, 2, 3] = 6 beats (each element × φ, rounded)
Iteration 3: [2, 3, 5] = 10 beats
Iteration 4: [3, 5, 8] = 16 beats
Iteration 5: [5, 8, 13] = 26 beats
```

The ostinato grows by φ at each iteration, creating an expanding rhythmic structure that eventually becomes too large to perceive as a pattern, dissolving into a quasi-random rhythm.

### 5.3 Phasing Ostinato

Two ostinatos at φ-ratio tempos:

```
Ostinato A: [1, 1, 2, 3, 5] at Tempo T
Ostinato B: [1, 1, 2, 3, 5] at Tempo T × φ
```

The phase relationship between the two ostinatos evolves according to:

```
Phase(t) = (T × φ - T) × t / (T × φ) = (φ - 1) × t / φ = t / φ²
```

The phase cycle completes every φ² beats, creating a long-range rhythmic evolution.

## 6. PHI-DRUMMING PATTERNS

### 6.1 West African Phi-Patterns

Traditional West African drumming contains φ-rhythmic structures:

```
Djembe pattern (Fon):
  |X . . X . . X . X . . X . . X . X . . X . . X . . X . . X . . X . . .|
  |1     4     7   9     12    15  17    20    23    26    29    32    35

  Inter-onset intervals: 3, 3, 2, 2, 3, 3, 2, 3, 2, 3, 3, 2, 2, 3, 3, 2, 3
  Approximation to φ: 3/2 = 1.500 (error from φ: 7.3%)
```

### 6.2 Indian Tala Phi-Structures

The 16-beat Tintal can be subdivided using Fibonacci groupings:

```
Tintal: 4 + 4 + 4 + 4 (standard)
Phi-Tintal: 5 + 3 + 5 + 3 (Fibonacci grouping)
            or: 8 + 5 + 3 (recursive Fibonacci)
```

The phi-Tintal creates asymmetric phrases that maintain the overall 16-beat cycle while introducing golden-ratio internal proportions.

### 6.3 Brazilian Phi-Bossa

Bossa nova rhythm with φ-syncopation:

```
Standard Bossa: |X . . X . . X . . X . . X . . X . . X . . X . . X . . X . . X . . X . . X . . X . . X . . X . .|
Phi-Bossa:      |X . . . X . X . . . X . . X . . . X . X . . . X . X . . . X . X . . . X . X . . . X . X . . .|
                |1     6   10       16    21      27  30      36  40      46  50      56  60      66  70      76|

Phi-syncopated accents at positions: 6, 10, 16, 21, 27, 30, 36, 40, 46, 50, 56, 60, 66, 70, 76
Gaps: 4, 6, 5, 5, 6, 4, 6, 5, 5, 6, 4, 6, 5, 5, 6...
Pattern: 4, 6, 5, 5 repeated (sums to 20 = F(6))
```

## 7. PHI-REST PATTERNS

### 7.1 The Golden Rest

A rest following a note in phi-rhythm has duration:

```
Rest = Note_duration × (φ - 1) = Note_duration × 0.6180339887
```

For notes of durations 1, 2, 3, 5, 8:

```
Note 1: Rest = 0.618 beats → Round to nearest Fibonacci: 1 beat
Note 2: Rest = 1.236 beats → Round to nearest Fibonacci: 1 beat
Note 3: Rest = 1.854 beats → Round to nearest Fibonacci: 2 beats
Note 5: Rest = 3.090 beats → Round to nearest Fibonacci: 3 beats
Note 8: Rest = 4.944 beats → Round to nearest Fibonacci: 5 beats
```

### 7.2 Silence Architecture

In phi-composition, the distribution of sound and silence follows the golden ratio:

```
Sound_total : Silence_total = φ : 1
```

For a 34-beat phrase:
```
Sound: 34/φ = 21 beats
Silence: 34 - 21 = 13 beats
```

The 13 beats of silence can be distributed as:
```
Beginning: 5 beats (F(5))
Middle: 3 beats (F(4))
End: 5 beats (F(5))
```

### 7.3 Breath Rhythm

Phi-rests create a natural breathing rhythm for wind players and singers:

```
Inhale: φ × Exhale
```

For a phrase of 21 beats:
```
Exhale (play): 21/φ = 13 beats
Inhale (rest): 21 - 13 = 8 beats
```

This ratio matches the natural breathing cycle at rest (approximately 6 breaths per minute, with inhale:exhale ratio of 1:1.6).

## 8. PHI-ACCELERATION AND DECELERATION

### 8.1 Fermata-Phi

A fermata (held note) in phi-composition has duration:

```
Fermata = Beat_duration × φ^n
```

Where n is the expressive level:
```
n = 0: No fermata (1 beat)
n = 1: Light fermata (φ beats ≈ 1.618 beats)
n = 2: Medium fermata (φ² beats ≈ 2.618 beats)
n = 3: Heavy fermata (φ³ beats ≈ 4.236 beats)
n = 4: Grand fermata (φ⁴ beats ≈ 6.854 beats)
```

### 8.2 Ritardando Pattern

A phi-ritardando slows down by φ-ratio at each beat:

```
Beat 1: Duration = D
Beat 2: Duration = D × φ
Beat 3: Duration = D × φ²
Beat 4: Duration = D × φ³
```

The total duration of 4 beats:

```
T = D(1 + φ + φ² + φ³) = D × φ⁴ = D × 6.854
```

The ritardando stretches the phrase by a factor of φ⁴, creating a dramatic slowing effect.

### 8.3 Accelerando Pattern

A phi-accelerando speeds up by 1/φ at each beat:

```
Beat 1: Duration = D
Beat 2: Duration = D / φ
Beat 3: Duration = D / φ²
Beat 4: Duration = D / φ³
```

The total duration:

```
T = D(1 + 1/φ + 1/φ² + 1/φ³) = D × φ/(φ - 1) = D × φ² = D × 2.618
```

The accelerando compresses the phrase by a factor of φ², creating a rushing effect.

## 9. PHI-RHYTHM IN DANCE

### 9.1 Waltz Phi-Phrasing

The waltz (3/4 time) can incorporate φ-phrasing:

```
Standard waltz: |X . . . . . X . . . . . X . . . . . X . . . . .|  (4 measures of 3/4)
Phi-waltz:      |X . . . . . X . . . . . X . . . X . . . . . X . . . . . X . . . . . . . . . . . X . . . . . X|
                |1         7         13        19   22      28         34                  43       49|

Phrase lengths: 6, 6, 6, 3, 3, 6, 6, 10, 6, 6...
Fibonacci approximations: 5, 5, 5, 3, 3, 5, 5, 8, 5, 5...
```

### 9.2 Tango Phi-Contraption

Tango rhythm with φ-accentuation:

```
Standard tango: |X . X . X . X .|  (4/4 with accents on 1, 3)
Phi-tango:      |X . . X . X . . X . . X . X . . X . . X . X . . X . . X . X . .|
                |1     4   6     9     12  14    17    19    22  24    27    29    32

Accent positions: 1, 4, 6, 9, 12, 14, 17, 19, 22, 24, 27, 29, 32
Gaps: 3, 2, 3, 3, 2, 3, 2, 3, 2, 3, 2, 3
Pattern: 3, 2 repeated (sums to 5 = F(5))
```

### 9.3 Ballet Phi-Phrasing

Choreographic phrasing in ballet follows φ-rhythms:

```
Tendu sequence:  8 counts (F(6))
Degagé sequence: 5 counts (F(5))
Rond de jambe:  13 counts (F(7))
Grand battement:  8 counts (F(6))
```

The dancer's movements align with the φ-rhythmic structure of the music, creating a unified audio-visual experience.

## 10. COMPUTATIONAL PHI-RHYTHM

### 10.1 Algorithmic Generation

```python
PHI = (1 + 5**0.5) / 2
FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]

def phi_rhythm(total_beats, subdivisions=16):
    """Generate a phi-rhythm pattern."""
    pattern = [0] * (total_beats * subdivisions)
    
    # Place beats at Fibonacci intervals
    beat_positions = []
    pos = 0
    while pos < len(pattern):
        beat_positions.append(pos)
        # Next beat at Fibonacci-determined interval
        interval = FIB[len(beat_positions) % len(FIB)]
        pos += interval * subdivisions // 4
    
    for bp in beat_positions:
        if bp < len(pattern):
            pattern[bp] = 1
    
    return pattern

def phi_polyrhythm(period_a, period_b, beats):
    """Generate two φ-polyrhythmic streams."""
    stream_a = [0] * beats
    stream_b = [0] * beats
    
    # Stream A: isochronous
    for i in range(0, beats, period_a):
        stream_a[i] = 1
    
    # Stream B: φ-ratio period
    phi_period = int(period_a * PHI)
    for i in range(0, beats, phi_period):
        stream_b[i] = 1
    
    return stream_a, stream_b

def phi_swing(eighth_notes, ratio=PHI):
    """Apply phi-swing to eighth-note pattern."""
    swung = []
    for i, note in enumerate(eighth_notes):
        if i % 2 == 0:  # Downbeat
            swung.append(('long', note))
        else:  # Upbeat
            swung.append(('short', note))
    return swung
```

### 10.2 Analysis Functions

```python
def analyze_phi_content(rhythm):
    """Measure the phi-content of a rhythm."""
    # Extract inter-onset intervals
    onsets = [i for i, v in enumerate(rhythm) if v == 1]
    iois = [onsets[i+1] - onsets[i] for i in range(len(onsets)-1)]
    
    # Count Fibonacci-proportioned IOIs
    fib_count = sum(1 for ioi in iois if ioi in FIB[:10])
    fib_ratio = fib_count / len(iois) if iois else 0
    
    # Check for φ-ratios between consecutive IOIs
    phi_count = 0
    for i in range(len(iois)-1):
        ratio = iois[i+1] / iois[i] if iois[i] > 0 else 0
        if abs(ratio - PHI) < 0.1 or abs(1/ratio - PHI) < 0.1:
            phi_count += 1
    phi_ratio = phi_count / (len(iois)-1) if len(iois) > 1 else 0
    
    return {
        'fibonacci_density': fib_ratio,
        'phi_ratio_density': phi_ratio,
        'fibonacci_target': 0.618,
        'phi_ratio_target': 0.382
    }
```

### 10.3 Real-Time Phi-Rhythm Engine

```python
class PhiRhythmEngine:
    def __init__(self, bpm=120):
        self.bpm = bpm
        self.beat_duration = 60.0 / bpm
        self.fib_index = 0
        self.phase = 0.0
    
    def next_beat_time(self):
        """Calculate the time of the next beat."""
        fib = FIB[self.fib_index % len(FIB)]
        duration = self.beat_duration * fib / FIB[0]
        self.phase += duration
        self.fib_index += 1
        return self.phase
    
    def phi_accent(self, time):
        """Calculate accent level at given time."""
        # Golden spiral accent
        theta = 2 * 3.14159 * time / (self.beat_duration * PHI)
        accent = abs((theta % (2 * 3.14159)) / (2 * 3.14159))
        return accent
    
    def phi_velocity(self, time):
        """Calculate MIDI velocity following golden spiral."""
        theta = 2 * 3.14159 * time / (self.beat_duration * PHI * 8)
        velocity = int(64 + 40 * (theta % (2 * 3.14159)) / (2 * 3.14159))
        return max(1, min(127, velocity))
```

## References

- London, J. (2012). "Hearing in Time: Meter as a Mode of Listening"
- Lerdahl, F. & Jackendoff, R. (1983). "A Generative Theory of Tonal Music"
- Hasty, C. (1997). "Meter as Rhythm"
- Agmon, E. (1996). "Linear Transformations between Musical Metrics"
- Drew, U. (1993). "Conducting with Movement"
