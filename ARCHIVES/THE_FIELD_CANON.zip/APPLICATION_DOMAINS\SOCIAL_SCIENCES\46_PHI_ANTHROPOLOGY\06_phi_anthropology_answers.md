# PHI-ANTHROPOLOGY: Answer Key

---

## Problem 1: Civilizational Peak Timing

**(a) Peak time:**
```
t_peak = τ_crisis × ln(β/α)/ln(φ)
= 250 × ln(0.04/0.015)/ln(φ)
= 250 × ln(2.667)/ln(φ)
= 250 × 0.981/0.481
= 510.2 years
```

**(b) Peak complexity:**
```
C_peak = C₀ × exp(−t_peak × (α + β)/2)
= C₀ × exp(−510.2 × 0.0275)
= C₀ × exp(−14.03)
= C₀ × 8.0 × 10^(−7) (very small, growth limited by crises)
```

**(c) Complexity at t = 500:**
```
C(500) = C₀ × φ^(500/τ_civ) × exp(−500 × (α + β)/2)
= C₀ × φ^(500/500) × exp(−500 × 0.0275)
= C₀ × 1.618 × exp(−13.75)
= C₀ × 1.618 × 1.07 × 10^(−6)
= C₀ × 1.73 × 10^(−6)
```

**(d) If β doubles to 0.08:**
```
t_peak_new = 250 × ln(0.08/0.015)/ln(φ)
= 250 × ln(5.333)/ln(φ)
= 250 × 1.674/0.481
= 870.3 years
```

---

## Problem 2: Migration Front Propagation

**(a) Velocities:**
```
r = 50 km: v = 12 × φ^(−50/100) = 12 × φ^(−0.5) = 12 × 0.786 = 9.43 km/yr
r = 100 km: v = 12 × φ^(−1) = 12 × 0.618 = 7.42 km/yr
r = 200 km: v = 12 × φ^(−2) = 12 × 0.382 = 4.58 km/yr
```

**(b) Times:**
```
r = 50 km: t = 50/9.43 = 5.3 years
r = 100 km: t = 100/7.42 = 13.5 years
r = 200 km: t = 200/4.58 = 43.7 years
```

**(c) Distance for v < 0.5 km/yr:**
```
0.5 = 12 × φ^(−r/100)
0.0417 = φ^(−r/100)
ln(0.0417) = −r/100 × ln(φ)
r = −100 × ln(0.0417)/ln(φ)
= −100 × (−3.178)/0.481
= 660.7 km
```

**(d) Standard exponential comparison:**
```
Standard: v = 12 × e^(−r/100)
At r = 50: v_std = 12 × e^(−0.5) = 7.28 km/yr
At r = 100: v_std = 12 × e^(−1) = 4.41 km/yr
At r = 200: v_std = 12 × e^(−2) = 1.62 km/yr
Phi-model: 9.43, 7.42, 4.58 (phi decays slower)
```

---

## Problem 3: Language Branching

**(a) Number of languages:**
```
t = 500: N = 1 × φ^(500/250) = φ^2 = 2.618 ≈ 3 languages
t = 1000: N = 1 × φ^(1000/250) = φ^4 = 6.854 ≈ 7 languages
t = 2000: N = 1 × φ^(2000/250) = φ^8 = 46.98 ≈ 47 languages
```

**(b) Time for 100 languages:**
```
100 = φ^(t/250)
ln(100) = t/250 × ln(φ)
t = 250 × ln(100)/ln(φ)
= 250 × 4.605/0.481
= 2,393 years
```

**(c) Branching rate at t = 1000:**
```
dN/dt = N × ln(φ)/τ_branch
At t = 1000: N = 7, so dN/dt = 7 × 0.481/250 = 0.0135 languages/year
```

**(d) If τ_branch = 500:**
```
100 = φ^(t/500)
t = 500 × ln(100)/ln(φ)
= 500 × 4.605/0.481
= 4,787 years
```

---

## Problem 4: Mythological Archetype Recurrence

**(a) Next 5 appearances:**
```
T(n) = 400 × φ^n
n=0: 3000 BCE (original)
n=1: 3000 − 647 = 2353 BCE
n=2: 3000 − 1067 = 1933 BCE
n=3: 3000 − 1727 = 1273 BCE
n=4: 3000 − 2794 = 206 BCE
```

**(b) Period for n = 5:**
```
T(5) = 400 × φ^5 = 400 × 11.089 = 4,436 years
```

**(c) Total recurrences in 5,000 years:**
```
Number of recurrences = floor(ln(5000/400)/ln(φ)) + 1
= floor(ln(12.5)/ln(φ)) + 1
= floor(2.526/0.481) + 1
= floor(5.25) + 1
= 5 + 1 = 6 recurrences
```

**(d) Probability per century:**
```
P(per century) = 100/T(n) averaged over n
Average T ≈ 400 × (1 + φ + φ² + φ³ + φ⁴ + φ⁵)/6
= 400 × (1 + 1.618 + 2.618 + 4.236 + 6.854 + 11.089)/6
= 400 × 27.415/6
= 1,828 years average
P = 100/1828 = 0.0547 = 5.47% per century
```

---

## Problem 5: Cultural Complexity Growth

**(a) Without saturation:**
```
t = 100: K = 50 × φ^(100/200) = 50 × φ^0.5 = 50 × 1.272 = 63.6
t = 300: K = 50 × φ^(300/200) = 50 × φ^1.5 = 50 × 2.058 = 102.9
t = 600: K = 50 × φ^(600/200) = 50 × φ^3 = 50 × 4.236 = 211.8
```

**(b) With saturation:**
```
t = 100: K = 63.6 × (1 − 63.6/5000) = 63.6 × 0.987 = 62.8
t = 300: K = 102.9 × (1 − 102.9/5000) = 102.9 × 0.979 = 100.7
t = 600: K = 211.8 × (1 − 211.8/5000) = 211.8 × 0.958 = 202.9
```

**(c) Time for 50% of K_max:**
```
2500 = 50 × φ^(t/200)
50 = φ^(t/200)
ln(50) = t/200 × ln(φ)
t = 200 × ln(50)/ln(φ)
= 200 × 3.912/0.481
= 1,627 years
```

**(d) Growth rate at t = 200:**
```
dK/dt = K × ln(φ)/τ_culture × (1 − K/K_max)
At t = 200: K = 50 × φ^1 = 80.9
dK/dt = 80.9 × 0.481/200 × (1 − 80.9/5000)
= 80.9 × 0.002405 × 0.984
= 0.191 per year
```

---

## Problem 6: Settlement Pattern Analysis

**(a) Densities:**
```
r = 5 km: ρ = 200 × φ^(−5/10) = 200 × φ^(−0.5) = 200 × 0.786 = 157.2 artifacts/km²
r = 10 km: ρ = 200 × φ^(−1) = 200 × 0.618 = 123.6 artifacts/km²
r = 20 km: ρ = 200 × φ^(−2) = 200 × 0.382 = 76.4 artifacts/km²
```

**(b) Total artifacts by zone:**
```
Zone 0-5 km: Area = π(5²) = 78.5 km²
Average density ≈ (200 + 157.2)/2 = 178.6
Total = 78.5 × 178.6 = 14,020

Zone 5-10 km: Area = π(10²−5²) = 235.6 km²
Average density ≈ (157.2 + 123.6)/2 = 140.4
Total = 235.6 × 140.4 = 33,078

Zone 10-20 km: Area = π(20²−10²) = 942.5 km²
Average density ≈ (123.6 + 76.4)/2 = 100.0
Total = 942.5 × 100.0 = 94,250
```

**(c) Distance for ρ < 10:**
```
10 = 200 × φ^(−r/10)
0.05 = φ^(−r/10)
ln(0.05) = −r/10 × ln(φ)
r = −10 × ln(0.05)/ln(φ)
= −10 × (−2.996)/0.481
= 62.3 km
```

**(d) Comparison with 1/r²:**
```
Standard: ρ = 200/(1 + r²/R²)
At r = 5: ρ_std = 200/(1 + 0.25) = 160.0 (vs 157.2 phi)
At r = 10: ρ_std = 200/(1 + 1) = 100.0 (vs 123.6 phi)
At r = 20: ρ_std = 200/(1 + 4) = 40.0 (vs 76.4 phi)
Phi-model has heavier tails (more artifacts at distance)
```

---

## Problem 7: Trade Route Efficiency

**(a) Phi-spiral distance:**
```
d_spiral ≈ 1.272 × d_straight = 1.272 × 800 = 1,017.6 km
```

**(b) Number of trading posts:**
```
n_posts = ln(800)/ln(φ) = 6.685/0.481 = 13.9 ≈ 14 posts
```

**(c) Total trade value:**
```
Each post handles 0.618 of incoming goods
Goods arriving at post k: G₀ × 0.618^k
Total trade = Σ_{k=0}^{13} G₀ × 0.618^k
= G₀ × (1 − 0.618^14)/(1 − 0.618)
= G₀ × (1 − 0.000337)/0.382
= G₀ × 2.617
= 2.617 × G₀
```

**(d) Break-even distance:**
```
Straight: 100% goods reach destination
Spiral: 61.8% reach each post, but more posts
Break-even when: 0.618^n_posts > 1 (never true for goods reaching end)
Break-even for total trade value: always (spiral always creates more trade)
```

---

## Problem 8: Cultural Assimilation

**(a) Assimilation at various times:**
```
t = 10: C = 40 + 40 × φ^(−10/25) = 40 + 40 × 0.757 = 40 + 30.3 = 70.3
t = 25: C = 40 + 40 × φ^(−1) = 40 + 40 × 0.618 = 40 + 24.7 = 64.7
t = 50: C = 40 + 40 × φ^(−2) = 40 + 40 × 0.382 = 40 + 15.3 = 55.3
```

**(b) Time for 50% assimilation:**
```
50% assimilation: C = 60
60 = 40 + 40 × φ^(−t/25)
0.5 = φ^(−t/25)
t = −25 × ln(0.5)/ln(φ) = 25 × 1.443 = 36.1 years
```

**(c) Assimilation rate at t = 25:**
```
dC/dt = −(C₀ − C_host)/τ × ln(φ) × φ^(−t/τ)
= −40/25 × 0.481 × 0.618
= −0.471 per year
Rate = 0.471 cultural units/year
```

**(d) If C_host = 60:**
```
New equilibrium: C_eq = 60
C(t) = 60 + (80 − 60) × φ^(−t/25) = 60 + 20 × φ^(−t/25)
At t = 25: C = 60 + 20 × 0.618 = 72.4
```

---

## Problem 9: Lexical Distance

**(a) With contacts:**
```
D = D₀ × 800/350 × φ^(−2)
= D₀ × 2.286 × 0.382
= D₀ × 0.873
```

**(b) Without contacts:**
```
D_no_contacts = D₀ × 800/350 = D₀ × 2.286
```

**(c) Contact effect:**
```
Ratio = 0.873/2.286 = 0.382 = φ^(−2)
```

**(d) Contacts for 90% reduction:**
```
0.1 = φ^(−N_contacts)
N_contacts = −ln(0.1)/ln(φ) = 2.303/0.481 = 4.79
N_contacts = 5 contacts needed
```

---

## Problem 10: Civilization Memory Decay

**(a) Knowledge at various times:**
```
t = 200: M = 100 × φ^(−200/600) = 100 × φ^(−0.333) = 100 × 0.794 = 79.4%
t = 500: M = 100 × φ^(−500/600) = 100 × φ^(−0.833) = 100 × 0.545 = 54.5%
t = 1000: M = 100 × φ^(−1000/600) = 100 × φ^(−1.667) = 100 × 0.296 = 29.6%
```

**(b) Half-life:**
```
t_(1/2) = τ × ln(2)/ln(φ) = 600 × 1.443 = 865.8 years
```

**(c) Drop below 10%:**
```
10 = 100 × φ^(−t/600)
0.1 = φ^(−t/600)
t = −600 × ln(0.1)/ln(φ) = 600 × 4.788 = 2,873 years
```

**(d) With reinforcement every 300 years:**
```
After 300 years: M = 100 × φ^(−300/600) = 100 × 0.786 = 78.6%
Reinforce to 100%: new starting point
Long-term: M oscillates between 78.6% and 100%
Average: 89.3% retention
```

---

*End of PHI-ANTHROPOLOGY Answers*
