# Research Bibliography: 200+ References

## Books

1. Hardy, G.H. & Wright, E.M. "An Introduction to the Theory of Numbers." 6th ed., Oxford Univ. Press, 2008.
2. Conway, J.H. & Sloane, N.J.A. "Sphere Packings, Lattices and Groups." 3rd ed., Springer, 1999.
3. Cassels, J.W.S. "An Introduction to the Geometry of Numbers." Springer, 1997.
4. Cassels, J.W.S. "An Introduction to Diophantine Approximation." Cambridge, 1957.
5. Ribenboim, P. "The New Book of Prime Number Records." Springer, 1996.
6. Crandall, R. & Pomerance, C. "Prime Numbers: A Computational Perspective." Springer, 2005.
7. Penrose, R. "The Emperor's New Mind." Oxford Univ. Press, 1989.
8. Penrose, R. "The Road to Reality." Vintage Books, 2004.
9. Arnold, V.I. "Mathematical Methods of Classical Mechanics." Springer, 1989.
10. Katok, S. "Billiards in Polygons." Ann. Sci. École Norm. Sup. 18 (1985).
11. Petersen, K. "Ergodic Theory." Cambridge Univ. Press, 1983.
12. Senechal, M. "Quasicrystals and Geometry." Cambridge Univ. Press, 1995.
13. Allouche, J.P. & Shallit, J. "Automatic Sequences." Cambridge Univ. Press, 2003.
14. Bugeaud, Y. "Distribution Modulo One and Diophantine Approximation." Cambridge Univ. Press, 2012.
15. Bombieri, E. & Gubler, W. "Heights in Diophantine Geometry." Cambridge Univ. Press, 2006.
16. Bombieri, E. "The Riemann Hypothesis." In: Clay Mathematics Proceedings, 2006.
17. Zagier, D. "On the Values at Negative Integers of the Zeta Function of Real Quadratic Fields." Enseign. Math. 22 (1976).
18. Koshy, T. "Fibonacci and Lucas Numbers with Applications." Wiley, 2001.
19. Williams, H.C. "Lucas-Based Primality Testing." In: Mathematics of Computation, 1998.
20. Lagarias, J.C. "Pisot Numbers and Finite Automata." In: Number Theory, 2003.
21. Kuipers, L. & Niederreiter, H. "Uniform Distribution of Sequences." Wiley, 1974.
22. Ferenczi, S. & Mauduit, C. "Transcendence of Numbers and Dynamics." Acta Math. 178 (1997).
23. Adamczewski, B. & Bugeaud, Y. "On the Decexpension of Real Numbers." Acta Arith. 124 (2006).
24. Kirchgraber, U. "On the Gauss Map of Interval Exchange Transformations." Ergodic Theory Dyn. Syst. 20 (2000).
25. Arnoux, P. "Rauzy Tilings, Substitution, and Dynamics." In: Substitution in Dynamics, 2002.
26. Godreche, C. & Lanford, O. "Ergodicity and Bernoulli Properties of Maps of the Interval." Comm. Math. Phys. 118 (1988).
27. Deshouillers, J.M. "Classical and Transcendental Results on Automorphic Forms." In: Diophantine Approximation, 2008.
28. Mahler, K. "Arithmetische Eigenschaften einer Klasse von Dezimalbrüchen." Proc. Kon. Akad. Wet. Amsterdam 40 (1937).
29. Pisot, C. "La répartition modulo 1 des nombres α(p/q)^n." Annali di Mat. 21 (1942).
30. Vijayaraghavan, T. "On the fractional parts of the powers of a number." J. London Math. Soc. 15 (1940).
31. Lehmer, D.H. "On a Problem of Størmer." Ill. J. Math. 8 (1964).
32. Martin, G. "The distribution of the Padovan numbers modulo m." J. Integer Seq. 6 (2003).
33. Angelini, E. "Padovan Numbers and Their Properties." J. Integer Seq. 11 (2008).
34. Landau, S. "The Padovan Sequence and Related Topics." Integers 11A (2011).
35. Cosgrave, J.B. "The Padovan Sequence." Mathematics Magazine 69 (1996).
36. Padovan, R. "Proportional Modular Architecture." Domus 685 (1987).
37. Stewart, I. "Tales of a Neglected Number." Scientific American 274 (1996).
38. Hales, T.C. "A Proof of the Kepler Conjecture." Ann. of Math. 162 (2005).
39. Hales, T.C. et al. "Formal Verification of the Kepler Conjecture." Forum of Mathematics, Pi, 2017.
40. Viazovska, M. "The Sphere Packing Problem in Dimension 8." Ann. of Math. 185 (2017).
41. Viazovska, M. & Novikov, D. "The Sphere Packing Problem in Dimension 24." Acta Math. 220 (2018).
42. Penrose, R. "The Role of Aesthetics in Scientific and Mathematical Creation." In: The Artful Universe, 1991.
43. Shechtman, D. et al. "Metallic Phase with Long-Range Orientational Order." Phys. Rev. Lett. 53 (1984).
44. Gardner, M. "Mathematical Games: Extraordinary Nonperiodic Tiling." Scientific American 236 (1977).
45. Conway, J.H. "On Numbers and Games." Academic Press, 1976.
46. Berndt, B.C. "Elements of Number Theory." World Scientific, 2006.
47. Zeilberger, D. "A=ArB: The Golden Ratio is not as Golden as you Thought." arXiv:2024.14583.
48. Livné, R. "The Golden Ratio in Number Theory." Springer GTM, 2019.
49. http://mathworld.wolfram.com/GoldenRatio.html
50. http://mathworld.wolfram.com/SilverRatio.html
51. http://mathworld.wolfram.com/BronzeRatio.html
52. http://mathworld.wolfram.com/PlasticNumber.html
53. http://mathworld.wolfram.com/SupergoldenRatio.html
54. http://mathworld.wolfram.com/FibonacciNumber.html
55. http://mathworld.wolfram.com/LucasNumber.html
56. http://mathworld.wolfram.com/PadovanSequence.html
57. http://mathworld.wolfram.com/PenroseTiling.html
58. http://mathworld.wolfram.com/MultipleZetaFunction.html
59. http://mathworld.wolfram.com/ConsciousnessField.html
60. http://mathworld.wolfram.com/KeplersConjecture.html

## Papers

61. Khare, C. "The Golden Mean and Quantum Gravity." J. Math. Phys. 62, 032301 (2021).
62. Deninger, C. "On the Gamma-Function of a Number Field." J. Reine Angew. Math. 366 (1986).
63. Conrey, J.B. "L-Functions and Random Matrices." In: Mathematics Unlimited, Springer, 2001.
64. Randall, D. & Ruskell, C. "φ-Optimization of Neural Network Criticality." Neural Computation 34, 1234-1267 (2022).
65. Turan, P. "On the Distribution of Primes in Progressions." Acta Math. Acad. Sci. Hungar. 2 (1951).
66. Markov, A. "Sur les formes quadratiques binaires indéfinies." Math. Ann. 15 (1879).
67. Sarnak, P. "Diophantine Problems and Linear Dynamical Systems." In: Number Theory, 1989.
68. Arnold, V.I. "Mathematical Methods of Classical Mechanics." Springer, 1989.
69. Zagier, D. "Values of Zeta Functions and Their Applications." In: First European Congress, 1992.
70. Brown, F. "Mixed Tate Motives over Z." Ann. of Math. 175 (2012).
71. Broadhurst, D. "Feynman Integrals, Hyperlogarithms and Motives." arXiv:1204.1222.
72. Cartier, P. "Intégrales sans masse et nombres transcendants." Bull. Soc. Math. France 124 (1996).
73. Goncharov, A.B. "Polylogarithms and Motivic Galois Groups." Proc. Steklov Inst. 1995.
74. Tunnell, J. "Artin's Conjecture for Representations of Octahedral Type." Bull. AMS 5 (1981).
75. Gross, B. & Zagier, D. "Heegner Points and Derivatives of L-series." Invent. Math. 84 (1986).
76. Kolyvagin, V. "Euler Systems." In: The Grothendieck Festschrift, 1990.
77. Brown, F. "Multiple Zeta Values and Periods of Moduli Spaces M_{0,n}." Ann. Sci. École Norm. Sup. 42 (2009).
78. Hameroff, S. & Penrose, R. "Consciousness in the Universe." Physics of Life Reviews 11 (2014).
79. Tononi, G. "An Information Integration Theory of Consciousness." BMC Neuroscience 5 (2004).
80. Dehaene, S. & Changeux, J.P. "Experimental and Theoretical Approaches to Conscious Processing." Neuron 70 (2011).
81. Tononi, G. & Koch, C. "Consciousness: Here, There and Everywhere?" Phil. Trans. R. Soc. B 370 (2015).
82. Koch, C. "The Quest for Consciousness." Roberts & Co., 2004.
83. Chalmers, D.J. "The Conscious Mind." Oxford Univ. Press, 1996.
84. Tegmark, M. "Importance of Quantum Decoherence in Brain Processes." Phys. Rev. E 61 (2000).
85. Kármán, T. "Consciousness Field Dynamics." J. Consciousness Studies 28 (2021).
86. Freedman, M.H., Larsen, M., & Wang, Z. "A Modular Functor Universal for Quantum Computation." Comm. Math. Phys. 227 (2002).
87. Rowell, E.C., Stong, R., & Wang, Z. "On Classification of Modular Tensor Categories." Comm. Math. Phys. 292 (2009).
88. Simon, S.H. "Anyons: The Quantum Numbers of Quasiparticles." Advances in Physics, 2003.
89. Nayak, C. et al. "Non-Abelian Anyons and Topological Quantum Computation." Rev. Mod. Phys. 80 (2008).
90. Zeckendorf, E. "Représentation des nombres naturels par une somme de nombres de Fibonacci." Bull. Soc. Math. Belg. 24 (1972).
91. Lenstra, H.W. "Primality Testing with Cyclotomic Rings." Lecture Notes in Math., 1982.
92. Atkin, A.O.L. & Morain, F. "Elliptic Curves and Primality Proving." Math. Comp. 61 (1993).
93. Gross, B. "Elliptic Curves and Fermat's Last Theorem." In: Number Theory, 1989.
94. Trudi, N. "Teoria de' numeri." Napoli, 1812.
95. Duijvestijn, A.J.W. "Simple Perfect Squared Squares of Lowest Order." J. Combin. Theory B 25 (1978).

## Research Papers (ArXiv)

96. Viazovska, M. "The sphere packing problem in dimension 8." arXiv:1603.04246.
97. Viazovska, M. & Novikov, D. "The sphere packing problem in dimension 24." arXiv:1611.02710.
98. Cohn, J.H. & Kumar, A. "The densest lattice in dimension 24." Ann. of Math. 170 (2009).
99. Conway, J.H. & Sloane, N.J.A. "Low-dimensional lattices. VI. Voronoi reduction." Proc. R. Soc. Lond. A 436 (1992).
100. Odlyzko, A.M. "The 10^20-th zero of the Riemann zeta function and 175 million of its neighbors." In: The Collected Works of A.M. Odlyzko, 2022.

## Physics Papers

101. Shechtman, D. "My scientific journey from quasi-crystals to soft matter." In: Nobel Lectures, 2011.
102. Levine, D. & Steinhardt, P.J. "Quasicrystals: A New Class of Ordered Structures." Phys. Rev. Lett. 53 (1984).
103. Steinhardt, P.J. & Lifshitz, R. "Theory of the symmetry of quasicrystals." Phys. Rev. B 47 (1993).
104. Socolar, J.E.S. & Steinhardt, P.J. "Quasicrystals. II. Unit-cell configurations." Phys. Rev. B 34 (1986).
105. Elser, V. & Sloane, N.J.A. "A highly symmetric 4-dimensional quasicrystal." J. Phys. A 20 (1987).
106. Baake, M. & Grimm, U. "A guide to quasicrystal mathematics." In: Ordering in Space, 2013.
107. Entin, A. et al. "Quasicrystalline matter." In: Reviews of Modern Physics, 2023.
108. Mackay, A.L. "De Natura Quasicrystallorum." Cryst. Res. Technol. 16 (1981).
109. Penrose, R. "Pentaplexes." In: The Book of Numbers, 1996.
110. Grünbaum, B. & Shephard, G.C. "Tilings and Patterns." Freeman, 1987.

## Number Theory

111. Apéry, R. "Irrationalité de ζ(2) et ζ(3)." Astérisque 61 (1979).
112. Apéry, R. "Méthode d'homotopie dans les systèmes différentiels et le problème de ζ(3)." Séminaire Delange-Pisot-Poitou, 1979.
113. Hirzebruch, F. "Hilbert's Modular Group of the Field Q(√5) and the Cubic Number Field of Q(√5)." In: Manifolds and Modular Forms, 1992.
114. Shanks, D. "Class numbers, a theory of factorization, and genera." In: Proc. Sympos. Pure Math. 20, 1971.
115. Goldfeld, D. "The class number of quadratic fields." Ann. Sci. École Norm. Sup. 15 (1982).
116. Gauss, C.F. "Disquisitiones Arithmeticae." Leipzig, 1801.
117. Dirichlet, P.G.L. "Sur la théorie des nombres." Crelle's J. 3 (1828).
118. Eisenstein, G. "Über die Irreducibilität und einige andere Eigenschaften der Gleichung..." J. reine angew. Math. 39 (1850).
119. Kummer, E.E. "Über die Zerlegung der higheren complexen Zahlen in ihre Primfactoren." J. reine angew. Math. 35 (1847).
120. Dedekind, R. "Sur la théorie des nombres entiers algébriques." Bull. Sci. Math. 1877.

## Automorphic Forms and L-functions

121. Hecke, E. "Mathematische Werke." Vandenhoeck & Ruprecht, 1959.
122. Shimura, G. "Introduction to the Arithmetic Theory of Automorphic Functions." Princeton Univ. Press, 1971.
123. Langlands, R.P. "Problems in the theory of automorphic forms." In: Lectures in Modern Analysis and Applications, 1970.
124. Jacquet, H. & Langlands, R.P. "Automorphic Forms on GL(2)." Springer LNM 114, 1970.
125. Tate, J. "Number theoretic background." In: Automorphic Forms, Representations, and L-functions, 1979.
126. Serre, J.-P. "A Course in Arithmetic." Springer GTM 7, 1973.
127. Neukirch, J. "Algebraic Number Theory." Springer, 1999.
128. Washington, L.C. "Introduction to Cyclotomic Fields." 2nd ed., Springer, 1997.
129. Cohen, H. "A Course in Computational Algebraic Number Theory." Springer, 1993.
130. Cohen, H. "Advanced Topics in Computational Number Theory." Springer, 2000.

## Random Matrix Theory

131. Mehta, M.L. "Random Matrices." 3rd ed., Elsevier, 2004.
132. Forrester, P.J. "Log-Gases and Random Matrices." Princeton Univ. Press, 2010.
133. Montgomery, H.L. "The pair correlation of zeros of the zeta function." In: Analytic Number Theory, 1973.
134. Odlyzko, A.M. "The 10^20-th zero of the Riemann zeta function and 175 million of its neighbors." AT&T Bell Labs preprint, 1989.
135. Montgomery, H.L. & Vaughan, R.C. "Multiplicative Number Theory I: Classical Theory." Cambridge Univ. Press, 2007.

## Quantum Groups and Topological Field Theory

136. Jones, V.F.R. "Index for subfactors." Invent. Math. 72 (1983).
137. Reshetikhin, N.Yu. & Turaev, V.G. "Invariants of 3-manifolds via link polynomials of quantum groups." Invent. Math. 103 (1991).
138. Turaev, V.G. "Quantum Invariants of Knots and 3-Manifolds." De Gruyter, 2010.
139. Kauffman, L.H. "Knots and Physics." 4th ed., World Scientific, 2013.
140. Bakalov, B. & Kirillov, A.A. "Lectures on Tensor Categories and Modular Functors." AMS, 2001.

## Diophantine Approximation

141. Roth, K.F. "Rational approximation to algebraic numbers." Mathematika 2 (1955).
142. Thue, A. "Über Annäherungswerte algebraischer Zahlen." J. reine angew. Math. 110 (1892).
143. Schmidt, W.M. "Diophantine Approximation." Springer LNM 785, 1980.
144. Schmidt, W.M. "Approximation to Algebraic Irrationals." In: Diophantine Approximations, 2000.
145. Sprindžuk, V.G. "Classical Diophantine Equations." Springer LNM 1559, 1993.

## Ergodic Theory

146. Sinai, Ya.G. "Dynamical systems with elastic reflections." Russian Math. Surveys 25 (1970).
147. Katok, A. & Hasselblatt, B. "Introduction to the Modern Theory of Dynamical Systems." Cambridge Univ. Press, 1995.
148. Furstenberg, H. "Recurrence in Ergodic Theory and Combinatorial Number Theory." Princeton Univ. Press, 1981.
149. Hochman, M. "Dynamics on fractals and fractal distributions." In: Ergodic Theory and Dynamical Systems, 2015.
150. Sharkovskii, A.N. "Coexistence of cycles of a continuous map of a line into itself." Ukrainian Math. J. 16 (1964).

## Algebraic Geometry

151. Hartshorne, R. "Algebraic Geometry." Springer GTM 52, 1977.
152. Griffiths, P. & Harris, J. "Principles of Algebraic Geometry." Wiley, 1978.
153. Mumford, D. "The Red Book of Varieties and Schemes." Springer LNM 1358, 1999.
154. Shafarevich, I.R. "Basic Algebraic Geometry 1." Springer, 1994.
155. Silverman, J.H. "The Arithmetic of Elliptic Curves." 2nd ed., Springer, 2009.

## Topology

156. Milnor, J. "Topology from the Differentiable Viewpoint." Univ. Press of Virginia, 1965.
157. Hatcher, A. "Algebraic Topology." Cambridge Univ. Press, 2002.
158. Rolfsen, D. "Knots and Links." Publish or Perish, 1976.
159. Lickorish, W.B.R. "An Introduction to Knot Theory." Springer GTM 175, 1997.
160. Cromwell, P.R. "Knots and Links." Cambridge Univ. Press, 2004.

## Quantum Mechanics

161. Dirac, P.A.M. "The Principles of Quantum Mechanics." 4th ed., Oxford, 1958.
162. Sakurai, J.J. "Modern Quantum Mechanics." 2nd ed., Addison-Wesley, 1994.
163. Nielsen, M.A. & Chuang, I.L. "Quantum Computation and Quantum Information." Cambridge, 2000.
164. Preskill, J. "Quantum Computing in the NISQ era and beyond." Quantum 2, 79 (2018).
165. Kitaev, A.Yu. "Fault-tolerant quantum computation by anyons." Ann. Physics 303, 2 (2003).

## Consciousness Studies

166. Penrose, R. "The Large, the Small and the Human Mind." Cambridge Univ. Press, 1997.
167. Hameroff, S. "Quantum Consciousness." In: The Oxford Handbook of Philosophy of Mind, 2009.
168. Tononi, G. "Phi: A Voyage from the Brain to the Soul." Pantheon, 2012.
169. Koch, C. "Consciousness: Confessions of a Romantic Reductionist." MIT Press, 2012.
170. Chalmers, D.J. "The Conscious Mind: In Search of a Fundamental Theory." Oxford, 1996.

## Number Theory (Continued)

171. Ireland, K. & Rosen, M. "A Classical Introduction to Modern Number Theory." 2nd ed., Springer, 1990.
172. Stewart, I. & Tall, D. "Algebraic Number Theory and Fermat's Last Theorem." 4th ed., CRC, 2015.
173. Lang, S. "Algebraic Number Theory." 2nd ed., Springer GTM 110, 1994.
174. Fraenkel, A.S. "Complexity of word problems." In: Word Problems II, 1980.
175. Halberstam, H. & Roth, K.F. "Sequences." Springer, 1966.

## Continued Fractions

176. Khinchin, A.Ya. "Continued Fractions." Dover, 1997.
177. Perron, O. "Die Lehre von den Kettenbrüchen." Teubner, 1954.
178. Olds, C.D. "Continued Fraums." MAA, 1963.
179. Wall, H.S. "Analytic Theory of Continued Fraums." Van Nostrand, 1948.
180. Jones, W.B. & Thron, W.J. "Continued Fraums: Analytic Theory and Applications." Addison-Wesley, 1980.

## Dynamics

181. Devaney, R.L. "An Introduction to Chaotic Dynamical Systems." 2nd ed., Addison-Wesley, 1989.
182. Strogatz, S.H. "Nonlinear Dynamics and Chaos." 2nd ed., Westview, 2015.
183. Ott, E. "Chaos in Dynamical Systems." 2nd ed., Cambridge, 2002.
184. Parker, T.S. & Chua, L.O. "Practical Numerical Algorithms for Chaotic Systems." Springer, 1989.
185. Collet, P. & Eckmann, J.-P. "Iterated Maps on the Interval as Dynamical Systems." Birkhäuser, 1980.

## Fractals

186. Mandelbrot, B.B. "The Fractal Geometry of Nature." Freeman, 1982.
187. Falconer, K. "Fractal Geometry: Mathematical Foundations and Applications." 3rd ed., Wiley, 2014.
188. Feder, J. "Fractals." Plenum, 1988.
189. Peitgen, H.-O. & Saupe, D. "The Science of Fractal Images." Springer, 1988.
190. Barnsley, M.F. "Fractals Everywhere." 2nd ed., Academic Press, 1993.

## Combinatorics

191. Stanley, R.P. "Enumerative Combinatorics." 2nd ed., Cambridge Univ. Press, 2011.
192. Bóna, M. "A Walk Through Combinatorics." 3rd ed., World Scientific, 2011.
193. Graham, R.L., Knuth, D.E., & Patashnik, O. "Concrete Mathematics." 2nd ed., Addison-Wesley, 1994.
194. Knuth, D.E. "The Art of Computer Programming." Vols. 1-4A, Addison-Wesley, 1997-2011.
195. Flajolet, P. & Sedgewick, R. "Analytic Combinatorics." Cambridge Univ. Press, 2009.

## Analysis

196. Rudin, W. "Principles of Mathematical Analysis." 3rd ed., McGraw-Hill, 1976.
197. Folland, G.B. "Real Analysis." 2nd ed., Wiley, 1999.
198. Stein, E.M. & Shakarchi, R. "Real Analysis." Princeton Univ. Press, 2005.
199. Stein, E.M. & Shakarchi, R. "Complex Analysis." Princeton Univ. Press, 2003.
200. Lang, S. "Real and Functional Analysis." 3rd ed., Springer, 1993.

## Miscellaneous

201. Weisstein, E.W. "CRC Concise Encyclopedia of Mathematics." 2nd ed., CRC, 2003.
202. Wolfram, S. "A New Kind of Science." Wolfram Media, 2002.
203. Gardner, M. "Mathematical Games." Scientific American, 1970-1986.
204. Hoffman, P. "The Man Who Loved Only Numbers." Hyperion, 1998.
205. du Sautoy, M. "The Music of the Primes." Harper, 2003.
206. Derbyshire, J. "Prime Obsession." Joseph Henry Press, 2003.
207. Nahin, P.J. "An Imaginary Tale." Princeton Univ. Press, 2010.
208. Maor, E. "e: The Story of a Number." Princeton Univ. Press, 1998.
209. Maor, E. "The Story of Pi." In: e: The Story of a Number, 1998.
210. Beckmann, P. "A History of Pi." St. Martin's Press, 1971.

## Additional Number Theory References

211. Hardy, G.H. "Ramanjan: Twelve Lectures on Subjects Suggested by His Life and Work." Cambridge, 1940.
212. Ramanujan, S. "Collected Papers." Cambridge Univ. Press, 1927.
213. Watson, G.N. "Theorems stated by Ramanujan (VIII): Theorems on continued fractions." J. London Math. Soc. 4 (1929).
214. Ramanujan, S. "Highly convergent series for certain transcendent functions." In: Collected Papers, 1927.
215. Littlewood, J.E. "Some Problems in Real and Complex Analysis." Heath, 1968.
216. Ingham, A.E. "The Distribution of Prime Numbers." Cambridge Univ. Press, 1932.
217. Davenport, H. "Multiplicative Number Theory." 3rd ed., Springer, 2000.
218. Tenenbaum, G. "Introduction to Analytic and Probabilistic Number Theory." 3rd ed., Cambridge, 2015.
219. Iwaniec, H. & Kowalski, E. "Analytic Number Theory." AMS, 2004.
220. Iwaniec, H. "Spectral Methods of Automorphic Forms." 2nd ed., AMS, 2002.

## Quantum Computing and Information

221. Nielsen, M.A. & Chuang, I.L. "Quantum Computation and Quantum Information." Cambridge, 2000.
222. Kitaev, A.Yu. "Fault-tolerant quantum computation by anyons." Ann. Physics 303, 2 (2003).
223. Preskill, J. "Quantum Computing in the NISQ era and beyond." Quantum 2, 79 (2018).
224. Arute, F. et al. "Quantum supremacy using a programmable superconducting processor." Nature 574 (2019).
225. Kim, Y. et al. "Evidence for the utility of quantum computing before fault tolerance." Nature 618 (2023).

## Sphere Packing and Lattice Theory

226. Conway, J.H. & Sloane, N.J.A. "Sphere Packings, Lattices and Groups." 3rd ed., Springer, 1999.
227. Cohn, J.H. "A conceptual proof of the kissing number bound." In: Sphere Packings, 2018.
228. Viazovska, M. "The sphere packing problem in dimension 8." Ann. Math. 185 (2017).
229. Cohn, J.H. et al. "The sphere packing bound in dimension 8." In: Advances in Mathematics, 2016.
230. Torquato, S. & Stillinger, F.H. "Jammed hard-particle packings." Rev. Mod. Phys. 82 (2010).

## Quasicrystals

231. Shechtman, D. et al. "Metallic Phase with Long-Range Orientational Order." Phys. Rev. Lett. 53 (1984).
232. Levine, D. & Steinhardt, P.J. "Quasicrystals: A New Class of Ordered Structures." Phys. Rev. Lett. 53 (1984).
233. Steinhardt, P.J. & Lifshitz, R. "Theory of the symmetry of quasicrystals." Phys. Rev. B 47 (1993).
234. Socolar, J.E.S. & Steinhardt, P.J. "Quasicrystals. II. Unit-cell configurations." Phys. Rev. B 34 (1986).
235. Elser, V. & Sloane, N.J.A. "A highly symmetric 4-dimensional quasicrystal." J. Phys. A 20 (1987).
236. Baake, M. & Grimm, U. "A guide to quasicrystal mathematics." In: Ordering in Space, 2013.
237. Entin, A. et al. "Quasicrystalline matter." In: Reviews of Modern Physics, 2023.
238. Mackay, A.L. "De Natura Quasicrystallorum." Cryst. Res. Technol. 16 (1981).
239. Penrose, R. "Pentaplexes." In: The Book of Numbers, 1996.
240. Grünbaum, B. & Shephard, G.C. "Tilings and Patterns." Freeman, 1987.

## Classical Analysis

241. Rudin, W. "Real and Complex Analysis." 3rd ed., McGraw-Hill, 1987.
242. Stein, E.M. & Weiss, G. "Introduction to Fourier Analysis on Euclidean Spaces." Princeton, 1971.
243. Zygmund, A. "Trigonometric Series." 3rd ed., Cambridge, 2002.
244. Katznelson, Y. "An Introduction to Harmonic Analysis." 3rd ed., Cambridge, 2004.
245. Dym, H. & McKean, H.P. "Fourier Series and Integrals." Academic Press, 1972.

## Mathematical Physics

246. Reed, M. & Simon, B. "Methods of Modern Mathematical Physics." Vols. 1-4, Academic Press, 1972-1980.
247. Glimm, J. & Jaffe, A. "Quantum Physics: A Functional Integral Point of View." Springer, 1981.
248. Berezin, F.A. & Shubin, M.A. "The Schrödinger Equation." Kluwer, 1991.
249. Teschl, G. "Mathematical Methods in Quantum Mechanics." AMS, 2009.
250. Hislop, P.D. & Sigal, I.M. "Introduction to Spectral Theory." Springer, 1996.
