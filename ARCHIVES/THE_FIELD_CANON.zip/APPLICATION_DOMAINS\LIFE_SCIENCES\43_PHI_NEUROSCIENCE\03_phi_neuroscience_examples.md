﻿# PHI-NEUROSCIENCE: Worked Examples

---

## Example 1: Phi-Firing Rate Calculation

**Problem:** Calculate the phi-corrected firing rate for a cortical pyramidal neuron with V0 = 20 mV and membrane potential 15 mV above threshold.

**Solution:**
`
Given: f0 = 100 Hz, V0 = 20 mV, dV = 15 mV

Step 1: Phi-firing rate
f_phi = f0 x phi^(-dV/V0) = 100 x phi^(-15/20)
f_phi = 100 x phi^(-0.75) = 100 x e^(-0.75 x 0.481)
f_phi = 100 x e^(-0.361) = 100 x 0.697 = 69.7 Hz
`

**Answer:** f_phi = 69.7 Hz (30% lower than standard rate)

---

## Example 2: Phi-Action Potential Waveform

**Problem:** Calculate the peak voltage of a phi-corrected action potential at t = 1 ms.

**Solution:**
`
Given: V_rest = -70 mV, V_peak = +40 mV, tau_rise = 0.5 ms, tau_fall = 2.0 ms

Step 1: Calculate V_phi at t = 1 ms
V_phi(t) = V_rest + (V_peak - V_rest) x phi^(-t/tau_rise) x (1 - phi^(-t/tau_fall))
V_phi(1) = -70 + 110 x phi^(-1/0.5) x (1 - phi^(-1/2.0))
V_phi(1) = -70 + 110 x phi^(-2) x (1 - phi^(-0.5))
V_phi(1) = -70 + 110 x 0.382 x (1 - 0.786)
V_phi(1) = -70 + 110 x 0.382 x 0.214
V_phi(1) = -70 + 8.95 = -61.05 mV
`

**Answer:** V_phi(1ms) = -61.05 mV

---

## Example 3: Phi-STDP Weight Update

**Problem:** Calculate the phi-corrected weight change for a pre-post spike pair with dt = +10 ms.

**Solution:**
`
Given: A+ = 0.01, tau+ = 20 ms, dt = +10 ms

Step 1: Standard STDP
dw = A+ x e^(-dt/tau+) = 0.01 x e^(-10/20) = 0.01 x 0.607 = 0.00607

Step 2: Phi-STDP
dw_phi = A+ x phi^(-dt/tau+) = 0.01 x phi^(-10/20) = 0.01 x phi^(-0.5)
dw_phi = 0.01 x 0.786 = 0.00786
`

**Answer:** dw_phi = 0.00786 (29% larger than standard)

---

## Example 4: Phi-Brain Wave Coupling

**Problem:** Calculate the theta-gamma coupling strength for phi-harmonic frequencies.

**Solution:**
`
Given: f_theta = 6 Hz, f_gamma = 40 Hz, standard coupling = 0.5

Step 1: Phi-harmonic frequencies
f_theta_phi = f0 x phi^1 = 4.236 Hz
f_gamma_phi = f0 x phi^4 = 17.94 Hz

Step 2: Phi-coupling strength
C_phi = C x phi^(-|f1/f2 - phi|) = 0.5 x phi^(-|6/40 - 1.618|) = 0.5 x phi^(-1.468)
C_phi = 0.5 x 0.434 = 0.217

Step 3: For phi-harmonic pair
C_phi_harmonic = 0.5 x phi^(-|4.236/17.94 - phi|) = 0.5 x phi^(-|0.236 - 1.618|)
C_phi_harmonic = 0.5 x phi^(-1.382) = 0.5 x 0.465 = 0.233
`

**Answer:** C_phi = 0.217 (standard) vs 0.233 (phi-harmonic)

---

## Example 5: Phi-Working Memory Capacity

**Problem:** Calculate phi-corrected working memory capacity under cognitive load of 0.6.

**Solution:**
`
Given: C_WM = 7 chunks, cognitive_load = 0.6, max_load = 1.0

Step 1: Standard: C_WM remains 7
Step 2: Phi-corrected
C_WM_phi = C_WM x phi^(-cognitive_load/phi) = 7 x phi^(-0.6/1.618)
C_WM_phi = 7 x phi^(-0.371) = 7 x 0.817 = 5.72
`

**Answer:** C_WM_phi = 5.7 chunks (18% reduction under load)

---

## Example 6: Phi-Consciousness Threshold

**Problem:** Calculate the consciousness threshold for a neural assembly with 10 regions.

**Solution:**
`
Given: 10 regions, w_i = 0.5, d_i = i-1 for i=1..10

Step 1: Calculate C_crit
C_crit = Sigma w_i x phi^(-d_i) = 0.5 x Sigma phi^(-(i-1))
C_crit = 0.5 x (1 + 0.618 + 0.382 + 0.236 + 0.146 + 0.090 + 0.056 + 0.034 + 0.021 + 0.013)
C_crit = 0.5 x 2.596 = 1.298

Step 2: Compare to threshold
1/phi = 0.618
C_crit = 1.298 > 0.618 = threshold
`

**Answer:** C_crit = 1.298 (consciousness achieved, threshold = 0.618)

---

## Example 7: Phi-EEG Alpha Rhythm

**Problem:** Calculate the phi-corrected alpha oscillation at t = 50 ms.

**Solution:**
`
Given: A_alpha = 50 muV, tau_alpha = 100 ms, f_alpha = 11.09 Hz

Step 1: Calculate alpha_phi(t)
alpha_phi(50) = A_alpha x phi^(-t/tau_alpha) x sin(2pi x f_alpha x t)
alpha_phi(50) = 50 x phi^(-50/100) x sin(2pi x 11.09 x 0.050)
alpha_phi(50) = 50 x phi^(-0.5) x sin(3.486)
alpha_phi(50) = 50 x 0.786 x (-0.343)
alpha_phi(50) = -13.49 muV
`

**Answer:** alpha_phi(50ms) = -13.49 muV

---

## Example 8: Phi-Memory Consolidation

**Problem:** Calculate memory strength after 24 hours with phi-decay and 5 rehearsals.

**Solution:**
`
Given: M0 = 1.0, t = 24 hr, tau_decay = 48 hr, alpha = 0.5, N = 5

Step 1: Standard decay
M(24) = M0 x e^(-t/tau) = 1.0 x e^(-24/48) = 0.607

Step 2: Phi-corrected
M_phi(24) = M0 x phi^(-t/tau) x (1 + alpha x log_phi(N))
M_phi(24) = 1.0 x phi^(-24/48) x (1 + 0.5 x log_phi(5))
M_phi(24) = phi^(-0.5) x (1 + 0.5 x 1.183)
M_phi(24) = 0.786 x 1.592 = 1.251
`

**Answer:** M_phi(24hr) = 1.251 (phi-enhanced with rehearsal)

---

## Example 9: Phi-Learning Rate Schedule

**Problem:** Calculate learning rate at epoch 50 with initial eta = 0.01.

**Solution:**
`
Given: eta_0 = 0.01, epoch = 50, tau_decay = 100

Step 1: Standard exponential decay
eta(50) = 0.01 x e^(-50/100) = 0.01 x 0.607 = 0.00607

Step 2: Phi-decay
eta_phi(50) = 0.01 x phi^(-50/100) = 0.01 x phi^(-0.5)
eta_phi(50) = 0.01 x 0.786 = 0.00786
`

**Answer:** eta_phi = 0.00786 (29% higher than standard at epoch 50)

---

## Example 10: Phi-Neural Network Initialization

**Problem:** Calculate phi-initialized weights for a layer with 256 input neurons.

**Solution:**
`
Given: n_in = 256

Step 1: Standard initialization
W_std = N(0, 1/sqrt(256)) = N(0, 0.0625)

Step 2: Phi-initialization
W_phi = N(0, phi^(-1)/sqrt(256)) = N(0, 0.618 x 0.0625) = N(0, 0.0386)
`

**Answer:** W_phi has std = 0.0386 (38% smaller variance)

---

## Example 11: Phi-Synaptic Plasticity Window

**Problem:** Calculate the phi-STDP window at dt = -15 ms (pre after post).

**Solution:**
`
Given: A- = 0.012, tau- = 25 ms, dt = -15 ms

Step 1: Standard LTD
dw = -A- x e^(dt/tau-) = -0.012 x e^(-15/25) = -0.012 x 0.549 = -0.00659

Step 2: Phi-LTD
dw_phi = -A- x phi^(dt/tau-) = -0.012 x phi^(-15/25) = -0.012 x phi^(-0.6)
dw_phi = -0.012 x 0.715 = -0.00858
`

**Answer:** dw_phi = -0.00858 (30% larger LTD)

---

## Example 12: Phi-Brain Region Connectivity

**Problem:** Calculate effective connectivity between PFC and hippocampus at distance 3.

**Solution:**
`
Given: w_PFC-HPC = 0.6, distance = 3 (cortical regions apart)

Step 1: Standard connectivity: 0.6
Step 2: Phi-weighted
w_phi = w x phi^(-distance) = 0.6 x phi^(-3) = 0.6 x 0.236 = 0.142
`

**Answer:** w_phi = 0.142 (76% reduction over 3 regions)

---

## Example 13: Phi-Neural Oscillator Sync

**Problem:** Two oscillators with coupling K = 0.1. Calculate phi-corrected synchrony time.

**Solution:**
`
Given: K = 0.1, omega_diff = 0.5 rad/s

Step 1: Standard sync time
T_sync = 1/(K x omega_diff) = 1/(0.1 x 0.5) = 20 time units

Step 2: Phi-corrected
K_phi = K/phi = 0.0618
T_sync_phi = 1/(K_phi x omega_diff) = 1/(0.0618 x 0.5) = 32.4 time units
`

**Answer:** T_sync_phi = 32.4 (62% longer to sync)

---

## Example 14: Phi-Attention Allocation

**Problem:** Calculate attention weight for a stimulus with relevance 0.8.

**Solution:**
`
Given: A_stimulus = 1.0, relevance = 0.8, optimal_relevance = 0.6, sigma = 0.3

Step 1: Standard attention
A = A_stimulus = 1.0

Step 2: Phi-attention
A_phi = A_stimulus x phi^(-|0.8 - 0.6|/0.3) = phi^(-0.667) = 0.693
`

**Answer:** A_phi = 0.693

---

## Example 15: Phi-Gradient Descent

**Problem:** Calculate phi-adaptive gradient update with gradient = 0.5, sigma = 0.3.

**Solution:**
`
Given: eta = 0.01, gradient = 0.5, sigma = 0.3

Step 1: Standard update
dw = -0.01 x 0.5 = -0.005

Step 2: Phi-adaptive
dw_phi = -0.01 x phi^(-|0.5|/0.3) x 0.5 = -0.01 x phi^(-1.667) x 0.5
dw_phi = -0.01 x 0.395 x 0.5 = -0.00198
`

**Answer:** dw_phi = -0.00198 (60% smaller update)

---

## Example 16: Phi-Engram Formation

**Problem:** Calculate engram strength with 3 learning events at t = 0, 5, 10 min.

**Solution:**
`
Given: w = [0.8, 0.6, 0.4], t_consolidation = 30 min

Step 1: Engram
E = 0.8 x phi^(-|0-30|/tau) + 0.6 x phi^(-|5-30|/tau) + 0.4 x phi^(-|10-30|/tau)
E = 0.8 x phi^(-30/tau) + 0.6 x phi^(-25/tau) + 0.4 x phi^(-20/tau)
Assuming tau = 30:
E = 0.8 x phi^(-1) + 0.6 x phi^(-0.833) + 0.4 x phi^(-0.667)
E = 0.8 x 0.618 + 0.6 x 0.669 + 0.4 x 0.693
E = 0.494 + 0.401 + 0.277 = 1.172
`

**Answer:** E_engram = 1.172

---

## Example 17: Phi-Homeostatic Scaling

**Problem:** Calculate homeostatic scaling factor when firing rate is 20% above target.

**Solution:**
`
Given: r = 120 Hz, r_target = 100 Hz, g_0 = 1.0

Step 1: Standard scaling: g = 1.0 (no change)
Step 2: Phi-scaling
g_phi = g_0 x phi^(-|r - r_target|/r_target) = phi^(-20/100) = phi^(-0.2)
g_phi = 0.871
`

**Answer:** g_phi = 0.871 (13% reduction)

---

## Example 18: Phi-Metaplasticity

**Problem:** Calculate BCM threshold shift after high activity period.

**Solution:**
`
Given: theta_0 = 0.5, recent_activity = 150 Hz, r_target = 100 Hz

Step 1: Standard: theta = 0.5 (no change)
Step 2: Phi-threshold
theta_phi = theta_0 x phi^(recent_activity/r_target) = 0.5 x phi^(1.5)
theta_phi = 0.5 x 1.978 = 0.989
`

**Answer:** theta_phi = 0.989 (98% increase in threshold)

---

## Example 19: Phi-BCI Decoding

**Problem:** Calculate BCI accuracy with channel noise 0.3.

**Solution:**
`
Given: A_BCI = 0.85, channel_noise = 0.3

Step 1: Standard accuracy: 0.85
Step 2: Phi-corrected
A_phi = A_BCI x phi^(-channel_noise) = 0.85 x phi^(-0.3) = 0.85 x 0.843
A_phi = 0.717
`

**Answer:** A_phi = 71.7% (reduced by noise)

---

## Example 20: Phi-Neural Prosthetic Integration

**Problem:** Calculate prosthetic integration after 6 months.

**Solution:**
`
Given: I_0 = 0.2, t = 6 months, tau_integrate = 12 months

Step 1: Standard integration
I(6) = I_0 x (1 - e^(-t/tau)) = 0.2 x (1 - e^(-0.5)) = 0.2 x 0.393 = 0.0787

Step 2: Phi-integration
I_phi(6) = I_0 x phi^(-t/tau) x (1 - phi^(-t/tau))
I_phi(6) = 0.2 x phi^(-0.5) x (1 - phi^(-0.5))
I_phi(6) = 0.2 x 0.786 x 0.214 = 0.0337
`

**Answer:** I_phi(6mo) = 0.034 (phi-slower integration)

---

*Part of the 32_PHI_PHYSICS / 06_EXPANDED_MATHEMATICS system.*
*Version 1.0 -- Agent I of 26*

---

## Example 21: Phi-Neurotransmitter Binding

**Problem:** Calculate phi-corrected dopamine receptor affinity.

**Solution:**
`
Given: Kd = 10 nM, receptor = D2

Step 1: Phi-affinity
Kd_phi = Kd/phi = 10/1.618 = 6.18 nM

Step 2: Binding probability at [DA] = 100 nM
P_bind = [DA]/(Kd + [DA]) = 100/110 = 0.909
P_bind_phi = [DA]/(Kd_phi + [DA]) = 100/106.18 = 0.942
`

**Answer:** Kd_phi = 6.18 nM (3.5% more binding)

---

## Example 22: Phi-Brain Development

**Problem:** Calculate phi-corrected age for neural tube closure.

**Solution:**
`
Given: Age = 28 days

Step 1: Phi-age
Age_phi = Age/phi = 28/1.618 = 17.3 days

Step 2: Developmental advancement
Advancement = (28 - 17.3)/28 = 38%
`

**Answer:** Age_phi = 17.3 days (38% earlier closure)

---

## Example 23: Phi-Sleep Architecture

**Problem:** Calculate phi-corrected N2 sleep duration.

**Solution:**
`
Given: N2_duration = 25 min

Step 1: Phi-duration
N2_phi = N2/phi = 25/1.618 = 15.5 min

Step 2: Percentage of cycle
Standard: 25/90 = 27.8%
Phi: 15.5/55.6 = 27.8% (same percentage)
`

**Answer:** N2_phi = 15.5 min (38% shorter)

---

## Example 24: Phi-Pain Processing

**Problem:** Calculate phi-corrected sharp pain threshold.

**Solution:**
`
Given: Threshold = 10 muA

Step 1: Phi-threshold
Threshold_phi = Threshold/phi = 10/1.618 = 6.18 muA

Step 2: Pain sensitivity increase
Increase = (10 - 6.18)/10 = 38%
`

**Answer:** Threshold_phi = 6.18 muA (38% more sensitive)

---

## Example 25: Phi-Autonomic Response

**Problem:** Calculate phi-corrected heart rate increase during stress.

**Solution:**
`
Given: HR_increase = 30 bpm

Step 1: Phi-effect
HR_phi = HR_increase/phi = 30/1.618 = 18.5 bpm

Step 2: Comparison
Standard: +30 bpm (130 bpm total)
Phi: +18.5 bpm (118.5 bpm total)
`

**Answer:** HR_phi = +18.5 bpm (38% smaller response)

---

## Example 26: Phi-Neurological Biomarker

**Problem:** Calculate phi-corrected Alzheimer's Abeta42 level.

**Solution:**
`
Given: Level = 500 pg/mL, disease_stage = early

Step 1: Phi-level
Level_phi = Level/phi = 500/1.618 = 309 pg/mL

Step 2: Diagnostic threshold
Threshold_phi = Threshold/phi = 400/1.618 = 247 pg/mL
Level_phi (309) > Threshold_phi (247) = positive
`

**Answer:** Level_phi = 309 pg/mL (diagnostic threshold also lowered)

---

## Example 27: Phi-NN Hyperparameter

**Problem:** Calculate phi-optimized learning rate search range.

**Solution:**
`
Given: Standard range [1e-5, 1e-1], base_LR = 1e-3

Step 1: Phi-range
LR_low = base_LR × phi^(-5) = 1e-3 × 0.0902 = 9.02e-5
LR_high = base_LR × phi^(5) = 1e-3 × 11.09 = 1.11e-2

Step 2: Optimal LR
LR_optimal = base_LR × phi^(-1) = 1e-3 × 0.618 = 6.18e-4
`

**Answer:** LR_range = [9.02e-5, 1.11e-2], optimal = 6.18e-4

---

## Example 28: Phi-Drug Effect

**Problem:** Calculate phi-corrected SSRI effect size.

**Solution:**
`
Given: Effect = 0.4, target = serotonin

Step 1: Phi-effect
Effect_phi = Effect/phi = 0.4/1.618 = 0.247

Step 2: Clinical significance
Threshold = 0.3 (standard)
Effect_phi (0.247) < Threshold (0.3) = subclinical
`

**Answer:** Effect_phi = 0.247 (subclinical effect)

---

## Example 29: Phi-Oscillation Coherence

**Problem:** Calculate phi-corrected prefrontal-parietal coherence.

**Solution:**
`
Given: Coherence = 0.7

Step 1: Phi-coherence
Coherence_phi = Coherence/phi = 0.7/1.618 = 0.433

Step 2: Functional significance
High: > 0.6 (standard)
Phi-high: > 0.371 (phi-adjusted)
Coherence_phi (0.433) = moderate
`

**Answer:** Coherence_phi = 0.433 (moderate coherence)

---

## Example 30: Phi-Consciousness State

**Problem:** Calculate phi-corrected consciousness threshold for normal wakefulness.

**Solution:**
`
Given: Integrated_info = 1.0

Step 1: Phi-threshold
Threshold_phi = 1.0/phi = 0.618

Step 2: Compare to consciousness criterion
C_crit = 1/phi = 0.618
Integrated_info (1.0) > Threshold (0.618) = conscious
`

**Answer:** Threshold_phi = 0.618 (consciousness achieved)

