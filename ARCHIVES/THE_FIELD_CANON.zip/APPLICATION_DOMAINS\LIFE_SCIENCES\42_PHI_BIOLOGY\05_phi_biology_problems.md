﻿# PHI-BIOLOGY: Practice Problems

---

## Problem 1: Phi-Codon Weight
Calculate the phi-weight for the codon GCG (Ala).

## Problem 2: Phi-Protein Folding
A 200-residue protein has DeltaG_fold = -15 kcal/mol. Calculate the phi-corrected folding energy.

## Problem 3: Phi-Logistic Growth
Bacteria with r = 2.0/hr, K = 5x10^8, N0 = 10^5. Find population at t = 3 hours.

## Problem 4: Phi-Selection
Fitness difference Dw = 0.08. Calculate phi-selection coefficient and equilibrium frequency.

## Problem 5: Phi-Predator-Prey
alpha = 0.8, beta = 0.15, delta = 0.1, gamma = 2.0. Find phi-corrected equilibrium.

## Problem 6: Phi-Biodiversity
Community with p1 = 0.5, p2 = 0.3, p3 = 0.15, p4 = 0.05. Calculate phi-Shannon index.

## Problem 7: Phi-DNA Fidelity
Virus with epsilon_0 = 10^(-4) and proofreading level 1. Calculate phi-corrected mutation rate.

## Problem 8: Phi-Allometry
Predict brain mass of 100 kg mammal. Standard: M_brain = 0.01 x M_body^(3/4).

## Problem 9: Phi-Trophic Cascade
Four-level food chain with 2000 kcal/m^2. Calculate phi-corrected energy at each level.

## Problem 10: Phi-Gene Network
3-gene network with w_ij = 0.4 x phi^(-|i-j|). Find steady-state expression levels.

## Problem 11: Phi-Island Biogeography
Island of 50,000 km^2 with mainland S = 800. Calculate phi-species count.

## Problem 12: Phi-Mutation Spectrum
Mutation probability at positions 30 and 150 with lambda = 50 bp.

## Problem 13: Phi-Cell Division
If hepatocyte divides every 25 hr, predict neuron division time using phi-scaling.

## Problem 14: Phi-Epistasis
a1 = 0.5, a2 = 0.3, epsilon = 0.4. Calculate phi-corrected fitness for (1,1).

## Problem 15: Phi-Phylogenetics
Human-mouse distance d = 0.2. Calculate phi-corrected distance.

## Problem 16: Phi-Genome
Gene density at 20 Mb from centromere with rho_0 = 20 genes/Mb.

## Problem 17: Phi-Ecosystem
5-species food web with phi-competition alpha = 0.2/phi. Calculate stability margin.

## Problem 18: Phi-Drug Binding
Drug with Kd = 50 nM, receptor complexity = 8. Calculate phi-corrected Kd.

## Problem 19: Phi-Population Genetics
N_e = 500, mu = 5x10^(-6). Calculate phi-corrected genetic diversity.

## Problem 20: Phi-Aging
Gompertz lambda = 0.0003/day, complexity = 15. Calculate phi-aging rate.

---

*Part of the 32_PHI_PHYSICS / 06_EXPANDED_MATHEMATICS system.*
*Version 1.0 -- Agent I of 26*

## Problem 21: Phi-Enzyme Kinetics
Hexokinase Km = 0.1 mM. Calculate phi-corrected Km.

## Problem 22: Phi-Immune Response
Antibody affinity maturation with phi-correction. Starting Kd = 10^(-8) M.

## Problem 23: Phi-Plant Growth
Leaf area index = 3.0. Calculate phi-corrected LAI.

## Problem 24: Phi-Marine Ecology
Coral calcification rate = 10 mg/cm^2/day. Calculate phi-rate.

## Problem 25: Phi-Microbiology
Bacterial generation time = 20 min. Calculate phi-generation time.

## Problem 26: Phi-Virology
Viral burst size = 1000 virions. Calculate phi-burst size.

## Problem 27: Phi-Ecological Succession
Time to climax = 100 years. Calculate phi-succession time.

## Problem 28: Phi-Conservation
Minimum viable population = 500. Calculate phi-MVP.

## Problem 29: Phi-Biogeography
Tropical zone boundary = 23.5 degrees. Calculate phi-boundary.

## Problem 30: Phi-Evolutionary Rate
Primate substitution rate = 1.0 x 10^(-9). Calculate phi-rate.
