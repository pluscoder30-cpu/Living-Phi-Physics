# Foundation Mathematics: The Plastic Number

## Welcome, Young Mathematician!

You've learned about gold, silver, and bronze. Now it's time for the **Plastic Number**! It's approximately **1.3247179...** and it's the ratio that makes spirals in 3D!

The plastic number isn't about shapes on paper — it's about shapes in space. It's the ratio that helps things spiral upward, like a spring or a spiral staircase!

---

## Part 1: What is the Plastic Number?

### The 3D Spiral Number

The plastic number (let's call it "psi" or just "plastic") is about **1.325**. It's called plastic because it describes how things "mold" into 3D shapes!

### The Plastic Equation

The plastic number is the solution to this equation:

x³ = x + 1

Let's check:
- Plastic = 1.325...
- Plastic³ = 2.325...
- Plastic + 1 = 2.325...

They're equal! The plastic number is the only number that equals its own cube minus itself.

### Where Plastic Hides

The plastic number shows up in 3D patterns:

- **3D Spirals**: When something spirals upward (like a spring), the ratio between consecutive turns is often plastic!

- **Triangles**: The Padovan sequence (which uses plastic) creates triangles that spiral outward!

- **Architecture**: Some buildings use plastic proportions in their 3D designs.

- **Crystals**: Some crystal structures have plastic proportions.

### The Plastic Sequence

The plastic sequence is: 1, 1, 1, 2, 2, 3, 4, 5, 7, 9, 12...

Each term is the sum of the term two places back and the term three places back:
- 1 + 0 = 1 (starting)
- 1 + 1 = 2
- 1 + 2 = 3
- 2 + 2 = 4
- 2 + 3 = 5
- 3 + 4 = 7
- 4 + 5 = 9
- 5 + 7 = 12

Divide consecutive terms:
- 2 ÷ 1 = 2
- 3 ÷ 2 = 1.5
- 4 ÷ 3 = 1.333...
- 5 ÷ 4 = 1.25
- 7 ÷ 5 = 1.4
- 9 ÷ 7 = 1.286...
- 12 ÷ 9 = 1.333...

Getting closer to 1.325!

---

## Part 2: The 3D Spiral

### How to Draw a 3D Spiral

A 3D spiral goes up like a spring. Here's how to draw one:

**Step 1**: Draw a flat circle (an ellipse, since we're looking at it from the side).

**Step 2**: Above the circle, draw another circle, slightly smaller.

**Step 3**: Connect the edges of the circles with diagonal lines.

**Step 4**: Keep adding circles above, each one slightly smaller.

**Step 5**: Connect all the circles with a smooth curve going upward.

You've made a 3D spiral! The ratio between the sizes of the circles should be close to plastic (1.325).

### The Plastic Property

Here's what makes plastic special for 3D:

If you take a 3D spiral and measure the ratio between consecutive turns, you get the plastic number. This means:

- Turn 1 has diameter D
- Turn 2 has diameter D × 1.325
- Turn 3 has diameter D × 1.325²
- And so on...

The spiral grows at a constant rate in 3D!

---

## Part 3: What Happens When You Add Plastic?

### Plastic Addition Properties

The plastic number has these special properties:

- Plastic³ = Plastic + 1
- Plastic² = Plastic × Plastic = 1.757... (not a simple relation)
- Plastic³ = Plastic² + Plastic = 2.325...

The plastic number connects cubes, squares, and addition!

### More Plastic Math

- Plastic - 1 = 0.325...
- Plastic² - Plastic = 0.433...
- Plastic³ - Plastic² = 1

The plastic number creates interesting relationships between powers!

### The Plastic Identity

The most important identity is:

Plastic³ = Plastic + 1

This means the cube of plastic equals plastic plus 1. It's like the golden identity, but for 3D!

---

## Part 4: Plastic in Everyday Life

### Architecture and Design

- **Spiral staircases**: Some follow plastic proportions
- **Helical structures**: DNA-like shapes use plastic ratios
- **3D art**: Sculptors use plastic for balanced proportions

### Nature

- **Shells**: Some shells spiral in 3D using plastic ratios
- **Plants**: Some plants grow in 3D spirals (like pine cones)
- **Animal horns**: Horns that spiral outward use plastic proportions

### Mathematics

- **Number theory**: The plastic number is a special algebraic number
- **Geometry**: It creates interesting 3D tilings
- **Dynamical systems**: It describes how some systems evolve in 3D

---

## Part 5: 10 Fun Exercises

### Exercise 1: Draw a 3D Spiral
Using a pencil, draw a spiral that goes upward. Start at the bottom and spiral up like a spring. Try to make each turn 1.325 times bigger than the one below!

### Exercise 2: The Plastic Rectangle
Draw a rectangle with the ratio 1:1.325. If the height is 6 cm, the width should be about 7.95 cm. How does it compare to golden and silver rectangles?

### Exercise 3: Build a Plastic Tower
Use blocks to build a spiral tower:
- Start with a 3 cm block
- Place the next block at an angle
- Make each block 1.325 times taller
- Keep going until you have 5 blocks

### Exercise 4: The Padovan Pattern
Draw the Padovan sequence as triangles:
- Start with a small triangle
- Add triangles to make a spiral
- Each new triangle follows the Padovan pattern

### Exercise 5: Plastic vs. Other Ratios
Draw four rectangles:
- Golden: 1 × 1.618
- Silver: 1 × 2.414
- Bronze: 1 × 3.303
- Plastic: 1 × 1.325

Which one do you like best? Which one seems most "balanced"?

### Exercise 6: The 3D Shape
Build a 3D model using toothpicks and marshmallows:
- Create a spiral that goes upward
- Each level should be 1.325 times bigger
- How many levels can you build?

### Exercise 7: Plastic in Music
If you have access to a piano, play notes that are a plastic interval apart. How does it sound compared to golden, silver, and bronze intervals?

### Exercise 8: The Plastic Spiral
Draw a spiral on paper. Now draw another spiral that goes upward (3D). Compare them. How are they different?

### Exercise 9: Real-World Plastic Hunt
Find 3D spirals in your world:
- A spiral staircase
- A spring
- A screw
- A drill bit
- A spiral galaxy (in a picture)

Measure the ratio between consecutive turns if you can!

### Exercise 10: Plastic Journal
In your math journal:
- Draw a 3D spiral
- Write down the plastic identity: Plastic³ = Plastic + 1
- List three things that use plastic proportions
- Write a poem about 3D math

---

## Part 6: Amazing Plastic Facts

### Fact 1: Plastic is the "Median" Metallic Ratio
While gold, silver, and bronze are "extreme" ratios (getting bigger), plastic is in the middle — it's the most balanced ratio for 3D shapes!

### Fact 2: Plastic and the Padovan Sequence
The Padovan sequence (1, 1, 1, 2, 2, 3, 4, 5, 7, 9, 12...) is closely related to plastic. The ratio of consecutive terms approaches plastic!

### Fact 3: Plastic in Crystals
Some crystal structures have plastic proportions in their 3D arrangement. The atoms organize themselves using plastic math!

### Fact 4: Plastic and Springs
When you stretch a spring, the coils spread out in a pattern related to plastic. The spring "remembers" its plastic proportions!

### Fact 5: Plastic is Algebraic
The plastic number is an algebraic number — it's the solution to a polynomial equation (x³ = x + 1). This makes it special among mathematical constants!

---

## Part 7: Plastic Poems

### The Plastic Poem
Plastic is the number that makes things spiral high,
In three dimensions, reaching for the sky,
Not flat on paper, but rising up,
Plastic is the number of the 3D cup!

### The Spiral Rhyme
One point three two five,
That's plastic, alive,
In springs, in stairs,
In 3D affairs!

---

## Part 8: What You've Learned

Today you discovered:

1. **The plastic number** is about 1.325 — it's the ratio for 3D spirals.

2. **The plastic identity**: Plastic³ = Plastic + 1

3. **The Padovan sequence** uses plastic proportions to create triangle spirals.

4. **Plastic appears** in 3D structures like springs, spiral staircases, and crystal lattices.

5. **Plastic connects** cubes, squares, and addition in a special way.

---

## Part 9: Challenge Problems

### Challenge 1: Solve for Plastic
Can you solve x³ = x + 1 to find the exact value of plastic? (Hint: use the cubic formula or numerical methods)

### Challenge 2: The 3D Spiral Formula
If a 3D spiral has radius r at height h, and the ratio between turns is plastic, write a formula for the radius at any height.

### Challenge 3: Padovan Triangles
Draw the first 15 terms of the Padovan sequence as triangles. How big is the pattern?

### Challenge 4: Plastic and Phi
How does the plastic number (1.325) compare to phi (1.618)? Which is bigger? By how much?

### Challenge 5: Build a Plastic Sculpture
Create a 3D sculpture using plastic proportions. You can use clay, paper, or any materials. Make sure each level is 1.325 times bigger!

---

## Part 10: Glossary

**Algebraic Number**: A number that is the solution to a polynomial equation

**3D**: Three-dimensional — having height, width, and depth

**Padovan Sequence**: A sequence where each term is the sum of the terms two and three places back: 1, 1, 1, 2, 2, 3, 4, 5, 7, 9, 12...

**Plastic Number**: Approximately 1.325, the solution to x³ = x + 1

**Polynomial**: An expression with variables and coefficients, like x³ - x - 1 = 0

**Spiral**: A curve that winds around a center point

**Spring**: A coiled shape that can stretch and compress

---

## Remember!

**Plastic makes spirals in 3D!**

The next time you see a spring, a spiral staircase, or a shell spiraling upward, remember: plastic math is at work! While gold, silver, and bronze are flat (2D), plastic is the ratio that reaches into the third dimension!

---

*Life isn't flat — it's 3D! And the math that describes 3D spirals is the plastic number. Welcome to the third dimension!*
