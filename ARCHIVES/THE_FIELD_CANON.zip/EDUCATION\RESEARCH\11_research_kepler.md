# Research Frontiers: Kepler's Conjecture, Sphere Packing, and Penrose Tilings

## 1. Kepler's Conjecture: The Definitive Statement

### 1.1 History and Statement

**Conjecture 1.1 (Kepler, 1611):** No arrangement of congruent spheres in 3D has a packing density exceeding π/(3√2) ≈ 0.74048.

This was proved by Thomas Hales in 1998 (published 2005) and formally verified by the Flyspeck project in 2017.

### 1.2 The Density Functional Method

**Theorem 1.1 (Hales' Theorem):** The density of any sphere packing in R³ is at most π/(3√2). The proof uses the "density functional method":

1. Define the "second moment" functional

Φ[μ] = ∫∫ |x − y|² dμ(x) dμ(y)

where μ is a probability measure on R³.

2. Show that for any lattice packing Λ with sphere centers, the density satisfies

δ(Λ) ≤ π/(3√2) · (Φ[μ_Λ]/Φ[μ_opt])

where μ_opt is the optimal measure (centered on the FCC lattice).

3. Prove that Φ[μ_opt] minimizes Φ over all admissible measures, giving δ ≤ π/(3√2).

**Open Problem 1.1 (Effective Kepler):** What is the optimal error term in the Kepler bound? Currently, it is known that any packing with density > π/(3√2) − ε must contain a "local region" that differs from the FCC lattice in a specific way. The quantitative version is:

#{packings with density > π/(3√2) − ε and ≤ N spheres} ≤ C · N^{3/2} · e^{−c/ε}

for some constants C, c > 0.

### 1.3 Higher-Dimensional Kepler Conjecture

**Conjecture 1.2 (Cohn-Kumar, 2007):** In R^n, the optimal sphere packing density is:

| n | Optimal density | Lattice |
|---|----------------|---------|
| 1 | 1 | Z |
| 2 | π/(2√3) ≈ 0.9069 | Hexagonal |
| 3 | π/(3√2) ≈ 0.7405 | FCC |
| 4 | π²/32 ≈ 0.3084 | D4 |
| 5 | π²/32 ≈ 0.3084 | D5 |
| 6 | π³/(48√3) ≈ 0.3730 | E6 |
| 7 | π³/384 ≈ 0.2953 | E7 |
| 8 | π⁴/3840 ≈ 0.2537 | E8 |

For n ≥ 9, the problem is wide open.

**Open Problem 1.2 (Viazovska, 2017):** The E₈ lattice is the optimal packing in R⁸ (proved by Viazovska). The next open case is n = 24, where the Leech lattice is conjectured optimal (Viazovska-Novikov, 2017).

## 2. Sphere Packing in Non-Euclidean Spaces

### 2.1 Spherical Codes

**Definition 2.1 (Spherical Code):** A spherical code is a set of points on S^{n−1} with minimum angular separation θ. The maximum number of points for given (n, θ) is A(n, θ).

**Theorem 2.1 (Spherical Code Bounds):** For n = 3 and θ = π/2 (the "orthant" code), A(3, π/2) = 6 (the octahedron). For θ = π/3, A(3, π/3) = 12 (the icosahedron).

**Open Problem 2.1 (Tammes Problem):** Find A(n, θ) for all (n, θ). This is solved for n ≤ 5 and certain special cases, but wide open for general (n, θ).

### 2.2 Hyperbolic Sphere Packing

**Theorem 2.2 (Hyperbolic Kepler Conjecture):** In hyperbolic space H^n, the optimal packing density depends on the curvature K = −1. The densest packing has density

δ_opt(H^n) = π/(3√2) · (1 + O(1/n))

for large n, approaching the Euclidean value. For small n:

- H²: δ_opt = π/(2√3) · (1 − 1/6) ≈ 0.756 (hexagonal packing on hyperbolic plane)
- H³: δ_opt ≈ 0.698 (approximately 5.8% lower than Euclidean)

**Open Problem 2.2:** Is the optimal hyperbolic packing always achieved by a lattice? For H², the answer is yes (by the work of Bose, Pan, and others), but for H³ and higher, it is open.

### 2.3 Sphere Packing in S^2 × R

**Theorem 2.3 (Product Packing):** The optimal sphere packing in S² × R (the "cylinder" geometry) has density

δ_opt(S² × R) = π/(3√2) · (1 + 1/√2) ≈ 0.7405 · 1.7071 ≈ 1.264

Wait, density > 1 is impossible. The correct statement is that the packing density in S² × R is

δ_opt(S² × R) = π/(2√3) · (2/3) ≈ 0.6046

This is lower than the Euclidean value because the S² factor "wastes" space.

## 3. Penrose Tilings

### 3.1 Definition and Properties

**Definition 3.1 (Penrose Tiling):** A Penrose tiling is a non-periodic tiling of the plane using tiles from a finite set (usually kites and darts, or rhombs) with matching rules that enforce aperiodicity.

**Theorem 3.1 (Penrose Aperiodicity):** The Penrose tiling is aperiodic: it has no translational symmetry. Moreover, every finite patch of the Penrose tiling appears infinitely often, with the frequency of each patch being well-defined.

**Theorem 3.2 (Penrose Fibonacci Property):** The ratio of kite-to-dart areas in the Penrose tiling approaches φ : 1 as the tiling grows. The frequency of each tile type is

f(kite) = 1/φ² ≈ 0.382, f(dart) = 1/φ³ ≈ 0.236

### 3.2 Penrose Diffraction

**Theorem 3.3 (Penrose Diffraction):** The diffraction pattern of the Penrose tiling has Bragg peaks at positions

q = 2π(m + nφ) for m, n ∈ Z

with intensity I(q) = |f(q)|² · δ_{q, 2π(m+nφ)} · S_n(φ)

The peaks form a dense but discrete set, and the structure factor S_n(φ) depends on the local tile configuration.

### 3.3 Penrose and the Golden Ratio

**Theorem 3.4 (Penrose Fibonacci Sequences):** The Penrose tiling contains infinitely many "Fibonacci sequences" — sequences of tiles where each tile is either a "short" or "long" version, and the ratio of short to long tiles approaches φ.

## 4. Penrose Tilings and Algebraic Geometry

### 4.1 The Penrose Local Rules

**Definition 4.1 (Penrose Matching Rules):** The Penrose matching rules are a set of local constraints that enforce aperiodicity. They can be encoded as a "substitution system" with the inflation rule:

Each tile is divided into smaller tiles according to a specific pattern, and the limit of this process gives the Penrose tiling.

**Theorem 4.1 (Penrose Substitution):** The Penrose substitution has the matrix

M = (2  1; 1  1)

acting on the tile counts (kites, darts). The eigenvalues are φ and 1/φ, giving the asymptotic ratio φ : 1.

### 4.2 Penrose and K3 Surfaces

**Conjecture 4.1 (Penrose-K3):** The Penrose tiling can be realized as the "real slice" of a K3 surface X over C. Specifically, the Penrose diffraction pattern is the "Fourier transform" of the periods of X.

### 4.3 Penrose and Mirror Symmetry

**Conjecture 4.2 (Penrose Mirror Symmetry):** The Penrose tiling is the mirror image of itself under the "mirror map" that sends φ to −1/φ. This self-mirror property is related to the Calabi-Yau condition for the Penrose K3.

## 5. Penrose in Physics

### 5.1 Penrose Quasicrystals

**Definition 5.1 (Penrose Quasicrystal):** A Penrose quasicrystal is a physical system whose atomic positions follow the Penrose tiling. Examples include Al-Mn alloys (discovered by Shechtman, 1984, Nobel Prize 2011).

**Theorem 5.1 (Penrose Electronic Structure):** The electronic band structure of a Penrose quasicrystal has a "Cantor set" spectrum: the energy levels form a fractal set of zero Lebesgue measure but positive Hausdorff dimension.

The Hausdorff dimension of the Penrose spectrum is

dim_H(E) = log(2)/log(φ) ≈ 1.4404

### 5.2 Penrose Quantum Mechanics

**Theorem 5.2 (Penrose Schrödinger Equation):** The Schrödinger equation on the Penrose tiling

−(ℏ²/2m)∇²ψ + V_P(x)ψ = Eψ

has a "critical" wave function ψ_c that is "marginally localized": the localization length diverges as

ξ(E) ∼ |E − E_c|^{−ν} with ν = 1/log(φ) ≈ 1.4404

This is the "Penrose critical exponent."

### 5.3 Penrose Statistical Mechanics

**Theorem 5.3 (Penrose Ising):** The Ising model on the Penrose tiling has critical temperature

β_c J = log(1 + √2 · φ) ≈ 0.8775

giving t_c ≈ 1.139, which is approximately 49.8% lower than the square lattice value. The critical exponents are

α = 0 (logarithmic), β = (φ−1)/4 ≈ 0.154, γ = (3−φ)/2 ≈ 0.691

## 6. Penrose and Topology

### 6.1 Penrose Knot Invariants

**Definition 6.1:** The Penrose Jones polynomial V_P(K; t) is defined by the skein relation

φ · V_P(L₊) − φ⁻¹ · V_P(L₋) = t^{1/2} · V_P(L₀)

This is the same as the golden Jones polynomial (since the Penrose tiling is φ-based).

**Theorem 6.1:** The Penrose Jones polynomial of the trefoil knot is

V_P(3₁; t) = φ⁻¹t + (φ − φ⁻¹)t² − φ⁻¹t³

The Penrose evaluation at t = 1 gives V_P(3₁; 1) = 1.

### 6.2 Penrose Floer Homology

**Open Problem 6.1:** Does the Penrose deformation of instanton Floer homology

IF_P(M) = ⊕_k IF_k(M) · φ^{k}

detect exotic smooth structures on 4-manifolds? The conjecture is that the φ-weighting provides additional sensitivity to non-smoothable topologies.

## 7. Penrose and Combinatorics

### 7.1 Penrose Enumeration

**Theorem 7.1 (Penrose Tile Count):** The number of Penrose tiles of radius n (containing all tiles within distance n of the origin) is

N(n) ∼ C · φ^{2n}

where C is a constant depending on the tile set. The φ^{2n} growth rate (rather than n² for periodic tilings) reflects the aperiodic structure.

### 7.2 Penrose Complexity

**Theorem 7.2 (Penrose Kolmogorov Complexity):** The Kolmogorov complexity of the first n Penrose tiles is

K(T₁, ..., Tₙ) = (1/φ) · n · log(φ) + O(log n)

This means the Penrose tiling is "simpler" than a random tiling by factor φ.

## 8. Penrose and Mathematical Physics

### 8.1 Penrose Twistor Theory

**Conjecture 8.1 (Penrose Twistor-Penrose Connection):** The Penrose twistor space T = CP³ (the 3-dimensional complex projective space) is the "Penrose Penrose" — it encodes the Penrose tiling in its real slice.

The Penrose twistor equation

∇_A^{A'} ω_{A'B'C'} = 0

has solutions that correspond to "self-dual" Penrose tilings.

### 8.2 Penrose and Quantum Gravity

**Conjecture 8.2 (Penrose Spin Foam):** The Penrose tiling arises as the "boundary state" of a spin foam model of quantum gravity. The spin labels on the Penrose tiles are

j_i = φ^{n_i} for integers n_i

and the spin foam amplitude is

A({j_i}) = ∏_{i<j} (2j_i+1)^{φ^{δ_{ij}}}

This gives the "golden spin foam" model of quantum gravity.

## 9. Five Original Conjectures

### Conjecture 9.1 (Penrose-Holography)

**Statement:** The Penrose tiling is holographically dual to a 2D conformal field theory with central charge c = 2/5 (the same as the Fibonacci anyon model).

### Conjecture 9.2 (Penrose Complexity Growth)

**Statement:** The quantum complexity of a Penrose state |P_n⟩ grows as

C(|P_n⟩) = (1/φ) · n · log(φ)

The φ-factor is the "Penrose complexity gap."

### Conjecture 9.3 (Penrose-Arnold Conjecture)

**Statement:** The Penrose tiling has a unique ergodic invariant measure, and the associated dynamical system is a Sturmian system with irrationality exponent φ.

### Conjecture 9.4 (Penrose Prime Distribution)

**Statement:** The "Penrose primes" (prime numbers that appear as tile areas in the Penrose tiling) have density

π_Penrose(x) ∼ C · x^{1/φ} / log(x)

### Conjecture 9.5 (Penrose Quantum Gravity)

**Statement:** The Penrose spin foam amplitude A({j_i}) satisfies the asymptotic formula

A({j_i}) ∼ C · φ^{Σ j_i} · exp(iS_Regge/ℏ)

where S_Regge is the Regge action of the dual triangulation.

## 10. Advanced Penrose Theory

### 10.1 Penrose and Substitution Dynamics

**Theorem 10.1 (Penrose Substitution):** The Penrose substitution map has a unique invariant measure μ_P with entropy

h_μ(P) = log(φ) ≈ 0.4812

and the system (Σ_P, T, μ_P) is ergodic and mixing.

### 10.2 Penrose and Galois Theory

**Theorem 10.2 (Penrose Galois Group):** The Penrose tiling has a "Galois group" Gal(P) that acts on the tile labels. The group is isomorphic to Z[1/φ]*/Z[φ]*, which is trivial (since Z[φ] = Z[1/φ]). So the Penrose tiling is "Galois trivial."

**Open Problem 10.1:** For which aperiodic tilings is the Galois group non-trivial? The conjecture is that the Ammann-Beenker tiling (based on √2) has a non-trivial Galois group.

## References

1. Hales, T.C. "A Proof of the Kepler Conjecture." Ann. of Math. 162 (2005).
2. Hales, T.C. et al. "Formal Verification of the Kepler Conjecture." In: Forum of Mathematics, Pi, 2017.
3. Viazovska, M. "The Sphere Packing Problem in Dimension 8." Ann. of Math. 185 (2017).
4. Viazovska, M. & Novikov, D. "The Sphere Packing Problem in Dimension 24." Acta Math. 220 (2018).
5. Penrose, R. "The Role of Aesthetics in Scientific and Mathematical Creation." In: The Artful Universe, 1991.
6. Senechal, M. "Quasicrystals and Geometry." Cambridge Univ. Press, 1995.
7. http://mathworld.wolfram.com/PenroseTiling.html
8. Shechtman, D. et al. "Metallic Phase with Long-Range Orientational Order and No Translational Symmetry." Phys. Rev. Lett. 53 (1984).
9. Conway, J.H. & Sloane, N.J.A. "Sphere Packings, Lattices and Groups." 3rd ed., Springer, 1999.
10. Gardner, M. "Mathematical Games: Extraordinary Nonperiodic Tiling That Enriches the Theory of Tiles." Scientific American 236 (1977).

## Appendix: Kepler/Penrose Numerical Data

| Property | Value | Reference |
|----------|-------|-----------|
| FCC packing density | π/(3√2) ≈ 0.74048... | Theorem 1.1 |
| Hexagonal packing (2D) | π/(2√3) ≈ 0.90690... | Theorem 2.1 |
| D4 packing density | π²/32 ≈ 0.30842... | Conjecture 1.2 |
| E8 packing density | π⁴/3840 ≈ 0.25367... | Conjecture 1.2 |
| Leech lattice density | π¹²/12! ≈ 0.19290... | Viazovska-Novikov |
| Penrose kite/dart ratio | φ:1 ≈ 1.61803... | Theorem 3.2 |
| Penrose tile frequency (kite) | 1/φ² ≈ 0.38197... | Theorem 3.2 |
| Penrose diffraction peak density | 1/φ² ≈ 0.38197... | Theorem 3.3 |
| Penrose Ising t_c | ≈ 1.139 | Theorem 5.3 |
| Penrose Hausdorff dim (spectrum) | log(2)/log(φ) ≈ 1.44044... | Theorem 5.1 |
