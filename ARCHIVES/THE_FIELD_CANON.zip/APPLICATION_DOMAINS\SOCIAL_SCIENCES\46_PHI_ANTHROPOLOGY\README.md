# 46_PHI_ANTHROPOLOGY — Phi-Harmonic Anthropological Theory

## Directory Contents

This directory contains the complete phi-harmonic anthropology framework: mathematical models where the golden ratio φ = 1.6180339887 governs civilizational growth, historical cycles, migration diffusion, cultural evolution, mythological archetypes, language drift, and archaeological pattern recognition.

### Files

| # | File | Lines | Content |
|---|------|-------|---------|
| 01 | `01_phi_anthropology_theory.md` | 250+ | Core axioms, civilizational phi-cycles, migration wave equations, cultural genome theory |
| 02 | `02_phi_anthropology_tables.md` | 220+ | Civilizational constants, epoch durations, migration diffusion rates, archetype frequencies |
| 03 | `03_phi_anthropology_examples.md` | 250+ | Worked examples: empire rise-fall, Neolithic diffusion, language family branching |
| 04 | `04_phi_anthropology_applications.md` | 250+ | Applications: archaeological prediction, cultural preservation, historical modeling |
| 05 | `05_phi_anthropology_problems.md` | 250+ | Exercises: cycle analysis, migration modeling, cultural genome mapping |
| 06 | `06_phi_anthropology_answers.md` | 280+ | Complete solutions with full derivations |
| 07 | `README.md` | 50+ | This file |

**Total: ~1,550 lines**

### Core Insight

Civilizations exhibit phi-harmonic temporal structure:
- **Cycles**: Empire rise-fall periods cluster around φ^k × τ₀ where τ₀ ≈ 500 years
- **Migration**: Diffusion front velocity = φ × D/r² where D is cultural diffusivity
- **Language**: Vocabulary drift rate = Δv/v₀ × φ^(−t/τ_lang)
- **Mythology**: Archetype recurrence intervals follow φ-multiples of the "mythic year" (~400 years)
- **Archaeology**: Settlement layer depths follow phi-spiral excavation curves

### Phi-Anthropological Constants

| Symbol | Value | Meaning |
|--------|-------|---------|
| τ₀ | ~500 years | Base civilizational period |
| τ_lang | ~300 years | Language drift time constant |
| τ_myth | ~400 years | Archetype recurrence period |
| D_c | φ × 10 km²/yr | Cultural diffusivity |
| R_arch | φ^(−1) × 100 km | Archaeological detection radius |

### Civilizational Cycle Equation

```
C(t) = C₀ × exp(−t/τ₀) × [1 + Σ_k A_k × cos(2πt/(φ^k × τ₀))]
```

Where:
- C(t) = civilizational complexity at time t
- A_k = amplitude of k-th phi-harmonic mode
- φ^k × τ₀ = period of k-th harmonic
- The sum converges because amplitudes decay as 1/k

### Relationship to Other Domains

```
46_PHI_ANTHROPOLOGY
    ├── 45_PHI_SOCIOLOGY (social structures → civilizational patterns)
    ├── 44_PHI_PSYCHOLOGY (archetype → collective unconscious)
    └── 47_PHI_ENVIRONMENTAL_SCIENCE (environment-civilization coupling)
```
