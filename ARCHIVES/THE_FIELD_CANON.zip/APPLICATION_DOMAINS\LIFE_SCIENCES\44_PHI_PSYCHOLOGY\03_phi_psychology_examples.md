﻿# PHI-PSYCHOLOGY: Worked Examples

---

## Example 1: Phi-Visual Perception

**Problem:** Calculate the phi-perception sensitivity for a stimulus at the golden angle (137.5 degrees).

**Solution:**
`
Given: theta = 137.5 degrees, theta_golden = 137.5 degrees, P0 = 1.0, d_theta = 10 degrees

Step 1: Calculate perception
P_phi = P0 x phi^(-|theta - theta_golden|/d_theta)
P_phi = 1.0 x phi^(0) = 1.0
`

**Answer:** P_phi = 1.0 (maximum perception at golden angle)

---

## Example 2: Phi-Aesthetic Preference

**Problem:** Calculate aesthetic preference for a logo with proportions 1:1.618.

**Solution:**
`
Given: r_logo = 1.618, r_golden = 1.618, w = 0.8

Step 1: Calculate preference
A_phi = w x phi^(-|r_logo - r_golden|/0.1) = 0.8 x phi^(0) = 0.8
`

**Answer:** A_phi = 0.8 (maximum aesthetic preference)

---

## Example 3: Phi-Emotional Intensity

**Problem:** Calculate emotional intensity for joy (v=0.9, a=0.6).

**Solution:**
`
Given: v = 0.9, a = 0.6, I0 = 1.0

Step 1: Calculate intensity
I_phi = I0 x phi^(a/v) = 1.0 x phi^(0.6/0.9) = phi^(0.667)
I_phi = 1.618^0.667 = 1.390
`

**Answer:** I_phi = 1.390 (39% above baseline)

---

## Example 4: Phi-Therapy Dosing

**Problem:** Calculate therapy dose at session 8 with initial dose D0 = 1.0.

**Solution:**
`
Given: D0 = 1.0, n = 8, tau_therapy = 20

Step 1: Standard dose: D = 1.0 (constant)
Step 2: Phi-dose
D_phi(n) = D0 x phi^(-n/tau) = 1.0 x phi^(-8/20) = phi^(-0.4)
D_phi = 0.743
`

**Answer:** D_phi = 0.743 (26% reduction at session 8)

---

## Example 5: Phi-Attention Span

**Problem:** Calculate attention span under cognitive load of 0.7.

**Solution:**
`
Given: T0 = 1000 ms, cognitive_load = 0.7, max_load = 1.0

Step 1: Standard attention: T = 1000 ms
Step 2: Phi-attention
T_phi = T0 x phi^(-cognitive_load/phi) = 1000 x phi^(-0.7/1.618)
T_phi = 1000 x phi^(-0.433) = 1000 x 0.738 = 738 ms
`

**Answer:** T_phi = 738 ms (26% shorter under load)

---

## Example 6: Phi-Choice Architecture

**Problem:** Calculate phi-nudged utility for an option at distance 2 from default.

**Solution:**
`
Given: U_option = 0.8, distance = 2, phi = 1.618

Step 1: Standard utility: 0.8
Step 2: Phi-nudged
U_phi = U_option x phi^(-distance/phi) = 0.8 x phi^(-2/1.618)
U_phi = 0.8 x phi^(-1.236) = 0.8 x 0.546 = 0.437
`

**Answer:** U_phi = 0.437 (45% reduction due to distance from default)

---

## Example 7: Phi-Social Influence

**Problem:** Calculate influence decay from friend vs stranger.

**Solution:**
`
Given: I_friend = 0.6, I_stranger = 0.05, distance_friend = 4, distance_stranger = 10

Step 1: Friend influence
I_phi_friend = 0.6 x phi^(-4) = 0.6 x 0.146 = 0.088

Step 2: Stranger influence
I_phi_stranger = 0.05 x phi^(-10) = 0.05 x 0.0081 = 0.00041

Step 3: Ratio
I_phi_friend / I_phi_stranger = 0.088 / 0.00041 = 215
`

**Answer:** Friend influence is 215x stranger influence

---

## Example 8: Phi-Memory Retrieval

**Problem:** Calculate memory retrieval probability after 48 hours with 3 rehearsals.

**Solution:**
`
Given: R0 = 1.0, t = 48 hr, tau_decay = 24 hr, rehearsals = 3

Step 1: Standard decay
R(48) = e^(-48/24) = e^(-2) = 0.135

Step 2: Phi-retrieval
R_phi = R0 x phi^(-t/tau) x phi^(rehearsals/10)
R_phi = phi^(-2) x phi^(0.3) = phi^(-1.7)
R_phi = 0.356
`

**Answer:** R_phi = 0.356 (163% better retention with phi-rehearsal)

---

## Example 9: Phi-Working Memory

**Problem:** Calculate working memory capacity for complex task (4 attributes).

**Solution:**
`
Given: C_WM = 7, task_complexity = 4, phi = 1.618

Step 1: Standard: C_WM = 5 chunks
Step 2: Phi-corrected
C_WM_phi = 7 x phi^(-4/phi) = 7 x phi^(-2.472)
C_WM_phi = 7 x 0.233 = 1.63
`

**Answer:** C_WM_phi = 1.6 chunks (severe reduction for complex tasks)

---

## Example 10: Phi-Developmental Milestone

**Problem:** Calculate phi-age for pre-operational stage (standard age 2-7 years).

**Solution:**
`
Given: age = 5 years (mid-stage)

Step 1: Standard: stage = pre-operational
Step 2: Phi-age
age_phi = age x phi^(stage/10) = 5 x phi^(2/10) = 5 x phi^0.2
age_phi = 5 x 1.101 = 5.51 years
`

**Answer:** Phi-age = 5.51 years (10% advancement)

---

## Example 11: Phi-Emotional Regulation

**Problem:** Calculate effectiveness of cognitive reappraisal vs suppression.

**Solution:**
`
Given: E_reappraisal = 0.50, E_suppression = -0.20

Step 1: Phi-enhanced reappraisal
E_phi_reappraisal = E_reappraisal x phi = 0.50 x 1.618 = 0.809

Step 2: Phi-attenuated suppression
E_phi_suppression = E_suppression x phi^(-1) = -0.20 x 0.618 = -0.124
`

**Answer:** Reappraisal: 0.809 vs Suppression: -0.124

---

## Example 12: Phi-Music Therapy

**Problem:** Calculate therapeutic effect of 432 Hz vs 528 Hz music.

**Solution:**
`
Given: E_432 = 0.25, E_528 = 0.40

Step 1: Phi-corrected 432 Hz
E_phi_432 = E_432 x phi^(-1) = 0.25 x 0.618 = 0.155

Step 2: Phi-corrected 528 Hz
E_phi_528 = E_528 x phi^(-1) = 0.40 x 0.618 = 0.247
`

**Answer:** 432 Hz: 0.155 vs 528 Hz: 0.247

---

## Example 13: Phi-Color Perception

**Problem:** Calculate phi-color contrast sensitivity.

**Solution:**
`
Given: dE_standard = 3.0, phi = 1.618

Step 1: Phi-corrected threshold
dE_phi = dE_standard x phi^(-1) = 3.0 x 0.618 = 1.854
`

**Answer:** dE_phi = 1.85 (38% finer color discrimination)

---

## Example 14: Phi-Risk Perception

**Problem:** Calculate risk perception for a high-risk activity.

**Solution:**
`
Given: R0 = 1.0, perceived_risk = 8, actual_risk = 5

Step 1: Standard risk perception: R = 1.0
Step 2: Phi-risk
R_phi = R0 x phi^(perceived/actual) = phi^(8/5) = phi^1.6
R_phi = 2.472
`

**Answer:** R_phi = 2.47 (overestimation by 147%)

---

## Example 15: Phi-Time Preference

**Problem:** Calculate discounting for reward at 10 months.

**Solution:**
`
Given: V0 = 1.0, t = 10 months, tau_discount = 12 months

Step 1: Standard discounting
delta = e^(-t/tau) = e^(-10/12) = 0.435

Step 2: Phi-discounting
delta_phi = phi^(-t/tau) = phi^(-10/12) = phi^(-0.833)
delta_phi = 0.596
`

**Answer:** delta_phi = 0.596 (37% more patient with phi-discounting)

---

## Example 16: Phi-Conformity

**Problem:** Calculate conformity pressure when group opinion is 0.8 and own is 0.5.

**Solution:**
`
Given: C0 = 1.0, group_opinion = 0.8, own_opinion = 0.5, sigma_group = 0.3

Step 1: Standard conformity: C = 1.0
Step 2: Phi-conformity
C_phi = C0 x phi^(-|0.5 - 0.8|/0.3) = phi^(-1.0) = 0.618
`

**Answer:** C_phi = 0.618 (38% reduction in conformity pressure)

---

## Example 17: Phi-Moral Reasoning

**Problem:** Calculate moral weight for harm vs fairness principles.

**Solution:**
`
Given: w_harm = 0.7, w_fairness = 0.5, context_match = 0.6, sigma = 0.3

Step 1: Phi-weighted harm
W_phi_harm = 0.7 x phi^(-|1 - 0.6|/0.3) = 0.7 x phi^(-1.333) = 0.7 x 0.486 = 0.340

Step 2: Phi-weighted fairness
W_phi_fairness = 0.5 x phi^(-|1 - 0.6|/0.3) = 0.5 x phi^(-1.333) = 0.5 x 0.486 = 0.243
`

**Answer:** Harm: 0.340 vs Fairness: 0.243

---

## Example 18: Phi-Language Processing

**Problem:** Calculate phi-semantic processing for word-context match.

**Solution:**
`
Given: w_word = 0.8, context_match = 0.7, sigma = 0.4

Step 1: Standard processing: C = 0.8
Step 2: Phi-semantic
C_phi = 0.8 x phi^(-|0.7 - 1.0|/0.4) = 0.8 x phi^(-0.75) = 0.8 x 0.697
C_phi = 0.558
`

**Answer:** C_phi = 0.558

---

## Example 19: Phi-Psychedelic Therapy

**Problem:** Calculate psychedelic therapy intensity at t = 4 hours.

**Solution:**
`
Given: I0 = 1.0, t = 4 hr, tau_peak = 2 hr, lambda_phi = 3 hr, intention = 0.8

Step 1: Phi-therapy intensity
I_phi(4) = I0 x phi^(-t/tau_peak) x sin(2pi x t/lambda_phi) x phi^(intention/phi)
I_phi(4) = phi^(-2) x sin(2pi x 4/3) x phi^(0.494)
I_phi(4) = 0.382 x sin(8.378) x 1.333
I_phi(4) = 0.382 x (-0.988) x 1.333 = -0.504
`

**Answer:** I_phi(4hr) = -0.504 (descending phase)

---

## Example 20: Phi-Collective Unconscious

**Problem:** Calculate archetype strength for hero archetype.

**Solution:**
`
Given: A_hero = 0.8, optimal_hero = 0.6, 5 archetypes

Step 1: Phi-archetype strength
C_hero = 0.8 x phi^(-|0.8 - 0.6|) = 0.8 x phi^(-0.2) = 0.8 x 0.871
C_hero = 0.697

Step 2: Total unconscious
C_total = Sigma C_i = sum of all phi-weighted archetypes
`

**Answer:** C_hero = 0.697

---

*Part of the 32_PHI_PHYSICS / 06_EXPANDED_MATHEMATICS system.*
*Version 1.0 -- Agent I of 26*
