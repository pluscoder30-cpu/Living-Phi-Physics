# 10 — The Padovan Sequence | Intermediate Level

## Ages 13–16 | The Plastic Number's Sequence

---

## 1. Definition

The Padovan sequence is defined by:

```
P(0) = P(1) = P(2) = 1
P(n) = P(n-2) + P(n-3)  for n >= 3
```

First 25 terms:

```
1, 1, 1, 2, 2, 3, 4, 5, 7, 9, 12, 16, 21, 28, 37, 49, 65, 86,
114, 151, 200, 265, 351, 465, 616
```

The Padovan sequence is named after Italian architect Mario Padovan, who
first described it in 1906.

---

## 2. Connection to the Plastic Number

The plastic number psi is the real root of x^3 - x - 1 = 0, with
psi = 1.3247179572...

**Theorem:** P(n+1)/P(n) -> psi as n -> infinity.

**Proof sketch:** Assume P(n+1)/P(n) -> L. Then:

```
P(n+1) = P(n-1) + P(n-2)

P(n+1)/P(n) = P(n-1)/P(n) + P(n-2)/P(n)

As n -> inf: L = 1/L + 1/L^2

Multiply by L^2: L^3 = L + 1
               L^3 - L - 1 = 0

Positive root: L = psi = 1.3247179572...  (check)
```

---

## 3. Binet-like Formula

The nth Padovan number can be computed directly:

```
P(n) = a * psi^n + b * x2^n + c * x3^n
```

where psi = 1.3247179572... and x2, x3 are the complex conjugate roots
of x^3 - x - 1 = 0.

Since |x2| = |x3| < 1, the terms b*x2^n and c*x3^n -> 0 as n -> infinity.
So for large n:

```
P(n) ~ a * psi^n
```

The Padovan sequence grows exponentially with base psi.

---

## 4. Powers of psi

Using psi^3 = psi + 1, we can reduce powers:

```
psi^4 = psi * psi^3 = psi(psi + 1) = psi^2 + psi

psi^5 = psi * psi^4 = psi(psi^2 + psi) = psi^3 + psi^2
      = (psi + 1) + psi^2 = psi^2 + psi + 1

psi^6 = psi * psi^5 = psi(psi^2 + psi + 1) = psi^3 + psi^2 + psi
      = (psi + 1) + psi^2 + psi = psi^2 + 2*psi + 1

psi^7 = psi * psi^6 = psi(psi^2 + 2*psi + 1) = psi^3 + 2*psi^2 + psi
      = (psi + 1) + 2*psi^2 + psi = 2*psi^2 + 2*psi + 1
```

---

## 5. Recurrence Variants

**Variant 1:** Padovan with different starting values

```
P(0) = a, P(1) = b, P(2) = c
P(n) = P(n-2) + P(n-3)

Different starting values produce sequences with the same growth rate (psi)
but different initial conditions.
```

**Variant 2:** Perrin sequence

```
R(0) = 3, R(1) = 0, R(2) = 2
R(n) = R(n-2) + R(n-3)

First terms: 3, 0, 2, 3, 2, 5, 5, 7, 10, 12, 17, 22, 29, 39, 51, ...
```

The Perrin sequence has the same recurrence as Padovan but different starting
values. It shares the same characteristic equation x^3 - x - 1 = 0.

---

## 6. Geometric Interpretation

The Padovan sequence is related to the "plastic spiral":

```
Start with an equilateral triangle of side 1.
Add equilateral triangles to the sides in the pattern:
- Add triangle to side 1: new side length = 1
- Add triangle to side 1: new side length = 1
- Add triangle to side 2: new side length = 2
- Add triangle to side 2: new side length = 2
- Add triangle to side 3: new side length = 3
- ...

The side lengths follow the Padovan sequence: 1, 1, 1, 2, 2, 3, 4, 5, ...
```

---

## 7. Worked Problems

### Problem 1: Compute P(15)

**Question:** Find P(15) using the recurrence.

**Solution:**

```
P(0) = 1
P(1) = 1
P(2) = 1
P(3) = P(1) + P(0) = 2
P(4) = P(2) + P(1) = 2
P(5) = P(3) + P(2) = 3
P(6) = P(4) + P(3) = 4
P(7) = P(5) + P(4) = 5
P(8) = P(6) + P(5) = 7
P(9) = P(7) + P(6) = 9
P(10) = P(8) + P(7) = 12
P(11) = P(9) + P(8) = 16
P(12) = P(10) + P(9) = 21
P(13) = P(11) + P(10) = 28
P(14) = P(12) + P(11) = 37
P(15) = P(13) + P(12) = 49
```

---

### Problem 2: Ratio convergence

**Question:** Compute P(n+1)/P(n) for n = 8 through 14.

**Solution:**

```
P(9)/P(8) = 9/7 = 1.2857
P(10)/P(9) = 12/9 = 1.3333
P(11)/P(10) = 16/12 = 1.3333
P(12)/P(11) = 21/16 = 1.3125
P(13)/P(12) = 28/21 = 1.3333
P(14)/P(13) = 37/28 = 1.3214
P(15)/P(14) = 49/37 = 1.3243

psi = 1.3247179572...

The ratios converge to psi.
```

---

### Problem 3: Verify psi^3 = psi + 1

**Question:** Compute psi^3 and psi + 1 to 6 decimal places.

**Solution:**

```
psi = 1.324718

psi^3 = (1.324718)^3 = 2.324718

psi + 1 = 1.324718 + 1 = 2.324718

psi^3 = psi + 1  (check)
```

---

### Problem 4: Perrin sequence comparison

**Question:** Compute the first 10 terms of the Perrin sequence.

**Solution:**

```
R(0) = 3
R(1) = 0
R(2) = 2
R(3) = R(1) + R(0) = 3
R(4) = R(2) + R(1) = 2
R(5) = R(3) + R(2) = 5
R(6) = R(4) + R(3) = 5
R(7) = R(5) + R(4) = 7
R(8) = R(6) + R(5) = 10
R(9) = R(7) + R(6) = 12

Compare to Padovan: 1, 1, 1, 2, 2, 3, 4, 5, 7, 9
```

---

### Problem 5: Padovan product identity

**Question:** Find a relationship between P(n) and P(n+1)*P(n-1).

**Solution:**

```
n=5: P(5)*P(3) = 3*2 = 6, P(4)^2 = 4
n=6: P(6)*P(4) = 4*2 = 8, P(5)^2 = 9
n=7: P(7)*P(5) = 5*3 = 15, P(6)^2 = 16
n=8: P(8)*P(6) = 7*4 = 28, P(7)^2 = 25
```

No simple identity like Cassini's formula exists for Padovan numbers.

---

### Problem 6: Padovan and the plastic spiral

**Question:** If you create a plastic spiral using Padovan side lengths, what
is the total perimeter after adding 8 triangles?

**Solution:**

```
Side lengths: 1, 1, 1, 2, 2, 3, 4, 5

Each triangle adds its side length to the perimeter.
But the perimeter also loses the side where the new triangle is attached.

Simplified: total perimeter after n triangles = sum of first n Padovan numbers + 2

Sum(1 to 8) = 1+1+1+2+2+3+4+5 = 19
Perimeter = 19 + 2 = 21
```

---

### Problem 7: Padovan mod 2

**Question:** What is the pattern of even/odd Padovan numbers?

**Solution:**

```
P(0) = 1 (odd)
P(1) = 1 (odd)
P(2) = 1 (odd)
P(3) = 2 (even)
P(4) = 2 (even)
P(5) = 3 (odd)
P(6) = 4 (even)
P(7) = 5 (odd)
P(8) = 7 (odd)
P(9) = 9 (odd)
P(10) = 12 (even)
P(11) = 16 (even)
P(12) = 21 (odd)
P(13) = 28 (even)
P(14) = 37 (odd)

Pattern: O, O, O, E, E, O, E, O, O, O, E, E, O, E, ...
Period: 8
```

---

### Problem 8: Compare growth rates

**Question:** Compare the growth of Padovan, Fibonacci, and powers of 2.

**Solution:**

```
n  | P(n) | F(n) | 2^n
---|------|------|-----
1  | 1    | 1    | 2
2  | 1    | 1    | 4
3  | 1    | 2    | 8
4  | 2    | 3    | 16
5  | 2    | 5    | 32
6  | 3    | 8    | 64
7  | 4    | 13   | 128
8  | 5    | 21   | 256
9  | 7    | 34   | 512

Padovan grows slower than Fibonacci (psi < phi)
Both grow slower than 2^n
```

---

### Problem 9: Padovan and 3D geometry

**Question:** The Padovan sequence is connected to 3D spirals. If a 3D spiral
grows with factor psi per step, what is the growth after 5 steps?

**Solution:**

```
Growth per step: psi = 1.324718
Growth after 5 steps: psi^5

psi^5 = psi^2 + psi + 1
      = (1.324718)^2 + 1.324718 + 1
      = 1.754878 + 1.324718 + 1
      = 4.079596
```

---

### Problem 10: Padovan sum identity

**Question:** Find a formula for sum(P(0) to P(n)).

**Solution:**

```
Sum = P(0) + P(1) + ... + P(n)

Since P(k) = P(k+3) - P(k+1):

Sum = [P(3)-P(1)] + [P(4)-P(2)] + [P(5)-P(3)] + ... + [P(n+3)-P(n+1)]

This telescopes to: P(n+3) + P(n+2) - P(1) - P(0)
                   = P(n+3) + P(n+2) - 2
```

**Example:** P(0)+P(1)+P(2)+P(3)+P(4) = 1+1+1+2+2 = 7 = P(7)+P(6)-2 = 5+4-2. (check)

---

### Problem 11: Padovan primes

**Question:** Which Padovan numbers are prime?

**Solution:**

```
P(2) = 1 (not prime)
P(3) = 2 (prime)
P(4) = 2 (prime)
P(5) = 3 (prime)
P(7) = 5 (prime)
P(8) = 7 (prime)
P(12) = 21 (not prime)
P(14) = 37 (prime)
P(15) = 49 (not prime)
P(18) = 114 (not prime)
```

---

### Problem 12: Perrin primality test

**Question:** The Perrin sequence has a primality test: if n is prime, then
n divides R(n). Test this for n = 5, 7, 11.

**Solution:**

```
R(5) = 5, 5 divides 5  (prime, divides itself)
R(7) = 7, 7 divides 7  (prime, divides itself)
R(11) = 22, 11 divides 22  (prime, divides itself)

For composite n=8: R(8) = 10, 8 does not divide 10  (composite, doesn't divide)
For composite n=9: R(9) = 12, 9 does not divide 12  (composite, doesn't divide)
```

The converse is not always true: some composites also satisfy n | R(n)
(Perrin pseudoprimes).

---

### Problem 13: Padovan and the tribonacci

**Question:** How does the Padovan sequence differ from the tribonacci sequence?

**Solution:**

```
Padovan: P(n) = P(n-2) + P(n-3)
Tribonacci: T(n) = T(n-1) + T(n-2) + T(n-3)

Padovan uses two of the three previous terms (skipping one)
Tribonacci uses all three previous terms

Padovan growth rate: psi = 1.3247
Tribonacci growth rate: tau = 1.8393

Tribonacci grows faster.
```

---

### Problem 14: Padovan matrix formula

**Question:** Find a matrix formula for computing Padovan numbers.

**Solution:**

```
The recurrence P(n) = P(n-2) + P(n-3) can be written as:

| P(n+1) |     | 0  1  0 |   | P(n)   |
| P(n)   |  =  | 0  0  1 | * | P(n-1) |
| P(n-1) |     | 1  1  0 |   | P(n-2) |

So: | P(n+1) |     | 0  1  0 |^(n-2)   | P(3) |
    | P(n)   |  =  | 0  0  1 |      *   | P(2) |
    | P(n-1) |     | 1  1  0 |         | P(1) |
```

---

### Problem 15: Padovan and fractals

**Question:** The Padovan sequence generates the "Padovan triangle" fractal.
If the initial triangle has side 1, what is the total area after 5 iterations?

**Solution:**

```
Each iteration adds triangles of increasing side length.

Area of equilateral triangle with side s: (sqrt(3)/4) * s^2

Iteration 0: side 1, area = sqrt(3)/4 = 0.433
Iteration 1: side 1, area = 0.433 (adds to previous)
Iteration 2: side 1, area = 0.433
Iteration 3: side 2, area = sqrt(3) = 1.732
Iteration 4: side 2, area = 1.732
Iteration 5: side 3, area = (sqrt(3)/4)*9 = 3.897

Total area after 5 iterations = 0.433 + 0.433 + 0.433 + 1.732 + 1.732 + 3.897
                              = 8.660 square units
```

---

## 10. Summary Table

| Property | Value |
|----------|-------|
| Recurrence | P(n) = P(n-2) + P(n-3) |
| Starting values | P(0)=P(1)=P(2)=1 |
| Growth rate | psi = 1.3247179572... |
| Binet | P(n) ~ a * psi^n |
| Characteristic eq | x^3 - x - 1 = 0 |
| Related sequence | Perrin |
| 3D geometry | Plastic spiral |

---

## 11. Key Takeaways for Ages 13-16

1. **Padovan sequence** uses the recurrence P(n) = P(n-2) + P(n-3).
2. **Plastic number psi** is the growth rate: P(n+1)/P(n) -> psi.
3. **psi^3 = psi + 1** is the defining identity.
4. **Perrin sequence** has the same recurrence but different starting values.
5. **3D geometry** connects Padovan to plastic spirals.
6. **Growth rate** is slower than Fibonacci (psi < phi).

---

*Next: 11_intermediate_kepler.md — The Kepler Ratio*
