# PHI-ELECTROACOUSTIC COMPOSITION

## 1. PHI in Electronic Music Production

### 1.1 The PHI-DAW Framework

A Digital Audio Workstation (DAW) configured with phi-ratio parameters creates a naturally balanced mix environment.

```
PHI-Session Setup:
  BPM: 97 (60 x phi)
  Time signature: 5/4 or 8/5
  Grid resolution: 21 subdivisions per bar (F(8))
  Sample rate: 43200 Hz (phi-referenced: 432 x 100)
  Bit depth: 21-bit (F(8))
```

### 1.2 PHI-Mixing Ratios

Track volume relationships follow phi:

```
Group A (rhythm):   -6.0 dB (reference)
Group B (bass):     -6.0 + 6.2 dB = 0.2 dB (phi x 1 dB)
Group C (harmony):  -6.0 - 3.8 dB = -9.8 dB (reference / phi)
Group D (melody):   -6.0 + 2.4 dB = -3.6 dB (phi x reference)
Group E (effects):  -6.0 - 6.2 dB = -12.2 dB (reference / phi)
```

The phi-ratio between group volumes creates a mix where every element occupies its natural dynamic space without masking.

### 1.3 PHI-Panning

Stereo field placement uses phi-divisions:

```
Total pan width: 180 degrees
phi-divisions: 180/phi = 111.28 degrees

Pan positions:
  Hard left: -90 degrees
  phi-left: -90 + 111.28/2 = -34.36 degrees
  Center: 0 degrees
  phi-right: +34.36 degrees
  Hard right: +90 degrees
```

This creates five natural panning positions instead of the standard three (left, center, right).

## 2. PHI-Sound Design

### 2.1 Oscillator Architecture

```
PHI-Oscillator bank:
  Osc 1: f0 (fundamental)
  Osc 2: f0 x phi (minor sixth above)
  Osc 3: f0 x phi^2 (octave + minor sixth)
  Osc 4: f0 x phi^3 (two octaves + minor third)

FM synthesis with phi-ratios:
  Carrier: f0
  Modulator: f0 x phi
  Modulation index: I = phi x I0

  Result: Sidebands at f0 +/- n x (f0 x phi)
         = f0 x (1 +/- n x phi)
```

### 2.2 PHI-Filter Design

```
Low-pass filter:
  Cutoff: f0
  Resonance: Q = phi (critical damping at phi-Q)

Band-pass filter:
  Center: f0 x phi
  Bandwidth: BW = f0 / phi

High-pass filter:
  Cutoff: f0 x phi^2
  Slope: -6 x phi dB/octave = -9.71 dB/octave

Cascaded PHI-filter:
  Stage 1: LPF at f0
  Stage 2: BPF at f0 x phi
  Stage 3: HPF at f0 x phi^2
  
  Result: Bandpass from f0 to f0 x phi^2
         = bandwidth of f0 x (phi^2 - 1) = f0 x phi
```

### 2.3 PHI-Envelope Design

```
PHI-ADSR:
  Attack:  T_a (reference)
  Decay:   T_a x phi
  Sustain: Level / phi
  Release: T_a x phi^2

  Example (T_a = 100ms):
    Attack: 100 ms
    Decay: 162 ms
    Sustain: 0.618 (of peak level)
    Release: 262 ms
    
  Total envelope time: 100 + 162 + 262 = 524 ms
  Ratio to Attack: 524/100 = 5.24 = phi^3 + 1
```

## 3. PHI-Sampling

### 3.1 Sample Rate and phi

```
Standard sample rates: 44100, 48000, 96000 Hz
PHI-sample rates: 
  43200 Hz (432 x 100, phi-referenced)
  69984 Hz (43200 x phi)
  113234 Hz (43200 x phi^2)
  
  Nyquist frequency at 43200 Hz: 21600 Hz
  phi-Nyquist: 21600/phi = 13350 Hz
  
  The phi-Nyquist ensures that the highest representable
  frequency is phi times the audible range upper limit
```

### 3.2 Granular Synthesis

```
PHI-Grain parameters:
  Grain size: 50 ms (reference)
  Grain spacing: 50/phi = 30.9 ms
  Density: 1/30.9 = 32.4 grains/second
  
  Pitch randomization: +/- 50/phi cents = +/- 30.9 cents
  Time randomization: +/- 30.9 ms
  
  The phi-ratio between grain size and spacing creates
  a natural overlap that prevents clicks while maintaining
  the granular texture
```

### 3.3 Spectral Processing

```
PHI-Spectral freeze:
  Capture spectrum at time t
  Identify peaks at phi-related frequencies
  Sustain these peaks at phi-decay rate
  
  Amplitude of peak at frequency f_n:
    A(t) = A0 x phi^(-t/T_phi)
    Where T_phi = 1/(f0 x phi)
    
  Result: Spectral content decays at a rate proportional
  to its phi-distance from the fundamental
```

## 4. PHI-Algorithmic Composition

### 4.1 Markov Chains with phi-Transition Probabilities

```
State transition matrix:
  States: 7 (Fibonacci number)
  
  P(i->j) proportional to:
    1/phi^|i-j| if |i-j| is a Fibonacci number
    1/phi^(2|i-j|) otherwise
    
  Normalized transition matrix:
         S1    S2    S3    S4    S5    S6    S7
    S1 [0.236 0.382 0.236 0.090 0.034 0.013 0.005]
    S2 [0.146 0.236 0.382 0.146 0.056 0.021 0.008]
    S3 [0.090 0.146 0.236 0.382 0.146 0.056 0.021]
    ...
```

### 4.2 Cellular Automata with phi-Rules

```
Rule: phi-cellular automaton
  Cell states: 0 or 1
  Neighborhood: 3 cells (left, center, right)
  
  Update rule:
    new_state = (left + center + right) mod phi_rounded
    
  phi_rounded = round(phi) = 2
    
  This creates a modified Rule-30 automaton where
  the modulator is phi-based instead of integer-based
  
  Resulting patterns exhibit phi-fractal structure
```

### 4.3 Neural Network Composition

```
PHI-Neural architecture:
  Input layer: 21 neurons (F(8))
  Hidden layer 1: 13 neurons (F(7))
  Hidden layer 2: 8 neurons (F(6))
  Output layer: 5 neurons (F(5))
  
  Activation function: tanh(x/phi)
  Learning rate: 0.001 x phi = 0.001618
  Batch size: 13 (F(7))
  
  The phi-tapered architecture creates a natural
  information bottleneck that forces the network
  to learn phi-efficient representations
```

## 5. PHI-Spatial Audio

### 5.1 Ambisonics with phi

```
PHI-Ambisonic decoder:
  Channels: 8 (F(6))
  Speaker positions at phi-intervals:
    Azimuth: 0, 45, 90, 135, 180, 225, 270, 315 degrees
    (Standard: 45 degree spacing = 360/8)
    
  phi-spacing: 360/phi = 222.8 degrees
  Alternative: 360/phi^2 = 137.5 degrees (golden angle)
  
  8 speakers at golden angle spacing:
    0, 137.5, 275.0, 52.5, 190.0, 327.5, 105.0, 242.5 degrees
```

### 5.2 PHI-Reverb Design

```
PHI-Reverb parameters:
  Early reflections:
    Delay times: T0, T0 x phi, T0 x phi^2, T0 x phi^3
    Amplitudes: A0, A0/phi, A0/phi^2, A0/phi^3
    
  Late reverb:
    Density: increases by phi per second
    Decay time: RT60 = phi x T_musical
    Diffusion: phi x standard_diffusion
    
  Example (T0 = 20ms):
    Delays: 20, 32.4, 52.4, 84.7 ms
    Amplitudes: 1.0, 0.618, 0.382, 0.236
    RT60 = phi x 2.0 = 3.24 seconds
```

### 5.3 Doppler Effect phi

```
PHI-Doppler simulation:
  Source speed: v = c/phi (where c = speed of sound)
  
  Frequency shift:
    f_received = f_source x (c + v_listener) / (c - v_source)
    
  At v = c/phi = 343/phi = 212 m/s:
    f_received = f_source x (343 + 0) / (343 - 212)
               = f_source x 343/131
               = f_source x 2.618
               = f_source x phi^2
    
  The Doppler shift at phi-velocity is exactly phi^2,
  creating a natural pitch bend that follows the golden ratio
```

## 6. PHI-Audio Effects

### 6.1 PHI-Delay

```
PHI-Delay line:
  Delay time: T_phi = T0 x phi
  Feedback: 1/phi = 0.618 (self-sustaining decay)
  Mix: dry/(dry + wet) = 1/phi = 0.618
  
  For T0 = 100ms:
    Delay: 162 ms
    Feedback: 0.618
    After 5 repeats: amplitude = 0.618^5 = 0.090 (-20.9 dB)
    After 10 repeats: amplitude = 0.618^10 = 0.008 (-41.9 dB)
    
  The phi-feedback creates a natural decay that sounds
  like acoustic reverberation
```

### 6.2 PHI-Chorus

```
PHI-Chorus parameters:
  Delay: 20 ms (reference)
  Modulation rate: 0.618 Hz (1/phi)
  Modulation depth: 3.24 ms (phi ms)
  Voices: 3 (at 0, phi, phi^2 ms delay)
  
  Voice 1: 20 ms delay, 0 ms modulation
  Voice 2: 20 x phi = 32.4 ms delay, 3.24 ms modulation
  Voice 3: 20 x phi^2 = 52.4 ms delay, 5.24 ms modulation
```

### 6.3 PHI-Phaser

```
PHI-Phaser filter stages:
  Number of stages: 8 (F(6))
  Notch frequencies at phi-ratio:
    f1 = f0
    f2 = f0 x phi
    f3 = f0 x phi^2
    ...
    f8 = f0 x phi^7
    
  LFO rate: 1/phi Hz = 0.618 Hz
  LFO shape: phi-spiral (logarithmic)
  Feedback: 1/phi = 0.618
```

## 7. PHI-Mastering

### 7.1 EQ Curve

```
PHI-EQ settings:
  Low shelf: f0 = 100 Hz, gain = -3/phi = -1.85 dB
  Low-mid: f1 = 100 x phi = 162 Hz, gain = 0 dB (flat)
  Mid: f2 = 162 x phi = 262 Hz, gain = +2 dB
  High-mid: f3 = 262 x phi = 424 Hz, gain = 0 dB (flat)
  High shelf: f4 = 424 x phi = 686 Hz, gain = +3/phi = +1.85 dB
  
  The phi-spaced EQ bands create a balanced spectrum
  where each band is φ times the bandwidth of the previous
```

### 7.2 Compression

```
PHI-Compressor settings:
  Threshold: -20 dB (reference)
  Ratio: phi:1 = 1.618:1
  Attack: 10 ms
  Release: 10 x phi = 16.2 ms
  
  Knee: soft knee at phi x threshold = -20/phi = -12.36 dB
  
  The phi-ratio compression is gentler than 2:1 but
  more assertive than 1.5:1, creating a natural dynamic
  range that preserves transients while controlling peaks
```

### 7.3 Limiting

```
PHI-Limiter settings:
  Ceiling: -0.382 dB (1/phi dB below 0)
  Release: auto, phi-modulated
  
  True peak detection at phi-intervals:
    Check at: T, T x phi, T x phi^2, T x phi^3
    This catches inter-sample peaks at the most
    likely positions based on phi-probability
```

## 8. Live Performance

### 8.1 PHI-Live Coding

```
PHI-SuperCollider code:
  // PHI-rhythm engine
  (
  SynthDef(\phiRhythm, {arg out=0, freq=440, amp=0.5|
      var sig, env;
      sig = SinOsc.ar(freq);
      env = EnvGen.ar(
          Env([0, 1, 1/phi, 0], [0.01, 0.1, 0.162]),
          doneAction: 2
      );
      Out.ar(out, sig * env * amp);
  }).add;
  
  // PHI-pattern player
  Pbind(
      \instrument, \phiRhythm,
      \freq, Pseq([440, 440*phi, 440*phi**2, 440*phi**3], inf),
      \dur, Pseq([1, 1/phi, 1/phi**2, 1/phi**3], inf),
      \amp, 0.5
  ).play;
  )
```

### 8.2 PHI-Modular Synthesis

```
PHI-Modular patch:
  Oscillator 1: Sine wave at f0
  Oscillator 2: Sine wave at f0 x phi
  VCA: modulated by oscillator 2
  Filter: cutoff at f0 x phi, Q = phi
  Envelope: phi-ADSR
  Delay: feedback = 1/phi
  
  Patch cables:
    Osc2 -> VCA mod input
    Osc1 -> Filter input
    Filter -> VCA input
    Envelope -> VCA CV
    VCA -> Delay input
    Delay -> Filter feedback
```

### 8.3 PHI-DJ Technique

```
PHI-BPM matching:
  Track A: 120 BPM
  Track B: 120 x phi = 194.2 BPM (too fast)
  
  Alternative: Track B at 120/phi = 74.2 BPM
  Or: Track B at 120 x phi^(-1) = 74.2 BPM
  
  PHI-beatmatching:
    Find phi-point in Track A: 120 beats x 0.618 = 74.2 beats
    Find phi-point in Track B: match at 74.2 beats
    Transition: crossfade over 74.2 beats
```

## 9. Release and Distribution

### 9.1 PHI-Release Strategy

```
Release timeline (in days):
  Day 0: Singles release
  Day 1: Music video (phi x 0.618 = 1 day)
  Day 2: Behind-the-scenes (phi x 1 = 2 days)
  Day 3: Live performance (phi x 2 = 3 days)
  Day 5: Remix release (phi x 3 = 5 days)
  Day 8: Full album (phi x 5 = 8 days)
  Day 13: Deluxe edition (phi x 8 = 13 days)
  Day 21: Box set (phi x 13 = 21 days)
```

### 9.2 PHI-Track Listing

```
Album track order (phi-sequenced):
  Track 1: Introduction (30 seconds)
  Track 2: Opening (phi x 30 = 49 seconds)
  Track 3: Build (phi^2 x 30 = 79 seconds)
  Track 4: Peak (phi^3 x 30 = 128 seconds)
  Track 5: Resolution (phi^4 x 30 = 207 seconds)
  Track 6: Reflection (phi^5 x 30 = 335 seconds)
  Track 7: Conclusion (phi^6 x 30 = 542 seconds)
  
  Total: 1360 seconds = 22.7 minutes (close to F(9)/phi = 21 minutes)
```

## References

- Curtis Roads (2001). "The Computer Music Tutorial"
- Miller Puckette (2007). "The Theory and Technique of Electronic Music"
- F. Richard Moore (1990). "Elements of Computer Music"
- Barry Truax (1994). "Handbook for Acoustic Ecology"
- Joel Chadabe (1997). "Electric Sound"
