# PHI-Reinsurance: Golden Ratio Risk Transfer

## Directory 92_PHI_INSURANCE_SCIENCE | File 04

---

## 1. PHI-Proportional Reinsurance

### 1.1 PHI-Quota Share

```
Retention = (1 - cession%) * phi^{cedant_retention}
Cession = cession% * gross_premium * phi^{-cedant_expense}
```

### 1.2 PHI-Surplus

```
Retention = line * phi^{cedant_capacity}
Cession = (line - retention) / line * loss * phi^{cedant_benefit}
```

### 1.3 PHI-Facultative

```
Premium = manual_rate * phi^{cessional_load} * phi^{-volume_discount}
```

### 1.4 PHI-Working Cover

```
Working = layer * phi{-loss_ratio} * phi{-volatility}
```

---

## 2. PHI-Non-Proportional

### 2.1 PHI-Excess of Loss

```
Premium = E[min(L - retention, limit)] * phi^{loading}
```

### 2.2 PHI-Stop Loss

```
Premium = E[min(L, stop_loss_limit)] * phi{moral_hazard}
```

### 2.3 PHI-Per Risk

```
Retention = max_retention * phi^{risk_size}
```

### 2.4 PHI-Per Occurrence

```
Retention = per_occurrence * phi{frequency_adjustment}
```

---

## 3. PHI-Catastrophe Reinsurance

### 3.1 PHI-Event

```
Premium = expected_cat_loss * phi{return_period} * phi{loading}
```

### 3.2 PHI-XoL

```
Retention = attachment * phi{severity}
Limit = capacity * phi{max_loss}
```

### 3.3 PHI-Multi-Peril

```
Premium = sum peril_premium * phi^{-diversification}
```

### 3.4 PHI-Retrospective

```
Premium = historical_loss * phi{trend_factor}
```

---

## 4. PHI-Reinsurance Pricing

### 4.1 PHI-Pricing Formula

```
Premium = E[L] * (1 + phi{expense}) * (1 + phi{profit}) * phi{market}
```

### 4.2 PHI-Burning Cost

```
Burning = sum historical / n * phi{exposure_trend}
```

### 4.3 PHI-Expected Loss

```
EL = frequency * severity * phi{large_loss_adjustment}
```

### 4.4 PHI-Risk Margin

```
Margin = VaR * phi{cost_of_capital} * phi{uncertainty}
```

---

## 5. PHI-Contract Terms

### 5.1 PHI-Restoration

```
Restoration = limit * phi{restoration_premium}
```

### 5.2 PHI-Erasure

```
Erasure = paid * phi{erasure_cost}
```

### 5.3 PHI-Claims Occurrence

```
Occurrence = trigger * phi{occurrence_basis}
```

### 5.4 PHI-Losses Occurring

```
LO = occurrence * phi{losses_occurring}
```

---

## 6. PHI-Retrocession

### 6.1 PHI-Retro-XoL

```
Premium = expected_cedant_loss * phi{retro_loading}
```

### 6.2 PHI-Pool

```
Pool_share = line / total_lines * phi{diversification}
```

### 6.3 PHI-Catastrophe Bonds

```
Coupon = risk_free + spread * phi{trigger_probability}
```

### 6.4 PHI-ILW

```
ILW = max(0, industry_loss - trigger) * phi{basis_risk}
```

---

## 7. PHI-Reinsurance Accounting

### 7.1 PHI-DAC

```
DAC = deferred_commission * phi{amortization_period}
```

### 7.2 PHI-Unearned Premium

```
UPR = premium * (unexpired/total) * phi{deferred}
```

### 7.3 PHI-Claims Reserve

```
Reserve = incurred - paid * phi{development}
```

### 7.4 PHI-Profit Commission

```
Commission = (premium - loss) * commission% * phi{cedant_profit}
```

---

## 8. Summary

PHI-reinsurance provides:
1. PHI-quota share with phi-retention and phi-cession
2. PHI-non-proportional with phi-XoL and phi-stop loss
3. PHI-catastrophe with phi-event and phi-multi-peril
4. PHI-pricing with phi-burning cost and phi-risk margin
5. PHI-terms with phi-restoration and phi-erasure
6. PHI-retrocession with phi-retro-XoL and phi-ILW
7. PHI-accounting with phi-DAC and phi-UPR

The golden ratio creates natural layers of risk transfer while optimizing the balance between retention and cession.