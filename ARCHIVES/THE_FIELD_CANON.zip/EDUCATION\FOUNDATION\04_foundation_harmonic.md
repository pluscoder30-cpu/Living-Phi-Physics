# Foundation Mathematics: Harmonic Math

## Welcome, Young Mathematician!

Have you ever noticed how some sounds seem to fit together perfectly? Like when you sing a note and someone else sings a note that sounds "just right" with yours? That's **harmony** — and it's all about math!

Harmony is when sounds fit together. The secret behind beautiful music is the secret behind beautiful math!

---

## Part 1: What is Harmony?

### Sounds That Fit Together

When two sounds fit together well, we call them **harmonious**. When they don't fit, we call them **dissonant**.

But what makes sounds fit together? The answer is: **ratios**!

The ratio between two notes determines how they sound together. Simple ratios sound good. Complicated ratios sound messy.

### The Musical Ratios

Here are the most important musical ratios:

- **Octave**: 2:1 — The same note, higher or lower. Sounds perfect!
- **Fifth**: 3:2 — The most powerful harmony. Think of the "Star Wars" theme!
- **Fourth**: 4:3 — Very stable. Think of "Here Comes the Bride."
- **Third**: 5:4 — Sweet and happy. Think of a major chord.
- **Sixth**: 5:3 — Warm and rich.

See the pattern? The numbers are all small, simple ratios!

### Why Simple Ratios Sound Good

When two notes have a simple ratio like 2:1, their sound waves line up perfectly:

```
Note 1: ~~--~~--~~--~~--~~
Note 2: ~~~~~~----------~~~~~~
```

The waves meet up at regular points. Your brain likes this pattern!

When the ratio is complicated, the waves don't line up:

```
Note 1: ~~--~~--~~--~~--~~
Note 2: ~---~~---~~---~~---
```

The waves clash. Your brain doesn't like this!

---

## Part 2: The Harmonic Series

### The Numbers Behind Harmony

The harmonic series is a list of numbers that comes from music:

1, 1/2, 1/3, 1/4, 1/5, 1/6, 1/7, 1/8...

These are the **overtones** — the extra sounds that come with every note you play!

### How Overtones Work

When you pluck a guitar string, it doesn't just make one sound. It makes a whole bunch of sounds at once:

- The whole string vibrates (the fundamental)
- Half the string vibrates (first overtone)
- A third of the string vibrates (second overtone)
- And so on...

These overtones are what give each instrument its unique sound!

### The Harmonic Series in Music

The harmonic series is the foundation of Western music:

- **Octave** = 2nd harmonic (1/2 of the string)
- **Fifth** = 3rd harmonic (1/3 of the string)
- **Fourth** = 4th harmonic (1/4 of the string)
- **Major Third** = 5th harmonic (1/5 of the string)

As you go higher in the harmonic series, the notes get closer together!

---

## Part 3: Musical Scales and Math

### The 12 Notes

The Western musical scale has 12 notes per octave:

C, C#, D, D#, E, F, F#, G, G#, A, A#, B

Each note is separated by the same ratio: the **twelfth root of 2** (about 1.05946).

### Why 12?

Why 12 notes? Because 12 is a good compromise between:
- Making simple ratios available
- Having enough notes to play complex music
- Keeping the intervals small enough to sound smooth

### Equal Temperament

Modern instruments use **equal temperament** — each note is equally spaced. This makes it easy to play in any key, but some intervals aren't perfectly in tune.

Historically, musicians used **just intonation** — intervals based on perfect ratios. This sounds better in some keys but worse in others.

---

## Part 4: Harmony in Nature

### The Harmonic Series in Nature

Harmony isn't just in music. It's everywhere in nature:

- **Planets**: The orbits of planets create harmonious ratios
- **Atoms**: Electrons in atoms follow harmonic patterns
- **DNA**: The structure of DNA has harmonic proportions
- **Weather**: Some weather patterns follow harmonic cycles

### Kepler's Music of the Spheres

The astronomer Johannes Kepler believed that planets make music as they orbit the Sun! He wrote a whole book called "Harmonices Mundi" (The Harmony of the World).

Kepler found that:
- Earth and Mars have a 2:3 ratio (a fifth)
- Jupiter and Saturn have a 5:9 ratio
- All the planets together create a cosmic harmony!

### Harmony in Your Body

Your body has harmonic rhythms:
- Your heartbeat has a rhythm
- Your breathing has a rhythm
- Your brain waves have rhythms
- Even your DNA has a rhythmic structure!

---

## Part 5: 10 Fun Exercises

### Exercise 1: The String Experiment
If you have a guitar or ukulele, press down on a string at the halfway point. Play the note. Then play the open string. The pressed note should be exactly one octave higher!

### Exercise 2: Draw Harmonic Waves
Draw two waves:
- Wave A: 4 complete cycles
- Wave B: 6 complete cycles (same length)

Notice how they line up every 2 cycles? That's a 2:3 ratio — a perfect fifth!

### Exercise 3: The Harmonic Series Calculator
Write out the first 10 terms of the harmonic series:
1, 1/2, 1/3, 1/4, 1/5, 1/6, 1/7, 1/8, 1/9, 1/10

Convert them to decimals:
1, 0.5, 0.333..., 0.25, 0.2, 0.167..., 0.143..., 0.125, 0.111..., 0.1

What pattern do you notice?

### Exercise 4: Ratios in Songs
Listen to three songs and try to identify the main intervals:
- "Twinkle, Twinkle, Little Star" — what's the interval between the first two notes?
- "Here Comes the Bride" — what's the interval?
- "Star Wars Theme" — what's the interval?

### Exercise 5: Build a Harmonic Tower
Draw a tower with 8 levels. Each level represents a harmonic:
- Level 1: Fundamental (full height)
- Level 2: 1/2 height
- Level 3: 1/3 height
- Level 4: 1/4 height
- And so on...

Color each level a different color!

### Exercise 6: The 12-Note Wheel
Draw a circle divided into 12 equal sections. Label each section with a note (C, C#, D, etc.). Now draw lines connecting notes that have simple ratios:
- C to G (a fifth)
- C to F (a fourth)
- C to E (a major third)

What shape do you see?

### Exercise 7: Harmony in Patterns
Create a visual pattern using harmonic proportions:
- Draw a large shape (the fundamental)
- Draw a shape half as big (2nd harmonic)
- Draw a shape a third as big (3rd harmonic)
- Keep going!

### Exercise 8: Your Body's Harmony
Measure these ratios on your body:
- Height of your head to height of your body
- Length of your hand to length of your arm
- Width of your shoulders to width of your hips

Are any of these close to musical ratios?

### Exercise 9: Piano Key Lengths
If you have access to a piano, measure the lengths of the white keys. Are they in harmonic proportions?

### Exercise 10: Harmony Journal
In your math journal:
- Draw a picture of sound waves showing harmony
- Write down three harmonic ratios you found today
- Draw a picture of Kepler's music of the spheres
- Write a short poem about harmony

---

## Part 6: Amazing Harmony Facts

### Fact 1: Pythagoras and the Discovery
The ancient Greek mathematician Pythagoras discovered that musical harmony is based on numbers. He found that:
- A string half as long plays an octave higher
- A string 2/3 as long plays a fifth higher
- A string 3/4 as long plays a fourth higher

This was the first time anyone connected math to music!

### Fact 2: The Tetractys
Pythagoras loved the number 10. He drew it as a triangle:
```
    *
   * *
  * * *
 * * * *
```
This is called the **tetractys**. It contains the ratios 1:2, 2:3, and 3:4 — the three most important musical intervals!

### Fact 3: Music Therapy
Music therapy uses harmonic principles to help people:
- Reduce stress
- Improve memory
- Manage pain
- Enhance mood

The math behind music literally heals!

### Fact 4: The Harmonic Series Diverges
The sum of the harmonic series (1 + 1/2 + 1/3 + 1/4 + ...) goes to infinity! It grows slowly, but it never stops. This is one of the most surprising facts in math!

### Fact 5: Harmony in Architecture
Many famous buildings use harmonic ratios in their design:
- The Parthenon uses 2:3 ratios
- Gothic cathedrals use harmonic proportions
- Modern concert halls are designed for optimal harmony

---

## Part 7: Harmony Poems

### The Harmony Poem
Harmony is when sounds align,
When ratios fit, and all is fine,
From Pythagoras to modern day,
Music and math show us the way!

### The Musical Rhyme
One to two is an octave true,
Two to three, a fifth for you,
Three to four, a fourth to sing,
Four to five, a third — what a thing!

---

## Part 8: What You've Learned

Today you discovered:

1. **Harmony is math** — simple ratios between sounds create pleasant combinations.

2. **The harmonic series** (1, 1/2, 1/3, 1/4...) is the foundation of music and appears in nature.

3. **Musical scales** are based on mathematical ratios, and modern instruments use 12 equally-spaced notes.

4. **Harmony appears** in planets, atoms, DNA, and your own body.

5. **Pythagoras** discovered the connection between math and music over 2,500 years ago!

---

## Part 9: Challenge Problems

### Challenge 1: The Harmonic Series Sum
Try adding the first 10 terms of the harmonic series:
1 + 1/2 + 1/3 + 1/4 + 1/5 + 1/6 + 1/7 + 1/8 + 1/9 + 1/10

What do you get? (Answer: about 2.93)

### Challenge 2: Equal Temperament
If the 12-note scale divides the octave into equal parts, what is the exact ratio between each note? (Hint: it's 2^(1/12))

### Challenge 3: Harmonic Mean
The harmonic mean of two numbers a and b is 2ab/(a+b). Calculate the harmonic mean of 4 and 9.

### Challenge 4: Music and Fractions
A whole note lasts 4 beats. A half note lasts 2 beats. A quarter note lasts 1 beat. How many of each note type fit in one measure (4 beats)?

### Challenge 5: Build a Harmony Machine
Design a simple instrument that demonstrates harmonic ratios. What materials would you use? How would you tune it?

---

## Part 10: Glossary

**Consonant**: Sounds that fit together well, creating a pleasant effect

**Dissonant**: Sounds that clash, creating tension

**Equal Temperament**: A tuning system where each note is equally spaced

**Harmonic Mean**: A type of average: 2ab/(a+b)

**Harmonic Series**: The list of numbers: 1, 1/2, 1/3, 1/4, ...

**Interval**: The distance between two notes

**Just Intonation**: A tuning system based on perfect ratios

**Octave**: An interval with a 2:1 ratio

**Overtone**: An extra frequency that sounds along with the main note

**Tetractys**: A triangular arrangement of 10 dots, used by Pythagoras

---

## Remember!

**Harmony is when sounds fit together!**

The next time you hear music, remember: behind every beautiful melody and harmony, there's beautiful math. Harmony is the universe's way of saying "these numbers work together!"

---

*Music is math you can hear. Harmony is math you can feel. And the best part? You don't need to understand the math to enjoy the music — but understanding the math makes the music even more beautiful!*
