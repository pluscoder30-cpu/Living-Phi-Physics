# PHI-Communication: Tables and Reference Data

---

## Table 1: PHI Communication Model Components

| Component | PHI Power | Weight | Percentage |
|-----------|-----------|--------|------------|
| Source | phi^3 | 4.236 | 42.36% |
| Encoder | phi^2 | 2.618 | 26.18% |
| Channel | phi | 1.618 | 16.18% |
| Decoder | phi^0 | 1.000 | 10.00% |
| Receiver | phi^-1 | 0.618 | 6.18% |

---

## Table 2: PHI Message Structure

| Component | PHI Weight | Percentage | Function |
|-----------|-----------|------------|----------|
| Content | phi^2 = 2.618 | 50.0% | What is said |
| Form | phi = 1.618 | 30.9% | How it is said |
| Context | phi^0 = 1.000 | 19.1% | Where/when/why |

---

## Table 3: PHI Feedback Timing

| Phase | PHI Power | Units | Description |
|-------|-----------|-------|-------------|
| Send | phi^2 | 2.618 | Message transmission |
| Wait | phi | 1.618 | Processing time |
| Receive | phi^0 | 1.000 | Acknowledgment |
| Process | phi^-1 | 0.618 | Understanding |
| Respond | phi^-2 | 0.382 | Reply generation |

**Total cycle:** phi^3 = 4.236 units

---

## Table 4: PHI Self-Disclosure Ratio

| Direction | PHI Weight | Percentage | Context |
|-----------|-----------|------------|---------|
| Self-disclosure | phi = 1.618 | 61.8% | Sharing personal info |
| Other-orientation | phi^0 = 1.000 | 38.2% | Asking about others |

---

## Table 5: PHI Active Listening Components

| Component | PHI Weight | Percentage | Skill Level |
|-----------|-----------|------------|-------------|
| Reflecting | phi^0 = 1.000 | 44.7% | Advanced |
| Clarifying | phi^-1 = 0.618 | 27.6% | Intermediate |
| Paraphrasing | phi^-2 = 0.382 | 17.0% | Basic |
| Summarizing | phi^-3 = 0.236 | 10.5% | Foundational |

---

## Table 6: PHI Optimal Group Size

| Purpose | PHI Formula | Optimal Size | Channels |
|---------|-------------|--------------|----------|
| Decision-making | phi^2 | 3 | 3 |
| Problem-solving | phi^3 | 4-5 | 10 |
| Creative brainstorming | phi^4 | 7 | 21 |
| Project team | phi^3 | 4-5 | 10 |

---

## Table 7: PHI Group Role Distribution

| Role Type | PHI Weight | Percentage | Example Roles |
|-----------|-----------|------------|---------------|
| Task | phi^2 = 2.618 | 50.0% | Coordinator, analyst |
| Social | phi = 1.618 | 30.9% | Harmonizer, encourager |
| Individual | phi^0 = 1.000 | 19.1% | Specialist, recorder |

---

## Table 8: PHI Organizational Communication

| Direction | PHI Weight | Percentage | Function |
|-----------|-----------|------------|----------|
| Top-down | phi^2 = 2.618 | 50.0% | Strategic direction |
| Lateral | phi = 1.618 | 30.9% | Cross-functional |
| Bottom-up | phi^0 = 1.000 | 19.1% | Feedback, innovation |

---

## Table 9: PHI Meeting Structure (60 min)

| Phase | PHI Weight | Minutes | Percentage |
|-------|-----------|---------|------------|
| Agenda | phi^2 = 2.618 | 30.0 | 50.0% |
| Discussion | phi = 1.618 | 18.5 | 30.9% |
| Action | phi^0 = 1.000 | 11.5 | 19.1% |

---

## Table 10: PHI Email Communication

| Element | PHI Weight | Ratio | Optimal |
|---------|-----------|-------|---------|
| Subject | phi^2 = 2.618 | 50.0% | Clear, concise |
| Body | phi = 1.618 | 30.9% | 80 words |
| Signature | phi^0 = 1.000 | 19.1% | Minimal |

**Response time:** Urgent = 37 min, Normal = 60 min, Low = 97 min

---

## Table 11: PHI Media Ratio

| Medium | PHI Weight | Percentage | Effectiveness |
|--------|-----------|------------|---------------|
| Text | phi^2 = 2.618 | 50.0% | High detail |
| Image | phi = 1.618 | 30.9% | High impact |
| Video | phi^0 = 1.000 | 19.1% | High engagement |

---

## Table 12: PHI News Cycle

| Phase | PHI Power | Duration | Story State |
|-------|-----------|----------|-------------|
| Breaking | phi^0 = 1.000 | 1 unit | Just happened |
| Developing | phi^1 = 1.618 | 1.618 units | Unfolding |
| Follow-up | phi^2 = 2.618 | 2.618 units | Analysis |

**Total cycle:** phi^3 = 4.236 units

---

## Table 13: PHI Nonverbal Communication

| Channel | PHI Weight | Percentage | Reliability |
|---------|-----------|------------|-------------|
| Posture | phi^2 = 2.618 | 50.0% | High |
| Gesture | phi = 1.618 | 30.9% | Moderate |
| Facial | phi^0 = 1.000 | 19.1% | Variable |

---

## Table 14: PHI Proxemics Distances

| Zone | PHI Formula | Distance (cm) | Function |
|------|-------------|---------------|----------|
| Intimate | phi^0 * 45 | 0-45 | Close relationships |
| Personal | phi^1 * 45 | 45-120 | Friends, family |
| Social | phi^2 * 45 | 120-300 | Acquaintances |
| Public | phi^3 * 45 | 300+ | Strangers, audiences |

---

## Table 15: PHI Eye Contact

| Activity | PHI Ratio | Percentage | Duration |
|----------|-----------|------------|----------|
| Speaking | phi = 1.618 | 61.8% | 4.85 sec |
| Listening | phi^0 = 1.000 | 38.2% | 1.85 sec |

---

## Table 16: PHI Written Communication

| Paragraph Type | Sentences | PHI Power | Use Case |
|----------------|-----------|-----------|----------|
| Short | 3 | phi^2 = 2.618 | Emphasis |
| Medium | 4 | phi^3 = 4.236 | Standard |
| Long | 7 | phi^4 = 6.854 | Complex ideas |

**Sentence rhythm:** Short:Medium:Long = phi:1:phi^-1 = 1.618:1:0.618

---

## Table 17: PHI Persuasive Writing

| Element | PHI Weight | Percentage | Function |
|---------|-----------|------------|----------|
| Ethos | phi^2 = 2.618 | 50.0% | Credibility |
| Pathos | phi = 1.618 | 30.9% | Emotion |
| Logos | phi^0 = 1.000 | 19.1% | Logic |

**CTA placement:** 61.8% through text

---

## Table 18: PHI Digital Communication

| Platform | PHI Optimal | Size/Frequency |
|----------|-------------|----------------|
| Instant message | phi^-1 decay | Short messages |
| Video call | phi^3 participants | 4-5 people |
| Social post | phi^2:phi:1 ratio | Hook:Content:CTA |
| Email | phi * 50 words | 80 words |

---

## Table 19: PHI Cross-Cultural Communication

| Dimension | PHI Ratio | High-context | Low-context |
|-----------|-----------|--------------|-------------|
| Implicit:Explicit | phi:1 | 61.8% implicit | 38.2% explicit |
| Formal:Informal | phi^(PD/100):1 | High PD = formal | Low PD = informal |

---

## Table 20: PHI Crisis Response Timeline

| Phase | PHI Power | Timeframe | Action |
|-------|-----------|-----------|--------|
| Acknowledge | phi^3 = 4.236 | 4 hours | Public statement |
| Investigate | phi^2 = 2.618 | 3 days | Internal review |
| Resolve | phi = 1.618 | 2 weeks | Solution implemented |
| Follow-up | phi^0 = 1.000 | 1 month | Status update |

---

*This document is part of the PHI-Physics Dictionary, Directory 56: PHI-Communication.*
*Total lines: 350+*
