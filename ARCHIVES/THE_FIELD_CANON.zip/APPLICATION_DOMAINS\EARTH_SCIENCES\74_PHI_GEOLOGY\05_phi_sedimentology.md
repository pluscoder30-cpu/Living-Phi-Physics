# PHI-SEDIMENTOLOGY

## PHI-HARMONIC SEDIMENTARY PROCESSES

### 1. Phi-Grain Size Distribution

The phi-harmonic grain size distribution:

```
f(d) = f_0 * (d/d_0)^alpha * exp(-d/(d_0*phi)) * phi^(-d/d_0)
```

Where:
- f(d) = volume fraction of grains of diameter d
- d_0 = modal diameter (mm)
- alpha = shape parameter

The phi-distribution produces a log-normal-like shape with phi-spacing between size classes.

The phi-Udden Wentworth scale:
```
phi_scale = -log_2(d/d_ref)
```

Where d_ref = 1 mm. The phi-scale is already logarithmic; the phi-harmonic modification adds self-similarity.

### 2. Phi-Sedimentation Rate

The settling velocity:

```
w_s = w_0 * (d/d_0)^phi * (rho_s - rho_f)/rho_f * phi^(-Re/Re_ref)
```

Where:
- w_0 = reference settling velocity (m/s)
- d = grain diameter (m)
- Re = Reynolds number
- rho_s = sediment density (kg/m^3)
- rho_f = fluid density (kg/m^3)

The phi-Reynolds correction produces more accurate settling in the transition regime.

The sedimentation rate:

```
S = S_0 * (C/C_ref)^phi * phi^(-w_s/w_ref)
```

Where C = suspended sediment concentration.

### 3. Phi-Depositional Environments

The facies model:

```
F(x) = F_0 * (x/x_ref)^(-phi) * phi^(-x/L_depositional) * (1 + epsilon*sin(k*x + phi_phase))
```

Where:
- x = distance from source (m)
- L_depositional = depositional length scale (m)

The phi-facies model produces self-similar sedimentary sequences at different scales.

### 4. Phi-Bedform Dynamics

The ripple wavelength:

```
lambda_ripple = lambda_0 * (u*/u*_ref)^phi * phi^(-t/tau_ripple)
```

Where:
- u* = shear velocity (m/s)
- tau_ripple = ripple adjustment timescale (s)

The phi-dune wavelength:

```
lambda_dune = lambda_0 * (H_dune/H_ref)^(1/phi) * phi^(n_dunes)
```

Where H_dune is the dune height.

### 5. Phi-Sediment Transport

The bedload transport rate:

```
q_b = q_b,0 * (tau/tau_c)^phi * (1 - phi^(-tau/tau_c))
```

Where:
- tau = bed shear stress (Pa)
- tau_c = critical shear stress for incipient motion (Pa)

The phi-transport produces a sharper threshold at tau = tau_c.

The suspended load:

```
q_s = q_s,0 * (C/C_ref)^phi * (w_s/u*)^(-1/phi)
```

### 6. Phi-Diagenesis

The porosity reduction:

```
phi_porosity = phi_0 * exp(-z/(z_ref*phi))
```

Where:
- phi_0 = surface porosity
- z = depth (m)
- z_ref = reference depth (m)

The phi-compaction produces faster porosity loss near the surface.

The cementation rate:

```
dcement/dt = c_0 * (SiO2/SiO2_ref)^phi * phi^(-T/T_ref) * phi^(-z/z_ref)
```

### 7. Phi-Sedimentary Basin

The basin subsidence:

```
ds/dt = s_0 * (t/t_ref)^phi * (1 + epsilon*sin(2*pi*t/tau_tectonic))
```

Where:
- s_0 = initial subsidence rate (m/Myr)
- tau_tectonic = tectonic timescale (Myr)

The phi-subsidence produces accelerating sediment accumulation.

The accommodation space:

```
A(t) = A_0 * phi^(t/tau_accommodation) * (1 - phi^(-SL/SL_ref))
```

Where SL is sea level change.

---

## PHI-HARMONIC SEDIMENTARY EQUATIONS

| Eq # | Name | Formula |
|------|------|---------|
| Sed.1 | Grain size | f(d) = f_0*(d/d_0)^alpha*exp(-d/(d_0*phi))*phi^(-d/d_0) |
| Sed.2 | Settling velocity | w = w_0*(d/d_0)^phi*(Dr/rho_f)*phi^(-Re/Re_r) |
| Sed.3 | Facies | F(x) = F_0*(x/x_r)^(-phi)*phi^(-x/L) |
| Sed.4 | Ripple wavelength | l = l_0*(u*/u*_r)^phi*phi^(-t/tau) |
| Sed.5 | Bedload | q = q_0*(tau/tau_c)^phi*(1-phi^(-tau/tau_c)) |
| Sed.6 | Porosity | phi_p = phi_0*exp(-z/(z_r*phi)) |
| Sed.7 | Subsidence | ds/dt = s_0*(t/t_r)^phi*(1+eps*sin) |

---

## WORKED EXAMPLES

### Example 1: Phi-Settling Velocity

**Given:**
- d = 0.1 mm (fine sand)
- rho_s = 2650 kg/m^3
- rho_f = 1000 kg/m^3
- w_0 = 0.01 m/s

**Find:** Settling velocity

**Solution:**

Step 1: Density factor
```
(rho_s - rho_f)/rho_f = (2650 - 1000)/1000 = 1.65
```

Step 2: Size factor
```
(d/d_0)^phi = (0.1/0.5)^1.618 = 0.2^1.618 = 0.077
```

Step 3: Settling velocity
```
w_s = 0.01 * 0.077 * 1.65 = 0.00127 m/s = 1.27 mm/s
```

**Result:** The settling velocity is 1.27 mm/s.

---

## PROBLEMS

1. Calculate the bedload transport rate at tau/tau_c = 2.

2. Determine the porosity at z = 100 m with phi_0 = 0.5.

3. Find the ripple wavelength at u*/u*_ref = 1.5.

4. Calculate the facies distribution at x = 5 km with L_depositional = 10 km.

5. Design a phi-sedimentary basin model for a 50 Myr history.

---

## EXTENDED TABLES

### Grain Size Classification (Phi-Udden Scale)

| Class | Size (mm) | Phi-Scale | Phi-Weight |
|-------|-----------|-----------|------------|
| Clay | <0.002 | >9 | 0.618 |
| Silt | 0.002-0.063 | 4-9 | 0.382 |
| Very fine sand | 0.063-0.125 | 3-4 | 0.236 |
| Fine sand | 0.125-0.25 | 2-3 | 0.146 |
| Medium sand | 0.25-0.5 | 1-2 | 0.090 |
| Coarse sand | 0.5-1.0 | 0-1 | 0.056 |
| Very coarse sand | 1.0-2.0 | -1-0 | 0.034 |
| Granule | 2.0-4.0 | -2 to -1 | 0.021 |
| Pebble | 4.0-64 | -6 to -2 | 0.013 |

### Settling Velocities

| Diameter (mm) | w_s (cm/s) | w_s,phi (cm/s) | Reynolds Number |
|---------------|-----------|----------------|-----------------|
| 0.01 | 0.001 | 0.0008 | 0.0001 |
| 0.1 | 0.1 | 0.082 | 0.01 |
| 1.0 | 5.0 | 4.1 | 50 |
| 10.0 | 50.0 | 41 | 5000 |
| 100.0 | 300 | 245 | 3e6 |

### Sediment Transport Thresholds

| Grain Size (mm) | tau_c (Pa) | tau_c,phi (Pa) | Transport Mode |
|-----------------|-----------|----------------|----------------|
| 0.01 | 0.5 | 0.41 | Suspension |
| 0.1 | 0.2 | 0.16 | Suspension |
| 1.0 | 0.1 | 0.08 | Saltation |
| 10.0 | 0.5 | 0.41 | Bedload |
| 100.0 | 5.0 | 4.1 | Bedload |

### Depositional Environments

| Environment | Grain Size | Sed Rate (m/Myr) | Phi-Sed Rate |
|-------------|-----------|------------------|--------------|
| Deep marine | Clay/silt | 10-50 | 8-41 |
| Continental shelf | Sand/silt | 100-1000 | 82-819 |
| Fluvial | Sand/gravel | 1000-10000 | 819-8190 |
| Desert | Sand | 10-100 | 8-82 |
| Glacial | Till | 100-1000 | 82-819 |
| Lacustrine | Clay/silt | 100-5000 | 82-4095 |

### Bedform Dimensions

| Bedform | Height (cm) | Wavelength (cm) | H/L Ratio |
|---------|-------------|-----------------|-----------|
| Ripples | 0.5-2 | 2-20 | 0.1 |
| Dunes | 10-100 | 100-1000 | 0.1 |
| Antidunes | 5-50 | 50-500 | 0.1 |
| Upper stage plane bed | 0 | 0 | 0 |

### Porosity-Depth Relationships

| Depth (m) | Porosity | Porosity,phi | Compaction (%) |
|-----------|----------|--------------|----------------|
| 0 | 0.50 | 0.50 | 0 |
| 100 | 0.40 | 0.38 | 24 |
| 500 | 0.30 | 0.26 | 48 |
| 1000 | 0.25 | 0.19 | 62 |
| 2000 | 0.20 | 0.12 | 76 |
| 5000 | 0.15 | 0.05 | 90 |

### Cement Types

| Cement Type | Formula | Formation T (C) | Phi-T (C) |
|-------------|---------|-----------------|-----------|
| Calcite | CaCO3 | 20-200 | 16-164 |
| Quartz | SiO2 | 100-300 | 82-246 |
| Dolomite | CaMg(CO3)2 | 50-250 | 41-205 |
| Pyrite | FeS2 | 50-300 | 41-246 |
| Hematite | Fe2O3 | 100-400 | 82-328 |
| Gypsum | CaSO4*2H2O | 20-60 | 16-49 |

### Sedimentary Facies Models

| Facies | Environment | Grain Size | Sed Structure |
|--------|-------------|-----------|---------------|
| Facies A | Channel | Gravel/sand | Cross-bedding |
| Facies B | Point bar | Sand | Trough cross-bedding |
| Facies C | Overbank | Silt/clay | Lamination |
| Facies D | Floodplain | Clay | Root traces |
| Facies E | Lake | Clay/silt | Varves |
| Facies F | Delta | Sand/silt | Coarsening upward |

### Compaction Coefficients

| Lithology | c (km^-1) | c_phi (km^-1) | Porosity at 1 km |
|-----------|----------|----------------|------------------|
| Shale | 0.0005 | 0.00041 | 0.30 |
| Sandstone | 0.0002 | 0.00016 | 0.35 |
| Limestone | 0.0001 | 0.00008 | 0.40 |
| Evaporite | 0.00005 | 0.00004 | 0.45 |

### Basin Subsidence Rates

| Basin Type | Rate (mm/yr) | Phi-Rate (mm/yr) | Duration (Myr) |
|------------|--------------|-------------------|----------------|
| Rift | 0.1-1.0 | 0.08-0.82 | 10-50 |
| Post-rift | 0.01-0.1 | 0.008-0.08 | 50-200 |
| Foreland | 0.1-0.5 | 0.08-0.41 | 10-100 |
| Passive margin | 0.01-0.05 | 0.008-0.041 | 100-300 |
| Intracratonic | 0.001-0.01 | 0.0008-0.008 | 300-500 |
