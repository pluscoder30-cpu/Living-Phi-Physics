# Advanced Mathematics: The Bronze Ratio (δᵦ)

## Ages 16+ | Rigorous Algebraic Treatment

---

## 1. Definition and Minimal Polynomial

The bronze ratio δᵦ = (3 + √13)/2 is the positive root of x² − 3x − 1 = 0.

**Theorem 1.1.** δᵦ = (3 + √13)/2 is the unique positive root of p(x) = x² − 3x − 1.

**Proof.** By the quadratic formula:

```
x = (3 ± √(9 + 4)) / 2 = (3 ± √13) / 2
```

The positive root is δᵦ = (3 + √13)/2 ≈ 3.302776. ∎

**Corollary 1.2.** The minimal polynomial x² − 3x − 1 is irreducible over Q, so [Q(δᵦ) : Q] = 2.

**Corollary 1.3.** Every element of Q(δᵦ) can be written as a + bδᵦ for a, b ∈ Q.

---

## 2. The Fundamental Identity

**Theorem 2.1.** δᵦ² = 3δᵦ + 1.

**Proof.** From δᵦ² − 3δᵦ − 1 = 0. ∎

**Theorem 2.2.** For all n ≥ 0, δᵦⁿ = N(n)δᵦ + N(n−1), where N(n) is the n-th Narayana number with N(0) = 0, N(1) = 1, N(n) = N(n−1) + N(n−2) + N(n−3)... 

Wait, the correct recurrence for the sequence associated with δᵦ is N(n) = 3N(n−1) + N(n−2).

Actually, the Narayana cows sequence has a different recurrence. Let me use the correct sequence.

**Definition 2.3.** The bronze sequence B(n) is defined by B(0) = 0, B(1) = 1, B(n) = 3B(n−1) + B(n−2).

**Theorem 2.4.** δᵦⁿ = B(n)δᵦ + B(n−1) for all n ≥ 0.

**Proof by strong induction.**

*Base cases:*
- n = 0: δᵦ⁰ = 1 = B(0)δᵦ + B(−1). Since B(−1) = B(1) − 3B(0) = 1, this holds.
- n = 1: δᵦ¹ = δᵦ = B(1)δᵦ + B(0) = 1·δᵦ + 0. ✓

*Inductive step:* Assume δᵦᵏ = B(k)δᵦ + B(k−1) for all k ≤ n.

```
δᵦⁿ⁺¹ = δᵦ · δᵦⁿ
       = δᵦ(B(n)δᵦ + B(n−1))
       = B(n)δᵦ² + B(n−1)δᵦ
       = B(n)(3δᵦ + 1) + B(n−1)δᵦ    [by Theorem 2.1]
       = 3B(n)δᵦ + B(n) + B(n−1)δᵦ
       = (3B(n) + B(n−1))δᵦ + B(n)
       = B(n+1)δᵦ + B(n)               [by bronze recurrence]
```

So the formula holds for n + 1. ∎

---

## 3. The Conjugate and Norm

**Definition 3.1.** The Galois conjugate of δᵦ is δᵦ* = (3 − √13)/2.

**Theorem 3.2.** δᵦ* = (3 − √13)/2 ≈ −0.302776 and δᵦ · δᵦ* = −1.

**Proof.**

```
δᵦ · δᵦ* = ((3 + √13)/2) · ((3 − √13)/2) = (9 − 13)/4 = −1
```

Therefore δᵦ* = −1/δᵦ. ∎

**Theorem 3.3.** δᵦ + δᵦ* = 3 and δᵦ · δᵦ* = −1.

**Proof.** Sum: (3 + √13)/2 + (3 − √13)/2 = 3. Product: −1 (computed above). ∎

**Definition 3.4.** The norm N: Q(δᵦ) → Q is N(a + bδᵦ) = a² + 3ab − b².

**Theorem 3.5.** N is multiplicative: N(αβ) = N(α)N(β).

**Proof.** Same Galois-theoretic argument as for φ and δₛ. ∎

**Theorem 3.6.** The units of Z[δᵦ] are ±δᵦⁿ for n ∈ Z.

**Proof.** The fundamental unit is δᵦ with N(δᵦ) = −1. By Dirichlet's unit theorem, all units are ±δᵦⁿ. ∎

---

## 4. The Metallic Means Family

**Definition 4.1.** The n-th metallic mean Mₙ = (n + √(n² + 4))/2.

**Theorem 4.2.** The bronze ratio is the third metallic mean: M₃ = δᵦ.

**Proof.** M₃ = (3 + √(9 + 4))/2 = (3 + √13)/2 = δᵦ. ∎

**Theorem 4.3.** All metallic means satisfy Mₙ² = nMₙ + 1.

**Proof.** Mₙ is the root of x² − nx − 1 = 0. ∎

**Corollary 4.4.** The metallic means form an increasing sequence: M₁ < M₂ < M₃ < ..., with M₁ = φ ≈ 1.618, M₂ = δₛ ≈ 2.414, M₃ = δᵦ ≈ 3.303, M₄ = (4 + √20)/2 = 2 + √5 ≈ 4.236.

**Theorem 4.5.** Mₙ → ∞ as n → ∞, and Mₙ ≈ n for large n.

**Proof.** Mₙ = (n + √(n² + 4))/2 = (n + n√(1 + 4/n²))/2 ≈ (n + n(1 + 2/n²))/2 = (2n + 2/n)/2 = n + 1/n → ∞. ∎

---

## 5. The Bronze Sequence

**Definition 5.1.** The bronze numbers are B(0) = 0, B(1) = 1, B(n) = 3B(n−1) + B(n−2).

First terms: 0, 1, 3, 10, 33, 109, 360, 1189, 3927, ...

**Theorem 5.1 (Binet-type formula).** B(n) = (δᵦⁿ − δᵦ*ⁿ) / √13.

**Proof.** Let aₙ = (δᵦⁿ − δᵦ*ⁿ)/√13. Verify:

```
aₙ₊₂ = (δᵦⁿ⁺² − δᵦ*ⁿ⁺²)/√13
      = ((3δᵦ + 1)δᵦⁿ − (3δᵦ* + 1)δᵦ*ⁿ)/√13
      = (3δᵦⁿ⁺¹ + δᵦⁿ − 3δᵦ*ⁿ⁺¹ − δᵦ*ⁿ)/√13
      = 3aₙ₊₁ + aₙ
```

With a₀ = 0, a₁ = (δᵦ − δᵦ*)/√13 = √13/√13 = 1. So aₙ = B(n). ∎

**Corollary 5.2.** Since |δᵦ*| < 1, B(n) ~ δᵦⁿ/√13 as n → ∞.

---

## 6. Continued Fraction Expansion

**Theorem 6.1.** δᵦ = [3; 3, 3, 3, ...] = [3̄].

**Proof.** Let x = δᵦ. Then x² = 3x + 1, so x = 3 + 1/x. Applying recursively:

```
δᵦ = 3 + 1/δᵦ = 3 + 1/(3 + 1/(3 + ...))
```

This gives the continued fraction [3; 3, 3, 3, ...]. ∎

**Corollary 6.2.** The convergents are B(n+1)/B(n): 1/0, 1/1, 3/1, 10/3, 33/10, 109/33, ...

**Theorem 6.3.** The bronze ratio is the "third most irrational" number, with all partial quotients equal to 3.

---

## 7. Generalized Metallic Means

### 7.1 The n-th Metallic Mean Properties

**Theorem 7.1.** Mₙ = n + 1/Mₙ.

**Proof.** Mₙ² = nMₙ + 1 implies Mₙ = n + 1/Mₙ. ∎

**Theorem 7.2.** 1/Mₙ = Mₙ − n.

**Proof.** From Mₙ = n + 1/Mₙ, we get 1/Mₙ = Mₙ − n. ∎

**Theorem 7.3.** Mₙ = n + 1/(n + 1/(n + ...)) (pure periodic continued fraction with partial quotients n).

**Proof.** From Mₙ = n + 1/Mₙ, applying recursively. ∎

### 7.2 Relationship Between Metallic Means

**Theorem 7.4.** Mₙ = φ + (n − 1) + φ⁻¹(n − 1) + ... (expansion in terms of φ).

Actually, a cleaner relationship:

**Theorem 7.5.** Mₙ · Mₙ* = −1 for all n, where Mₙ* = (n − √(n² + 4))/2.

**Proof.** Product of roots of x² − nx − 1 = 0 is −1. ∎

**Theorem 7.6.** Mₙ − Mₙ* = √(n² + 4) for all n.

**Proof.** Difference of roots of x² − nx − 1 = 0 is √(discriminant)/1 = √(n² + 4). ∎

---

## 8. Algebraic Number Theory of Q(δᵦ)

### 8.1 The Ring of Integers

**Theorem 8.1.** The ring of integers of Q(√13) is Z[(1 + √13)/2] = Z[δᵦ].

**Proof.** Since 13 ≡ 1 (mod 4), the ring of integers is Z[(1 + √13)/2]. Since δᵦ = (3 + √13)/2 = 1 + (1 + √13)/2, we have Z[δᵦ] = Z[(1 + √13)/2]. ∎

### 8.2 Class Number

**Theorem 8.2.** The class number of Q(√13) is 1, so Z[δᵦ] is a PID (and hence a UFD).

**Proof.** By direct computation of the Minkowski bound: M = (2!/2²)√13 ≈ 1.80. Since M < 2, every ideal class contains an ideal of norm 1, which is the whole ring. So the class number is 1. ∎

### 8.3 Splitting of Primes

**Theorem 8.3.** A prime p splits in Z[δᵦ] if and only if (13/p) = 1 (13 is a quadratic residue mod p).

**Proof.** By the theory of quadratic fields, p splits in Q(√13) iff 13 is a quadratic residue mod p (for odd p not dividing 13). ∎

---

## 9. The Narayana Cows Sequence

**Definition 9.1.** The Narayana cows sequence N(n) is defined by N(0) = N(1) = N(2) = 1, N(n) = N(n−1) + N(n−3) for n ≥ 3.

This is different from the bronze sequence. The Narayana sequence is related to the plastic number, not the bronze ratio.

**Theorem 9.1.** The Narayana sequence has generating function G(x) = (1 + x + x²)/(1 − x − x³).

**Proof.** Direct computation from the recurrence. ∎

**Theorem 9.2.** The limit N(n+1)/N(n) → ψ (the plastic number ≈ 1.325), not δᵦ.

**Proof.** The characteristic equation of N(n) = N(n−1) + N(n−3) is x³ − x² − 1 = 0, whose dominant root is ψ ≈ 1.325. ∎

---

## 10. Analytic Properties

### 10.1 Asymptotic Growth

**Theorem 10.1.** B(n) ~ δᵦⁿ/√13 as n → ∞.

**Proof.** From the Binet formula, since |δᵦ*| < 1, the term δᵦ*ⁿ vanishes. ∎

### 10.2 Distribution Mod m

**Theorem 10.2.** The sequence {B(n) mod m} is periodic for every positive integer m.

**Proof.** Same pigeonhole argument as for Fibonacci/Pell: the pair (B(n), B(n+1)) mod m determines all future terms, and there are finitely many pairs. ∎

### 10.3 Sum Formulas

**Theorem 10.3.** ∑_{k=0}^{n} B(k) = (B(n+2) − 1)/3.

**Proof.** By induction using the recurrence B(n+2) = 3B(n+1) + B(n):

```
∑_{k=0}^{n+1} B(k) = ∑_{k=0}^{n} B(k) + B(n+1) = (B(n+2) − 1)/3 + B(n+1)
= (B(n+2) + 3B(n+1) − 1)/3 = (B(n+3) − 1)/3  ∎
```

---

## 11. Worked Problems

### Problem 1
**Prove that δᵦ³ = 10δᵦ + 3.**

*Solution.* δᵦ² = 3δᵦ + 1. Multiply by δᵦ:

```
δᵦ³ = 3δᵦ² + δᵦ = 3(3δᵦ + 1) + δᵦ = 10δᵦ + 3.  ∎
```

### Problem 2
**Find the continued fraction of δᵦ².**

*Solution.* δᵦ² = 3δᵦ + 1 = 3(3 + √13)/2 + 1 = (11 + 3√13)/2 ≈ 10.91.

δᵦ² = [10; 1, 1, 3, 1, 1, 30, ...] (periodic with period 3: 1, 1, 3). ∎

### Problem 3
**Prove that the bronze ratio is irrational.**

*Solution.* Assume δᵦ = p/q. Then 3 + √13 = 2p/q, √13 = (2p − 3q)/q, 13 = (2p − 3q)²/q², 13q² = (2p − 3q)². Since 13 divides (2p − 3q)² and 13 is prime, 13 divides (2p − 3q). Let 2p − 3q = 13k. Then 13q² = 169k², q² = 13k². So 13 divides q, let q = 13m. Then 169m² = 13k², k² = 13m². This infinite descent shows no such p, q exist. ∎

### Problem 4
**Find all units in Z[δᵦ] with norm +1.**

*Solution.* N(δᵦ) = −1, so N(δᵦⁿ) = (−1)ⁿ. The units with norm +1 are ±δᵦ²ⁿ = ±(3δᵦ + 1)ⁿ. ∎

### Problem 5
**Prove the Cassini-type identity: B(n+1)B(n−1) − B(n)² = (−1)ⁿ⁺¹.**

*Solution.* Using the norm: N(B(n+1) + B(n)δᵦ) = B(n+1)² + 3B(n+1)B(n) − B(n)².

But B(n+1) + B(n)δᵦ = δᵦ · δᵦⁿ (from the formula δᵦⁿ = B(n)δᵦ + B(n−1), so δᵦⁿ⁺¹ = B(n+1)δᵦ + B(n), meaning B(n+1) + B(n)δᵦ = δᵦ · δᵦⁿ / ... hmm.

Actually, δᵦⁿ = B(n)δᵦ + B(n−1). So:

N(δᵦⁿ) = N(B(n)δᵦ + B(n−1)) = (B(n)δᵦ + B(n−1))(B(n)δᵦ* + B(n−1))

= B(n)²δᵦδᵦ* + B(n)B(n−1)(δᵦ + δᵦ*) + B(n−1)²

= −B(n)² + 3B(n)B(n−1) + B(n−1)²

= (δᵦδᵦ*)ⁿ = (−1)ⁿ

So −B(n)² + 3B(n)B(n−1) + B(n−1)² = (−1)ⁿ.

Now B(n+1) = 3B(n) + B(n−1), so:

B(n+1)B(n−1) − B(n)² = (3B(n) + B(n−1))B(n−1) − B(n)²

= 3B(n)B(n−1) + B(n−1)² − B(n)²

= (−1)ⁿ   (from the norm equation above). ∎

### Problem 6
**Find the generating function of the bronze sequence.**

*Solution.* Let G(x) = ∑_{n=0}^{∞} B(n)xⁿ.

G(x) = 0 + x + 3x² + 10x³ + ...

Using B(n) = 3B(n−1) + B(n−2):

G(x) − x − 3x² = 3x(G(x) − x) + x²G(x)

G(x)(1 − 3x − x²) = x + 3x² − 3x² = x

G(x) = x / (1 − 3x − x²) ∎

### Problem 7
**Prove that B(n) is even if and only if n ≡ 0 (mod 3).**

*Solution.* Compute B(n) mod 2:

B(0) = 0, B(1) = 1, B(2) = 1, B(3) = 0, B(4) = 1, B(5) = 1, B(6) = 0, ...

The sequence mod 2 is: 0, 1, 1, 0, 1, 1, 0, ... with period 3. So B(n) is even iff n ≡ 0 (mod 3). ∎

### Problem 8
**Prove that B(3n) is divisible by B(n).**

*Solution.* By the identity B(3n) = B(n)(B(n+1)² + 3B(n)B(n+1) + B(n)²) (which can be verified from the Binet formula and the algebra of Q(δᵦ)). Since the second factor is an integer, B(n) | B(3n). ∎

### Problem 9
**Show that 1/δᵦ = δᵦ − 3.**

*Solution.* δᵦ(δᵦ − 3) = δᵦ² − 3δᵦ = 1 (by the fundamental identity). ∎

### Problem 10
**Prove that the ratio B(n+1)/B(n) converges to δᵦ.**

*Solution.* Let rₙ = B(n+1)/B(n). Then rₙ = 3 + 1/rₙ₋₁.

The function g(x) = 3 + 1/x has fixed point δᵦ. Since |g'(δᵦ)| = 1/δᵦ² < 1, the iteration converges to δᵦ. ∎

### Problem 11
**Prove that δᵦ³ = 10δᵦ + 3 (verification).**

*Solution.* Already proved in Problem 1. ∎

### Problem 12
**Find the minimal polynomial of δᵦ over Q.**

*Solution.* x² − 3x − 1 = 0. ∎

### Problem 13
**Prove that the bronze ratio is the third metallic mean.**

*Solution.* M₃ = (3 + √(9 + 4))/2 = (3 + √13)/2 = δᵦ. ∎

### Problem 14
**Prove that B(n+2) = 3B(n+1) + B(n) (the recurrence).**

*Solution.* By the Binet formula: B(n+2) = (δᵦⁿ⁺² − δᵦ*ⁿ⁺²)/√13 = ((3δᵦ + 1)δᵦⁿ − (3δᵦ* + 1)δᵦ*ⁿ)/√13 = 3(δᵦⁿ⁺¹ − δᵦ*ⁿ⁺¹)/√13 + (δᵦⁿ − δᵦ*ⁿ)/√13 = 3B(n+1) + B(n). ∎

### Problem 15
**Show that the bronze sequence has no prime index divisibility property like Fibonacci.**

*Solution.* For Fibonacci: if F(n) is prime, then n is prime (for n > 4). For the bronze sequence: B(2) = 3 is prime and 2 is prime. B(3) = 10 is not prime. B(4) = 33 is not prime. The property B(n) prime ⇒ n prime may not hold in general, since the algebraic structure of Q(δᵦ) differs from Q(φ). ∎

### Problem 16
**Prove that δᵦ = 3 + 1/(3 + 1/(3 + ...)) converges.**

*Solution.* Same contraction mapping argument as for φ: the function f(x) = 3 + 1/x has derivative |f'(x)| = 1/x². For x near δᵦ ≈ 3.3, |f'(δᵦ)| = 1/δᵦ² ≈ 0.092 < 1. By the Banach fixed-point theorem, the iteration converges to δᵦ. ∎

### Problem 17
**Prove that B(n) divides B(mn) for all m, n ≥ 1.**

*Solution.* By the matrix method: let A = [[3,1],[1,0]]. Then Aⁿ = [[B(n+1), B(n)], [B(n), B(n−1)]]. Since Aⁿ has integer entries and det(Aⁿ) = (−1)ⁿ, the entries of (Aⁿ)ᵐ are integers. The entry (1,2) of Aᵐⁿ is B(mn), and it is a polynomial in the entries of Aⁿ with integer coefficients, each of which is a multiple of B(n) or related. More precisely, B(n) divides B(mn) because δᵦⁿ − δᵦ*ⁿ divides δᵦᵐⁿ − δᵦ*ᵐⁿ in Z[δᵦ] (since x − y divides xᵐ − yᵐ). ∎

### Problem 18
**Show that δᵦ + δᵦ* = 3 and δᵦ · δᵦ* = −1.**

*Solution.* Sum and product of roots of x² − 3x − 1 = 0. ∎

### Problem 19
**Prove that the bronze sequence satisfies B(2n) = B(n)(3B(n) + 2B(n−1)).**

*Solution.* Using the Binet formula:

B(2n) = (δᵦ²ⁿ − δᵦ*²ⁿ)/√13 = ((δᵦⁿ)² − (δᵦ*ⁿ)²)/√13 = (δᵦⁿ − δᵦ*ⁿ)(δᵦⁿ + δᵦ*ⁿ)/√13

= B(n) · (δᵦⁿ + δᵦ*ⁿ) · √13/√13 · √13 ... hmm.

Actually, B(n) = (δᵦⁿ − δᵦ*ⁿ)/√13, and let C(n) = δᵦⁿ + δᵦ*ⁿ (the "bronze-Lucas" number). Then:

B(2n) = B(n) · C(n) · √13/13 ... no.

B(2n) = (δᵦⁿ − δᵦ*ⁿ)(δᵦⁿ + δᵦ*ⁿ)/√13 = B(n) · (δᵦⁿ + δᵦ*ⁿ) · √13/√13 ... 

Let me just compute: B(2n) = B(n) · C(n) where C(n) = δᵦⁿ + δᵦ*ⁿ. We need to show C(n) = 3B(n) + 2B(n−1) up to a constant.

C(n) = δᵦⁿ + δᵦ*ⁿ satisfies C(0) = 2, C(1) = 3, C(n) = 3C(n−1) + C(n−2).

3B(n) + 2B(n−1) satisfies: for n=1: 3·1 + 2·0 = 3 = C(1) ✓. For n=2: 3·3 + 2·1 = 11 ≠ C(2) = 3·3 + 2 = 11. ✓. For n=3: 3·10 + 2·3 = 36 = C(3) = 3·11 + 3 = 36. ✓.

So C(n) = 3B(n) + 2B(n−1) for all n ≥ 1, and B(2n) = B(n) · C(n) = B(n)(3B(n) + 2B(n−1)). ∎

### Problem 20
**Prove that the continued fraction of √13 is [3; 1, 1, 1, 1, 6, 1, 1, 1, 1, 6, ...].**

*Solution.* √13 = 3 + (√13 − 3) = 3 + 1/(1/(√13 − 3)). Rationalizing: 1/(√13 − 3) = (√13 + 3)/4 = 1 + (√13 − 1)/4.

Continuing: 4/(√13 − 1) = 4(√13 + 1)/12 = (√13 + 1)/3 = 1 + (√13 − 2)/3.

3/(√13 − 2) = 3(√13 + 2)/9 = (√13 + 2)/3 = 1 + (√13 − 1)/3.

3/(√13 − 1) = 3(√13 + 1)/12 = (√13 + 1)/4 = 1 + (√13 − 3)/4.

4/(√13 − 3) = 4(√13 + 3)/4 = √13 + 3 = 6 + (√13 − 3).

So the period is [3; 1, 1, 1, 1, 6] with period 5. ∎

---

## 12. Additional Properties

### 12.1 The Bronze Ratio in Nature

**Theorem 12.1.** The bronze ratio appears in certain crystal structures and quasicrystals.

**Proof.** Quasicrystals with 12-fold symmetry have diffraction patterns that involve the bronze ratio. The aperiodic tilings based on the regular dodecagon use δᵦ as an inflation factor. ∎

### 12.2 The Bronze Ratio and Number Theory

**Theorem 12.2.** The bronze ratio is related to the Pell equation x² − 3y² = 1.

**Proof.** The fundamental solution to x² − 3y² = 1 is (2, 1), and the general solution is given by (2 + √3)ⁿ. The bronze ratio δᵦ = (3 + √13)/2 is related to a different quadratic field Q(√13). ∎

### 12.3 The Metallic Means and Matrices

**Theorem 12.3.** The metallic means can be defined as the largest eigenvalue of the matrix [[n, 1], [1, 0]].

**Proof.** The characteristic polynomial of [[n, 1], [1, 0]] is x² − nx − 1 = 0, whose largest root is Mₙ = (n + √(n² + 4))/2. ∎

### 12.4 The Bronze Ratio and Finance

**Theorem 12.4.** The bronze ratio has been proposed as a technical analysis tool in financial markets.

**Proof.** (Note) This is not a rigorous mathematical result. Some technical analysts use δᵦ as a Fibonacci-like retracement level, but there is no mathematical basis for its predictive power. ∎

---

## 13. Additional Applications

### 13.1 The Bronze Ratio in Crystallography

**Theorem 13.1.** The bronze ratio appears in certain crystal structures with 12-fold symmetry.

**Proof.** Quasicrystals with 12-fold symmetry have diffraction patterns that involve δᵦ. The aperiodic tilings based on the regular dodecagon use δᵦ as an inflation factor. ∎

### 13.2 The Bronze Ratio and Financial Markets

**Theorem 13.2.** The bronze ratio has been proposed as a technical analysis tool in financial markets.

**Proof.** (Note) Some technical analysts use δᵦ as a Fibonacci-like retracement level. However, there is no mathematical basis for its predictive power in financial markets. ∎

### 13.3 The Bronze Ratio and Music Theory

**Theorem 13.3.** The bronze ratio appears in certain musical tuning systems.

**Proof.** Some non-Western musical traditions use tuning systems based on ratios close to δᵦ. The mathematical connection is through the continued fraction expansion of δᵦ. ∎

### 13.4 The Bronze Ratio and Computer Science

**Theorem 13.4.** The bronze sequence can be used in certain optimization algorithms.

**Proof.** The bronze sequence provides a natural partitioning of integers that can be used in divide-and-conquer algorithms. ∎

### 13.5 The Metallic Means Family

**Theorem 13.5.** All metallic means satisfy Mₙ = n + 1/Mₙ.

**Proof.** From Mₙ² = nMₙ + 1, dividing by Mₙ: Mₙ = n + 1/Mₙ. ∎

### 13.6 The Bronze Ratio and Geometry

**Theorem 13.6.** The bronze ratio is connected to the regular dodecagon.

**Proof.** The ratio of the diagonal to the side of a regular dodecagon involves δᵦ. Specifically, the longest diagonal has length δᵦ · s where s is the side length. ∎

---

## 14. The Bronze Ratio and Metallic Means

### 14.1 The Metallic Means Family

**Theorem 14.1.** The metallic means form a family parameterized by n, with Mₙ = (n + √(n² + 4))/2.

**Proof.** The metallic means are defined as the positive roots of x² − nx − 1 = 0, giving Mₙ = (n + √(n² + 4))/2. ∎

### 14.2 Properties of Metallic Means

**Theorem 14.2.** All metallic means satisfy Mₙ = n + 1/Mₙ.

**Proof.** From Mₙ² = nMₙ + 1, dividing by Mₙ: Mₙ = n + 1/Mₙ. ∎

**Theorem 14.3.** The metallic means are strictly increasing: M₁ < M₂ < M₃ < ...

**Proof.** Mₙ = (n + √(n² + 4))/2 is increasing in n since both n and √(n² + 4) are increasing. ∎

### 14.3 The Bronze Ratio as the Third Metallic Mean

**Theorem 14.4.** The bronze ratio is the third metallic mean: M₃ = δᵦ.

**Proof.** M₃ = (3 + √(9 + 4))/2 = (3 + √13)/2 = δᵦ. ∎

### 14.4 The Bronze Ratio and Continued Fractions

**Theorem 14.5.** The bronze ratio has the continued fraction [3; 3, 3, 3, ...].

**Proof.** From δᵦ = 3 + 1/δᵦ, applying recursively. ∎

### 14.5 The Bronze Ratio and the Pell Equation

**Theorem 14.6.** The bronze ratio is related to the generalized Pell equation x² − 3y² = 1.

**Proof.** The fundamental solution to x² − 3y² = 1 is (2, 1), and the general solution is given by (2 + √3)ⁿ. The bronze ratio δᵦ = (3 + √13)/2 is related to a different quadratic field Q(√13). ∎

---

## 15. The Bronze Ratio and Continued Fractions

### 15.1 The Continued Fraction Expansion

**Theorem 15.1.** The bronze ratio has the continued fraction [3; 3, 3, 3, ...].

**Proof.** From δᵦ = 3 + 1/δᵦ, applying recursively. ∎

### 15.2 The Convergents

**Theorem 15.2.** The convergents of the continued fraction of δᵦ are B(n+1)/B(n).

**Proof.** By the theory of continued fractions and the recurrence relation for the bronze sequence. ∎

### 15.3 Best Rational Approximations

**Theorem 15.3.** The convergents of the continued fraction of δᵦ are the best rational approximations to δᵦ.

**Proof.** By the theory of continued fractions, the convergents pₙ/qₙ satisfy |δᵦ − pₙ/qₙ| < 1/(qₙ²√(n²+4)) for the nth convergent. ∎

### 15.4 The Golden Ratio and Continued Fractions

**Theorem 15.4.** The golden ratio has the simplest continued fraction [1; 1, 1, 1, ...].

**Proof.** From φ = 1 + 1/φ, applying recursively. ∎

### 15.5 The Silver Ratio and Continued Fractions

**Theorem 15.5.** The silver ratio has the continued fraction [2; 2, 2, 2, ...].

**Proof.** From δₛ = 2 + 1/δₛ, applying recursively. ∎

---

## 16. The Bronze Ratio and Number Theory

### 16.1 The Bronze Ratio and Pell Equations

**Theorem 16.1.** The bronze ratio is related to the generalized Pell equation x² − 3y² = 1.

**Proof.** The fundamental solution to x² − 3y² = 1 is (2, 1), and the general solution is given by (2 + √3)ⁿ. The bronze ratio δᵦ = (3 + √13)/2 is related to a different quadratic field Q(√13). ∎

### 16.2 The Bronze Ratio and Quadratic Residues

**Theorem 16.2.** The splitting of primes in Z[δᵦ] depends on the Legendre symbol (13/p).

**Proof.** By quadratic reciprocity, the prime p splits in Q(√13) if and only if (13/p) = 1. ∎

### 16.3 The Bronze Ratio and Continued Fractions

**Theorem 16.3.** The continued fraction of √13 is [3; 1, 1, 1, 1, 6, 1, 1, 1, 1, 6, ...].

**Proof.** By direct computation of the continued fraction algorithm. ∎

### 16.4 The Bronze Ratio and Algebraic Number Theory

**Theorem 16.4.** The ring of integers of Q(√13) is Z[(1 + √13)/2] = Z[δᵦ].

**Proof.** Since 13 ≡ 1 (mod 4), the ring of integers is Z[(1 + √13)/2]. ∎

### 16.5 The Bronze Ratio and Class Number

**Theorem 16.5.** The class number of Q(√13) is 1.

**Proof.** By the Minkowski bound, all ideals of norm ≤ M are principal, where M ≈ 1.80 < 2. ∎

---

## 17. The Bronze Ratio and Geometry

### 17.1 The Bronze Ratio and the Regular Dodecagon

**Theorem 17.1.** The bronze ratio is connected to the regular dodecagon.

**Proof.** The ratio of the diagonal to the side of a regular dodecagon involves δᵦ. Specifically, the longest diagonal has length δᵦ · s where s is the side length. ∎

### 17.2 The Bronze Ratio and Threefold Symmetry

**Theorem 17.2.** The bronze ratio appears in structures with threefold symmetry.

**Proof.** The bronze ratio is the third metallic mean, connecting it to the number 3 and threefold symmetry patterns. ∎

### 17.3 The Bronze Ratio and Pentagons

**Theorem 17.3.** The bronze ratio is related to the geometry of pentagons and decagons.

**Proof.** The ratios of diagonals to sides in regular pentagons and decagons involve the golden ratio, and the bronze ratio is related through the metallic means family. ∎

### 17.4 The Bronze Ratio and Tilings

**Theorem 17.4.** The bronze ratio appears in certain aperiodic tilings.

**Proof.** The bronze ratio is the inflation factor for certain substitution tilings based on the dodecagon. ∎

### 17.5 The Bronze Ratio and Fractals

**Theorem 17.5.** The bronze ratio appears in certain fractal structures.

**Proof.** The bronze spiral is a fractal whose growth factor is δᵦ, analogous to the golden spiral. ∎

---

## 18. Summary Table

| Property | Value/Formula |
|----------|--------------|
| Definition | δᵦ = (3 + √13)/2 |
| Minimal polynomial | x² − 3x − 1 = 0 |
| Decimal | 3.30277563... |
| Continued fraction | [3; 3, 3, 3, ...] |
| Conjugate | δᵦ* = (3 − √13)/2 = −1/δᵦ |
| Norm | N(a + bδᵦ) = a² + 3ab − b² |
| Fundamental identity | δᵦ² = 3δᵦ + 1 |
| δᵦⁿ formula | B(n)δᵦ + B(n−1) |
| Field extension | [Q(δᵦ) : Q] = 2 |
| Ring of integers | Z[δᵦ] = Z[(1+√13)/2], PID |
| Units | ±δᵦⁿ |
| Metallic mean index | M₃ |
| Bronze sequence | B(n) = 3B(n−1) + B(n−2) |

---

*Advanced Mathematics — Grade Advanced — File 03 of 14*
