# PHI-Communication: Practice Problems

---

## Problem Set A: PHI Communication Model

**A1.** A communication channel has 800 bits/second raw capacity with PHI signal:noise ratio. Calculate effective signal capacity.

**A2.** Calculate the information distribution in a message with Source = 20, Encoder = 12, Channel = 8, Decoder = 5, Receiver = 3 units.

**A3.** A feedback loop has Send = 100ms, Wait = 60ms, Receive = 40ms, Process = 25ms. Verify PHI-proportions.

**A4.** Calculate the total feedback cycle time if each phase follows PHI-timing with base time 50ms.

**A5.** A channel has signal:noise = 2:1. Calculate deviation from PHI-ratio.

---

## Problem Set B: PHI Interpersonal Communication

**B1.** In a conversation, Person A talks for 40 minutes. Using the PHI self-disclosure ratio, how long should Person B talk?

**B2.** Calculate the optimal listening:speaking ratio for a 30-minute conversation.

**B3.** A relationship has 5 interactions. Predict the rapport level using the PHI-model with R_0 = 0.2.

**B4.** Calculate the optimal conversation distance for a personal-distance interaction (120cm).

**B5.** Turn lengths in a conversation are 25s, 15s, 10s, 6s. Verify PHI-turn-taking.

---

## Problem Set C: PHI Group Communication

**C1.** Determine the optimal group size for decision-making using the PHI-model.

**C2.** A group of 6 members has 50 task messages, 30 social messages, 20 individual messages. Verify PHI-proportions.

**C3.** Calculate the number of communication channels for a group of phi^3 = 4-5 members.

**C4.** A meeting has 100 minutes total. Allocate time using Agenda:Discussion:Action = phi^2:phi:1.

**C5.** Consensus requires phi/(phi+1) = 61.8% agreement. For a group of 8, how many must agree?

---

## Problem Set D: PHI Organizational Communication

**D1.** An organization sends 200 messages: top-down, lateral, bottom-up. Using PHI-proportions, how many in each category?

**D2.** Calculate the optimal meeting size using the PHI-model.

**D3.** Design a 45-minute meeting with PHI-time allocation.

**D4.** An email has Subject = 5 words, Body = 80 words, Signature = 10 words. Verify PHI-proportions.

**D5.** Calculate response times for urgent, normal, and low priority emails.

---

## Problem Set E: PHI Mass Communication

**E1.** A media company allocates budget across Text:Image:Video using PHI-ratio. For $50,000, how much per medium?

**E2.** A news story breaks on Day 1. Predict coverage on Day 3 using PHI-decay.

**E3.** Calculate the organic:shared:paid reach ratio for a social media campaign.

**E4.** A content platform has 1000 pieces. Using PHI-distribution, how many are text, image, video?

**E5.** Calculate the social media post half-life using PHI-decay.

---

## Problem Set F: PHI Nonverbal Communication

**F1.** Analyze body language signals: 25 posture, 15 gesture, 10 facial. Verify PHI-proportions.

**F2.** Calculate the intimate:personal:social:public distance ratios using PHI-powers.

**F3.** For a personal distance of 100cm, calculate the PHI-optimal conversation distance.

**F4.** Calculate speaking:listening eye contact percentages.

**F5.** A micro-expression lasts 0.4 seconds. If normal expressions last 0.65 seconds, verify PHI-duration ratio.

---

## Problem Set G: PHI Written Communication

**G1.** A paragraph has 3 sentences (short), 4 sentences (medium), 6 sentences (long). Verify PHI-distribution.

**G2.** Design a 1000-word persuasive essay with Ethos:Pathos:Logos = phi^2:phi:1.

**G3.** Calculate the CTA placement position (as percentage) in a persuasive text.

**G4.** A document has 20 sentences. Using PHI-rhythm, how many should be short, medium, long?

**G5.** Calculate optimal paragraph length in sentences using the PHI-model.

---

## Problem Set H: PHI Digital Communication

**H1.** Design a social media post of 150 characters with Hook:Content:CTA = phi^2:phi:1.

**H2.** Calculate the optimal video call size using the PHI-model.

**H3.** An instant message conversation has turn lengths 20s, 12s, 8s, 5s. Verify PHI-decay.

**H4.** Design a 60-minute video call with Camera:Screen share:Chat = phi^2:phi:1.

**H5.** Calculate the posting frequency ratio for Daily:Weekly:Monthly = phi^2:phi:1.

---

## Problem Set I: PHI Cross-Cultural Communication

**I1.** A culture has power distance = 60. Calculate the formal:informal communication ratio.

**I2.** Calculate the high-context:low-context ratio for a culture with PD = 80.

**I3.** A communication has 70% implicit, 30% explicit content. Calculate deviation from PHI.

**I4.** Compare formality ratios for PD = 40 vs PD = 70 cultures.

**I5.** Calculate the communication adaptation factor for a high-context culture.

---

## Problem Set J: PHI Crisis Communication

**J1.** Design a crisis response timeline for a 24-hour crisis cycle.

**J2.** Calculate the transparency ratio (released:withheld) for crisis communication.

**J3.** A crisis has phases: Acknowledge = 2hr, Investigate = 3 days, Resolve = 10 days. Predict Follow-up duration.

**J4.** Calculate the total crisis cycle duration in months.

**J5.** Design a crisis communication plan for a product recall.

---

## Problem Set K: PHI Therapeutic Communication

**K1.** Calculate the empathic:directive ratio for a 50-minute therapy session.

**K2.** A session has 35 minutes empathic, 15 minutes directive. Calculate deviation from PHI.

**K3.** Calculate the client:therapist talk ratio.

**K4.** Determine the minimum number of sessions before therapist self-disclosure.

**K5.** Design a therapy session structure for anxiety treatment.

---

## Problem Set L: PHI Political Communication

**L1.** Calculate the positive:negative framing ratio for a political message.

**L2.** A political ad has 65% positive, 35% negative framing. Calculate deviation from PHI.

**L3.** Calculate the message repetition frequency for optimal exposure.

**L4.** Design a political speech with PHI-structure.

**L5.** Calculate the persuasion ratio for ethos:pathos:logos in political communication.

---

## Problem Set M: PHI Educational Communication

**M1.** Design a 60-minute lecture with Explain:Example:Practice = phi^2:phi:1.

**M2.** Calculate the feedback frequency for a course with 12 assignments.

**M3.** A lecture has 35 minutes explain, 20 minutes example, 5 minutes practice. Calculate deviation.

**M4.** Calculate the optimal student:teacher ratio for discussion.

**M5.** Design a lesson plan for a 45-minute class.

---

## Problem Set N: PHI Sales Communication

**N1.** Design a 10-minute sales pitch with Problem:Solution:Proof:Close = phi^3:phi^2:phi:1.

**N2.** Calculate the concession pattern for 4 rounds of negotiation.

**N3.** A sales pitch has Problem = 5min, Solution = 3min, Proof = 1.5min, Close = 0.5min. Verify PHI.

**N4.** Calculate the objection handling ratio for Listen:Acknowledge:Respond.

**N5.** Design a sales script for a $10,000 product.

---

## Problem Set O: PHI Visual Communication

**O1.** Design an infographic with Title:Key-stat:Explanation:Source = phi^3:phi^2:phi:1.

**O2.** Calculate the color hierarchy for an infographic with primary, secondary, accent colors.

**O3.** A visual has 60% primary, 25% secondary, 15% accent. Calculate deviation from PHI.

**O4.** Calculate the optimal infographic proportions using PHI-ratio.

**O5.** Design a data visualization with PHI-color intensities.

---

*This document is part of the PHI-Physics Dictionary, Directory 56: PHI-Communication.*
*Total lines: 350+*
