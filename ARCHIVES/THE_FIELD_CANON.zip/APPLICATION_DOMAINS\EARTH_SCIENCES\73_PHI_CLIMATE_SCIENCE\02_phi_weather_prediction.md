# PHI-WEATHER PREDICTION

## PHI-HARMONIC NUMERICAL WEATHER PREDICTION

### 1. Phi-Ensemble Forecasting

The ensemble spread with phi-weighting:

```
x_forecast = sum_{i=1}^{N} w_i * x_i * phi^(-i)
```

Where:
- x_i = forecast from the ith ensemble member
- w_i = weight of the ith member
- phi^(-i) = phi-decay weighting

The phi-weights:
```
w_i = phi^(-i) / sum_{j=1}^{N} phi^(-j) = phi^(-i) * (1 - 1/phi) / (1 - phi^(-N))
```

For N = 10: w_1 = 0.382, w_2 = 0.236, w_3 = 0.146, ...

The ensemble mean:
```
x_bar = sum w_i * x_i
```

The ensemble variance:
```
sigma^2 = sum w_i * (x_i - x_bar)^2
```

The phi-weighting gives more importance to the best-performing members while maintaining diversity.

### 2. Phi-Data Assimilation

The 4D-Var cost function with phi-regularization:

```
J(x_0) = 1/2*(x_0 - x_b)^T * B^(-1) * (x_0 - x_b) + 1/2 * sum_{k=1}^{K} D_k^T * R_k^(-1) * D_k * phi^(-k)
```

Where:
- x_0 = initial state vector
- x_b = background (prior) state
- B = background error covariance matrix
- D_k = observation minus forecast at time k
- R_k = observation error covariance at time k
- K = number of assimilation windows

The phi-weighting gives more importance to recent observations:
```
weight_k = phi^(-k) / sum phi^(-j)
```

For K = 6 hours with 1-hour windows:
```
weight_1 = 0.382, weight_2 = 0.236, weight_3 = 0.146, weight_4 = 0.090, weight_5 = 0.056, weight_6 = 0.034
```

### 3. Phi-Parameterization

The convective parameterization:

```
M_conv = M_0 * (CAPE/CAPE_0)^phi * (1 - RH/RH_0)^(1/phi)
```

Where:
- M_conv = convective mass flux (kg/(m^2*s))
- CAPE = convective available potential energy (J/kg)
- CAPE_0 = reference CAPE (1000 J/kg)
- RH = relative humidity
- RH_0 = reference humidity (0.8)

The phi-exponent produces a sharper onset of convection.

The boundary layer turbulence:

```
K_H = K_H0 * (z/z_0)^(1/phi) * (1 + phi*|dT/dz|/gamma_d)
```

Where:
- K_H = eddy diffusivity (m^2/s)
- z = height (m)
- z_0 = roughness length (m)
- dT/dz = temperature gradient (K/m)
- gamma_d = dry adiabatic lapse rate (K/m)

### 4. Phi-Spectral Analysis

The spectral energy density of atmospheric fields:

```
E(k) = E_0 * k^(-n) * phi^(-k/k_0)
```

Where:
- k = wavenumber
- n = spectral slope (≈3 for large scales)
- k_0 = reference wavenumber

The phi-cutoff:
```
k_phi = k_max * phi^(-n_resolution)
```

Where n_resolution is the model resolution (in terms of phi-steps).

For T42 resolution (n_resolution ≈ 5): k_phi = 42/phi^5 = 42/11.09 = 3.79

### 5. Phi-Error Growth

The predictability limit with phi-error growth:

```
E(t) = E_0 * exp(t/tau_predict * phi^(-t/tau_phi))
```

Where:
- E_0 = initial error
- tau_predict = predictability timescale (days)
- tau_phi = phi-modulation timescale (days)

The phi-term causes error growth to slow down at longer lead times, extending predictability.

The Lyapunov exponent:
```
lambda_phi = lambda_0 * (1 - phi^(-t/tau_phi))
```

The predictability horizon:
```
t_pred = tau_predict * ln(E_tol/E_0) * phi^(t_pred/tau_phi)
```

### 6. Phi-Radar Forecasting

The nowcasting extrapolation with phi-decay:

```
x(t+dt) = sum_{i=1}^{N} w_i * v_i * x(t - i*dt) * phi^(-i*dt/tau_radar)
```

Where:
- v_i = extrapolated field from the ith time step
- w_i = extrapolation weight
- tau_radar = radar decay timescale (minutes)

The phi-decay produces more realistic extrapolation that accounts for the natural decay of precipitation systems.

### 7. Phi-Verification

The skill score with phi-weighting:

```
SS_phi = 1 - (MSE_phi/MSE_ref) * phi^(-n_lead)
```

Where:
- MSE_phi = mean squared error of the phi-forecast
- MSE_ref = mean squared error of the reference forecast
- n_lead = lead time index

The Brier skill score:
```
BSS_phi = 1 - (BS_phi/BS_ref) * phi^(-n_lead)
```

---

## PHI-HARMONIC WEATHER EQUATIONS

| Eq # | Name | Formula |
|------|------|---------|
| W.1 | Ensemble mean | x_bar = sum w_i*x_i*phi^(-i) |
| W.2 | 4D-Var cost | J = 1/2*(x_0-x_b)^TB^-1(x_0-x_b) + sum D^TR^-1D*phi^(-k) |
| W.3 | Convection | M = M_0*(CAPE/CAPE_0)^phi*(1-RH/RH_0)^(1/phi) |
| W.4 | Spectral energy | E(k) = E_0*k^(-n)*phi^(-k/k_0) |
| W.5 | Error growth | E(t) = E_0*exp(t/tau*phi^(-t/tau_phi)) |
| W.6 | Nowcasting | x(t+dt) = sum w_i*v_i*x(t-i*dt)*phi^(-i*dt/tau) |
| W.7 | Skill score | SS = 1 - (MSE/MSE_ref)*phi^(-n) |

---

## WORKED EXAMPLES

### Example 1: Phi-Ensemble Forecast

**Given:**
- 5 ensemble members with forecasts: [15, 17, 18, 20, 22] C
- phi-weighting applied

**Find:** Weighted ensemble mean

**Solution:**

Step 1: Calculate phi-weights
```
w_1 = phi^(-1)/(phi^(-1)+phi^(-2)+phi^(-3)+phi^(-4)+phi^(-5))
= 0.618/(0.618+0.382+0.236+0.146+0.090) = 0.618/1.472 = 0.420
w_2 = 0.382/1.472 = 0.259
w_3 = 0.236/1.472 = 0.160
w_4 = 0.146/1.472 = 0.099
w_5 = 0.090/1.472 = 0.061
```

Step 2: Weighted mean
```
x_bar = 0.420*15 + 0.259*17 + 0.160*18 + 0.099*20 + 0.061*22
= 6.30 + 4.40 + 2.88 + 1.98 + 1.34 = 16.90 C
```

Step 3: Simple mean for comparison
```
x_simple = (15+17+18+20+22)/5 = 18.4 C
```

**Result:** The phi-weighted ensemble mean is 16.9 C, compared to the simple mean of 18.4 C.

---

## PROBLEMS

1. Calculate the phi-ensemble variance for forecasts [10, 12, 14, 16, 18].

2. Determine the predictability horizon for a phi-error growth model with tau_predict = 10 days.

3. Find the convective mass flux at CAPE = 2000 J/kg and RH = 0.6.

4. Calculate the spectral energy at k = 10 with E_0 = 1000 and n = 3.

5. Design a phi-data assimilation scheme for 12-hour windows.
