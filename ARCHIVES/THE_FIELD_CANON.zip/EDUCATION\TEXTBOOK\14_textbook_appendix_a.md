# Appendix A: Formula Reference Sheet

## Every Formula in the Textbook, Organized by Chapter

---

## Chapter 1: The Golden Ratio (Phi)

| Formula | Description |
|---------|-------------|
| phi = (1 + sqrt(5))/2 | Definition of the golden ratio |
| phi ≈ 1.6180339887 | Numerical value |
| phi^2 = phi + 1 | Fundamental property |
| 1/phi = phi - 1 | Reciprocal property |
| 1/phi ≈ 0.6180339887 | Numerical value of reciprocal |
| phi^n = phi^(n-1) + phi^(n-2) | Recursive property of powers |
| phi^n = F(n) x phi + F(n-1) | Connection to Fibonacci numbers |
| Golden angle = 360°/phi^2 ≈ 137.5° | Angle used in phyllotaxis |
| r = a x phi^(2 theta/pi) | Equation of the golden spiral |

---

## Chapter 2: The Silver Ratio

| Formula | Description |
|---------|-------------|
| delta = 1 + sqrt(2) | Definition of the silver ratio |
| delta ≈ 2.4142135623 | Numerical value |
| delta^2 = 2 x delta + 1 | Fundamental property |
| 1/delta = delta - 2 | Reciprocal property |
| M(n) = (n + sqrt(n^2 + 4))/2 | General metallic ratio |
| P(n) = 2P(n-1) + P(n-2) | Pell sequence recurrence |
| r = a x delta^(2 theta/pi) | Silver spiral equation |

---

## Chapter 3: The Bronze Ratio

| Formula | Description |
|---------|-------------|
| B = (3 + sqrt(13))/2 | Definition of the bronze ratio |
| B ≈ 3.3027756377 | Numerical value |
| B^2 = 3B + 1 | Fundamental property |
| 1/B = B - 3 | Reciprocal property |
| a(n) = na(n-1) + a(n-2) | General metallic sequence |
| r = a x B^(2 theta/pi) | Bronze spiral equation |

---

## Chapter 4: Harmonic Mathematics

| Formula | Description |
|---------|-------------|
| H(n) = sum(1/k, k=1 to n) | nth harmonic number |
| H(n) ≈ ln(n) + gamma | Approximation |
| gamma ≈ 0.5772156649 | Euler-Mascheroni constant |
| f = f0 x 2^(n/12) | Equal temperament frequency |
| Overtones: f, 2f, 3f, 4f, ... | Harmonic series in music |
| Perfect fifth ratio = 3/2 | Musical interval |
| Perfect fourth ratio = 4/3 | Musical interval |
| Major third ratio = 5/4 | Musical interval |

---

## Chapter 5: Fibonacci and Lucas Numbers

| Formula | Description |
|---------|-------------|
| F(0)=0, F(1)=1, F(n)=F(n-1)+F(n-2) | Fibonacci recurrence |
| L(0)=2, L(1)=1, L(n)=L(n-1)+L(n-2) | Lucas recurrence |
| F(n) = (phi^n - psi^n)/sqrt(5) | Binet's formula (Fibonacci) |
| L(n) = phi^n + psi^n | Binet's formula (Lucas) |
| psi = (1 - sqrt(5))/2 | Conjugate of phi |
| L(n) = F(n-1) + F(n+1) | Lucas-Fibonacci identity |
| F(n)^2 + F(n+1)^2 = F(2n+1) | Sum of squares identity |
| F(n-1)F(n+1) - F(n)^2 = (-1)^n | Cassini's identity |
| gcd(F(m), F(n)) = F(gcd(m,n)) | GCD property |

---

## Chapter 6: Plastic and Supergolden Ratios

| Formula | Description |
|---------|-------------|
| rho^3 = rho + 1 | Plastic number equation |
| rho ≈ 1.3247179572 | Plastic number value |
| psi^3 = psi^2 + 1 | Supergolden ratio equation |
| psi ≈ 1.4655712318 | Supergolden ratio value |
| P(n) = P(n-2) + P(n-3) | Padovan recurrence |
| N(n) = N(n-1) + N(n-3) | Narayana cows recurrence |
| rho = cube_root((9+sqrt(69))/18) + cube_root((9-sqrt(69))/18) | Closed form for rho |

---

## Chapter 7: Padovan and Kepler Ratios

| Formula | Description |
|---------|-------------|
| P(n) = P(n-2) + P(n-3) | Padovan recurrence |
| Kepler triangle sides: 1, sqrt(phi), phi | Kepler triangle ratio |
| Kepler triangle: 1 + phi = phi^2 | Pythagorean verification |
| Padovan spiral: triangles with sides P(n) | Padovan spiral construction |

---

## Chapter 8: Living Mathematics

| Formula | Description |
|---------|-------------|
| Golden angle = 360°/phi^2 ≈ 137.5077° | Phyllotaxis angle |
| Phyllotaxis fractions: 1/2, 1/3, 2/5, 3/8, 5/13, ... | Fibonacci fraction approximations |
| r = a x b^(theta/2pi) | General logarithmic spiral |
| r = a x phi^(2 theta/pi) | Golden spiral |

---

## Chapter 9: Phi-Statistics and Phi-Geometry

| Formula | Description |
|---------|-------------|
| Pentagon diagonal = phi x side | Golden ratio in pentagon |
| Golden ratio search: interval shrinks by 1/phi | Optimization algorithm |
| Icosahedron: vertex distance = phi x edge | Golden ratio in 3D |
| Dodecahedron: face distance = phi^2 x edge | Golden ratio in 3D |

---

## Chapter 10: Phi-Chemistry and Phi-Physics

| Formula | Description |
|---------|-------------|
| alpha ≈ 1/137 | Fine structure constant |
| phi^5 ≈ 11.090 | Fifth power of golden ratio |
| Fibonacci anyon states = F(n-1) | Quantum states count |
| DNA: 34A / 20A ≈ 1.7 | DNA proportions |

---

## Chapter 11: Phi-Biology and Phi-Medicine

| Formula | Description |
|---------|-------------|
| DNA pitch/width ≈ 1.7 ≈ phi | DNA double helix |
| Alpha waves: 13/8 = 1.625 ≈ phi | Brain wave ratios |
| Liver length/width ≈ phi | Organ proportions |

---

## Chapter 12: Phi-Economics and Phi-Computer Science

| Formula | Description |
|---------|-------------|
| Retracement 61.8% = 1/phi | Fibonacci trading |
| Extension 161.8% = phi | Fibonacci extension |
| Golden search: shrinks by 1/phi | Optimization algorithm |
| x_{n+1} = (phi x x_n) mod 1 | Pseudorandom generator |
| Fibonacci heap degree = O(log n) | Data structure bound |

---

## General Metallic Ratios

| n | Name | Formula | Value |
|---|------|---------|-------|
| 1 | Golden | (1 + sqrt(5))/2 | 1.6180339887 |
| 2 | Silver | 1 + sqrt(2) | 2.4142135623 |
| 3 | Bronze | (3 + sqrt(13))/2 | 3.3027756377 |
| 4 | Copper | 2 + sqrt(5) | 4.2360679774 |
| 5 | Nickel | (5 + sqrt(29))/2 | 5.1925824035 |

---

## Common Approximations

| Constant | Value | Approximation |
|----------|-------|---------------|
| phi | 1.6180339887 | 1.618 |
| 1/phi | 0.6180339887 | 0.618 |
| phi^2 | 2.6180339887 | 2.618 |
| phi^3 | 4.2360679774 | 4.236 |
| phi^4 | 6.8541019661 | 6.854 |
| phi^5 | 11.0901699437 | 11.090 |
| sqrt(phi) | 1.2720196495 | 1.272 |
| 1/sqrt(phi) | 0.7861513778 | 0.786 |

---

## Trigonometric Values

| Function | Value | Description |
|----------|-------|-------------|
| cos(36°) | (1+sqrt(5))/4 = phi/2 | Related to pentagon |
| sin(36°) | sqrt(10-2sqrt(5))/4 | Pentagon geometry |
| cos(72°) | (sqrt(5)-1)/4 = 1/(2phi) | Pentagon geometry |
| sin(72°) | sqrt(10+2sqrt(5))/4 | Pentagon geometry |
| cos(108°) | -(sqrt(5)-1)/4 | Pentagon geometry |
| tan(36°) | sqrt(5-2sqrt(5)) | Pentagon geometry |
| cos(137.5°) | -1/(2phi) | Golden angle |

---

## Important Sequences

| Sequence | Recurrence | First Terms | Limit Ratio |
|----------|-----------|-------------|-------------|
| Fibonacci | F(n) = F(n-1) + F(n-2) | 0,1,1,2,3,5,8,13,... | phi |
| Lucas | L(n) = L(n-1) + L(n-2) | 2,1,3,4,7,11,18,... | phi |
| Pell | P(n) = 2P(n-1) + P(n-2) | 0,1,2,5,12,29,... | delta |
| Padovan | Pa(n) = Pa(n-2) + Pa(n-3) | 1,1,1,2,2,3,4,5,... | rho |
| Narayana | N(n) = N(n-1) + N(n-3) | 1,1,1,2,3,4,6,9,... | psi |
| Perrin | Pe(n) = Pe(n-2) + Pe(n-3) | 3,0,2,3,2,5,5,7,... | rho |
| Bronze | Br(n) = 3Br(n-1) + Br(n-2) | 0,1,3,10,33,109,... | B |

---

## Geometric Properties

| Shape | Golden Ratio Connection |
|-------|------------------------|
| Regular pentagon | Diagonal = phi x side |
| Regular decagon | Radius = phi x side |
| Golden rectangle | Length = phi x width |
| Golden triangle | Sides in ratio phi:1:phi |
| Kepler triangle | Sides: 1, sqrt(phi), phi |
| Icosahedron | Vertex distance = phi x edge |
| Dodecahedron | Face distance = phi^2 x edge |
| Penrose tiling | Thick/thin ratio approaches phi |

---

## Musical Intervals

| Interval | Ratio | Cents | Example |
|----------|-------|-------|---------|
| Unison | 1:1 | 0 | C to C |
| Minor second | 16:15 | 112 | C to D-flat |
| Major second | 9:8 | 204 | C to D |
| Minor third | 6:5 | 316 | C to E-flat |
| Major third | 5:4 | 386 | C to E |
| Perfect fourth | 4:3 | 498 | C to F |
| Tritone | 45:32 | 600 | C to F-sharp |
| Perfect fifth | 3:2 | 702 | C to G |
| Minor sixth | 8:5 | 814 | C to A-flat |
| Major sixth | 5:3 | 884 | C to A |
| Minor seventh | 9:5 | 1018 | C to B-flat |
| Major seventh | 15:8 | 1088 | C to B |
| Octave | 2:1 | 1200 | C to C |

---

## Unit Conversions

| Quantity | Value |
|----------|-------|
| 1 degree | pi/180 radians |
| 1 radian | 180/pi degrees |
| Golden angle | 137.5077... degrees = 2.3999... radians |
| Silver angle | 360/delta^2 = 61.7284... degrees |
| Plastic angle | 360/rho^2 = 205.1443... degrees |

---

## Constants of Nature Related to Phi

| Constant | Value | Relation to Phi |
|----------|-------|-----------------|
| Fine structure constant | alpha ≈ 1/137.036 | Approximate: 1/phi^5 ≈ 0.090 |
| Proton-electron mass ratio | mp/me ≈ 1836.15 | Approximate: phi^16 ≈ 2207 |
| Cosmological constant | Lambda ≈ 10^-122 | Speculative relation to phi |
| Planck constant | h = 6.626 x 10^-34 Js | No direct relation |

---

*End of Appendix A*
