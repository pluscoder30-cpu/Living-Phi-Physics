# PHI-Hull Design: Golden Ratio Naval Architecture

## PHI-HULL-001: PHI-Hull Geometry

### 1.1 PHI-Lines Plan

The PHI-hull lines follow φ-harmonic curves:

```
y_hull(x) = (B/2) * [1 - (x/L)^phi]^(1/phi) * [1 + (1/phi) * sin(phi * x/L)]
```

where:
- B = maximum beam
- L = waterline length
- x = longitudinal position

### 1.2 PHI-Prismatic Coefficient

The PHI-prismatic coefficient:

```
Cp_phi = Cp_0 * [1 + (1/phi^2) * (Fn/Fn_ref)^phi]
```

where:
- Cp_0 = baseline prismatic coefficient
- Fn = Froude number

### 1.3 PHI-Block Coefficient

The PHI-block coefficient:

```
Cb_phi = Cb_0 * [1 + (1/phi) * (L/B)^(-1/phi)]
```

### 1.4 PHI-Midship Coefficient

The PHI-midship coefficient:

```
Cm_phi = Cm_0 * [1 + (1/phi^2) * (B/T)^phi]
```

### 1.5 PHI-Waterplane Coefficient

The PHI-waterplane coefficient:

```
Cwp_phi = Cwp_0 * [1 + (1/phi) * (L/B)^(1/phi)]
```

### 1.6 PHI-Longitudinal Prismatic Distribution

The PHI-longitudinal distribution:

```
Cp(x) = Cp_0 * [1 + (1/phi) * cos(phi * x/L)] * (1/phi)^(x/L)
```

### 1.7 PHI-Hull Surface Parametrization

The PHI-hull surface:

```
S(x,y,z) = S_base + SUM A_n * phi_n(x,y,z) * (1/phi)^n
```

## PHI-HULL-002: PHI-Hydrostatics

### 2.1 PHI-Displacement

The PHI-displacement:

```
Delta_phi = rho * g * L * B * T * Cb_phi * [1 + (1/phi^2) * (trim)^phi]
```

### 2.2 PHI-Vertical Center of Buoyancy

The PHI-VCB:

```
VCB_phi = T * Cb_phi * [1 + (1/phi) * (T/L)^phi]
```

### 2.3 PHI-Metacentric Height

The PHI-GM:

```
GM_phi = I_wp/V - VCG * [1 + (1/phi^2) * (heel_angle/heel_ref)^phi]
```

### 2.4 PHI-Righting Arm

The PHI-GZ curve:

```
GZ_phi = sin(heel) * [BM * cos(heel) + KM * sin(heel)] * [1 + (1/phi) * cos(phi * heel)]
```

### 2.5 PHI-Trim

The PHI-trim moment:

```
M_trim = Delta * g * L * (LCB - LCF) * [1 + (1/phi^2) * (trim)^phi]
```

### 2.6 PHI-Buoyancy Distribution

The PHI-buoyancy:

```
b(x) = rho * g * A_waterline(x) * [1 + (1/phi) * cos(phi * x/L)]
```

### 2.7 PHI-Waterline Area

The PHI-waterline area:

```
A_wp = L * B * Cwp_phi * [1 + (1/phi) * (L/B)^(-1/phi)]
```

## PHI-HULL-003: PHI-Hydrodynamic Resistance

### 3.1 PHI-Frictional Resistance

The PHI-frictional resistance:

```
Rf_phi = 0.5 * rho * V^2 * S_wet * Cf_phi
Cf_phi = 0.075 / (log10(Re) - 2)^2 * [1 + (1/phi) * sin(phi * Re/Re_ref)]
```

### 3.2 PHI-Residuary Resistance

The PHI-residuary resistance:

```
Rr_phi = Rr_0 * [1 + (1/phi^2) * (Fn/Fn_ref)^phi] * (1/phi)^(Fn/Fn_ref)
```

### 3.3 PHI-Wave-Making Resistance

The PHI-wave resistance:

```
Rw_phi = Rw_0 * [1 + (1/phi) * sin(phi * Fn)] * (1/phi)^(Fn^2)
```

### 3.4 PHI-Air Resistance

The PHI-air resistance:

```
Ra_phi = 0.5 * rho_air * V^2 * A_front * Cd_phi
Cd_phi = Cd_0 * [1 + (1/phi) * (V_wind/V_ship)^phi]
```

### 3.5 PHI-Momentum Thickness

The PHI-momentum thickness:

```
theta_phi = theta_0 * [1 + (1/phi) * (x/L)^(1/phi)]
```

### 3.6 PHI-Wave Profile

The PHI-wave profile along hull:

```
z_wave(x) = z_0 * [1 + (1/phi) * sin(phi * x/L)] * (1/phi)^(x/L)
```

### 3.7 PHI-Total Resistance

The PHI-total resistance:

```
Rt_phi = Rf_phi + Rr_phi + Ra_phi + Rappendage * [1 + (1/phi^2) * (Fn)^phi]
```

## PHI-HULL-004: PHI-Ship Powering

### 4.1 PHI-Effective Power

The PHI-effective power:

```
Pe_phi = Rt_phi * V * [1 + (1/phi) * sin(phi * Fn)]
```

### 4.2 PHI-Propulsive Coefficient

The PHI-propulsive coefficient:

```
PC_phi = eta_h * eta_o * eta_r * eta_s * phi * [1 + (1/phi^2) * (J/J_opt)^phi]
```

### 4.3 PHI-Brake Power

The PHI-brake power:

```
Pb_phi = Pe_phi / PC_phi * [1 + (1/phi) * (load_factor)^phi]
```

### 4.4 PHI-Specific Fuel Consumption

The PHI-SFC:

```
SFC_phi = SFC_0 * (1/phi) * [1 + (1/phi^2) * (load/load_ref)^phi]
```

### 4.5 PHI-Speed-Power Relationship

The PHI-speed-power:

```
P = P_ref * (V/V_ref)^phi * [1 + (1/phi) * (Fn)^phi]
```

### 4.6 PHI-Hull Efficiency

The PHI-hull efficiency:

```
eta_h_phi = (1-t)/(1-w) * [1 + (1/phi) * (Fn/Fn_ref)^phi]
```

### 4.7 PHI-Appendage Power

The PHI-appendage power:

```
P_appendage = P_bare * (1/phi) * [1 + (1/phi^2) * (A_appendage/A_ref)^phi]
```

## PHI-HULL-005: PHI-Ship Maneuvering

### 5.1 PHI-Turning Circle

The PHI-turning diameter:

```
D_turn_phi = D_turn_0 * (1/phi) * [1 + (1/phi^2) * (delta_r/delta_max)^phi]
```

### 5.2 PHI-Tactical Diameter

The PHI-tactical diameter:

```
TD_phi = TD_0 * (1/phi) * [1 + (1/phi) * (L/B)^phi]
```

### 5.3 PHI-Advance

The PHI-advance:

```
Advance_phi = Advance_0 * (1/phi) * [1 + (1/phi^2) * (rudder_angle)^phi]
```

### 5.4 PHI-Tactical Transfer

The PHI-transfer:

```
Transfer_phi = Transfer_0 * (1/phi) * [1 + (1/phi^2) * (speed/V_ref)^phi]
```

### 5.5 PHI-Stop Distance

The PHI-panic stop:

```
Stop_phi = Stop_0 * phi * [1 + (1/phi^2) * (V/V_ref)^phi]
```

### 5.6 PHI-Course Keeping

The PHI-course keeping:

```
Error_heading = Error_0 * (1/phi) * [1 + (1/phi^2) * (current/Wind)^phi]
```

### 5.7 PHI-Zig-Zag Maneuver

The PHI-zig-zag:

```
Overshoot_phi = Overshoot_0 * (1/phi) * [1 + (1/phi^2) * (rudder_overshoot)^phi]
```

## PHI-HULL-006: PHI-Seakeeping

### 6.1 PHI-Motion Response

The PHI-motion:

```
Response = Response_0 * [1 + (1/phi) * sin(phi * omega * t)] * (1/phi)^(|omega - omega_n|)
```

### 6.2 PHI-Roll Damping

The PHI-roll damping:

```
B_roll = B_0 * phi * [1 + (1/phi^2) * (omega/omega_n)^phi]
```

### 6.3 PHI-Pitch Response

The PHI-pitch:

```
Pitch_response = Pitch_0 * [1 + (1/phi) * sin(phi * omega_e * t)] * (1/phi)^(|omega_e - omega_pitch|)
```

### 6.4 PHI-Heave Response

The PHI-heave:

```
Heave_response = Heave_0 * [1 + (1/phi) * cos(phi * omega_e * t)] * (1/phi)^(|omega_e - omega_heave|)
```

### 6.5 PHI-Added Resistance

The PHI-added resistance in waves:

```
Raw_phi = Raw_0 * [1 + (1/phi^2) * (H_s/H_ref)^phi] * (1/phi)^(Fn/Fn_ref)
```

### 6.6 PHI-Cargo Shifting

The PHI-cargo force:

```
F_cargo = m_cargo * a_response * [1 + (1/phi) * sin(phi * omega * t)]
```

### 6.7 PHI-Deck Wetness

The PHI-deck wetness probability:

```
P_wet = 1 - exp(-(z_deck/H_s)^phi * [1 + (1/phi) * cos(phi * omega_e * t)])
```

## PHI-HULL-007: PHI-Hull Structural Design

### 7.1 PHI-Hull Girder Strength

The PHI-bending moment:

```
M_hull = M_sagging * [1 + (1/phi) * sin(phi * x/L)] + M_hogging * [1 + (1/phi) * cos(phi * x/L)]
```

### 7.2 PHI-Plate Buckling

The PHI-plate critical buckling:

```
sigma_cr_plate = (pi^2 * k_c * D) / (b^2 * t) * phi * [1 + (1/phi^2) * (a/b)^phi]
```

### 7.3 PHI-Stiffener Spacing

The PHI-stiffener spacing:

```
s_phi = s_0 * (1/phi) * [1 + (1/phi^2) * (pressure/pressure_ref)^phi]
```

### 7.4 PHI-Midship Section

The PHI-midship modulus:

```
Z_mid = Z_0 * phi * [1 + (1/phi^2) * (sigma_allow/sigma_ref)^phi]
```

### 7.5 PHI-Torsional Rigidity

The PHI-torsion:

```
J_hull = J_0 * phi * [1 + (1/phi^2) * (L/B)^phi]
```

### 7.6 PHI-Hull Vibration

The PHI-hull natural frequency:

```
fn_hull = fn_0 * phi * [1 + (1/phi^2) * (m_loaded/m_light)^(-phi)]
```

### 7.7 PHI-Fatigue Assessment

The PHI-fatigue life:

```
N_fatigue = N_0 * phi^2 * [1 + (1/phi) * (stress_range/stress_ref)^(-phi)]
```

## PHI-HULL-008: PHI-Hull Optimization

### 8.1 PHI-Hull Form Optimization

The PHI-optimization:

```
J_opt = J_cost * (1/phi) + J_performance * phi + J_environment * phi^2
```

### 8.2 PHI-CFD Optimization

The PHI-CFD:

```
Resistance = Resistance_0 * (1/phi) * [1 + (1/phi^2) * (mesh/mesh_ref)^phi]
```

### 8.3 PHI-Tank Testing

The PHI-tank test correlation:

```
Correction = Correction_0 * [1 + (1/phi) * (Re/Re_ref)^phi]
```

### 8.4 PHI-Parametric Hull

The PHI-parametric:

```
Hull = Hull_base + SUM delta_i * N_i(x,y,z) * (1/phi)^i
```

### 8.5 PHI-Shape Optimization

The PHI-shape:

```
Shape_opt = Shape_0 + delta_shape * [1 + (1/phi) * sin(phi * x/L)]
```

### 8.6 PHI-Multi-Objective Hull

The PHI-Pareto:

```
min R(phi) * phi^2
min Cost(phi) * phi
subject to constraints
```

### 8.7 PHI-Validation

The PHI-validation:

```
Error = Error_CFD - Error_tank * [1 + (1/phi) * (Fn/Fn_ref)^phi]
```

## PHI-HULL-009: PHI-Hull Materials

### 9.1 PHI-Steel Hull

The PHI-steel yield strength:

```
sigma_y_phi = sigma_y_0 * phi * [1 + (1/phi^2) * (T/T_ref)^(-phi)]
```

### 9.2 PHI-Aluminum Hull

The PHI-aluminum:

```
sigma_al_phi = sigma_0 * [1 + (1/phi) * (temp/temp_ref)^phi]
```

### 9.3 PHI-Composite Hull

The PHI-composite:

```
E_composite = E_0 * phi * [1 + (1/phi^2) * (V_f/V_f_ref)^phi]
```

### 9.4 PHI-Wood Hull

The PHI-wood:

```
sigma_wood = sigma_0 * [1 + (1/phi) * (moisture/moisture_ref)^(-phi)]
```

### 9.5 PHI-Corrosion Allowance

The PHI-corrosion:

```
t_corrosion = t_0 * (1/phi) * [1 + (1/phi^2) * (seawater/seawater_ref)^phi]
```

### 9.6 PHI-Anti-Fouling

The PHI-anti-fouling:

```
Roughness = Roughness_0 * (1/phi) * [1 + (1/phi^2) * (time/time_ref)^phi]
```

### 9.7 PHI-Fire Protection

The PHI-fire rating:

```
Rating = Rating_0 * phi * [1 + (1/phi^2) * (hazard/hazard_ref)^phi]
```

## PHI-HULL-010: PHI-Hull Manufacturing

### 10.1 PHI-Plate Rolling

The PHI-plate:

```
Curvature = Curvature_0 * [1 + (1/phi) * sin(phi * x/L)]
```

### 10.2 PHI-Welding

The PHI-weld quality:

```
Quality = Quality_0 * phi * [1 + (1/phi^2) * (welder_skill)^phi]
```

### 10.3 PHI-Fairing

The PHI-fairing:

```
Deviation = Deviation_0 * (1/phi) * [1 + (1/phi^2) * (panel_size)^phi]
```

### 10.4 PHI-Coating

The PHI-coating thickness:

```
t_coat = t_0 * [1 + (1/phi) * sin(phi * x/L)] * (1/phi)^(corrosion_severity)
```

### 10.5 PHI-Block Construction

The PHI-block:

```
Block_weight = Block_0 * [1 + (1/phi^2) * (complexity)^phi]
```

### 10.6 PHI-Dry Docking

The PHI-dry docking:

```
Cost_drydock = Cost_0 * phi * [1 + (1/phi^2) * (hull_condition)^phi]
```

### 10.7 PHI-Launch

The PHI-launch:

```
Speed_launch = sqrt(2 * g * d) * [1 + (1/phi) * sin(phi * t/tau)]
```

## PHI-HULL-011: PHI-Hull Maintenance

### 11.1 PHI-Condition Assessment

The PHI-condition:

```
Condition = Condition_0 * (1/phi) * [1 + (1/phi^2) * (age/age_ref)^phi]
```

### 11.2 PHI-Inspection

The PHI-inspection:

```
Detection = Detection_0 * phi * [1 + (1/phi^2) * (method_quality)^phi]
```

### 11.3 PHI-Repair

The PHI-repair:

```
Cost_repair = Cost_0 * phi * [1 + (1/phi^2) * (damage_severity)^phi]
```

### 11.4 PHI-Life Extension

The PHI-life extension:

```
Life_extended = Life_0 * phi * [1 + (1/phi^2) * (upgrade_level)^phi]
```

### 11.5 PHI-Scrap

The PHI-scrap value:

```
Value_scrap = Value_0 * (1/phi) * [1 + (1/phi^2) * (steel_weight)^phi]
```

### 11.6 PHI-Recycling

The PHI-recycling:

```
Recycling = Recycling_0 * phi * [1 + (1/phi^2) * (recyclability)^phi]
```

### 11.7 PHI-Environmental Compliance

The PHI-compliance:

```
Compliance = Compliance_0 * phi * [1 + (1/phi^2) * (regulation_stringency)^phi]
```

## PHI-HULL-012: PHI-Hull Research Frontiers

### 12.1 PHI-Air Lubrication

The PHI-air lubrication:

```
R_lubricated = R_bare * (1/phi) * [1 + (1/phi^2) * (air_flow)^phi]
```

### 12.2 PHI-Appendage Design

The PHI-appendage:

```
Cd_appendage = Cd_0 * (1/phi) * [1 + (1/phi^2) * (Re/Re_ref)^phi]
```

### 12.3 PHI-Bulbous Bow

The PHI-bulb:

```
R_bulb = R_bare * (1 - 1/phi) * [1 + (1/phi) * sin(phi * Fn)]
```

### 12.4 PHI-Stern Optimization

The PHI-stern:

```
W_stern = W_0 * [1 + (1/phi) * cos(phi * x/L)] * (1/phi)^(Fn/Fn_ref)
```

### 12.5 PHI-Hull-Propeller Interaction

The PHI-hull-prop:

```
eta_interaction = eta_0 * phi * [1 + (1/phi^2) * (tip_clearance/tip_ref)^phi]
```

### 12.6 PHI-Wave-Body Interaction

The PHI-wave-body:

```
F_wave = F_0 * [1 + (1/phi) * sin(phi * omega * t)] * (1/phi)^(x/L)
```

### 12.7 PHI-Fluid-Structure Interaction

The PHI-FSI:

```
Displacement = Displacement_0 * [1 + (1/phi) * sin(phi * omega * t)] * (1/phi)^(stiffness/stiffness_ref)
```

### 12.8 PHI-Cavitating Hull

The PHI-cavitation:

```
sigma_cav = sigma_0 * [1 + (1/phi) * (V/V_ref)^phi] * (1/phi)^(depth/depth_ref)
```

### 12.9 PHI-Ice Hull

The PHI-ice:

```
Force_ice = F_0 * phi * [1 + (1/phi^2) * (ice_thickness/ice_ref)^phi]
```

### 12.10 PHI-Autonomous Hull Design

The PHI-AI hull:

```
Hull_optimal = Hull_base + SUM delta_i * phi_i(x,y,z) * (1/phi)^i * confidence_i
```
