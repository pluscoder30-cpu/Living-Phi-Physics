# 04 — The Harmonic Ratio | Intermediate Level

## Ages 13–16 | Music Theory & Mathematics

---

## 1. Definition

The harmonic ratio relates to the harmonic series and musical intervals.
The most fundamental harmonic ratio is:

```
H = 2^(1/12) ≈ 1.0594630943...
```

This is the ratio between consecutive semitones in equal temperament tuning.

A full octave has ratio 2:1. Dividing it into 12 equal semitones gives each
semitone a ratio of 2^(1/12).

---

## 2. Algebraic Proof: The Octave and Semitone

**Claim:** (2^(1/12))¹² = 2

**Proof:**

```
(2^(1/12))¹² = 2^(12/12) = 2¹ = 2  ✓
```

This is the fundamental identity of equal temperament: 12 semitones make an octave.

**General identity:** (2^(1/n))ⁿ = 2 for any positive integer n.

---

## 3. Musical Intervals as Ratios

| Interval | Semitones | Ratio | Decimal |
|----------|-----------|-------|---------|
| Unison | 0 | 1:1 | 1.000 |
| Minor 2nd | 1 | 2^(1/12) | 1.059 |
| Major 2nd | 2 | 2^(2/12) | 1.122 |
| Minor 3rd | 3 | 2^(3/12) | 1.189 |
| Major 3rd | 4 | 2^(4/12) | 1.260 |
| Perfect 4th | 5 | 2^(5/12) | 1.335 |
| Tritone | 6 | 2^(6/12) | 1.414 |
| Perfect 5th | 7 | 2^(7/12) | 1.498 |
| Minor 6th | 8 | 2^(8/12) | 1.587 |
| Major 6th | 9 | 2^(9/12) | 1.682 |
| Minor 7th | 10 | 2^(10/12) | 1.782 |
| Major 7th | 11 | 2^(11/12) | 1.888 |
| Octave | 12 | 2^(12/12) | 2.000 |

---

## 4. Pythagorean Tuning vs Equal Temperament

**Pythagorean tuning** uses the ratio 3:2 (perfect fifth) as its foundation:

```
Perfect fifth: 3/2 = 1.500
Perfect fourth: 4/3 = 1.333...
Major third: 5/4 = 1.250
Minor third: 6/5 = 1.200
```

**Equal temperament** approximates these with powers of 2^(1/12):

```
Perfect fifth: 2^(7/12) ≈ 1.498  (vs 1.500 exact)
Major third: 2^(4/12) ≈ 1.260   (vs 1.250 exact)
```

The "error" in equal temperament is small but audible to trained ears.

---

## 5. The Harmonic Series

When a string vibrates, it produces not just one frequency but a series:

```
Fundamental: f
2nd harmonic: 2f (octave)
3rd harmonic: 3f (octave + fifth)
4th harmonic: 4f (2 octaves)
5th harmonic: 5f (2 octaves + major third)
6th harmonic: 6f (2 octaves + fifth)
...
```

The ratios between consecutive harmonics are:

```
2/1, 3/2, 4/3, 5/4, 6/5, 7/6, 8/7, ...
```

These are the **harmonic ratios**: H(n) = (n+1)/n.

---

## 6. Properties of Harmonic Ratios H(n) = (n+1)/n

**Theorem:** H(n) → 1 as n → ∞.

**Proof:**

```
H(n) = (n+1)/n = 1 + 1/n

As n → ∞: 1/n → 0, so H(n) → 1  ✓
```

This means higher harmonics are closer together in pitch.

---

## 7. The Tritone: 2^(6/12) = √2

The tritone (half an octave) has ratio:

```
2^(6/12) = 2^(1/2) = √2 ≈ 1.414213...
```

This connects music theory to the silver ratio family (since δₛ = 1 + √2).

In Pythagorean tuning, the tritone is (3/2)² / 2 = 9/8, which is ≈ 1.125.
The equal temperament version (√2 ≈ 1.414) is quite different, which is why
the tritone sounds "out of tune" in Pythagorean systems.

---

## 8. Consonance and Frequency Ratios

The most consonant intervals have simple ratios:

```
Octave:     2:1  = 2.000  (most consonant after unison)
Fifth:      3:2  = 1.500
Fourth:     4:3  = 1.333
Major 3rd:  5:4  = 1.250
Minor 3rd:  6:5  = 1.200
```

The simpler the ratio, the more consonant the interval. This is because the
waveforms align more frequently.

---

## 9. Worked Problems

### Problem 1: Find the ratio of a perfect fifth

**Question:** What is the frequency ratio of a perfect fifth in equal temperament?

**Solution:**

```
Perfect fifth = 7 semitones
Ratio = 2^(7/12)
     ≈ 1.498307
```

Compare to the Pythagorean ratio 3/2 = 1.500.

---

### Problem 2: Semitone calculation

**Question:** If concert A is 440 Hz, what is the frequency of the note a major
third above it?

**Solution:**

```
Major third = 4 semitones
Ratio = 2^(4/12) = 2^(1/3) ≈ 1.2599

Frequency = 440 × 2^(1/3)
          ≈ 440 × 1.2599
          ≈ 554.4 Hz
```

This is approximately C#5.

---

### Problem 3: Octave equivalence

**Question:** If a note has frequency f, what frequency is one octave higher?

**Solution:**

```
One octave = 12 semitones
Ratio = 2^(12/12) = 2¹ = 2

If f = 440 Hz (A4), one octave up is 880 Hz (A5).
One octave down is 220 Hz (A3).
```

---

### Problem 4: Harmonic series ratios

**Question:** Find the ratio between the 3rd and 2nd harmonics.

**Solution:**

```
3rd harmonic: 3f
2nd harmonic: 2f

Ratio = 3f / 2f = 3/2 = 1.500

This is the perfect fifth.
```

---

### Problem 5: How many semitones in a tritone?

**Question:** The tritone has ratio √2. How many semitones is this?

**Solution:**

```
2^(n/12) = √2 = 2^(1/2)

n/12 = 1/2
n = 6 semitones
```

---

### Problem 6: Frequency of the 5th harmonic

**Question:** If the fundamental is 200 Hz, what is the frequency of the 5th
harmonic?

**Solution:**

```
5th harmonic = 5 × 200 = 1000 Hz

In musical terms: 1000/200 = 5, which is:
- 2 octaves above (ratio 4:1)
- Plus a major third (ratio 5:4)

So the 5th harmonic is 2 octaves + a major third above the fundamental.
```

---

### Problem 7: Equal temperament vs just intonation

**Question:** Compare the equal temperament major third (2^(4/12)) with the
just intonation major third (5/4).

**Solution:**

```
Equal temperament: 2^(1/3) ≈ 1.259921
Just intonation: 5/4 = 1.250000

Difference: 1.259921 − 1.250000 = 0.000921

Percentage difference: 0.000921 / 1.250 ≈ 0.074%
```

The difference is about 14 cents (1 cent = 1/100 of a semitone).

---

### Problem 8: The harmonic mean

**Question:** The harmonic mean of two numbers a and b is 2ab/(a+b). Find the
harmonic mean of the frequencies 440 Hz and 880 Hz.

**Solution:**

```
Harmonic mean = 2(440)(880) / (440 + 880)
              = 774400 / 1320
              = 586.67 Hz

Geometric mean = √(440 × 880) = √387200 ≈ 622.25 Hz
Arithmetic mean = (440 + 880)/2 = 660 Hz
```

The harmonic mean (586.67) is less than the geometric mean (622.25),
which is less than the arithmetic mean (660). This is always true for
positive numbers.

---

### Problem 9: Number of octaves in a frequency range

**Question:** How many octaves separate 100 Hz and 10,000 Hz?

**Solution:**

```
Number of octaves = log₂(10000/100)
                  = log₂(100)
                  = log(100) / log(2)
                  = 2 / 0.30103
                  ≈ 6.644 octaves
```

---

### Problem 10: Constructing a major scale

**Question:** Starting from C4 = 261.63 Hz, compute the frequencies of the
notes in the C major scale.

**Solution:**

```
C4: 261.63 Hz                    (unison)
D4: 261.63 × 2^(2/12) ≈ 293.66  (major 2nd)
E4: 261.63 × 2^(4/12) ≈ 329.63  (major 3rd)
F4: 261.63 × 2^(5/12) ≈ 349.23  (perfect 4th)
G4: 261.63 × 2^(7/12) ≈ 392.00  (perfect 5th)
A4: 261.63 × 2^(9/12) ≈ 440.00  (major 6th)
B4: 261.63 × 2^(11/12) ≈ 493.88 (major 7th)
C5: 261.63 × 2^(12/12) ≈ 523.25 (octave)
```

---

### Problem 11: The diminished fifth

**Question:** What is the ratio of a diminished fifth (6 semitones) in equal
temperament?

**Solution:**

```
Diminished fifth = 6 semitones
Ratio = 2^(6/12) = 2^(1/2) = √2 ≈ 1.4142

This is the tritone, also known as the "devil's interval" in medieval music.
```

---

### Problem 12: Frequency ratios in chords

**Question:** A major chord consists of a root, major third, and perfect fifth.
If the root is 330 Hz, what are the other two frequencies?

**Solution:**

```
Root: 330 Hz (E4)
Major third: 330 × 2^(4/12) ≈ 330 × 1.260 ≈ 415.8 Hz (G#4)
Perfect fifth: 330 × 2^(7/12) ≈ 330 × 1.498 ≈ 494.4 Hz (B4)
```

---

### Problem 13: The equal temperament cent

**Question:** One cent is 1/100 of a semitone. How many cents separate the equal
temperament fifth from the Pythagorean fifth?

**Solution:**

```
Equal temperament fifth: 2^(7/12) ≈ 1.498307
Pythagorean fifth: 3/2 = 1.500000

Difference in ratio: 1.500000 / 1.498307 ≈ 1.001130

Difference in cents: 1200 × log₂(1.001130)
                   = 1200 × 0.001630
                   ≈ 1.955 cents ≈ 2 cents
```

The Pythagorean fifth is about 2 cents sharper than the equal temperament fifth.

---

### Problem 14: Harmonic series and musical pitch

**Question:** The fundamental frequency is 110 Hz (A2). Find the frequencies of
the first 8 harmonics and identify which musical notes they correspond to.

**Solution:**

```
Harmonic 1: 110 Hz     = A2
Harmonic 2: 220 Hz     = A3 (octave)
Harmonic 3: 330 Hz     = E4 (octave + fifth)
Harmonic 4: 440 Hz     = A4 (2 octaves)
Harmonic 5: 550 Hz     ≈ C#5 (2 octaves + major third)
Harmonic 6: 660 Hz     = E5 (2 octaves + fifth)
Harmonic 7: 770 Hz     ≈ G5 (2 octaves + minor seventh)
Harmonic 8: 880 Hz     = A5 (3 octaves)
```

---

### Problem 15: The Fibonacci connection

**Question:** The ratios of consecutive Fibonacci numbers approximate φ. Do
consecutive harmonic ratios also converge?

**Solution:**

```
Harmonic ratios: H(n) = (n+1)/n

H(1) = 2/1 = 2.000
H(2) = 3/2 = 1.500
H(3) = 4/3 = 1.333
H(4) = 5/4 = 1.250
H(5) = 6/5 = 1.200
H(6) = 7/6 = 1.167

The ratios H(n) converge to 1, not to a constant like φ.

But the PRODUCT of consecutive ratios:
H(1) × H(2) × ... × H(n) = (n+1)/1 = n+1

This grows without bound.
```

The harmonic series diverges: 1 + 1/2 + 1/3 + 1/4 + ... = ∞.

---

## 10. Summary Table

| Property | Value |
|----------|-------|
| Semitone ratio | 2^(1/12) ≈ 1.05946 |
| Octave ratio | 2:1 |
| Perfect fifth | 3:2 (Pythagorean) or 2^(7/12) (ET) |
| Major third | 5:4 (just) or 2^(4/12) (ET) |
| Tritone | √2 ≈ 1.414 |
| Harmonic series | f, 2f, 3f, 4f, ... |
| Harmonic ratio | H(n) = (n+1)/n → 1 |
| Equal temperament | 12-TET, 100 cents/semitone |

---

## 11. Key Takeaways for Ages 13–16

1. **Equal temperament divides the octave** into 12 equal semitones using 2^(1/12).
2. **Musical intervals are frequency ratios:** Simple ratios sound consonant.
3. **The harmonic series** produces all notes from a single vibrating string.
4. **Equal temperament is a compromise:** It's slightly out of tune but allows
   playing in all keys.
5. **The tritone = √2:** Connects music theory to the silver ratio family.
6. **Consonance correlates with simple ratios:** 2:1, 3:2, 4:3 are the most consonant.

---

*Next: 05_intermediate_living.md — Living Mathematics*
