# PHI-GEOCHEMISTRY

## PHI-HARMONIC GEOCHEMICAL CYCLING

### 1. Phi-Elemental Ratios

The phi-harmonic elemental ratio model:

```
(X/Y)_sample = (X/Y)_chondrite * phi^(-n_refractory) * (1 + epsilon*phi^(n_volatile))
```

Where:
- (X/Y)_chondrite = chondritic reference ratio
- n_refractory = refractory element index
- n_volatile = volatile element index

The phi-modification produces a self-similar pattern of elemental fractionation.

### 2. Phi-Isotope Fractionation

The isotope fractionation factor:

```
alpha_phi = alpha_0 * phi^(Delta_G/(R*T*phi))
```

Where:
- alpha_0 = baseline fractionation factor
- Delta_G = Gibbs free energy change (J/mol)
- R = gas constant (8.314 J/(mol*K))

The phi-exponent produces stronger fractionation at low temperatures.

### 3. Phi-Mineral Stability

The phase diagram boundary:

```
T_boundary = T_0 * (P/P_0)^(1/phi) * phi^(-X/X_ref)
```

Where:
- T_0 = reference temperature (K)
- P_0 = reference pressure (GPa)
- X = compositional variable

The phi-boundary produces curved phase boundaries that match experimental data.

### 4. Phi-Weathering Rate

The silicate weathering rate:

```
R_weather = R_0 * (CO2/CO2_ref)^phi * (T/T_ref)^(1/phi) * (A_mineral/A_ref) * phi^(-SM/SM_ref)
```

Where:
- R_0 = baseline rate (mol/(m^2*s))
- A_mineral = mineral surface area (m^2)
- SM = soil moisture (m^3/m^3)

The phi-terms capture the nonlinear dependencies on climate and surface area.

### 5. Phi-Hydrothermal Circulation

The hydrothermal fluid velocity:

```
v_hydro = v_0 * (Delta_P/P_ref)^phi * phi^(-T/T_ref) * (k/k_ref)^(1/phi)
```

Where:
- Delta_P = pressure gradient (Pa/m)
- k = permeability (m^2)

The phi-permeability dependence produces channelized flow.

The mineral precipitation rate:

```
R_precip = R_0 * (SI)^phi * phi^(-t/tau_saturation)
```

Where SI = saturation index.

### 6. Phi-Metamorphic Reactions

The metamorphic grade:

```
Grade = Grade_0 * phi^(T/T_ref) * (P/P_ref)^(1/phi) * phi^(-t/tau_metamorphic)
```

Where:
- T = temperature (K)
- P = pressure (GPa)
- tau_metamorphic = reaction timescale (Myr)

The phi-terms produce curved metamorphic facies boundaries.

### 7. Phi-Ore Formation

The ore grade:

```
G_ore = G_0 * (C_fluid/C_ref)^phi * phi^(-V/V_ref) * (1 - phi^(-t/tau_deposition))
```

Where:
- C_fluid = fluid metal concentration (ppm)
- V = fluid volume (m^3)
- tau_deposition = deposition timescale (yr)

The phi-deposition produces a sharp enrichment front.

The concentration factor:

```
CF = CF_0 * phi^(n_enrichment)
```

Where n_enrichment is the number of enrichment cycles.

---

## PHI-HARMONIC GEOCHEMICAL EQUATIONS

| Eq # | Name | Formula |
|------|------|---------|
| Geo.1 | Elemental ratio | (X/Y) = (X/Y)_ch*phi^(-n_r)*(1+eps*phi^(n_v)) |
| Geo.2 | Fractionation | alpha = alpha_0*phi^(DG/(RT*phi)) |
| Geo.3 | Phase boundary | T = T_0*(P/P_0)^(1/phi)*phi^(-X/X_r) |
| Geo.4 | Weathering | R = R_0*(CO2/CO2_r)^phi*(T/T_r)^(1/phi)*A*phi^(-SM/SM_r) |
| Geo.5 | Hydrothermal | v = v_0*(DP/P_r)^phi*phi^(-T/T_r)*(k/k_r)^(1/phi) |
| Geo.6 | Metamorphic | G = G_0*phi^(T/T_r)*(P/P_r)^(1/phi)*phi^(-t/tau) |
| Geo.7 | Ore grade | G = G_0*(C/C_r)^phi*phi^(-V/V_r)*(1-phi^(-t/tau)) |

---

## WORKED EXAMPLES

### Example 1: Phi-Weathering Rate

**Given:**
- R_0 = 1e-8 mol/(m^2*s)
- CO2 = 400 ppm
- CO2_ref = 280 ppm
- T = 298 K, T_ref = 290 K

**Find:** Weathering rate

**Solution:**

Step 1: CO2 factor
```
(CO2/CO2_ref)^phi = (400/280)^1.618 = 1.429^1.618 = 1.78
```

Step 2: Temperature factor
```
(T/T_ref)^(1/phi) = (298/290)^0.618 = 1.028^0.618 = 1.017
```

Step 3: Weathering rate
```
R = 1e-8 * 1.78 * 1.017 = 1.81e-8 mol/(m^2*s)
```

**Result:** The phi-weathering rate is 1.81e-8 mol/(m^2*s).

---

## PROBLEMS

1. Calculate the isotope fractionation at T = 300 K with Delta_G = -5 kJ/mol.

2. Determine the metamorphic grade at T = 800 K and P = 1 GPa.

3. Find the ore grade after 3 enrichment cycles with CF_0 = 10.

4. Calculate the hydrothermal velocity at Delta_P = 100 Pa/m and k = 1e-12 m^2.

5. Design a phi-geochemical model for a hydrothermal system.

---

## EXTENDED TABLES

### Elemental Abundances in Earth's Crust

| Element | Abundance (ppm) | Phi-Abundance (ppm) | Category |
|---------|-----------------|--------------------|----------|
| O | 461,000 | 285,000 | Major |
| Si | 282,000 | 174,000 | Major |
| Al | 82,300 | 50,800 | Major |
| Fe | 56,300 | 34,700 | Major |
| Ca | 41,500 | 25,600 | Major |
| Na | 23,600 | 14,600 | Major |
| Mg | 23,300 | 14,400 | Major |
| K | 20,900 | 12,900 | Major |
| Ti | 5,650 | 3,490 | Minor |
| H | 1,400 | 864 | Minor |
| Mn | 950 | 586 | Minor |
| P | 1,050 | 648 | Minor |

### Isotope Fractionation Factors

| Isotope Pair | Alpha_0 | Alpha_phi | Temperature (C) |
|-------------|---------|-----------|-----------------|
| 18O/16O (water) | 1.0098 | 1.0080 | 25 |
| 13C/12C (carbonate) | 1.0028 | 1.0023 | 25 |
| 34S/32S (sulfide) | 1.0222 | 1.0182 | 25 |
| 56Fe/54Fe (iron) | 1.0009 | 1.0007 | 25 |
| 26Mg/24Mg (magnesium) | 1.0003 | 1.0002 | 25 |

### Mineral Stability Fields

| Mineral | T Range (C) | P Range (GPa) | Phi-T Range (C) |
|---------|------------|---------------|-----------------|
| Quartz | 200-800 | 0-2 | 164-655 |
| Feldspar | 400-900 | 0.5-3 | 328-737 |
| Garnet | 500-1000 | 1-5 | 410-819 |
| Pyroxene | 600-1200 | 1-8 | 491-983 |
| Olivine | 800-1800 | 0-15 | 655-1474 |
| Diamond | 900-1300 | >4 | 738-1065 |

### Weathering Rates

| Mineral | Rate (mol/m^2/s) | Phi-Rate (mol/m^2/s) | Activation E (kJ/mol) |
|---------|------------------|----------------------|----------------------|
| Olivine | 1e-9 | 8.2e-10 | 80 |
| Pyroxene | 1e-10 | 8.2e-11 | 75 |
| Plagioclase | 1e-11 | 8.2e-12 | 65 |
| K-feldspar | 1e-12 | 8.2e-13 | 60 |
| Quartz | 1e-14 | 8.2e-15 | 70 |
| Mica | 1e-13 | 8.2e-14 | 55 |

### Hydrothermal Fluid Compositions

| Fluid Type | T (C) | pH | Salinity (wt%) | Phi-pH |
|------------|-------|-----|----------------|--------|
| Black smoker | 350-400 | 2-3 | 3-5 | 1.7-2.5 |
| White smoker | 200-300 | 4-5 | 2-4 | 3.3-4.1 |
| Low-T vent | 50-150 | 6-7 | 1-3 | 5.0-5.8 |
| Brine pool | 100-200 | 5-6 | 10-25 | 4.1-5.0 |
| Seawater | 2-25 | 7.8-8.2 | 3.5 | 6.4-6.7 |

### Metamorphic Facies

| Facies | T (C) | P (GPa) | Phi-T (C) | Rocks |
|--------|-------|---------|-----------|-------|
| Greenschist | 300-500 | 0.2-0.8 | 246-410 | Basalt, pelite |
| Amphibolite | 500-700 | 0.3-1.2 | 410-573 | Basalt, pelite |
| Granulite | 700-900 | 0.4-1.5 | 573-737 | Basalt, pelite |
| Eclogite | 500-800 | 1.2-3.0 | 410-655 | Basalt |
| Blueschist | 200-400 | 0.6-1.5 | 164-328 | Basalt, pelite |
| Hornfels | 400-800 | <0.3 | 328-655 | Various |
| Zeolite | 100-300 | <0.3 | 82-246 | Volcanic |

### Ore Deposit Types

| Type | Metal | Grade (%) | Phi-Grade (%) | T Form (C) |
|------|-------|----------|--------------|------------|
| Porphyry Cu | Cu | 0.3-1.0 | 0.25-0.82 | 300-600 |
| VMS | Cu, Zn | 2-10 | 1.6-8.2 | 150-350 |
| Sedimentary Cu | Cu | 1-5 | 0.8-4.1 | 50-200 |
| Orogenic Au | Au | 1-10 g/t | 0.8-8.2 g/t | 200-500 |
| Carlin Au | Au | 1-5 g/t | 0.8-4.1 g/t | 150-300 |
| IOCG | Cu, Fe | 1-5 | 0.8-4.1 | 200-500 |

### Concentration Factors

| Element | CF (crust to ore) | Phi-CF | Enrichment Cycles |
|---------|-------------------|--------|-------------------|
| Cu | 100-1000 | 82-819 | 3-4 |
| Zn | 100-1000 | 82-819 | 3-4 |
| Pb | 100-1000 | 82-819 | 3-4 |
| Au | 1000-10000 | 819-8190 | 4-5 |
| Ag | 100-1000 | 82-819 | 3-4 |
| Fe | 10-100 | 8-82 | 2-3 |

### Rock-Eval Pyrolysis Parameters

| Parameter | Source Rock | Phi-Value | Interpretation |
|-----------|-----------|-----------|----------------|
| S1 (mg HC/g) | 0.5-20 | 0.4-16.4 | Free hydrocarbons |
| S2 (mg HC/g) | 5-100 | 4-82 | Kerogen cracking |
| S3 (mg CO2/g) | 0.5-5 | 0.4-4.1 | Oxygen content |
| Tmax (C) | 430-470 | 352-385 | Maturity |
| HI (mg HC/g TOC) | 100-700 | 82-573 | Kerogen type |
| OI (mg CO2/g TOC) | 5-50 | 4-41 | Kerogen type |

### Fluid Inclusion Data

| Inclusion Type | T (C) | Salinity (wt%) | Phi-T (C) |
|---------------|-------|----------------|-----------|
| Primary | 100-400 | 5-25 | 82-328 |
| Secondary | 50-200 | 1-15 | 41-164 |
| Monster | 150-350 | 10-30 | 123-287 |
| daughter | 200-500 | 30-50 | 164-410 |
