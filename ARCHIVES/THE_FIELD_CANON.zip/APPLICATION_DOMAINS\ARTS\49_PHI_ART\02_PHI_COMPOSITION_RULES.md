# PHI-COMPOSITION RULES IN VISUAL ART

## 1. The PHI-Composition Framework

### 1.1 Core Principle

Every visual composition can be analyzed as a relationship between positive and negative space, between elements and the ground they occupy. PHI-composition uses the golden ratio phi = 1.6180339887 to establish these relationships with mathematical precision, creating works that feel both intentional and organic.

### 1.2 The PHI-Compositional Grid

The foundational grid divides the canvas at phi-proportions:

```
Canvas width: W
Canvas height: H = W/phi

Primary vertical lines: W/phi, W/phi^2
Primary horizontal lines: H/phi, H/phi^2

For a 161.8 x 100 cm canvas:
  Vertical: 100 cm, 61.8 cm from left
  Horizontal: 61.8 cm, 38.2 cm from top

  The four intersection points create the PHI-compositional anchors:
    Anchor 1 (100, 61.8): primary focus — strongest visual weight
    Anchor 2 (61.8, 38.2): secondary focus — supporting element
    Anchor 3 (100, 38.2): tertiary focus — accent or detail
    Anchor 4 (61.8, 61.8): quaternary focus — entry point
```

## 2. Rule of PHI-Division

### 2.1 Horizontal Division

Divide the canvas horizontally at the golden section:

```
Upper section: H/phi = 61.8 cm (sky, background, head)
Lower section: H/phi^2 = 38.2 cm (ground, foreground, body)

For landscape:
  Sky occupies 61.8% of canvas
  Ground occupies 38.2%
  
For portrait:
  Head occupies 38.2%
  Body occupies 61.8%
```

### 2.2 Vertical Division

Divide the canvas vertically at the golden section:

```
Left section: W/phi = 100 cm
Right section: W/phi^2 = 61.8 cm

For left-to-right reading cultures:
  Left section (100 cm): dominant content
  Right section (61.8 cm): supporting content or resolution
  
  The eye enters from the left, travels through the larger
  section, and rests in the smaller section
```

### 2.3 Diagonal Division

The phi-diagonal creates dynamic tension:

```
Diagonal from corner to corner at phi-angle:
  Angle = arctan(H/W) = arctan(1/phi) = 31.72 degrees

  The diagonal divides the canvas into two phi-triangles:
    Upper triangle: area = W x H / 2
    Lower triangle: area = W x H / 2
    
  Equal areas, but the phi-angle creates visual movement
  along the diagonal, with energy flowing from corner to corner
```

## 3. PHI-Spiral Composition

### 3.1 The Golden Spiral

The most powerful phi-compositional tool is the golden spiral, which can be overlaid on any canvas:

```
Golden spiral construction:
  Start with phi-rectangle (W x W/phi)
  Remove square (W/phi x W/phi)
  Remaining rectangle: (W - W/phi) x W/phi = W/phi^2 x W/phi
  This is also a phi-rectangle
  Repeat: remove square, get smaller phi-rectangle
  Continue infinitely inward

  Spiral arc through each square's corners:
    Quarter-circle in each square
    Radius decreases by factor of phi each quarter-turn
```

### 3.2 Spiral Application

```
For a 161.8 x 100 cm canvas:

Square 1: 100 x 100 cm (left portion)
  Spiral arc from top-left to bottom-right
  
Square 2: 61.8 x 61.8 cm (right portion, top)
  Spiral arc from top-right to bottom-left
  
Square 3: 38.2 x 38.2 cm (right portion, bottom-left)
  Spiral arc from bottom-left to top-right
  
Square 4: 23.6 x 23.6 cm (right portion, bottom-right, top)
  Spiral arc from top-right to bottom-left
  
  ...continuing inward

Placement along spiral:
  Subject: at the spiral's terminus (smallest square)
  Secondary elements: along the spiral's curve
  Background: follows the spiral's direction
```

### 3.3 Reverse Spiral

```
Counter-clockwise golden spiral:
  Start from center, spiral outward
  Each turn expands by factor of phi
  
  Use for:
    Explosive compositions (energy radiating from center)
    Growth narratives (something emerging from within)
    Atmospheric effects (light radiating outward)
```

## 4. PHI-Visual Weight

### 4.1 Weight Distribution

Visual weight in PHI-composition follows the golden ratio:

```
Element weight: proportional to area x contrast x color intensity

Distribution rule:
  Primary element: 61.8% of total visual weight
  Secondary element: 23.6% (61.8% of remaining)
  Tertiary element: 14.6% (61.8% of remaining)
  
  Total: 61.8 + 23.6 + 14.6 = 100%

Example in a portrait:
  Face: 61.8% weight (largest, highest contrast)
  Clothing: 23.6% weight (medium area, medium contrast)
  Background: 14.6% weight (smallest, lowest contrast)
```

### 4.2 Weight Balancing

```
Asymmetric balance using phi:

If Element A is at position x from center,
Element B should be at position x x phi from center
on the opposite side, with weight A/phi

Example:
  Large element (weight 100) at 30 cm left of center
  Small element (weight 100/phi = 61.8) at 30 x phi = 48.5 cm right of center
  
  Torque balance: 100 x 30 = 3000 = 61.8 x 48.5 = 2997.3 (balanced)
```

### 4.3 Negative Space Weight

```
Negative space (empty areas) also carries visual weight:

Active negative space: 38.2% of canvas (1/phi of total)
Passive negative space: 23.6% of canvas (1/phi^2 of total)
Dead negative space: 14.6% of canvas (1/phi^3 of total)

Active negative space creates tension (the eye wants to fill it)
Passive negative space provides rest (the eye accepts it)
Dead negative space is neutral (the eye ignores it)
```

## 5. PHI-Line and Edge

### 5.1 Leading Lines

```
PHI-Leading lines follow the golden spiral:

Line A (primary): follows the spiral's outermost arc
 起点: canvas edge
 终点: focal point at spiral's center
  
Line B (secondary): follows the spiral's second arc
 起点: perpendicular to Line A
 终点: secondary focus

Line C (tertiary): follows the spiral's third arc
 起点: perpendicular to Line B
 终点: tertiary focus
```

### 5.2 Edge Treatment

```
Edge quality follows phi-distribution:

Hard edges: 38.2% of all edges (1/phi of total)
  - Focal points
  - High-contrast boundaries
  - Silhouette lines

Soft edges: 61.8% of all edges (phi/total)
  - Background transitions
  - Atmospheric perspective
  - Motion blur areas

Lost edges: within soft edges, some disappear entirely
  - Where figure meets background at same value
  - Creates mystery and invites eye to search
```

### 5.3 Line Weight

```
Line weight (thickness) in phi-proportions:

Outline: 3 pt (reference)
Contour: 3/phi = 1.85 pt
Detail: 1.85/phi = 1.14 pt
Accent: 3 x phi = 4.85 pt
Bold: 4.85 x phi = 7.85 pt

The phi-progression of line weights creates a natural
hierarchy from bold structure to delicate detail
```

## 6. PHI-Color Composition

### 6.1 Color Area Ratios

```
In a balanced composition, color areas follow phi:

Dominant color: 61.8% of chromatic area
Subordinate color: 23.6% of chromatic area
Accent color: 14.6% of chromatic area

Example:
  Canvas area: 10,000 cm²
  Chromatic area (excluding neutral): 6,000 cm²
  
  Dominant (blue): 6,000 x 0.618 = 3,708 cm²
  Subordinate (orange): 6,000 x 0.236 = 1,416 cm²
  Accent (red): 6,000 x 0.146 = 876 cm²
```

### 6.2 Color Contrast Ratios

```
Value contrast between elements:
  Maximum contrast: black/white (21:1 ratio)
  PHI-contrast: 21/phi = 13:1 ratio (strong but not maximum)
  Subtle contrast: 21/phi^2 = 8:1 ratio
  Whisper contrast: 21/phi^3 = 5:1 ratio

  The phi-contrast creates visual hierarchy without
  the harshness of maximum contrast
```

### 6.3 Temperature Balance

```
Warm : Cool color area = phi : 1

For a balanced composition:
  Warm colors (red, orange, yellow): 61.8% of chromatic area
  Cool colors (blue, green, purple): 38.2% of chromatic area
  
  Within warm:
    Red: 61.8% x 61.8% = 38.2%
    Orange: 61.8% x 23.6% = 14.6%
    Yellow: 61.8% x 14.6% = 9.0%
    
  Within cool:
    Blue: 38.2% x 61.8% = 23.6%
    Green: 38.2% x 23.6% = 9.0%
    Purple: 38.2% x 14.6% = 5.6%
```

## 7. PHI-Space and Depth

### 7.1 Foreground-Middleground-Background

```
Depth zones in phi-proportions:

Foreground: 38.2% of depth (closest to viewer)
Middleground: 23.6% of depth (main subject zone)
Background: 38.2% of depth (furthest from viewer)

Note: foreground and background are equal in depth,
but the middleground is narrower, creating compression
in the zone of primary interest
```

### 7.2 Perspective Ratios

```
One-point perspective with phi:

Vanishing point: at phi-intersection (100, 61.8) on canvas
Horizon line: at 61.8 cm from top
Ground line: at 100 cm from top (bottom of canvas)

Receding lines converge at vanishing point:
  All parallel lines in the scene converge to VP
  The convergence rate follows phi:
    Objects at distance d appear at scale 1/phi^(d/D)
    Where D = reference distance
```

### 7.3 Atmospheric Perspective

```
Phi-atmospheric perspective:

Distance from viewer: d
Value shift: toward background value by factor of 1/phi^(d/D)
Saturation shift: toward gray by factor of 1/phi^(d/D)
Hue shift: toward blue by factor of 1/phi^(d/D)

At d = D (one reference distance):
  Value: shifted by 1/phi = 61.8%
  Saturation: reduced by 1/phi = 38.2% remaining
  Hue: shifted toward blue by 1/phi

At d = 2D:
  Value: shifted by 1/phi^2 = 38.2%
  Saturation: reduced by 1/phi^2 = 23.6% remaining
```

## 8. PHI-Temporal Composition

### 8.1 Narrative Flow

```
Visual narrative follows phi-timing:

Introduction: 38.2% of visual scan time (first impression)
Development: 23.6% (deepening engagement)
Climax: 14.6% (peak attention)
Resolution: 23.6% (rest and integration)

Total: 38.2 + 23.6 + 14.6 + 23.6 = 100%

The climax is the shortest phase but receives
the most intense attention
```

### 8.2 Scan Path

```
Eye movement through a phi-composition:

Entry: bottom-left corner (phi-spiral start)
  ↓ Move along spiral arc to focal point 1
  ↑ Continue to focal point 2
  → Move to focal point 3
  ↓ Return to focal point 4
  
The scan path traces the golden spiral,
ensuring the eye visits all important elements
in the order of their visual importance
```

### 8.3 Rhythm and Repetition

```
Phi-rhythm in visual elements:

Element spacing: follows Fibonacci sequence
  Element 1 to 2: 1 unit
  Element 2 to 3: 1 unit
  Element 3 to 4: 2 units
  Element 4 to 5: 3 units
  Element 5 to 6: 5 units
  
  The increasing spacing creates acceleration then deceleration,
  like breathing: inhale (expansion) and exhale (contraction)
```

## 9. PHI-Abstraction

### 9.1 Geometric PHI-Abstraction

```
Abstract composition from phi-geometry:

Layer 1: phi-rectangle (background structure)
Layer 2: golden spiral (movement path)
Layer 3: phi-circles (at spiral intersections)
Layer 4: phi-lines (connecting intersections)
Layer 5: phi-colors (filling regions)

Each layer is semi-transparent:
  Layer 1: 100% opacity (foundation)
  Layer 2: 61.8% opacity (structure)
  Layer 3: 38.2% opacity (form)
  Layer 4: 23.6% opacity (direction)
  Layer 5: 14.6% opacity (atmosphere)
```

### 9.2 Organic PHI-Abstraction

```
Organic abstraction from phi-ratios:

Curves: logarithmic spirals with growth factor phi
Shapes: phi-ellipses (axes in phi-ratio)
Textures: phi-random distribution (not uniform, not clustered)
Colors: phi-harmony palette

The organic quality comes from the self-similarity:
  The same phi-ratio appears at every scale
  Zoom into any area and the proportions are maintained
  This creates a fractal-like coherence
```

### 9.3 Minimalist PHI-Abstraction

```
Minimalist PHI-composition:

Elements: maximum 5 (Fibonacci number)
Colors: maximum 3 (Fibonacci number)
Lines: maximum 8 (Fibonacci number)

Arrangement:
  Element 1: 61.8% of canvas area
  Element 2: 23.6% of canvas area
  Element 3: 14.6% of canvas area
  
  The three elements create complete phi-hierarchy
  with nothing superfluous
```

## 10. PHI-Composition Verification

### 10.1 Measurement Protocol

```
To verify a composition follows phi-rules:

1. Measure all major divisions
   [ ] Primary division at 0.618 of total
   [ ] Secondary division at 0.382 of total
   
2. Check focal point positions
   [ ] Primary focal at phi-intersection
   [ ] Secondary focal at adjacent phi-intersection
   
3. Measure element sizes
   [ ] Largest element : total = 1 : phi
   [ ] Largest : second = phi : 1
   [ ] Second : third = phi : 1
   
4. Check color areas
   [ ] Dominant : Subordinate = phi : 1
   [ ] Subordinate : Accent = phi : 1
   
5. Verify edge quality
   [ ] Hard edges : Soft edges = 1 : phi
```

### 10.2 Phi-Score

```
Calculate a composition's phi-score:

Score = (phi-compliant elements / total elements) x 100

Elements to check:
  1. Canvas ratio
  2. Grid alignment
  3. Focal point position
  4. Element size ratios
  5. Color area ratios
  6. Value distribution
  7. Edge quality ratio
  8. Line weight ratio
  9. Spacing patterns
  10. Negative space ratio

Target: Score > 61.8% (phi-threshold)
Score > 80%: Strong phi-composition
Score > 90%: Exceptional phi-composition
Score = 100%: Perfect phi-composition (rare and potentially sterile)
```

## References

- Arnheim, R. (1974). "Art and Visual Perception"
- Bouleau, C. (1963). "The Painter's Secret Geometry"
- Ghyka, M. (1931). "The Geometry of Art and Life"
- Itten, J. (1961). "The Art of Color"
- Albers, J. (1963). "Interaction of Color"
