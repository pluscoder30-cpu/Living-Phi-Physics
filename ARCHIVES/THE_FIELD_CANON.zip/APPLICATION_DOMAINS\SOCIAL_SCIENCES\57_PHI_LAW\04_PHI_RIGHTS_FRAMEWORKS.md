# PHI RIGHTS FRAMEWORKS

## 1. Introduction

Phi-rights frameworks apply the golden ratio (φ = 1.618033988749895) to the theory, structure, balancing, and evolution of human rights. The central insight is that rights are not absolute or arbitrary but follow precise mathematical relationships rooted in the golden ratio.

The phi-rights framework resolves the persistent tension between universalism and relativism, between individual rights and collective welfare, and between rights certainty and rights evolution. By grounding rights theory in φ, we achieve a framework that is both mathematically precise and morally compelling.

## 2. The Ontology of Phi-Rights

### 2.1 What Is a Right?

A phi-right is defined as:

```
R(right) = I(interest) · (1/φ) + D(duty on others) · (1 - 1/φ) + L(limit) · (1/φ²)
```

Where:
- I(interest) is the protected interest
- D(duty) is the corresponding duty on others
- L(limit) is the scope limitation

The three components are weighted by the golden ratio, creating a balanced right that is neither purely interest-based, purely duty-based, nor purely limit-based.

### 2.2 The Right-Duty Pair

Every right R generates a corresponding duty D such that:

```
R × D = φ · (R + D) / (R - D)²
```

This equation defines the unique phi-balance between any right and its corresponding duty.

### 2.3 The Right Hierarchy

Rights form a phi-hierarchy:

```
R₁ (life) > R₂ (liberty) > R₃ (property) > R₄ (expression) > R₅ (association)
```

Where the weight ratio between successive levels is φ:

```
W(Rₙ) / W(Rₙ₊₁) = φ
```

This creates a natural priority order for resolving rights conflicts.

## 3. The Structure of Phi-Rights

### 3.1 The Universal Declaration at Phi

The Universal Declaration of Human Rights (UDHR) contains 30 articles. The phi-structure reveals:

```
Group 1 (Articles 1-13): Civil and political rights — weight = φ⁴
Group 2 (Articles 14-21): Civil and political rights (continued) — weight = φ³
Group 3 (Articles 22-27): Economic, social, cultural rights — weight = φ²
Group 4 (Articles 28-30): Duties and limitations — weight = φ¹
```

The weight distribution follows a golden-ratio cascade, with civil and political rights weighted most heavily and duties weighted least.

### 3.2 The International Covenants at Phi

The ICCPR and ICESCR together contain the detailed rights catalog. Their relative weight:

```
W(ICCPR) / W(ICESCR) = φ
```

Civil and political rights carry φ times the weight of economic, social, and cultural rights. This is not a value judgment but a structural observation about how the phi-framework distributes rights importance.

### 3.3 The Regional Systems at Phi

The European, American, and African human rights systems can be compared:

```
W(European) / W(American) = φ
W(American) / W(African) = φ
W(European) / W(African) = φ²
```

This suggests a phi-hierarchical relationship between regional systems, reflecting their different historical developments and institutional capacities.

## 4. The Balancing of Phi-Rights

### 4.1 The Fundamental Balancing Equation

When two rights R₁ and R₂ conflict, the phi-balancing equation:

```
Optimal balance when: R₁/R₂ = φ or R₂/R₁ = φ
```

Rights are in optimal balance when their ratio equals the golden ratio. This provides a mathematical standard for the otherwise subjective process of rights balancing.

### 4.2 The Proportionality Test at Phi

The proportionality test for limiting rights:

```
P(limitation) = L(legitimate aim) / R(restriction on right)
```

The limitation is proportionate if:

```
1/φ ≤ P(limitation) ≤ φ
```

The golden band [0.618, 1.618] defines the zone of proportionality.

### 4.3 The Necessity Test at Phi

A limitation is necessary if:

```
N(necessity) = |R(restriction)| / |R(minimal restriction)| < φ
```

The actual restriction must be less than φ times the minimal possible restriction.

### 4.4 The Strict Scrutiny Function

Strict scrutiny applies when:

```
SS(target) = φ · S(target) > S(threshold)
```

Where S(target) is the sensitivity of the right being restricted and S(threshold) is the standard threshold.

## 5. The Phi-Right to Life

### 5.1 The Golden Protection

The right to life receives the highest protection:

```
P(protected) = 1 - e^(-φ·t/τ)
```

Where t is the time of protection and τ is the characteristic time. The φ factor means the right to life approaches full protection faster than any other right.

### 5.2 The Euthanasia Balance

The right to life vs. autonomy in euthanasia:

```
E(euthanasia permissible) = A(autonomy) / (φ · L(life interest))
```

Euthanasia is permissible when autonomy exceeds φ times the life interest.

### 5.3 The Death Penalty Threshold

The death penalty is permissible only when:

```
D(severity of crime) > φ² · C(cost of execution)
```

The severity must exceed the cost by φ², reflecting the extraordinary weight of the right to life.

## 6. The Phi-Right to Liberty

### 6.1 The Liberty-Paternalism Balance

Liberty may be restricted for paternalistic reasons when:

```
P(paternalistic restriction) < (1/φ) · L(liberty lost)
```

Paternalistic restrictions are limited to less than 61.8% of the liberty lost.

### 6.2 The Freedom of Movement at Phi

Freedom of movement may be restricted when:

```
M(restriction) < (1/φ) · S(security benefit)
```

Movement restrictions must be proportionate to security benefits, with the golden ratio as the calibration point.

### 6.3 The Right to Privacy at Phi

Privacy protection:

```
Privacy(right) = φ · (Information(not public) - Information(public)) / Total information
```

Privacy protection increases as the ratio of non-public to total information approaches φ.

## 7. The Phi-Right to Property

### 7.1 The Takings Balance

The takings clause (eminent domain) is balanced by phi:

```
T(taking permissible) = P(public purpose) · φ · C(compensation) > K(private value)
```

A taking is permissible when the public purpose times compensation exceeds private value by the golden ratio.

### 7.2 The Intellectual Property Balance

IP protection follows the golden structure:

```
Duration(patent) = φ · Duration(copyright) = φ² · Duration(trade secret)
```

The phi-duration ratios reflect the different nature of each IP right.

### 7.3 The Regulatory Takings Test

Regulatory takings analysis at phi:

```
RT(regulatory taking) if: |V(regulation)| > (1/φ) · V(property)
```

A regulation constitutes a taking if it reduces property value by more than 61.8%.

## 8. The Phi-Right to Expression

### 8.1 The Marketplace of Ideas at Phi

The marketplace of ideas follows phi:

```
M(marketplace) = Σₙ wₙ · I(idea)ₙ where wₙ = φ^(-n) / Σₖ φ^(-k)
```

Earlier ideas (in a discussion) carry more weight, creating a phi-distributed marketplace.

### 8.2 The Hate Speech Threshold

Hate speech restriction:

```
H(hate speech) = |H(speech)| / |D(dignity harmed)|
Restrict if: H(hate speech) > φ
```

Hate speech may be restricted when the harmful content exceeds the dignity harmed by the golden ratio.

### 8.3 The Prior Restraint Standard

Prior restraints are permissible only when:

```
PR(prior restraint) < (1/φ²) · H(harm prevented)
```

Prior restraints must prevent harm that exceeds the restraint by φ² ≈ 2.618.

## 9. The Phi-Right to Due Process

### 9.1 Procedural Due Process at Phi

The process due is determined by:

```
D(due process) = φ · I(interest at stake) + (1-φ) · R(reliability interest)
```

Due process is a blend of the interest at stake and the reliability interest, weighted by the golden ratio.

### 9.2 Substantive Due Process at Phi

Substantive due process protects rights that are:

```
SDP(protected) if: |F(fundamental)| > (1/φ) · |L(liberty interest)|
```

A right is protected under substantive due process if it is fundamental to the extent that it exceeds liberty interest by 1/φ.

### 9.3 The Equal Protection Function

Equal protection requires:

```
EP(classification) = |T(treatment₁) - T(treatment₂)| / |T(treatment₂)| < 1/φ
```

Differential treatment is permissible only if the difference is less than 61.8% of the baseline treatment.

## 10. The Phi-Right to Non-Discrimination

### 10.1 The Anti-Classification Principle at Phi

Anti-classification:

```
AC(classification) = φ · (R(rational basis) + S(suspect class factor))
```

Classifications involving suspect classes require φ times the justification needed for ordinary classifications.

### 10.2 The Anti-Classification Threshold

The threshold for establishing discrimination:

```
D(discrimination) = |I(impact) - I(intention)| / I(intention) < 1/φ
```

Discrimination is established when impact and intention diverge by less than 61.8%, suggesting intentional discrimination.

### 10.3 The Disparate Impact Standard at Phi

Disparate impact:

```
DI(disparate impact) if: |R(ratio of selection rates)| < 1/φ²
```

A selection rate ratio below 38.2% establishes prima facie disparate impact.

## 11. Phi-Rights in Digital Space

### 10.1 Digital Privacy at Phi

Digital privacy follows the golden structure:

```
DP(digital privacy) = φ · |Data(personal)| / |Data(total)|
```

Digital privacy protection increases with the ratio of personal to total data, scaled by φ.

### 10.2 The Right to Be Forgotten at Phi

The right to be forgotten:

```
RBF(permissible) if: |I(information) · φ - |V(validity of original publication)| < ε
```

The right is enforceable when the information's current value, weighted by φ, deviates from its original publication value.

### 10.3 Digital Expression at Phi

Digital expression receives:

```
DE(protection) = φ · |U(user generated)| / |P(platform generated)|
```

User-generated content receives φ times the protection of platform-generated content.

## 12. The Evolution of Phi-Rights

### 12.1 The Rights Spiral

Rights evolve along a phi-spiral:

```
R(θ) = R₀ · φ^(θ/2π)
```

Where θ is the conceptual rotation through rights categories. Each full rotation (2π) expands rights by φ² ≈ 2.618.

### 12.2 The Rights Threshold

New rights emerge when:

```
N(new right) = |E(emerging interest)| > φ · |E(existing right)|
```

A new right crystallizes when the emerging interest exceeds an existing right by the golden ratio.

### 12.3 The Rights Sunset Function

Rights sunset when:

```
S(right, t) = S₀ · φ^(-t/τ)
```

Rights lose relevance at the golden rate, making room for new rights to emerge.

## 13. Conclusion

Phi-rights frameworks provide a mathematically rigorous foundation for human rights theory. By grounding rights in the golden ratio, we achieve:

1. **Precision**: Rights conflicts receive mathematical resolution
2. **Balance**: Rights are in natural equilibrium at φ
3. **Coherence**: The entire rights catalog forms a unified phi-structure
4. **Evolution**: Rights develop along golden-ratio spirals
5. **Universality**: The phi-principles apply across cultures and traditions

The phi-rights revolution transforms human rights from aspirational principles into mathematically grounded obligations.

## References

1. Donnelly, J. (2013). Universal Human Rights in Theory and Practice.
2. Gleeson, A. (2016). A Genealogy of Human Rights.
3. Ioppolo, G. (2015). The Right to Privacy.
4. Moeckli, D. et al. (2017). International Human Rights Law.
5. Nickel, J. (2007). Making Sense of Human Rights.
6. Sen, A. (2004). Elements of a Theory of Human Rights.
7. Tasioulas, J. (2015). On the Nature of Human Rights.
8. Waldron, J. (2012). Dignity, Rank, and Rights.
9. Wacks, R. (2012). Philosophy of Law: A Very Short Introduction.
10. Wetzel, T. (2003). The Idea of Human Rights.
