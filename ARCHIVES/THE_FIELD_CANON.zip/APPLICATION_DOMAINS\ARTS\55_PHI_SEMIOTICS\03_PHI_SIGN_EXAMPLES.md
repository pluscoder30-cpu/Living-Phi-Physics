# PHI-Semiotics: Worked Examples

---

## Example 1: PHI Triadic Sign Calculation

**Problem:** Calculate the information distribution in a Peircean sign.

**Given:**
- Representamen: 10 units of information
- Object: 6 units of information
- Interpretant: 4 units of information

**Solution:**

```
Total information = 10 + 6 + 4 = 20 units

PHI-proportions:
  Representamen: phi^2 = 2.618
  Object: phi = 1.618
  Interpretant: phi^0 = 1.000
  Total: 5.236

Expected distribution:
  Representamen: 2.618/5.236 * 20 = 10.0 units (100% match)
  Object: 1.618/5.236 * 20 = 6.18 units (3% deviation)
  Interpretant: 1.000/5.236 * 20 = 3.82 units (4.5% deviation)

The actual distribution closely matches PHI-proportions.
```

---

## Example 2: PHI Visual Hierarchy Design

**Problem:** Design a poster with PHI-proportional visual weights.

**Given:**
- Title needs weight 1.000
- Body text needs weight 0.382

**Solution:**

```
Font size ratios:
  Title = phi^0 = 1.000
  Subtitle = phi^(-1) = 0.618
  Body = phi^(-2) = 0.382
  Caption = phi^(-3) = 0.236

If body = 12pt:
  Title = 12 / phi^(-2) = 12 / 0.382 = 31.4pt -> 32pt
  Subtitle = 12 / phi^(-2) * phi^(-1) = 12 * 0.618/0.382 = 19.4pt -> 20pt
  Caption = 12 * phi^(-3)/phi^(-2) = 12 * 0.236/0.382 = 7.4pt -> 8pt

Eye movement path:
  Title (32pt) -> Subtitle (20pt) -> Body (12pt) -> Caption (8pt)
  = phi^0 -> phi^(-1) -> phi^(-2) -> phi^(-3)
```

---

## Example 3: PHI Color Palette Design

**Problem:** Create a PHI-balanced color palette for a brand.

**Given:**
- Primary brand color: Blue
- Need dominant, accent, and neutral colors

**Solution:**

```
Color distribution:
  Dominant: phi/(phi+1+phi^(-1)) = 1.618/3.236 = 50.0%
  Accent: 1/(phi+1+phi^(-1)) = 1/3.236 = 30.9%
  Neutral: phi^(-1)/(phi+1+phi^(-1)) = 0.618/3.236 = 19.1%

For a website with 1000px total width:
  Dominant (Blue): 500px (backgrounds, headers)
  Accent (Orange): 309px (buttons, highlights)
  Neutral (Gray): 191px (text, borders)

Color wheel distance:
  Blue -> Orange = 180 degrees (complementary)
  Blue -> Gray = neutral (achromatic)

This creates maximum contrast with PHI-balance.
```

---

## Example 4: PHI Narrative Arc Design

**Problem:** Structure a 300-page novel using PHI-proportions.

**Given:**
- Total pages: 300
- PHI arc: phi^3 : phi^2 : phi : 1 : phi^(-1)

**Solution:**

```
Total weight = phi^3 + phi^2 + phi + 1 + phi^(-1)
            = 4.236 + 2.618 + 1.618 + 1.000 + 0.618
            = 10.090

Phase allocation:
  Exposition: 4.236/10.090 * 300 = 126 pages
  Rising Action: 2.618/10.090 * 300 = 78 pages
  Climax: 1.618/10.090 * 300 = 48 pages
  Falling Action: 1.000/10.090 * 300 = 30 pages
  Resolution: 0.618/10.090 * 300 = 18 pages

Verification: 126 + 78 + 48 + 30 + 18 = 300 pages

Climax position: 126 + 78 = 204 pages (68% through)
This is phi^2/(phi^3+phi^2) = 2.618/6.854 = 38.2% of the way through rising+climax.
```

---

## Example 5: PHI Advertising Layout

**Problem:** Design an ad with PHI-balanced message components.

**Given:**
- Headline weight: phi^2 = 2.618
- Body weight: phi = 1.618
- CTA weight: phi^0 = 1.000

**Solution:**

```
Total weight = 2.618 + 1.618 + 1.000 = 5.236

Space allocation (for 100cm^2 ad):
  Headline: 2.618/5.236 * 100 = 50.0 cm^2
  Body: 1.618/5.236 * 100 = 30.9 cm^2
  CTA: 1.000/5.236 * 100 = 19.1 cm^2

Font size:
  Headline: 48pt (phi^0 = 1.000)
  Body: 48 * phi^(-2) = 48 * 0.382 = 18.3pt -> 18pt
  CTA: 48 * phi^(-3) = 48 * 0.236 = 11.3pt -> 12pt

Color:
  Headline: Brand primary (phi^0)
  Body: Dark gray (phi^(-1) = 0.618)
  CTA: Brand accent (phi^(-2) = 0.382)
```

---

## Example 6: PHI Brand Consistency Score

**Problem:** Measure brand consistency across touchpoints.

**Given:**
- Touchpoints: website, social media, packaging, signage
- Consistency scores: 0.85, 0.78, 0.72, 0.81

**Solution:**

```
Weighted consistency (each touchpoint weighted by importance):
  Website: 0.85 * phi^0 = 0.85
  Social: 0.78 * phi^(-1) = 0.78 * 0.618 = 0.482
  Packaging: 0.72 * phi^(-2) = 0.72 * 0.382 = 0.275
  Signage: 0.81 * phi^(-3) = 0.81 * 0.236 = 0.191

Total weighted: 0.85 + 0.482 + 0.275 + 0.191 = 1.798
Total weight: 1.000 + 0.618 + 0.382 + 0.236 = 2.236

Consistency score: 1.798/2.236 = 0.804 = 80.4%

Interpretation: Strong brand consistency (above 61.8% threshold)
```

---

## Example 7: PHI Intertextual Density

**Problem:** Measure intertextual references in a poem.

**Given:**
- Poem length: 100 words
- Direct quotes: 2
- Allusions: 5
- Echoes: 8
- Traces: 3

**Solution:**

```
Weighted reference count:
  Direct quotes: 2 * phi^0 = 2 * 1.000 = 2.000
  Allusions: 5 * phi^(-1) = 5 * 0.618 = 3.090
  Echoes: 8 * phi^(-2) = 8 * 0.382 = 3.056
  Traces: 3 * phi^(-3) = 3 * 0.236 = 0.708

Total weighted: 2.000 + 3.090 + 3.056 + 0.708 = 8.854

Intertextual density:
  D = 8.854 / (phi * 100) = 8.854 / 161.8 = 0.0547

Interpretation: Low intertextual density (below phi^(-1) = 0.618)
The poem is relatively original, with few references.
```

---

## Example 8: PHI Meme Lifespan Prediction

**Problem:** Predict the lifespan of a viral meme.

**Given:**
- Initial engagement: 1,000,000 views
- Age: 3 days

**Solution:**

```
Lifespan model: L = L0 * phi^(-age/days)

At day 1: L = 1,000,000 * phi^0 = 1,000,000
At day 2: L = 1,000,000 * phi^(-1) = 618,000
At day 3: L = 1,000,000 * phi^(-2) = 382,000
At day 4: L = 1,000,000 * phi^(-3) = 236,000
At day 5: L = 1,000,000 * phi^(-4) = 146,000
At day 6: L = 1,000,000 * phi^(-5) = 90,000
At day 7: L = 1,000,000 * phi^(-6) = 56,000

Half-life: When L = L0/2
  0.5 = phi^(-t)
  t = ln(0.5)/ln(phi^(-1)) = -0.693/(-0.481) = 1.44 days

The meme's half-life is approximately 1.44 days.
After 1 week, engagement drops to 5.6% of initial.
```

---

## Example 9: PHI UI Navigation Depth

**Problem:** Design website navigation with PHI-optimal depth.

**Given:**
- Content pages: 50
- PHI navigation depth: floor(phi^3) = 4

**Solution:**

```
Navigation levels:
  Level 0 (Home): phi^0 = 1.000
  Level 1 (Categories): phi^(-1) = 0.618
  Level 2 (Subcategories): phi^(-2) = 0.382
  Level 3 (Content): phi^(-3) = 0.236
  Level 4 (Detail): phi^(-4) = 0.146 (maximum)

Content distribution:
  Level 1: 50 * phi^(-1) = 30.9 -> 31 pages
  Level 2: 50 * phi^(-2) = 19.1 -> 19 pages
  Level 3: 50 * phi^(-3) = 11.8 -> 12 pages (deep content)
  Level 4: 50 * phi^(-4) = 7.3 -> 7 pages (archives)

Pages per level:
  Home: 1
  Categories: 5 (floor(phi^2) = 2, but need 5 for 50 pages)
  Subcategories: 3 per category = 15 total
  Content: 2 per subcategory = 30 total
  Detail: 1 per content = 50 total

Click depth to any page: maximum 4 clicks (phi^3)
```

---

## Example 10: PHI Emotional Semiotic Arc

**Problem:** Map emotional intensity through a film.

**Given:**
- Film duration: 120 minutes
- PHI emotional arc: phi^3 : phi^2 : phi : 1 : phi^(-1)

**Solution:**

```
Total weight = phi^3 + phi^2 + phi + 1 + phi^(-1) = 10.090

Phase durations:
  Setup (neutral): 4.236/10.090 * 120 = 50.4 minutes
  Rising tension: 2.618/10.090 * 120 = 31.1 minutes
  Peak emotion: 1.618/10.090 * 120 = 19.2 minutes
  Release: 1.000/10.090 * 120 = 11.9 minutes
  Resolution: 0.618/10.090 * 120 = 7.4 minutes

Emotional intensity curve:
  Minute 0-50: I = phi^0 = 1.000 (baseline)
  Minute 50-81: I = phi^1 = 1.618 (rising)
  Minute 81-100: I = phi^2 = 2.618 (peak)
  Minute 100-112: I = phi^1 = 1.618 (falling)
  Minute 112-120: I = phi^0 = 1.000 (resolution)

Peak intensity at minute 90 (75% through) -- classic three-act climax.
```

---

## Example 11: PHI Sacred Geometry in Religious Art

**Problem:** Analyze PHI-proportions in a mandala.

**Given:**
- Mandala diameter: 100 cm
- Concentric circles with PHI-radii

**Solution:**

```
Circle radii (from center):
  Circle 1 (absolute): phi^0 * 10 = 10 cm (10% of radius)
  Circle 2 (transcendent): phi^1 * 10 = 16.2 cm
  Circle 3 (immanent): phi^2 * 10 = 26.2 cm
  Circle 4 (material): phi^3 * 10 = 42.4 cm
  Circle 5 (outer): phi^4 * 10 = 68.5 cm

Wait -- let me recalculate for a 50cm radius:
  Inner: 50/phi^4 = 50/6.854 = 7.3 cm
  Next: 50/phi^3 = 50/4.236 = 11.8 cm
  Middle: 50/phi^2 = 50/2.618 = 19.1 cm
  Outer: 50/phi = 50/1.618 = 30.9 cm
  Edge: 50 cm

Ring widths:
  Ring 1: 7.3 cm (phi^-4)
  Ring 2: 4.5 cm (phi^-5)
  Ring 3: 7.3 cm (phi^-4)
  Ring 4: 11.8 cm (phi^-3)
  Ring 5: 19.1 cm (phi^-2)

The outer ring (material world) is phi times wider than the middle ring (immanent).
```

---

## Example 12: PHI Medical Symptom Weighting

**Problem:** Weight symptoms for differential diagnosis.

**Given:**
- Cardinal symptom: chest pain (weight 1.000)
- Accessory symptoms: shortness of breath, sweating
- Negative symptom: no fever

**Solution:**

```
Symptom weights:
  Chest pain: phi^0 = 1.000 (cardinal)
  Shortness of breath: phi^(-1) = 0.618 (accessory 1)
  Sweating: phi^(-2) = 0.382 (accessory 2)
  No fever: phi^(-3) = 0.236 (negative)

Differential diagnosis confidence:
  MI (myocardial infarction):
    + chest pain (1.000)
    + shortness of breath (0.618)
    + sweating (0.382)
    + no fever (0.236)
    Total: 2.236 (high confidence)

  Pneumonia:
    + chest pain (1.000)
    + shortness of breath (0.618)
    - sweating (-0.382) (less typical)
    - no fever (-0.236) (fever expected)
    Total: 1.000 (lower confidence)

  Anxiety:
    + chest pain (1.000)
    + shortness of breath (0.618)
    + sweating (0.382)
    + no fever (0.236)
    Total: 2.236 (same as MI -- need more data)
```

---

## Example 13: PHI Fashion Capsule Wardrobe

**Problem:** Design a 30-piece capsule wardrobe with PHI-proportions.

**Given:**
- Total pieces: 30
- Classic:Trendy:Avant-garde = phi^2:phi:1

**Solution:**

```
Total weight = phi^2 + phi + 1 = 5.236

Distribution:
  Classic: 2.618/5.236 * 30 = 15.0 pieces
  Trendy: 1.618/5.236 * 30 = 9.27 -> 9 pieces
  Avant-garde: 1.000/5.236 * 30 = 5.73 -> 6 pieces

Color palette (for 30 pieces):
  Neutral: phi/(phi+phi^(-1)+phi^(-2)) * 30 = 1.618/2.618 * 30 = 18.5 -> 19 pieces
  Accent: phi^(-1)/2.618 * 30 = 0.618/2.618 * 30 = 7.1 -> 7 pieces
  Statement: phi^(-2)/2.618 * 30 = 0.382/2.618 * 30 = 4.4 -> 4 pieces

Verification: 19 + 7 + 4 = 30 pieces
```

---

## Example 14: PHI Legal Contract Analysis

**Problem:** Analyze contract clause distribution.

**Given:**
- Total clauses: 50
- Explicit : Implicit : Ambiguous = phi^2 : phi : 1

**Solution:**

```
Total weight = phi^2 + phi + 1 = 5.236

Distribution:
  Explicit: 2.618/5.236 * 50 = 25.0 clauses
  Implicit: 1.618/5.236 * 50 = 15.45 -> 15 clauses
  Ambiguous: 1.000/5.236 * 50 = 9.55 -> 10 clauses

Risk assessment:
  Explicit clauses: 25 (50%) -- low risk
  Implicit clauses: 15 (30%) -- moderate risk (subject to interpretation)
  Ambiguous clauses: 10 (20%) -- high risk (litigation potential)

  Ambiguity ratio: 10/50 = 0.20 < phi^(-2) = 0.382
  → Acceptable ambiguity level
```

---

## Example 15: PHI Scientific Paper Structure

**Problem:** Structure a research paper using PHI-proportions.

**Given:**
- Total word count: 8,000 words
- Sections: Introduction, Methods, Results, Discussion

**Solution:**

```
PHI-section weights:
  Introduction: phi^3 = 4.236
  Methods: phi^2 = 2.618
  Results: phi = 1.618
  Discussion: 1.000

Total weight = 4.236 + 2.618 + 1.618 + 1.000 = 9.472

Word allocation:
  Introduction: 4.236/9.472 * 8000 = 3578 words
  Methods: 2.618/9.472 * 8000 = 2213 words
  Results: 1.618/9.472 * 8000 = 1366 words
  Discussion: 1.000/9.472 * 8000 = 845 words

Verification: 3578 + 2213 + 1366 + 845 = 8002 words (rounding)

Note: This is unusual -- standard papers have shorter introductions.
PHI-structure emphasizes setup and context.
```

---

## Example 16: PHI Website Information Architecture

**Problem:** Design site map for an e-commerce site.

**Given:**
- Products: 200
- Categories: 10
- PHI navigation depth: 4

**Solution:**

```
Architecture:
  Level 0: Home (1 page)
  Level 1: Categories (10 pages)
  Level 2: Subcategories (10 * phi = 16.2 -> 16 per category)
  Level 3: Products (16 * phi = 25.9 -> 16 products per subcat)
  Level 4: Product detail (1 page each)

Wait -- let me recalculate:
  Home: 1
  Categories: 10
  Subcategories: 10 * 3 = 30 (3 per category)
  Products: 30 * 7 = 210 (7 per subcategory, close to 200)

Pages per level:
  Level 1: 10 (phi^0 = 1.000 weight)
  Level 2: 30 (phi^(-1) = 0.618 weight)
  Level 3: 200 (phi^(-2) = 0.382 weight)

Clicks to product: 3 (home -> category -> subcategory -> product)
Within phi^3 = 4 maximum.
```

---

## Example 17: PHI Film Editing Rhythm

**Problem:** Determine shot durations for a PHI-rhythmic edit.

**Given:**
- Scene duration: 60 seconds
- Average shot length (ASL): 3 seconds

**Solution:**

```
PHI-shot duration distribution:
  Long shots: phi^0 = 1.000 * ASL = 3.0 seconds
  Medium shots: phi^(-1) = 0.618 * ASL = 1.85 seconds
  Short shots: phi^(-2) = 0.382 * ASL = 1.15 seconds

Shot count (for 60 seconds):
  If all long: 60/3 = 20 shots
  If PHI-distributed:
    Long: 20 * phi^(-1) = 12.4 -> 12 shots (36 seconds)
    Medium: 20 * phi^(-2) = 7.6 -> 8 shots (14.8 seconds)
    Short: 20 * phi^(-3) = 4.7 -> 5 shots (5.75 seconds)
    Total: 12 + 8 + 5 = 25 shots (56.55 seconds, close to 60)

Editing rhythm:
  3.0 - 1.85 - 1.15 - 3.0 - 1.85 - 1.15 - ...
  = phi^0 - phi^(-1) - phi^(-2) - phi^0 - phi^(-1) - phi^(-2)
```

---

## Example 18: PHI Museum Exhibition Design

**Problem:** Design exhibit flow with PHI-proportional time allocation.

**Given:**
- Total visit time: 120 minutes
- Exhibit sections: 5

**Solution:**

```
PHI-time allocation:
  Section 1 (Intro): phi^3 = 4.236
  Section 2 (Main): phi^2 = 2.618
  Section 3 (Deep): phi = 1.618
  Section 4 (Interactive): 1.000
  Section 5 (Gift shop): phi^(-1) = 0.618

Total weight = 10.090

Time per section:
  Intro: 4.236/10.090 * 120 = 50.4 minutes
  Main: 2.618/10.090 * 120 = 31.1 minutes
  Deep: 1.618/10.090 * 120 = 19.2 minutes
  Interactive: 1.000/10.090 * 120 = 11.9 minutes
  Gift shop: 0.618/10.090 * 120 = 7.4 minutes

Verification: 50.4 + 31.1 + 19.2 + 11.9 + 7.4 = 120 minutes

Note: The intro is longest (establishing context), gift shop shortest.
This matches optimal museum flow research.
```

---

## Example 19: PHI Social Media Post Timing

**Problem:** Optimize posting schedule for maximum engagement.

**Given:**
- Target audience: 8-hour active window
- PHI post distribution

**Solution:**

```
Post timing (8-hour window = 480 minutes):
  Post 1: phi^0 = 1.000 * (480/phi^3) = 113.3 minutes from start
  Post 2: phi^(-1) = 0.618 * 113.3 = 70.0 minutes later
  Post 3: phi^(-2) = 0.382 * 113.3 = 43.3 minutes later
  Post 4: phi^(-3) = 0.236 * 113.3 = 26.7 minutes later

Schedule (starting 9 AM):
  Post 1: 10:53 AM (113 min after 9:00)
  Post 2: 12:03 PM (70 min later)
  Post 3: 12:46 PM (43 min later)
  Post 4: 1:13 PM (27 min later)

Engagement prediction:
  Post 1: phi^0 = 1.000 (highest -- optimal timing)
  Post 2: phi^(-1) = 0.618
  Post 3: phi^(-2) = 0.382
  Post 4: phi^(-3) = 0.236 (lowest -- diminishing returns)
```

---

## Example 20: PHI Wayfinding System

**Problem:** Design wayfinding signs with PHI-hierarchy.

**Given:**
- Building: 5 floors
- Sign types: Directory, Floor map, Directional, Room number

**Solution:**

```
Sign hierarchy:
  Directory: phi^0 = 1.000 (largest, most prominent)
  Floor map: phi^(-1) = 0.618
  Directional: phi^(-2) = 0.382
  Room number: phi^(-3) = 0.236 (smallest)

Sign sizes (if Directory = 100cm):
  Directory: 100 cm
  Floor map: 61.8 cm
  Directional: 38.2 cm
  Room number: 23.6 cm

Placement density:
  Directory: 1 per entrance (phi^0 = 1.000)
  Floor map: phi = 1.618 per floor -> 2 per floor
  Directional: phi^2 = 2.618 per hallway -> 3 per hallway
  Room number: phi^3 = 4.236 per room -> 4 per room

Total signs for 5-floor building:
  Directories: 2 (entrances)
  Floor maps: 10 (2 per floor)
  Directional: 30 (3 per hallway, 6 hallways)
  Room numbers: 100 (4 per room, 25 rooms)
  Total: 142 signs
```

---

## Summary Table: PHI Semiotics Examples

| # | Domain | PHI-concept | Result |
|---|--------|-------------|--------|
| 1 | Sign theory | Triadic distribution | 50:30.9:19.1% |
| 2 | Visual design | Hierarchy weights | phi^0 to phi^-4 |
| 3 | Color theory | Palette balance | 61.8:23.6:14.6% |
| 4 | Narrative | Plot arc | phi^3:phi^2:phi:1:phi^-1 |
| 5 | Advertising | Message structure | 50:30.9:19.1% |
| 6 | Branding | Consistency score | 80.4% |
| 7 | Literary | Intertextual density | D = references/(phi*length) |
| 8 | Digital | Meme half-life | 1.44 days |
| 9 | UX design | Navigation depth | floor(phi^3) = 4 |
| 10 | Film | Emotional arc | 75% climax position |
| 11 | Religious art | Mandala radii | phi-scaled circles |
| 12 | Medical | Symptom weighting | phi^-rank confidence |
| 13 | Fashion | Capsule wardrobe | 15:9:6 pieces |
| 14 | Legal | Contract analysis | 25:15:10 clauses |
| 15 | Academic | Paper structure | 3578:2213:1366:845 words |
| 16 | E-commerce | Site architecture | 3 clicks to product |
| 17 | Film editing | Shot rhythm | phi^0:phi^-1:phi^-2 |
| 18 | Museums | Exhibit flow | 50:31:19:12:7 minutes |
| 19 | Social media | Post timing | phi-decaying intervals |
| 20 | Wayfinding | Sign hierarchy | 100:62:38:24 cm |

---

*This document is part of the PHI-Physics Dictionary, Directory 55: PHI-Semiotics.*
*Total lines: 500+*
