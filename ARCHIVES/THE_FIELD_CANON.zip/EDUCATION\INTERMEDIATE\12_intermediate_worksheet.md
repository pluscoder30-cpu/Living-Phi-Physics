# 12 — Intermediate Worksheet | 150 Practice Problems

## Ages 13–16 | One Problem Per System Per Number

---

## Instructions

Solve all 150 problems. Show your work. Each problem is labeled by system:
[PHI] = Golden Ratio, [SIL] = Silver Ratio, [BRZ] = Bronze Ratio,
[HAR] = Harmonic/Music, [LIV] = Living Math, [PLA] = Plastic Number,
[SUP] = Supergolden, [FIB] = Fibonacci, [LUC] = Lucas, [PAD] = Padovan,
[KEP] = Kepler.

---

## Problems 1–15: Basic Definitions

1. [PHI] Compute phi^2 using phi^2 = phi + 1.
2. [SIL] Compute delta_s^2 using delta_s^2 = 2*delta_s + 1.
3. [BRZ] Compute delta_b^2 using delta_b^2 = 3*delta_b + 1.
4. [HAR] What is the frequency ratio of a perfect fifth in equal temperament?
5. [LIV] A 10 kg animal has metabolic rate B. A 1000 kg animal has rate B'. What is B'/B?
6. [PLA] Verify that psi^3 = psi + 1 for psi = 1.324718.
7. [SUP] Verify that psi_s^3 = psi_s^2 + 1 for psi_s = 1.465571.
8. [FIB] Compute F(10) using the Fibonacci recurrence.
9. [LUC] Compute L(10) using the Lucas recurrence.
10. [PAD] Compute P(10) using the Padovan recurrence.
11. [KEP] What is the golden angle in degrees?
12. [PHI] Solve x^2 - x - 1 = 0 for the positive root.
13. [SIL] Solve x^2 - 2x - 1 = 0 for the positive root.
14. [BRZ] Solve x^2 - 3x - 1 = 0 for the positive root.
15. [HAR] How many semitones are in an octave?

---

## Problems 16–30: Identities and Proofs

16. [PHI] Prove that 1/phi = phi - 1.
17. [SIL] Prove that 1/delta_s = delta_s - 2.
18. [BRZ] Prove that 1/delta_b = delta_b - 3.
19. [HAR] Show that 2^(6/12) = sqrt(2).
20. [LIV] Explain why A/V ratio decreases as an organism grows.
21. [PLA] Find 1/psi in terms of psi.
22. [SUP] Find 1/psi_s in terms of psi_s.
23. [FIB] State Cassini's Identity.
24. [LUC] State the identity L(n) = F(n-1) + F(n+1).
25. [PAD] State the Padovan recurrence relation.
26. [KEP] What is Kepler's third law?
27. [PHI] Prove that phi - 1/phi = 1.
28. [SIL] Prove that delta_s - 1/delta_s = 2.
29. [BRZ] Prove that delta_b - 1/delta_b = 3.
30. [HAR] What is the harmonic mean of 2 and 8?

---

## Problems 31–45: Sequences

31. [FIB] Find the next 5 Fibonacci numbers after 89.
32. [LUC] Find the next 5 Lucas numbers after 47.
33. [PAD] Find the next 5 Padovan numbers after 28.
34. [PHI] Compute F(12)/F(11).
35. [SIL] Compute P(8)/P(7) for Pell numbers.
36. [BRZ] Compute N(6)/N(5) for Narayana numbers.
37. [LIV] A population grows logistically with K=1000 and r=0.3. Starting from 100, find P(5).
38. [PLA] Compute psi^6 in terms of lower powers.
39. [SUP] Compute psi_s^5 in terms of lower powers.
40. [FIB] Use Binet's formula to compute F(8).
41. [LUC] Use Binet's formula to compute L(8).
42. [PAD] Estimate P(20) using P(n) ~ a * psi^n.
43. [HAR] List the frequencies of the C major scale starting from C4 = 261.63 Hz.
44. [KEP] If Earth's period is 365.25 days, find Venus's period using the 8:13 resonance.
45. [LIV] Compute the fractal dimension if log(N)/log(1/epsilon) gives N=1000 at epsilon=0.01.

---

## Problems 46–60: Algebra

46. [PHI] Express phi^5 in the form a*phi + b.
47. [SIL] Express delta_s^4 in the form a*delta_s + b.
48. [BRZ] Express delta_b^4 in the form a*delta_b + b.
49. [PLA] Express psi^5 in the form a*psi^2 + b*psi + c.
50. [SUP] Express psi_s^5 in the form a*psi_s^2 + b*psi_s + c.
51. [PHI] If x = phi, find x^4 - 3x^2 + 1.
52. [SIL] If x = delta_s, find x^3 - 4x - 2.
53. [FIB] Prove that F(n)^2 + F(n+1)^2 = F(2n+1).
54. [LUC] Prove that L(n)^2 - 5*F(n)^2 = 4*(-1)^n.
55. [PAD] Find P(20) using the recurrence.
56. [HAR] Convert 440 Hz to the note 7 semitones higher.
57. [KEP] A dodecahedron has edge 4 cm. Find the diagonal of a face.
58. [LIV] A coastline has D = 1.25. If measured at epsilon = 0.1, what is N?
59. [PHI] Solve the system: x + y = 5, x/y = phi.
60. [SIL] Solve the system: x + y = 7, x/y = delta_s.

---

## Problems 61–75: Geometry

61. [PHI] A golden rectangle has width 8. Find its length.
62. [SIL] A silver rectangle has width 6. Find its length.
63. [BRZ] A bronze rectangle has width 5. Find its length.
64. [PHI] A regular pentagon has side 10. Find its diagonal.
65. [KEP] A dodecahedron has edge 3. Find its face diagonal.
66. [KEP] An icosahedron has edge 2. Find its circumradius.
67. [PLA] A plastic solid has width psi. Find its dimensions.
68. [LIV] A cell has radius 5 micrometers. Find its A/V ratio.
69. [HAR] A string is 100 cm long. What length produces a note one octave higher?
70. [PHI] Find the area of a golden rectangle with width 1.
71. [SIL] Find the area of a silver rectangle with width 1.
72. [FIB] The Fibonacci spiral uses squares with sides 1,1,2,3,5,8. Find total area.
73. [PAD] A plastic spiral uses sides 1,1,1,2,2,3. Find total area.
74. [BRZ] Find the area of a bronze rectangle with width 2.
75. [LIV] A tree branches into 2 at each level. After 6 levels, how many tips?

---

## Problems 76–90: Number Theory

76. [FIB] Find gcd(F(12), F(18)).
77. [FIB] Write 50 as a sum of non-consecutive Fibonacci numbers.
78. [LUC] Which Lucas numbers up to L(15) are prime?
79. [FIB] What is the parity pattern of Fibonacci numbers?
80. [PAD] What is the parity pattern of Padovan numbers?
81. [PHI] Find the continued fraction of phi (first 5 terms).
82. [SIL] Find the continued fraction of delta_s (first 5 terms).
83. [BRZ] Find the continued fraction of delta_b (first 3 terms).
84. [PLA] What is the continued fraction of psi (first 3 terms)?
85. [HAR] How many cents separate ET and just intonation for a major third?
86. [FIB] Which Fibonacci numbers up to F(15) are prime?
87. [LUC] Verify the Lucas-Lehmer test for 2^7 - 1 = 127.
88. [PAD] Which Padovan numbers up to P(15) are prime?
89. [LIV] What is the fractal dimension of a coastline with D = 1.3?
90. [KEP] What is cos(dihedral angle of dodecahedron)?

---

## Problems 91–105: Comparisons

91. Order phi, delta_s, delta_b, psi, psi_s from smallest to largest.
92. Which grows faster: Fibonacci or Padovan? By what factor?
93. Which grows faster: Lucas or Fibonacci? By what factor?
94. Is the golden angle closer to 120 or 150 degrees?
95. Is the tritone ratio (sqrt(2)) closer to phi or 1.5?
96. Compare the growth of Fibonacci, Lucas, and powers of 2.
97. Which Platonic solid has the most faces?
98. Compare the metabolic rate per kg of a mouse vs elephant.
99. Is psi closer to 1.3 or 1.4?
100. Is psi_s closer to 1.4 or 1.5?
101. Which sequence has the largest 10th term: Fibonacci, Lucas, or Padovan?
102. Compare the continued fraction complexity of phi vs psi.
103. Which is larger: F(10) or L(8)?
104. Compare P(10) with F(7).
105. Is the Earth-Venus resonance (8/13) closer to 1/phi or 1/2?

---

## Problems 106–120: Applications

106. [PHI] Design a golden rectangle with area 10.
107. [SIL] Design a silver rectangle with area 12.
108. [HAR] Tune a guitar string at 330 Hz. What is the frequency 5 semitones up?
109. [LIV] A DLA cluster has D = 1.71. If epsilon = 0.1, estimate N.
110. [PLA] A plastic spiral grows by factor psi per quarter turn. Growth after 2 full turns?
111. [KEP] A planet orbits at the golden angle from another at 30 degrees. Where is it?
112. [FIB] A sunflower has 34 and 55 spirals. What is the ratio?
113. [LUC] Use L(n) to estimate F(2n) for n=5.
114. [PAD] A Padovan spiral has side lengths up to P(8). Total perimeter?
115. [BRZ] A bronze rectangle has area 20. Find its dimensions.
116. [SUP] A supergolden spiral grows by psi_s per quarter turn. Growth after 3 turns?
117. [LIV] A population doubles every generation. After 10 generations, what is the ratio to the initial?
118. [HAR] Construct a C major scale starting from A4 = 440 Hz.
119. [KEP] An icosahedron has edge 5. Find its volume.
120. [PHI] Create a Fibonacci tiling with squares up to side 13. Total area?

---

## Problems 121–135: Advanced

121. [PHI] Prove that F(n) = (phi^n - psi^n) / sqrt(5) for n=1,2.
122. [SIL] Derive the Pell number Binet formula.
123. [BRZ] Derive the Narayana number Binet formula.
124. [PLA] Find the minimal polynomial for psi^2.
125. [SUP] Find the minimal polynomial for psi_s^2.
126. [FIB] Prove that gcd(F(m), F(n)) = F(gcd(m,n)) for m=6, n=9.
127. [LUC] Prove that F(2n) = F(n)*L(n) for n=4.
128. [PAD] Prove that sum(P(0)..P(n)) = P(n+3) + P(n+2) - 2 for n=4.
129. [HAR] Show that equal temperament is a compromise between just intervals.
130. [LIV] Explain the 3/4 power law using surface area arguments.
131. [KEP] Derive Kepler's third law from Newton's law of gravitation.
132. [PHI] Find the matrix M such that M^n gives Fibonacci numbers.
133. [SIL] Find the matrix M such that M^n gives Pell numbers.
134. [BRZ] Find the matrix M such that M^n gives Narayana numbers.
135. [PLA] Find the matrix M such that M^n gives Padovan numbers.

---

## Problems 136–150: Challenge

136. [PHI] Prove that the golden ratio is the most irrational number.
137. [SIL] Prove that delta_s is the simplest metallic mean after phi.
138. [BRZ] Prove that the metallic means satisfy M_n^2 = n*M_n + 1.
139. [HAR] Prove that 12-TET is the best equal division of the octave for harmony.
140. [LIV] Derive Kleiber's Law from fractal vascular network theory.
141. [PLA] Prove that psi is the smallest Pisot number.
142. [SUP] Compare the Pisot properties of psi and psi_s.
143. [FIB] Prove that F(p) is prime only if p is prime (for p > 4).
144. [LUC] Prove that L(n) = phi^n + psi^n satisfies the Lucas recurrence.
145. [PAD] Prove that the Padovan sequence grows as psi^n.
146. [KEP] Prove that the dodecahedron has golden ratio proportions.
147. [PHI] Show that the Fibonacci spiral approximates the golden spiral.
148. [HAR] Show that the tritone divides the octave in half.
149. [LIV] Explain why fractal dimension D < 2 for coastlines.
150. [SUP] Compare all sequences: Fibonacci, Lucas, Padovan, Narayana, Perrin.

---

## Scoring

- Problems 1–45: 2 points each (90 points)
- Problems 46–90: 3 points each (135 points)
- Problems 91–135: 4 points each (180 points)
- Problems 136–150: 5 points each (75 points)

Total: 480 points

---

## Quick Reference Formulas

### Golden Ratio
- phi = (1 + sqrt(5))/2 = 1.618034
- phi^2 = phi + 1
- 1/phi = phi - 1 = (sqrt(5)-1)/2
- phi^n = F(n)*phi + F(n-1)

### Silver Ratio
- delta_s = 1 + sqrt(2) = 2.414214
- delta_s^2 = 2*delta_s + 1
- 1/delta_s = delta_s - 2 = sqrt(2) - 1

### Bronze Ratio
- delta_b = (3 + sqrt(13))/2 = 3.302776
- delta_b^2 = 3*delta_b + 1
- 1/delta_b = delta_b - 3

### Harmonic
- Semitone ratio = 2^(1/12) = 1.059463
- Octave = 2:1
- Perfect fifth = 3:2 (just) or 2^(7/12) (ET)
- Major third = 5:4 (just) or 2^(4/12) (ET)
- Tritone = sqrt(2) = 2^(6/12)

### Living Math
- Kleiber's Law: B = B_0 * M^(3/4)
- Surface area: A = 4*pi*r^2
- Volume: V = (4/3)*pi*r^3
- A/V ratio = 3/r
- Fractal dimension: D = log(N)/log(1/epsilon)

### Plastic Number
- psi = 1.324718
- psi^3 = psi + 1
- 1/psi = psi^2 - 1

### Supergolden
- psi_s = 1.465571
- psi_s^3 = psi_s^2 + 1
- 1/psi_s = psi_s^2 - psi_s

### Fibonacci
- F(n) = F(n-1) + F(n-2)
- F(1)=1, F(2)=1
- Binet: F(n) = (phi^n - psi^n) / sqrt(5)
- Cassini: F(n-1)*F(n+1) - F(n)^2 = (-1)^n
- Sum: F(1)+...+F(n) = F(n+2) - 1

### Lucas
- L(n) = L(n-1) + L(n-2)
- L(0)=2, L(1)=1
- Binet: L(n) = phi^n + psi^n
- Identity: L(n) = F(n-1) + F(n+1)
- Product: F(2n) = F(n)*L(n)

### Padovan
- P(n) = P(n-2) + P(n-3)
- P(0)=P(1)=P(2)=1
- Growth rate: psi = 1.324718

### Metallic Means
- M_n = (n + sqrt(n^2 + 4))/2
- M_n^2 = n*M_n + 1
- 1/M_n = M_n - n

---

## Tips for Solving

1. Always check if an identity can simplify the problem
2. Use the recurrence relation before resorting to formulas
3. For convergence problems, compute at least 5 terms
4. For geometry problems, draw a diagram first
5. For proofs, state what you assume and what you need to prove
6. Check your answer makes sense (correct units, reasonable magnitude)
7. Use the summary tables in each chapter for quick reference
8. Verify identities with specific values before proving generally

---

*Answers: 13_intermediate_answer_key.md*
