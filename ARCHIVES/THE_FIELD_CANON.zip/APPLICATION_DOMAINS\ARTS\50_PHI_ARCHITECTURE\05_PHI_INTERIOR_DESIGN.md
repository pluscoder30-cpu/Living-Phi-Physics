# PHI-INTERIOR DESIGN

## 1. PHI-Interior Principles

### 1.1 The PHI-Space

An interior space governed by phi feels naturally balanced, comfortable, and aesthetically satisfying. The golden ratio phi = 1.6180339887 governs the relationships between room dimensions, furniture placement, color distribution, and material selection.

### 1.2 The PHI-Room Formula

```
PHI-Room proportions:

Room width : Room length = 1 : phi
Room length : Room height = phi : 1
Room width : Room height = 1 : 1 (cube)

For a room of width W:
  Length = W x phi
  Height = W
  
  Example (W = 4.0 m):
    Length = 4.0 x phi = 6.47 m
    Height = 4.0 m
    
  The phi-rectangle room:
    Feels neither too deep nor too shallow
    Has a natural sense of direction
    Allows furniture arrangement at phi-points
```

## 2. PHI-Furniture Design

### 2.1 PHI-Table Proportions

```
PHI-Dining table:

Table length : Table width = phi : 1

For a table of width W:
  Length = W x phi
  
  Example (W = 0.9 m):
    Length = 0.9 x phi = 1.46 m (seats 4-6)
    
  Table height : Table width = 1 : phi
    Height = 0.9 / phi = 0.56 m (too low)
    
  Better: Table height = 0.75 m (standard)
  PHI: Table height = 0.9 / phi^0 = 0.9 m (counter height)
  
  Seat height : Table height = 1 : phi
    Seat = 0.75 / phi = 0.46 m (standard)
```

### 2.2 PHI-Desk Design

```
PHI-Desk:

Desk width : Desk depth = phi : 1

For a desk of depth D:
  Width = D x phi
  
  Example (D = 0.7 m):
    Width = 0.7 x phi = 1.13 m
    
  Desk height : Desk width = 1 : phi^2
    Height = 1.13 / phi^2 = 0.43 m (too low)
    
  Better: Desk height = 0.75 m (standard)
  PHI: Desk height = 1.13 / phi = 0.70 m (slightly low but ergonomic)
    
  Monitor distance : Desk depth = phi : 1
    Monitor distance = 0.7 x phi = 1.13 m (too far)
    
  Better: Monitor distance = 0.7 m (standard)
  PHI: Monitor distance = 0.7 / phi = 0.43 m (close but OK for large monitor)
```

### 2.3 PHI-Bookshelf

```
PHI-Bookshelf:

Shelf width : Shelf height = 1 : phi

For a shelf of height H:
  Width = H x phi
  
  Example (H = 0.3 m):
    Width = 0.3 x phi = 0.49 m (narrow)
    
  Better: Shelf width = 0.9 m (standard)
  PHI: Shelf height = 0.9 / phi = 0.56 m (tall shelf)
    
  Shelf depth : Book height = phi : 1
    For books of height 0.25 m:
    Shelf depth = 0.25 x phi = 0.41 m (deep)
    
  Better: Shelf depth = 0.3 m (standard)
  PHI: Shelf depth = 0.25 x 1.0 = 0.25 m (standard)
```

## 3. PHI-Color in Interiors

### 3.1 PHI-Color Distribution

```
PHI-Room color:

Wall color : Floor color : Ceiling color = phi^2 : phi : 1

For a room of total color area A:
  Walls: A x phi^2 / (phi^2 + phi + 1) = 55.9% of A
  Floor: A x phi / (phi^2 + phi + 1) = 34.5% of A
  Ceiling: A x 1 / (phi^2 + phi + 1) = 9.6% of A
  
  Example (A = 100 m²):
    Walls: 55.9 m² (warm mid-tone)
    Floor: 34.5 m² (dark natural)
    Ceiling: 9.6 m² (light neutral)
    
  The phi-color distribution:
    Grounds the space (dark floor)
    Envelopes the occupant (warm walls)
    Opens upward (light ceiling)
```

### 3.2 PHI-Accent Colors

```
PHI-Accent color:

Dominant : Accent = phi : 1

For a dominant color area D:
  Accent = D / phi
  
  Example (D = 55.9 m²):
    Accent = 55.9 / phi = 34.5 m² (too much for accent)
    
  Better: Dominant : Accent = phi^2 : 1
    Accent = 55.9 / phi^2 = 21.4 m² (still a lot)
    
  Practical: Accent = 14.6% of total color area
  PHI-accent = 14.6% x phi = 23.6% (slightly more)
```

### 3.3 PHI-Textile Colors

```
PHI-Textile color hierarchy:

Primary textile: 61.8% of textile area (sofa, curtains)
Secondary textile: 23.6% (throw pillows, rugs)
Accent textile: 14.6% (art, plants)

Color temperature:
  Primary: warm (2700K equivalent)
  Secondary: neutral (3500K equivalent)
  Accent: cool (5000K equivalent)
  
  The phi-temperature hierarchy:
    Warm dominant (comfortable)
    Neutral secondary (balanced)
    Cool accent (refreshing)
```

## 4. PHI-Lighting Design

### 4.1 PHI-Light Layering

```
PHI-Light layers:

Ambient : Task : Accent = phi^2 : phi : 1

For a total light output L:
  Ambient: L x phi^2 / (phi^2 + phi + 1) = 55.9% of L
  Task: L x phi / (phi^2 + phi + 1) = 34.5% of L
  Accent: L x 1 / (phi^2 + phi + 1) = 9.6% of L
  
  Example (L = 3000 lumens):
    Ambient: 1677 lumens (general illumination)
    Task: 1035 lumens (desk, reading)
    Accent: 288 lumens (art, plants)
    
  The phi-lighting:
    Provides adequate general light
    Focuses task light where needed
    Highlights accents with restraint
```

### 4.2 PHI-Fixture Placement

```
PHI-Fixture spacing:

Fixture spacing : Fixture height = phi : 1

For a fixture mounted at height H:
  Spacing = H x phi
  
  Example (H = 2.4 m ceiling):
    Spacing = 2.4 x phi = 3.88 m
    
  Fixture distance from wall : Fixture spacing = 1 : phi
    Distance = 3.88 / phi = 2.40 m
    
  The phi-placement creates:
    Even illumination without hot spots
    Natural rhythm of light pools
    Balance between wall and center lighting
```

### 4.3 PHI-Color Temperature

```
PHI-Color temperature zones:

Daylight zone: 5000-6500 K (blue-white)
Transition zone: 3500-5000 K (neutral)
Warm zone: 2700-3500 K (warm white)

PHI-temperature boundaries:
  Daylight/Transition: 5000/phi = 3090 K (round to 3100 K)
  Transition/Warm: 3500/phi = 2162 K (round to 2200 K)
  
  The phi-zones create:
    Bright, alert areas (daylight)
    Comfortable working areas (transition)
    Relaxing, intimate areas (warm)
```

## 5. PHI-Material Selection

### 5.1 PHI-Material Palette

```
PHI-Material palette:

Material type : Quantity = phi-weighted

Wood: 61.8% of material surface (dominant)
Stone: 23.6% (secondary)
Metal: 14.6% (accent)

Example (total material surface = 100 m²):
  Wood: 61.8 m² (floors, furniture, trim)
  Stone: 23.6 m² (countertops, fireplace, feature wall)
  Metal: 14.6 m² (fixtures, hardware, accents)
```

### 5.2 PHI-Material Texture

```
PHI-Texture balance:

Smooth : Textured = phi : 1

For a total surface S:
  Smooth: S x phi / (1 + phi) = 61.8%
  Textured: S / (1 + phi) = 38.2%
  
  Example (S = 100 m²):
    Smooth: 61.8 m² (painted walls, glass, metal)
    Textured: 38.2 m² (stone, wood grain, fabric)
    
  The phi-texture creates:
    Visual rest (smooth majority)
    Tactile interest (textured minority)
    Balance between calm and stimulation
```

### 5.3 PHI-Material Finish

```
PHI-Finish levels:

Matte : Satin : Glossy = phi^2 : phi : 1

For a total finish surface S:
  Matte: S x phi^2 / (phi^2 + phi + 1) = 55.9%
  Satin: S x phi / (phi^2 + phi + 1) = 34.5%
  Glossy: S x 1 / (phi^2 + phi + 1) = 9.6%
  
  Example (S = 100 m²):
    Matte: 55.9 m² (walls, ceilings, most surfaces)
    Satin: 34.5 m² (floors, furniture)
    Glossy: 9.6 m² (mirrors, metal accents)
    
  The phi-finish creates:
    Soft, diffused light (matte majority)
    Subtle reflection (satin minority)
    Sparkle and focus (glossy accents)
```

## 6. PHI-Room Types

### 6.1 PHI-Living Room

```
PHI-Living room layout:

Seating area : Circulation area = phi : 1

For a total floor area F:
  Seating: F x phi / (1 + phi) = 61.8%
  Circulation: F / (1 + phi) = 38.2%
  
  Example (F = 30 m²):
    Seating: 18.5 m²
    Circulation: 11.5 m²
    
  Furniture arrangement:
    Sofa : Coffee table distance = phi : 1
    Sofa length : Armchair length = phi : 1
    Rug width : Room width = 1 : phi
```

### 6.2 PHI-Kitchen

```
PHI-Kitchen layout:

Work triangle perimeter : Room perimeter = 1 : phi

For a room of perimeter P:
  Work triangle = P / phi
  
  Example (P = 20 m):
    Work triangle = 20 / phi = 12.4 m
    
  Counter height : Counter depth = phi : 1
    Height = 0.9 m (standard)
    Depth = 0.9 / phi = 0.56 m (standard)
    
  Upper cabinet height : Lower cabinet height = 1 : phi
    Upper = 0.75 m
    Lower = 0.75 x phi = 1.21 m (including countertop)
```

### 6.3 PHI-Bedroom

```
PHI-Bedroom layout:

Bed area : Remaining area = 1 : phi

For a total floor area F:
  Bed area = F / (1 + phi) = 38.2%
  Remaining = F x phi / (1 + phi) = 61.8%
  
  Example (F = 20 m²):
    Bed area: 7.6 m² (bed + nightstands)
    Remaining: 12.4 m² (dresser, seating, circulation)
    
  Bed proportions:
    Width : Length = 1 : phi
    Standard double: 1.4 x 2.2 m (ratio 1.571, close to phi)
    PHI-double: 1.4 x 2.27 m (exact phi)
    
  Nightstand height : Bed height = phi : 1
    Nightstand = 0.65 m
    Bed = 0.65 / phi = 0.40 m (mattress height)
```

## 7. PHI-Retail Interiors

### 7.1 PHI-Store Layout

```
PHI-Store layout:

Display area : Circulation area = phi : 1

For a total floor area F:
  Display: F x phi / (1 + phi) = 61.8%
  Circulation: F / (1 + phi) = 38.2%
  
  Example (F = 500 m²):
    Display: 309 m²
    Circulation: 191 m²
    
  Fixture height : Eye height = phi : 1
    Fixture = 1.6 m (eye height) x phi = 2.59 m (too tall)
    
  Better: Fixture height = 1.6 m (standard)
  PHI-fixture = 1.6 / phi = 0.99 m (counter height)
```

### 7.2 PHI-Restaurant

```
PHI-Restaurant layout:

Dining area : Service area = phi : 1

For a total floor area F:
  Dining: F x phi / (1 + phi) = 61.8%
  Service: F / (1 + phi) = 38.2%
  
  Table spacing : Table width = phi : 1
    For tables of width W:
    Spacing = W x phi
    
  Example (W = 0.9 m):
    Spacing = 0.9 x phi = 1.46 m (between tables)
    
  Booth depth : Table width = phi : 1
    Booth = 0.9 x phi = 1.46 m (deep booth)
```

### 7.3 PHI-Office

```
PHI-Office layout:

Workstation : Support = phi : 1

For a total floor area F:
  Workstation: F x phi / (1 + phi) = 61.8%
  Support: F / (1 + phi) = 38.2%
  
  Example (F = 1000 m²):
    Workstation: 618 m²
    Support: 382 m²
    
  Desk height : Chair height = phi : 1
    Desk = 0.75 m
    Chair = 0.75 / phi = 0.46 m (seat height)
    
  Monitor distance : Desk depth = phi : 1
    Monitor = 0.7 x phi = 1.13 m (too far)
    
  Better: Monitor distance = 0.7 m (standard)
```

## 8. PHI-Art and Accessories

### 8.1 PHI-Art Placement

```
PHI-Art hanging:

Art center height : Eye height = phi : 1

For eye height of 1.6 m:
  Art center = 1.6 x phi = 2.59 m (too high)
    
  Better: Art center = 1.6 / phi = 0.99 m (too low)
  
  Optimal: Art center = 1.57 m (57 inches, museum standard)
  PHI: Art center = 1.57 x phi = 2.54 m (too high)
  
  Practical: Art center = 1.5 m (standard)
  PHI-art center = 1.5 / phi = 0.93 m (slightly low)
```

### 8.2 PHI-Accent Objects

```
PHI-Accent object placement:

Object height : Shelf height = 1 : phi

For a shelf of height H:
  Object = H / phi
  
  Example (H = 0.3 m):
    Object = 0.3 / phi = 0.19 m (small object)
    
  Object spacing : Object width = phi : 1
    For objects of width W:
    Spacing = W x phi
    
  Example (W = 0.15 m):
    Spacing = 0.15 x phi = 0.24 m
```

### 8.3 PHI-Plant Placement

```
PHI-Plant placement:

Plant height : Room height = 1 : phi^2

For a room of height H:
  Plant = H / phi^2
  
  Example (H = 2.7 m):
    Plant = 2.7 / phi^2 = 1.03 m
    
  Plant : Window = 1 : phi
    For a window of height 1.5 m:
    Plant = 1.5 / phi = 0.93 m
    
  The phi-plant creates:
    Natural proportion to room
    Connection to window (light source)
    Human-scale greenery
```

## 9. PHI-Bathroom Design

### 9.1 PHI-Bathroom Layout

```
PHI-Bathroom:

Bathroom width : Bathroom length = 1 : phi

For a bathroom of width W:
  Length = W x phi
  
  Example (W = 1.8 m):
    Length = 1.8 x phi = 2.91 m
    
  Vanity height : Vanity depth = phi : 1
    Height = 0.85 m (standard)
    Depth = 0.85 / phi = 0.52 m (standard)
    
  Mirror height : Vanity height = phi : 1
    Mirror = 0.85 x phi = 1.37 m (tall mirror)
```

### 9.2 PHI-Shower Design

```
PHI-Shower:

Shower width : Shower depth = 1 : phi

For a shower of width W:
  Depth = W x phi
  
  Example (W = 0.9 m):
    Depth = 0.9 x phi = 1.46 m
    
  Showerhead height : Shower width = phi : 1
    Height = 0.9 x phi = 1.46 m (low)
    
  Better: Showerhead height = 2.0 m (standard)
  PHI: Showerhead height = 0.9 x phi^2 = 2.36 m (tall)
```

## 10. PHI-Interior Verification

### 10.1 PHI-Interior Score

```
Calculate a room's PHI-Interior Score:

Components (each 0-20):
  1. Room proportions (phi-ratio compliance)
  2. Furniture placement (phi-alignment)
  3. Color distribution (phi-weighting)
  4. Lighting layers (phi-layering)
  5. Material selection (phi-palette)

Total: /100
Target: > 61.8
```

### 10.2 PHI-Interior Checklist

```
[ ] Room proportions follow phi-ratio (1:phi)
[ ] Furniture at phi-intersections of room grid
[ ] Color areas follow phi-distribution (61.8/23.6/14.6)
[ ] Lighting layered at phi-ratios (ambient/task/accent)
[ ] Materials weighted by phi (wood:stone:metal = phi^2:phi:1)
[ ] Textures balanced at phi (smooth:textured = phi:1)
[ ] Finishes distributed at phi (matte:satin:glossy)
[ ] Plants at phi-proportions to room height
[ ] Art hung at phi-height
[ ] Overall feel: balanced, comfortable, harmonious
```

## References

- Kertis, J. (2015). "Interior Design: A Complete Guide"
- Tay, L. (2011). "Elements of Design"
- Bronson, G. (2012). "Home Design: How to Create the Perfect Living Space"
- Edwards, B. (2009). "The Interior Design Reference and Specification Book"
- Riley, T. (2003). "The Details: 1000 Decorative Details"
