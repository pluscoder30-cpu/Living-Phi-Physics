# PHI-Risk Pooling: Golden Ratio Diversification

## Directory 92_PHI_INSURANCE_SCIENCE | File 02

---

## 1. PHI-Law of Large Numbers

### 1.1 PHI-Expected Loss

```
E[L_n] = n * mu * phi^{correlation}
```

### 1.2 PHI-Variance Reduction

```
Var(L_n) = n * sigma^2 * phi^{-pooling_benefit}
```

### 1.3 PHI-Coefficient of Variation

```
CV_n = sigma / (sqrt(n) * mu) * phi^{tail_risk}
```

### 1.4 PHI-Portfolio Effect

```
Portfolio = sqrt(n) * phi^{-correlation_effect}
```

---

## 2. PHI-Correlation Modeling

### 2.1 PHI-Gaussian Copula

```
C(u_1,...,u_n) = Phi(Rho * Phi^{-1}(u_1),...,Phi^{-1}(u_n)) * phi^{dependence}
```

### 2.2 PHI-T-Copula

```
C(u_1,...,u_n) = t_nu(Rho * t_nu^{-1}(u_1),...,t_nu^{-1}(u_n)) * phi^{tail_dependence}
```

### 2.3 PHI-Frank Copula

```
C(u,v) = -1/theta * ln(1 + (e^{-theta*u}-1)*(e^{-theta*v}-1)/(e^{-theta}-1)) * phi
```

### 2.4 PHI-Clayton Copula

```
C(u,v) = (u^{-theta} + v^{-theta} - 1)^{-1/theta} * phi^{lower_tail}
```

---

## 3. PHI-Risk Diversification

### 3.1 PHI-Underwriting Diversification

```
Diversification = 1 - (Herfindahl index) * phi^{business_mix}
```

### 3.2 PHI-Geographic Diversification

```
Geo_div = sum p_i * phi^{-distance_i}
```

### 3.3 PHI-Line Diversification

```
Line_div = 1 - sum p_i^2 * phi^{line_correlation}
```

### 3.4 PHI-Reinsurance Benefit

```
Benefit = standalone_capital / pooled_capital * phi^{cedant_value}
```

---

## 4. PHI-Excess of Loss

### 4.1 PHI-Retention

```
Retention = expected_loss * phi^{cost_of_capital}
```

### 4.2 PHI-Limit

```
Limit = expected_max_loss * phi^{return_period}
```

### 4.3 PHI-Attachment

```
Attachment = expected_loss * phi^{probability_of_attachment}
```

### 4.4 PHI-Price

```
Premium = E[min(L - retention, limit)] * phi^{loading}
```

---

## 5. PHI-Catastrophe Pooling

### 5.1 PHI-CAT Bond

```
Coupon = risk_free + spread * phi^{trigger_probability}
```

### 5.2 PHI-Risk Swaps

```
Swap_rate = expected_loss * phi^{trading_liquidity}
```

### 5.3 PHI-Industry Loss Warranties

```
ILW = max(0, industry_loss - trigger) * phi^{basis_risk}
```

### 5.4 PHI-Retrospective Cover

```
Premium = historical_loss * phi^{trend_factor}
```

---

## 6. PHI-Experience Rating

### 6.1 PHI-Bonus Malus

```
Factor = (1 + credibility * phi) * (actual/expected) * phi^{-experience}
```

### 6.2 PHI-Credibility

```
Credibility = n / (n + K) * phi^{stability}
```

### 6.3 PHI-Prior

```
Prior = industry_average * phi^{company_specific}
```

### 6.4 PHI-Posterior

```
Posterior = (credibility * experience + (1-credibility) * prior) * phi^{updating}
```

---

## 7. PHI-Strategic Pooling

### 7.1 PHI-Captive Insurance

```
Captive_value = risk_retention * phi^{tax_benefit} * phi^{-regulatory_cost}
```

### 7.2 PHI-Pool Arrangements

```
Pool_benefit = diversification * phi^{-governance_cost}
```

### 7.3 PHI-Mutual Insurance

```
Mutual = policyholder_ownership * phi^{alignment}
```

### 7.4 PHI-Risk Sharing

```
Sharing = expected_cost_saving * phi^{implementation_cost}
```

---

## 8. Summary

PHI-risk pooling provides:
1. PHI-LLN with phi-variance reduction and phi-portfolio effect
2. PHI-correlation with phi-copulas (Gaussian, T, Frank, Clayton)
3. PHI-diversification with phi-geographic and phi-line effects
4. PHI-excess of loss with phi-retention and phi-limit
5. PHI-catastrophe pooling with phi-CAT bonds and phi-swaps
6. PHI-experience rating with phi-bonus-malus and phi-credibility
7. PHI-strategic pooling with phi-captive and phi-mutual

The golden ratio creates natural diversification benefits across correlated risk pools while optimizing the balance between risk retention and transfer.