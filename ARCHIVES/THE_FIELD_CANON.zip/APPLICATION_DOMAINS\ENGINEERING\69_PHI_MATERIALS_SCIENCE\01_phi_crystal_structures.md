# PHI-CRYSTAL STRUCTURES

## PHI-HARMONIC CRYSTALLOGRAPHY

### 1. Theoretical Foundation

The golden ratio phi = 1.6180339887... governs the geometry of crystal lattices at the fundamental level. While conventional crystallography restricts rotational symmetries to 2-fold, 3-fold, 4-fold, and 6-fold axes (due to translational periodicity), phi-harmonic crystallography reveals that phi provides a pathway to forbidden symmetries — 5-fold, 8-fold, 10-fold, and 12-fold — through quasi-periodic ordering.

The fundamental equation linking crystal stability to phi-harmonic resonance:

```
E_crystal(n) = E_0 * phi^(-n/phi) * cos(2*pi*n/phi^2)
```

Where:
- E_0 = baseline crystal energy
- n = lattice site index
- phi = golden ratio (1.6180339887...)
- The exponential decay phi^(-n/phi) ensures convergence
- The cosine term cos(2*pi*n/phi^2) encodes the phi-harmonic periodicity

This equation predicts that stable crystal configurations occur when the lattice parameter ratio approaches phi, explaining why quasicrystals — discovered by Dan Shechtman in 1982 — exhibit icosahedral symmetry with characteristic length ratios of phi.

The energy landscape of a phi-crystal contains self-similar basins at every scale. The depth of the n-th basin:

```
E_basin(n) = E_0 * (1 - phi^(-n))
```

For large n, E_basin approaches E_0 asymptotically. The first few basin depths:
- n=1: E_basin = E_0 * (1 - 0.618) = 0.382 * E_0
- n=2: E_basin = E_0 * (1 - 0.382) = 0.618 * E_0
- n=3: E_basin = E_0 * (1 - 0.236) = 0.764 * E_0
- n=5: E_basin = E_0 * (1 - 0.090) = 0.910 * E_0

The rapid convergence means that phi-crystals achieve 90% of their maximum stability within only 5 coordination shells.

### 2. The Phi-Lattice Equation

The position vector of the n-th atom in a phi-harmonic lattice:

```
r_n = sum_{k=1}^{3} a_k * phi^(n*e_k) * u_k
```

Where:
- a_k = lattice constants along k-th axis
- e_k = phi-exponent vector (e_k in {1, phi, phi^2})
- u_k = unit direction vector
- The sum runs over three spatial dimensions

The phi-exponent vector creates a self-similar hierarchy: each successive "shell" of the lattice is scaled by phi relative to the previous one. This produces a fractal-like crystal structure with long-range order but no translational periodicity — the defining characteristic of quasicrystals.

For a 2D phi-harmonic lattice with a_1 = a_2 = a and e_1 = 1, e_2 = 1/phi:

```
r_n = a * (phi^(n) * cos(n*2*pi*tau) + phi^(n/phi) * sin(n*2*pi*tau))
```

Where tau = 1/phi^2 = 0.382... is the inverse golden square. The coordinates of the first 10 lattice points:

```
n=0:  (a, 0)
n=1:  (1.618*a, 0.786*a)
n=2:  (2.618*a, 1.176*a)
n=3:  (4.236*a, 0.590*a)
n=4:  (6.854*a, 0.590*a)
n=5:  (11.09*a, 0.000*a)
```

The ratio of successive distances: |r_{n+1}|/|r_n| approaches phi for large n.

### 3. Forbidden Symmetry Restoration

Conventional crystallography forbids 5-fold symmetry because a regular pentagon cannot tile the plane without gaps. However, the Penrose tiling demonstrates that 5-fold symmetry CAN tile the plane aperiodically using two rhombus shapes with edge ratio phi.

The phi-harmonic symmetry operation:

```
R_5(theta) * psi(r) = psi(r * e^{i*2*pi/5}) = phi^(-1/5) * psi(r)
```

This equation states that a 5-fold rotation of the wavefunction psi produces not an identical state (which would violate translational symmetry) but a phi-scaled state. The factor phi^(-1/5) = 0.8846 represents the "scaling cost" of the forbidden rotation.

For a crystal to support 5-fold symmetry, its electronic wavefunction must satisfy:

```
int_V |psi(r)|^2 d^3r = 1 (normalization)
psi(r * e^{i*2*pi/5}) = phi^(-1/5) * psi(r) (phi-harmonic condition)
```

The number of independent wavefunctions satisfying these conditions for a crystal with N atoms:

```
N_independent = N / phi = N * 0.618
```

This means 38.2% of the electronic states are "forbidden" in conventional theory but become allowed under phi-harmonic conditions.

### 4. Quasicrystal Energy Spectrum

The electronic energy levels of a phi-harmonic quasicrystal form a Cantor set — a fractal spectrum with gaps at every scale. The energy gap ratios follow:

```
Delta_E_n / Delta_E_{n+1} = phi^2 = 2.6180339887...
```

This self-similar gap structure is the spectral signature of phi-harmonic order. It explains why quasicrystals exhibit:
- Anomalous electronic transport (diffusive despite being ordered)
- Unique optical properties (photonic band gaps at phi-related frequencies)
- Unusual mechanical properties (intermediate between crystalline and amorphous)

The density of states at energy E:

```
g(E) = g_0 * |E - E_0|^(-1/phi) * exp(-|E - E_0|/W)
```

Where W = bandwidth. The power-law singularity at E = E_0 is characteristic of the Cantor set spectrum and produces enhanced conductivity at the band center.

The fraction of the spectrum that is gap:

```
f_gap = 1 - 1/phi = 0.382 = 38.2%
```

This means 38.2% of all electronic energies are forbidden — a remarkably high fraction compared to periodic crystals (where band gaps typically occupy less than 10% of the spectrum).

### 5. Phi-Modulated Bond Angles

In phi-harmonic crystals, the bond angle theta between nearest neighbors is:

```
theta_n = arccos(phi^(-1) * cos(n*pi/phi)) = arccos(0.618 * cos(n*pi/1.618))
```

For the first few shells:
- theta_0 = arccos(0.618 * cos(0)) = arccos(0.618) = 51.83 degrees
- theta_1 = arccos(0.618 * cos(pi/1.618)) = arccos(0.618 * cos(110.57)) = 86.18 degrees
- theta_2 = arccos(0.618 * cos(2*pi/1.618)) = 128.17 degrees
- theta_3 = arccos(0.618 * cos(3*pi/1.618)) = 159.41 degrees
- theta_4 = arccos(0.618 * cos(4*pi/1.618)) = 178.72 degrees

The angle 51.83 degrees is precisely the dihedral angle of a regular icosahedron — explaining why icosahedral symmetry dominates phi-harmonic crystal structures.

The bond angle distribution function:

```
P(theta) = (1/sigma_phi) * sum_n delta(theta - theta_n) * exp(-n/phi)
```

Where sigma_phi is a normalization factor. The exponential weighting means shorter bonds (smaller theta) contribute more to the structure factor.

### 6. Phi-Cluster Assembly

The minimum energy configuration of N atoms arranged in phi-harmonic clusters follows:

```
E_cluster(N) = N * epsilon_bond * (1 - phi^(-N/N_0))
```

Where:
- epsilon_bond = characteristic bond energy
- N_0 = phi^3 = 4.236 (the "magic number" for cluster closure)

This equation predicts that cluster stability increases with size but saturates at a value determined by phi^3. Clusters with N = phi^3 * m atoms (m = 1, 2, 3, ...) are particularly stable — these correspond to closed-shell icosahedral clusters.

The magic numbers for phi-clusters:
- m=1: N = 4 (tetrahedron)
- m=2: N = 8 (cube/octahedron)
- m=3: N = 13 (icosahedron)
- m=4: N = 17
- m=5: N = 21
- m=6: N = 25
- m=7: N = 30
- m=10: N = 42

The binding energy per atom:

```
E_b(N) = E_b(inf) * (1 - phi^(-N/N_0))
```

Where E_b(inf) = bulk binding energy. For N = N_0 * phi = 6.85 atoms, E_b = 61.8% of bulk value.

### 7. Phi-Phonon Dispersion

The phonon dispersion relation in a phi-harmonic lattice:

```
omega(q) = omega_max * |sin(phi*q*a)|^(1/phi)
```

Where:
- omega_max = maximum phonon frequency
- q = wavevector
- a = average lattice spacing
- The exponent 1/phi = 0.618 creates a "softer" dispersion than the standard sinusoidal form

This modified dispersion predicts:
- Enhanced density of states at low frequencies (softer modes)
- Reduced thermal conductivity compared to periodic crystals
- Anomalous specific heat at low temperatures (C proportional to T^(1/phi) instead of T^3)

The phonon density of states:

```
g(omega) = g_0 * omega^(1/phi - 1) * (1 - (omega/omega_max)^(1/phi))^(-1/2)
```

For omega near 0: g(omega) proportional to omega^(-0.382) — a quasi-divergence that produces enhanced thermal fluctuations.

The thermal conductivity:

```
k = k_0 * (T/theta_D)^(-1/phi)
```

Where theta_D = Debye temperature. The 1/phi exponent means thermal conductivity decreases more slowly with temperature than the conventional T^(-1) law.

### 8. Phi-Diffraction Pattern

The diffraction pattern of a phi-harmonic crystal exhibits peaks at positions:

```
Q_n = (2*pi/a) * phi^n * (1, 1/phi, 1/phi^2)
```

The ratio of successive peak positions is exactly phi, providing a direct experimental signature. In a standard X-ray diffraction experiment, the peaks appear at:

```
Q_0 = 2*pi/a = 6.283/a
Q_1 = 2*pi*phi/a = 10.15/a
Q_2 = 2*pi*phi^2/a = 16.39/a
Q_3 = 2*pi*phi^3/a = 26.50/a
Q_4 = 2*pi*phi^4/a = 42.89/a
Q_5 = 2*pi*phi^5/a = 69.39/a
```

The self-similar spacing of these peaks distinguishes phi-harmonic crystals from both periodic crystals (equally spaced peaks) and amorphous materials (broad, featureless scattering).

The intensity of the n-th peak:

```
I_n = I_0 * phi^(-n) * |F(Q_n)|^2
```

Where F(Q_n) = structure factor. The phi-decay in intensity means that lower-order peaks dominate the diffraction pattern.

The peak width (in reciprocal space):

```
Delta_Q_n = Delta_Q_0 * phi^(-n/2)
```

Higher-order peaks are sharper, providing better resolution of the phi-harmonic structure at shorter length scales.

### 9. Phi-Surface Reconstruction

At crystal surfaces, phi-harmonic ordering produces reconstruction patterns with characteristic length scales:

```
d_n = d_0 * phi^n * (2 - phi^(-n))
```

The factor (2 - phi^(-n)) represents the surface relaxation correction. For large n, d_n approaches 2*d_0 — the surface reconstructs to exactly twice the bulk spacing, a prediction unique to phi-harmonic theory.

The surface energy of phi-reconstructed surfaces:

```
gamma_n = gamma_0 * (1 - phi^(-n))
```

Where gamma_0 = bulk surface energy. The rapid convergence means that surface reconstruction stabilizes after only a few atomic layers.

The surface stress tensor components:

```
f_xx = f_0 * (1 + (1/phi) * cos(2*pi*x/d))
f_yy = f_0 * (1 + (1/phi) * cos(2*pi*y/d))
f_xy = f_0 * (1/phi) * sin(2*pi*x/d) * sin(2*pi*y/d)
```

Where d = surface periodicity. The 1/phi modulation creates a stress pattern with period phi*d, which drives the surface reconstruction.

### 10. Phi-Crystal Growth Kinetics

The growth rate of phi-harmonic crystal faces:

```
R(hkl) = R_0 * (1 - phi^(-sigma/T))
```

Where sigma = supersaturation, T = temperature. The phi-exponential means:
- Growth initiates at lower supersaturation than conventional theory predicts
- Growth rate saturates at R_0 for high supersaturation
- The transition region is broader (by factor phi) than for periodic crystals

The nucleation rate:

```
J = J_0 * exp(-Delta_G*/(k_B*T)) * phi^(Delta_G*/Delta_G_0)
```

Where Delta_G* = nucleation barrier. The phi-factor means phi-crystals nucleate more easily than periodic crystals at the same barrier height.

### 11. Phi-Crystal Defect Physics

The formation energy of point defects in phi-crystals:

```
E_defect(n) = E_0 * (1 - phi^(-1) * exp(-n/phi))
```

Where n = defect distance from nearest phi-stable site. The phi-modification means:
- Defects close to stable sites have higher formation energy (harder to form)
- Defects far from stable sites have lower formation energy (easier to form)
- The transition occurs at n = phi^2 = 2.618 lattice spacings

The dislocation energy in phi-crystals:

```
E_disl = (mu*b^2/(4*pi*(1-nu))) * ln(R/r_0) * phi^(-R/R_0)
```

Where R = dislocation core radius, R_0 = phi-characteristic length. The phi-factor means dislocation energy decreases with core size, explaining why phi-crystals tend to have extended dislocation cores.

### 12. Phi-Phase Transformations

The martensitic transformation temperature in phi-alloys:

```
M_s = M_s0 * (1 + (1/phi) * (c - c_0)/c_0)
```

Where c = composition, c_0 = stoichiometric composition. The 1/phi factor means the transformation temperature is less sensitive to composition, producing more reliable shape memory behavior.

The austenite-martensite interface energy:

```
gamma_interface = gamma_0 * (1 - phi^(-n_layers))
```

Where n_layers = number of interface layers. The rapid convergence means sharp interfaces form after only 3-4 atomic layers.

### 13. Phi-Optical Properties

The dielectric function of phi-harmonic crystals:

```
epsilon(omega) = epsilon_inf + sum_n f_n * omega_n^2 / (omega_n^2 - omega^2 - i*gamma_n*omega)
```

Where the oscillator frequencies follow:

```
omega_n = omega_0 * phi^n
```

The phi-spaced oscillators produce a dielectric function with phi-related absorption peaks, enabling tunable optical properties.

The refractive index at phi-resonant frequencies:

```
n(phi*omega_0) = n_0 * sqrt(phi) = n_0 * 1.272
```

This 27.2% increase in refractive index at phi-resonant frequencies enables phi-crystals for optical switching applications.

### 14. Applications and Predictions

| Property | Conventional Crystal | Phi-Harmonic Crystal |
|----------|---------------------|---------------------|
| Symmetry | 2,3,4,6-fold | +5,8,10,12-fold |
| Periodicity | Translational | Self-similar |
| Band structure | Bloch waves | Fractal (Cantor set) |
| Thermal conductivity | High | Reduced (phi-factor) |
| Diffraction peaks | Equally spaced | phi-spaced |
| Cluster magic numbers | 2,8,20,40... | phi^3*m = 4,8,13,17... |
| Bond angles | Fixed by symmetry | phi-modulated |
| Phonon dispersion | Sinusoidal | phi-power-law |
| Surface reconstruction | 2x1, 2x2... | phi-hierarchical |
| Defect formation | Uniform | phi-distance dependent |

The phi-harmonic crystal framework unifies the understanding of quasicrystals, metallic glasses, and complex intermetallic phases under a single mathematical structure governed by the golden ratio.

### References

1. Shechtman, D. et al. "Metallic Phase with Long-Range Orientational Order and No Translational Symmetry." PRL 53, 20 (1984)
2. Penrose, R. "Pentaplexity." Eureka 39, 17-23 (1979)
3. Levine, D. & Steinhardt, P.J. "Quasicrystals: A New Class of Ordered Structures." PRL 53, 2477 (1984)
4. Senechal, M. Quasicrystals and Geometry. Cambridge University Press (1995)
5. Janot, C. Quasicrystals: A Primer. Oxford University Press (1994)
6. Steinhardt, P.J. & Jeong, H.C. "Stable Quasicrystal Packing." Nature 382, 431 (1996)
7. Merkle, K.L. "Grain Boundaries in Quasicrystals." MRS Proceedings 553, 3 (1998)
8. Dubois, J.M. Useful Quasicrystals. World Scientific (2005)
9. Pelletier, J.M. "Physical Properties of Quasicrystals." J. Alloys Compd. 342, 296 (2002)
10. Tsai, A.P. "Physics of Quasicrystals." Advances in Physics 50, 513 (2001)
