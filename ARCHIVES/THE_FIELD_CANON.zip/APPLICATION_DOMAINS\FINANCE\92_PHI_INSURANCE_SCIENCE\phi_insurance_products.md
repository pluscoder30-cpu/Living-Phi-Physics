# PHI-Insurance Products: Golden Ratio Product Design

## Directory 92_PHI_INSURANCE_SCIENCE | File 06

---

## 1. PHI-Life Insurance

### 1.1 PHI-Term Life

```
Premium = mortality_cost * phi{term_factor} + expense * phi{policy_load}
```

### 1.2 PHI-Whole Life

```
Premium = level_cost * phi{cash_value_buildup} + expense
Cash_value = premium * phi{investment_return} * phi{mortality_savings}
```

### 1.3 PHI-Universal Life

```
Account_value = prev * (1+i) + premium - expense - COI * phi{cost_of_insurance}
```

### 1.4 PHI-VUL

```
Account_value = prev * (1+investment_return) - expense - mortality * phi{risk_charge}
```

---

## 2. PHI-Health Insurance

### 2.1 PHI-Managed Care

```
Premium = expected_cost * phi{utilization_management} + margin
```

### 2.2 PHI-HSA Compatible

```
Premium = base * phi{high_deductible} + HSA_contribution * phi{tax_benefit}
```

### 2.3 PHI-Medicare Advantage

```
Premium = base + supplemental * phi{star_rating} - rebate * phi{benchmark}
```

### 2.4 PHI-Stop Loss

```
Premium = expected_attachment * phi{aggregate_load} + margin
```

---

## 3. PHI-Property Insurance

### 3.1 PHI-Homeowners

```
Premium = TIV * rate * phi{construction} * phi{protection} * phi{exposure}
```

### 3.2 PHI-Commercial Property

```
Premium = TIV * rate * phi{business_interruption} + demand_extension * phi{extra_expense}
```

### 3.3 PHI-Inland Marine

```
Premium = value * rate * phi{transit_risk} + installation * phi{storage_risk}
```

### 3.4 PHI-Flood

```
Premium = TIV * rate * phi{flood_zone} * phi{elevation} * phi{deductible}
```

---

## 4. PHI-Casualty Insurance

### 4.1 PHI-General Liability

```
Premium = payroll * rate * phi{class_code} * phi{experience_mod}
```

### 4.2 PHI-Professional Liability

```
Premium = revenue * rate * phi{practice_area} * phi{claims_history}
```

### 4.3 PHI-D&O

```
Premium = market_cap * rate * phi{governance} * phi{industry_risk}
```

### 4.4 PHI-Cyber

```
Premium = revenue * rate * phi{data_volume} * phi{security_posture}
```

---

## 5. PHI-Specialty

### 5.1 PHI-Marine

```
Premium = hull_value * rate * phi{navigation_area} + cargo * phi{trade_lane}
```

### 5.2 PHI-Aviation

```
Premium = hull_value * rate * phi{pilot_experience} + liability * phi{passenger_count}
```

### 5.3 PHI-Nuclear

```
Premium = limits * rate * phi{plant_safety} * phi{regulatory_compliance}
```

### 5.4 PHI-Pet

```
Premium = breed_risk * age_factor * phi{coverage_level} + deductible * phi{pet_value}
```

---

## 6. PHI-Retirement

### 6.1 PHI-Immediate Annuity

```
Payout = premium * payout_rate * phi{life_expectancy}
```

### 6.2 PHI-Deferred Annuity

```
Cash_value = premium * phi{guaranteed_rate} * phi{deferral_period}
```

### 6.3 PHI-Guaranteed Income

```
Income = premium * payout_rate * phi{longevity_risk}
```

### 6.4 PHI-LDI

```
Matching = asset_duration / liability_duration * phi{funding_level}
```

---

## 7. PHI-Embedded Value

### 7.1 PHI-New Business Value

```
NBV = premium * margin * phi{persistence} - acquisition * phi{amortization}
```

### 7.2 PHI-In-Force Value

```
IFV = future_NBV * phi{discount_rate}
```

### 7.3 PHI-Adjusted NAV

```
ANAV = NAV + IFV * phi{friction}
```

### 7.4 PHI-Solvency II

```
SCR = technical_provisions * phi{risk_margin} + capital_requirement
```

---

## 8. Summary

PHI-insurance products provide:
1. PHI-life with term, whole, universal, VUL with phi-premiums
2. PHI-health with managed care, HSA, Medicare, stop loss
3. PHI-property with homeowners, commercial, flood
4. PHI-casualty with GL, professional, D&O, cyber
5. PHI-specialty with marine, aviation, nuclear, pet
6. PHI-retirement with annuities and LDI
7. PHI-embedded value with NBV and IFV

The golden ratio creates natural product structures that balance coverage, pricing, and profitability across insurance lines.