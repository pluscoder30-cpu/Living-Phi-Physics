# PHI-COMPOSITE MATERIALS

## PHI-HARMONIC COMPOSITE ARCHITECTURE

### 1. Phi-Fiber Reinforcement Theory

The optimal fiber arrangement in phi-harmonic composites follows the golden angle (137.508 degrees) between successive fibers. For a unidirectional composite with N fibers per unit area:

```
theta_n = n * 137.508 degrees = n * (2*pi/phi^2) radians
```

This arrangement produces the most uniform stress distribution because the golden angle is the "most irrational" angle — it avoids periodic clustering that creates stress concentrations.

The stress concentration factor for phi-arranged fibers:

```
K_t = 1 + (1/phi^2) * (d/D)^2 = 1 + 0.382 * (d/D)^2
```

Where d = fiber diameter, D = inter-fiber spacing. This is 38.2% lower than the worst-case arrangement (square packing, K_t = 1 + (d/D)^2).

The optimal fiber volume fraction:

```
V_f,opt = 1/phi^2 = 0.382 = 38.2%
```

This is the maximum packing fraction for phi-arranged circular fibers in a plane. For comparison:
- Square packing: V_f = pi/4 = 0.785 (78.5%)
- Hexagonal packing: V_f = pi/(2*sqrt(3)) = 0.907 (90.7%)
- Random packing: V_f = 0.55-0.62 (55-62%)

The phi-packing is less dense but produces more uniform stress distributions.

### 2. Phi-Hierarchical Laminates

The layup sequence for phi-harmonic laminates:

```
[0/phi/2phi/3phi/...] where angles are multiples of 180 degrees/phi^n
```

For a 5-ply laminate:
- Ply 1: 0 degrees
- Ply 2: 180 degrees/phi = 111.25 degrees
- Ply 3: 180 degrees/phi^2 = 68.75 degrees
- Ply 4: 180 degrees/phi^3 = 42.48 degrees
- Ply 5: 180 degrees/phi^4 = 26.24 degrees

The resulting laminate has quasi-isotropic properties with:

```
E_x = E_y = E_f * V_f/phi + E_m * (1-V_f/phi)
G_xy = G_f * V_f/phi^2 + G_m * (1-V_f/phi^2)
```

The in-plane shear modulus is reduced by factor 1/phi^2 = 0.382 compared to the rule-of-mixtures prediction.

The bending stiffness matrix:

```
D_ij = sum_k Q_ij^(k) * (z_k^3 - z_{k-1}^3)/3
```

Where Q_ij^(k) = reduced stiffness of k-th ply. For phi-laminates, the Q_ij values follow:

```
Q_ij(phi*theta) = Q_ij(theta) * phi^(-|i-j|)
```

The phi-weighting of off-diagonal terms produces a stiffness matrix with reduced coupling between normal and shear deformations.

### 3. Phi-Impact Resistance

The energy absorption of phi-harmonic composites under impact:

```
E_absorbed = E_0 * (1 - exp(-t/tau_phi)) * phi^(V_f/V_f,crit)
```

Where tau_phi = phi * tau_0 is the characteristic absorption time. The phi-enhancement in the exponent means that increasing fiber volume fraction beyond the critical value V_f,crit produces exponentially greater energy absorption.

The ballistic limit velocity:

```
V_50 = V_0 * (t*t_f*rho_f)^(1/phi) / (A_impact)^(1/phi^2)
```

Where t = thickness, rho_f = fiber density, A_impact = impact area. The phi-exponents produce a V_50 that varies more slowly with thickness than the conventional t^(1/2) scaling.

The delamination area after impact:

```
A_delam = A_0 * (E_impact/E_crit)^phi
```

Where E_impact = impact energy, E_crit = critical delamination energy. The phi-exponent means delamination area increases faster than linearly with impact energy, producing a sharper onset of damage.

### 4. Phi-Delamination Resistance

The interlaminar fracture toughness of phi-harmonic laminates:

```
G_Ic = G_Ic,matrix * (1 + phi * (t_f/t_m)^(1/phi))
```

Where t_f = fiber thickness, t_m = matrix thickness. The phi-weighting favors thin interlayers, producing a self-healing effect where micro-cracks are deflected by the phi-hierarchical interfaces.

The mode mixity dependence:

```
G_c(psi) = G_Ic * cos^2(psi/phi) + G_IIc * sin^2(psi/phi)
```

Where psi = mode mixity angle. The phi-dividing the angle produces a smoother transition between mode I and mode II fracture.

The fatigue delamination growth:

```
da/dN = C * (Delta_G/G_c)^phi
```

Where Delta_G = energy release rate range. The phi-exponent predicts slower crack growth at low Delta_G but faster growth at high Delta_G.

### 5. Phi-Thermal Conductivity

The effective thermal conductivity of phi-arranged fiber composites:

```
k_eff = k_m * (1 + 2*V_f*(k_f/k_m - 1)/(k_f/k_m + 2 - 2*V_f*(1-1/phi)))
```

This is a phi-modified Maxwell-Garnett equation. The (1-1/phi) = 0.382 factor reduces the effective volume fraction of fibers, predicting lower thermal conductivity than standard models — beneficial for thermal insulation applications.

The thermal conductivity anisotropy:

```
k_parallel/k_perpendicular = 1 + (phi-1) * (k_f/k_m - 1) * V_f
```

The phi-enhancement means anisotropy increases 61.8% faster with fiber content than the conventional prediction.

The thermal diffusivity:

```
alpha_eff = k_eff / (rho * C_p) = alpha_m * (1 + phi*V_f*(alpha_f/alpha_m - 1))
```

### 6. Phi-Fatigue Life Prediction

The S-N curve for phi-harmonic composites:

```
N_f = N_0 * (sigma_max/sigma_ref)^(-phi)
```

Where N_0 = reference cycle count, sigma_ref = reference stress. The phi-exponent predicts:
- At sigma_max = sigma_ref: N_f = N_0
- At sigma_max = 0.618*sigma_ref: N_f = N_0 * phi = 1.618*N_0
- At sigma_max = 0.382*sigma_ref: N_f = N_0 * phi^2 = 2.618*N_0

The Goodman diagram modified for phi-composites:

```
sigma_a/sigma_e + sigma_m/sigma_u = 1/phi
```

Where sigma_a = alternating stress, sigma_m = mean stress, sigma_e = endurance limit, sigma_u = ultimate strength. The 1/phi factor means phi-composites tolerate 61.8% higher mean stress for the same fatigue life.

### 7. Phi-Damping Capacity

The specific damping capacity of phi-composites:

```
tan(delta) = tan(delta)_m * (1 + phi*V_f*tan(delta)_f/tan(delta)_m)
```

The phi-enhancement means that even small amounts of high-damping fibers produce significant composite damping. For V_f = 0.1 and tan(delta)_f/tan(delta)_m = 10:

```
tan(delta)_composite/tan(delta)_matrix = 1 + 0.618*10 = 7.18
```

A 718% increase in damping from only 10% fiber content.

The loss factor frequency dependence:

```
eta(omega) = eta_0 * (omega*tau_phi)^(1/phi) / (1 + (omega*tau_phi)^(2/phi))
```

The peak loss occurs at:

```
omega_peak = 1/tau_phi = 1/(phi*tau_0)
```

### 8. Phi-Permeability

The permeability of phi-woven fiber preforms for composite manufacturing:

```
K = K_0 * (1-V_f)^phi / (1 + phi*V_f^2)
```

Where K_0 = neat permeability. The phi-exponent in the numerator and phi-weighting in the denominator predict better resin flow than random weaves but worse than unidirectional — optimal for balanced impregnation.

The anisotropy ratio:

```
K_11/K_22 = phi * (1-V_f/V_f,crit)^(1/phi)
```

Where V_f,crit = critical fiber volume fraction. The phi-factor means permeability anisotropy increases with fiber content.

### 9. Phi-Interface Strength

The fiber-matrix interface strength in phi-harmonic composites:

```
tau_interface = tau_0 * (1 + (1/phi) * cos^2(theta))
```

Where theta = fiber orientation angle. The maximum interface strength occurs at theta = 0 degrees (aligned fibers) and the minimum at theta = 90 degrees, with the phi-factor creating a smooth angular dependence.

The interfacial shear stress distribution:

```
tau(r) = tau_max * (r/R)^(-1/phi)
```

Where r = radial distance from fiber center, R = fiber radius. The 1/phi exponent means shear stress is concentrated near the fiber surface, producing a more effective load transfer.

### 10. Multi-Scale Design Rules

| Scale | Phi-Rule | Application |
|-------|----------|-------------|
| Nano | 137.5 degree fiber angle | CNT forests |
| Micro | phi-spaced plies | Laminates |
| Meso | phi-hierarchical weaves | Textile composites |
| Macro | Golden section proportions | Structural design |

The phi-composite framework enables true multi-scale optimization where the same geometric principle (golden ratio) governs structure at every level, creating materials with emergent properties not achievable through conventional design.

### References

1. Hull, D. & Clyne, T.W. An Introduction to Composites. Cambridge (1996)
2. Daniel, I.M. & Ishai, O. Engineering Mechanics of Composite Materials. Oxford (2006)
3. Talreja, R.V. & Singh, C.V. Damage and Failure of Composite Materials. Cambridge (2012)
4. Barbero, E.J. Introduction to Composite Materials Design. CRC (2018)
5. Meredith, J. et al. "Recycling of Carbon Fibre/PEEK Composites." Composites B 43, 1 (2012)
6. Tsai, S.W. & Hahn, H.T. Introduction to Composite Materials TechnoNology. Technomic (1980)
7. Kaw, A.K. Mechanics of Composite Materials. CRC (2006)
8. Hyer, M.W. Stress Analysis of Fiber-Reinforced Composite Materials. DEStech (2009)
9. Vinson, J.R. & Sierakowski, R.L. The Behavior of Structures Composed of Composite Materials. Springer (2002)
10. Gibson, R.F. Principles of Composite Material Mechanics. CRC (2012)
