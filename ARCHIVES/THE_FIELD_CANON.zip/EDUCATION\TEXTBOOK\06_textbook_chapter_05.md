# Chapter 5: Fibonacci and Lucas Numbers

## The Most Famous Sequences in Mathematics

---

### Overview

The Fibonacci sequence is the most famous sequence in mathematics. It is defined by the simple rule: each number is the sum of the two preceding numbers. Starting from 1, 1, the sequence is:

1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, ...

The Lucas sequence is the "twin" of the Fibonacci sequence, defined by the same rule but starting from 2, 1:

2, 1, 3, 4, 7, 11, 18, 29, 47, 76, 123, 199, 322, 521, ...

Both sequences are intimately connected to the golden ratio. The ratio of consecutive Fibonacci numbers approaches φ, and the ratio of consecutive Lucas numbers also approaches φ. In fact, the Fibonacci and Lucas numbers can be expressed in terms of the golden ratio using Binet's formula.

---

## Lesson 5.1: The Fibonacci Sequence

### Explanation

The **Fibonacci sequence** is defined by:

F(0) = 0, F(1) = 1, F(n) = F(n-1) + F(n-2) for n ≥ 2

The first few terms are:

| n | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| F(n) | 0 | 1 | 1 | 2 | 3 | 5 | 8 | 13 | 21 | 34 | 55 |

**Key Concept**: Each Fibonacci number is the sum of the two preceding Fibonacci numbers.

### Ratios of Consecutive Fibonacci Numbers

Let us compute the ratios of consecutive Fibonacci numbers:

| Ratio | Value |
|-------|-------|
| F(2)/F(1) | 1/1 = 1.0000 |
| F(3)/F(2) | 2/1 = 2.0000 |
| F(4)/F(3) | 3/2 = 1.5000 |
| F(5)/F(4) | 5/3 = 1.6667 |
| F(6)/F(5) | 8/5 = 1.6000 |
| F(7)/F(6) | 13/8 = 1.6250 |
| F(8)/F(7) | 21/13 = 1.6154 |
| F(9)/F(8) | 34/21 = 1.6190 |
| F(10)/F(9) | 55/34 = 1.6176 |
| F(11)/F(10) | 89/55 = 1.6182 |

These ratios oscillate above and below φ ≈ 1.6180339887, getting closer and closer.

**Key Concept**: The ratio of consecutive Fibonacci numbers approaches the golden ratio φ.

### Why Does This Work?

Let r(n) = F(n)/F(n-1) be the ratio of consecutive Fibonacci numbers. From the recurrence F(n) = F(n-1) + F(n-2), we get:

r(n) = F(n)/F(n-1) = (F(n-1) + F(n-2))/F(n-1) = 1 + F(n-2)/F(n-1) = 1 + 1/r(n-1)

If the ratios converge to some limit L, then L = 1 + 1/L, which gives:

L² = L + 1

This is the golden ratio equation! So L = φ.

### Worked Example 5.1.1

Compute the first 10 Fibonacci numbers and the ratios of consecutive pairs.

**Solution**: 
F(0) = 0
F(1) = 1
F(2) = 1
F(3) = 2
F(4) = 3
F(5) = 5
F(6) = 8
F(7) = 13
F(8) = 21
F(9) = 34
F(10) = 55

Ratios: 1.000, 2.000, 1.500, 1.667, 1.600, 1.625, 1.615, 1.619, 1.618

These approach φ ≈ 1.618.

### Practice Problems

1. Compute F(11), F(12), and F(13).
2. Compute F(12)/F(11) and compare it to φ.
3. For which n is F(n) first greater than 100?
4. For which n is F(n) first greater than 1,000,000?
5. Prove that F(n) is even if and only if n is a multiple of 3.

### Teacher's Notes

**Pattern Recognition**: Ask students to look for patterns in the Fibonacci sequence. Some patterns:
- Every 3rd Fibonacci number is even (F(3) = 2, F(6) = 8, F(9) = 34, ...)
- F(n) is odd if n is not a multiple of 3
- The last digits repeat with period 60 (Pisano period)

**Historical Note**: The Fibonacci sequence was introduced to Western mathematics by Leonardo of Pisa (Fibonacci) in his 1202 book *Liber Abaci*. However, the sequence was known in Indian mathematics centuries earlier, where it was used to enumerate patterns of Sanskrit poetry.

---

## Lesson 5.2: Binet's Formula

### Explanation

**Binet's formula** expresses the nth Fibonacci number in terms of the golden ratio:

F(n) = (φⁿ - ψⁿ) / √5

where φ = (1 + √5)/2 is the golden ratio and ψ = (1 - √5)/2 ≈ -0.618 is the conjugate of φ.

This formula is remarkable because it expresses a whole number (F(n)) in terms of irrational numbers (φ and ψ). The irrational parts cancel out, leaving a whole number.

**Key Concept**: F(n) = (φⁿ - ψⁿ) / √5.

### Why Binet's Formula Works

The proof uses the fact that φ and ψ are both roots of the equation x² = x + 1.

Consider the sequence defined by G(n) = (φⁿ - ψⁿ) / √5. We need to show that G(n) = F(n) for all n.

**Base cases**:
G(0) = (φ⁰ - ψ⁰) / √5 = (1 - 1) / √5 = 0 = F(0) ✓
G(1) = (φ - ψ) / √5 = ((1 + √5)/2 - (1 - √5)/2) / √5 = (√5) / √5 = 1 = F(1) ✓

**Inductive step**: Assume G(k) = F(k) for all k < n. Then:

G(n) = (φⁿ - ψⁿ) / √5

Since φ² = φ + 1 and ψ² = ψ + 1, we have φⁿ = φ × φⁿ⁻¹ = φ × (φⁿ⁻² + φⁿ⁻²) ... actually, let me use a different approach.

Since φ and ψ are roots of x² = x + 1, we have φ² = φ + 1 and ψ² = ψ + 1. Multiplying by φⁿ⁻² and ψⁿ⁻² respectively:

φⁿ = φⁿ⁻¹ + φⁿ⁻²
ψⁿ = ψⁿ⁻¹ + ψⁿ⁻²

Therefore:
φⁿ - ψⁿ = (φⁿ⁻¹ - ψⁿ⁻¹) + (φⁿ⁻² - ψⁿ⁻²)

Dividing by √5:
G(n) = G(n-1) + G(n-2)

Since G(0) = F(0) and G(1) = F(1), and G satisfies the same recurrence as F, we have G(n) = F(n) for all n. ✓

### Worked Example 5.2.1

Compute F(10) using Binet's formula.

**Solution**: F(10) = (φ¹⁰ - ψ¹⁰) / √5

φ¹⁰ = ((1 + √5)/2)¹⁰ ≈ 122.991869381
ψ¹⁰ = ((1 - √5)/2)¹⁰ ≈ -0.008130619

F(10) = (122.991869381 - (-0.008130619)) / √5 = 122.999999999 / 2.236067977 ≈ 55.000

So F(10) = 55. ✓

### Worked Example 5.2.2

Approximate F(20) using Binet's formula, noting that ψⁿ becomes very small for large n.

**Solution**: Since |ψ| ≈ 0.618 < 1, ψⁿ → 0 as n → ∞. For large n, F(n) ≈ φⁿ/√5.

F(20) ≈ φ²⁰/√5 = ((1 + √5)/2)²⁰/√5

φ²⁰ ≈ 15126.9999339

F(20) ≈ 15126.9999339 / 2.236067977 ≈ 6765.000

The exact value is F(20) = 6765. ✓

### Practice Problems

1. Compute F(15) using Binet's formula.
2. Approximate F(30) using the formula F(n) ≈ φⁿ/√5.
3. For what value of n does ψⁿ become less than 0.001?
4. Use Binet's formula to prove that F(n) is the nearest integer to φⁿ/√5 for n ≥ 0.
5. Compute F(50) using the approximation F(n) ≈ φⁿ/√5.

### Teacher's Notes

**Deep Insight**: Binet's formula is one of the most beautiful formulas in mathematics. It connects the Fibonacci sequence (whole numbers) to the golden ratio (an irrational number) through an exact formula. The fact that irrational numbers can combine to give whole numbers is deeply surprising.

**Approximation**: For large n, F(n) ≈ φⁿ/√5. This means Fibonacci numbers grow exponentially, with growth factor φ ≈ 1.618 per step.

---

## Lesson 5.3: Properties of Fibonacci Numbers

### Explanation

The Fibonacci sequence has many remarkable properties. Here are some of the most important:

**Property 1: Sum of Squares**

F(0)² + F(1)² + F(2)² + ... + F(n)² = F(n) × F(n+1)

For example: 1² + 1² + 2² + 3² + 5² = 1 + 1 + 4 + 9 + 25 = 40 = 5 × 8 = F(5) × F(6). ✓

**Property 2: gcd Property**

gcd(F(m), F(n)) = F(gcd(m, n))

For example: gcd(F(6), F(9)) = gcd(8, 34) = 2 = F(3) = F(gcd(6,9)). ✓

**Property 3: Cassini's Identity**

F(n-1) × F(n+1) - F(n)² = (-1)ⁿ

For example: F(4) × F(6) - F(5)² = 3 × 8 - 25 = 24 - 25 = -1 = (-1)⁵. ✓

**Property 4: Zeckendorf's Theorem**

Every positive integer can be written uniquely as a sum of non-consecutive Fibonacci numbers.

For example: 100 = 89 + 8 + 3 = F(11) + F(6) + F(4). (No other representation using non-consecutive Fibonacci numbers is possible.)

**Property 5: Fibonacci and the Golden Ratio**

F(n) = (φⁿ - ψⁿ) / √5

This is Binet's formula, which we proved in the previous lesson.

### Worked Example 5.3.1

Verify Cassini's identity for n = 7.

**Solution**: F(6) × F(8) - F(7)² = 8 × 21 - 169 = 168 - 169 = -1 = (-1)⁷. ✓

### Worked Example 5.3.2

Express 100 as a sum of non-consecutive Fibonacci numbers (Zeckendorf representation).

**Solution**: The Fibonacci numbers less than 100 are: 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89.

Start with the largest: 100 - 89 = 11.
Next: 11 - 8 = 3.
Next: 3 - 3 = 0.

So 100 = 89 + 8 + 3 = F(11) + F(6) + F(4).

Check: 89, 8, 3 are non-consecutive Fibonacci numbers (indices 11, 6, 4 are not consecutive). ✓

### Practice Problems

1. Verify the sum of squares property for n = 6.
2. Verify Cassini's identity for n = 8.
3. Find the Zeckendorf representation of 200.
4. Find the Zeckendorf representation of 1000.
5. Prove that F(n) divides F(kn) for all positive integers k. (Hint: use Binet's formula.)

### Teacher's Notes

**Proof Activity**: Cassini's identity is a good first proof for students. The proof uses induction and the Fibonacci recurrence. Walk through the proof step by step.

**Computational Activity**: Have students write a program (or use a spreadsheet) to compute Fibonacci numbers and verify these properties for large values of n.

---

## Lesson 5.4: The Lucas Sequence

### Explanation

The **Lucas sequence** is defined by:

L(0) = 2, L(1) = 1, L(n) = L(n-1) + L(n-2) for n ≥ 2

The first few terms are:

| n | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| L(n) | 2 | 1 | 3 | 4 | 7 | 11 | 18 | 29 | 47 | 76 | 123 |

The Lucas sequence is sometimes called the "twin" of the Fibonacci sequence because it satisfies the same recurrence but with different starting values.

### Binet's Formula for Lucas Numbers

Just as Fibonacci numbers have Binet's formula, so do Lucas numbers:

L(n) = φⁿ + ψⁿ

where φ = (1 + √5)/2 and ψ = (1 - √5)/2.

Notice the difference: Fibonacci uses (φⁿ - ψⁿ)/√5, while Lucas uses φⁿ + ψⁿ.

**Key Concept**: L(n) = φⁿ + ψⁿ.

### Relationship Between Fibonacci and Lucas Numbers

The Fibonacci and Lucas numbers are closely related:

**Property 1**: L(n) = F(n-1) + F(n+1)

For example: L(5) = F(4) + F(6) = 3 + 8 = 11. ✓

**Property 2**: F(n) = (L(n-1) + L(n+1)) / 5

For example: F(5) = (L(4) + L(6)) / 5 = (7 + 18) / 5 = 25/5 = 5. ✓

**Property 3**: L(n)² - 5F(n)² = 4(-1)ⁿ

For example: L(5)² - 5F(5)² = 121 - 125 = -4 = 4(-1)⁵. ✓

### Worked Example 5.4.1

Compute L(10) using Binet's formula.

**Solution**: L(10) = φ¹⁰ + ψ¹⁰

φ¹⁰ ≈ 122.991869381
ψ¹⁰ ≈ -0.008130619

L(10) ≈ 122.991869381 + (-0.008130619) = 122.983738762

The exact value is L(10) = 123. (The small discrepancy is due to rounding.)

### Worked Example 5.4.2

Verify that L(n) = F(n-1) + F(n+1) for n = 7.

**Solution**: L(7) = 29
F(6) + F(8) = 8 + 21 = 29 ✓

### Practice Problems

1. Compute the first 12 Lucas numbers.
2. Compute L(12) using Binet's formula.
3. Verify L(n) = F(n-1) + F(n+1) for n = 8.
4. Verify L(n)² - 5F(n)² = 4(-1)ⁿ for n = 6.
5. Prove that L(n) = F(n-1) + F(n+1) using Binet's formulas for F and L.

### Teacher's Notes

**Comparison Activity**: Have students create two columns — one for Fibonacci numbers and one for Lucas numbers — and compare them side by side. What patterns do they notice?

**Extension**: Research the "Lucas-Lehmer test" for primality, which uses Lucas numbers to test whether Mersenne numbers (2ⁿ - 1) are prime.

---

## Lesson 5.5: Fibonacci Numbers in Nature

### Explanation

The Fibonacci sequence appears throughout nature. Here are some of the most striking examples:

**1. Phyllotaxis (Leaf Arrangement)**

Leaves on a stem are arranged so that each leaf gets maximum sunlight. The number of spirals in a sunflower head is almost always a pair of consecutive Fibonacci numbers: 34 and 55, or 55 and 89.

**2. Flower Petals**

The number of petals on a flower is often a Fibonacci number:

| Flower | Number of Petals |
|--------|-----------------|
| Lily | 3 |
| Buttercup | 5 |
| Delphinium | 8 |
| Marigold | 13 |
| Asters | 21 |
| Daisies | 34, 55, or 89 |

**3. Pinecones**

Pinecones have two sets of spirals: one turning clockwise, the other counterclockwise. The number of spirals in each direction is almost always a pair of consecutive Fibonacci numbers.

**4. Pineapples**

Pineapples have three sets of spirals, with counts that are typically 8, 13, and 21 — three consecutive Fibonacci numbers.

**5. Branching Patterns**

Trees branch in patterns that approximate the Fibonacci sequence. The main trunk produces a branch. The trunk and branch each produce more branches. The number of branches at each level often follows the Fibonacci sequence.

**6. The Nautilus Shell**

The nautilus shell grows in a logarithmic spiral. While the nautilus spiral is not exactly a golden spiral (it is closer to a spiral with ratio 1.33 per quarter turn), it is often cited as an example of Fibonacci-like growth in nature.

### Why Does Nature Use Fibonacci?

The Fibonacci sequence appears in nature because of the **golden angle** (approximately 137.5°). When a plant grows new leaves, seeds, or petals, each new element is placed at an angle of approximately 137.5° from the previous one. This angle ensures maximum spacing and minimum overlap.

The golden angle is related to the golden ratio:

Golden angle = 360° × (1 - 1/φ) = 360° × (φ - 1)/φ = 360° × 1/φ² ≈ 137.5077...°

The ratio 1/φ² is irrational, which means the leaves never line up exactly. This is optimal for capturing sunlight.

### Worked Example 5.5.1

A sunflower has 34 spirals clockwise and 55 spirals counterclockwise. What is the ratio of the larger to the smaller number? How close is this to φ?

**Solution**: 55/34 ≈ 1.6176...

φ ≈ 1.6180...

The ratio is very close to φ. ✓

### Worked Example 5.5.2

A flower has 21 petals. Is 21 a Fibonacci number?

**Solution**: The Fibonacci sequence is: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, ...

Yes, 21 = F(8) is a Fibonacci number. ✓

### Practice Problems

1. Count the spirals on a pinecone. Are the counts Fibonacci numbers?
2. Count the petals on several flowers. Are the counts Fibonacci numbers?
3. Explain why the golden angle (137.5°) leads to Fibonacci numbers in phyllotaxis.
4. Research: what is the relationship between the Fibonacci sequence and the golden ratio in phyllotaxis?
5. Why is the golden angle better than 120° or 144° for leaf arrangement?

### Teacher's Notes

**Field Trip**: If possible, take students outdoors to count spirals on pinecones, pineapples, and sunflowers. This is one of the most memorable mathematics activities.

**Misconception**: Not all numbers in nature are Fibonacci numbers. The Fibonacci sequence is an approximation, not an exact law. Some sunflowers have 33 or 35 spirals, not exactly 34.

---

## Lesson 5.6: Fibonacci Numbers in Computer Science

### Explanation

Fibonacci numbers appear in several areas of computer science:

### The Fibonacci Heap

A Fibonacci heap is a data structure used in graph algorithms. It was invented by Michael Fredman and Robert Tarjan in 1984.

The Fibonacci heap has several remarkable properties:
- Insert: O(1) amortized
- Find minimum: O(1)
- Delete minimum: O(log n) amortized
- Decrease key: O(1) amortized
- Merge: O(1)

The name "Fibonacci heap" comes from the fact that the structure of the heap is related to Fibonacci numbers. Specifically, the maximum degree of any node in a Fibonacci heap is bounded by O(log n), and the proof of this bound uses Fibonacci numbers.

### Fibonacci Search

Fibonacci search is a search algorithm that works on sorted arrays. It is similar to binary search but uses Fibonacci numbers to determine the split points.

The advantage of Fibonacci search over binary search is that it uses only additions and subtractions, not divisions. This can be faster on some hardware.

### Fibonacci Coding

Fibonacci coding is a universal code that uses Fibonacci numbers to represent integers. Every positive integer can be uniquely represented as a sum of non-consecutive Fibonacci numbers (Zeckendorf's representation).

In Fibonacci coding, the representation of an integer is a binary string where the ith bit is 1 if F(i) is in the Zeckendorf representation, and 0 otherwise.

### The Golden Ratio in Algorithm Analysis

The golden ratio appears in the analysis of several algorithms:

**1. The Fibonacci Search Algorithm**

The time complexity of Fibonacci search is O(log_φ n), which is slightly worse than the O(log₂ n) of binary search. But Fibonacci search uses fewer operations per step.

**2. The Analysis of Quicksort**

The average-case analysis of quicksort involves the golden ratio. The expected number of comparisons is approximately 2φ ln n ≈ 3.286 ln n.

**3. The Analysis of the Euclidean Algorithm**

The worst-case input for the Euclidean algorithm (which computes the greatest common divisor) is consecutive Fibonacci numbers. This is because the Euclidean algorithm takes the most steps when the inputs are consecutive Fibonacci numbers.

### Worked Example 5.6.1

What is the Zeckendorf representation of 100?

**Solution**: The Fibonacci numbers less than 100 are: 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89.

Start with the largest: 100 - 89 = 11.
Next: 11 - 8 = 3.
Next: 3 - 3 = 0.

So 100 = 89 + 8 + 3 = F(11) + F(6) + F(4).

The Fibonacci coding representation is: 10010010010 (reading from F(11) down to F(0), with 1s at positions 11, 6, and 4).

### Worked Example 5.6.2

What is the worst-case number of steps for the Euclidean algorithm to compute gcd(F(n+1), F(n))?

**Solution**: The Euclidean algorithm applied to F(n+1) and F(n) takes exactly n steps. This is because:

gcd(F(n+1), F(n)) = gcd(F(n), F(n-1)) = ... = gcd(F(2), F(1)) = gcd(1, 1) = 1

Each step reduces the indices by 1, so it takes n steps.

### Practice Problems

1. Find the Zeckendorf representation of 200.
2. How many steps does the Euclidean algorithm take to compute gcd(89, 55)?
3. What is the time complexity of Fibonacci search?
4. Why is Fibonacci search better than binary search on some hardware?
5. Research: what is a Fibonacci heap?

### Teacher's Notes

**Computer Science Connection**: This lesson connects Fibonacci numbers to computer science. The applications are practical and relevant to students interested in programming and algorithms.

**Implementation**: Have students implement Fibonacci search in Python or another programming language. Compare its performance to binary search.

---

## Lesson 5.7: Fibonacci Numbers in Art and Architecture

### Explanation

Fibonacci numbers and the golden ratio have been used in art and architecture for centuries.

### The Golden Ratio in Classical Architecture

The ancient Greeks used the golden ratio in their architecture:

**1. The Parthenon**

The Parthenon in Athens (built 447-432 BC) has dimensions that approximate the golden ratio. The ratio of the width to the height of the facade is close to φ.

**2. The Great Pyramid**

The Great Pyramid of Giza (built c. 2560 BC) has dimensions related to the golden ratio. The ratio of the slant height to half the base length is close to φ.

**3. Gothic Cathedrals**

Gothic cathedrals used harmonic ratios in their design, including the golden ratio. The proportions of the nave, the spacing of the columns, and the dimensions of the rose windows all approximate the golden ratio.

### The Golden Ratio in Renaissance Art

Renaissance artists were aware of the golden ratio and used it in their compositions:

**1. Leonardo da Vinci**

Leonardo's "Vitruvian Man" is based on golden proportions. The ratio of the height to the navel height is φ.

**2. Michelangelo**

Michelangelo's "The Creation of Adam" on the Sistine Chapel ceiling has the finger of God touching Adam at the golden section of the composition.

**3. Raphael**

Raphael's "The School of Athens" uses golden proportions in the arrangement of the figures.

### The Golden Ratio in Modern Art

Modern artists have also used the golden ratio:

**1. Mondrian**

Mondrian's abstract paintings use golden-ratio-based proportions for the colored rectangles.

**2. Dalí**

Dalí's "The Sacrament of the Last Supper" is painted on a golden rectangle, and the proportions of the composition are based on the golden ratio.

**3. Seurat**

Seurat's pointillist paintings use golden-ratio-based compositions.

### Worked Example 5.7.1

A painting has width 80 cm. If the height is φ times the width, what is the height?

**Solution**: Height = φ × 80 = 1.618 × 80 = 129.44 cm.

The painting is approximately 80 × 129 cm, which is close to the golden rectangle ratio of 5:8.

### Practice Problems

1. Find a photograph of the Parthenon. Can you identify the golden-ratio proportions?
2. Research: how did Leonardo da Vinci use the golden ratio?
3. Find a Mondrian painting and analyze its proportions.
4. Why might artists use the golden ratio?
5. Design a painting using golden-ratio proportions.

### Teacher's Notes

**Art Connection**: This lesson connects Fibonacci numbers and the golden ratio to art and architecture. Show photographs of buildings and paintings that use golden proportions.

**Art Activity**: Have students create artwork using golden-ratio proportions. They should use the golden rectangle as a compositional tool.

---

## Summary of Chapter 5

### Key Concepts

1. The **Fibonacci sequence** is F(0) = 0, F(1) = 1, F(n) = F(n-1) + F(n-2).
2. The **Lucas sequence** is L(0) = 2, L(1) = 1, L(n) = L(n-1) + L(n-2).
3. The ratio of consecutive Fibonacci numbers approaches the **golden ratio** φ.
4. **Binet's formula**: F(n) = (φⁿ - ψⁿ)/√5, L(n) = φⁿ + ψⁿ.
5. Fibonacci numbers satisfy many identities: sum of squares, Cassini's identity, gcd property.
6. **Zeckendorf's theorem**: Every positive integer is uniquely a sum of non-consecutive Fibonacci numbers.
7. Fibonacci numbers appear in nature: phyllotaxis, flower petals, pinecones, branching patterns.

### Key Formulas

| Formula | Description |
|---------|-------------|
| F(n) = F(n-1) + F(n-2) | Fibonacci recurrence |
| L(n) = L(n-1) + L(n-2) | Lucas recurrence |
| F(n) = (φⁿ - ψⁿ)/√5 | Binet's formula (Fibonacci) |
| L(n) = φⁿ + ψⁿ | Binet's formula (Lucas) |
| L(n) = F(n-1) + F(n+1) | Lucas-Fibonacci identity |
| F(n)² + F(n+1)² = F(2n+1) | Sum of squares identity |
| F(n-1)F(n+1) - F(n)² = (-1)ⁿ | Cassini's identity |

### Connections to Other Chapters

- **Chapter 1 (Golden Ratio)**: The golden ratio is the limit of consecutive Fibonacci ratios.
- **Chapter 2 (Silver Ratio)**: The Pell sequence is the silver analogue of the Fibonacci sequence.
- **Chapter 3 (Bronze Ratio)**: The bronze sequence is the bronze analogue of the Fibonacci sequence.
- **Chapter 8 (Living Mathematics)**: Fibonacci numbers appear in phyllotaxis and biological growth patterns.
- **Chapter 12 (Phi-Economics and Phi-CS)**: Fibonacci numbers are used in trading algorithms and computer science.

---

**End of Chapter 5**

*Next: Chapter 6 — Plastic and Supergolden Ratios*
