# Foundation Mathematics: The Golden Ratio (Phi)

## Welcome, Young Mathematician!

Have you ever noticed how a sunflower looks perfectly spiral? Or how a seashell curls in just the right way? There's a secret number hiding in nature that makes these beautiful patterns happen. It's called **Phi** (pronounced "fee") — the golden ratio!

Phi is approximately **1.6180339887...** but don't worry about memorizing all those digits. Just remember: Phi is the magic number that nature uses to grow things!

---

## Part 1: What is Phi?

### The Magic Number

Phi is a special number that shows up everywhere in nature:

- **Sunflowers**: The seeds spiral in two directions. Count the spirals going left and right — they're always numbers next to each other in a special sequence!

- **Seashells**: The nautilus shell grows in a perfect spiral. Each section is 1.618 times bigger than the last!

- **Hurricanes**: The storm clouds spiral outward using phi proportions.

- **Human bodies**: The length of your forearm compared to your hand is close to phi!

### The Ratio That Nature Uses to Grow

Think about how a plant grows. It doesn't just grow randomly — it follows a pattern. Phi helps plants pack their leaves, seeds, and petals in the most efficient way possible.

When you divide any Fibonacci number by the one before it, you get closer and closer to phi:
- 8 ÷ 5 = 1.6
- 13 ÷ 8 = 1.625
- 21 ÷ 13 = 1.615...
- 34 ÷ 21 = 1.619...

See how it's getting closer to 1.618?

---

## Part 2: The Golden Rectangle

### How to Draw a Golden Rectangle

A golden rectangle has sides in the ratio 1:1.618. Here's how to draw one:

**Step 1**: Draw a square that is 10 cm on each side.

**Step 2**: Find the middle of the bottom side. That's 5 cm from either corner.

**Step 3**: Put your compass on the middle point. Open it to the top right corner.

**Step 4**: Swing the compass down until it touches the line extending from the bottom.

**Step 5**: Draw a line from that point up to the top right corner.

**Step 6**: You now have a golden rectangle! The long side is about 16.18 cm.

### The Golden Spiral

Inside every golden rectangle, you can draw a spiral:

1. Draw a square inside your golden rectangle (using the short side length)
2. You're left with a smaller golden rectangle
3. Draw a square in that smaller rectangle
4. Keep going! You'll get smaller and smaller golden rectangles
5. Now draw a curve connecting the corners of each square
6. You've made a golden spiral!

---

## Part 3: What Happens When You Add Phi?

### Phi Addition is Special

Here's something amazing about phi. When you add 1 to phi, you get phi squared!

Phi + 1 = Phi × Phi

Let's check:
- Phi = 1.618...
- Phi + 1 = 2.618...
- Phi × Phi = 2.618...

They're the same! This is called the **golden identity**.

### More Phi Fun Facts

- Phi - 1 = 1 ÷ Phi (phi is the only number where subtracting 1 gives you the same as dividing by it!)

- Phi² = Phi + 1

- Phi³ = 2 × Phi + 1

- 1 ÷ Phi = Phi - 1 = 0.618...

This means phi connects multiplication, addition, and division in a special way!

---

## Part 4: Phi in Everyday Life

### Art and Architecture

Artists and builders have used phi for thousands of years:

- The **Parthenon** in Greece has phi proportions in its columns
- **Leonardo da Vinci** used phi in his paintings
- Modern **credit cards** are almost golden rectangles!

### Music

The lengths of piano keys follow phi proportions. The white keys on a piano have lengths related to phi!

---

## Part 5: 10 Fun Exercises

### Exercise 1: Count the Petals
Look at a flower (or picture of one). Count the petals. Common numbers are 3, 5, 8, 13, 21 — all Fibonacci numbers! Write down how many petals you see.

### Exercise 2: Draw Your Own Golden Rectangle
Using a ruler and compass, draw a golden rectangle. Start with a 5 cm square. Remember the steps from Part 2!

### Exercise 3: Find Phi in Nature
Go outside and find three things that show phi proportions:
- A pinecone (count the spirals)
- A pineapple (count the hexagons in each direction)
- A leaf (notice the vein pattern)

### Exercise 4: The Fibonacci Connection
Write out the Fibonacci sequence up to 100:
0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89

Now divide each number by the one before it:
1÷1 = ?
2÷1 = ?
3÷2 = ?
5÷3 = ?

Do you see them getting closer to 1.618?

### Exercise 5: Golden Spiral Art
Draw a golden rectangle. Inside it, draw squares of decreasing size. Then connect the corners with a smooth curve to make a spiral. Color each square a different color!

### Exercise 6: Phi Scavenger Hunt
Find these phi things in your house:
- A credit card (golden rectangle!)
- A standard sheet of paper (close to a silver rectangle, but let's compare)
- A book cover
- A picture frame

Measure the length and width of each. Which one is closest to 1.618?

### Exercise 7: Build a Phi Tower
Use blocks or books to build a tower where each level is 1.618 times taller than the one below. Start with a 2 cm block. What's the next height? (About 3.2 cm)

### Exercise 8: Phi in Music
If you have access to a piano, look at the white keys. The ratio of a C key length to a D key length is close to phi. Measure the keys if you can!

### Exercise 9: The Phi Poster
Create a poster showing phi in nature. Draw or glue pictures of:
- A sunflower
- A nautilus shell
- A hurricane
- A human face (with phi proportions marked)

### Exercise 10: Phi Journal
Start a math journal! Every day for a week, find one example of phi or Fibonacci numbers in your world. Write down what you found and take a picture if you can.

---

## Part 6: Amazing Phi Facts

### Fact 1: Phi Never Ends
Phi is an **irrational number**. That means its decimal places go on forever without repeating!

1.6180339887498948482045868343656381177203091798057628621354486227052604628189024497072072041893911374...

### Fact 2: Phi is the Most Irrational Number
Of all the irrational numbers, phi is the "most irrational" because it's the hardest to approximate with fractions!

### Fact 3: Phi in Space
The Voyager spacecraft's antenna dish is a golden spiral. NASA uses phi to design things that work perfectly!

### Fact 4: Your Fingers Have Phi
Look at your hand. The ratio of your palm length to your finger length is close to phi. The ratio of each finger section to the next is also close to phi!

### Fact 5: Phi and Bees
A honeycomb uses phi in its construction. The hexagons that make up the comb follow phi proportions for maximum strength!

---

## Part 7: Phi Poems

### The Phi Poem
Phi is the number that makes things grow,
In spirals, shells, and flowers that show,
From sunflowers bright to galaxies far,
Phi is the ratio of every star.

### The Golden Rhyme
One point six one eight,
That's phi, isn't it great?
In nature it hides,
In math it provides,
A pattern we can't debate!

---

## Part 8: What You've Learned

Today you discovered:

1. **Phi is a special number** (about 1.618) that nature uses to grow things efficiently.

2. **Golden rectangles** can be drawn using a square and compass. They contain the famous golden spiral.

3. **Phi has special math properties**: Phi + 1 = Phi × Phi

4. **Phi is everywhere**: in flowers, shells, art, music, and even your own body!

5. **Fibonacci numbers** (0, 1, 1, 2, 3, 5, 8, 13...) connect to phi — when you divide consecutive Fibonacci numbers, you get closer to phi!

---

## Part 9: Challenge Problems

### Challenge 1: The Phi Formula
Can you prove that phi + 1 = phi × phi?
Hint: Start with phi = (1 + √5) / 2

### Challenge 2: Golden Rectangles in Rectangles
Draw a golden rectangle. Draw a square inside it. What shape is left over? (Hint: it's another golden rectangle!)

### Challenge 3: The Spiral in the Spiral
If you zoom into a golden spiral, what do you see? (Answer: another golden spiral!)

### Challenge 4: Phi and Infinity
Phi is related to the continued fraction:
phi = 1 + 1/(1 + 1/(1 + 1/(1 + ...)))

Can you see why this makes phi special?

### Challenge 5: Nature's Code
If a sunflower has 34 spirals going clockwise and 55 going counterclockwise, what number comes next in each direction? (Hint: Fibonacci!)

---

## Part 10: Glossary

**Fibonacci Sequence**: A list of numbers where each number is the sum of the two before it: 0, 1, 1, 2, 3, 5, 8, 13...

**Golden Ratio**: The same as phi — approximately 1.618

**Golden Rectangle**: A rectangle where the ratio of length to width is phi

**Golden Spiral**: A spiral that gets wider by a factor of phi for every quarter turn

**Irrational Number**: A number that can't be written as a simple fraction, and its decimals go on forever

**Ratio**: A comparison of two numbers by division

**Sequence**: A list of numbers that follows a pattern

---

## Remember!

**Phi is the ratio that nature uses to grow things!**

From the tiniest flower to the biggest galaxy, phi helps the universe organize itself in the most beautiful and efficient way possible.

Next time you see a sunflower, remember: you're looking at math in action!

---

*Math is not just about numbers — it's about the patterns that connect everything in the universe. Phi is one of those patterns!*
