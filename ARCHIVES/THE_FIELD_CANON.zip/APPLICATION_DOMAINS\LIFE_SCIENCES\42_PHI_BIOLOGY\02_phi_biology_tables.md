# PHI-BIOLOGY: Reference Tables

---

## Table 1: Phi-Codon Weight System

| Codon | Amino Acid | w(codon) | P(codon) rel. | Phi-Rank |
|-------|------------|----------|---------------|----------|
| AAA | Lys | 0.000 | 1.000 | 1 |
| AAT | Asn | 0.382 | 0.852 | 2 |
| AAG | Lys | 0.618 | 0.764 | 3 |
| AAC | Asn | 1.000 | 0.651 | 4 |
| ATA | Ile | 1.000 | 0.651 | 5 |
| ATT | Ile | 1.382 | 0.555 | 6 |
| ATG | Met | 1.618 | 0.497 | 7 |
| ATC | Ile | 2.000 | 0.422 | 8 |
| AGA | Arg | 1.618 | 0.497 | 9 |
| AGT | Ser | 2.000 | 0.422 | 10 |
| ACG | Thr | 2.236 | 0.382 | 11 |
| ACA | Thr | 1.618 | 0.497 | 12 |
| ACT | Thr | 2.000 | 0.422 | 13 |
| ACC | Thr | 2.618 | 0.327 | 14 |
| AGC | Ser | 2.618 | 0.327 | 15 |
| TAA | Stop | 2.000 | 0.422 | 16 |
| TAT | Tyr | 2.382 | 0.364 | 17 |
| TAG | Stop | 2.618 | 0.327 | 18 |
| TAC | Tyr | 3.000 | 0.278 | 19 |
| TTA | Leu | 2.382 | 0.364 | 20 |
| TTT | Phe | 2.764 | 0.306 | 21 |
| TTG | Leu | 3.000 | 0.278 | 22 |
| TTC | Phe | 3.382 | 0.237 | 23 |
| TCA | Ser | 3.000 | 0.278 | 24 |
| TCT | Ser | 3.382 | 0.237 | 25 |
| TCG | Ser | 3.618 | 0.211 | 26 |
| TCC | Ser | 4.000 | 0.178 | 27 |
| TGA | Stop | 3.618 | 0.211 | 28 |
| TGT | Cys | 4.000 | 0.178 | 29 |
| TGG | Trp | 4.236 | 0.159 | 30 |
| TGC | Cys | 4.618 | 0.136 | 31 |
| GTA | Val | 3.000 | 0.278 | 32 |
| GTT | Val | 3.382 | 0.237 | 33 |
| GTG | Val | 3.618 | 0.211 | 34 |
| GTC | Val | 4.000 | 0.178 | 35 |
| GCA | Ala | 3.618 | 0.211 | 36 |
| GCT | Ala | 4.000 | 0.178 | 37 |
| GCG | Ala | 4.236 | 0.159 | 38 |
| GCC | Ala | 4.618 | 0.136 | 39 |
| GAA | Glu | 3.236 | 0.255 | 40 |
| GAT | Asp | 3.618 | 0.211 | 41 |
| GAG | Glu | 3.854 | 0.191 | 42 |
| GAC | Asp | 4.236 | 0.159 | 43 |
| GGA | Gly | 3.854 | 0.191 | 44 |
| GGT | Gly | 4.236 | 0.159 | 45 |
| GGG | Gly | 4.472 | 0.143 | 46 |
| GGC | Gly | 4.854 | 0.121 | 47 |
| CGA | Arg | 3.236 | 0.255 | 48 |
| CGT | Arg | 3.618 | 0.211 | 49 |
| CGG | Arg | 3.854 | 0.191 | 50 |
| CGC | Arg | 4.236 | 0.159 | 51 |
| CAA | Gln | 3.000 | 0.278 | 52 |
| CAT | His | 3.382 | 0.237 | 53 |
| CAG | Gln | 3.236 | 0.255 | 54 |
| CAC | His | 3.764 | 0.198 | 55 |
| CTA | Leu | 3.618 | 0.211 | 56 |
| CTT | Leu | 4.000 | 0.178 | 57 |
| CTG | Leu | 4.236 | 0.159 | 58 |
| CTC | Leu | 4.618 | 0.136 | 59 |
| CCA | Pro | 3.618 | 0.211 | 60 |
| CCT | Pro | 4.000 | 0.178 | 61 |
| CCG | Pro | 4.236 | 0.159 | 62 |
| CCC | Pro | 4.618 | 0.136 | 63 |

---

## Table 2: Phi-Growth Constants by Organism

| Organism | r (standard) | r_φ = r/φ | K (standard) | K_φ = K×φ | T_generation |
|----------|-------------|-----------|-------------|-----------|--------------|
| E. coli | 1.5 /hr | 0.927 /hr | 10⁹ /mL | 1.618×10⁹ | 20 min |
| Yeast | 0.5 /hr | 0.309 /hr | 10⁸ /mL | 1.618×10⁸ | 90 min |
| Fruit fly | 0.3 /day | 0.185 /day | 500 | 809 | 10 days |
| Mouse | 0.1 /day | 0.0618 /day | 1000 | 1618 | 3 weeks |
| Human | 0.02 /yr | 0.0124 /yr | 10⁹ | 1.618×10⁹ | 25 yr |
| Oak tree | 0.005 /yr | 0.00309 /yr | 10⁶ | 1.618×10⁶ | 50 yr |
| Blue whale | 0.01 /yr | 0.00618 /yr | 10⁵ | 1.618×10⁵ | 20 yr |
| Elephant | 0.015 /yr | 0.00927 /yr | 5×10⁵ | 8.09×10⁵ | 30 yr |
| Coral | 0.001 /yr | 0.000618 /yr | 10⁷ | 1.618×10⁷ | 100 yr |
| Tortoise | 0.002 /yr | 0.001236 /yr | 10⁴ | 1.618×10⁴ | 50 yr |

---

## Table 3: Phi-Allometric Scaling Exponents

| Process | Standard Exp. | Phi Exp. | φ-Value | Ratio |
|---------|--------------|----------|---------|-------|
| Metabolic rate vs mass | 3/4 = 0.750 | φ⁻¹ = 0.618 | 0.618 | 0.824 |
| Heart rate vs mass | -1/4 = -0.250 | -φ⁻² = -0.382 | -0.382 | 1.528 |
| Lifespan vs mass | 1/4 = 0.250 | φ⁻¹ = 0.618 | 0.618 | 2.472 |
| Brain mass vs body | 3/4 = 0.750 | φ⁻¹ = 0.618 | 0.618 | 0.824 |
| Population density | -3/4 = -0.750 | -φ⁻¹ = -0.618 | -0.618 | 0.824 |
| Home range vs mass | 3/4 = 0.750 | φ⁻¹ = 0.618 | 0.618 | 0.824 |
| Tree height vs diameter | 2/3 = 0.667 | φ⁻¹ = 0.618 | 0.618 | 0.927 |
| Wing span vs mass | 1/3 = 0.333 | φ⁻² = 0.382 | 0.382 | 1.147 |
| Generation time vs mass | 1/4 = 0.250 | φ⁻² = 0.382 | 0.382 | 1.528 |
| Respiratory rate vs mass | -1/4 = -0.250 | -φ⁻² = -0.382 | -0.382 | 1.528 |

---

## Table 4: Phi-Evolutionary Dynamics

| Parameter | Formula | Value | Significance |
|-----------|---------|-------|--------------|
| Phi-selection coefficient | s_φ = s/φ | 0.382s | Reduced selection |
| Phi-mutation rate | μ_φ = μ×φ^(c/100) | Variable | Complexity-scaled |
| Phi-drift strength | D_φ = D/φ | 0.382D | Reduced drift |
| Phi-adaptation rate | a_φ = a×φ^(-1) | 0.618a | Slower adaptation |
| Phi-fitness peak width | w_φ = w/φ | 0.618w | Narrower peaks |
| Phi-neutral distance | d_φ = d×φ | 1.618d | Longer neutral paths |
| Phi-speciation rate | σ_φ = σ/φ | 0.618σ | Slower speciation |
| Phi-extinction risk | E_φ = E×φ^(-N/φ) | Variable | Population-scaled |
| Phi-gene flow | G_φ = G/φ | 0.618G | Reduced gene flow |
| Phi-epistasis weight | ε_φ = ε×φ^(-|i-j|) | Variable | Distance-scaled |

---

## Table 5: Phi-Ecology Parameters

| Ecological Process | Standard | Phi-Modified | Ratio |
|--------------------|----------|-------------|-------|
| Predator-prey ratio | N_prey/N_pred | (N_prey/N_pred)^φ | φ-power |
| Trophic efficiency | 10% | 10% × φ⁻¹ = 6.18% | 0.618 |
| Shannon diversity | H = -Σp ln p | H_φ = -Σp log_φ p | 1/ln(φ) |
| Simpson diversity | D = 1-Σp² | D_φ = 1-Σp^φ | φ-exponent |
| Species-area exponent | z = 0.25 | z_φ = 0.382 | φ⁻² |
| Immigration rate | I = m(1-S/S_max) | I_φ = I × φ^(-S/S_max) | φ-decay |
| Extinction rate | E = eS/S_max | E_φ = E × φ^(S/S_max) | φ-growth |
| Competition coeff. | α_ij | α_φ,ij = α_ij/φ | φ-attenuation |
| Mutualism benefit | β_ij | β_φ,ij = β_ij × φ | φ-amplification |
| Predator switching | s = 0 | s_φ = 0.382 | φ-enabled |

---

## Table 6: Phi-Protein Folding Parameters

| Property | Standard | Phi-Modified | Significance |
|----------|----------|-------------|--------------|
| Helix propensity | P_helix | P_helix × φ^(ΔG/RT) | Enhanced helix |
| Sheet propensity | P_sheet | P_sheet × φ^(ΔG/RT) | Enhanced sheet |
| Coil propensity | P_coil | P_coil × φ^(-ΔG/RT) | Reduced coil |
| Folding rate | k_fold | k_fold × φ^(-N/100) | Size-scaled |
| Stability | ΔG_fold | ΔG_fold × φ | Enhanced stability |
| Contact order | CO | CO × φ^(-1/3) | Reduced CO |
| Loop length | L_loop | L_loop × φ^(-1/2) | Shorter loops |
| Disulfide bonds | n_SS | n_SS × φ^(1/3) | More SS bonds |
| Proline content | f_Pro | f_Pro × φ^(-1) | Less proline |
| Glycine content | f_Gly | f_Gly × φ^(-1/3) | Less glycine |

---

## Table 7: Phi-DNA Replication Fidelity

| Organism | ε₀ (errors/bp/rep) | Proofreading | ε_φ (phi-corrected) | φ-Improvement |
|----------|-------------------|--------------|---------------------|---------------|
| RNA virus | 10⁻⁴ | None | 10⁻⁴ | 1.0× |
| DNA virus | 10⁻⁶ | Basic | 3.82×10⁻⁷ | 2.62× |
| Bacteria | 10⁻⁹ | 3'→5' exon | 2.47×10⁻¹⁰ | 4.05× |
| Eukaryote | 10⁻¹⁰ | Exon + MMR | 1.53×10⁻¹¹ | 6.54× |
| Human | 10⁻¹¹ | Full repair | 9.47×10⁻¹³ | 10.56× |
| Plant | 10⁻⁹ | Variable | 2.47×10⁻¹⁰ | 4.05× |
| Fungus | 10⁻⁹ | Variable | 2.47×10⁻¹⁰ | 4.05× |
| Archaea | 10⁻¹⁰ | Robust | 1.53×10⁻¹¹ | 6.54× |

---

## Table 8: Phi-Phylogenetic Branch Lengths

| Clade | Standard Distance | Phi-Distance | φ-Correction |
|-------|-------------------|-------------|--------------|
| Human-Chimp | 0.006 | 0.00370 | φ⁻¹ scaling |
| Human-Gorilla | 0.012 | 0.00741 | φ⁻¹ scaling |
| Human-Orangutan | 0.031 | 0.01915 | φ⁻¹ scaling |
| Mammal-Bird | 0.35 | 0.2163 | φ⁻¹ scaling |
| Vertebrate-Insect | 0.75 | 0.4635 | φ⁻¹ scaling |
| Animal-Plant | 1.2 | 0.7416 | φ⁻¹ scaling |
| Eukarya-Bacteria | 2.5 | 1.545 | φ⁻¹ scaling |
| Life LUCA | 4.0 | 2.472 | φ⁻¹ scaling |

---

## Table 9: Phi-Gene Regulatory Network Motifs

| Motif Type | Standard Frequency | Phi-Frequency | φ-Enhancement |
|------------|-------------------|---------------|---------------|
| Negative feedback | 15% | 15% × φ⁻¹ = 9.27% | Reduced |
| Positive feedback | 8% | 8% × φ = 12.94% | Enhanced |
| Feed-forward | 12% | 12% × φ⁻¹ = 7.41% | Reduced |
| Bi-fan | 5% | 5% × φ = 8.09% | Enhanced |
| Auto-regulation | 20% | 20% × φ⁻¹ = 12.36% | Reduced |
| Mutual inhibition | 3% | 3% × φ = 4.85% | Enhanced |
| Three-component | 10% | 10% × φ⁻¹ = 6.18% | Reduced |
| Oscillator | 4% | 4% × φ = 6.47% | Enhanced |

---

## Table 10: Phi-Genome Architecture

| Feature | Standard | Phi-Modified | Significance |
|---------|----------|-------------|--------------|
| Gene density | ρ genes/Mb | ρ × φ^(-x/λ) | Position-dependent |
| GC content | ~40% | 40% × φ⁻¹ = 24.7% | Reduced GC |
| Intron length | ~3 kb | 3 kb × φ = 4.85 kb | Longer introns |
| Exon length | ~150 bp | 150 bp × φ⁻¹ = 93 bp | Shorter exons |
| Promoter CpG | Variable | CpG × φ^(expression) | Expression-linked |
| Enhancer distance | ~50 kb | 50 kb × φ = 80.9 kb | Farther enhancers |
| Chromosome bands | ~400 | 400 × φ⁻¹ = 247 | Fewer bands |
| Replication timing | S-phase | S-phase × φ | Slower replication |
| Telomere length | ~10 kb | 10 kb × φ = 16.18 kb | Longer telomeres |
| Centromere size | ~400 kb | 400 kb × φ⁻¹ = 247 kb | Smaller centromeres |

---

*Part of the 32_PHI_PHYSICS / 06_EXPANDED_MATHEMATICS system.*
*Version 1.0 — Agent I of 26*

---

## Table 11: Phi-Enzyme Kinetics Parameters

| Enzyme | Km (standard) | Km_phi (phi-corrected) | Vmax_phi | kcat_phi/Km_phi |
|--------|--------------|------------------------|----------|-----------------|
| Hexokinase | 0.1 mM | 0.062 mM | Vmax/phi | 2.0x higher |
| PFK | 0.05 mM | 0.031 mM | Vmax/phi | 2.0x higher |
| Pyruvate kinase | 0.2 mM | 0.124 mM | Vmax/phi | 2.0x higher |
| Lactate dehydrogenase | 0.15 mM | 0.093 mM | Vmax/phi | 2.0x higher |
| Carbonic anhydrase | 12 mM | 7.42 mM | Vmax/phi | 2.0x higher |
| Catalase | 25 mM | 15.45 mM | Vmax/phi | 2.0x higher |
| Superoxide dismutase | 0.3 mM | 0.185 mM | Vmax/phi | 2.0x higher |
| Glutathione peroxidase | 0.08 mM | 0.049 mM | Vmax/phi | 2.0x higher |

---

## Table 12: Phi-Immune System Parameters

| Immune Process | Standard | Phi-Modified | Significance |
|----------------|----------|-------------|--------------|
| Antibody affinity maturation | 10^(-8) M | 10^(-8) x phi^(-3) M | Stronger binding |
| T-cell receptor diversity | 10^15 | 10^15 x phi^(1/3) | More diverse |
| Cytokine production rate | R_0 | R_0 x phi^(-activation) | Regulated response |
| Macrophage phagocytosis | 10 bacteria/cell | 10 x phi bacteria/cell | Enhanced killing |
| NK cell cytotoxicity | 50% lysis | 50% x phi^(-1) = 31% | More selective |
| Complement activation | C3 = 1.0 | C3 x phi^(-pathway) | Pathway-specific |
| Dendritic cell maturation | 24 hr | 24/phi = 14.8 hr | Faster maturation |
| B-cell proliferation | 10 divisions | 10 x phi^(-antigen) | Antigen-scaled |

---

## Table 13: Phi-Plant Physiology Parameters

| Process | Standard | Phi-Modified | Significance |
|---------|----------|-------------|--------------|
| Photosynthetic rate | P_max | P_max x phi^(-light/1000) | Light-scaled |
| Stomatal conductance | g_s | g_s x phi^(-VPD) | VPD-responsive |
| Root growth rate | 2 cm/day | 2/phi = 1.24 cm/day | Slower, deeper |
| Leaf area index | 3.0 | 3.0 x phi = 4.85 | Fuller canopy |
| Flower opening time | 6 AM | 6/phi = 3.7 AM | Earlier blooming |
| Seed germination | 80% | 80% x phi^(-seed_age/10) | Age-dependent |
| Xylem transport | 1 m/hr | 1/phi = 0.618 m/hr | Slower, more efficient |
| Phloem loading | 0.5 M sucrose | 0.5/phi = 0.309 M | Lower concentration |

---

## Table 14: Phi-Marine Biology Parameters

| Parameter | Standard | Phi-Modified | Significance |
|-----------|----------|-------------|--------------|
| Phytoplankton growth | 0.5 /day | 0.5/phi = 0.309 /day | Slower growth |
| Zooplankton grazing | 0.3 /day | 0.3/phi = 0.185 /day | Less grazing |
| Coral calcification | 10 mg/cm^2/day | 10/phi = 6.18 mg/cm^2/day | Slower calcification |
| Fish school size | 100 fish | 100 x phi = 162 fish | Larger schools |
| Whale migration | 10,000 km | 10,000/phi = 6,180 km | Shorter migration |
| Kelp forest density | 50 fronds/m^2 | 50/phi = 31 fronds/m^2 | Less dense |
| Tide pool temperature | 15-20 C | 15-20/phi = 9.3-12.4 C | Cooler |
| Deep sea pressure | 1 atm/10m | 1/phi atm/10m = 0.618 | Reduced |

---

## Table 15: Phi-Microbiology Parameters

| Parameter | Standard | Phi-Modified | Significance |
|-----------|----------|-------------|--------------|
| Bacterial generation time | 20 min | 20/phi = 12.4 min | Faster division |
| Phage burst size | 100 | 100 x phi = 162 | Larger burst |
| Biofilm thickness | 100 muM | 100/phi = 61.8 muM | Thinner biofilm |
| Quorum sensing threshold | 10^6 cells/mL | 10^6/phi = 6.18x10^5 | Lower threshold |
| Sporulation rate | 10% | 10% x phi = 16.2% | Higher sporulation |
| Antibiotic MIC | 1 muM | 1/phi = 0.618 muM | Lower MIC |
| Conjugation rate | 10^(-6) | 10^(-6) x phi^(plasmid_size/10) | Size-dependent |
| Motility speed | 25 muM/s | 25/phi = 15.5 muM/s | Slower, more efficient |

---

## Table 16: Phi-Virology Parameters

| Parameter | Standard | Phi-Modified | Significance |
|-----------|----------|-------------|--------------|
| Viral mutation rate | 10^(-4)/nt/rep | 10^(-4) x phi^(-proofreading) | Proofreading-scaled |
| Burst size | 1000 virions | 1000/phi = 618 | Smaller burst |
| Latency period | 8 hr | 8/phi = 4.95 hr | Shorter latency |
| Receptor binding | Kd = 10 nM | Kd/phi = 6.18 nM | Stronger binding |
| Immune evasion | 0.5 | 0.5 x phi^(-immune_response) | Response-dependent |
| Tissue tropism | Broad | Broad/phi = Narrow | More specific |
| Genome size | 10 kb | 10/phi = 6.18 kb | Smaller genome |
| Pack efficiency | 50% | 50% x phi^(-1) = 31% | Less efficient |

---

## Table 17: Phi-Ecological Succession Parameters

| Stage | Time (years) | Phi-Time | Species Richness | Phi-Richness |
|-------|-------------|----------|-----------------|--------------|
| Bare substrate | 0 | 0 | 0 | 0 |
| Pioneer | 1-5 | 0.6-3.1 | 5-20 | 3-12 |
| Early successional | 5-20 | 3.1-12.4 | 20-50 | 12-31 |
| Mid successional | 20-50 | 12.4-30.9 | 50-100 | 31-62 |
| Late successional | 50-100 | 30.9-61.8 | 100-150 | 62-93 |
| Climax | 100+ | 61.8+ | 150-200 | 93-124 |

---

## Table 18: Phi-Conservation Biology Metrics

| Metric | Standard | Phi-Modified | Application |
|--------|----------|-------------|-------------|
| Minimum viable population | 500 | 500/phi = 309 | Smaller populations viable |
| Critical habitat size | 100 km^2 | 100/phi = 61.8 km^2 | Smaller reserves needed |
| Extinction debt time | 100 yr | 100 x phi = 162 yr | Longer payback |
| Recovery time | 50 yr | 50 x phi = 80.9 yr | Longer recovery |
| Genetic diversity target | 90% | 90% x phi^(-1) = 56% | Lower threshold |
| Connectivity requirement | 1 corridor | 1/phi = 0.618 corridors | Fewer corridors |
| Invasion risk threshold | 10% | 10% x phi = 16.2% | Higher tolerance |
| Climate refugia size | 50 km^2 | 50 x phi = 80.9 km^2 | Larger refugia |

---

## Table 19: Phi-Biogeography Zones

| Zone | Latitude (deg) | Phi-Latitude | Temperature (C) | Phi-Temp |
|------|---------------|-------------|-----------------|----------|
| Tropical | 0-23.5 | 0-14.5 | 25-35 | 15.5-21.6 |
| Subtropical | 23.5-35 | 14.5-21.6 | 15-25 | 9.3-15.5 |
| Temperate | 35-50 | 21.6-30.9 | 5-15 | 3.1-9.3 |
| Boreal | 50-65 | 30.9-40.2 | -5 to 5 | -3.1 to 3.1 |
| Polar | 65-90 | 40.2-55.6 | -40 to -5 | -24.7 to -3.1 |

---

## Table 20: Phi-Evolutionary Rate Constants

| Taxon | Substitution Rate (x10^(-9)/site/yr) | Phi-Rate | Molecular Clock |
|-------|--------------------------------------|----------|-----------------|
| Primate | 1.0 | 0.618 | Slow |
| Rodent | 2.5 | 1.545 | Medium |
| Bird | 1.5 | 0.927 | Medium |
| Fish | 0.8 | 0.494 | Slow |
| Insect | 3.5 | 2.163 | Fast |
| Plant | 0.5 | 0.309 | Very slow |
| Mammal (avg) | 1.2 | 0.742 | Medium |
| Reptile | 0.7 | 0.433 | Slow |

