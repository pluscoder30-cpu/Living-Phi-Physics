# PHI-Semiotics: The Golden Ratio in Signs and Meaning

## The Complete System

**PHI-Semiotics:** PHI-sign theory, PHI-visual semiotics, PHI-linguistic semiotics, PHI-cultural semiotics, PHI-narrative semiotics, PHI-musical semiotics, PHI-digital semiotics.

---

### Files

| # | File | Description | Lines |
|---|------|-------------|-------|
| 1 | [01_PHI_SIGN_THEORY.md](01_PHI_SIGN_THEORY.md) | Complete theory: sign architecture, visual, linguistic, cultural, narrative, musical, digital semiotics | ~500 |
| 2 | [02_PHI_SIGN_TABLES.md](02_PHI_SIGN_TABLES.md) | PHI sign component weights, visual hierarchy, color symbolism, gestalt, narrative tables | ~350 |
| 3 | [03_PHI_SIGN_EXAMPLES.md](03_PHI_SIGN_EXAMPLES.md) | 20 worked examples: triadic sign to wayfinding design | ~500 |
| 4 | [04_PHI_SIGN_APPLICATIONS.md](04_PHI_SIGN_APPLICATIONS.md) | Brand identity, web design, motion graphics, typography, photography, UI | ~350 |
| 5 | [05_PHI_SIGN_PROBLEMS.md](05_PHI_SIGN_PROBLEMS.md) | 20 practice problems across 15 problem sets | ~350 |
| 6 | [06_PHI_SIGN_ANSWERS.md](06_PHI_SIGN_ANSWERS.md) | Complete answer key with solutions | ~400 |
| 7 | [07_PHI_SIGN_SUPPLEMENTARY.md](07_PHI_SIGN_SUPPLEMENTARY.md) | Quantum semiotics, social semiotics, biosemiotics, cognitive semiotics | ~400 |
| 8 | [README.md](README.md) | This index | ~80 |

**Total: ~2,930 lines across 8 files**

---

### Quick Reference

```
PHI sign distribution:
  Representamen : Object : Interpretant = phi^2 : phi : 1

PHI visual hierarchy:
  Title : Subtitle : Body : Caption = phi^0 : phi^-1 : phi^-2 : phi^-3

PHI color palette:
  Dominant : Accent : Neutral = phi : phi^-1 : phi^-2 = 61.8% : 23.6% : 14.6%

PHI narrative arc:
  Setup : Rising : Climax : Falling : Resolution = phi^3 : phi^2 : phi : 1 : phi^-1

PHI ad structure:
  Headline : Body : CTA = phi^2 : phi : 1

PHI brand meaning:
  Functional : Emotional : Symbolic = phi^-1 : phi^0 : phi^1

PHI navigation depth:
  Maximum clicks = floor(phi^3) = 4

PHI meme half-life:
  Half-life = 1.44 days

PHI intertextual density:
  D = SUM(references * phi^-rank) / (phi * text_length)
```

---

### PHI Values Reference

| Constant | Value | Formula |
|----------|-------|---------|
| phi | 1.618 | (1+sqrt(5))/2 |
| 1/phi | 0.618 | phi-1 |
| 1/phi^2 | 0.382 | 2-phi |
| phi^2 | 2.618 | phi+1 |
| phi^3 | 4.236 | 2*phi+1 |
| phi^4 | 6.854 | 3*phi+2 |

---

*This directory is part of the PHI-Physics Dictionary, Directory 55: PHI-Semiotics.*
