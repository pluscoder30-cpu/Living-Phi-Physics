# Foundation Mathematics: Lucas Numbers

## Welcome, Young Mathematician!

You've learned about Fibonacci numbers. Now it's time to meet Fibonacci's mathematical twin — **Lucas numbers**!

Lucas numbers are: 2, 1, 3, 4, 7, 11, 18, 29, 47, 76, 123, 199...

They follow the same rule as Fibonacci (each number is the sum of the two before it), but they start with different numbers!

---

## Part 1: What are Lucas Numbers?

### Fibonacci's Twin

Lucas numbers were named after **Édouard Lucas**, a French mathematician who studied them in the 1870s. He's the same person who created the Tower of Hanoi puzzle!

The Lucas sequence starts with 2 and 1:
- L(0) = 2
- L(1) = 1
- L(2) = 2 + 1 = 3
- L(3) = 1 + 3 = 4
- L(4) = 3 + 4 = 7
- L(5) = 4 + 7 = 11
- L(6) = 7 + 11 = 18
- L(7) = 11 + 18 = 29
- L(8) = 18 + 29 = 47
- L(9) = 29 + 47 = 76
- L(10) = 47 + 76 = 123

### The Same Rule, Different Start

The rule for Lucas numbers is exactly the same as Fibonacci:
**Each number = the sum of the two before it**

The only difference is the starting numbers:
- Fibonacci: 0, 1, ...
- Lucas: 2, 1, ...

This small change creates a whole new sequence!

### Where Lucas Hides

Lucas numbers show up in similar places as Fibonacci:

- **Prime Testing**: Lucas numbers help test if big numbers are prime!

- **Mathematics**: They appear in formulas alongside Fibonacci.

- **Nature**: Some natural patterns use Lucas numbers instead of Fibonacci.

- **Games**: The Tower of Hanoi (created by Lucas) uses powers of 2, which relate to Lucas numbers!

---

## Part 2: Lucas and Fibonacci Together

### The Relationship

Fibonacci and Lucas numbers are deeply connected:

- L(n) = F(n-1) + F(n+1)

Example:
- L(5) = F(4) + F(6) = 3 + 8 = 11 ✓
- L(6) = F(5) + F(7) = 5 + 13 = 18 ✓

### Adding Fibonacci and Lucas

When you add consecutive Fibonacci numbers, you often get Lucas numbers:
- 1 + 2 = 3 (Lucas)
- 2 + 3 = 5 (not Lucas)
- 3 + 5 = 8 (not Lucas)

Hmm, that's not quite right. Let me share the actual property:

The sum of the first n Fibonacci numbers equals F(n+2) - 1, not a Lucas number.

The real connection is:
- F(n) + L(n) = 2 × F(n+1)

Example:
- F(5) + L(5) = 5 + 11 = 16 = 2 × 8 = 2 × F(6) ✓

### The Golden Connection

Like Fibonacci numbers, the ratio of consecutive Lucas numbers approaches phi (1.618...):
- 3 ÷ 1 = 3
- 4 ÷ 3 = 1.333...
- 7 ÷ 4 = 1.75
- 11 ÷ 7 = 1.571...
- 18 ÷ 11 = 1.636...
- 29 ÷ 18 = 1.611...
- 47 ÷ 29 = 1.620...
- 76 ÷ 47 = 1.617...
- 123 ÷ 76 = 1.618...

Getting closer to phi!

---

## Part 3: Lucas Number Patterns

### The Last Digits

The last digits of Lucas numbers also repeat! The pattern of last digits is:
2, 1, 3, 4, 7, 1, 8, 9, 7, 6, 3, 9, 2, 1, 3, 4, 7, 1, 8, 9, 7, 6, 3, 9...

The pattern repeats every 24 numbers!

### Lucas and Powers of 2

Lucas numbers have interesting relationships with powers of 2:
- L(3) = 4 = 2²
- L(6) = 18 = 2 × 9
- L(9) = 76 = 4 × 19

### Lucas Primes

Some Lucas numbers are prime:
- L(0) = 2 (prime)
- L(1) = 1 (not prime)
- L(2) = 3 (prime)
- L(4) = 7 (prime)
- L(5) = 11 (prime)
- L(7) = 29 (prime)
- L(8) = 47 (prime)
- L(11) = 199 (prime)

Lucas primes are used in number theory!

---

## Part 4: Lucas in Everyday Life

### Mathematics

- **Prime Testing**: The Lucas primality test uses Lucas numbers to check if large numbers are prime.

- **Formulas**: Many Fibonacci formulas have Lucas versions.

- **Sequences**: Lucas is part of a family of sequences that includes Fibonacci.

### Games and Puzzles

- **Tower of Hanoi**: Created by Lucas, uses powers of 2 (related to Lucas numbers).

- **Fibonacci-Lucas Games**: Some mathematical games use both sequences.

### Nature

- **Some flowers** have Lucas numbers of petals instead of Fibonacci.

- **Some spirals** in nature follow Lucas proportions.

- **Mathematical biology** uses Lucas numbers to model growth patterns.

---

## Part 5: 10 Fun Exercises

### Exercise 1: Lucas Calculator
Write out the Lucas sequence up to 200:
2, 1, 3, 4, 7, 11, 18, 29, 47, 76, 123, 199

Now divide each by the one before it:
1÷2 = ?
3÷1 = ?
4÷3 = ?
7÷4 = ?

How close to phi do you get?

### Exercise 2: Fibonacci vs Lucas
Write both sequences side by side:
| n | Fibonacci | Lucas |
|---|-----------|-------|
| 0 | 0         | 2     |
| 1 | 1         | 1     |
| 2 | 1         | 3     |
| 3 | 2         | 4     |
| 4 | 3         | 7     |
| 5 | 5         | 11    |

What patterns do you see?

### Exercise 3: The Lucas Spiral
Draw a Lucas spiral (similar to Fibonacci spiral but using Lucas numbers):
- Draw 1×1 squares
- Draw 2×2 squares
- Draw 3×3 squares
- Draw 4×4 squares
- Draw 7×7 squares
- Connect the corners with quarter-circles

### Exercise 4: Add Them Up
Add Fibonacci and Lucas numbers:
- F(5) + L(5) = 5 + 11 = 16
- F(6) + L(6) = 8 + 18 = 26
- F(7) + L(7) = 13 + 29 = 42

What do you notice about the sums? (Hint: they're 2 × F(n+1))

### Exercise 5: Lucas Primes Hunt
Find all Lucas numbers up to 200 that are prime. How many did you find?

### Exercise 6: Tower of Hanoi
The Tower of Hanoi with n disks requires 2^n - 1 moves. How does this relate to Lucas numbers?

- 1 disk: 1 move
- 2 disks: 3 moves
- 3 disks: 7 moves
- 4 disks: 15 moves

These are 2^n - 1, not exactly Lucas, but related!

### Exercise 7: Lucas in Art
Create a picture using Lucas numbers:
- Draw 2 circles
- Draw 1 circle next to it
- Draw 3 circles below
- Draw 4 circles to the left
- Draw 7 circles above
- Color them in a pattern!

### Exercise 8: The Lucas Pattern
Draw a pattern using Lucas numbers:
- Start with 2 stars
- Add 1 star
- Add 3 stars
- Add 4 stars
- Add 7 stars
- Arrange them in a spiral!

### Exercise 9: Compare Sequences
Write the first 10 terms of:
- Fibonacci: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34
- Lucas: 2, 1, 3, 4, 7, 11, 18, 29, 47, 76
- Add them: 2, 2, 4, 6, 10, 16, 26, 42, 68, 110

What pattern do you see in the sums?

### Exercise 10: Lucas Journal
In your math journal:
- Write the Lucas sequence up to 200
- Draw the Lucas spiral
- List 3 differences between Fibonacci and Lucas
- Write a poem about mathematical twins

---

## Part 6: Amazing Lucas Facts

### Fact 1: Lucas Did Everything
Édouard Lucas was a mathematician who:
- Studied Fibonacci and Lucas numbers
- Created the Tower of Hanoi
- Studied prime numbers
- Invented Lucas sequences!

He was one of the most creative mathematicians of the 1800s!

### Fact 2: Lucas Numbers are Named After Him
Unlike Fibonacci (who was named after his nickname), Lucas numbers are named after Édouard Lucas directly!

### Fact 3: Lucas and Primes
The Lucas primality test is one of the fastest ways to test if a very large number is prime. It's used in computer programs!

### Fact 4: Lucas Sequences
There are actually infinite sequences that follow the Fibonacci rule but start with different numbers. Lucas is just the most famous one after Fibonacci!

### Fact 5: Lucas in Nature
While Fibonacci is more common in nature, Lucas numbers do appear:
- Some flower petals follow Lucas counts
- Some spiral patterns use Lucas ratios
- Mathematical biology uses Lucas models

---

## Part 7: Lucas Poems

### The Lucas Poem
Lucas is Fibonacci's twin,
Two sequences, both so keen,
Same rule, different start,
Mathematical works of art!

### The Twin Rhyme
Fibonacci starts with zero, one,
Lucas starts with two — that's more fun!
Same rule: add the two before,
Mathematical twins forevermore!

---

## Part 8: What You've Learned

Today you discovered:

1. **Lucas numbers** follow the same rule as Fibonacci but start with 2 and 1.

2. **Lucas is Fibonacci's twin** — they're deeply connected through many mathematical relationships.

3. **The ratio of consecutive Lucas numbers** also approaches phi (1.618...).

4. **Lucas numbers** are used in prime testing and number theory.

5. **Lucas sequences** are a family of sequences that follow the Fibonacci rule with different starting numbers.

---

## Part 9: Challenge Problems

### Challenge 1: The Lucas Formula
Is there a formula like Binet's formula for Lucas numbers? (Hint: yes! L(n) = phi^n + (-phi)^(-n))

### Challenge 2: Lucas and Fibonacci Squares
What is F(n)² + F(n+1)²? (Answer: F(2n+1))
What is L(n)² + L(n+1)²? (Answer: 5 × F(2n+1) + something... research this!)

### Challenge 3: The Lucas Spiral Area
What is the area of a golden rectangle made from Lucas squares up to 7×7?

### Challenge 4: Lucas Primes
Find all Lucas numbers up to 1000 that are prime. How many are there?

### Challenge 5: Lucas in Code
Write a program (or pseudocode) that generates both Fibonacci and Lucas numbers up to 1000.

---

## Part 10: Glossary

**Algebraic Number**: A number that is the solution to a polynomial equation

**Édouard Lucas**: A French mathematician (1842-1891) who studied Fibonacci numbers and created the Tower of Hanoi

**Lucas Numbers**: 2, 1, 3, 4, 7, 11, 18, 29, 47, 76, 123, 199...

**Primality Test**: A test to check if a number is prime

**Prime Number**: A number divisible only by 1 and itself

**Sequence**: A list of numbers that follows a pattern

**Tower of Hanoi**: A puzzle with three pegs and disks of different sizes

---

## Remember!

**Lucas is Fibonacci's twin!**

The next time you think about Fibonacci numbers, remember: there's a twin sequence that follows the same rule but starts differently. Lucas numbers are just as beautiful and important as Fibonacci — they're mathematical siblings!

---

*In math, small changes can create big differences. Changing the starting numbers from 0, 1 to 2, 1 creates a whole new sequence with its own special properties. That's the beauty of mathematics!*
