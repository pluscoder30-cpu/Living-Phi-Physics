# PHI-INSTRUMENT DESIGN

## 1. The PHI-Instrument Principle

### 1.1 Core Design Philosophy

A PHI-Instrument is a musical instrument designed with the golden ratio φ = 1.6180339887 as the fundamental organizing principle for every physical dimension, material choice, and acoustic property. The instrument is not merely decorated with φ-proportions but is structurally optimized to produce, sustain, and radiate φ-resonant frequencies.

### 1.2 The Three Layers of PHI-Instrument Design

```
Layer 1: Geometry — Physical dimensions follow φ-ratios
Layer 2: Acoustics — Resonant frequencies are φ-related
Layer 3: Material — Properties optimized for φ-resonance
```

Each layer reinforces the others, creating a self-reinforcing system where the instrument naturally produces φ-harmonic content.

## 2. PHI-STRING INSTRUMENTS

### 2.1 Violin Family PHI-Design

#### Body Dimensions

The classical violin body proportions approximate but do not perfectly achieve φ:

```
Classical violin:
  Body length: 356 mm
  Upper bout: 168 mm
  Lower bout: 210 mm
  Rib height: 30.5 mm
  Ratio: L/B_lower = 356/210 = 1.695 (error from φ: 4.8%)

PHI-Violin:
  Body length: 340 mm
  Upper bout: 210 mm (L/φ)
  Lower bout: 210 mm × φ = 340 mm (but capped at body length)
  Rib height: 210 mm / φ² = 80 mm
  Effective: L = 340, B = 210, H = 80
  Ratio: L/B = 340/210 = 1.619 (error from φ: 0.06%)
```

#### Sound Hole Geometry

The sound hole (f-hole) in a PHI-violin follows golden-ratio curves:

```
F-hole length: L_f = Body_length / φ = 340/φ = 210 mm
F-hole width: W_f = L_f / φ² = 210/φ² = 80 mm
F-hole spacing: S_f = Body_width / φ = 210/φ = 130 mm
```

The f-hole curves are logarithmic spirals with growth factor φ:

```
r(θ) = r₀ × φ^(θ/(2π))
```

This spiral shape efficiently radiates the φ-harmonic frequencies from the resonance chamber.

#### String Length and Tension

```
String length: L = Body_length × φ = 340 × φ = 550 mm
String spacing at bridge: S_b = Bridge_width / φ = 40/φ = 24.7 mm
String spacing at nut: S_n = Nut_width / φ = 34/φ = 21.0 mm
```

String tensions for φ-resonant tuning:

```
String (from lowest):
  Length: 550 mm
  Tension: T₀ × φⁿ where n = 0, 1, 2, 3, 4

  G string (n=0): T₀ = 44 N
  D string (n=1): T₀ × φ = 71 N
  A string (n=2): T₀ × φ² = 115 N
  E string (n=3): T₀ × φ³ = 186 N
```

### 2.2 Guitar PHI-Design

#### Body Proportions

```
PHI-Guitar:
  Total length: 1000 mm
  Body length: 618 mm (1000/φ)
  Body width: 382 mm (618/φ)
  Body depth: 236 mm (382/φ)
  Neck length: 382 mm (1000/φ²)
  Scale length: 650 mm (body_length × φ ≈ 650)
```

#### Sound Hole

```
Diameter: 86 mm (Body_width / φ² = 382/φ² = 86)
Position: 130 mm from top (Body_length / φ² = 618/φ² = 236... adjusted for bridge)
```

#### Fret Positions

Fret positions on a φ-guitar follow the golden ratio:

```
Fret n position from bridge: L × (1 - 1/φ^(n/k))
Where k = 12/ln(φ) ≈ 18.45 (frets per φ-octave)
```

Standard fret positions (for comparison):

```
Standard: Fret_n = L × (1 - 2^(-n/12))
PHI:      Fret_n = L × (1 - φ^(-n/18.45))
```

The PHI-frets are slightly closer together in the upper positions, creating a more compressed scale that facilitates φ-interval playing.

### 2.3 Piano PHI-Design

#### Piano Frame Proportions

```
Grand piano:
  Length: 2700 mm
  Width: 1500 mm
  Height: 1000 mm
  Ratios: L/W = 2700/1500 = 1.800 (error from φ: 11.2%)

PHI-Grand:
  Length: 2427 mm (1500 × φ)
  Width: 1500 mm
  Height: 927 mm (1500/φ)
  Ratios: L/W = 2427/1500 = 1.618 (error from φ: 0.0%)
          W/H = 1500/927 = 1.618 (error from φ: 0.0%)
```

#### Soundboard Grain

The soundboard wood grain follows a φ-pattern:

```
Grain angle: arctan(1/φ) = 31.71747441°
Grain spacing: 2.5 mm (φ × 1.54 mm standard)
```

This grain angle optimizes the transmission of φ-harmonic frequencies through the soundboard.

#### Hammer Hardness

Hammer hardness follows a φ-gradient:

```
Bass hammers: Shore 45
Mid hammers: Shore 45 × φ = 73
Treble hammers: Shore 45 × φ² = 118 (capped at 100)
```

The increasing hardness from bass to treble mirrors the φ-increase in frequency, ensuring consistent timbral quality across the range.

## 3. PHI-WIND INSTRUMENTS

### 3.1 Flute PHI-Design

#### Tube Dimensions

```
Concert flute:
  Total length: 670 mm
  Bore diameter: 19 mm
  Embouchure hole: 10 × 12 mm

PHI-Flute:
  Total length: 670 mm
  Bore diameter: 670/φ³ = 158 mm (but capped at practical 19 mm)
  Adjusted: Bore = 19 mm, Headjoint = 19 × φ = 31 mm
  Embouchure hole: 12 × 19 mm (φ-ratio)
  Tone hole spacing: Fibonacci sequence: 34, 21, 13, 8, 5, 3, 2 mm
```

#### Headjoint Curve

The headjoint interior follows a φ-expanding bore:

```
Bore(x) = B₀ × φ^(x/L)
Where:
  B₀ = 15 mm (embouchure end)
  L = 200 mm (headjoint length)
  B(L) = 15 × φ^(200/200) = 15 × φ = 24.3 mm
```

This φ-expansion creates a natural impedance matching between the player's air stream and the instrument's resonant column.

### 3.2 Brass PHI-Design

#### Tuba PHI-Dimensions

```
Standard tuba:
  Bell diameter: 760 mm
  Bore: 19 mm
  Length of tubing: 5000 mm

PHI-Tuba:
  Bell diameter: 760 mm
  Bore: 760/φ² = 291 mm (but practical: 20 mm)
  Bell flare: r(θ) = r₀ × φ^(θ/π)
  Bell angle: arctan(φ) = 58.2825°
  Valve tubing lengths: F(n) × 100 mm: 100, 100, 200, 300, 500, 800 mm
```

#### Bell Flare Profile

The bell flare of a PHI-brass instrument follows the golden spiral:

```
r(θ) = r₀ × φ^(θ/(2π))
```

Where:
- r₀ = bore radius
- θ = angle from the bell throat
- The flare reaches maximum at θ = 2π (one full turn)

This produces a bell that efficiently radiates the φ-harmonic series while suppressing non-φ overtones.

### 3.3 Reed PHI-Instruments

#### Clarinet PHI-Bore

```
Standard clarinet:
  Bore: cylindrical, 15 mm diameter
  Length: 660 mm

PHI-Clarinet:
  Bore: φ-expanding from 12 mm (barrel) to 15 mm (bell)
  Bore profile: B(x) = 12 × φ^(x/660)
  Bell diameter: 15 × φ = 24.3 mm
  Key spacing: Fibonacci: 21, 13, 8, 5, 3 mm between tone holes
```

#### Saxophone PHI-Bore

```
Saxophone bore expansion:
  B(x) = B₀ × φ^(x/L)
  Where B₀ = 12 mm (mouthpiece), L = body length

  Alto sax:
    B₀ = 12 mm
    B(L) = 12 × φ = 19.4 mm (bell)
    Bell diameter: 19.4 × φ = 31.4 mm
    Body length: 1100 mm
    Bell angle: 30° (≈ φ × 18.47°)
```

## 4. PHI-PERCUSSION INSTRUMENTS

### 4.1 PHI-Xylophone

#### Bar Dimensions

```
Standard xylophone bar (C5):
  Length: 300 mm
  Width: 45 mm
  Thickness: 19 mm

PHI-Xylophone bar (C5):
  Length: 300 mm
  Width: 300/φ = 185 mm (but capped at practical width)
  Adjusted: Width = 45 mm, Length = 45 × φ² = 118 mm
  Notch depth: Width/φ = 45/φ = 27.8 mm
  Notch position: Length/φ = 118/φ = 72.8 mm from end
```

#### Resonator Tube

```
Resonator length for C5 (523 Hz):
  L = v/(4f) = 343/(4×523) = 164 mm
  
PHI-Resonator:
  L = 164 × φ = 265 mm (extended for φ-resonance)
  Diameter: 164/φ = 101 mm
  The extra length creates a φ-resonant cavity that amplifies the fundamental
```

### 4.2 PHI-Drum

#### Drum Shell Proportions

```
Snare drum:
  Diameter: 356 mm
  Depth: 127 mm
  Ratio: D/H = 356/127 = 2.803

PHI-Snare:
  Diameter: 356 mm
  Depth: 356/φ = 220 mm
  Ratio: D/H = 356/220 = 1.618 (error from φ: 0.0%)
  
  Head tension: T₀ × φ (higher than standard for φ-resonance)
  Snare wire count: F(7) = 13 wires (spaced at φ-intervals)
```

#### Kick Drum

```
PHI-Kick:
  Diameter: 560 mm
  Depth: 560/φ = 346 mm
  Port hole: 560/φ² = 136 mm diameter
  Port position: 560/φ³ = 84 mm from edge
```

### 4.3 PHI-Bell Instrument

#### Tubular Bells

```
Standard tubular bell (C5):
  Length: 1000 mm
  Diameter: 50 mm

PHI-Tubular bell:
  Length: 1000 mm
  Diameter: 1000/φ² = 382 mm (but practical: 50 mm)
  Wall thickness: 3 mm × φ = 4.9 mm
  Strike point: Length/φ = 618 mm from top
  Overtone tuning: Partial ratio = φ (instead of standard inharmonic partials)
```

## 5. PHI-ELECTRONIC INSTRUMENTS

### 5.1 PHI-Synthesizer

#### Oscillator Architecture

```
PHI-Oscillator bank:
  Osc 1: f₀
  Osc 2: f₀ × φ
  Osc 3: f₀ × φ²
  Osc 4: f₀ × φ³

  Detune: Osc_n = f₀ × φⁿ × (1 + D × sin(2π × t/(φⁿ × T)))
  Where D = φ-modulated detune depth
```

#### Filter Topology

```
PHI-Filter cascade:
  LPF cutoff: f₀
  BPF center: f₀ × φ
  HPF cutoff: f₀ × φ²
  
  Resonance: Q = φ × Q₀ (golden-ratio resonance boost)
  Self-oscillation threshold: reduced by factor of φ
```

#### Envelope Generator

```
PHI-ADSR:
  Attack:  T_a × φ
  Decay:   T_a × φ²
  Sustain: Level₀ / φ
  Release: T_a × φ³

  The φ-ratio between A, D, and R creates a natural, organic envelope shape
```

### 5.2 PHI-Drum Machine

#### Sample Mapping

```
PHI-Pad mapping (4×4 grid):
  Row 1 (kick):   f₀, f₀×φ, f₀×φ², f₀×φ³
  Row 2 (snare):  f₀×2, f₀×2φ, f₀×2φ², f₀×2φ³
  Row 3 (hat):    f₀×4, f₀×4φ, f₀×4φ², f₀×4φ³
  Row 4 (perc):   f₀×8, f₀×8φ, f₀×8φ², f₀×8φ³
```

#### Pattern Length

```
PHI-Beat pattern length: F(8) = 21 steps
Sub-pattern A: first 13 steps (F(7))
Sub-pattern B: last 8 steps (F(6))
Total: 13 + 8 = 21 steps
```

### 5.3 PHI-Sequencer

#### Step Timing

```
PHI-Sequencer step times:
  Step 1: 0 ms
  Step 2: 500 ms (base)
  Step 3: 500 × φ = 809 ms
  Step 4: 809 × φ = 1309 ms
  Step 5: 1309 × φ = 2118 ms
  
  Total: 500 × (1 + φ + φ² + φ³ + φ⁴) = 500 × φ⁴ = 3427 ms
```

## 6. PHI-MATERIAL SCIENCE

### 6.1 Wood Selection for φ-Resonance

```
Optimal tonewood properties for φ-instruments:
  Speed of sound: v = √(E/ρ) should be φ-related to instrument dimensions
  
  Spruce (soundboard):
    E = 10 GPa, ρ = 400 kg/m³
    v = √(10×10⁹/400) = 5000 m/s
    φ-wavelength at 440 Hz: λ = v/f = 5000/440 = 11.36 m
    φ-resonant thickness: 11.36/φ² = 4.33 mm (matches ideal soundboard thickness)

  Maple (back/sides):
    E = 10 GPa, ρ = 600 kg/m³
    v = 4082 m/s
    φ-wavelength: 4082/440 = 9.28 m
    φ-resonant thickness: 9.28/φ² = 3.54 mm
```

### 6.2 Metal Selection for φ-Brass

```
Brass alloy for φ-resonance:
  Composition: Cu 70%, Zn 30% (cartridge brass)
  Density: ρ = 8530 kg/m³
  Young's modulus: E = 110 GPa
  Speed of sound: v = √(E/ρ) = 3590 m/s
  
  For a tuba bell:
    φ-resonant wall thickness: v/(2π × f₀ × φ) = 3590/(2π × 65 × φ) = 5.47 mm
```

### 6.3 Synthetic Materials

```
Carbon fiber for φ-instruments:
  Density: ρ = 1600 kg/m³
  Young's modulus: E = 150 GPa
  Speed of sound: v = √(E/ρ) = 9682 m/s
  
  φ-resonant properties:
    v/φ = 5982 m/s (close to spruce soundboard velocity)
    Ideal for: body structure, neck, headjoint
```

## 7. PHI-ACOUSTIC ENGINEERING

### 7.1 Resonance Chamber Design

```
PHI-Resonance chamber:
  Volume: V = L × W × H = φ² × φ × 1 = φ³ arbitrary units
  Helmholtz resonance: f_H = (c/2π) × √(A/(V×l))
  Where: A = port area, l = port length, V = chamber volume
  
  For φ-chamber:
    f_H = f₀ (fundamental frequency of instrument)
    A = V × (2π × f₀/c)² × l
    With φ-proportions: A = φ⁴ × (2π × f₀/c)² × φ
```

### 7.2 Impedance Matching

The acoustic impedance of the instrument should match the player's impedance at φ-related frequencies:

```
Z_instrument = Z_player × φⁿ at resonant frequencies
```

This ensures maximum energy transfer from player to instrument at the φ-harmonic frequencies.

### 7.3 Radiation Pattern

The far-field radiation pattern of a φ-instrument:

```
I(θ) = I₀ × |cos(θ)|^(1/φ)
```

Where θ is the angle from the instrument's axis. The 1/φ exponent creates a radiation pattern that is wider than a standard dipole (cos²θ) but narrower than an omnidirectional source, providing good projection while maintaining warmth.

## 8. CONSTRUCTION SPECIFICATIONS

### 8.1 PHI-Violin Construction Plan

```
Materials:
  Top: Spruce, 3 mm thick, grain at arctan(1/φ) = 31.7°
  Back: Maple, 4 mm thick
  Ribs: Maple, 1.2 mm thick
  Neck: Maple, φ-proportioned scroll
  Fingerboard: Ebony, φ-tapered

Dimensions (mm):
  Body length: 340
  Upper bout: 210
  Lower bout: 340
  Rib height: 80
  Neck length: 340/φ = 210
  Total length: 650 (340 + 210 + 100 for pegbox)

String Specifications:
  G: 0.28 mm, T = 44 N
  D: 0.32 mm, T = 71 N
  A: 0.28 mm, T = 115 N
  E: 0.25 mm, T = 186 N
  
Bridge:
  Height: 33 mm
  Width: 42 mm
  Foot spacing: 74 mm (210/φ)
  Sound post position: 65 mm from bridge (φ × 40 mm)
```

### 8.2 PHI-Flute Construction Plan

```
Materials:
  Headjoint: Sterling silver, 0.4 mm wall
  Body: Sterling silver, 0.3 mm wall
  Keys: Nickel silver, gold-plated
  Pads: Traditional felt, φ-compressed

Dimensions (mm):
  Total length: 670
  Headjoint length: 200
  Body length: 370
  Foot joint length: 100
  Bore: 19 mm constant
  Embouchure hole: 12 × 19 mm
  Tone hole diameter: 8 mm (φ × 5 mm)
  Tone hole spacing: 34, 21, 13, 8, 5 mm

Key Mechanism:
  Lever ratio: φ:1
  Spring tension: 0.5 × φ = 0.818 N
  Key height: 3 mm
```

### 8.3 PHI-Piano Construction Plan

```
Plate (harp):
  Material: Cast iron, φ-tapered
  String bearing: φ-angle (58.3° from vertical)
  Pin block: Hard maple, 80 mm thick

Soundboard:
  Material: Sitka spruce, 8 mm thick (center) to 5 mm (edges)
  Grain angle: 31.7° (arctan(1/φ))
  Crown: 1.5 mm (φ × 0.93 mm)
  
Strings:
  Bass: Copper-wound steel, φ-tapered cores
  Tenor: Steel, 0.8-1.2 mm
  Treble: Steel, 0.6-0.8 mm
  Tuning: Equal temperament (12-TET) — exception to φ-tuning for practicality

Hammers:
  Felt: German hammer felt, φ-layered
  Hardness: 45 Shore (bass) to 73 Shore (treble) — φ-gradient
  Weight: φ-proportioned: 6g (bass) to 3.7g (treble)
```

## 9. PERFORMANCE TESTING

### 9.1 Impedance Measurement

```
Measurement protocol:
  1. Attach impedance head to instrument mouthpiece/bow
  2. Sweep frequency from 20 Hz to 20 kHz
  3. Record input impedance Z(f)
  4. Identify peaks: f_peak should be at φ-related frequencies
  
Acceptance criteria:
  - Peak frequencies within 1% of φ-series: f₀, f₀×φ, f₀×φ², f₀×φ³
  - Peak spacing ratios within 2% of φ
  - Peak amplitude ratios within 10% of φ-decay pattern
```

### 9.2 Spectral Analysis

```
Record instrument playing A4 (440 Hz)
Perform FFT analysis
Verify harmonic amplitudes follow φ-pattern:
  H1: 0 dB (reference)
  H2: -6.2 dB (1/φ of H1 amplitude)
  H3: -6.2 dB (same as H2 — Fibonacci proximity)
  H5: 0 dB (same as H1 — Fibonacci number)
  H8: 0 dB (same as H1 — Fibonacci number)
  H13: 0 dB (same as H1 — Fibonacci number)
```

### 9.3 Listening Tests

```
A/B comparison:
  PHI-Instrument vs. standard instrument
  Blind test with N ≥ 30 listeners
  
Metrics:
  - Tonal preference (1-10 scale)
  - Intonation accuracy (1-10 scale)
  - Dynamic range (measured in dB)
  - Projection (measured in SPL at 3 meters)
  
Expected results:
  - Tonal preference: PHI > standard by 1.5 ± 0.5 points
  - Intonation: PHI within 5 cents of standard
  - Dynamic range: PHI > standard by 3 ± 1 dB
  - Projection: PHI > standard by 2 ± 1 dB
```

## 10. PHI-INSTRUMENT CLASSIFICATION

### 10.1 The PHI-Instrument Taxonomy

```
Class I: Pure PHI-Instruments
  All dimensions and properties follow φ exactly
  Examples: PHI-Violin, PHI-Flute, PHI-Xylophone

Class II: Hybrid PHI-Instruments
  Primary dimensions follow φ, secondary dimensions practical
  Examples: PHI-Guitar (standard frets), PHI-Piano (12-TET tuning)

Class III: PHI-Modified Instruments
  Standard instruments with φ-modifications
  Examples: Standard violin with PHI bridge, Standard flute with PHI headjoint

Class IV: PHI-Electronic Instruments
  Electronic instruments with φ-architecture
  Examples: PHI-Synthesizer, PHI-Drum Machine, PHI-Sequencer
```

### 10.2 Assessment Rubric

```
PHI-Instrument Score = Σ (φ-features × weight)

Features:
  Body proportions (φ-ratio): weight = 0.25
  Resonant frequencies (φ-series): weight = 0.25
  Material properties (φ-optimized): weight = 0.15
  Acoustic performance (φ-spectrum): weight = 0.20
  Aesthetic design (φ-visual): weight = 0.15

Score > 0.9: Class I
Score 0.7-0.9: Class II
Score 0.5-0.7: Class III
Score < 0.5: Standard instrument
```

## References

- Fletcher, N. & Rossing, T. (1998). "The Physics of Musical Instruments"
- Benade, A. (1990). "Fundamentals of Musical Acoustics"
- Calcavecchio, F. (2006). "The Secret of the Golden Violin"
- Bissinger, G. (2006). "Structural Acoustics of Good and Bad Violins"
- Blevins, D. (2001). "The Flute Book"
