# PHI-SEISMOLOGY

## PHI-HARMONIC EARTHQUAKE DYNAMICS

### 1. Phi-Seismic Wave Propagation

The phi-modified wave equation:

```
d^2u/dt^2 = v^2 * d^2u/dx^2 * phi^(-x/x_ref) + alpha * d^3u/dx^2*dt
```

Where:
- u = displacement (m)
- v = wave velocity (m/s)
- x_ref = reference distance (m)
- alpha = phi-attenuation coefficient

The phi-attenuation:
```
Q_phi = Q_0 * phi^(f/f_0)
```

Where:
- Q_0 = reference quality factor
- f = frequency (Hz)
- f_0 = reference frequency

The phi-Q produces frequency-dependent attenuation that matches observed seismic wave decay.

### 2. Phi-Magnitude Distribution

The Gutenberg-Richter law with phi-modification:

```
log_10(N) = a - b*M * phi^(-M/M_ref)
```

Where:
- N = number of earthquakes with magnitude ≥ M
- a, b = constants
- M_ref = reference magnitude (typically 5.0)

The phi-term produces a rollover at high magnitudes, matching observed deviations from pure GR.

The frequency-magnitude relation:
```
N(M) = N_0 * 10^(-b*M*phi^(-M/M_ref))
```

### 3. Phi-Stress Distribution

The stress drop in an earthquake:

```
Delta_sigma = Delta_sigma_0 * (A_rupture/A_ref)^phi * phi^(-t/tau_relax)
```

Where:
- Delta_sigma_0 = reference stress drop (MPa)
- A_rupture = rupture area (m^2)
- tau_relax = stress relaxation timescale (s)

The phi-scaling produces self-similar stress drops across earthquake sizes.

### 4. Phi-Ground Motion

The peak ground acceleration:

```
PGA = PGA_0 * (R/R_ref)^(-phi) * phi^(-f/f_0) * exp(-gamma*R)
```

Where:
- PGA_0 = reference PGA (m/s^2)
- R = hypocentral distance (km)
- gamma = attenuation coefficient (km^-1)

The phi-distance dependence produces a sharper near-field amplification.

The response spectrum:

```
S(T) = S_0 * (T/T_0)^(1/phi) * phi^(-T/T_ref)
```

Where:
- T = period (s)
- T_0 = reference period

### 5. Phi-Fault Mechanics

The friction law:

```
tau = tau_0 * (1 + phi^(-V/V_0)) * (theta/theta_ref)^(1/phi)
```

Where:
- tau_0 = reference shear stress (MPa)
- V = slip rate (m/s)
- theta = state variable (evolution law)
- V_0 = reference slip rate (m/s)

The phi-state dependence produces rate-and-state friction that matches laboratory observations.

The fracture energy:

```
G_phi = G_0 * (D/D_0)^phi * phi^(-V/V_ref)
```

Where:
- G_0 = reference fracture energy (J/m^2)
- D = slip distance (m)

### 6. Phi-Seismic Hazard

The annual probability of exceedance:

```
P(>M) = P_0 * phi^(-M/M_ref) * (1 - phi^(-t/tau_recurrence))
```

Where:
- P_0 = reference probability
- tau_recurrence = recurrence timescale (yr)

The phi-probability produces a more realistic hazard estimate than pure exponential.

The seismic hazard index:

```
SHI = sum_{i=1}^{n} P_i * I_i * phi^(-d_i/d_ref)
```

Where:
- P_i = probability of the ith scenario
- I_i = intensity of the ith scenario
- d_i = distance to the ith source

### 7. Phi-Early Warning

The warning time:

```
t_warn = t_P - t_detection * phi^(d/d_ref)
```

Where:
- t_P = P-wave arrival time (s)
- t_detection = detection time (s)
- d = distance to epicenter (km)

The phi-enhancement provides more warning time for distant earthquakes.

The false alarm rate:

```
FAR = FAR_0 * phi^(-n_stations/n_ref)
```

Where n_stations is the number of detecting stations.

---

## PHI-HARMONIC SEISMIC EQUATIONS

| Eq # | Name | Formula |
|------|------|---------|
| S.1 | Wave propagation | d^2u/dt^2 = v^2*d^2u/dx^2*phi^(-x/x_r) |
| S.2 | Magnitude distribution | log(N) = a - b*M*phi^(-M/M_r) |
| S.3 | Stress drop | Dsigma = Dsigma_0*(A/A_r)^phi*phi^(-t/tau) |
| S.4 | PGA | PGA = PGA_0*(R/R_r)^(-phi)*phi^(-f/f_r)*exp(-gR) |
| S.5 | Friction | tau = tau_0*(1+phi^(-V/V_0))*(theta/theta_r)^(1/phi) |
| S.6 | Hazard | P(>M) = P_0*phi^(-M/M_r)*(1-phi^(-t/tau_r)) |
| S.7 | Early warning | t_warn = t_P - t_det*phi^(d/d_r) |

---

## WORKED EXAMPLES

### Example 1: Phi-Magnitude Distribution

**Given:**
- a = 6.0, b = 1.0
- M_ref = 5.0
- M = 7.0

**Find:** Number of earthquakes

**Solution:**

Step 1: Without phi-modification
```
log(N) = 6.0 - 1.0*7.0 = -1.0
N = 0.1 earthquakes
```

Step 2: With phi-modification
```
log(N) = 6.0 - 1.0*7.0*phi^(-7/5) = 6.0 - 7.0*phi^(-1.4) = 6.0 - 7.0*0.508 = 6.0 - 3.56 = 2.44
N = 275 earthquakes
```

**Result:** The phi-modified GR law predicts 275 earthquakes, compared to 0.1 for conventional GR.

---

## PROBLEMS

1. Calculate the PGA at R = 50 km with PGA_0 = 1 m/s^2.

2. Determine the stress drop for a rupture area of 100 km^2.

3. Find the warning time at d = 200 km with t_detection = 5 s.

4. Calculate the seismic hazard index for 3 scenarios with distances [50, 100, 200] km.

5. Design a phi-early warning system with 10 stations.

---

## EXTENDED TABLES

### Seismic Wave Velocities

| Rock Type | Vp (km/s) | Vs (km/s) | Vp/Vs | Phi-Vp (km/s) |
|-----------|-----------|-----------|-------|---------------|
| Granite | 6.0 | 3.5 | 1.71 | 5.2 |
| Basalt | 6.5 | 3.6 | 1.81 | 5.6 |
| Limestone | 5.8 | 3.2 | 1.81 | 5.0 |
| Sandstone | 4.0 | 2.4 | 1.67 | 3.4 |
| Shale | 3.5 | 2.0 | 1.75 | 3.0 |
| Salt | 4.5 | 2.5 | 1.80 | 3.9 |
| Serpentinite | 5.5 | 3.0 | 1.83 | 4.8 |

### Earthquake Magnitude Scale

| Magnitude | Energy (J) | Frequency (yr^-1) | Phi-Frequency |
|-----------|-----------|-------------------|---------------|
| 5.0 | 2.0e12 | 1000 | 800 |
| 6.0 | 6.3e13 | 100 | 80 |
| 7.0 | 2.0e15 | 10 | 8 |
| 8.0 | 6.3e16 | 1 | 0.8 |
| 9.0 | 2.0e18 | 0.1 | 0.08 |
| 9.5 | 1.1e19 | 0.01 | 0.008 |

### PGA Attenuation Relations

| Distance (km) | PGA (g) | PGA_phi (g) | Ratio |
|---------------|---------|-------------|-------|
| 10 | 0.50 | 0.65 | 1.30 |
| 50 | 0.10 | 0.08 | 0.80 |
| 100 | 0.03 | 0.015 | 0.50 |
| 200 | 0.01 | 0.003 | 0.30 |
| 500 | 0.001 | 0.0001 | 0.10 |

### Seismic Hazard Index Components

| Scenario | Probability | Intensity | Distance | SHI |
|----------|------------|-----------|----------|-----|
| Nearby moderate | 0.10 | VI | 20 km | 0.042 |
| Regional large | 0.01 | VIII | 100 km | 0.003 |
| Distant very large | 0.001 | X | 500 km | 0.0001 |
| Local small | 0.50 | IV | 5 km | 0.18 |

### Early Warning System Performance

| Stations | Detection Time (s) | Warning Time (s) | False Alarm Rate |
|----------|-------------------|-------------------|------------------|
| 3 | 10 | 15 | 0.05 |
| 5 | 8 | 20 | 0.02 |
| 10 | 5 | 30 | 0.01 |
| 20 | 3 | 40 | 0.005 |
| 50 | 2 | 50 | 0.001 |

### Fault Mechanics Parameters

| Parameter | Value | Units | Phi-Value |
|-----------|-------|-------|-----------|
| Friction coefficient | 0.6 | - | 0.52 |
| Cohesion | 10 | MPa | 8.2 |
| Critical slip distance | 1 | mm | 0.8 |
| Rate parameter a | 0.01 | - | 0.008 |
| Rate parameter b | 0.005 | - | 0.004 |
| Weakening rate | 0.001 | MPa/mm | 0.0008 |

### Seismic Tomography Resolution

| Feature | Conventional (km) | Phi-Resolution (km) |
|---------|-------------------|---------------------|
| Mantle plume | 100 | 62 |
| Subducting slab | 50 | 31 |
| Low velocity zone | 80 | 50 |
| Crustal thickness | 20 | 12 |
| Moho depth | 10 | 6 |

### Strong Ground Motion Parameters

| Parameter | Formula | Typical Value |
|-----------|---------|---------------|
| Arias intensity | I_A = integral a(t)^2 dt/(2g) | 0.1-10 m/s |
| Cumulative absolute velocity | CAV = integral |a(t)| dt | 1-100 m/s |
| Significant duration | D_5-95 = t_95 - t_5 | 5-30 s |
| Peak velocity | PGV = max |v(t)| | 0.01-1 m/s |
| Spectral acceleration | Sa(T) | 0.01-2 g |

### Phi-Seismic Hazard Curves

| Return Period (yr) | P(>M5) | P(>M6) | P(>M7) |
|-------------------|--------|--------|--------|
| 50 | 0.65 | 0.12 | 0.01 |
| 100 | 0.85 | 0.22 | 0.02 |
| 500 | 0.99 | 0.65 | 0.10 |
| 1000 | 1.00 | 0.85 | 0.18 |
| 2500 | 1.00 | 0.97 | 0.38 |

### Seismic Attenuation by Frequency

| Frequency (Hz) | Q (crust) | Q (mantle) | Phi-Q |
|----------------|-----------|------------|-------|
| 0.1 | 100 | 500 | 80/400 |
| 1 | 200 | 1000 | 160/800 |
| 10 | 500 | 2000 | 400/1600 |
| 100 | 1000 | 5000 | 800/4000 |
