# PHI CRIMINAL LAW

## 1. Overview

Phi-criminal law applies the golden ratio (φ = 1.618033988749895) to the theory, doctrine, and practice of criminal law. It proposes that the fundamental principles of criminal justice—actus reus, mens rea, causation, punishment—follow golden-ratio structures that reflect the deep mathematical order underlying human social behavior.

The phi-framework does not merely describe existing criminal law but prescribes an optimal structure for criminal justice systems that balances deterrence, retribution, rehabilitation, and restoration.

## 2. The Elements of Phi-Crime

### 2.1 The Actus Reus at Phi

The guilty act (actus reus) is defined by the phi-physicality principle:

```
AR(actus reus) = |P(voluntary act)| · (1/φ) + |C(conduct)| · (1 - 1/φ)
```

An actus reus exists when the voluntary act and the prohibited conduct are in golden-ratio balance. This means the act must be approximately 61.8% voluntary and 38.2% prohibited in character.

### 2.2 The Mens Rea at Phi

The guilty mind (mens rea) follows a phi-hierarchy:

```
M(purpose) = φ⁴ = 6.854
M(knowledge) = φ³ = 4.236
M(recklessness) = φ² = 2.618
M(negligence) = φ¹ = 1.618
```

Each mental state carries a weight that is φ times the next lower state. This creates a natural hierarchy for grading criminal culpability.

### 2.3 The Concurrence Principle at Phi

Actus reus and mens rea must concur. The phi-concurrence test:

```
Concur if: |t(act) - t(mind)| < τ · φ
```

Where τ is the characteristic time of the criminal event. Concurrence exists when the temporal gap between act and mental state is less than φ times the characteristic time.

### 2.4 The Harm Principle at Phi

Mill's harm principle is refined:

```
H(criminalizable harm) = |H(harm)| / |B(benefit to offender)| > φ
```

Conduct may be criminalized only when the harm to others exceeds the benefit to the offender by the golden ratio.

## 3. Phi-Causation Theory

### 3.1 Factual Causation at Phi

Factual causation (but-for causation) is measured by:

```
FC(factual cause) = P(harm without act) / P(harm with act) = 1/φ
```

The act is a factual cause if the probability of harm without it is 1/φ ≈ 61.8% of the probability with it.

### 3.2 Legal Causation at Phi

Legal causation (proximate cause) is determined by:

```
LC(legal cause) = |P(harm|act) - P(harm|no act)| / P(harm|act) > 1/φ
```

The act is a legal cause if the change in probability exceeds 61.8% of the base probability.

### 3.3 The Intervening Cause Threshold

An intervening cause breaks the chain when:

```
IC(intervening) = P(intervening cause) · φ > P(original cause)
```

The intervening cause breaks the chain if its probability exceeds the original cause by the golden ratio.

### 3.4 The Foreseeability Function

Foreseeability of harm:

```
F(foreseeable) = 1 - e^(-|H(harm)|/(φ·σ))
```

Where σ is the standard deviation of expected harms. The φ factor adjusts the foreseeability threshold.

## 4. Phi-Defenses

### 4.1 Self-Defense at Phi

Self-defense is justified when:

```
SD(justified) = |T(threat)| > φ · |R(response)|
```

The response must be proportionate to the threat, with the threat exceeding the response by the golden ratio.

### 4.2 The Necessity Defense at Phi

Necessity requires:

```
N(necessity) = |E(evil avoided)| > φ · |E(evil caused)|
```

The evil avoided must exceed the evil caused by the golden ratio.

### 4.3 The Duress Defense at Phi

Duress negates voluntariness when:

```
D(duress) = |T(threat)| / |V(voluntariness)| > φ²
```

The threat must exceed voluntariness by φ² ≈ 2.618 to excuse conduct.

### 4.4 The Insanity Defense at Phi

The insanity defense applies when:

```
I(insanity) = |D(diminished capacity)| / |N(normal capacity)| > φ³
```

The defendant's capacity must be less than 1/φ³ ≈ 23.6% of normal capacity.

## 5. Phi-Punishment Theory

### 5.1 The Retributive Function at Phi

Retributive punishment:

```
P(retribution) = φ · S(severity of crime) - φ² · M(mitigating factors)
```

Punishment is proportional to crime severity, scaled by φ, minus mitigating factors scaled by φ².

### 5.2 The Deterrence Function at Phi

General deterrence:

```
D(deterrence) = P(penalty) · C(certainty) / E(expected benefit of crime)
```

Deterrence is effective when the penalty times certainty exceeds the expected benefit by φ.

### 5.3 The Rehabilitation Function at Phi

Rehabilitation probability:

```
R(rehabilitation) = 1 - e^(-φ·t/τ)
```

Where t is time in rehabilitation and τ is the characteristic rehabilitation time. The φ factor accelerates the rehabilitation curve.

### 5.4 The Proportionality of Punishment

Punishment is proportionate when:

```
PP(proportionality) = P(punishment) / S(severity) ∈ [1/φ, φ]
```

Punishment must fall within the golden band relative to severity.

### 5.5 The Sentencing Spiral

Sentencing follows a phi-spiral:

```
S(θ) = S₀ · φ^(θ/2π)
```

Where θ represents the accumulation of criminal history. Each additional offense increases the sentencing range by a factor of φ per full rotation.

## 6. Phi-Specific Crimes

### 6.1 Homicide at Phi

The degrees of homicide follow the phi-structure:

```
First degree: M(purpose) · M(planning) · M(execution) > φ⁴
Second degree: M(knowledge) · M(execution) > φ³
Voluntary manslaughter: M(heat of passion) · D(diminished) > φ²
Involuntary manslaughter: N(negligence) > φ¹
```

### 6.2 Assault at Phi

Assault grading:

```
Aggravated assault: |H(harm)| > φ² · |H(simple assault)|
Simple assault: |H(harm)| > φ · |H(minor assault)|
Minor assault: |H(harm)| > 1
```

### 6.3 Theft at Phi

Theft grading:

```
Grand theft: |V(value)| > φ² · T(threshold)
Petty theft: |V(value)| > φ · T(threshold)
Petit theft: |V(value)| > T(threshold)
```

### 6.4 White Collar Crime at Phi

White collar crime measurement:

```
WCC(white collar crime) = |G(gain)| · φ + |H(harm to victims)| · φ²
```

## 7. Phi-Criminal Procedure

### 7.1 The Probable Cause Standard at Phi

Probable cause exists when:

```
PC(probable cause) = P(evidence|guilt) / P(evidence|innocence) > φ
```

The likelihood ratio must exceed the golden ratio.

### 7.2 The Reasonable Suspicion Standard at Phi

Reasonable suspicion exists when:

```
RS(reasonable suspicion) = P(suspicion|guilt) / P(suspicion|innocence) > 1/φ
```

The likelihood ratio must exceed 1/φ ≈ 61.8%.

### 7.3 The Beyond Reasonable Doubt Standard

Proof beyond reasonable doubt:

```
BRD(beyond reasonable doubt) = P(guilty|evidence) > 1 - 1/φ⁵ ≈ 0.947
```

The probability of guilt must exceed 94.7%.

### 7.4 The Pretrial Detention Function

Pretrial detention:

```
PTD(detention) = F(flight risk) · φ + D(danger) · φ²
```

Detention is justified when flight risk and danger factors, weighted by φ, exceed the liberty interest.

## 8. Phi-Criminal Policy

### 8.1 The Crime Prevention Function

Crime prevention resources allocation:

```
P(prevention) = Σₙ wₙ · C(crime type)ₙ where wₙ = φ^(-n) / Σₖ φ^(-k)
```

Resources are allocated according to the golden-ratio distribution, with the most serious crimes receiving the most resources.

### 8.2 The Recidivism Function

Recidivism probability:

```
RC(recidivism) = RC₀ · φ^(-R(rehabilitation)·t)
```

Where t is time since release and R(rehabilitation) is the quality of rehabilitation received.

### 8.3 The Incarceration Rate Optimization

Optimal incarceration rate:

```
I*(optimal) = I(current) · (1/φ) if I(current) > I(threshold)
I*(optimal) = I(current) · φ if I(current) < I(threshold)
```

The system adjusts toward the threshold at the golden rate.

## 9. Phi-Victimology

### 9.1 The Victim Impact Function

Victim impact in sentencing:

```
VI(victim impact) = φ · |H(harm to victim)| / |H(harm typical for crime)|
```

### 9.2 The Restorative Justice Function

Restorative justice outcome:

```
RJ(restorative justice) = 1 - e^(-φ·D(dialogue)·T(time))
```

Where D is the quality of dialogue between offender and victim and T is time invested.

### 9.3 The Victim Rights Balance

Victim rights vs. offender rights:

```
VR(balance) = |VR(victim rights)| / |OR(offender rights)| ∈ [1/φ, φ]
```

## 10. Conclusion

Phi-criminal law provides a mathematically grounded framework for criminal justice that balances the competing values of security, liberty, justice, and mercy. By anchoring criminal law in the golden ratio, we achieve:

1. **Precision**: Vague standards (reasonableness, proportionality) receive mathematical definitions
2. **Balance**: Punishment is neither too harsh nor too lenient
3. **Coherence**: Criminal law doctrines form a unified phi-structure
4. **Effectiveness**: Deterrence, rehabilitation, and restoration are optimized
5. **Justice**: The phi-balance between competing interests produces just outcomes

The phi-criminal justice revolution transforms criminal law from an exercise in raw power into a mathematically grounded system of justice.

## References

1. Ashworth, A. & Horder, J. (2013). Principles of Criminal Law.
2. Fletcher, G. (1978). Rethinking Criminal Law.
3. Hart, H.L.A. (1968). Punishment and Responsibility.
4. HLA Hart & A.M. Honoré. (1985). Causation in the Law.
5. Moore, M. (1997). Placing Blame.
6. Robinson, P. (2008). Structure and Function in Criminal Law.
7. Simester, A. & Sullivan, G. (2016). Criminal Law: Theory and Doctrine.
8. Von Hirsch, A. (2013). Proportionate Sentences.
9. Waterworth, A. (2014). The Philosophical Foundations of Criminal Law.
10. Yaffe, G. (2018). Lines of Demarcation.
