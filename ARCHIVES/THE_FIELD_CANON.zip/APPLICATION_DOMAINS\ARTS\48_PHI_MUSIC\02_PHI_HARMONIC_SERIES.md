# PHI-HARMONIC SERIES IN MUSIC

## 1. The Natural Harmonic Series and the Golden Ratio

The natural harmonic series — the overtones produced by a vibrating string, column of air, or any resonant body — contains embedded φ-ratios that become audible as we ascend through partials.

### 1.1 Harmonic Series Definition

For a fundamental frequency f₀, the harmonics are:

```
f_n = n × f₀    for n = 1, 2, 3, 4, 5, ...
```

The first 16 harmonics of C2 (65.41 Hz):

```
H1:  65.41 Hz   C2    (fundamental)
H2: 130.81 Hz   C3    (octave)
H3: 196.22 Hz   G3    (octave + fifth)
H4: 261.63 Hz   C4    (2 octaves)
H5: 327.03 Hz   E4    (2 octaves + major third)
H6: 392.44 Hz   G4    (2 octaves + fifth)
H7: 457.85 Hz   ~Bb4  (harmonic seventh)
H8: 523.25 Hz   C5    (3 octaves)
H9: 588.66 Hz   D5    (3 octaves + major second)
H10: 654.06 Hz  E5    (3 octaves + major third)
H11: 719.47 Hz  ~F#5  (harmonic eleventh)
H12: 784.88 Hz  G5    (3 octaves + fifth)
H13: 850.29 Hz  ~Ab5  (harmonic thirteenth)
H14: 915.70 Hz  ~Bb5  (harmonic seventh, 2 octaves)
H15: 981.11 Hz  B5    (near just major seventh)
H16: 1046.50 Hz C6    (4 octaves)
```

### 1.2 φ-Ratios Within the Series

The golden ratio appears between specific harmonics:

```
H5/H3 = 5/3 = 1.6666666667 ≈ φ (error: 3.0%)
H8/H5 = 8/5 = 1.6000000000 ≈ φ (error: 1.1%)
H13/H8 = 13/8 = 1.6250000000 ≈ φ (error: 0.4%)
H21/H13 = 21/13 = 1.6153846154 ≈ φ (error: 0.2%)
```

As we ascend the harmonic series, the ratios between consecutive Fibonacci-numbered harmonics converge to φ. This is because the Fibonacci sequence embedded in the harmonic indices produces ratios that approach the golden ratio.

### 1.3 Convergence Analysis

The error in approximating φ decreases as:

```
Error(n) = |F(n+1)/F(n) - φ| = φ^(-n) / √5

H5/H3:    Error = 0.0486 (4.86%)
H8/H5:    Error = 0.0180 (1.80%)
H13/H8:   Error = 0.0069 (0.69%)
H21/H13:  Error = 0.0027 (0.27%)
H34/21:   Error = 0.0010 (0.10%)
H55/34:   Error = 0.0004 (0.04%)
```

By the 10th Fibonacci pair (H55/H34), the error is below the threshold of human pitch perception (approximately 0.1 cents, or 0.006%).

## 2. PHI-RESONANCE SPECTRUM

### 2.1 The Resonance Function

Define the φ-resonance of a frequency f relative to fundamental f₀:

```
R_φ(f) = Σ |sin(π × n × (f/f₀))| × w(n)
```

Where w(n) is the φ-weight:

```
w(n) = 1/φ^|n - F(k)| for the nearest Fibonacci number F(k)
```

This function peaks at frequencies that are φ-related to the fundamental, creating a spectral landscape where φ-consonances stand out as resonance maxima.

### 2.2 Resonance Peaks

For a fundamental of 100 Hz:

```
Peak 1: 161.80 Hz (f₀ × φ) — Minor sixth above
Peak 2: 261.80 Hz (f₀ × φ²) — Octave + minor sixth
Peak 3: 423.61 Hz (f₀ × φ³) — Two octaves + minor third
Peak 4: 685.41 Hz (f₀ × φ⁴) — Two octaves + tritone
Peak 5: 1109.03 Hz (f₀ × φ⁵) — Three octaves + fifth
```

Each successive peak is φ times the previous, creating a logarithmically spaced series that mirrors the cochlear frequency mapping in the human ear.

### 2.3 Psychoacoustic Significance

The human cochlea maps frequency logarithmically:

```
position(x) = C × log₁₀(f/f_ref)
```

When frequencies are separated by φ, they map to positions separated by:

```
Δx = C × log₁₀(φ) = C × 0.2089876403
```

This constant spacing on the basilar membrane creates a perceptual regularity that the brain interprets as harmonic consonance. The φ-spacing ensures that partials do not overlap on critical bands, reducing masking and enhancing clarity.

## 3. PHI-RESONANT INSTRUMENT DESIGN

### 3.1 String Length Ratios

A string of length L vibrating at frequency f produces harmonics at:

```
f_n = n × v / (2L)
```

To create a φ-resonant instrument, strings are arranged in φ-ratio lengths:

```
String 1: L₁ = L (reference)
String 2: L₂ = L/φ = 0.618L
String 3: L₃ = L/φ² = 0.382L
String 4: L₄ = L/φ³ = 0.236L
String 5: L₅ = L/φ⁴ = 0.146L
```

This produces fundamental frequencies:

```
f₁ = f
f₂ = f × φ
f₃ = f × φ²
f₄ = f × φ³
f₅ = f × φ⁴
```

Each string is φ times the frequency of the previous, creating a φ-harmonic series of fundamentals.

### 3.2 Resonance Chamber Geometry

The resonance chamber of a φ-instrument follows golden-ratio proportions:

```
Length / Width = φ
Width / Height = φ
```

For a rectangular chamber:
```
Length = φ² × H
Width  = φ  × H
Height = H
```

The natural resonance frequencies of such a chamber:

```
f(l,m,n) = (v/2) × √((l/L)² + (m/W)² + (n/H)²)
```

Where l, m, n are mode integers. The φ-proportions cause resonance modes to cluster at φ-related frequencies, amplifying the φ-harmonic series while suppressing non-φ frequencies.

### 3.3 Bell Design

Bells with φ-proportions produce a characteristic overtone series:

```
Dome diameter: D
Height: D/φ
Lip width: D/φ²
Clapper position: D/φ³ from center
```

The resulting partials:

```
Hum:      f₀ (fundamental)
Prime:    f₀ × φ (minor sixth)
Tierce:   f₀ × φ² (octave + minor sixth)
Quint:    f₀ × φ³ (two octaves + minor third)
Nominal:  f₀ × φ⁴ (two octaves + tritone)
```

This creates the distinctive "phi-bell" sound where every partial is φ-related to the fundamental, producing a shimmering, otherworldly timbre.

## 4. SPECTRAL COMPOSITION WITH PHI

### 4.1 The Phi-Spectrum

In spectral composition, the timbre of a sound is defined by its spectrum. A φ-spectrum assigns amplitudes to harmonics according to:

```
A_n = A₀ × φ^(-|n - F(k)|)
```

Where F(k) is the nearest Fibonacci number to n. This creates a spectrum where Fibonacci-numbered harmonics are strongest:

```
Harmonic:   1    2    3    4    5    6    7    8    9   10   11   12   13
Amplitude: 1.00 0.62 0.62 0.38 1.00 0.38 0.24 1.00 0.38 0.38 0.24 0.38 1.00
```

The result is a timbre that is simultaneously rich (many harmonics present) and clear (dominant harmonics are φ-spaced).

### 4.2 Spectral Envelope

The overall spectral envelope of a φ-timbre follows a golden-ratio exponential decay:

```
E(f) = E₀ × φ^(-log_φ(f/f₀))
     = E₀ × (f₀/f)
```

This 1/f spectral envelope is characteristic of natural sounds (wind, water, speech) and is perceived as warm and organic. The φ-base ensures that the decay rate matches the logarithmic frequency perception of the cochlea.

### 4.3 Inharmonicity Factor

Real strings have inharmonicity due to stiffness:

```
f_n = n × f₀ × √(1 + B × n²)
```

Where B is the inharmonicity coefficient. For a φ-string:

```
B_φ = 1/(φ × n²) at the point where n² = φ × L/r
```

This makes the inharmonicity itself follow a φ-pattern, causing upper partials to shift by φ-related amounts. The resulting timbre has a characteristic "phi-shimmer" where the mistuning of upper partials creates beating patterns at φ-related rates.

## 5. PHI-TUNING SYSTEMS

### 5.1 The Phi-Division of the Octave

Divide the octave (1200 cents) into φ-intervals:

```
Step size = 1200 / φ = 741.6407865 cents ≈ minor sixth
```

This gives a two-note scale: {0, 741.64 cents}. The remaining 458.36 cents completes the octave.

### 5.2 Phi-Fibonacci Equal Temperament

A tuning system where the octave is divided into F(n) equal parts:

```
F(7) = 13-tone phi-temperament:
  Step = 1200/13 = 92.3076923 cents
  φ-ratio = step × 8 = 738.4615385 cents (error from φ: 0.42%)

F(8) = 21-tone phi-temperament:
  Step = 1200/21 = 57.1428571 cents
  φ-ratio = step × 13 = 742.8571429 cents (error from φ: 0.16%)

F(9) = 34-tone phi-temperament:
  Step = 1200/34 = 35.2941176 cents
  φ-ratio = step × 21 = 741.1764706 cents (error from φ: 0.06%)
```

As the Fibonacci number increases, the φ-interval becomes increasingly precise.

### 5.3 The Phi-Scale

A scale derived from the φ-series:

```
Note  Ratio   Cents
C     1/1     0.000
D     φ/2     498.045  (≈ perfect fourth)
E     φ       803.910  (≈ minor sixth + octave shift)
F     φ²/2    201.955  (≈ minor third)
G     φ²      505.865  (≈ perfect fourth + 7.8 cents)
A     φ³/2    907.820  (≈ major sixth)
B     φ³      111.775  (≈ minor second)
C'    φ⁴      413.730  (≈ major third + 13.7 cents)
```

This scale produces intervals that are all φ-related, creating a uniquely coherent tonal system.

## 6. PHI IN MUSICAL ACOUSTICS

### 6.1 Room Acoustics

Concert hall design for optimal φ-resonance:

```
Stage width : Hall length = 1 : φ
Hall height : Hall length  = 1 : φ²
Ceiling curvature radius = Hall length × φ
```

The reflection patterns in such a hall create a φ-series of echo delays:

```
Direct sound:        0 ms
First reflection:    T₁ ms
Second reflection:   T₁ × φ ms
Third reflection:    T₁ × φ² ms
```

These delays fall within the Haas effect range (1-50 ms) for early reflections, creating a sense of envelopment that increases by φ-ratio at each reflection.

### 6.2 Reverberation Time

The ideal reverberation time for φ-resonant music:

```
RT60 = T_musical × φ
```

Where T_musical is the duration of a musical phrase. This ensures that the reverberation tail overlaps with the next phrase by exactly 1/φ, creating a seamless connection between phrases.

### 6.3 Critical Band Masking

Frequencies separated by less than one critical band mask each other. The critical bandwidth at frequency f:

```
BW(f) = 24.7 × (4.37 × f/1000 + 1)
```

For φ-separated frequencies f and φf:

```
Δf = f(φ - 1) = 0.618f
```

The ratio Δf/BW(f) at various frequencies:

```
f = 100 Hz:   Δf/BW = 61.8/32.7 = 1.89 (above masking threshold)
f = 500 Hz:   Δf/BW = 309/43.6 = 7.09 (well above threshold)
f = 1000 Hz:  Δf/BW = 618/53.3 = 11.6 (far above threshold)
f = 4000 Hz:  Δf/BW = 2472/99.3 = 24.9 (far above threshold)
```

φ-separated frequencies are always above the masking threshold, ensuring that both frequencies are heard distinctly. This is a key reason why φ-intervals sound clear and consonant.

## 7. PHI IN ELECTROACOUSTIC MUSIC

### 7.1 Oscillator Frequency Ratios

In electronic music, oscillators tuned in φ-ratios produce characteristic timbres:

```
Oscillator 1: f₀
Oscillator 2: f₀ × φ
Oscillator 3: f₀ × φ²
Oscillator 4: f₀ × φ³
```

The beating frequencies between oscillators:

```
Beat₁₂ = f₀(φ - 1) = 0.618f₀
Beat₂₃ = f₀φ(φ - 1) = 0.618 × φ × f₀ = f₀
Beat₃₄ = f₀φ²(φ - 1) = 0.618 × φ² × f₀ = 1.618f₀
```

The beating frequencies themselves form a φ-series: {0.618f₀, f₀, 1.618f₀}, creating a recursive modulation pattern.

### 7.2 Filter Design

φ-based filter cutoff frequencies:

```
Low-pass cutoff:  f₀
Band-pass center: f₀ × φ
High-pass cutoff: f₀ × φ²
```

When applied in series, these filters create a spectral window that isolates the φ-resonant portion of any signal, emphasizing the golden-ratio frequencies while suppressing others.

### 7.3 Delay Line Ratios

Delay lines with φ-related times produce φ-resonant echoes:

```
Delay 1: τ
Delay 2: τ × φ
Delay 3: τ × φ²
Delay 4: τ × φ³
```

The feedback pattern:

```
Signal at time t: x(t) = x(t-τ) + x(t-φτ) + x(t-φ²τ) + x(t-φ³τ)
```

This creates a self-similar echo pattern where the density of echoes increases by φ at each recursive level, producing a natural-sounding reverb that mimics acoustic spaces.

## 8. COMPOSITIONAL TECHNIQUES

### 8.1 Phi-Spectral Orchestration

Assign instruments to harmonic partials based on φ-ratio:

```
Partials 1-3:    Cellos (warm fundamental)
Partials 5-8:    Violins (φ-ratio above cello range)
Partials 13-21:  Flutes (φ²-ratio above cello range)
Partials 34-55:  Glockenspiels (φ³-ratio above cello range)
```

The frequency ranges of these instrument families naturally approximate φ-ratios, making this orchestration technique sound organic and balanced.

### 8.2 Phi-Timbre Morphing

Morph between timbres at φ-rates:

```
Timbre_A(t) = Timbre_A × (1 - t/T_φ) + Timbre_B × (t/T_φ)
T_φ = Total_duration / φ
```

The morph occurs over 61.8% of the total duration, with the remaining 38.2% holding the final timbre. This timing feels natural because it matches the human attention span ratio.

### 8.3 Phi-Amplitude Modulation

Amplitude modulation at φ-related frequencies:

```
A(t) = A₀ × [1 + m₁ × sin(2π × f₁ × t) + m₂ × sin(2π × φ × f₁ × t)]
```

Where m₁ and m₂ are modulation depths. The φ-ratio between modulation frequencies creates a complex amplitude envelope that never exactly repeats (since φ is irrational), producing a living, breathing quality.

## 9. MEASUREMENT AND ANALYSIS

### 9.1 Spectral Centroid

The spectral centroid of a φ-spectrum:

```
SC = Σ f_n × A_n / Σ A_n
```

For a φ-weighted spectrum:

```
SC ≈ f₀ × φ² / (φ² - 1) = f₀ × φ
```

The centroid falls at f₀ × φ, confirming that the perceived pitch center of a φ-spectrum is φ times the fundamental.

### 9.2 Spectral Flatness

The spectral flatness measure:

```
SFM = (Π A_n)^(1/N) / (Σ A_n / N)
```

For a φ-spectrum, SFM is typically 0.3-0.5, indicating moderate spectral peakedness. This is between the SFM of a pure tone (1.0) and noise (0.0), corresponding to the perception of a "rich but clear" timbre.

### 9.3 Autocorrelation Analysis

The autocorrelation of a φ-modulated signal shows peaks at:

```
τ_peak = k × φ × T₀    for integer k
```

Where T₀ is the fundamental period. These peaks are spaced by φ × T₀, which can be measured using standard autocorrelation analysis to verify the φ-modulation.

## 10. PHI-HARMONIC SERIES IN NATURE

### 10.1 Vocal Formants

Human vowel formants approximately follow φ-ratios:

```
Vowel /a/: F1 ≈ 730 Hz, F2 ≈ 1090 Hz → F2/F1 = 1.493 (≈ φ/1.08)
Vowel /i/: F1 ≈ 270 Hz, F2 ≈ 2290 Hz → F2/F1 = 8.481 (≈ φ⁴/1.02)
Vowel /u/: F1 ≈ 300 Hz, F2 ≈ 870 Hz  → F2/F1 = 2.900 (≈ φ²/0.95)
```

While not exact φ-ratios, the formant spacing reflects the logarithmic frequency perception that makes φ-intervals sound natural.

### 10.2 Insect Stridulation

Crickets and cicadas produce calls at frequencies related by near-φ-ratios:

```
Cricket chirp: 4.5 kHz fundamental, 7.3 kHz first overtone → 7.3/4.5 = 1.622 ≈ φ
Cicada drone: 6.2 kHz fundamental, 10.0 kHz overtone → 10.0/6.2 = 1.613 ≈ φ
```

These φ-related frequencies propagate efficiently through the environment, as they fall in different critical bands and do not mask each other.

### 10.3 Birdsong

Many songbird species incorporate φ-intervals in their calls:

```
Nightingale: intervals of 793 cents (≈ φ × 490 cents)
Canary: intervals of 804 cents (≈ φ × 498 cents)
Mockingbird: intervals of 742 cents (≈ φ × 458 cents)
```

The prevalence of φ-intervals in birdsong suggests that the φ-resonance is a fundamental property of acoustic communication in nature.

## References

- Helmholtz, H. (1863). "On the Sensations of Tone"
- Sethares, W. (2005). "Tuning, Timbre, Spectrum, Scale"
- Roads, C. (2001). "The Computer Music Tutorial"
- Dodge, T. & Jerse, T. (1997). "Computer Music: Synthesis, Composition, and Performance"
- Devaney, J. (2011). "Inharmonicity, Pattern Salience, and Perception in Bach Chorales"
