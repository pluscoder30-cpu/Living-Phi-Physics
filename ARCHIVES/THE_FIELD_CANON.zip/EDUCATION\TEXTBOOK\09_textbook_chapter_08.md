# Chapter 8: Living Mathematics

## Phi in Biology, Nature, and Growth

---

### Overview

The golden ratio is not just an abstract mathematical constant. It is one of the most frequently occurring numbers in biology. Plants use the golden ratio to arrange leaves, seeds, and petals. Animals use it in the proportions of their bodies. The human body is built on golden proportions.

In this chapter, we will explore the many ways the golden ratio (and related constants) appear in living systems. This is mathematics as nature practices it — not in textbooks, but in leaves, shells, flowers, and bones.

---

## Lesson 8.1: Phyllotaxis — The Mathematics of Leaf Arrangement

### Explanation

**Phyllotaxis** is the study of how leaves, seeds, petals, and other plant organs are arranged on a stem or in a flower head. The word comes from the Greek *phyllon* (leaf) and *taxis* (arrangement).

The key discovery in phyllotaxis is that plants arrange their organs at angles that approximate the **golden angle**:

Golden angle = 360° × (1 - 1/φ) ≈ 137.5077...°

This angle ensures that each leaf gets maximum sunlight and minimum overlap with its neighbors.

### Why 137.5°?

Consider a plant that produces leaves at regular angular intervals. If the angle is a rational fraction of 360° (like 90° or 120°), the leaves line up in straight rows, leaving large gaps. This is wasteful — some leaves are in full sun, others are in deep shade.

If the angle is an irrational fraction of 360°, the leaves never line up exactly. They fill the space more uniformly. The most irrational number is the golden ratio φ, because it is the "most irrational" — its continued fraction representation has all 1s, making it the hardest number to approximate by rationals.

The golden angle is 360°/φ² ≈ 137.5°, and it is the angle that maximizes the uniformity of leaf arrangement.

**Key Concept**: The golden angle (137.5°) is the most irrational angle, ensuring maximum uniformity in leaf arrangement.

### Phyllotaxis Fractions

Phyllotaxis is often described using fractions that approximate 1/φ²:

| Fraction | Approximation | Angle | Example |
|----------|--------------|-------|---------|
| 1/2 | 0.5000 | 180° | Some grasses |
| 1/3 | 0.3333 | 120° | Some flowers |
| 2/5 | 0.4000 | 144° | Many plants |
| 3/8 | 0.3750 | 135° | Common |
| 5/13 | 0.3846 | 138.46° | Very common |
| 8/21 | 0.3810 | 137.14° | Extremely common |
| 13/34 | 0.3824 | 137.65° | Nearly perfect |
| 21/55 | 0.3818 | 137.45° | Almost perfect |

Notice that the denominators are Fibonacci numbers, and the fractions approach 1/φ² ≈ 0.3820.

### Worked Example 8.1.1

A sunflower produces seeds at an angle of 137.5° from the previous seed. After 8 seeds, what are the angular positions?

**Solution**: 
Seed 1: 0°
Seed 2: 137.5°
Seed 3: 275.0° (= 275° mod 360°)
Seed 4: 412.5° (= 52.5° mod 360°)
Seed 5: 550.0° (= 190.0° mod 360°)
Seed 6: 687.5° (= 327.5° mod 360°)
Seed 7: 825.0° (= 105.0° mod 360°)
Seed 8: 962.5° (= 242.5° mod 360°)

The angular positions are: 0°, 137.5°, 275°, 52.5°, 190°, 327.5°, 105°, 242.5°.

These are spread out around the circle with no two seeds too close together.

### Worked Example 8.1.2

Why is the golden angle better than 120° for leaf arrangement?

**Solution**: With 120° spacing:
Leaf 1: 0°
Leaf 2: 120°
Leaf 3: 240°
Leaf 4: 360° = 0° (same as Leaf 1!)

After 3 leaves, the pattern repeats. Leaf 4 is directly above Leaf 1. This means the leaves line up in 3 straight rows, leaving large gaps between the rows.

With 137.5° spacing, the leaves never line up exactly, filling the space much more uniformly.

### Practice Problems

1. A plant produces leaves at 137.5° intervals. What are the angular positions of the first 6 leaves?
2. Why is 120° spacing bad for leaf arrangement?
3. Compute the phyllotaxis fraction 8/21 and compare it to 1/φ².
4. Why do Fibonacci numbers appear in the denominators of phyllotaxis fractions?
5. Find a real plant and measure the angle between consecutive leaves. How close is it to 137.5°?

### Teacher's Notes

**Field Activity**: Take students outdoors to examine leaf arrangements on real plants. Measure the angle between consecutive leaves using a protractor. Compare to 137.5°.

**Misconception**: Not all plants use the golden angle exactly. Some use 120°, 144°, or other angles. The golden angle is optimal, but evolution does not always find the optimal solution.

---

## Lesson 8.2: Flower Petals and Fibonacci Numbers

### Explanation

The number of petals on a flower is often a Fibonacci number. Here is a table of common flowers and their petal counts:

| Flower | Petals | Fibonacci? |
|--------|--------|-----------|
| Lily | 3 | F(4) = 3 ✓ |
| Buttercup | 5 | F(5) = 5 ✓ |
| Delphinium | 8 | F(6) = 8 ✓ |
| Marigold | 13 | F(7) = 13 ✓ |
| Asters | 21 | F(8) = 21 ✓ |
| Daisies | 34, 55, or 89 | F(9), F(10), or F(11) ✓ |

This is not a coincidence. The number of petals is determined by the same developmental process that governs phyllotaxis.

### Why Fibonacci Numbers?

The number of petals on a flower is determined by the number of primordia (embryonic organs) that form at the tip of the flower bud. These primordia are arranged at the golden angle, just like leaves on a stem.

The number of visible petals corresponds to the number of spirals in the flower head, which is a Fibonacci number. This is the same phenomenon that produces Fibonacci numbers in sunflower spirals.

**Key Concept**: The number of petals is a Fibonacci number because petals are arranged at the golden angle, and the golden angle produces Fibonacci spirals.

### Exceptions

Not all flowers have Fibonacci numbers of petals. Some common exceptions:

- **Tulips**: typically 6 petals (not a Fibonacci number, but 6 = 2 × 3)
- **Some roses**: variable, often not Fibonacci
- **Clematis**: typically 4-8 petals
- **Some flowers**: double flowers with many more petals than normal

These exceptions are due to mutations or cultivation that disrupt the normal developmental process.

### Worked Example 8.2.1

A flower has 13 petals. Is 13 a Fibonacci number?

**Solution**: The Fibonacci sequence is: 0, 1, 1, 2, 3, 5, 8, 13, 21, ...

Yes, 13 = F(7) is a Fibonacci number. ✓

### Worked Example 8.2.2

A flower has 12 petals. Is 12 a Fibonacci number?

**Solution**: The Fibonacci numbers near 12 are 8 and 13. Since 12 is not in the Fibonacci sequence, 12 is not a Fibonacci number.

This flower might be a mutation or a cultivated variety with a non-standard petal count.

### Practice Problems

1. Count the petals on 5 different flowers. Are the counts Fibonacci numbers?
2. Why might some flowers have non-Fibonacci petal counts?
3. Research: what is a "double flower"? How does it affect petal count?
4. Why do lilies have 3 petals, buttercups have 5, and delphiniums have 8?
5. Predict the petal count of a flower based on its position in the Fibonacci sequence.

### Teacher's Notes

**Classroom Activity**: Bring several flowers to class (or have students bring them). Count the petals together. Discuss whether each count is a Fibonacci number.

**Botany Connection**: This lesson connects mathematics to botany. The developmental biology of flower formation is governed by the same mathematical principles as phyllotaxis.

---

## Lesson 8.3: Pinecones, Pineapples, and Seed Heads

### Explanation

Pinecones, pineapples, and sunflower heads all have spirals, and the number of spirals is almost always a pair of consecutive Fibonacci numbers.

### Pinecones

A pinecone has two sets of spirals: one turning clockwise, the other counterclockwise. The number of spirals in each direction is typically:

- 8 and 13 (most common)
- 5 and 8
- 13 and 21

These are pairs of consecutive Fibonacci numbers.

### Pineapples

A pineapple has three sets of spirals, with counts that are typically:

- 8, 13, and 21 (three consecutive Fibonacci numbers)
- 5, 8, and 13

### Sunflower Heads

A sunflower head has two sets of spirals, with counts that are typically:

- 34 and 55
- 55 and 89
- 89 and 144

These are larger Fibonacci numbers because the sunflower head has more seeds.

### Why Fibonacci Numbers in Spirals?

The spiral counts are Fibonacci numbers because the seeds are arranged at the golden angle. The golden angle produces a pattern where the visible spirals correspond to Fibonacci numbers.

This can be understood mathematically: the golden ratio φ satisfies φ² = φ + 1, which means that the best rational approximations to φ are ratios of consecutive Fibonacci numbers. When you count spirals in a sunflower, you are essentially counting the best rational approximations to the golden angle.

**Key Concept**: Fibonacci spirals in nature are a consequence of the golden angle.

### Worked Example 8.3.1

A pinecone has 8 spirals clockwise and 13 spirals counterclockwise. What is the ratio of the larger to the smaller?

**Solution**: 13/8 = 1.625

This is close to φ ≈ 1.618. ✓

### Worked Example 8.3.2

A sunflower has 55 spirals clockwise and 89 spirals counterclockwise. What is the ratio?

**Solution**: 89/55 = 1.6181818...

This is very close to φ ≈ 1.6180339... ✓

### Practice Problems

1. Find a pinecone and count the spirals in each direction. Are the counts Fibonacci numbers?
2. Find a pineapple and count the spirals in three directions.
3. Why do larger sunflowers have larger Fibonacci numbers?
4. What would happen if a plant used 120° instead of 137.5° for seed arrangement?
5. Research: are there any plants that do NOT use the golden angle?

### Teacher's Notes

**Field Activity**: Bring pinecones and pineapples to class. Have students count the spirals. This is one of the most memorable and convincing demonstrations of mathematics in nature.

**Photography**: Show high-resolution photographs of sunflower heads, pointing out the spirals. Use computer software to overlay Fibonacci spirals on the photograph.

---

## Lesson 8.4: The Nautilus Shell and Logarithmic Spirals

### Explanation

The nautilus shell is one of the most famous examples of a logarithmic spiral in nature. As the nautilus grows, it adds new chambers to its shell, each slightly larger than the previous one.

The nautilus shell is often described as a "golden spiral," but this is not quite accurate. The actual growth ratio of the nautilus shell is about 1.33 per quarter turn, which is closer to the silver ratio divided by √2 than to the golden ratio.

However, the nautilus shell is still a beautiful example of a logarithmic spiral, and it illustrates the same mathematical principles that govern the golden spiral.

### Logarithmic Spirals in Nature

The logarithmic spiral appears in many natural structures:

- **Nautilus shells**: growth ratio ≈ 1.33 per quarter turn
- **Hurricane clouds**: logarithmic spiral pattern
- **Spiral galaxies**: logarithmic spiral arms
- **Spider webs**: logarithmic spiral threads
- **Ram's horns**: logarithmic spiral growth
- **Eagle talons**: approximately logarithmic curve

All of these structures share a common property: they grow while maintaining their shape. This is called **self-similarity**, and it is a defining characteristic of logarithmic spirals.

**Key Concept**: Logarithmic spirals are self-similar: they look the same at any scale.

### The Equiangular Property

The logarithmic spiral is also called the **equiangular spiral** because it intersects every radial line at the same angle. This means that if you draw a line from the center of the spiral to any point on the spiral, the angle between this line and the tangent to the spiral is constant.

This property makes the logarithmic spiral unique among curves: it is the only curve that maintains a constant angle with all radial lines.

### Worked Example 8.4.1

A nautilus shell has a growth ratio of 1.33 per quarter turn. If the first chamber has radius 1 cm, what is the radius after 4 quarter turns (one complete revolution)?

**Solution**: After 4 quarter turns, the radius is:

1 × 1.33⁴ = 1 × 3.129 = 3.129 cm

### Worked Example 8.4.2

A golden spiral has growth factor φ per quarter turn. After 4 quarter turns, what is the growth factor?

**Solution**: φ⁴ = ((1 + √5)/2)⁴ ≈ 6.854

So the golden spiral grows by a factor of about 6.85 per complete revolution, compared to 3.13 for the nautilus shell.

### Practice Problems

1. A logarithmic spiral has growth factor 1.5 per quarter turn. What is the growth factor per complete revolution?
2. A nautilus shell starts with radius 2 cm. What is the radius after 3 complete revolutions?
3. Why is the nautilus spiral not exactly a golden spiral?
4. What property makes logarithmic spirals unique among curves?
5. Find a photograph of a logarithmic spiral in nature (hurricane, galaxy, etc.) and describe its properties.

### Teacher's Notes

**Misconception**: Many popular sources claim the nautilus shell is a golden spiral. It is not — the growth ratio is about 1.33, not φ. However, the nautilus shell is still a beautiful example of a logarithmic spiral, and it illustrates the same mathematical principles.

**Demonstration**: If you have access to a nautilus shell (or a cross-section), show it to students. Point out the logarithmic spiral and the self-similar growth pattern.

---

## Lesson 8.5: Human Body Proportions and the Golden Ratio

### Explanation

The human body contains many proportions that approximate the golden ratio. Here are some of the most commonly cited examples:

### Proportions in the Human Body

**1. Height to Navel Height**

The ratio of total height to the height of the navel (from the floor) is approximately φ.

For a person 170 cm tall:
Navel height ≈ 170/φ ≈ 105 cm

**2. Forearm to Hand**

The ratio of the forearm length to the hand length is approximately φ.

If the forearm is 25 cm, the hand is approximately 25/φ ≈ 15.4 cm.

**3. Face Proportions**

The ratio of face width to face height (from hairline to chin) is approximately 1/φ.

**4. Finger Segments**

The ratio of the length of one finger segment to the next is approximately φ.

### Why Does the Human Body Have Golden Proportions?

The human body is not designed according to the golden ratio. Rather, the golden proportions emerge from the way the body grows and develops.

During embryonic development, the body grows in segments, and each segment is approximately φ times the previous one. This growth pattern is controlled by genes and developmental signaling, and it naturally produces golden proportions.

Similarly, the proportions of the face are determined by the growth rates of the skull, jaw, and other facial bones. These growth rates happen to produce ratios close to φ.

**Key Concept**: Golden proportions in the human body are a result of growth patterns, not design.

### The Face and the Golden Rectangle

A face can be inscribed in a golden rectangle:

- The width of the face is 1 unit.
- The height of the face (from hairline to chin) is φ units.
- The eyes are located at the golden section of the height.

This does not mean that all faces are golden rectangles — faces vary widely. But the average face approximates a golden rectangle.

### Worked Example 8.5.1

A person is 180 cm tall. If the ratio of height to navel height is φ, what is the navel height?

**Solution**: Navel height = 180/φ ≈ 180/1.618 ≈ 111.2 cm

### Worked Example 8.5.2

A face is 14 cm wide. If the width-to-height ratio is 1/φ, what is the face height?

**Solution**: Face height = 14 × φ ≈ 14 × 1.618 ≈ 22.7 cm

### Practice Problems

1. Measure your own height and the height of your navel (from the floor). Compute the ratio. How close is it to φ?
2. Measure the width and height of your face. Compute the ratio.
3. Measure the segments of your index finger. Are the ratios close to φ?
4. Why might human proportions approximate the golden ratio?
5. Are there cultures that have used the golden ratio in art to depict the human body?

### Teacher's Notes

**Measurement Activity**: Have students measure each other's body proportions and compute the ratios. This is a fun, interactive activity that makes the mathematics personal.

**Caveat**: Emphasize that human proportions vary widely. The golden ratio is an average, not a law. Some people have golden proportions; others do not. Beauty is not determined by the golden ratio.

**Art Connection**: Show students how artists like Leonardo da Vinci and Michelangelo used golden proportions in their depictions of the human body.

---

## Lesson 8.6: Fibonacci Numbers in Animal Biology

### Explanation

The golden ratio and Fibonacci numbers appear not just in plants but also in animals.

### The Fibonacci Sequence in Animal Structures

**1. Honeycomb Geometry**

Honeybees build hexagonal honeycombs. The number of cells in each ring of the honeycomb follows a pattern related to Fibonacci numbers:
- Ring 1: 6 cells
- Ring 2: 12 cells
- Ring 3: 18 cells

While these are multiples of 6, the ratios of the areas of consecutive rings approximate the golden ratio when the hexagons are arranged spirally.

**2. Spiral Shells**

Many mollusk shells grow in logarithmic spirals. The number of whorls (complete turns) in some shells is a Fibonacci number:
- Nautilus: typically 30-36 whorls (close to F(9) = 34)
- Some snails: whorl counts that are Fibonacci numbers

**3. Bird Flight Patterns**

Some birds fly in V-formations. The angle of the V is often close to the golden angle (137.5°), which minimizes air resistance for following birds.

**4. Fish Schooling**

Fish schools sometimes arrange themselves in patterns that approximate Fibonacci spirals. This arrangement minimizes overlap and maximizes visibility.

### The Fibonacci Sequence in Animal Behavior

**1. The Fibonacci Spiral in Spider Webs**

Some spiders build webs with spiral patterns that approximate the golden spiral. The spiral threads are spaced at distances that follow the Fibonacci sequence.

**2. The Fibonacci Sequence in Ant Trails**

Ant trails sometimes follow patterns related to the Fibonacci sequence. When ants forage, they explore the environment in a pattern that approximates a Fibonacci spiral.

### Worked Example 8.6.1

A honeybee starts at the center of a honeycomb and moves outward. The number of cells in each ring is 6, 12, 18, 24, 30. What is the ratio of the 4th to the 2nd ring?

**Solution**: 24/12 = 2. This is not a Fibonacci ratio, but the spiral arrangement of the cells produces Fibonacci-like patterns when viewed from above.

### Practice Problems

1. Count the whorls on a snail shell. Is the count a Fibonacci number?
2. Measure the angle of a bird V-formation. How close is it to the golden angle?
3. Examine a spider web. Are the spiral threads spaced at Fibonacci intervals?
4. Why might animals use Fibonacci patterns?
5. Find an example of a Fibonacci pattern in animal behavior.

### Teacher's Notes

**Zoology Connection**: This lesson connects the golden ratio to zoology. Show photographs of animal structures that use Fibonacci patterns.

**Field Activity**: If possible, take students outdoors to observe animal structures. Count the whorls on snail shells, measure the angle of bird V-formations, or examine spider webs.

**Evolutionary Connection**: Discuss why Fibonacci patterns might be favored by evolution. The answer is the same as for plants: the golden angle maximizes spacing and minimizes overlap, which is advantageous for both plants and animals.

---

## Lesson 8.7: The Golden Ratio in Microbiology

### Explanation

The golden ratio appears in microbiology, particularly in the growth patterns of bacteria and the structure of viruses.

### Bacterial Growth Patterns

Some bacteria grow in patterns that approximate the golden ratio. When bacteria colonize a surface, they often arrange themselves in patterns that follow the golden angle (137.5°). This arrangement maximizes the use of available space and resources.

### Viral Capsid Structure

Many viruses have icosahedral capsids (protein shells). The icosahedron has five-fold symmetry, which is related to the golden ratio. The number of protein subunits in an icosahedral capsid is typically 60 × n, where n is a Fibonacci number:

- T = 1: 60 subunits (icosahedron)
- T = 3: 180 subunits
- T = 4: 240 subunits
- T = 7: 420 subunits

The triangulation number T determines the size of the capsid, and some values of T are related to Fibonacci numbers.

### The Golden Ratio and DNA Packaging

DNA is packaged into cells using a hierarchical structure. The DNA double helix is wound into nucleosomes, which are then wound into chromatin fibers, which are then wound into chromosomes.

The ratios of the sizes at each level of this hierarchy sometimes approximate the golden ratio. This suggests that the golden ratio may play a role in the efficient packaging of DNA.

### The Golden Ratio and Protein Folding

Proteins fold into specific three-dimensional structures. The ratios of the distances between different parts of the protein sometimes approximate the golden ratio. This may be related to the optimal packing of amino acids in the protein structure.

### Worked Example 8.7.1

A virus has an icosahedral capsid with triangulation number T = 4. How many protein subunits does it have?

**Solution**: Number of subunits = 60 × T = 60 × 4 = 240.

The icosahedron has 20 triangular faces, and each face is divided into T smaller triangles. The total number of triangles is 20T, and each triangle has 3 vertices, but each vertex is shared by multiple triangles. The total number of unique vertices is 10T + 2.

For T = 4: vertices = 10(4) + 2 = 42. But the number of protein subunits is 60T = 240, because each vertex can be occupied by up to 60/T subunits... actually, let me reconsider.

The triangulation number T determines the number of protein subunits in the capsid. The formula is:

Number of subunits = 60T

For T = 4: subunits = 240. ✓

### Practice Problems

1. Research: what is a viral capsid?
2. How many protein subunits does a virus with T = 7 have?
3. Why might bacteria arrange themselves at the golden angle?
4. How does DNA packaging relate to the golden ratio?
5. What is the triangulation number of a virus?

### Teacher's Notes

**Biology Connection**: This lesson connects the golden ratio to microbiology. The appearance of the golden ratio in viral capsids is a beautiful example of mathematics in nature.

**Misconception**: Not all viruses have icosahedral capsids. Some have helical capsids, and some have complex structures. The golden ratio appears specifically in icosahedral viruses.

---

## Summary of Chapter 8

### Key Concepts

1. **Phyllotaxis** is the study of leaf arrangement, governed by the golden angle (137.5°).
2. The golden angle ensures maximum uniformity in leaf arrangement.
3. **Flower petals** are often Fibonacci numbers because of the golden angle.
4. **Pinecones and pineapples** have Fibonacci spirals because of the golden angle.
5. The **nautilus shell** is a logarithmic spiral, but not exactly a golden spiral.
6. The human body contains many proportions that approximate the golden ratio.
7. Golden proportions in biology result from growth patterns, not design.

### Key Formulas

| Formula | Description |
|---------|-------------|
| Golden angle = 360°/φ² ≈ 137.5° | Angle used in phyllotaxis |
| r = a × b^(θ/2π) | General logarithmic spiral |
| r = a × φ^(2θ/π) | Golden spiral |
| Fibonacci spirals in sunflowers | Consecutive Fibonacci numbers |

### Connections to Other Chapters

- **Chapter 1 (Golden Ratio)**: The golden ratio governs phyllotaxis and body proportions.
- **Chapter 5 (Fibonacci and Lucas Numbers)**: Fibonacci numbers appear in petal counts and spiral counts.
- **Chapter 7 (Padovan and Kepler Ratios)**: The Padovan spiral appears in some biological structures.
- **Chapter 11 (Phi-Biology and Phi-Medicine)**: DNA and neural oscillations use the golden ratio.

---

**End of Chapter 8**

*Next: Chapter 9 — Phi-Statistics and Phi-Geometry*
