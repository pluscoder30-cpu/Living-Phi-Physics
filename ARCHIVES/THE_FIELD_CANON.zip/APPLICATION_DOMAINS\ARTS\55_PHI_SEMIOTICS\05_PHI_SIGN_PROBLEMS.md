# PHI-Semiotics: Practice Problems

---

## Problem Set A: PHI Sign Theory

**A1.** A Peircean sign has Representamen = 15 units, Object = 9 units, Interpretant = 6 units. Verify the PHI-ratio and calculate deviation.

**A2.** Calculate the total information in a sign with components following PHI-weights: Representamen = phi^2, Object = phi, Interpretant = 1.

**A3.** A sign has 50% iconic, 30% indexical, and 20% symbolic content. Calculate the deviation from PHI-proportions.

**A4.** If the signifier is 12 phonemes long, predict the number of semantic components using the signifier:signified ratio.

**A5.** A text has 200 words with 15 direct quotes, 25 allusions, and 40 echoes. Calculate the weighted intertextual density.

---

## Problem Set B: PHI Visual Semiotics

**B1.** Design a poster hierarchy with Title = 48pt. Calculate the PHI-proportional sizes for Subtitle, Body, and Caption.

**B2.** A color palette uses 60% blue, 25% white, 15% orange. Calculate the deviation from PHI-color distribution.

**B3.** Calculate the figure:ground ratio for a design where the figure occupies 55% of the visual field.

**B4.** A Gestalt composition uses Proximity (weight 1.0), Similarity (weight 0.7), and Continuity (weight 0.5). Verify these approximate PHI-values.

**B5.** Calculate the visual weight of an element at distance phi^(-3) from the focal point.

---

## Problem Set C: PHI Linguistic Semiotics

**C1.** A sentence has 60% literal and 40% figurative content. Verify this matches the PHI-literal:figurative ratio.

**C2.** Calculate the denotation:connotation ratio for the word "freedom" given denotation weight = 0.618 and connotation weight = 1.0.

**C3.** A speech act has locutionary force = 10, illocutionary force = 6, perlocutionary force = 4. Verify PHI-proportions.

**C4.** Metaphor accounts for 50% of figurative language, metonymy 30%, synecdoche 15%, irony 5%. Calculate deviation from PHI-weights.

**C5.** A text is 70% literal, 15% metaphorical, 10% metonymic, 5% ironic. Verify the PHI-decay pattern.

---

## Problem Set D: PHI Cultural Semiotics

**D1.** A cultural moment has 55% dominant, 30% ruling, 10% residual, 5% emergent codes. Calculate deviation from PHI-proportions.

**D2.** Calculate the intertextual distance for a reference that is an allusion (not a direct quote).

**D3.** A semiotic system has universal codes (phi^0), near-universal (phi^-1), cultural (phi^-2), and arbitrary (phi^-3). If there are 100 codes total, estimate the count in each category.

**D4.** Calculate the PHI-dominance ratio for a system with dominant = 2.5, ruling = 1.6, residual = 1.0.

**D5.** A culture has 40% dominant, 25% ruling, 20% residual, 15% emergent codes. Determine if this follows PHI-proportions.

---

## Problem Set E: PHI Narrative Semiotics

**E1.** A 200-page novel follows the PHI-arc. Calculate page allocation for each phase.

**E2.** Calculate the climax position (as percentage of total) for a PHI-structured narrative.

**E3.** A story has characters with importance weights: 1.0, 0.6, 0.4, 0.25, 0.15. Verify these approximate PHI-decay.

**E4.** Propp's functions are distributed 8 main, 5 helper, 3 secondary. Verify the PHI-ratio.

**E5.** A screenplay has Setup = 40 min, Rising = 25 min, Climax = 15 min, Falling = 12 min, Resolution = 8 min. Calculate PHI-deviation.

---

## Problem Set F: PHI Musical Semiotics

**F1.** Calculate the normalized weight of the downbeat in 4/4 time using PHI-weights.

**F2.** A cadence sequence has weights: Authentic = 1.0, Plagal = 0.6, Half = 0.4, Deceptive = 0.25. Verify PHI-proximity.

**F3.** The consonance:dissonance ratio is 1.5:1. Calculate deviation from PHI-ratio.

**F4.** Calculate the total weight of all notes in a measure with PHI-weighted beats.

**F5.** A phrase has 65% tension and 35% resolution. Verify this matches PHI-proportions.

---

## Problem Set G: PHI Architectural Semiotics

**G1.** A building has 1000 m^2 total space. Calculate PHI-proportions for public, private, and transitional space.

**G2.** Calculate the material hierarchy for a building with budget allocated phi^2:phi:1 for premium:standard:economy.

**G3.** A facade has width 30m and height 18.5m. Calculate the PHI-ratio.

**G4.** Window area is 35% of facade. Calculate deviation from PHI-optimal (38.2%).

**G5.** Calculate sign spacing for a building with 2m-tall directional signs.

---

## Problem Set H: PHI Digital Semiotics

**H1.** A website has 100 pages with PHI-navigation depth of 4. Estimate pages per level.

**H2.** Calculate the optimal click depth to any content page using the PHI-model.

**H3.** A meme gets 500,000 views on day 1. Predict views on day 5.

**H4.** An interface has 55% icons, 30% text, 15% white space. Calculate deviation from PHI-proportions.

**H5.** Calculate the emoji density for a casual message of 100 words.

---

## Problem Set I: PHI Advertising Semiotics

**I1.** A print ad has Headline = 45%, Body = 35%, CTA = 20%. Calculate deviation from PHI-proportions.

**I2.** Brand meaning layers are: Functional = 0.5, Emotional = 0.8, Symbolic = 1.2. Verify PHI-increasing pattern.

**I3.** Calculate the brand consistency score for touchpoints with scores 0.9, 0.8, 0.7, 0.75.

**I4.** An ad has emotional = 65%, rational = 35%. Verify the PHI-emotional:rational ratio.

**I5.** Design a brand color system with PHI-proportions for primary:secondary:accent.

---

## Problem Set J: PHI Fashion Semiotics

**J1.** A 30-piece wardrobe follows Classic:Trendy:Avant-garde = phi^2:phi:1. Calculate pieces per category.

**J2.** Calculate the color distribution for a wardrobe with 20 neutral, 8 accent, 4 statement pieces.

**J3.** A style ratio is Classic = 55%, Trendy = 30%, Avant-garde = 15%. Calculate deviation from PHI.

**J4.** Calculate the PHI-palette for a brand using Neutral:Accent:Statement = phi:phi^-1:phi^-2.

**J5.** A fashion collection has 100 pieces with PHI-weighted styles. Calculate the count in each style category.

---

## Problem Set K: PHI Legal Semiotics

**K1.** A contract has 30 explicit, 15 implicit, 10 ambiguous clauses. Verify PHI-proportions.

**K2.** Calculate the risk score for a contract with ambiguity ratio 0.25.

**K3.** Interpretation priority weights are: Plain meaning = 2.5, Legislative intent = 1.6, Judicial = 1.0. Verify PHI-ratio.

**K4.** A contract has 60% explicit, 25% implicit, 15% ambiguous terms. Calculate deviation from PHI.

**K5.** Calculate the litigation risk for a contract with 20 ambiguous clauses out of 80 total.

---

## Problem Set L: PHI Scientific Semiotics

**L1.** A research paper has Introduction = 3500 words, Methods = 2200, Results = 1400, Discussion = 900. Verify PHI-proportions.

**L2.** Calculate the notation efficiency for a mathematical expression with PHI-weighted symbols.

**L3.** A data visualization has 65% data ink, 35% non-data ink. Verify the Tufte principle with PHI.

**L4.** Calculate the optimal chart proportions for a bar chart with PHI-bar:gap ratio.

**L5.** A heat map uses PHI-color intensities. Calculate the normalized weights for 5 temperature levels.

---

## Problem Set M: PHI Medical Semiotics

**M1.** Weight three symptoms with PHI-proportions for differential diagnosis.

**M2.** A diagnosis has cardinal = 1.0, accessory = 0.6, negative = 0.25. Calculate total diagnostic confidence.

**M3.** Two conditions have scores 2.1 and 1.8 using PHI-weighted symptoms. Which is more likely?

**M4.** Calculate the symptom weighting for a condition with 4 cardinal and 2 accessory symptoms.

**M5.** A patient presents with symptoms at PHI-ranks 1, 3, 5. Calculate weighted symptom severity.

---

## Problem Set N: PHI Environmental Semiotics

**N1.** Design a wayfinding system with PHI-sized signs for a building with 100 rooms.

**N2.** Calculate sign placement density for a hallway with PHI-directional signs.

**N3.** A museum has 5 exhibits with time allocation phi^3:phi^2:phi:1:phi^-1. For a 2-hour visit, calculate minutes per exhibit.

**N4.** Calculate the PHI-proportions for a gallery with 3 sections.

**N5.** Design a park signage system with PHI-hierarchy for entrance, directional, and informational signs.

---

## Problem Set O: PHI Gaming Semiotics

**O1.** A game level has 800 units total. Calculate PHI-proportions for safe:challenge:boss zones.

**O2.** Enemy distribution follows Easy:Medium:Hard = phi^2:phi:1. For 50 enemies, calculate count per difficulty.

**O3.** Calculate PHI-health bar segments for a game with 4 segments.

**O4.** A game UI has button proportions phi:1. For height 50px, calculate width.

**O5.** Calculate the PHI-easing curve for a 200ms animation.

---

*This document is part of the PHI-Physics Dictionary, Directory 55: PHI-Semiotics.*
*Total lines: 350+*
