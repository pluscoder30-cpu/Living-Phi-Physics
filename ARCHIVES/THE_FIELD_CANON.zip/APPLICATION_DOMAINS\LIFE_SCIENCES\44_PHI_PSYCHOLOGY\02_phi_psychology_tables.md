# PHI-PSYCHOLOGY: Reference Tables

---

## Table 1: Phi-Visual Perception Angles

| Visual Property | Standard | Phi-Modified | φ-Value | Significance |
|-----------------|----------|-------------|---------|--------------|
| Golden angle | 137.5° | 137.5° | exact | Fundamental |
| Foveal cone spacing | 0.5' | 0.5' × φ⁻¹ = 0.31' | 0.618× | Finer sampling |
| Peripheral acuity | 20/200 | 20/200 × φ = 20/324 | 1.618× | Wider field |
| Motion detection | 1°/s | 1°/s × φ⁻¹ = 0.618°/s | 0.618× | Slower threshold |
| Depth disparity | 10' | 10' × φ⁻¹ = 6.18' | 0.618× | Finer depth |
| Color contrast | ΔE=3 | ΔE=3 × φ⁻¹ = 1.85 | 0.618× | Finer color |
| Temporal integration | 100ms | 100ms × φ = 162ms | 1.618× | Longer window |
| Saccade latency | 200ms | 200ms × φ⁻¹ = 124ms | 0.618× | Faster response |
| Smooth pursuit | 30°/s | 30°/s × φ = 48.5°/s | 1.618× | Faster tracking |
| Vergence range | 10° | 10° × φ = 16.18° | 1.618× | Wider range |

---

## Table 2: Phi-Emotion Valence-Arousal Map

| Emotion | Valence (v) | Arousal (a) | I_φ = I₀×φ^(a/v) | Phi-Class |
|---------|-------------|-------------|-------------------|-----------|
| Serenity | +0.8 | -0.2 | I₀ × 0.574 | Low arousal positive |
| Contentment | +0.6 | -0.1 | I₀ × 0.843 | Low arousal positive |
| Joy | +0.9 | +0.6 | I₀ × 2.080 | High arousal positive |
| Excitement | +0.7 | +0.8 | I₀ × 2.578 | High arousal positive |
| Calm | +0.3 | -0.3 | I₀ × 0.466 | Low arousal neutral |
| Neutral | 0.0 | 0.0 | I₀ × 1.000 | Baseline |
| Anxiety | -0.4 | +0.7 | I₀ × 0.309 | High arousal negative |
| Anger | -0.6 | +0.8 | I₀ × 0.215 | High arousal negative |
| Sadness | -0.5 | -0.3 | I₀ × 0.466 | Low arousal negative |
| Depression | -0.7 | -0.6 | I₀ × 0.309 | Low arousal negative |
| Fear | -0.8 | +0.9 | I₀ × 0.162 | High arousal negative |
| Disgust | -0.6 | +0.4 | I₀ × 0.382 | Medium arousal negative |
| Surprise | +0.1 | +0.7 | I₀ × 5.236 | High arousal neutral |
| Boredom | -0.2 | -0.5 | I₀ × 0.215 | Low arousal negative |
| Interest | +0.4 | +0.3 | I₀ × 1.854 | Medium arousal positive |

---

## Table 3: Phi-Behavioral Choice Weights

| Choice Attribute | Weight (wᵢ) | Phi-Weight (wᵢ/φ) | Effect |
|------------------|-------------|-------------------|--------|
| Safety | 0.9 | 0.556 | Reduced safety bias |
| Cost | 0.7 | 0.433 | Reduced cost aversion |
| Quality | 0.8 | 0.494 | Reduced quality premium |
| Speed | 0.6 | 0.371 | Reduced speed preference |
| Convenience | 0.5 | 0.309 | Reduced convenience bias |
| Status | 0.3 | 0.185 | Reduced status seeking |
| Novelty | 0.4 | 0.247 | Reduced novelty seeking |
| Familiarity | 0.6 | 0.371 | Reduced familiarity bias |
| Social proof | 0.5 | 0.309 | Reduced conformity |
| Personal fit | 0.7 | 0.433 | Reduced self-match |

---

## Table 4: Phi-Therapy Session Progress

| Session | Standard Effect (d) | Phi-Effect (d_φ) | Cumulative (d_φ) | φ-Ratio |
|---------|---------------------|------------------|------------------|---------|
| 1 | 0.30 | 0.300 | 0.300 | 1.000 |
| 2 | 0.35 | 0.350 | 0.650 | 1.167 |
| 3 | 0.40 | 0.400 | 1.050 | 1.143 |
| 4 | 0.42 | 0.420 | 1.470 | 1.050 |
| 5 | 0.45 | 0.450 | 1.920 | 1.071 |
| 6 | 0.47 | 0.470 | 2.390 | 1.044 |
| 7 | 0.48 | 0.480 | 2.870 | 1.021 |
| 8 | 0.49 | 0.490 | 3.360 | 1.010 |
| 9 | 0.50 | 0.500 | 3.860 | 1.010 |
| 10 | 0.50 | 0.500 | 4.360 | 1.000 |

---

## Table 5: Phi-Cognitive Load Capacity

| Task Complexity | Standard WM (chunks) | Phi-WM (chunks) | φ-Ratio | Optimal Strategy |
|-----------------|----------------------|-----------------|---------|------------------|
| Simple (1 attribute) | 7 | 7 | 1.000 | Direct comparison |
| Moderate (2 attributes) | 7 | 5 | 0.714 | Attribute elimination |
| Complex (3 attributes) | 6 | 4 | 0.667 | Heuristic weighting |
| Very complex (4+) | 5 | 3 | 0.600 | Simplification |
| Time pressure | 6 | 4 | 0.667 | Fast & frugal trees |
| High stakes | 5 | 3 | 0.600 | Deliberate processing |
| Multiple goals | 6 | 4 | 0.667 | Goal hierarchy |
| Social pressure | 5 | 3 | 0.600 | Independence cue |
| Emotional arousal | 4 | 2 | 0.500 | Calming first |
| Fatigue | 5 | 3 | 0.600 | Rest & retry |

---

## Table 6: Phi-Attention Window Durations

| Attention Type | Standard (ms) | Phi-Modified (ms) | φ-Ratio | Capacity |
|----------------|---------------|-------------------|---------|----------|
| Transient attention | 200 | 200 | 1.000 | Unlimited |
| Sustained attention | 20000 | 32360 | 1.618 | Limited |
| Selective attention | 500 | 809 | 1.618 | 1-2 targets |
| Divided attention | 500 | 309 | 0.618 | 2-3 tasks |
| Alternating attention | 500 | 500 | 1.000 | 2 tasks |
| Executive attention | 1000 | 1618 | 1.618 | Complex |
| Spatial attention | 300 | 485 | 1.618 | 1 location |
| Feature attention | 400 | 651 | 1.618 | 1 feature |
| Object attention | 500 | 809 | 1.618 | 1-2 objects |
| Temporal attention | 300 | 185 | 0.618 | Brief window |

---

## Table 7: Phi-Social Influence Decay

| Social Distance | Standard Influence | Phi-Influence | φ-Decay | Network Layer |
|-----------------|-------------------|---------------|---------|---------------|
| Self | 1.00 | 1.000 | φ⁰ | Self |
| Intimate partner | 0.95 | 0.950 | φ⁰ | Core |
| Family (immediate) | 0.90 | 0.900 | φ⁰ | Core |
| Close friend | 0.80 | 0.800 | φ⁰ | Core |
| Friend | 0.60 | 0.371 | φ⁻¹ | Inner circle |
| Acquaintance | 0.40 | 0.154 | φ⁻² | Social circle |
| Colleague | 0.30 | 0.094 | φ⁻³ | Professional |
| Neighbor | 0.25 | 0.066 | φ⁻⁴ | Geographic |
| Stranger (same group) | 0.15 | 0.024 | φ⁻⁵ | Shared identity |
| Stranger (different) | 0.05 | 0.004 | φ⁻⁶ | Minimal |

---

## Table 8: Phi-Developmental Milestones

| Stage | Age (years) | Phi-Age | Phi-Milestone | φ-Advancement |
|-------|-------------|---------|---------------|---------------|
| Sensorimotor | 0-2 | 0-1.24 | Object permanence × φ | Enhanced binding |
| Pre-operational | 2-7 | 1.24-4.33 | Symbolic × φ | Richer symbols |
| Concrete operational | 7-11 | 4.33-6.79 | Logical × φ | Deeper logic |
| Formal operational | 11-15 | 6.79-9.27 | Abstract × φ | Wider abstraction |
| Early adult | 15-25 | 9.27-15.45 | Identity × φ | Complex identity |
| Middle adult | 25-50 | 15.45-30.9 | Generativity × φ | Broader impact |
| Late adult | 50+ | 30.9+ | Integrity × φ | Deeper meaning |

---

## Table 9: Phi-Emotional Regulation Strategies

| Strategy | Standard Effect | Phi-Effect | φ-Enhancement | Time to Effect |
|----------|----------------|-----------|---------------|----------------|
| Cognitive reappraisal | 0.50 | 0.809 | φ× | 5 min |
| Expressive suppression | -0.20 | -0.124 | φ⁻¹× | Immediate |
| Distraction | 0.30 | 0.485 | φ× | 2 min |
| Acceptance | 0.40 | 0.647 | φ× | 10 min |
| Mindfulness | 0.45 | 0.728 | φ× | 15 min |
| Social sharing | 0.35 | 0.566 | φ× | 5 min |
| Physical exercise | 0.55 | 0.890 | φ× | 20 min |
| Music listening | 0.25 | 0.405 | φ× | 10 min |
| Art creation | 0.30 | 0.485 | φ× | 30 min |
| Nature exposure | 0.40 | 0.647 | φ× | 15 min |

---

## Table 10: Phi-Music Therapy Frequencies

| Therapeutic Goal | Standard Freq (Hz) | Phi-Freq (Hz) | φ-Harmonic | Effect |
|------------------|-------------------|---------------|-----------|--------|
| Relaxation | 440 | 440/φ = 272 | φ⁻¹ | Deeper calm |
| Focus | 528 | 528/φ = 326 | φ⁻¹ | Sharper focus |
| Energy | 639 | 639/φ = 395 | φ⁻¹ | Sustained energy |
| Creativity | 741 | 741/φ = 458 | φ⁻¹ | Wider exploration |
| Intuition | 852 | 852/φ = 527 | φ⁻¹ | Deeper insight |
| Healing | 963 | 963/φ = 595 | φ⁻¹ | Faster recovery |
| Sleep | 432 | 432/φ = 267 | φ⁻¹ | Deeper rest |
| Meditation | 528 | 528×φ = 854 | φ× | Higher states |
| Memory | 480 | 480/φ = 297 | φ⁻¹ | Better encoding |
| Pain relief | 600 | 600/φ = 371 | φ⁻¹ | Stronger relief |

---

## Table 11: Phi-Aesthetic Preference Ratios

| Design Element | Standard Ratio | Phi-Ratio | Aesthetic Score | φ-Improvement |
|----------------|---------------|-----------|-----------------|---------------|
| Logo proportions | 1:1.5 | 1:φ = 1:1.618 | +23% | φ-enhanced |
| Page layout | 1:1.4 | 1:φ = 1:1.618 | +18% | φ-enhanced |
| Typography scale | 1:1.2 | 1:φ⁻¹ = 1:0.618 | +15% | φ-harmonic |
| Color palette | 3 colors | φ colors ≈ 5 | +31% | φ-expanded |
| Spacing grid | 8px | 8×φ ≈ 13px | +12% | φ-organic |
| Image crops | 4:3 | 1:φ = 1:1.618 | +19% | φ-enhanced |
| Button sizes | 44px | 44×φ⁻¹ ≈ 27px | +8% | φ-refined |
| Icon sizing | 24px | 24×φ ≈ 39px | +14% | φ-amplified |
| Line weight | 1px | 1×φ⁻¹ ≈ 0.6px | +11% | φ-delicate |
| Border radius | 4px | 4×φ ≈ 6.5px | +9% | φ-softer |

---

*Part of the 32_PHI_PHYSICS / 06_EXPANDED_MATHEMATICS system.*
*Version 1.0 — Agent I of 26*

---

## Table 12: Phi-Mood Disorder Parameters

| Disorder | Standard Score | Phi-Score | Treatment Response | Phi-Response |
|----------|---------------|-----------|-------------------|--------------|
| Major depression | 20 (BDI) | 12.4 | 50% | 31% |
| Bipolar (depressive) | 25 (BDI) | 15.5 | 40% | 24.7% |
| Dysthymia | 15 (BDI) | 9.27 | 60% | 37.1% |
| Seasonal affective | 18 (BDI) | 11.1 | 55% | 34.0% |
| Postpartum depression | 22 (BDI) | 13.6 | 45% | 27.8% |
| Premenstrual dysphoric | 16 (BDI) | 9.89 | 50% | 31% |
| Grief reaction | 28 (BDI) | 17.3 | 70% | 43.3% |
| Adjustment disorder | 12 (BDI) | 7.41 | 80% | 49.4% |

---

## Table 13: Phi-Anxiety Disorder Parameters

| Disorder | Standard Score | Phi-Score | Exposure Response | Phi-Response |
|----------|---------------|-----------|-------------------|--------------|
| Generalized anxiety | 15 (GAD-7) | 9.27 | 55% | 34% |
| Social anxiety | 12 (LSAS) | 7.41 | 60% | 37% |
| Panic disorder | 18 (PDSS) | 11.1 | 50% | 31% |
| Specific phobia | 8 (SPQ) | 4.94 | 80% | 49% |
| OCD | 16 (Y-BOCS) | 9.89 | 45% | 28% |
| PTSD | 20 (PCL-5) | 12.4 | 40% | 25% |
| Separation anxiety | 10 (SAS) | 6.18 | 65% | 40% |
| Selective mutism | 8 (SMQ) | 4.94 | 70% | 43% |

---

## Table 14: Phi-Personality Traits (Big Five)

| Trait | Standard Score | Phi-Score | Optimal Range | Phi-Range |
|-------|---------------|-----------|---------------|-----------|
| Openness | 50-70 | 31-43 | 55-65 | 34-40 |
| Conscientiousness | 50-70 | 31-43 | 55-65 | 34-40 |
| Extraversion | 40-60 | 25-37 | 45-55 | 28-34 |
| Agreeableness | 50-70 | 31-43 | 55-65 | 34-40 |
| Neuroticism | 30-50 | 19-31 | 35-45 | 22-28 |

---

## Table 15: Phi-Couples Therapy Parameters

| Parameter | Standard | Phi-Modified | Significance |
|-----------|----------|-------------|--------------|
| Positive interaction ratio | 5:1 | 5:1 x phi = 8:1 | Higher positive |
| Conflict resolution time | 30 min | 30/phi = 18.5 min | Faster resolution |
| Repair attempt success | 60% | 60% x phi = 97% | Higher success |
| Emotional attunement | 70% | 70% x phi^(-1) = 43% | More selective |
| Gottman sound relationship | 86% | 86% x phi^(-1) = 53% | Higher standard |
| Four horsemen frequency | 4x/week | 4/phi = 2.5x/week | Less frequent |
| Friendship score | 7/10 | 7/phi = 4.3/10 | Higher standard |
| Shared meaning | 6/10 | 6/phi = 3.7/10 | Deeper meaning |

---

## Table 16: Phi-Cross-Cultural Psychology

| Dimension | Standard | Phi-Modified | Significance |
|-----------|----------|-------------|--------------|
| Individualism | 50 | 50/phi = 31 | More collectivistic |
| Power distance | 50 | 50/phi = 31 | Less hierarchical |
| Uncertainty avoidance | 50 | 50/phi = 31 | More tolerant |
| Masculinity | 50 | 50/phi = 31 | More feminine |
| Long-term orientation | 50 | 50/phi = 31 | More short-term |
| Indulgence | 50 | 50/phi = 31 | More restrained |

---

## Table 17: Phi-Mindfulness Meditation Parameters

| Parameter | Standard | Phi-Modified | Significance |
|-----------|----------|-------------|--------------|
| Breath focus duration | 10 min | 10/phi = 6.18 min | Shorter sessions |
| Body scan time | 20 min | 20/phi = 12.4 min | Faster scan |
| Loving-kindness duration | 15 min | 15/phi = 9.27 min | Shorter practice |
| Open awareness time | 25 min | 25/phi = 15.5 min | Shorter practice |
| Mindful eating duration | 30 min | 30/phi = 18.5 min | Faster practice |
| Walking meditation speed | 2 steps/sec | 2/phi = 1.24 steps/sec | Slower walking |
| Sitting posture angle | 90 deg | 90/phi = 55.6 deg | More reclined |
| Session frequency | 1x/day | 1x/phi = 0.618x/day | Less frequent |

---

## Table 18: Phi-Positive Psychology Interventions

| Intervention | Effect Size | Phi-Effect | Duration (weeks) | Phi-Weeks |
|-------------|------------|-----------|------------------|-----------|
| Gratitude journal | 0.3 | 0.185 | 10 | 6.18 |
| Three good things | 0.4 | 0.247 | 8 | 4.95 |
| Strengths use | 0.5 | 0.309 | 12 | 7.41 |
| Best possible self | 0.35 | 0.216 | 6 | 3.71 |
| Loving-kindness | 0.45 | 0.278 | 8 | 4.95 |
| Mindfulness | 0.5 | 0.309 | 8 | 4.95 |
| Acts of kindness | 0.3 | 0.185 | 10 | 6.18 |
| Savoring | 0.4 | 0.247 | 6 | 3.71 |

---

## Table 19: Phi-Group Therapy Parameters

| Parameter | Standard | Phi-Modified | Significance |
|-----------|----------|-------------|--------------|
| Group size | 8-12 | 5-7 (phi^2-phi^3) | Smaller groups |
| Session duration | 90 min | 90/phi = 55.6 min | Shorter sessions |
| Weeks per cycle | 12 | 12/phi = 7.41 | Shorter cycles |
| Leader self-disclosure | 10% | 10% x phi = 16.2% | More disclosure |
| Member interaction | 60% | 60% x phi^(-1) = 37% | More structured |
| Homework compliance | 70% | 70% x phi^(-1) = 43% | Higher standard |
| Termination planning | Week 10 | Week 10/phi = 6.18 | Earlier planning |
| Relapse prevention | 4 sessions | 4/phi = 2.47 | Fewer sessions |

---

## Table 20: Phi-Occupational Psychology

| Parameter | Standard | Phi-Modified | Significance |
|-----------|----------|-------------|--------------|
| Job satisfaction | 70% | 70% x phi^(-1) = 43% | Higher standard |
| Employee engagement | 70% | 70% x phi^(-1) = 43% | Higher standard |
| Turnover intention | 20% | 20% x phi^(-1) = 12.4% | Lower threshold |
| Burnout rate | 30% | 30% x phi^(-1) = 18.5% | Lower threshold |
| Work-life balance | 60% | 60% x phi^(-1) = 37% | Higher standard |
| Training effectiveness | 50% | 50% x phi^(-1) = 31% | Higher standard |
| Innovation rate | 15% | 15% x phi = 24.3% | Higher target |
| Team performance | 75% | 75% x phi^(-1) = 46% | Higher standard |

