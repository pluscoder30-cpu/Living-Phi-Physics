# PHI-Catastrophe Modeling: Golden Ratio Event Assessment

## Directory 92_PHI_INSURANCE_SCIENCE | File 05

---

## 1. PHI-Natural Catastrophe

### 1.1 PHI-Hurricane

```
Damage = f(wind_speed) * phi{building_vulnerability}
Wind_speed = V_max * phi{-distance/radius}
```

### 1.2 PHI-Earthquake

```
PGA = a * e^{b*M} / R^c * phi{site_amplification}
```

### 1.3 PHI-Flood

```
Depth_damage = depth * phi{velocity_factor} * phi{duration}
```

### 1.4 PHI-Wildfire

```
Spread_rate = wind * slope * fuel * phi{moisture}
```

---

## 2. PHI-Event Frequency

### 2.1 PHI-Poisson Process

```
P(N=n) = e^{-lambda*T} * (lambda*T)^n / n! * phi{overdispersion}
```

### 2.2 PHI-Negative Binomial

```
P(N=n) = C(n+r-1,n) * p^r * (1-p)^n * phi{r}
```

### 2.3 PHI-Mixed Poisson

```
P(N=n) = integral P(N=n|lambda) * f(lambda) * phi{lambda_mix}
```

### 2.4 PHI-Markov Modulated

```
Transition = P(state|prev_state) * phi{state_duration}
```

---

## 3. PHI-Event Severity

### 3.1 PHI-Pareto

```
P(X>x) = (x_m/x)^alpha * phi^{-x/x_m}
```

### 3.2 PHI-Reverse Weibull

```
F(x) = 1 - exp(-((x_u - x)/lambda)^k) * phi{tail}
```

### 3.3 PHI-GPD

```
G(x) = 1 - (1 + xi*x/sigma)^{-1/xi} * phi{threshold}
```

### 3.4 PHI-Lognormal

```
P(X>x) = 1 - Phi((ln(x)-mu)/sigma) * phi{tail_index}
```

---

## 4. PHI-Loss Estimation

### 4.1 PHI-Exposure

```
Exposure = sum building_value * phi{location_factor}
```

### 4.2 PHI-Vulnerability

```
Vulnerability = sum vulnerability_curve * phi{uncertainty}
```

### 4.3 PHI-Ground-Up Loss

```
GUL = exposure * vulnerability * phi{secondary_peril}
```

### 4.4 PHI-Insured Loss

```
Insured = GUL * coverage * phi{deductible_factor}
```

---

## 5. PHI-Event Sets

### 5.1 PHI-Stochastic Catalog

```
Catalog = sum event * phi{event_weight}
```

### 5.2 PHI-Probable Maximum Loss

```
PML = percentile(loss, return_period) * phi{confidence}
```

### 5.3 PHI-Modeled AAL

```
AAL = sum event_loss * probability * phi{severity_weight}
```

### 5.4 PHI-Return Period

```
Return = 1 / exceedance_probability * phi{estimation_error}
```

---

## 6. PHI-Climate Change

### 6.1 PHI-Frequency Trend

```
Trend = current_rate * phi{climate_change_factor}
```

### 6.2 PHI-Severity Trend

```
Trend = current_severity * phi{warming_factor}
```

### 6.3 PHI-Non-Stationary

```
Rate(t) = rate_0 * exp(beta * trend) * phi{volatility}
```

### 6.4 PHI-Scenario Analysis

```
Scenario = base_loss * phi{scenario_multiplier}
```

---

## 7. PHI-Catastrophe Bonds

### 7.1 PHI-Spread

```
Spread = expected_loss * phi{trading_liquidity} * phi{trigger_uncertainty}
```

### 7.2 PHI-Trigger

```
Trigger = industry_loss * phi{basis_risk} + PCS_index
```

### 7.3 PHI-Coupon

```
Coupon = risk_free + spread * phi{expected_loss}
```

### 7.4 PHI-Risk Premium

```
Premium = spread - expected_loss * phi{model_uncertainty}
```

---

## 8. Summary

PHI-catastrophe modeling provides:
1. PHI-hurricane, earthquake, flood, wildfire with phi-vulnerability
2. PHI-event frequency with phi-Poisson and phi-negative binomial
3. PHI-severity with phi-Pareto and phi-GPD
4. PHI-loss estimation with phi-exposure and phi-insured loss
5. PHI-event sets with phi-catalog and phi-PML
6. PHI-climate change with phi-frequency and phi-severity trends
7. PHI-cat bonds with phi-spread and phi-trigger

The golden ratio captures the fat-tailed nature of catastrophe losses and the self-similar patterns in event severity across return periods.