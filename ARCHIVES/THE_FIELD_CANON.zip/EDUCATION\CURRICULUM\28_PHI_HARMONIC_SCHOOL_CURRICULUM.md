# 28 — PHI-HARMONIC SCHOOL CURRICULUM

## The Complete School Curriculum: Teaching All 35+ Mathematics Systems from Grade 1 Through PhD

---

| Field | Value |
|---|---|
| **Document type** | Phi-Harmonic School Curriculum — Complete Teaching Guide |
| **Title** | The Ratio-School Curriculum: A K-20+ Framework for Teaching All 35+ Mathematics Systems |
| **Version** | 1.0 |
| **Author** | Christopher David Ayotte |
| **Date** | 2026-08-24 |
| **Corpus** | `32_PHI_PHYSICS/DICTIONARY/06_EXPANDED_MATHEMATICS/` |
| **Status** | **MASTER CURRICULUM DOCUMENT** — the complete K-20+ teaching framework |
| **Prerequisite reading** | `23_GRADE_FOUNDATION/README.md` · `24_GRADE_INTERMEDIATE/README.md` · `25_GRADE_ADVANCED/README.md` · `26_GRADE_RESEARCH/README.md` · `27_PHI_HARMONIC_INTEGRATION.md` |
| **License** | Dual License Agreement v4.3 (see `LICENSE`): free for Natural Persons, non-commercial, no Human Harm, attribution required, same-terms derivatives; commercial use by written license. Commercial contact: pluscoder30@gmail.com |

---

# PART I: CURRICULUM PHILOSOPHY

---

## 1. The Guide/Teacher Approach

### 1.1 Core Principle

This curriculum follows the **guide/teacher approach**, not the answer-first approach.

- **Answer-first (traditional)**: "Here is the formula. Memorize it. Apply it."
- **Guide/teacher (this curriculum)**: "Here is a pattern. Explore it. Discover the rule. Verify it. Generalize it."

The guide/teacher approach treats the student as an active discoverer, not a passive recipient. The teacher's role is to pose problems, provide tools, and guide exploration — never to hand down truths.

### 1.2 Why This Works

1. **Retention**: Students who discover rules remember them longer than students who memorize them
2. **Transfer**: Students who learn through exploration can apply knowledge to new situations
3. **Motivation**: Discovery is intrinsically motivating; memorization is not
4. **Depth**: Exploration reveals connections that memorization hides
5. **Joy**: Mathematics is beautiful when discovered; it is tedious when memorized

### 1.3 The Teacher's Role

| Role | Description | Example |
|------|-------------|---------|
| **Questioner** | Ask open-ended questions | "What happens when you add two phi-numbers?" |
| **Provocateur** | Challenge assumptions | "Are you sure the pattern continues?" |
| **Tool-provider** | Give students the right instruments | "Here is a ruler and compass. Construct the golden rectangle." |
| **Connector** | Show how topics relate | "Notice how the harmonic mean connects to music." |
| **Celebrator** | Acknowledge discoveries | "You just proved a theorem! Write it down." |

---

## 2. The 35+ Mathematics Systems

### 2.1 Complete List

| # | System | Key Number/Concept | Primary Domain |
|---|--------|-------------------|----------------|
| 1 | Phi Addition | φ = 1.618... | Algebra |
| 2 | Phi Subtraction | ⊖ | Algebra |
| 3 | Phi Multiplication | ⊗ | Algebra |
| 4 | Phi Division | ⊘ | Algebra |
| 5 | Phi Algebra | φ² = φ + 1 | Algebra |
| 6 | Phi Algebra Expanded | Group/ring structures | Algebra |
| 7 | Phi Calculus | d/dx(φ^x) | Calculus |
| 8 | Phi Calculus Expanded | Integration, series | Calculus |
| 9 | Phi Compounding | φⁿ growth | Applied Math |
| 10 | Phi Dynamics | ODEs with φ | Differential Equations |
| 11 | Phi Dynamics Expanded | Stability, bifurcation | Differential Equations |
| 12 | Phi vs Standard | Comparative analysis | Meta-math |
| 13 | Phi Statistics | φ-weighted distributions | Statistics |
| 14 | Phi Geometry | Golden rectangles, spirals | Geometry |
| 15 | Phi Topology | Self-similar spaces | Topology |
| 16 | Phi Trigonometry | φ in trig identities | Trigonometry |
| 17 | Phi Chemistry | Molecular φ-structures | Chemistry |
| 18 | Phi Number Theory | Fibonacci primes | Number Theory |
| 19 | Phi Ecology | Growth models | Ecology |
| 20 | Phi Medicine | Dosage optimization | Medicine |
| 21 | Phi Economics | Market dynamics | Economics |
| 22 | Phi Acoustics | Sound and φ | Acoustics |
| 23 | Phi Electromagnetics | Field theory | Physics |
| 24 | Phi Optics | Light and φ | Physics |
| 25 | Silver Ratio | δₛ = 2.414... | Algebra |
| 26 | Bronze Ratio | δᵦ = 3.303... | Algebra |
| 27 | Harmonic Math | H_n, harmonic mean | Analysis |
| 28 | Living Math | Coherence, connection | Systems Theory |
| 29 | Plastic Number | ψ = 1.325... | Algebra |
| 30 | Supergolden Ratio | ψₛ = 1.466... | Algebra |
| 31 | Fibonacci Sequence | F(n) = F(n-1) + F(n-2) | Combinatorics |
| 32 | Lucas Sequence | L(n) = L(n-1) + L(n-2) | Combinatorics |
| 33 | Padovan Sequence | P(n) = P(n-2) + P(n-3) | Combinatorics |
| 34 | Kepler Mathematics | T²/a³ = const | Applied Math |
| 35 | Phi-Harmonic Integration | ⊕_φₕ | Synthesis |
| 36 | DBW (De Boer-Wiegel) | Consciousness field | Applied Physics |
| 37 | FTL Mathematics | Warp metrics | Theoretical Physics |

### 2.2 Grouping by Family

| Family | Systems | Common Root |
|--------|---------|-------------|
| **Metallic Means** | Phi, Silver, Bronze | x² = nx + 1 |
| **Cubic Roots** | Plastic, Supergolden, Tribonacci | x³ = ax^b + c |
| **Recurrence Sequences** | Fibonacci, Lucas, Padovan | Linear recurrences |
| **Harmonic Systems** | Harmonic Math, Phi-Harmonic Integration | 1/n series |
| **Applied Systems** | Kepler, DBW, FTL | Physical applications |
| **Extended Phi** | Phi Algebra through Phi Optics | φ-based structures |
| **Living Systems** | Living Math | Coherence theory |

---

## 3. The HOW_TO_LEARN Folders

### 3.1 Structure

Each ratio-system in `06_EXPANDED_MATHEMATICS` contains a `HOW_TO_LEARN/` folder:

```
[SYSTEM]/
├── 01_theory.md          # Complete mathematical theory
├── 02_tables.md          # Reference tables
├── 03_examples.md        # Worked examples
├── 04_applications.md    # Real-world applications
├── 05_problems.md        # Practice problems
├── 06_answers.md         # Complete answer key
├── 07_[domain].md        # Domain-specific extensions
├── HOW_TO_LEARN/
│   ├── README.md         # Teaching guide for this system
│   ├── 01_discovery.md   # Discovery activities
│   ├── 02_exploration.md # Guided exploration
│   ├── 03_verification.md# Proof and verification
│   ├── 04_generalization.md # Extending the pattern
│   ├── 05_connection.md  # Connecting to other systems
│   └── 06_assessment.md  # Assessment rubrics
└── README.md             # System overview
```

### 3.2 How to Use the HOW_TO_LEARN Folders

**For Teachers:**
1. Read `README.md` first to understand the system
2. Follow `01_discovery.md` to design the opening activity
3. Use `02_exploration.md` to structure the main lesson
4. Reference `03_verification.md` for proof-writing guidance
5. Use `04_generalization.md` for extension activities
6. Use `05_connection.md` to show relationships to other systems
7. Use `06_assessment.md` for rubrics and grading

**For Students:**
1. Start with `01_discovery.md` — do the activities
2. Move to `02_exploration.md` — work through the guided problems
3. Try `03_verification.md` — can you prove the patterns?
4. Challenge yourself with `04_generalization.md` — extend the pattern
5. Make connections with `05_connection.md` — how does this relate to what you already know?
6. Test yourself with `06_assessment.md` — can you explain this to someone else?

**For Self-Study:**
1. Read the theory file (`01_theory.md`)
2. Work through the examples (`03_examples.md`)
3. Do the problems (`05_problems.md`)
4. Check your answers (`06_answers.md`)
5. Read the applications (`04_applications.md`) to see why it matters

---

# PART II: GRADE-BY-GRADE CURRICULUM MAP

---

## 4. Foundation Level (Grades 1-5, Ages 6-11)

### 4.1 Grade 1: Introduction to Patterns

**Theme**: "Math is about patterns, not numbers"

| Week | Topic | Activity | System |
|------|-------|----------|--------|
| 1-2 | Counting patterns | Count by 2s, 3s, 5s | Fibonacci intro |
| 3-4 | Shape patterns | Draw squares and rectangles | Phi intro |
| 5-6 | Sound patterns | Clap rhythms, find beats | Harmonic intro |
| 7-8 | Nature patterns | Find spirals in flowers | Fibonacci in nature |
| 9-10 | Pattern creation | Make your own patterns | All systems |
| 11-12 | Pattern sharing | Present your patterns | Communication |

**Learning Objectives:**
- Identify simple patterns (AB, ABB, ABC)
- Recognize that patterns repeat
- Create original patterns
- Understand that math describes patterns

### 4.2 Grade 2: The Number 1 and Its Friends

**Theme**: "Every number has a personality"

| Week | Topic | Activity | System |
|------|-------|----------|--------|
| 1-3 | The number 1 | What is 1? Why is it special? | Foundation |
| 4-6 | Adding 1 | What happens when you add 1? | Phi Addition intro |
| 7-9 | Halving | What is half? | Harmonic intro |
| 10-12 | Combining | Add and halve together | Phi-Harmonic intro |

**Learning Objectives:**
- Understand 1 as the unit
- Explore what happens when you add 1 repeatedly
- Understand the concept of half
- Begin to see connections between adding and halving

### 4.3 Grade 3: The Golden Rectangle

**Theme**: "The most beautiful rectangle"

| Week | Topic | Activity | System |
|------|-------|----------|--------|
| 1-2 | Rectangles | Draw rectangles of all sizes | Phi Geometry |
| 3-4 | The golden cut | Cut a rectangle to make a square + smaller rectangle | Phi ratio |
| 5-6 | Measuring phi | Measure the ratio of sides | φ ≈ 1.618 |
| 7-8 | Drawing spirals | Draw golden spirals | Fibonacci |
| 9-10 | Nature hunt | Find golden rectangles in nature | Applications |
| 11-12 | Art project | Create phi-based art | Integration |

**Learning Objectives:**
- Construct a golden rectangle using ruler and compass
- Measure the golden ratio in physical objects
- Draw a golden spiral
- Connect phi to natural forms

### 4.4 Grade 4: Music and Math

**Theme**: "Why some sounds fit together"

| Week | Topic | Activity | System |
|------|-------|----------|--------|
| 1-2 | vibrations | Make strings vibrate | Harmonic intro |
| 3-4 | Simple ratios | 2:1, 3:2, 4:3 intervals | Harmonic ratios |
| 5-6 | The harmonic series | Hear the overtone series | Harmonic series |
| 7-8 | Consonance | Which intervals sound good? | Harmonic analysis |
| 9-10 | Composing | Write a melody using ratios | Applications |
| 11-12 | Integration | How does music connect to phi? | Phi-Harmonic |

**Learning Objectives:**
- Understand that sound is vibration
- Hear and identify simple frequency ratios
- Understand the harmonic series
- Connect mathematical ratios to musical intervals

### 4.5 Grade 5: Counting Like Nature

**Theme**: "How plants and animals count"

| Week | Topic | Activity | System |
|------|-------|----------|--------|
| 1-2 | Fibonacci numbers | Count petals, seeds | Fibonacci |
| 3-4 | The rabbit problem | Model rabbit population | Fibonacci recurrence |
| 5-6 | Lucas numbers | Compare with Fibonacci | Lucas |
| 7-8 | Nature patterns | Find Fibonacci in pinecones, pineapples | Applications |
| 9-10 | The golden ratio connection | F(n+1)/F(n) → φ | Phi connection |
| 11-12 | Other sequences | Padovan, Silver | Preview |

**Learning Objectives:**
- Generate Fibonacci and Lucas numbers
- Find Fibonacci patterns in nature
- Understand the connection between Fibonacci and phi
- Preview other ratio-systems

---

## 5. Intermediate Level (Grades 6-8, Ages 11-14)

### 5.1 Grade 6: The Metallic Means Family

**Theme**: "Phi has brothers and sisters"

| Week | Topic | Activity | System |
|------|-------|----------|--------|
| 1-2 | Review phi | Golden ratio properties | Phi review |
| 3-4 | Silver ratio | x² = 2x + 1; δₛ = 2.414 | Silver |
| 5-6 | Bronze ratio | x² = 3x + 1; δᵦ = 3.303 | Bronze |
| 7-8 | The metallic means formula | Mₙ = (n + √(n²+4))/2 | Generalization |
| 9-10 | Metallic spirals | Draw silver and bronze spirals | Geometry |
| 11-12 | Comparison | How do the metallic means differ? | Analysis |

**Learning Objectives:**
- Derive the silver and bronze ratios
- Understand the metallic means formula
- Draw spirals for each metallic mean
- Compare the growth rates of different metallic sequences

### 5.2 Grade 7: Harmonic Mathematics

**Theme**: "The mathematics of harmony"

| Week | Topic | Activity | System |
|------|-------|----------|--------|
| 1-2 | Harmonic series | Sum 1 + 1/2 + 1/3 + ... | Harmonic series |
| 3-4 | Divergence | Prove the series diverges | Oresme's proof |
| 5-6 | Harmonic mean | H(a,b) = 2ab/(a+b) | Harmonic mean |
| 7-8 | Comparing means | H ≤ G ≤ A | Mean inequality |
| 9-10 | Harmonic numbers | Compute H₁ through H₂₀ | Computation |
| 11-12 | Applications | Physics, engineering | Real-world |

**Learning Objectives:**
- Compute partial sums of the harmonic series
- Prove divergence using Oresme's method
- Calculate harmonic means
- Understand the relationship between harmonic, geometric, and arithmetic means

### 5.3 Grade 8: Cubic Roots and Recurrence

**Theme**: "Beyond the quadratic"

| Week | Topic | Activity | System |
|------|-------|----------|--------|
| 1-2 | The plastic number | x³ = x + 1; ψ = 1.325 | Plastic |
| 3-4 | The supergolden ratio | x³ = x² + 1; ψₛ = 1.466 | Supergolden |
| 5-6 | Padovan sequence | P(n) = P(n-2) + P(n-3) | Padovan |
| 7-8 | Narayana cows | Connection to supergolden | Applications |
| 9-10 | Cubic equations | Solving x³ = ax + b | Algebra |
| 11-12 | 3D spirals | Drawing Padovan spirals | Geometry |

**Learning Objectives:**
- Solve simple cubic equations
- Understand the plastic and supergolden ratios
- Generate Padovan numbers
- Connect cubic equations to 3D geometry

---

## 6. Advanced Level (Grades 9-12, Ages 14-18)

### 6.1 Grade 9: Algebra of the Ratio-Systems

**Theme**: "The algebra behind the beauty"

| Semester | Topic | Systems |
|----------|-------|---------|
| Fall | Phi addition, subtraction, multiplication, division | Phi operations |
| Fall | Algebraic structures: groups, rings, fields | Phi algebra |
| Spring | Metallic means algebra | Silver, Bronze algebra |
| Spring | Recurrence relations | Fibonacci, Lucas, Padovan |

**Learning Objectives:**
- Prove closure, associativity, and commutativity for phi-operations
- Understand phi as an algebraic number (minimal polynomial x² − x − 1)
- Solve recurrence relations using characteristic equations
- Connect algebraic properties to geometric interpretations

### 6.2 Grade 10: Geometry and Trigonometry

**Theme**: "Shape and proportion"

| Semester | Topic | Systems |
|----------|-------|---------|
| Fall | Golden rectangle constructions | Phi geometry |
| Fall | Fibonacci and Lucas in geometry | Fibonacci geometry |
| Spring | Phi in trigonometry | Phi trig |
| Spring | Kepler's laws and orbital geometry | Kepler |

**Learning Objectives:**
- Construct golden rectangles and spirals with compass and straightedge
- Prove geometric properties of the golden ratio
- Connect phi to trigonometric identities
- Apply Kepler's third law to orbital calculations

### 6.3 Grade 11: Calculus and Analysis

**Theme**: "Rates of change and accumulation"

| Semester | Topic | Systems |
|----------|-------|---------|
| Fall | Phi-calculus: derivatives of φ^x | Phi calculus |
| Fall | Integration involving phi | Phi integration |
| Spring | Harmonic series and convergence | Harmonic analysis |
| Spring | Phi-harmonic transform | Phi-harmonic integration |

**Learning Objectives:**
- Differentiate and integrate functions involving φ
- Understand convergence of series involving phi and harmonic numbers
- Apply the phi-harmonic transform to simple signals
- Connect calculus concepts to geometric and harmonic interpretations

### 6.4 Grade 12: Advanced Topics and Integration

**Theme**: "How everything connects"

| Semester | Topic | Systems |
|----------|-------|---------|
| Fall | Phi statistics and probability | Phi statistics |
| Fall | Phi in chemistry and physics | Phi chemistry, electromagnetics |
| Spring | Living mathematics | Living Math |
| Spring | Phi-harmonic integration (capstone) | All systems |

**Learning Objectives:**
- Apply phi-weighted statistics to data analysis
- Understand phi's role in molecular structures
- See how all ratio-systems connect through the phi-harmonic integration
- Complete a capstone project integrating multiple systems

---

## 7. University Level (Undergraduate, Ages 18-22)

### 7.1 Semester-by-Semester Plan (4-Year Program)

#### Year 1: Foundations

| Semester | Course | Topics | Systems |
|----------|--------|--------|---------|
| Fall | MATH 101: Abstract Algebra I | Groups, rings, fields | Phi algebra, metallic means |
| Fall | MATH 102: Number Theory | Primes, divisibility, sequences | Fibonacci, Lucas, Padovan |
| Spring | MATH 111: Real Analysis I | Limits, continuity, differentiation | Phi calculus, harmonic analysis |
| Spring | MATH 112: Linear Algebra | Vector spaces, matrices | Phi-harmonic algebra |

**Learning Objectives:**
- Prove the group properties of phi-addition
- Understand the ring structure of Z[φ]
- Prove convergence of phi-related series
- Work with the phi-harmonic algebra as a matrix algebra

#### Year 2: Core Theory

| Semester | Course | Topics | Systems |
|----------|--------|--------|---------|
| Fall | MATH 201: Abstract Algebra II | Galois theory, field extensions | Minimal polynomials, conjugates |
| Fall | MATH 202: Complex Analysis | Analytic functions, residues | Phi in the complex plane |
| Spring | MATH 211: Topology | Topological spaces, continuity | Phi topology, self-similar spaces |
| Spring | MATH 212: Differential Equations | ODEs, PDEs | Phi dynamics, harmonic oscillators |

**Learning Objectives:**
- Compute the Galois group of φ's minimal polynomial
- Understand phi as an element of Q(√5)
- Prove topological properties of phi-harmonic spaces
- Solve the phi-harmonic oscillator equation

#### Year 3: Applications

| Semester | Course | Topics | Systems |
|----------|--------|--------|---------|
| Fall | MATH 301: Fourier Analysis | Fourier series, transforms | Harmonic analysis, phi-harmonic transform |
| Fall | MATH 302: Probability & Statistics | Distributions, inference | Phi statistics |
| Spring | MATH 311: Differential Geometry | Manifolds, curvature | Phi-harmonic manifold |
| Spring | MATH 312: Mathematical Physics | Classical and quantum mechanics | Phi in physics, Kepler |

**Learning Objectives:**
- Apply Fourier analysis to phi-harmonic signals
- Understand phi-weighted probability distributions
- Compute curvature of the phi-harmonic manifold
- Apply phi-mathematics to physical problems

#### Year 4: Research

| Semester | Course | Topics | Systems |
|----------|--------|--------|---------|
| Fall | MATH 401: Research Seminar | Independent research | Student's choice |
| Fall | MATH 402: Category Theory | Categories, functors, natural transformations | Phi-harmonic category |
| Spring | MATH 411: Thesis I | Literature review, problem formulation | Original research |
| Spring | MATH 412: Thesis II | Original research, write-up | Original research |

**Learning Objectives:**
- Read and understand research papers in phi-harmonic mathematics
- Formulate original research problems
- Carry out original research
- Write a thesis communicating research results

### 7.2 Course Descriptions

#### MATH 101: Abstract Algebra I

**Description**: Introduction to algebraic structures through the lens of ratio-systems.

**Topics**:
1. Groups: definition, examples, the phi-addition group (ℝ, ⊕)
2. Rings: definition, examples, the ring Z[φ] of golden integers
3. Fields: definition, examples, Q(√5) as the field of phi-numbers
4. Homomorphisms and isomorphisms
5. Subgroups and quotient groups

**Assessment**: Problem sets (40%), midterm (25%), final exam (35%)

**Textbook**: Custom notes drawing from Gallian's *Contemporary Abstract Algebra* and the corpus documents

#### MATH 201: Abstract Algebra II

**Description**: Galois theory and field extensions, with applications to the ratio-systems.

**Topics**:
1. Field extensions: Q(√5), Q(√2), Q(√13)
2. Minimal polynomials: x²−x−1 for φ, x²−2x−1 for δₛ, x²−3x−1 for δᵦ
3. Galois groups: Gal(Q(√5)/Q) ≅ Z/2Z
4. Norm and trace maps
5. Splitting of primes in quadratic fields

**Assessment**: Problem sets (35%), midterm (25%), final exam (40%)

#### MATH 301: Fourier Analysis

**Description**: Fourier analysis with applications to phi-harmonic signals.

**Topics**:
1. Fourier series: convergence, Parseval's theorem
2. Fourier transform: inversion, convolution, Plancherel
3. Phi-harmonic transform: definition, properties, applications
4. Wavelets and multi-resolution analysis
5. Applications to signal processing

**Assessment**: Problem sets (30%), programming projects (30%), final exam (40%)

---

## 8. Graduate Level (PhD, Ages 22+)

### 8.1 PhD Program Structure

#### Year 1: Coursework and Preliminary Exam

| Semester | Course | Topics |
|----------|--------|--------|
| Fall | MATH 501: Advanced Algebra | Algebraic number theory, class field theory |
| Fall | MATH 502: Advanced Analysis | Harmonic analysis, distributions |
| Spring | MATH 511: Advanced Geometry | Riemannian geometry, geometric analysis |
| Spring | MATH 512: Advanced Topology | Algebraic topology, K-theory |
| Spring | Preliminary Exam | Comprehensive exam on core topics |

#### Year 2: Specialization

| Semester | Course | Topics |
|----------|--------|--------|
| Fall | MATH 601: Research Topics in Phi-Mathematics | Current research directions |
| Fall | MATH 602: Seminar in Phi-Harmonic Integration | Advanced integration topics |
| Spring | MATH 611: Independent Study | Literature review, problem selection |
| Spring | MATH 612: Teaching Practicum | Teaching under supervision |

#### Year 3: Research

| Activity | Description |
|----------|-------------|
| Research | Original research under advisor's supervision |
| Qualifying Exam | Defend research proposal |
| Conference Presentations | Present at 2-3 conferences |
| Publications | Submit 1-2 papers to journals |

#### Year 4-5: Dissertation

| Activity | Description |
|----------|-------------|
| Research | Complete original research |
| Publications | Publish 2-4 papers |
| Dissertation Writing | Write and defend dissertation |
| Job Market | Apply for academic positions |

### 8.2 PhD Research Directions

| Direction | Description | Key Problems |
|-----------|-------------|--------------|
| **Phi-harmonic analysis** | Extending the phi-harmonic transform to higher dimensions | Multi-dimensional phi-harmonic transform, sampling theory |
| **Phi-harmonic geometry** | Geometry of the phi-harmonic manifold | Curvature estimates, geodesics, minimal surfaces |
| **Phi-harmonic algebra** | Abstract algebraic structures in phi-harmonic mathematics | Category theory, homological algebra |
| **Phi-harmonic physics** | Applications to physics | Quantum field theory, consciousness field theory |
| **Phi-harmonic computation** | Algorithms and complexity | Fast phi-harmonic transform, phi-harmonic sorting |
| **Phi-harmonic biology** | Applications to biology | Growth models, neural networks, evolution |

### 8.3 Dissertation Examples

**Example Dissertation 1**: "The Phi-Harmonic Transform: Theory and Applications"
- Chapter 1: Introduction and motivation
- Chapter 2: The phi-harmonic transform: definition and basic properties
- Chapter 3: Sampling theory for phi-harmonic signals
- Chapter 4: Fast phi-harmonic transform algorithm
- Chapter 5: Applications to audio processing
- Chapter 6: Applications to biomedical signals
- Chapter 7: Conclusion and future work

**Example Dissertation 2**: "Geometry of the Phi-Harmonic Manifold"
- Chapter 1: Introduction
- Chapter 2: The phi-harmonic metric
- Chapter 3: Curvature and topology
- Chapter 4: Geodesics and distance
- Chapter 5: Minimal surfaces
- Chapter 6: Comparison with hyperbolic geometry
- Chapter 7: Applications to physics

---

# PART III: PREREQUISITE MAP

---

## 9. What to Learn Before What

### 9.1 The Dependency Graph

```
Grade 1: Patterns → Grade 2: Numbers → Grade 3: Phi → Grade 4: Harmonic → Grade 5: Fibonacci
    ↓
Grade 6: Metallic Means → Grade 7: Harmonic Series → Grade 8: Cubic Roots
    ↓
Grade 9: Algebra → Grade 10: Geometry → Grade 11: Calculus → Grade 12: Integration
    ↓
Year 1 University: Abstract Algebra + Number Theory + Analysis + Linear Algebra
    ↓
Year 2: Galois Theory + Complex Analysis + Topology + Differential Equations
    ↓
Year 3: Fourier Analysis + Statistics + Differential Geometry + Mathematical Physics
    ↓
Year 4: Research Seminar + Category Theory + Thesis
    ↓
PhD: Advanced Coursework → Specialization → Research → Dissertation
```

### 9.2 Detailed Prerequisites

| System | Prerequisites | Can Be Taught With |
|--------|--------------|-------------------|
| Phi Addition | Basic addition | Grade 3 |
| Phi Subtraction | Phi Addition | Grade 3 |
| Phi Multiplication | Phi Addition, basic multiplication | Grade 6 |
| Phi Division | Phi Multiplication | Grade 6 |
| Phi Algebra | Basic algebra | Grade 9 |
| Phi Calculus | Basic calculus | Grade 11 |
| Phi Statistics | Probability, statistics | Grade 12 |
| Phi Geometry | Basic geometry | Grade 3, 10 |
| Phi Topology | Point-set topology | Year 2 University |
| Phi Trigonometry | Trigonometry | Grade 10 |
| Phi Chemistry | Basic chemistry | Grade 12 |
| Phi Number Theory | Number theory | Year 1 University |
| Phi Ecology | Basic biology, calculus | Grade 12 |
| Phi Medicine | Basic biology | Grade 12 |
| Phi Economics | Basic economics | Grade 12 |
| Phi Acoustics | Physics, trigonometry | Grade 10 |
| Phi Electromagnetics | Physics, vector calculus | Year 3 University |
| Phi Optics | Physics, wave theory | Year 3 University |
| Silver Ratio | Phi Addition | Grade 6 |
| Bronze Ratio | Silver Ratio | Grade 6 |
| Harmonic Math | Basic fractions | Grade 4, 7 |
| Living Math | All basic systems | Grade 8 |
| Plastic Number | Cubic equations | Grade 8 |
| Supergolden | Plastic Number | Grade 8 |
| Fibonacci | Basic patterns | Grade 5 |
| Lucas | Fibonacci | Grade 5 |
| Padovan | Basic recurrences | Grade 8 |
| Kepler | Basic physics, algebra | Grade 10 |
| Phi-Harmonic Integration | Phi Algebra + Harmonic Math | Grade 12 |
| DBW | All above + physics | PhD |
| FTL Mathematics | All above + differential geometry | PhD |

### 9.3 Parallel Tracks

Students can learn some systems in parallel:

**Track A (Geometric)**: Phi → Silver → Bronze → Metallic Means → Phi Geometry
**Track B (Algebraic)**: Phi Algebra → Phi Calculus → Phi Analysis → Abstract Algebra
**Track C (Harmonic)**: Harmonic intro → Harmonic Series → Harmonic Analysis → Phi-Harmonic Integration
**Track D (Applied)**: Fibonacci → Kepler → Phi Statistics → Phi Medicine/Ecology/Economics
**Track E (Advanced)**: All above → Living Math → DBW → FTL Mathematics

---

# PART IV: ASSESSMENT FRAMEWORK

---

## 10. Assessment Philosophy

### 10.1 Principles

1. **Assess understanding, not memorization**: Can the student explain *why*, not just *what*?
2. **Assess process, not just product**: How did the student arrive at the answer?
3. **Assess connections**: Can the student see how systems relate?
4. **Assess creativity**: Can the student create something original?
5. **Assess communication**: Can the student explain mathematics to others?

### 10.2 Assessment Types

| Type | Description | Weight |
|------|-------------|--------|
| **Discovery Journal** | Document explorations and discoveries | 15% |
| **Problem Sets** | Practice problems (guided + open-ended) | 25% |
| **Projects** | Extended investigations | 20% |
| **Presentations** | Explain a system to the class | 10% |
| **Exams** | Midterm and final (proof-based) | 20% |
| **Portfolio** | Collection of best work over the term | 10% |

### 10.3 Rubric for Discovery Journal

| Criteria | Excellent (4) | Good (3) | Satisfactory (2) | Needs Work (1) |
|----------|--------------|----------|-------------------|----------------|
| **Observation** | Detailed, insightful observations | Clear observations | Basic observations | Missing or unclear |
| **Pattern recognition** | Identifies deep patterns | Identifies obvious patterns | Identifies some patterns | Cannot identify patterns |
| **Conjecture** | Makes precise, testable conjectures | Makes reasonable conjectures | Makes vague conjectures | Cannot make conjectures |
| **Verification** | Proves conjectures rigorously | Verifies with examples | Checks some cases | No verification |
| **Connection** | Connects to other systems deeply | Connects to some systems | Makes surface connections | No connections |

### 10.4 Rubric for Projects

| Criteria | Excellent (4) | Good (3) | Satisfactory (2) | Needs Work (1) |
|----------|--------------|----------|-------------------|----------------|
| **Depth** | Explores the system deeply | Good exploration | Surface exploration | Minimal exploration |
| **Creativity** | Original insights and methods | Some original work | Follows given methods | Copies others' work |
| **Communication** | Clear, beautiful presentation | Clear presentation | Understandable | Unclear |
| **Connection** | Shows deep connections | Shows some connections | Mentions connections | No connections |
| **Reflection** | Thoughtful reflection on learning | Some reflection | Minimal reflection | No reflection |

---

# PART V: TEACHING METHODOLOGY

---

## 11. The Discovery-First Approach

### 11.1 Lesson Structure

Every lesson follows the **5E Model**:

1. **Engage**: Pose a provocative question or problem
2. **Explore**: Students investigate through activities
3. **Explain**: Students articulate what they discovered
4. **Elaborate**: Students extend the discovery to new situations
5. **Evaluate**: Students demonstrate understanding

### 11.2 Example Lesson: The Golden Ratio (Grade 3)

**Engage** (5 min):
"Here are two rectangles. Which one do you think is more beautiful?"

[Show a 2×3 rectangle and a golden rectangle]

**Explore** (20 min):
1. Measure the sides of both rectangles
2. Calculate the ratio of long side to short side
3. Cut a square from the golden rectangle
4. Measure the remaining rectangle
5. What do you notice?

**Explain** (10 min):
"The ratio is approximately 1.618. We call this the golden ratio, φ. When you cut a square from a golden rectangle, the remaining rectangle is also golden!"

**Elaborate** (10 min):
"Can you find this ratio in nature? Look at these photos of flowers, shells, and galaxies."

**Evaluate** (5 min):
"Draw a golden rectangle and explain why it's special."

### 11.3 Example Lesson: The Harmonic Series (Grade 7)

**Engage** (5 min):
"Can the sum 1 + 1/2 + 1/3 + 1/4 + ... ever reach 10? What about 100?"

**Explore** (20 min):
1. Compute partial sums: H₁, H₂, H₃, ... H₂₀
2. Plot the sums on a graph
3. How fast is it growing?
4. Compare with ln(n) + 0.577

**Explain** (10 min):
"The harmonic series grows without bound, but extremely slowly. To reach 10, you need about 12,000 terms. To reach 20, you need about 272 million terms."

**Elaborate** (10 min):
"Nicole Oresme proved this in 1350 using a brilliant trick. Can you understand his proof?"

**Evaluate** (5 min):
"Prove that the harmonic series diverges using Oresme's method."

---

## 12. Differentiation

### 12.1 For Advanced Students

- **Extension problems**: Open-ended investigations
- **Independent research**: Student-designed projects
- **Mentoring**: Help younger students
- **Competition preparation**: Math olympiad problems
- **Cross-disciplinary**: Connect to music, art, science

### 12.2 For Struggling Students

- **Hands-on activities**: More physical manipulatives
- **Visual representations**: More diagrams and pictures
- **Simplified problems**: Fewer variables, smaller numbers
- **Peer tutoring**: Work with stronger students
- **Extra time**: Extended deadlines, more practice

### 12.3 For English Language Learners

- **Visual vocabulary**: Math word walls with pictures
- **Bilingual resources**: Key terms in multiple languages
- **Gesture and movement**: Act out mathematical concepts
- **Real-world connections**: Use culturally relevant examples
- **Collaborative learning**: Partner with fluent speakers

---

# PART VI: IMPLEMENTATION GUIDE

---

## 13. School-Level Implementation

### 13.1 Year 1: Pilot Program

| Quarter | Action | Responsible |
|---------|--------|-------------|
| Q1 | Train 3-5 teachers on foundation material | Curriculum coordinator |
| Q2 | Pilot in 2-3 classrooms | Pilot teachers |
| Q3 | Collect feedback, revise materials | All stakeholders |
| Q4 | Plan expansion | Administration |

### 13.2 Year 2: Expansion

| Quarter | Action | Responsible |
|---------|--------|-------------|
| Q1 | Train 10-15 more teachers | Curriculum coordinator |
| Q2 | Expand to all elementary grades | Grade-level leads |
| Q3 | Begin middle school pilot | Middle school teachers |
| Q4 | Assess and revise | All stakeholders |

### 13.3 Year 3: Full Implementation

| Quarter | Action | Responsible |
|---------|--------|-------------|
| Q1 | Full K-8 implementation | All math teachers |
| Q2 | Begin high school pilot | High school teachers |
| Q3 | Assess and revise | All stakeholders |
| Q4 | Plan university partnerships | Administration |

### 13.4 Year 4+: Sustainability

- Annual teacher training workshops
- Student showcase events (phi-harmonic art show, music concert)
- Research partnerships with universities
- Open-source curriculum development
- Community engagement events

---

## 14. Teacher Training

### 14.1 Required Training

| Module | Hours | Content |
|--------|-------|---------|
| **Foundation** | 16 | All 10 ratio-systems at the student level |
| **Discovery Methods** | 8 | The 5E model, questioning techniques |
| **Assessment** | 8 | Discovery journals, project rubrics |
| **Differentiation** | 8 | Adapting for advanced/struggling students |
| **Technology** | 8 | GeoGebra, Desmos, coding |
| **Integration** | 8 | Connecting to music, art, science |

**Total**: 56 hours (1 week intensive or 8 weekly sessions)

### 14.2 Ongoing Support

- **Monthly meetings**: Share successes and challenges
- **Peer observation**: Visit other teachers' classrooms
- **Online community**: Forum for questions and resources
- **Annual conference**: Present student work and research
- **Mentoring**: Experienced teachers support newcomers

---

## 15. Technology Integration

### 15.1 Software Tools

| Tool | Use | Level |
|------|-----|-------|
| **GeoGebra** | Geometric constructions | Grades 3-12 |
| **Desmos** | Graphing and exploration | Grades 6-12 |
| **Python** | Programming and computation | Grades 9-PhD |
| **MATLAB** | Advanced computation | University |
| **LaTeX** | Mathematical writing | Grades 11-PhD |
| **Minecraft** | 3D phi-construction | Grades 3-8 |

### 15.2 Sample GeoGebra Activities

**Activity 1: Golden Rectangle Construction**
1. Open GeoGebra
2. Create a rectangle ABCD
3. Construct the midpoint M of AB
4. Draw a circle centered at M with radius MC
5. Extend AB to meet the circle at E
6. Rectangle AEFD is golden!

**Activity 2: Fibonacci Spiral**
1. Create a 1×1 square
2. Create another 1×1 square adjacent
3. Create a 2×2 square adjacent
4. Continue: 3×3, 5×5, 8×8
5. Draw quarter-circles in each square
6. The spiral is the golden spiral!

### 15.3 Sample Python Activities

**Activity 1: Fibonacci Numbers**
```python
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

for i in range(20):
    print(f"F({i}) = {fibonacci(i)}")
```

**Activity 2: Harmonic Series**
```python
def harmonic(n):
    return sum(1/i for i in range(1, n+1))

for n in [10, 100, 1000, 10000]:
    print(f"H({n}) = {harmonic(n):.6f}")
```

---

# PART VII: RESOURCE APPENDICES

---

## 16. Recommended Reading

### 16.1 For Teachers

- Livio, M. (2002). *The Golden Ratio*. Broadway Books.
- Posamentier, A. & Lehmann, I. (2007). *The Fabulous Fibonacci Numbers*. Prometheus Books.
- Devlin, K. (2001). *The Math Instinct*. Thunder's Mouth Press.
- Brown, S. (2012). *Music and Math*. University of Rochester Press.
- Mandelbrot, B. (1982). *The Fractal Geometry of Nature*. W.H. Freeman.

### 16.2 For Students (Elementary)

- Tang, G. (2010). *The Golden Ratio*. Sterling.
- Posamentier, A. (2010). *The Fabulous Fibonacci Numbers*. Prometheus Books.
- Peterson, I. (2001). *Mathematical Treks*. MAA.

### 16.3 For Students (Secondary)

- Nahin, P. (2010). *Dr. Euler's Fabulous Formula*. Princeton.
- Derbyshire, J. (2006). *Prime Obsession*. Joseph Henry Press.
- Stewart, I. (2008). *Professor Stewart's Cabinet of Mathematical Treasures*. Basic Books.

### 16.4 For University Students

- Apostol, T. (1976). *Introduction to Analytic Number Theory*. Springer.
- Stein, E. & Shakarchi, R. (2003). *Fourier Analysis*. Princeton.
- Gallian, J. (2017). *Contemporary Abstract Algebra*. Cengage.

---

## 17. Glossary of Teaching Terms

| Term | Definition |
|------|-----------|
| **5E Model** | Engage, Explore, Explain, Elaborate, Evaluate |
| **Discovery learning** | Students discover rules through exploration |
| **Guide/teacher approach** | Teacher guides, student discovers |
| **Answer-first approach** | Teacher provides rules, student memorizes |
| **Scaffolding** | Providing support structures for learning |
| **Differentiation** | Adapting instruction for different learners |
| **Formative assessment** | Ongoing assessment during learning |
| **Summative assessment** | Assessment at the end of a unit |
| **Portfolio** | Collection of student work over time |
| **Discovery journal** | Student record of explorations and discoveries |

---

## 18. Index

- **Assessment**: framework, 10; discovery journal, 10.3; projects, 10.4; rubrics, 10.3-10.4
- **Bronze ratio**: Grade 6, 5.1; algebra, 8.1
- **Calculus (phi)**: Grade 11, 6.3; university, Year 1
- **Category theory**: Year 4 University, 7.1
- **Chemistry (phi)**: Grade 12, 6.4
- **Cubic roots**: Grade 8, 5.3
- **DBW**: PhD, 8.1
- **Differentiation**: teaching, 12
- **Discovery journal**: assessment, 10.3
- **Discovery-first approach**: 11
- **Ecology (phi)**: Grade 12, 6.4
- **Economics (phi)**: Grade 12, 6.4
- **Electromagnetics (phi)**: Year 3 University, 7.1
- **FiveE model**: 11.1
- **Fibonacci**: Grade 5, 4.5; university, Year 1
- **Fourier analysis**: Year 3 University, 7.1
- **FTL mathematics**: PhD, 8.1
- **Geometry (phi)**: Grade 3, 4.3; Grade 10, 6.2
- **Golden ratio**: see Phi
- **Guide/teacher approach**: 1.1
- **Harmonic mathematics**: Grade 4, 4.4; Grade 7, 5.2; university, Year 3
- **Harmonic mean**: Grade 7, 5.2
- **Harmonic series**: Grade 7, 5.2; university, Year 3
- **HOW_TO_LEARN folders**: 3
- **Integration (phi-harmonic)**: Grade 12, 6.4
- **Kepler mathematics**: Grade 10, 6.2; Year 3 University
- **Living mathematics**: Grade 12, 6.4
- **Lucas sequence**: Grade 5, 4.5; university, Year 1
- **Medicine (phi)**: Grade 12, 6.4
- **Metallic means**: Grade 6, 5.1; university, Year 1
- **Music and math**: Grade 4, 4.4
- **Number theory (phi)**: Year 1 University
- **Optics (phi)**: Year 3 University
- **Padovan sequence**: Grade 8, 5.3; university, Year 1
- **Patterns**: Grade 1, 4.1
- **Phi**: Grade 3, 4.3; Grade 9, 6.1; throughout
- **Phi addition**: Grade 3, 4.3; Grade 9, 6.1
- **Phi algebra**: Grade 9, 6.1; university, Year 1
- **Phi calculus**: Grade 11, 6.3; university, Year 1
- **Phi chemistry**: Grade 12, 6.4
- **Phi dynamics**: Grade 11, 6.3
- **Phi geometry**: Grade 3, 4.3; Grade 10, 6.2
- **Phi-harmonic integration**: Grade 12, 6.4; university, Year 4
- **Phi statistics**: Grade 12, 6.4; Year 3 University
- **Phi topology**: Year 2 University
- **Phi trigonometry**: Grade 10, 6.2
- **Plastic number**: Grade 8, 5.3; university, Year 2
- **Prerequisite map**: 9
- **Silver ratio**: Grade 6, 5.1; university, Year 1
- **Supergolden ratio**: Grade 8, 5.3; university, Year 2
- **Technology integration**: 15
- **Teacher training**: 14
- **Topology (phi)**: Year 2 University
- **Trigonometry (phi)**: Grade 10, 6.2

---

*This curriculum document provides the complete framework for teaching all 35+ mathematics systems from Grade 1 through PhD, following the guide/teacher approach that treats students as active discoverers rather than passive recipients.*

---

**End of Document 28: PHI-HARMONIC SCHOOL CURRICULUM**
