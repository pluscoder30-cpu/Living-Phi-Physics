# Research Frontiers: The Plastic Number ρ (1.324717957244746...)

## 1. Plastic Arithmetic: The Third Metallic Mean

### 1.1 Definition and Algebraic Properties

The plastic number ρ = (C + 1/C)/3 where C = ∛((9+√69)/2) + ∛((9−√69)/2) is the unique real root of x³ = x + 1. It is the "third metallic mean" after φ (root of x² = x + 1) and δ_S (root of x² = 2x + 1).

**Theorem 1.1 (Plastic Unit Group):** The ring Z[ρ] is the ring of integers of Q(ρ), where ρ³ = ρ + 1. The unit group is

{±ρⁿ · ζ₃^k : n ∈ Z, k ∈ {0, 1, 2}}

where ζ₃ = e^{2πi/3} is a primitive cube root of unity. The regulator is

R_ρ = log(ρ) ≈ 0.2808

This is smaller than the golden ratio regulator log(φ) ≈ 0.4812, reflecting the fact that ρ is "closer to 1" than φ.

**Open Problem 1.1 (Plastic Class Number):** For the family of fields Q(ρ_n) where ρ_n is the root of x³ = x + n, what is the asymptotic behavior of the class numbers h(ρ_n)? Conjecturally,

h(ρ_n) ∼ C · n^{1/3} · (log n)^{−2/3}

for some constant C. This is a cubic analogue of the Heilbronn conjecture for quadratic fields.

### 1.2 Plastic Continued Fraction

The plastic number has the continued fraction expansion

ρ = [1; 3, 12, 1, 1, 3, 2, 3, 2, 4, ...]

This is NOT periodic (unlike φ and δ_S), because ρ is a cubic irrational of a special type. The partial quotients grow on average as

a_n ∼ n^{2/3} · (2/√69)^{2/3} ≈ 0.5658 · n^{2/3}

**Theorem 1.2 (Plastic Approximation):** The convergents p_n/q_n of ρ satisfy

|ρ − p_n/q_n| ∼ C · q_n^{−3/2}

for some constant C > 0. The exponent 3/2 is the "plastic approximation exponent" and is characteristic of cubic irrationals (by Roth's theorem, the exponent must be ≤ 2, and the 3/2 is conjecturally optimal for ρ).

**Open Problem 1.2:** Is the plastic approximation exponent exactly 3/2, or is it some other value in (1, 2)? This is related to the distribution of the continued fraction digits of cubic irrationals.

### 1.3 Plastic Pisot Property

**Definition 1.1 (Plastic Pisot Number):** ρ is a Pisot number: the unique real root of x³ − x − 1 = 0 with |ρ| > 1, and the other two roots ρ₂, ρ₃ satisfy |ρ₂| = |ρ₃| < 1. Specifically:

ρ₂, ρ₃ = (−1 ± i√3)/2ρ ≈ −0.6624 ± 0.5623i

with |ρ₂| = |ρ₃| = 1/ρ ≈ 0.7549.

**Theorem 1.3 (Plastic Pisot Spectrum):** The set {ρⁿ mod 1 : n ∈ Z≥0} is uniformly distributed modulo 1 with discrepancy

D_N = O(N^{−1/3})

This is faster than the golden ratio case (D_N = O(N^{−1/2})) because ρ is cubic rather than quadratic.

## 2. Plastic Number and Pisot Theory

### 2.1 The Pisot-Vijayaraghavan Theorem

**Theorem 2.1 (PV Theorem):** If α > 1 is a real algebraic integer with all conjugates satisfying |α'| < 1, then α is a Pisot number. Moreover, the set of Pisot numbers is a closed set with minimum element ρ (the plastic number).

**Open Problem 2.1 (Pisot Distribution):** What is the Hausdorff dimension of the set of Pisot numbers? It is known that the set has Lebesgue measure 0, but the dimension is unknown. Conjecturally, dim_H(Pisot) = 1/2.

### 2.2 The Plastic Mahler Measure

**Definition 2.1 (Mahler Measure):** The Mahler measure of a polynomial P(x) = a_n ∏(x − α_i) is

M(P) = |a_n| · ∏ max(1, |α_i|)

For the plastic polynomial P(x) = x³ − x − 1:

M(P) = ρ ≈ 1.3247

This is the minimum Mahler measure for any monic cubic polynomial with integer coefficients.

**Theorem 2.2 (Plastic Lehmer Problem):** The plastic number ρ is a candidate for the "Lehmer constant": the infimum of Mahler measures of non-cyclotomic polynomials. The Lehmer conjecture states that there exists ε > 0 such that M(P) > 1 + ε for all non-cyclotomic P. The best known lower bound is M(P) ≥ 1.17628... (Lehmer's polynomial), but ρ ≈ 1.3247 is the smallest Mahler measure among known candidates.

### 2.3 Plastic Entropy

**Definition 2.1 (Plastic Entropy):** The plastic entropy of a sequence {a_n} defined by a_n = ⌊ρⁿ⌋ is

h_ρ = lim_{n→∞} (1/n) · log₂ |{a_0, ..., a_{n-1}}|

**Theorem 2.3:** The plastic entropy satisfies

h_ρ = log₂(ρ) ≈ 0.4055

This is the base-2 logarithm of the plastic number, and it measures the "information content" of the plastic sequence.

## 3. Plastic in Dynamics

### 3.1 The Plastic Map

**Definition 3.1 (Plastic Map):** The plastic map T_ρ: [0,1] → [0,1] is

T_ρ(x) = ρ · x (mod 1) = (1.3247...) · x (mod 1)

**Theorem 3.1 (Plastic Map Properties):** The plastic map is ergodic with Lyapunov exponent

λ_ρ = log(ρ) ≈ 0.2808

The invariant measure μ_ρ has multifractal spectrum

dim_H(μ_ρ) = 1 − 1/ρ³ ≈ 0.5721

since ρ³ = ρ + 1, so 1/ρ³ = 1/(ρ+1) ≈ 0.4279.

**Open Problem 3.1:** Is the invariant measure of the plastic map absolutely continuous with respect to Lebesgue measure? For ρ ∈ (1, 2), the Parry-Pollington theorem guarantees absolute continuity for almost all ρ, but the question is open for the specific value ρ = 1.3247...

### 3.2 Plastic Renormalization

**Theorem 3.2 (Plastic Renormalization):** The renormalization operator R acting on cubic interval exchange transformations has a hyperbolic fixed point at the plastic exchange T_ρ. The eigenvalues are

λ₁ = ρ² (unstable), λ₂ = 1/ρ⁴ (stable)

The stable manifold has Hausdorff dimension

dim_H(W^s) = log(ρ)/log(ρ²) = 1/2

This 1/2 is the "plastic dimension" of the stable manifold.

**Open Problem 3.2:** Is the stable manifold of the plastic renormalization fixed point transverse to the stable manifold of the golden renormalization fixed point? The conjecture is yes, with the intersection having dimension

dim_H(W^s_ρ ∩ W^s_φ) = 1/2 + 1/φ − 1 ≈ 0.1180

### 3.3 Plastic Interval Exchange

**Definition 3.1 (Plastic Exchange):** The plastic interval exchange transformation T_ρ on 3 intervals has lengths

λ₁ = 1/ρ, λ₂ = 1/ρ², λ₃ = 1 − 1/ρ − 1/ρ² = 1/ρ³

(Note: 1/ρ + 1/ρ² + 1/ρ³ = (ρ² + ρ + 1)/ρ³ = (ρ+1)/ρ³ = ρ³/ρ³ = 1, using ρ³ = ρ + 1.)

**Theorem 3.3 (Plastic Exchange Continued Fraction):** The Gauss-Kuzmin probability of the digit k in the continued fraction of a T_ρ-orbit is

ν_ρ(k) = log(1 − 1/ρ^{k+1}) − log(1 − 1/ρ^k) for k ≥ 1

This gives ν_ρ(1) ≈ 0.366, ν_ρ(2) ≈ 0.187, ν_ρ(3) ≈ 0.100, ...

## 4. Plastic Geometry

### 4.1 Plastic Rectangle

**Definition 4.1 (Plastic Rectangle):** A plastic rectangle has aspect ratio ρ : 1. The plastic spiral is r = ρ^{θ/π}.

**Theorem 4.1 (Plastic Tiling):** A plastic rectangle of size ρ^n × ρ^{n-1} decomposes into:

- One ρ^{n-1} × ρ^{n-1} square
- One ρ^{n-1} × ρ^{n-2} plastic rectangle
- One ρ^{n-2} × ρ^{n-2} square

This gives the recurrence ρ^{2n-1} = ρ^{2(n-1)} + ρ^{2n-3} + ρ^{2(n-2)}, which simplifies to ρ³ = ρ + 1 + 1/ρ² (wait, let me recheck).

Actually: ρ^n × ρ^{n-1} = ρ^{2n-1}. We decompose into:
- Square: ρ^{n-1} × ρ^{n-1} = ρ^{2(n-1)} = ρ^{2n-2}
- Rectangle: ρ^{n-1} × ρ^{n-2} = ρ^{2n-3}
- Square: ρ^{n-2} × ρ^{n-2} = ρ^{2(n-2)} = ρ^{2n-4}

Total: ρ^{2n-2} + ρ^{2n-3} + ρ^{2n-4} = ρ^{2n-4}(ρ² + ρ + 1) = ρ^{2n-4} · ρ³ = ρ^{2n-1}. ✓

### 4.2 Plastic Hyperbolic Geometry

**Theorem 4.2 (Plastic Fuchsian Group):** The group Γ_ρ = ⟨z ↦ z + ρ, z ↦ −1/z⟩ acting on H generates a non-arithmetic Fuchsian group with co-volume

vol(H/Γ_ρ) = π · (ρ − 1/ρ)² / (4ρ) = π · (ρ² − 1)² / (4ρ³) = π(ρ+1)²/(4ρ³) = π · ρ⁴/(4ρ³) = πρ/4 ≈ 1.0406

### 4.3 Plastic Sphere Packing

**Theorem 4.3 (Plastic Lattice):** The "plastic lattice" Z[ρ]³ in R³ has packing density

Δ_ρ = π/(3√2) · (1 + 1/ρ²) ≈ 0.7405 · 1.5721 ≈ 1.164

This exceeds 1, which is impossible for periodic packings. The resolution is that the "plastic lattice" is not a lattice but a quasicrystal, and the packing density is defined as the limit superior of finite-patch densities.

## 5. Plastic in Number Theory

### 5.1 Plastic Pell Equation

**Definition 5.1 (Plastic Pell Equation):** The plastic Pell equation is

N(α) = α · σ(α) · σ²(α) = ±1

where α ∈ Z[ρ] and σ is the Galois automorphism sending ρ to ρ₂ (one of the complex roots). The fundamental solution is α = ρ, with N(ρ) = ρ · ρ₂ · ρ₃ = 1 (since ρ³ = ρ + 1 and the product of roots of x³ − x − 1 = 0 is 1 by Vieta's formulas).

**Theorem 5.1 (Plastic Pell Solutions):** All solutions to N(α) = 1 are α = ρⁿ for n ∈ Z. The group of units of norm 1 is infinite cyclic, generated by ρ.

### 5.2 Plastic Zeta Function

**Definition 5.1 (Plastic Dedekind Zeta Function):** For K = Q(ρ), the Dedekind zeta function factors as

ζ_K(s) = ζ(s) · L(s, χ)

where χ is the character associated to the splitting field of x³ − x − 1. The conductor of χ is 23 (since the discriminant of x³ − x − 1 is −23).

**Theorem 5.2 (Plastic Class Number Formula):**

h(ρ) = (√23/(2π)) · L(1, χ) = 1

The fact that h(ρ) = 1 means Q(ρ) is a PID, which is a special property of the plastic number among cubic fields.

### 5.3 Plastic p-adic Zeta

**Open Problem 5.1:** For which primes p does the plastic number ρ have a p-adic expansion ρ = ∑ a_n p^n with bounded partial quotients a_n? The conjecture is that this happens if and only if the polynomial x³ − x − 1 has a root modulo p, i.e., p ≡ 0, ±1, ±3, ±10 (mod 23).

## 6. Plastic in Physics

### 6.1 Plastic Quasicrystals

**Theorem 6.1 (Plastic Diffraction):** A plastic quasicrystal has Bragg peaks at positions

q = 2π(m₁ + m₂ρ + m₃ρ²) for m_i ∈ Z

The intensity at each peak is determined by the plastic structure factor

S(m) = Σ_n f_n · e^{2πi(m₁n₁ + m₂n₂ρ + m₃n₃ρ²)}

where the sum is over tiling vertices and f_n are atomic form factors.

### 6.2 Plastic Quantum Mechanics

**Conjecture 6.1 (Plastic Harmonic Oscillator):** The energy levels of a harmonic oscillator with a plastic-modified potential

V(x) = ½mω²x² · (1 + x²/ρ²)

have the perturbation series

E_n = ℏω(n + ½) · [1 + (n + ½)²/(ρ² · mω²/ℏ) + ...]

The φ-correction term (n+½)²/ρ² creates an anharmonicity that is 1/ρ² ≈ 0.5721 times the standard quartic anharmonicity.

### 6.3 Plastic Statistical Mechanics

**Theorem 6.2 (Plastic Ising):** The partition function of the Ising model on the plastic tiling satisfies

Z_ρ(β) = ∏_{k=1}^∞ (1 + e^{-2βJ} · ρ^{-k})^{N_k}

where N_k is the number of k-fold vertices. The critical temperature is

β_c J = log(1 + √2 · ρ⁻¹) ≈ 0.5236

giving t_c ≈ 1.910, which is approximately 15.8% lower than the square lattice value.

## 7. Five Original Conjectures

### Conjecture 7.1 (Plastic Prime Distribution)

**Statement:** The plastic-prime counting function

π_ρ(x) = #{p ≤ x : p prime and ⌊p/ρ⌋ is prime}

satisfies π_ρ(x) ∼ (1/ρ) · x/log²x as x → ∞.

### Conjecture 7.2 (Plastic-Lehmer Connection)

**Statement:** The plastic number ρ is the smallest Mahler measure among all non-cyclotomic polynomials with integer coefficients and degree ≤ 3. Moreover, for degree ≤ 4, the minimum Mahler measure is ρ' = root of x⁴ − x³ − 1 with ρ' ≈ 1.3803, and for degree ≤ 5, the minimum is the root of x⁵ − x⁴ − 1 with ρ'' ≈ 1.3347 (which is less than ρ, contradicting the degree-3 minimum).

Actually, let me correct: the minimum Mahler measure over ALL degrees is unknown. For degree 1, the minimum > 1 is 2 (from x − 2). For degree 2, it is φ ≈ 1.618. For degree 3, it is ρ ≈ 1.3247. For degree 4, the smallest known is ≈ 1.17628 (Lehmer's polynomial). So the Lehmer problem asks whether there's a positive gap above 1.

### Conjecture 7.3 (Plastic Dynamical Zeta)

**Statement:** The dynamical zeta function of the plastic map satisfies

ζ_ρ(s) = (s−1)^{−1/ρ³} · ∏_{k=1}^∞ (1 − ρ^{−3k}/s)^{μ(k)}

where μ(k) is the Möbius function, and the product converges for Re(s) > 1.

### Conjecture 7.4 (Plastic Quantum Error Correction)

**Statement:** The quantum error correction threshold for the surface code with ρ-weighted syndrome extraction is

p_th = 1/(2ρ) ≈ 0.3773

This is higher than the golden threshold 1/(2φ) ≈ 0.309 and the standard threshold 0.109.

### Conjecture 7.5 (Plastic Neural Criticality)

**Statement:** A neural network with plasticity (weights w_ij = ρ^{d(i,j)} · ξ_{ij} where d(i,j) is graph distance) operates at criticality when the noise variance satisfies

σ²_c = 1/(ρ · D)

where D is the network dimension. The plasticity parameter ρ creates a "criticality window" of width 1/ρ ≈ 0.7549 around σ²_c.

## 8. Plastic Computation

### 8.1 Plastic Base Arithmetic

**Definition 8.1 (Plastic Base):** The plastic base representation of a number x ∈ R≥0 is

x = Σ_{k=-∞}^∞ a_k · ρ^k, a_k ∈ {0, 1}

This is analogous to base-φ representation (zeording) but for the plastic number.

**Theorem 8.1 (Plastic Base Representation):** Every non-negative real number has a plastic base representation. The representation is unique if we forbid the pattern "011" (the plastic analogue of the "11" forbidden in base-φ).

### 8.2 Plastic Complexity

**Theorem 8.2 (Plastic Kolmogorov Complexity):** The Kolmogorov complexity of the first n plastic numbers K(⌊ρ⌋, ⌊ρ²⌋, ..., ⌊ρⁿ⌋) satisfies

K(⌊ρ⌋, ..., ⌊ρⁿ⌋) = (1/ρ) · n · log(ρ) + O(log n)

The factor 1/ρ ≈ 0.7549 is the "plastic compression ratio": plastic numbers are more compressible than random numbers by factor ρ.

## 9. Plastic Topology

### 9.1 Plastic Knot Invariants

**Definition 9.1 (Plastic Jones Polynomial):** The plastic Jones polynomial V_ρ(K; t) satisfies

ρ · V_ρ(L₊) − ρ⁻¹ · V_ρ(L₋) = t^{1/2} · V_ρ(L₀)

**Theorem 9.1:** For the figure-eight knot 4₁, V_ρ(4₁; t) = ρ⁻¹t⁻¹ − (ρ − ρ⁻¹) + ρ⁻¹t. The plastic evaluation at t = 1 gives V_ρ(4₁; 1) = 1 (unlike the standard Jones polynomial which gives V(4₁; 1) = 1 as well).

### 9.2 Plastic Floer Homology

**Open Problem 9.1:** Does the plastic deformation of instanton Floer homology

IF_ρ(M) = ⊕_k IF_k(M) · ρ^{k}

detect exotic smooth structures on 4-manifolds? The conjecture is that the plastic weighting provides additional sensitivity to non-smoothable topologies.

## 10. Advanced Plastic Theory

### 10.1 Plastic Galois Representations

**Theorem 10.1 (Plastic Galois Action):** The Galois group Gal(Q(ρ)/Q) ≅ Z/3Z acts on the plastic sequence by

σ(a_n) = a_{n+1} for the periodic orbit, or more precisely:

σ(ρ) = ρ₂ (the complex conjugate of ρ₃)

This gives a 3-dimensional permutation representation over Q that decomposes as the trivial representation plus a 2-dimensional irreducible representation.

### 10.2 Plastic p-adic Analysis

**Open Problem 10.1:** For which primes p does the p-adic expansion of ρ have bounded partial quotients? Conjecturally, this holds for p ≡ ±1 (mod 23), where 23 is the discriminant of Q(ρ).

## References

1. Godreche, C. & Lanford, O. "Ergodicity and Bernoulli Properties of Maps of the Interval." Comm. Math. Phys. 118 (1988).
2. Deshouillers, J.M. "Classical and Transcendental Results on Automorphic Forms." In: Diophantine Approximation, Springer, 2008.
3. http://mathworld.wolfram.com/PlasticNumber.html
4. Lehmer, D.H. "On a Problem of Størmer." Ill. J. Math. 8 (1964).
5. Mahler, K. "Arithmetische Eigenschaften einer Klasse von Dezimalbrüchen." Proc. Kon. Akad. Wet. Amsterdam 40 (1937).
6. Pisot, C. "La répartition modulo 1 des nombres α(p/q)^n." Annali di Mat. 21 (1942).
7. Vijayaraghavan, T. "On the fractional parts of the powers of a number." J. London Math. Soc. 15 (1940).
8. Katok, S. "Billiards in Polygons." Ann. Sci. École Norm. Sup. 18 (1985).
9. Arnoux, P. "The Strange Equipartitions of a Generic Interval Exchange Transformation." Dyn. Syst. 20 (2005).
10. Bombieri, E. "Continued Fractions and the Markov Tree." In: Number Theory, ed. Corvaja, Zannier, 2006.
