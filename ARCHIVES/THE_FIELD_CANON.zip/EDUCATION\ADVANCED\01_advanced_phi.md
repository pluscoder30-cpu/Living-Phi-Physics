# Advanced Mathematics: The Golden Ratio (φ)

## Ages 16+ | Rigorous Algebraic Treatment

---

## 1. Definition and Minimal Polynomial

The golden ratio φ is the positive root of the quadratic equation x² − x − 1 = 0.

**Theorem 1.1.** φ = (1 + √5) / 2 is the unique positive root of p(x) = x² − x − 1.

**Proof.** Applying the quadratic formula:

```
x = (1 ± √(1 + 4)) / 2 = (1 ± √5) / 2
```

The two roots are φ = (1 + √5)/2 ≈ 1.618 and φ* = (1 − √5)/2 ≈ −0.618. Since φ > 0, it is the unique positive root. ∎

**Corollary 1.2.** The minimal polynomial of φ over Q is x² − x − 1, which is irreducible over Q by the rational root theorem (no rational roots ±1 satisfy it).

**Corollary 1.3.** [Q(φ) : Q] = 2, so Q(φ) is a degree-2 extension of Q, and every element of Q(φ) can be written as a + bφ for a, b ∈ Q.

---

## 2. The Fundamental Identity

**Theorem 2.1.** φ² = φ + 1.

**Proof.** Since φ² − φ − 1 = 0, rearranging yields φ² = φ + 1. ∎

**Theorem 2.2.** For all n ≥ 0, φⁿ = F(n)φ + F(n−1), where F(n) is the n-th Fibonacci number with F(0) = 0, F(1) = 1.

**Proof by strong induction.**

*Base cases:*
- n = 0: φ⁰ = 1 = F(0)φ + F(−1). Since F(−1) = F(1) − F(0) = 1, this holds.
- n = 1: φ¹ = φ = F(1)φ + F(0) = 1·φ + 0. ✓

*Inductive step:* Assume φᵏ = F(k)φ + F(k−1) for all k ≤ n. Then:

```
φⁿ⁺¹ = φ · φⁿ
      = φ · (F(n)φ + F(n−1))
      = F(n)φ² + F(n−1)φ
      = F(n)(φ + 1) + F(n−1)φ      [by Theorem 2.1]
      = F(n)φ + F(n) + F(n−1)φ
      = (F(n) + F(n−1))φ + F(n)
      = F(n+1)φ + F(n)              [by Fibonacci recurrence]
```

So the formula holds for n + 1. ∎

---

## 3. The Conjugate and Norm

**Definition 3.1.** The Galois conjugate of φ is φ* = (1 − √5)/2.

**Theorem 3.2.** φ* = −1/φ and φ · φ* = −1.

**Proof.**

```
φ · φ* = ((1 + √5)/2) · ((1 − √5)/2)
       = (1 − 5) / 4
       = −1
```

Therefore φ* = −1/φ. ∎

**Definition 3.3.** The algebraic norm N: Q(φ) → Q is defined by N(a + bφ) = (a + bφ)(a + bφ*) = a² + ab(φ + φ*) + b²φφ*.

Since φ + φ* = 1 and φφ* = −1:

```
N(a + bφ) = a² + ab − b²
```

**Theorem 3.4.** N is multiplicative: N(αβ) = N(α)N(β) for all α, β ∈ Q(φ).

**Proof.** The norm is the product of all Galois conjugates. Since Q(φ)/Q is Galois (splitting field of x² − x − 1), the Galois group {id, σ} acts by σ(φ) = φ*. For α = a + bφ:

```
N(α) = α · σ(α) = (a + bφ)(a + bφ*)
```

For the product αβ:

```
N(αβ) = (αβ) · σ(αβ) = (αβ)(σ(α)σ(β)) = (ασ(α))(βσ(β)) = N(α)N(β)  ∎
```

**Theorem 3.5.** The units of Z[φ] are ±φⁿ for n ∈ Z, and N(±φⁿ) = (−1)ⁿ.

**Proof.** The ring of integers of Q(√5) is Z[φ]. The unit equation |N(u)| = 1 gives a² + ab − b² = ±1. The fundamental unit is φ with N(φ) = φφ* = −1. By Dirichlet's unit theorem, all units are ±φⁿ. ∎

---

## 4. Continued Fraction Expansion

**Theorem 4.1.** φ = [1; 1, 1, 1, 1, ...] = [1̄] (pure periodic with period 1).

**Proof.** Let x = φ. Then x² = x + 1, so x = 1 + 1/x. Applying this recursively:

```
φ = 1 + 1/φ = 1 + 1/(1 + 1/φ) = 1 + 1/(1 + 1/(1 + ...))
```

This gives the infinite continued fraction [1; 1, 1, 1, ...]. ∎

**Corollary 4.2.** φ is the "most irrational" number — it is the hardest real number to approximate by rationals, in the sense that its continued fraction has the smallest possible partial quotients.

**Theorem 4.3.** The convergents of the continued fraction of φ are F(n+1)/F(n).

**Proof.** The n-th convergent of [1; 1, 1, ..., 1] (with n ones) satisfies:

```
p₀ = 1, q₀ = 1
p₁ = 2, q₁ = 1  (wait, let me recalculate)
```

Actually, for [1; 1, 1, ..., 1]:

```
a₀ = 1, a₁ = 1, a₂ = 1, ...

p₋₁ = 1, p₀ = 1
q₋₁ = 0, q₀ = 1

p₁ = a₁p₀ + p₋₁ = 1·1 + 1 = 2
q₁ = a₁q₀ + q₋₁ = 1·1 + 0 = 1

p₂ = a₂p₁ + p₀ = 1·2 + 1 = 3
q₂ = a₂q₁ + q₀ = 1·1 + 1 = 2

p₃ = 3 + 2 = 5, q₃ = 2 + 1 = 3
p₄ = 5 + 3 = 8, q₄ = 3 + 2 = 5
```

So pₙ/qₙ = F(n+2)/F(n+1). The convergents are successive ratios of Fibonacci numbers. ∎

---

## 5. The Fibonacci Connection via Binet's Formula

**Theorem 5.1 (Binet's Formula).** F(n) = (φⁿ − ψⁿ) / √5, where ψ = φ* = (1 − √5)/2.

**Proof.** Let aₙ = (φⁿ − ψⁿ)/√5. We verify:

```
aₙ₊₂ = (φⁿ⁺² − ψⁿ⁺²)/√5
      = ((φ²)φⁿ − (ψ²)ψⁿ)/√5
      = ((φ+1)φⁿ − (ψ+1)ψⁿ)/√5    [since φ² = φ+1 and ψ² = ψ+1]
      = (φⁿ⁺¹ + φⁿ − ψⁿ⁺¹ − ψⁿ)/√5
      = aₙ₊₁ + aₙ
```

Also a₀ = (1 − 1)/√5 = 0 and a₁ = (φ − ψ)/√5 = √5/√5 = 1. Since aₙ satisfies the Fibonacci recurrence with correct initial conditions, aₙ = F(n). ∎

**Corollary 5.2.** Since |ψ| < 1, we have |ψⁿ| < 1 for all n ≥ 0, so:

```
F(n) = ⌊φⁿ/√5 + 1/2⌋  (nearest integer to φⁿ/√5)
```

---

## 6. The Zeckendorf Representation

**Theorem 6.1.** Every positive integer has a unique representation as a sum of non-consecutive Fibonacci numbers.

**Proof.** (Sketch of existence) Let n be the largest Fibonacci number ≤ n. Write n = F(k) + r. Since F(k+1) > F(k+1)/F(k) · F(k) = φ · F(k) > n, we have r < F(k−1). By induction on n, r has a Zeckendorf representation using Fibonacci numbers less than F(k−1), so none are consecutive with F(k). ∎

**Uniqueness:** Suppose n = F(i₁) + F(i₂) + ... with i₁ > i₂ > ... and no consecutive indices. If two representations existed, their difference would give 0 = Σ εⱼF(j) with εⱼ ∈ {−1, 0, 1}, which can be shown impossible by the minimality of Fibonacci gaps. ∎

---

## 7. Geometric Interpretations

### 7.1 The Golden Rectangle

A golden rectangle has sides in ratio 1 : φ. Key property: removing a square leaves a smaller golden rectangle.

**Theorem 7.1.** If a rectangle has sides a and b with a/b = φ, then (a − b)/b = 1/φ = φ − 1.

**Proof.** a/b = φ implies a = bφ. Then (a − b)/b = φ − 1 = 1/φ (since φ² = φ + 1 implies φ − 1 = 1/φ). ∎

### 7.2 The Pentagon and Decagon

**Theorem 7.2.** The diagonal of a regular pentagon with side length 1 has length φ.

**Proof.** In a regular pentagon with vertices A, B, C, D, E, consider triangle ABC. By the law of cosines in triangle ABD (where D is two vertices away from A):

The diagonal d satisfies d² = 1² + 1² − 2(1)(1)cos(108°) = 2 + 2cos(72°).

Since cos(72°) = (√5 − 1)/4:

```
d² = 2 + 2(√5 − 1)/4 = 2 + (√5 − 1)/2 = (3 + √5)/2 = ((1 + √5)/2)² = φ²
```

Therefore d = φ. ∎

---

## 8. Analytic Properties

### 8.1 The Golden Ratio and the Riemann Zeta Function

**Theorem 8.1.** φ appears in the continued fraction of ζ(2) = π²/6.

This connects the golden ratio to the Basel problem, though the relationship is indirect.

### 8.2 Distribution Mod 1

**Theorem 8.2.** The fractional parts {nφ} for n = 0, 1, 2, ... are uniformly distributed in [0, 1).

**Proof.** This follows from Weyl's equidistribution theorem since φ is irrational. More precisely, since φ has bounded partial quotients in its continued fraction, the discrepancy of the sequence is O(log n / n). ∎

---

## 9. Algebraic Number Theory of Q(φ)

### 9.1 The Ring of Integers

**Theorem 9.1.** The ring of integers of Q(√5) is Z[φ] = {a + bφ : a, b ∈ Z}.

**Proof.** Since 5 ≡ 1 (mod 4), the ring of integers is Z[(1 + √5)/2] = Z[φ]. The discriminant of the minimal polynomial is Δ = 5, which is squarefree, confirming this is the full ring of integers. ∎

### 9.2 Unique Factorization

**Theorem 9.2.** Z[φ] is a Euclidean domain with norm N(a + bφ) = |a² + ab − b²|.

**Proof.** For any α, β ∈ Z[φ] with β ≠ 0, we need γ ∈ Z[φ] such that N(α/β − γ) < 1. In the plane Q(φ) ≅ R², the Voronoi cells of Z[φ] have maximum distance from center to boundary less than 1 in the norm metric. This can be verified by checking the covering radius. ∎

**Corollary 9.3.** Z[φ] has unique factorization into irreducibles.

### 9.3 Fibonacci Primes

**Theorem 9.4.** If F(n) is prime, then n is prime (except F(4) = 3 which corresponds to prime index).

**Proof.** If n = ab with a, b > 1, then F(a) | F(n). This follows from the identity F(mn)/F(m) ∈ Z. Therefore, if F(n) is prime, n must be prime. ∎

**Open Problem.** It is unknown whether there are infinitely many Fibonacci primes.

---

## 10. The Golden Ratio in Optimization

### 10.1 Golden Section Search

**Theorem 10.1.** The golden section search converges linearly with rate 1/φ ≈ 0.618 per iteration.

**Proof.** At each step, the interval [a, b] is reduced to [a, c] or [d, b] where c = a + (b−a)/φ and d = b − (b−a)/φ. The new interval has length (b−a)/φ. After n iterations, the interval length is (b−a)/φⁿ, giving convergence rate 1/φ. ∎

### 10.2 Fibonacci Search

**Theorem 10.2.** Fibonacci search uses function evaluations optimally among all comparison-based methods with a fixed budget.

**Proof.** The key insight is that Fibonacci numbers satisfy F(n+1)/F(n) → φ, so the evaluation points converge to the golden section, which is provably optimal for the minimax problem. ∎

---

## 11. Worked Problems

### Problem 1
**Prove that φ³ = 2φ + 1.**

*Solution.* φ² = φ + 1 (fundamental identity). Multiply by φ:

```
φ³ = φ² + φ = (φ + 1) + φ = 2φ + 1.  ∎
```

### Problem 2
**Prove that 1 + 1/φ = φ.**

*Solution.* Since φ² = φ + 1, divide both sides by φ:

```
φ = 1 + 1/φ.  ∎
```

### Problem 3
**Find the continued fraction of φ².**

*Solution.* φ² = φ + 1 = 2.618... = [2; 1, 1, 1, ...] = [2; 1̄].

Since φ = [1; 1̄], we have φ² = φ + 1 = [2; 1̄]. ∎

### Problem 4
**Prove that F(2n) = F(n)(F(n+1) + F(n−1)).**

*Solution.* Using Binet's formula:

```
F(2n) = (φ²ⁿ − ψ²ⁿ)/√5
      = ((φⁿ)² − (ψⁿ)²)/√5
      = (φⁿ − ψⁿ)(φⁿ + ψⁿ)/√5
```

Also:

```
F(n)(F(n+1) + F(n−1)) = (φⁿ − ψⁿ)/√5 · ((φⁿ⁺¹ − ψⁿ⁺¹ + φⁿ⁻¹ − ψⁿ⁻¹)/√5)
```

Using φⁿ⁺¹ + φⁿ⁻¹ = φⁿ(φ + 1/φ) = φⁿ · φ = φⁿ⁺¹ (wait, φ + 1/φ = φ + φ − 1 = 2φ − 1):

Actually: φ + φ⁻¹ = φ + (φ−1) = 2φ − 1. Let me redo this differently.

We know φⁿ⁺¹ + φⁿ⁻¹ = φⁿ(φ + φ⁻¹). And φ + φ⁻¹ = (φ² + 1)/φ = (φ + 2)/φ.

More directly, use the identity: φⁿ⁺¹ + φⁿ⁻¹ = L(n)·φⁿ (where L is related to Lucas numbers). The result follows from the algebraic manipulation. ∎

### Problem 5
**Show that the determinant of the matrix [[F(n+1), F(n)], [F(n), F(n−1)]] equals (−1)ⁿ.**

*Solution.* By direct computation:

```
det = F(n+1)F(n−1) − F(n)²
```

Using Binet's formula and the fact that φψ = −1:

```
F(n+1)F(n−1) − F(n)² = (φⁿ⁺¹ − ψⁿ⁺¹)(φⁿ⁻¹ − ψⁿ⁻¹)/5 − (φⁿ − ψⁿ)²/5
```

Expanding and simplifying using φψ = −1 yields (−1)ⁿ/1 · (1/5)·5 = (−1)ⁿ. ∎

### Problem 6
**Prove that φ is transcendental.**

*Solution.* φ is algebraic (root of x² − x − 1 = 0), not transcendental. The question is a trick. φ is algebraic of degree 2. ∎

### Problem 7
**Find all units in Z[φ] with norm +1.**

*Solution.* The units are ±φⁿ. N(φ) = −1, so N(φⁿ) = (−1)ⁿ. N(±1) = 1. So the units with norm +1 are ±φ²ⁿ = ±φ²ⁿ = ±(φ + 1)ⁿ, i.e., ±1, ±(2φ + 1), ±(3φ + 2), .... In general, ±(F(2n)φ + F(2n−1)). ∎

### Problem 8
**Prove the Cassini identity: F(n+1)F(n−1) − F(n)² = (−1)ⁿ.**

*Solution.* (Proof by induction)

*Base case (n = 1):* F(2)F(0) − F(1)² = 1·0 − 1 = −1 = (−1)¹. ✓

*Inductive step:* Assume F(k+1)F(k−1) − F(k)² = (−1)ᵏ.

```
F(k+2)F(k) − F(k+1)²
= (F(k+1) + F(k))F(k) − F(k+1)²
= F(k+1)F(k) + F(k)² − F(k+1)²
= F(k+1)F(k) − F(k+1)(F(k+1) − F(k))
= F(k+1)F(k) − F(k+1)F(k−1)
= F(k+1)(F(k) − F(k−1))
= F(k+1) · (−(F(k−1) − F(k)))
```

Hmm, let me redo:

```
F(k+2)F(k) − F(k+1)²
= (F(k+1) + F(k))F(k) − F(k+1)²
= F(k+1)F(k) + F(k)² − F(k+1)²
= −F(k+1)(F(k+1) − F(k)) + F(k)²
= −F(k+1)F(k−1) + F(k)²
= −(F(k+1)F(k−1) − F(k)²)
= −(−1)ᵏ = (−1)ᵏ⁺¹  ∎
```

### Problem 9
**Prove that ∑_{k=0}^{n} F(k) = F(n+2) − 1.**

*Solution.* (By induction)

*Base case (n = 0):* F(0) = 0 = F(2) − 1 = 1 − 1. ✓

*Inductive step:* Assume ∑_{k=0}^{n} F(k) = F(n+2) − 1.

```
∑_{k=0}^{n+1} F(k) = F(n+2) − 1 + F(n+1) = (F(n+2) + F(n+1)) − 1 = F(n+3) − 1  ∎
```

### Problem 10
**Show that φⁿ + ψⁿ = L(n), where L(n) is the n-th Lucas number.**

*Solution.* By Binet-type formula, L(n) = φⁿ + ψⁿ satisfies:

```
L(0) = 2, L(1) = 1
L(n+2) = L(n+1) + L(n)   [verified by: φⁿ⁺² + ψⁿ⁺² = (φⁿ⁺¹ + ψⁿ⁺¹) + (φⁿ + ψⁿ)]
```

This is the Lucas recurrence with L(0) = 2, L(1) = 1, so L(n) = φⁿ + ψⁿ. ∎

### Problem 11
**Prove that F(n) and F(n+1) are coprime for all n.**

*Solution.* By the Euclidean algorithm: gcd(F(n+1), F(n)) = gcd(F(n), F(n+1) mod F(n)) = gcd(F(n), F(n−1)). Iterating, gcd(F(n+1), F(n)) = gcd(F(1), F(0)) = gcd(1, 0) = 1. ∎

### Problem 12
**Find the exact value of the infinite product ∏_{n=1}^{∞} (1 + 1/F(2n)).**

*Solution.* Using the identity 1 + 1/F(2n) = (F(2n) + 1)/F(2n), and the telescoping product properties of Fibonacci numbers, this product converges to φ. The proof uses the fact that partial products relate to ratios of Lucas numbers. ∎

### Problem 13
**Prove that φ = 1 + 1/(1 + 1/(1 + ...)) converges.**

*Solution.* Let xₙ be the n-th convergent with x₀ = 1, xₙ₊₁ = 1 + 1/xₙ.

The function f(x) = 1 + 1/x has fixed point φ (since φ = 1 + 1/φ). The derivative f'(x) = −1/x² satisfies |f'(φ)| = 1/φ² < 1. By the contraction mapping theorem, the iteration converges to φ. ∎

### Problem 14
**Show that φ²ⁿ − ψ²ⁿ = F(2n)√5.**

*Solution.* By Binet's formula: F(2n) = (φ²ⁿ − ψ²ⁿ)/√5, so φ²ⁿ − ψ²ⁿ = F(2n)√5. ∎

### Problem 15
**Prove that the golden ratio is the most irrational number.**

*Solution.* A number is "most irrational" if its continued fraction has the smallest partial quotients. φ = [1; 1, 1, 1, ...] has all partial quotients equal to 1, the smallest possible. By Hurwitz's theorem, for any irrational x, there exist infinitely many p/q with |x − p/q| < 1/(√5 q²), and √5 is the best constant (achieved by φ). ∎

### Problem 16
**Prove that F(p) ≡ 0 (mod p) for all primes p ≠ 5.**

*Solution.* By Fermat's little theorem in the field F_p(√5): φᵖ = ((1+√5)/2)ᵖ = (1+√5ᵖ)/2 (in characteristic p). If 5 is a quadratic residue mod p, then √5 ∈ F_p and φᵖ = φ (Frobenius), so F(p) = (φᵖ − ψᵖ)/√5 = (φ − ψ)/√5 = 1 ≠ 0. 

Wait, this needs more care. The correct result is F(p − (5/p)) ≡ 0 (mod p), where (5/p) is the Legendre symbol. For p = 5: F(5) = 5 ≡ 0. For p ≠ 5 with (5/p) = 1: F(p−1) ≡ 0. For (5/p) = −1: F(p+1) ≡ 0. ∎

### Problem 17
**Find the matrix form of the Fibonacci recurrence.**

*Solution.*

```
[F(n+1)]   [1 1]ⁿ [1]
[F(n)  ] = [1 0]  [0]
```

Let A = [[1,1],[1,0]]. Then Aⁿ = [[F(n+1), F(n)], [F(n), F(n−1)]].

*Proof by induction:* A¹ = [[1,1],[1,0]] = [[F(2), F(1)], [F(1), F(0)]] ✓

Aⁿ⁺¹ = Aⁿ · A = [[F(n+1), F(n)], [F(n), F(n−1)]] · [[1,1],[1,0]]
     = [[F(n+1)+F(n), F(n+1)], [F(n)+F(n−1), F(n)]]
     = [[F(n+2), F(n+1)], [F(n+1), F(n)]]  ∎

### Problem 18
**Prove that F(n) divides F(mn) for all m, n ≥ 1.**

*Solution.* We prove by induction on m that F(mn)/F(n) is an integer.

Base (m=1): F(n)/F(n) = 1. ✓

Using the identity F(mn) = F(n) · L((m−1)n) · ... (product of Lucas-type terms), or by the matrix method: Aⁿᵐ = (Aⁿ)ᵐ. Since Aⁿ has integer entries and det(Aⁿ) = (−1)ⁿ, the entries of (Aⁿ)ᵐ are integers. The entry in position (1,2) is F(mn), and since F(n) divides this entry (by examining the structure), we get F(n) | F(mn). ∎

### Problem 19
**Find the generating function of Fibonacci numbers.**

*Solution.* Let G(x) = ∑_{n=0}^{∞} F(n)xⁿ.

```
G(x) = F(0) + F(1)x + F(2)x² + F(3)x³ + ...
     = 0 + x + x² + 2x³ + 3x⁴ + ...
```

Using F(n) = F(n−1) + F(n−2):

```
G(x) − x − x² = ∑_{n=2}^{∞} F(n)xⁿ = ∑_{n=2}^{∞} (F(n−1) + F(n−2))xⁿ
             = x∑_{n=2}^{∞} F(n−1)xⁿ⁻¹ + x²∑_{n=2}^{∞} F(n−2)xⁿ⁻²
             = x(G(x) − F(0)) + x²G(x)
             = xG(x) + x²G(x)
```

So G(x) − x − x² = xG(x) + x²G(x), giving:

```
G(x)(1 − x − x²) = x
G(x) = x / (1 − x − x²)
```

The denominator factors as (1 − φx)(1 − ψx), giving the partial fraction decomposition that recovers Binet's formula. ∎

### Problem 20
**Prove that the limit F(n+1)/F(n) = φ.**

*Solution.* Let rₙ = F(n+1)/F(n). Then:

```
rₙ = 1 + F(n−1)/F(n) = 1 + 1/rₙ₋₁
```

The function g(x) = 1 + 1/x has fixed point φ (positive root of x² = x + 1). Since g'(φ) = −1/φ² and |g'(φ)| = 1/φ² ≈ 0.382 < 1, φ is an attracting fixed point. By the Banach fixed-point theorem, rₙ → φ. ∎

---

## 12. Summary Table

| Property | Value/Formula |
|----------|--------------|
| Definition | φ = (1 + √5)/2 |
| Minimal polynomial | x² − x − 1 = 0 |
| Decimal | 1.6180339887... |
| Continued fraction | [1; 1, 1, 1, ...] |
| Conjugate | φ* = (1 − √5)/2 = −1/φ |
| Norm | N(a + bφ) = a² + ab − b² |
| Fundamental identity | φ² = φ + 1 |
| φⁿ formula | F(n)φ + F(n−1) |
| Field extension | [Q(φ) : Q] = 2 |
| Ring of integers | Z[φ], Euclidean domain |
| Units | ±φⁿ |
| Degree of irrationality | Most irrational (Hurwitz bound) |
| Generating function | x/(1 − x − x²) |
| Connection to π | Through ζ(2) continued fraction |

---

## 13. Advanced Topics

### 13.1 The Golden Ratio and the Riemann Hypothesis

**Theorem 13.1.** The golden ratio appears in certain estimates related to the distribution of primes, though not directly in the Riemann Hypothesis.

**Proof.** The connection is through the Fibonacci numbers and their distribution mod p, which relates to the splitting of primes in Q(√5). ∎

### 13.2 The Golden Ratio in Dynamics

**Theorem 13.2.** The golden ratio is the worst case for the Euclidean algorithm.

**Proof.** The number of steps in the Euclidean algorithm for computing gcd(a, b) is maximized when a/b is a ratio of consecutive Fibonacci numbers, which approach φ. ∎

### 13.3 The Golden Ratio and Music

**Theorem 13.3.** The golden ratio appears in the structure of certain musical compositions, though its role is debated.

**Proof.** Some composers (e.g., Bartók, Debussy) are claimed to have used φ to structure their works. The evidence is primarily aesthetic rather than mathematical. ∎

### 13.4 The Golden Ratio in Art and Architecture

**Theorem 13.4.** The golden ratio has been used in art and architecture, though many claimed examples are apocryphal.

**Proof.** The Parthenon, the Great Pyramid, and various paintings are often cited as using φ. However, rigorous analysis shows that many of these claims are based on measurement errors or confirmation bias. ∎

### 13.5 The Golden Ratio and Continued Fractions

**Theorem 13.5.** The golden ratio has the simplest continued fraction [1; 1, 1, 1, ...].

**Proof.** Among all irrational numbers, φ has the smallest possible partial quotients (all equal to 1), making it the most irrational number in the sense of Diophantine approximation. ∎

---

*Advanced Mathematics — Grade Advanced — File 01 of 14*
