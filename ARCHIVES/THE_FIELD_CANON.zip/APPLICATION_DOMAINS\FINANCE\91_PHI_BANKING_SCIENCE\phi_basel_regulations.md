# PHI-Basel Regulations: Golden Ratio Capital Standards

## Directory 91_PHI_BANKING_SCIENCE | File 05

---

## 1. PHI-Basel III Capital

### 1.1 PHI-Minimum Capital

```
Capital_min = max(RWA * 8%, Pillar_2) * phi^{buffer}
```

### 1.2 PHI-CET1 Ratio

```
CET1 = Common_equity / RWA * phi^{quality_multiplier}
```

### 1.3 PHI-Tier 1

```
Tier1 = CET1 + AT1 * phi^{subordination_factor}
```

### 1.4 PHI-Total Capital

```
Total = Tier1 + Tier2 * phi^{loss_absorption}
```

---

## 2. PHI-Risk-Weighted Assets

### 2.1 PHI-Credit Risk

```
RWA_credit = sum EAD * RW * phi^{maturity}
RW = f(PD, LGD) * phi^{systematic_risk}
```

### 2.2 PHI-Market Risk

```
RWA_market = VaR * multiplier * phi^{stressed_multiplier}
```

### 2.3 PHI-Operational Risk

```
RWA_op = Business_indicator * phi^{loss_multiplier}
```

### 2.4 PHI-Counterparty Credit Risk

```
RWA_CCR = replace_cost * alpha * phi^{wrong_way_risk}
```

---

## 3. PHI-Liquidity Requirements

### 3.1 PHI-LCR (Liquidity Coverage Ratio)

```
LCR = HQLA / net_outflows * phi^{outflow_assumption}
HQLA = Level1 + Level2A/phi + Level2B/phi^2
```

### 3.2 PHI-NSFR (Net Stable Funding Ratio)

```
NSFR = ASF / RSF * phi^{stability_premium}
ASF = available_stable_funding * phi^{maturity}
RSF = required_stable_funding * phi^{asset_risk}
```

### 3.3 PHI-Bill Ratio

```
Bill_ratio = short_term_debt / total_debt * phi^{-maturity_mismatch}
```

### 3.4 PHI-Commitment

```
Commitment_ratio = commitments / assets * phi^{drawdown_probability}
```

---

## 4. PHI-Leverage Ratio

### 4.1 PHI-Backup Leverage

```
Leverage = Tier1 / EAD * phi^{supplementary_buffer}
```

### 4.2 PHI-Adjusted Leverage

```
Adj_leverage = Tier1 / (exposure - derivative-exposure * phi^{-netting})
```

### 4.3 PHI-G-SIB Surcharge

```
Surcharge = systemic_importance * phi^{connectedness}
```

### 4.4 PHI-D-SIB Surcharge

```
D_SIB = domestic_importance * phi^{concentration}
```

---

## 5. PHI-Countercyclical Buffer

### 5.1 PHI-Build-Up

```
Buffer = max(0, credit_gap * phi^{credit_cycle})
```

### 5.2 PHI-Release

```
Release_speed = buffer_level * phi^{-crisis_severity}
```

### 5.3 PHI-Migration

```
Migration_buffer = buffer_home * phi^{-cross_border_ratio}
```

### 5.4 PHI-Guidance

```
Guidance = f(credit/GDP, house_price/GDP, P/E_ratio) * phi^{lead_indicator}
```

---

## 6. PHI-Resolution Planning

### 6.1 PHI-Bail-In

```
Bail_in = liabilities * phi^{-priority}
```

### 6.2 PHI-Loss Absorption

```
Loss_absorption = equity + subordinated_debt * phi^{loss_severity}
```

### 6.3 PHI-Resolution Buffer

```
Buffer = capital_requirement * phi^{resolution_multiplier}
```

### 6.4 PHI-Separation

```
Separation_threshold = complexity * phi^{-manageability}
```

---

## 7. PHI-Reporting Requirements

### 7.1 PHI-Frequency

```
Frequency = risk_level * phi^{systemic_importance}
```

### 7.2 PHI-Granularity

```
Granularity = detail_level * phi^{-data_quality}
```

### 7.3 PHI-Timeliness

```
Timeliness = report_date + delay * phi^{-urgency}
```

### 7.4 PHI-Consolidation

```
Consolidation = group_reporting * phi^{cross_border}
```

---

## 8. Summary

PHI-Basel regulations provide:
1. PHI-capital with phi-CET1 and phi-Tier1 ratios
2. PHI-RWA with phi-credit, phi-market, phi-operational risk
3. PHI-liquidity with phi-LCR and phi-NSFR
4. PHI-leverage with phi-backup and phi-G-SIB surcharges
5. PHI-countercyclical with phi-build-up and phi-release
6. PHI-resolution with phi-bail-in and phi-loss absorption
7. PHI-reporting with phi-frequency and phi-granularity

The golden ratio provides a natural framework for calibrating regulatory buffers and systemic risk surcharges.