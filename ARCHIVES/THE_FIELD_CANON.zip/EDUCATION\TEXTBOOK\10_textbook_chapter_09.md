# Chapter 9: Phi-Statistics and Phi-Geometry

## The Golden Ratio in Probability, Statistics, and Geometry

---

### Overview

The golden ratio appears in statistics and geometry in ways that go far beyond simple ratios. In statistics, the golden ratio governs certain probability distributions and sampling methods. In geometry, the golden ratio underlies Penrose tilings, the icosahedron, and many other structures.

This chapter explores these deep connections, showing that the golden ratio is not just a curiosity but a fundamental constant of mathematical structure.

---

## Lesson 9.1: The Golden Ratio in Probability

### Explanation

The golden ratio appears in several probability contexts:

**1. The Golden Ratio Search**

The golden ratio search is an optimization algorithm that uses the golden ratio to find the maximum or minimum of a function. At each step, the algorithm eliminates a fraction 1/φ ≈ 61.8% of the search space.

The efficiency of the golden ratio search is related to the fact that 1/φ = φ - 1, which means the algorithm is self-similar: each step has the same structure as the previous one.

**2. The Fibonacci Search**

The Fibonacci search is a closely related algorithm that uses Fibonacci numbers instead of the golden ratio. It is slightly less efficient than the golden ratio search but can be implemented using only integer arithmetic.

**3. Golden Ratio in Random Walks**

In a random walk on the integers, the probability of returning to the origin is related to the golden ratio. Specifically, the probability that a random walk of length n returns to the origin is approximately 1/√(nφ).

### The Golden Ratio Search Algorithm

The golden ratio search works as follows:

1. Start with an interval [a, b] of length L.
2. Place two points inside the interval at distances L/φ and L/φ² from the left endpoint.
3. Evaluate the function at both points.
4. If f(L/φ) > f(L/φ²), eliminate the left portion. The new interval is [L/φ², b].
5. If f(L/φ) < f(L/φ²), eliminate the right portion. The new interval is [a, L/φ].
6. Repeat until the interval is sufficiently small.

At each step, the interval shrinks by a factor of 1/φ ≈ 0.618. After n steps, the interval length is L × (1/φ)ⁿ.

### Worked Example 9.1.1

We want to find the maximum of f(x) = -(x - 3)² + 5 on the interval [0, 10] using golden ratio search. After one step, what is the new interval?

**Solution**: The initial interval has length 10. The two interior points are:

x₁ = 10/φ ≈ 6.18
x₂ = 10/φ² ≈ 3.82

Evaluate: f(6.18) = -(6.18 - 3)² + 5 ≈ -10.11 + 5 = -5.11
f(3.82) = -(3.82 - 3)² + 5 ≈ -0.67 + 5 = 4.33

Since f(3.82) > f(6.18), we eliminate the right portion. The new interval is [0, 6.18].

The interval has shrunk from length 10 to length 6.18, a factor of 1/φ ≈ 0.618. ✓

### Worked Example 9.1.2

After 10 steps of golden ratio search, what fraction of the original interval remains?

**Solution**: After n steps, the fraction remaining is (1/φ)ⁿ.

(1/φ)¹⁰ = (0.6180339887)¹⁰ ≈ 0.00813

So only about 0.8% of the original interval remains. The search has narrowed the range by a factor of about 123.

### Practice Problems

1. Perform 3 steps of golden ratio search on f(x) = -(x - 5)² + 10 on [0, 20].
2. After 20 steps, what fraction of the original interval remains?
3. How does golden ratio search compare to binary search?
4. Why is the golden ratio better than 1/2 for the search fraction?
5. Implement the golden ratio search algorithm in pseudocode.

### Teacher's Notes

**Computer Science Connection**: The golden ratio search is used in computer science for optimization problems where the function is expensive to evaluate. It is more efficient than binary search for continuous functions.

**Comparison**: Binary search eliminates 50% of the search space at each step. Golden ratio search eliminates about 61.8% of the search space. After n steps, binary search narrows by 2ⁿ, while golden ratio search narrows by φⁿ ≈ 1.618ⁿ. Since φ > 2, golden ratio search is actually slower per step... wait, that is not right.

Actually, binary search eliminates half the interval at each step, so after n steps the interval is L/2ⁿ. Golden ratio search eliminates (1 - 1/φ) ≈ 38.2% of the interval at each step, so after n steps the interval is L × (1/φ)ⁿ. Since 1/φ ≈ 0.618 > 0.5, golden ratio search is actually slower per step than binary search.

The advantage of golden ratio search is that it requires only one function evaluation per step (after the initial setup), while binary search requires evaluating the function at the midpoint. If function evaluations are expensive, golden ratio search can be more efficient overall.

---

## Lesson 9.2: The Golden Ratio in Geometry

### Explanation

The golden ratio appears in many geometric contexts:

**1. The Regular Pentagon**

The diagonal of a regular pentagon is φ times its side length. This is the original context in which the golden ratio was studied by the ancient Greeks.

If the side of a regular pentagon is s, the diagonal is sφ. The ratio of diagonal to side is φ.

**2. The Icosahedron**

The icosahedron is a Platonic solid with 20 triangular faces. Its geometry is intimately connected to the golden ratio. The ratio of the distance between opposite vertices to the edge length is φ.

**3. The Dodecahedron**

The dodecahedron is a Platonic solid with 12 pentagonal faces. Since each face is a regular pentagon, the golden ratio appears throughout its geometry.

**4. Penrose Tilings**

Penrose tilings are aperiodic tilings of the plane that have five-fold symmetry. They are based on the golden ratio and use two types of tiles (kites and darts, or thick and thin rhombi).

**5. The Golden Triangle**

A golden triangle is an isosceles triangle whose sides are in the golden ratio. There are two types:
- The golden gnomon: vertex angle 36°, base angles 72° (sides in ratio φ:1:φ)
- The golden triangle: vertex angle 108°, base angles 36° (sides in ratio 1:φ:1)

### The Regular Pentagon and the Golden Ratio

In a regular pentagon with side s:

- Diagonal = sφ
- Radius of circumscribed circle = sφ/2
- Area = (s²/4)√(25 + 10√5) = (s²/4)√(5(5 + 2√5))

The ratio of diagonal to side is φ, which can be proved using similar triangles.

### Penrose Tilings

Penrose tilings use two types of tiles:

**Kites and Darts**: A kite has two pairs of equal sides, with ratios related to φ. A dart is similar but with a concave angle.

**Thick and Thin Rhombi**: A thick rhombus has angles of 72° and 108°. A thin rhombus has angles of 36° and 144°. The ratio of the diagonals of each rhombus is φ.

Penrose tilings have several remarkable properties:
- They are aperiodic (they never repeat exactly)
- They have five-fold rotational symmetry
- The ratio of thick to thin tiles approaches φ
- They are self-similar: zooming in by a factor of φ produces the same pattern

### Worked Example 9.2.1

A regular pentagon has side length 10 cm. What is the length of its diagonal?

**Solution**: Diagonal = sφ = 10 × 1.6180339887 ≈ 16.18 cm.

### Worked Example 9.2.2

In a Penrose tiling using kites and darts, there are 144 kites and 89 darts. What is the ratio of kites to darts?

**Solution**: 144/89 ≈ 1.618

This is close to φ. ✓

### Practice Problems

1. A regular pentagon has side 8 cm. What is the diagonal?
2. A regular pentagon has diagonal 20 cm. What is the side?
3. Verify that the diagonal of a regular pentagon is φ times the side.
4. Draw a Penrose tiling using kites and darts.
5. Count the tiles in a Penrose tiling. Is the ratio of thick to thin tiles close to φ?

### Teacher's Notes

**Construction Activity**: Have students construct a regular pentagon using a compass and straightedge. This is a classic geometric construction that reveals the golden ratio.

**Art Connection**: Show students examples of Penrose tilings and discuss their aesthetic properties. The mathematician Roger Penrose discovered these tilings in the 1970s, but they were anticipated by Islamic artists in the 13th century.

---

## Lesson 9.3: Phi-Normal Distributions

### Explanation

A **phi-normal distribution** is a normal (bell curve) distribution whose parameters are related to the golden ratio. While the standard normal distribution has mean 0 and standard deviation 1, a phi-normal distribution might have:

- Standard deviation σ = 1/φ ≈ 0.618
- Mean μ = φ ≈ 1.618
- Or other golden-ratio-related parameters

The phi-normal distribution is not a standard statistical distribution, but it appears in certain natural phenomena where the golden ratio governs the underlying process.

### Properties of the Phi-Normal Distribution

If X is phi-normally distributed with mean μ = φ and standard deviation σ = 1/φ:

- The probability density function is: f(x) = φ/(√(2π)) × exp(-(x - φ)²/(2/φ²))
- The variance is σ² = 1/φ² = φ - 1 ≈ 0.618
- The standard deviation is σ = 1/φ ≈ 0.618
- The full width at half maximum (FWHM) is 2√(2ln2) × σ ≈ 2.355 × 0.618 ≈ 1.455

### Worked Example 9.3.1

A phi-normal distribution has mean φ and standard deviation 1/φ. What is the probability that a random variable falls within one standard deviation of the mean?

**Solution**: For any normal distribution, the probability of falling within one standard deviation of the mean is approximately 68.27%. This property is the same for phi-normal distributions as for standard normal distributions, because the probability depends only on the number of standard deviations, not on the specific values of μ and σ.

### Practice Problems

1. What is the variance of a phi-normal distribution with σ = 1/φ?
2. What is the FWHM of a phi-normal distribution with σ = 1/φ?
3. If X is phi-normally distributed with μ = φ and σ = 1/φ, what is P(φ - 1/φ < X < φ + 1/φ)?
4. How does a phi-normal distribution compare to a standard normal distribution?
5. In what contexts might a phi-normal distribution arise naturally?

### Teacher's Notes

**Statistics Connection**: The phi-normal distribution is an example of how the golden ratio can parameterize statistical distributions. While it is not a standard distribution, it illustrates the principle that the golden ratio can appear in probabilistic contexts.

**Extension**: Ask students to compute the cumulative distribution function (CDF) of the phi-normal distribution and compare it to the standard normal CDF.

---

## Lesson 9.4: Penrose Tilings in Detail

### Explanation

Penrose tilings deserve a more detailed treatment because they are one of the most beautiful applications of the golden ratio in geometry.

### Construction of Penrose Tilings

There are several ways to construct Penrose tilings:

**1. Substitution Method**

Start with a single tile (a thick rhombus). Replace it with a specific pattern of smaller tiles. Repeat indefinitely. The result is a Penrose tiling.

**2. Projection Method**

Project a slice of a 5-dimensional cubic lattice onto a 2-dimensional plane. The resulting pattern is a Penrose tiling.

**3. Matching Rules**

Place tiles one at a time, following specific matching rules that ensure the tiling is Penrose. The matching rules use arrows and colors on the edges of the tiles.

### Properties of Penrose Tilings

**Property 1: Aperiodicity**

Penrose tilings never repeat exactly. No matter how far you extend the tiling, you will never find a repeating pattern.

**Property 2: Five-fold Symmetry**

Penrose tilings have five-fold rotational symmetry. If you rotate the tiling by 72°, it looks the same.

**Property 3: Self-similarity**

Penrose tilings are self-similar. If you zoom in by a factor of φ, the pattern looks the same. This is because the substitution rules are based on the golden ratio.

**Property 4: Fibonacci Counts**

The ratio of thick to thin tiles approaches φ. If there are F(n) thin tiles, there are approximately F(n+1) thick tiles, where F(n) is the nth Fibonacci number.

### Worked Example 9.4.1

In a Penrose tiling, there are 610 thick rhombi. Approximately how many thin rhombi are there?

**Solution**: The ratio of thick to thin tiles approaches φ. So:

Number of thin tiles ≈ 610/φ ≈ 610/1.618 ≈ 377

Indeed, 610 and 377 are consecutive Fibonacci numbers (F(15) and F(14)).

### Practice Problems

1. Draw a small Penrose tiling using kites and darts.
2. Count the tiles in your tiling. Is the ratio of kites to darts close to φ?
3. Explain why Penrose tilings are aperiodic.
4. How does the self-similarity of Penrose tilings relate to the golden ratio?
5. Research: what are the matching rules for Penrose tilings?

### Teacher's Notes

**Art Activity**: Have students create Penrose tilings using colored paper. This is a beautiful art activity that also teaches mathematics.

**History**: Roger Penrose discovered Penrose tilings in 1974. However, similar patterns appear in medieval Islamic art (the Darb-i Imam shrine in Isfahan, Iran, built in 1453). This is a remarkable example of mathematical discovery ahead of its time.

---

## Lesson 9.5: The Golden Ratio in Three-Dimensional Geometry

### Explanation

The golden ratio appears in several three-dimensional geometric structures:

**1. The Icosahedron**

The icosahedron has 20 triangular faces, 30 edges, and 12 vertices. The ratio of the distance between opposite vertices to the edge length is φ.

**2. The Dodecahedron**

The dodecahedron has 12 pentagonal faces, 30 edges, and 20 vertices. The ratio of the distance between opposite faces to the edge length is φ².

**3. The Rhombic Triacontahedron**

This polyhedron has 30 rhombic faces. The ratio of the long diagonal to the short diagonal of each face is φ.

**4. The Kepler-Poinsot Polyhedra**

These are star polyhedra whose geometry is based on the golden ratio. The small stellated dodecahedron and the great stellated dodecahedron both have golden ratio proportions.

### The Icosahedron in Detail

The icosahedron can be constructed from three golden rectangles:

1. Take three golden rectangles of the same size.
2. Orient them so that their planes are mutually perpendicular.
3. The 12 vertices of the icosahedron are the 12 vertices of the three golden rectangles.

This construction reveals the deep connection between the icosahedron and the golden ratio.

### Worked Example 9.5.1

An icosahedron has edge length 1. What is the distance between opposite vertices?

**Solution**: The distance between opposite vertices of an icosahedron with edge length 1 is:

d = φ × 1 = (1 + √5)/2 ≈ 1.618

### Worked Example 9.5.2

A dodecahedron has edge length 1. What is the distance between opposite faces?

**Solution**: The distance between opposite faces of a dodecahedron with edge length 1 is:

d = φ² × 1 = φ + 1 ≈ 2.618

### Practice Problems

1. Verify that the icosahedron can be constructed from three golden rectangles.
2. Compute the surface area of an icosahedron with edge length 1.
3. Compute the volume of a dodecahedron with edge length 1.
4. What is the ratio of the volume of an icosahedron to the volume of its circumscribed sphere?
5. Draw a three-dimensional golden rectangle.

### Teacher's Notes

**3D Visualization**: If you have access to a 3D printer or geometric model kits, show students the icosahedron and dodecahedron. Point out the golden ratio proportions.

**Historical Note**: The ancient Greeks studied the Platonic solids extensively. Plato associated each solid with a classical element: the icosahedron with water, the dodecahedron with the universe.

---

## Lesson 9.6: The Golden Ratio in Fractal Geometry

### Explanation

Fractals are geometric structures that are self-similar at every scale. The golden ratio appears in several important fractals.

### The Golden Ratio in the Mandelbrot Set

The Mandelbrot set is the most famous fractal. It is defined by the iteration z_{n+1} = z_n² + c, where z and c are complex numbers.

The Mandelbrot set has a striking resemblance to a golden rectangle. The main cardioid (the large heart-shaped region) has proportions that approximate the golden ratio. The smaller bulbs attached to the main cardioid are arranged in a pattern that follows the golden ratio.

### The Golden Ratio in the Sierpinski Triangle

The Sierpinski triangle is a fractal formed by repeatedly removing the central triangle from an equilateral triangle. The ratio of the area of the removed triangles to the total area involves the plastic number (ρ), which is related to the golden ratio family.

### The Golden Ratio in the Koch Snowflake

The Koch snowflake is a fractal formed by repeatedly adding smaller equilateral triangles to the sides of a larger triangle. The ratio of the perimeter to the area involves the golden ratio.

### The Golden Ratio in Julia Sets

Julia sets are fractals related to the Mandelbrot set. Some Julia sets have golden-ratio-based proportions, particularly those that are connected to the golden ratio in the Mandelbrot set.

### Self-Similarity and the Golden Ratio

The key property of fractals is self-similarity: they look the same at every scale. The golden ratio is the "most self-similar" number because it satisfies φ² = φ + 1, which means that scaling by φ is equivalent to adding 1. This self-similarity is why the golden ratio appears so frequently in fractals.

**Key Concept**: The golden ratio is the most self-similar number, which is why it appears in fractals.

### Worked Example 9.6.1

The Mandelbrot set has a small bulb at the tip of the main cardioid. The distance from the center of the main cardioid to the tip is approximately 0.25. The distance from the center to the nearest point on the bulb is approximately 0.154. What is the ratio?

**Solution**: Ratio = 0.25/0.154 ≈ 1.623

This is close to φ ≈ 1.618. ✓

### Practice Problems

1. Find a photograph of the Mandelbrot set. Can you see golden-ratio-based proportions?
2. Compute the ratio of the areas of successive removed triangles in the Sierpinski triangle.
3. Why does the golden ratio appear in the Mandelbrot set?
4. How is self-similarity related to the golden ratio?
5. Find another fractal that uses the golden ratio.

### Teacher's Notes

**Computer Activity**: If you have access to a computer, use a Mandelbrot set viewer to zoom into the set. Point out the golden-ratio-based proportions at different scales.

**Philosophy Connection**: The appearance of the golden ratio in fractals raises deep philosophical questions about the nature of mathematical beauty. Why is the golden ratio so pervasive? Is it a fundamental constant of nature, or is it a human preference?

---

## Lesson 9.7: The Golden Ratio in Tessellations and Tilings

### Explanation

Tessellations are patterns of shapes that cover the plane without gaps or overlaps. The golden ratio appears in several types of tessellations.

### Regular Tessellations

Regular tessellations use a single regular polygon to cover the plane. There are only three regular tessellations:

1. Equilateral triangles (3-fold symmetry)
2. Squares (4-fold symmetry)
3. Regular hexagons (6-fold symmetry)

None of these use the golden ratio directly, but they provide the foundation for more complex tessellations.

### Semiregular Tessellations

Semiregular tessellations use two or more regular polygons. There are 8 semiregular tessellations. Some of these use golden-ratio-based proportions:

**1. The Snub Square Tessellation**

The snub square tessellation uses squares and equilateral triangles. The ratio of the number of triangles to squares is related to the golden ratio.

**2. The Snub Hexagonal Tessellation**

The snub hexagonal tessellation uses hexagons and equilateral triangles. The proportions of the tessellation are related to the golden ratio.

### Penrose Tilings (Revisited)

Penrose tilings are the most famous golden-ratio-based tessellations. They use two types of tiles (kites and darts, or thick and thin rhombi) to cover the plane aperiodically.

The key properties of Penrose tilings are:
- They are aperiodic (never repeat exactly)
- They have five-fold symmetry
- The ratio of thick to thin tiles approaches φ
- They are self-similar (zooming by φ produces the same pattern)

### The Golden Ratio in Islamic Tessellations

Islamic art makes extensive use of tessellations. Many Islamic tessellations use golden-ratio-based proportions, particularly those with 8-fold or 10-fold symmetry.

The relationship between the golden ratio and Islamic tessellations is through the regular octagon (related to the silver ratio) and the regular decagon (related to the golden ratio).

### Worked Example 9.7.1

In a Penrose tiling, there are 233 thin rhombi. Approximately how many thick rhombi are there?

**Solution**: The ratio of thick to thin tiles approaches φ. So:

Number of thick tiles ≈ 233 × φ ≈ 233 × 1.618 ≈ 377

Indeed, 233 and 377 are consecutive Fibonacci numbers (F(13) and F(14)).

### Practice Problems

1. Draw a small Penrose tiling using kites and darts.
2. Count the tiles in your tiling. Is the ratio close to φ?
3. Find an Islamic tessellation that uses golden-ratio proportions.
4. Why are Penrose tilings aperiodic?
5. How does self-similarity relate to the golden ratio?

### Teacher's Notes

**Art Activity**: Have students create Penrose tilings using colored paper. This is a beautiful art activity that also teaches mathematics.

**History**: Penrose tilings were discovered by Roger Penrose in 1974, but similar patterns appear in medieval Islamic art (the Darb-i Imam shrine in Isfahan, Iran, built in 1453).

---

## Summary of Chapter 9

### Key Concepts

1. The **golden ratio search** is an optimization algorithm that uses the golden ratio to narrow the search space.
2. The golden ratio appears in the **regular pentagon** (diagonal = φ × side).
3. **Penrose tilings** are aperiodic tilings with five-fold symmetry, based on the golden ratio.
4. The **icosahedron** and **dodecahedron** have golden ratio proportions.
5. **Phi-normal distributions** are normal distributions parameterized by the golden ratio.
6. The golden ratio appears in many geometric structures in two and three dimensions.

### Key Formulas

| Formula | Description |
|---------|-------------|
| Golden ratio search: interval shrinks by 1/φ each step | Optimization algorithm |
| Pentagon diagonal = φ × side | Golden ratio in pentagon |
| Icosahedron: vertex distance = φ × edge | Golden ratio in 3D |
| Dodecahedron: face distance = φ² × edge | Golden ratio in 3D |

### Connections to Other Chapters

- **Chapter 1 (Golden Ratio)**: The golden ratio underlies all the geometric structures in this chapter.
- **Chapter 5 (Fibonacci and Lucas Numbers)**: Fibonacci numbers appear in Penrose tiling tile counts.
- **Chapter 8 (Living Mathematics)**: The golden ratio in biology is related to the geometric principles in this chapter.
- **Chapter 10 (Phi-Chemistry and Phi-Physics)**: Quasicrystals use Penrose tiling geometry.

---

**End of Chapter 9**

*Next: Chapter 10 — Phi-Chemistry and Phi-Physics*
