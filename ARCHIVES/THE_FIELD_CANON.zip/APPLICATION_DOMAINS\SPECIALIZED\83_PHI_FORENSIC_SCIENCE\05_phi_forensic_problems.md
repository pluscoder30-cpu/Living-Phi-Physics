# PHI-FORENSIC SCIENCE: Problem Sets

---

## Problem Set 1: Phi-Fingerprint Analysis

### Problem 1.1
Two fingerprints have 18 minutiae points. The top 6 ranked matches have distances [1, 4, 6, 10, 14, 22] pixels. Compute the phi-weighted match score with d_φ = 13.5 pixels.

### Problem 1.2
A fingerprint has ridge count mean = 18 with standard deviation σ = 5. Compute the phi-modified ridge count distribution and identify the phi-characteristic ridge count k_φ.

### Problem 1.3
Derive the expression for the phi-fingerprint similarity score S_φ that achieves 90% of the maximum possible score. Express the result in terms of the number of minutiae N.

### Problem 1.4
A fingerprint is captured under varying pressure (p/p₀ = 0.5, 1.0, 1.5, 2.0) at distances r = [5, 10, 15, 20] mm from the core. Compute the phi-deformed ridge spacing with s₀ = 0.5 mm and γ = 0.3.

### Problem 1.5
Compare the phi-minutiae matching and standard matching for a database of 100,000 fingerprints. Estimate the reduction in false positive identifications.

---

## Problem Set 2: Phi-DNA Profiling

### Problem 2.1
A DNA profile has 6 loci with allele frequencies [0.20, 0.12, 0.06, 0.03, 0.015, 0.008]. The suspect is heterozygous at all loci. Compute the phi-weighted likelihood ratio.

### Problem 2.2
A 3-person mixture has contributor proportions [0.5, 0.3, 0.2] with 8 loci. Design a phi-weighted deconvolution algorithm that assigns genotypes to contributors.

### Problem 2.3
Compute the phi-relatedness index for two individuals sharing alleles at 15 of 20 loci, with the shared loci being the most commonly variable.

### Problem 2.4
A population study has mutation rate μ₀ = 0.002 per locus per generation. Compute the phi-corrected mutation rate at forensic time scales (t = 50 generations, t_φ = 30 generations).

### Problem 2.5
Compare the standard and phi-weighted DNA mixture interpretation for a 4-person mixture with 12 loci and known contributor proportions [0.4, 0.3, 0.2, 0.1].

---

## Problem Set 3: Phi-Ballistics

### Problem 3.1
A bullet is fired at v₀ = 900 m/s, θ = 25°, at x = 300 m. Compute the phi-corrected vertical position with x_φ = 200 m.

### Problem 3.2
A rifle bullet has L/D = 4.5 with v = 850 m/s and v_crit = 340 m/s. Compute the phi-optimal rifling twist rate with T₀ = 1:10 inches.

### Problem 3.3
A toolmark has 32 striations. The phi-weighted correlation at the correct alignment is C_φ(0) = 0.89, and at the best spurious alignment is C_φ(Δx*) = 0.34. Compute the phi-individualization probability.

### Problem 3.4
A clothing sample has 220 GSR particles/cm² with muzzle reference N₀ = 350 particles/cm². Estimate the shooting distance with r_φ = 30 cm and λ_φ = 45 cm.

### Problem 3.5
Compare the phi-corrected and standard bullet trajectories for a handgun (v₀ = 380 m/s) at ranges [25, 50, 100, 150, 200] meters.

---

## Problem Set 4: Phi-Toxicology

### Problem 4.1
A toxin has EC₅₀ = 2.5 mg/kg with slope = 1.8 for toxicity class 3. Compute the phi-modified LD₅₀ and the dose producing 50% effect.

### Problem 4.2
A drug has pharmacokinetic parameters: D = 500 mg, k_a = 1.5/hr, k_e = 0.15/hr, V = 70 L. Compute the phi-modified concentration at t = [0.5, 1, 2, 4, 8, 12] hours with t_φ = 3 hours.

### Problem 4.3
Two toxins have EC₅₀ values [0.5, 5.0] mg/kg with concentrations [0.3, 2.0] mg/kg. Compute the phi-weighted mixture toxicity EC₅₀,mix.

### Problem 4.4
A chronic exposure study has dose D = 10 mg/day, F = 0.8, CL = 5 L/hr, τ = 24 hr, with N = 90 days. Compute the phi-steady-state concentration at day 60.

### Problem 4.5
Compare the standard and phi-modified dose-response curves for a pesticide with EC₅₀ = 1.0 mg/kg, slope = 2.5, and toxicity class 2.

---

## Problem Set 5: Phi-Digital Forensics

### Problem 5.1
A file system has 5,000 files with creation timestamps. Detect phi-timestamp clusters with Δt = 100 ms and K = 5,000.

### Problem 5.2
A network capture has 10,000 packets. Design a phi-anomalous packet timing detector with ω = [1, 3, 7, 15] Hz and K = 10,000.

### Problem 5.3
A RAM dump of 8 GB has a suspected malware pattern of length 256 bytes. Design a phi-weighted search with base address 0x7FFE0000 and L = 1,000,000.

### Problem 5.4
An image has pixel intensity distribution O_k for k = 0,...,255. Design a chi-squared phi-weighted steganography detector.

### Problem 5.5
Compare the phi-digital and standard digital forensic methods for a case with 500 GB of evidence across 3 storage devices.

---

## Problem Set 6: Phi-Serology and Audio Forensics

### Problem 6.1
A bloodstain has w = 0.6 mm, l = 2.4 mm at d = 2.0 m with d_φ = 1.5 m. Compute the phi-corrected impact angle.

### Problem 6.2
A bloodstain pattern has 45 stains with average w/l = 0.42. Classify the pattern (impact, cast-off, transfer, projected) using phi-weighted shape analysis.

### Problem 6.3
Two voice samples have spectral similarities [0.88, 0.82, 0.75, 0.70, 0.65] at frequencies [200, 400, 800, 1600, 3200] Hz. Compute the phi-weighted comparison score with f₀ = 200 Hz.

### Problem 6.4
A degraded recording has SNR = 5 dB with phi-enhancement. Compute the improvement in speaker comparison accuracy.

### Problem 6.5
Compare the phi-corrected and standard bloodstain analysis for impact angles [10, 20, 30, 45, 60, 75] degrees at distances [0.5, 1.0, 1.5, 2.0] meters.

---

## Problem Set 7: Integration and Analysis

### Problem 7.1
Design an integrated phi-forensic evidence scoring system that combines fingerprint, DNA, ballistics, and digital evidence for a murder case.

### Problem 7.2
Compute the total phi-forensic confidence for a case with evidence scores [0.85, 0.92, 0.78, 0.88] across 4 evidence types with phi-weights φ^(-k/4).

### Problem 7.3
Compare the cost-effectiveness of phi-enhanced vs. standard forensic analysis for a crime lab processing 50,000 cases annually.

### Problem 7.4
Design a phi-weighted evidence presentation format for court that maximizes jury comprehension while maintaining scientific accuracy.

### Problem 7.5
Prove that the phi-forensic confidence interval is narrower than the standard interval by a factor of 1/φ for evidence types with normally distributed measurement error.

---

## Problem Set 8: Phi-Fingerprint Advanced Analysis

### Problem 8.1
A latent fingerprint has 12 minutiae with quality scores [0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.15, 0.1, 0.08, 0.05]. Compute the phi-enhanced quality-weighted match score.

### Problem 8.2
Two fingerprints have different ridge counts at 10 reference regions: [12, 18, 22, 15, 20, 14, 25, 16, 19, 21] vs [11, 17, 23, 14, 21, 13, 24, 17, 18, 22]. Compute the phi-weighted ridge count similarity.

### Problem 8.3
Design a phi-hash function for fingerprint templates that maps 36 minutiae to a 64-bit code. Compute the collision probability for 10,000 templates.

### Problem 8.4
A fingerprint database has 10M records with 500,000 latent prints. Design a phi-tiered search strategy that reduces average search time by 40%.

### Problem 8.5
Compute the phi-fingerprint liveness detection score for 5 presentation attack instruments with artifact scores [0.85, 0.72, 0.91, 0.68, 0.78] and liveness indicators [0.12, 0.25, 0.08, 0.32, 0.20].

---

## Problem Set 9: Phi-DNA Advanced Analysis

### Problem 9.1
A mitochondrial DNA sequence has 12 variable sites with phi-weighted mutation rates. Compute the phi-adjusted time to most recent common ancestor (TMRCA) for two lineages.

### Problem 9.2
Design a phi-Y-STR analysis for 17 loci with mutation rates ranging from 0.001 to 0.005. Compute the phi-weighted paternal lineage discrimination.

### Problem 9.3
A degraded DNA sample has partial profiles at 8 of 20 STR loci. Design a phi-weighted profile completion algorithm that maximizes likelihood ratio.

### Problem 9.4
Compute the phi-kinship index for a grandparentage test with 15 shared alleles across 25 loci, with allele frequencies ranging from 0.01 to 0.30.

### Problem 9.5
A forensic laboratory processes 20,000 DNA cases annually. Design a phi-quality control system that detects contamination with 99.5% sensitivity.

---

## Problem Set 10: Phi-Ballistics Advanced Analysis

### Problem 10.1
A bullet fragment has 45 striations with varying contrast levels [0.2-1.0]. Design a phi-contrast-weighted matching algorithm.

### Problem 10.2
Compute the phi-ricochet angle for a bullet striking a steel plate at 30° with v₀ = 750 m/s and coefficient of restitution 0.4.

### Problem 10.3
Design a phi-caliber identification system that classifies 8 common calibers from GSR patterns with 95% accuracy.

### Problem 10.4
A shooting scene has 3 shell casings with phi-weighted ejection distances [2.1, 3.4, 1.8] meters. Reconstruct the shooter's position with phi-uncertainty quantification.

### Problem 10.5
Compute the phi-trajectory reconstruction from entry and exit wound positions on a victim with body dimensions [height=1.75m, width=0.45m, depth=0.25m].

---

## Problem Set 11: Phi-Toxicology Advanced Analysis

### Problem 11.1
A postmortem blood sample has ethanol concentration 180 mg/dL with postmortem interval of 12 hours. Compute the phi-corrected antemortem concentration.

### Problem 11.2
Design a phi-drug interaction matrix for 6 common drugs with synergistic and antagonistic effects. Compute the combined phi-toxicity score.

### Problem 11.3
A hair sample shows cocaine use over 6 months with segmental analysis. Compute the phi-weighted chronic exposure index with monthly segments.

### Problem 11.4
Compute the phi-therapeutic drug monitoring range for phenytoin with population variability σ = 3.2 mg/L and target concentration 12 mg/L.

### Problem 11.5
Design a phi-analytical quality control chart for a forensic toxicology laboratory processing 500 samples/day with 12 analytes.

---

## Problem Set 12: Phi-Forensic Digital Advanced Analysis

### Problem 12.1
A cryptocurrency wallet has 500 transactions across 3 years. Design a phi-blockchain analysis that traces fund flows and identifies mixing patterns.

### Problem 12.2
Compute the phi-metadata extraction score for 50 digital photographs with varying EXIF data completeness [20%-95%].

### Problem 12.3
A cloud storage account has 10,000 deleted files recoverable from 3 backup sources. Design a phi-prioritized file recovery strategy.

### Problem 12.4
Design a phi-android forensic analysis for a rooted device with 15 installed applications and 200,000 artifacts.

### Problem 12.5
Compute the phi-network forensics score for a case with 50,000 packets, 200 unique IPs, and 8 suspicious connections.

---

## Problem Set 13: Phi-Forensic Integration and Legal

### Problem 13.1
Design a phi-automated evidence triage system that classifies 1,000 evidence items into 8 categories with 95% accuracy.

### Problem 13.2
Compute the phi-forensic evidence weight for a case with 6 independent evidence sources with individual weights [0.7, 0.8, 0.6, 0.9, 0.5, 0.75].

### Problem 13.3
A courtroom presentation requires visualizing forensic evidence for 12 jurors. Design a phi-information-theoretic display that maximizes comprehension.

### Problem 13.4
Compute the phi-jury decision model for a case with 3 evidence types having Bayesian posterior probabilities [0.85, 0.72, 0.68].

### Problem 13.5
Design a phi-forensic laboratory accreditation system with 15 quality standards and phi-weighted compliance scoring.

---

*See companion files: 01_phi_forensic_theory.md, 06_phi_forensic_answers.md*
