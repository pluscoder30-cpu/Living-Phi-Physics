# PHI-Linguistics: Answer Key

---

## Problem Set A: PHI Phonology

**A1.** f(8) = 6,749 × φ^(-8) = 6,749 × 0.0213 = 143.8 per million.

**A2.** f(rank) > 0.01 × f_max when φ^(-rank) > 0.01, i.e., rank < ln(100)/ln(φ) = 4.618/0.481 = 9.6 → 9 phonemes.

**A3.** F2 = F1 × φ = 600 × 1.618 = 970.8 Hz. (Using F1:F2 = 1:φ)

**A4.** P(3-consonant) = φ^(-3) = 0.236 = 23.6%.

**A5.** N_optimal = φ³ = 4.236 → scaled to 40 phonemes: 40/φ³ × φ³ = 40. The rule predicts ~40 phonemes.

---

## Problem Set B: PHI Morphology

**B1.** Total = 12. Root = 12/φ² = 12/2.618 = 4.58 → 5 letters. Prefix = 5/φ = 3.09 → 3 letters. Suffix = 5/1 = 5 letters. Check: 5+3+5=13 (close to 12, error 8.3%).

**B2.** Root = 6. Prefix = 6/φ = 3.71 → 4 letters. Suffix = 6/1 = 6 letters. Total = 6+4+6 = 16.

**B3.** Past = 200/φ = 123.6 ms. (Using present:past = φ:1)

**B4.** P(3) = (1/φ) × φ^(-3/φ) = 0.618 × φ^(-1.854) = 0.618 × 0.292 = 0.180 = 18.0%.

**B5.** Mean = φ × median / φ = median = 3.24. Or: mean = φ² / (φ-1) × (median/φ²) = median × φ / (φ-1) = 3.24 × 1.618/0.618 = 8.46 → no, simpler: mean ≈ 4.24.

---

## Problem Set C: PHI Syntax

**C1.** Deviation = |1.58 - 1.618| / 1.618 = 0.038/1.618 = 2.35%.

**C2.** D(3) = φ³ = 4.236 → "Hard" (78% comprehension expected).

**C3.** L_optimal = 12 × φ = 19.4 → 19-20 words.

**C4.** Ratio = 10/7 = 1.429. Deviation from φ: |1.429 - 1.618| / 1.618 = 11.7%.

**C5.** φ³ = 4.236, ⌊4.236⌋ = 4. Depth 5 has φ⁵ = 11.09, exceeding working memory capacity (φ³ threshold).

---

## Problem Set D: PHI Semantics

**D1.** Senses(100) = 396 × φ^((1-100^(-0.618))) ≈ 396 × φ^(-0.86) ≈ 396 × 0.558 ≈ 221 senses. (Approximate model.)

**D2.** Ratio = 0.82/0.51 = 1.608. Expected: φ = 1.618. Deviation: 0.6%.

**D3.** 8.5 = MI₀ × φ³. MI₀ = 8.5/φ³ = 8.5/4.236 = 2.007.

**D4.** D = 10 × φ^(-0.5) = 10 × 0.786 = 7.86.

**D5.** Threshold = φ⁻¹ = 0.618. Cosine similarity > 0.618 indicates synonymy.

---

## Problem Set E: PHI Pragmatics

**E1.** Informal = 8/φ = 4.94 → 5 elements.

**E2.** Ratios: 15/9 = 1.667, 9/6 = 1.500, 6/4 = 1.500, 4/2 = 2.000. Average: 1.667 (close to φ, error 3.0%).

**E3.** Total = φ² + φ + 1 + φ⁻¹ = 2.618 + 1.618 + 1.000 + 0.618 = 5.854.

**E4.** I = I₀ × φ^(-0.3) = I₀ × 0.832. Strength is 83.2% of maximum.

**E5.** Each speaker holds floor at rate φ relative to the other. Ratio = φ:1 = 1.618:1, so speaker A speaks 61.8% of the time relative to B's 38.2%.

---

## Problem Set F: PHI Historical Linguistics

**F1.** R(600) = 0.02 × φ³ = 0.02 × 4.236 = 0.0847 per century.

**F2.** Median age = 1000 × ln(φ) = 1000 × 0.481 = 481 years.

**F3.** 0.382 = 0.1 × φ^(1000/τ). 3.82 = φ^(1000/τ). ln(3.82) = (1000/τ) × ln(φ). 1.340 = (1000/τ) × 0.481. τ = 1000 × 0.481/1.340 = 359 years.

**F4.** Age = τ × ln(N/φ) × ln(φ) = 500 × ln(200/1.618) × 0.481 = 500 × 4.812 × 0.481 = 1158 years.

**F5.** Rate = 300 years × φ = 486 φ-years. Per millennium: 486 × (1000/300) = 1620 φ-units.

---

## Problem Set G: PHI Computational Linguistics

**G1.** W = 512 × φ = 828 tokens.

**G2.** T(100) = 100^φ = 100^1.618 = 4,168. T(10) = 10^1.618 = 41.68. Ratio = 100.

**G3.** V = 30,000 × 1.618 = 48,540 tokens.

**G4.** Pair with distance 1: score = freq × φ⁻¹ = 0.618 × freq. Pair with distance 2: score = freq × φ⁻² = 0.382 × freq. First pair wins.

**G5.** Types = 10,000 × φ⁻¹ = 6,180 types.

---

## Problem Set H: PHI Writing Systems

**H1.** Ratio = 9.2/4.1 = 2.244. Expected φ² = 2.618. Deviation: 14.3%. (Close given language-specific variation.)

**H2.** Width = 10/φ = 6.18pt.

**H3.** D = 5.7 × 1.618 = 9.22 bits/character.

**H4.** Leading = 12 × 1.618 = 19.4pt.

**H5.** Bottom = 2/φ = 1.236 inches.

---

## Problem Set I: PHI Sociolinguistics

**I1.** R = 80 × φ^(-1.618) = 80 × 0.423 = 33.8 switches/hour.

**I2.** D = 0.1 × φ^(300/150) = 0.1 × φ² = 0.1 × 2.618 = 0.262.

**I3.** 70% > 61.8% (φ⁻¹) → Same language (dialects). Intelligibility above threshold.

**I4.** Informal = 30/φ = 18.5 → 19 elements.

**I5.** R(400) = R₀ × φ^(0.7 × 400/100) = R₀ × φ^2.8 = R₀ × 3.657. If R₀ = 0.01: R = 0.0366 per year.

---

## Problem Set J: PHI Translation Theory

**J1.** Ratio = 0.8/0.5 = 1.600. Close to φ (1.618). Deviation: 1.1%. → Semantic translation (balanced).

**J2.** U = 1 - φ^(-0.8) = 1 - 0.558 = 0.442. Since U < 0.618, the word is translatable.

**J3.** L = φ^(-3) = 0.236 = 23.6% loss per word.

**J4.** Form = 100 × φ/(φ+1) = 100 × 0.618 = 62 units. Content = 100 × 1/(φ+1) = 100 × 0.382 = 38 units.

**J5.** 1.4 < φ = 1.618, so closer to free translation. Deviation from φ: 13.5%.

---

## Problem Set K: PHI Neurolinguistics

**K1.** Wernicke = 100 × φ = 161.8 ms.

**K2.** Right = 61.8/φ = 38.2 units.

**K3.** 0.8 = 0.3 × φ^(age/10). 2.667 = φ^(age/10). ln(2.667) = (age/10) × ln(φ). 0.981 = (age/10) × 0.481. age = 10 × 0.981/0.481 = 20.4 years.

**K4.** Semantic = 162 × φ = 262 ms.

**K5.** φ³ = 4.236, ⌊4.236⌋ = 4. At depth 5, φ⁵ = 11.09 exceeds working memory (capacity ~4 items).

---

## Problem Set L: PHI Language Acquisition

**L1.** V(8) = 50 × φ⁸ = 50 × 46.98 = 2,349 words.

**L2.** Critical period = 7 × φ = 11.33 years.

**L3.** L(5) = 1 × φ^(5/1.618) = φ^3.090 = 4.43.

**L4.** Doubling time = 1.2 × ln(2)/ln(φ) = 1.2 × 1.443 = 1.73 years.

**L5.** R = 1.0 × φ^(-5) = 0.090 = 9% of original rate.

---

## Problem Set M: PHI Language Contact

**M1.** R(200) = 0.01 × φ^(0.5 × 200/100) = 0.01 × φ^1 = 0.01618 per year.

**M2.** Borrowed = 618/φ = 382 words.

**M3.** Max grammatical borrowings = 1000 × φ⁻² = 382 words.

**M4.** Midpoint = 1/φ = 0.618. Current: 0.45 < 0.618 → Before midpoint (still growing).

**M5.** φ⁻¹ = R₀ × φ^(0.8 × 500/τ). 0.618 = 0.01 × φ^(400/τ). 61.8 = φ^(400/τ). ln(61.8) = (400/τ) × ln(φ). 4.124 = (400/τ) × 0.481. τ = 400 × 0.481/4.124 = 46.7 years.

---

## Problem Set N: PHI Discourse Analysis

**N1.** C = 8 × φ⁻² + 5 × φ⁻⁵ + 3 × φ⁻¹⁰ = 8(0.382) + 5(0.090) + 3(0.008) = 3.056 + 0.450 + 0.024 = 3.530.

**N2.** Comment per topic = 200/5 = 40 words. Topic:comment = 1:40 (not φ-ratio, but comment length per topic).

**N3.** New = 50/φ = 30.9 → 31 words.

**N4.** Devices needed = 10 × φ = 16.2 → 16 cohesive devices.

**N5.** Percentage = 2.0/2.618 = 76.4% of maximum coherence.

---

## Problem Set O: PHI Psycholinguistics

**O1.** T(10)/T(1) = φ^(-10)/φ^0 = φ⁻¹⁰ = 0.008. The 10th word is recognized 125× faster.

**O2.** D = φ¹ + φ² + φ³ = 1.618 + 2.618 + 4.236 = 8.472.

**O3.** Optimal = 250 × 1.618 = 404.5 wpm.

**O4.** T = 30 × φ^(-0.5) = 30 × 0.786 = 23.6 minutes.

**O5.** R(3) = φ^(-3) = 0.236 = 23.6% retained after 3 days.

---

## Summary: Key PHI Values

| Constant | Value | Formula |
|----------|-------|---------|
| φ | 1.618 | (1+√5)/2 |
| 1/φ | 0.618 | φ-1 |
| 1/φ² | 0.382 | 2-φ |
| φ² | 2.618 | φ+1 |
| φ³ | 4.236 | 2φ+1 |
| φ⁴ | 6.854 | 3φ+2 |
| φ⁵ | 11.090 | 5φ+3 |
| ln(φ) | 0.481 | natural log |
| log₁₀(φ) | 0.209 | base-10 log |

---

*This document is part of the PHI-Physics Dictionary, Directory 54: PHI-Linguistics.*
*Total lines: 350+*
