# PHI-NEUROSCIENCE: Reference Tables

---

## Table 1: Phi-Firing Rate Parameters

| Neuron Type | f₀ (Hz) | f_φ = f₀/φ (Hz) | V₀ (mV) | φ-Factor |
|-------------|---------|-----------------|---------|----------|
| Cortical pyramidal | 100 | 61.8 | 20 | φ⁻¹ |
| Cortical interneuron | 200 | 123.6 | 15 | φ⁻¹ |
| Hippocampal CA1 | 50 | 30.9 | 25 | φ⁻¹ |
| Hippocampal interneuron | 150 | 92.7 | 18 | φ⁻¹ |
| Thalamic relay | 80 | 49.4 | 22 | φ⁻¹ |
| Thalamic interneuron | 180 | 111.2 | 16 | φ⁻¹ |
| Cerebellar Purkinje | 120 | 74.1 | 20 | φ⁻¹ |
| Cerebellar granule | 300 | 185.4 | 12 | φ⁻¹ |
| Retinal ganglion | 60 | 37.1 | 24 | φ⁻¹ |
| Auditory nerve | 400 | 247.2 | 10 | φ⁻¹ |
| Motor neuron | 70 | 43.3 | 23 | φ⁻¹ |
| Sensory receptor | 250 | 154.5 | 14 | φ⁻¹ |
| Dopaminergic (VTA) | 5 | 3.09 | 40 | φ⁻¹ |
| Serotonergic (raphe) | 3 | 1.85 | 45 | φ⁻¹ |
| Noradrenergic (LC) | 10 | 6.18 | 35 | φ⁻¹ |
| Cholinergic (basal) | 15 | 9.27 | 30 | φ⁻¹ |
| GABAergic (medium) | 20 | 12.36 | 28 | φ⁻¹ |
| Glutamatergic | 90 | 55.6 | 21 | φ⁻¹ |
| Mirror neuron | 45 | 27.8 | 26 | φ⁻¹ |
| Grid cell | 40 | 24.7 | 27 | φ⁻¹ |
| Place cell | 30 | 18.5 | 29 | φ⁻¹ |
| Boundary cell | 25 | 15.5 | 31 | φ⁻¹ |
| Head direction cell | 35 | 21.6 | 28 | φ⁻¹ |
| Speed cell | 55 | 34.0 | 24 | φ⁻¹ |
| Concept cell | 10 | 6.18 | 35 | φ⁻¹ |

---

## Table 2: Phi-EEG Frequency Bands

| Band | Standard Range (Hz) | Phi-Center (Hz) | Phi-Harmonic | φ-Power Ratio |
|------|--------------------|-----------------|--------------|--------------------|
| Delta | 1-4 | 1.0 | φ⁰ × 1.0 | 1.000 |
| Theta | 4-8 | 2.6 | φ¹ × 1.0 | 0.618 |
| Alpha | 8-13 | 6.8 | φ² × 1.0 | 0.382 |
| Beta | 13-30 | 11.1 | φ³ × 1.0 | 0.236 |
| Gamma | 30-100 | 17.9 | φ⁴ × 1.0 | 0.146 |
| High Gamma | 100-200 | 29.0 | φ⁵ × 1.0 | 0.090 |
| Ripple | 200-500 | 47.0 | φ⁶ × 1.0 | 0.056 |
| Fast Ripple | 500-1000 | 76.0 | φ⁷ × 1.0 | 0.034 |

---

## Table 3: Phi-STDP Parameters

| Synapse Type | A₊ (phi-corrected) | A₋ (phi-corrected) | τ₊ (ms) | τ₋ (ms) | φ-Ratio |
|--------------|---------------------|---------------------|---------|---------|---------|
| Excitatory (L2/3) | 0.00818 | 0.00982 | 16.18 | 20.23 | A₋/A₊ = φ⁻⁰·² |
| Excitatory (L4) | 0.01 | 0.01236 | 20 | 25 | A₋/A₊ = φ⁻⁰·² |
| Excitatory (L5) | 0.01236 | 0.015 | 24.72 | 30.9 | A₋/A₊ = φ⁻⁰·² |
| Inhibitory (FS) | 0.015 | 0.01854 | 12.36 | 15.5 | A₋/A₊ = φ⁻⁰·² |
| Inhibitory (LTS) | 0.01236 | 0.01 | 20 | 16.18 | A₋/A₊ = φ⁰·² |
| Hippocampal CA3 | 0.01545 | 0.01909 | 25 | 30.9 | A₋/A₊ = φ⁻⁰·² |
| Hippocampal CA1 | 0.01236 | 0.015 | 20 | 25 | A₋/A₊ = φ⁻⁰·² |
| Amygdala | 0.01854 | 0.023 | 15.5 | 19.2 | A₋/A₊ = φ⁻⁰·² |
| Cerebellum | 0.01 | 0.01236 | 16.18 | 20 | A₋/A₊ = φ⁻⁰·² |
| Striatum | 0.01236 | 0.01545 | 18.5 | 23 | A₋/A₊ = φ⁻⁰·² |

---

## Table 4: Phi-Brain Wave Coupling

| Coupling Pair | Standard (Hz) | Phi-Pair (Hz) | φ-Ratio | Strength |
|---------------|---------------|---------------|---------|----------|
| Delta-Theta | 2, 6 | 1.0, 2.6 | φ¹ | Strong |
| Delta-Alpha | 2, 10 | 1.0, 6.8 | φ² | Medium |
| Delta-Beta | 2, 20 | 1.0, 11.1 | φ³ | Weak |
| Delta-Gamma | 2, 40 | 1.0, 17.9 | φ⁴ | Very weak |
| Theta-Alpha | 6, 10 | 2.6, 6.8 | φ¹ | Strong |
| Theta-Beta | 6, 20 | 2.6, 11.1 | φ² | Medium |
| Theta-Gamma | 6, 40 | 2.6, 17.9 | φ³ | Strong |
| Alpha-Beta | 10, 20 | 6.8, 11.1 | φ¹ | Medium |
| Alpha-Gamma | 10, 40 | 6.8, 17.9 | φ² | Strong |
| Beta-Gamma | 20, 40 | 11.1, 17.9 | φ¹ | Strong |

---

## Table 5: Phi-Memory Parameters

| Memory System | Standard | Phi-Modified | Significance |
|---------------|----------|-------------|--------------|
| Working memory slots | 7 ± 2 | 7 × φ⁻¹ = 4.3 ± 1.2 | Reduced capacity |
| STM duration (s) | 20-30 | 20 × φ = 32.4 | Longer duration |
| LTM consolidation (hr) | 1-6 | 1 × φ = 1.62 | Faster initial |
| Forgetting half-life (day) | 1 | 1 × φ = 1.62 | Slower forgetting |
| Rehearsal benefit | 2× | 2 × φ = 3.24 | Enhanced benefit |
| Spacing effect | 1.5× | 1.5 × φ = 2.43 | Enhanced spacing |
| Testing effect | 1.5× | 1.5 × φ = 2.43 | Enhanced testing |
| Context effect | 1.3× | 1.3 × φ = 2.10 | Enhanced context |
| Sleep consolidation | 1.2× | 1.2 × φ = 1.94 | Enhanced sleep |
| Emotional boost | 2× | 2 × φ = 3.24 | Enhanced emotion |

---

## Table 6: Phi-Consciousness Thresholds

| Consciousness Metric | Threshold | Phi-Threshold | φ-Value |
|----------------------|-----------|---------------|---------|
| Global workspace activation | 0.5 | 0.382 | φ⁻² |
| Integrated information Φ | 1.0 | 0.618 | φ⁻¹ |
| Neural complexity | 0.4 | 0.247 | φ⁻³ |
| Recurrence index | 0.3 | 0.185 | φ⁻⁴ |
| Synchrony index | 0.6 | 0.371 | φ⁻² |
| Phase-locking value | 0.5 | 0.309 | φ⁻² |
| Mutual information | 0.4 | 0.247 | φ⁻³ |
| Causal density | 0.3 | 0.185 | φ⁻⁴ |
| Perturbational complexity | 0.5 | 0.309 | φ⁻² |
| Ignition probability | 0.4 | 0.247 | φ⁻³ |

---

## Table 7: Phi-Neural Network Initialization

| Network Type | Standard Init | Phi-Init | φ-Scaling |
|--------------|---------------|----------|-----------|
| Input layer | N(0, 1/√n) | N(0, φ⁻¹/√n) | φ⁻¹ scaling |
| Hidden layer | N(0, 1/√n) | N(0, 1/√(n×φ)) | φ-expansion |
| Output layer | N(0, 1/√n) | N(0, φ/√n) | φ-amplification |
| Recurrent weights | N(0, 0.01) | N(0, 0.01×φ⁻¹) | φ-attenuation |
| Bias | 0 | 0.01×φ⁻¹ | φ-offset |
| Attention weights | Uniform | φ-weighted | φ-bias |
| Embedding | N(0, 1) | N(0, φ⁻¹/2) | φ-compression |
| Layer norm | γ=1, β=0 | γ=φ⁻¹, β=0 | φ-normalization |

---

## Table 8: Phi-Learning Rate Schedules

| Schedule | Standard | Phi-Modified | φ-Benefit |
|----------|----------|-------------|-----------|
| Step decay | η × 0.1^epoch/10 | η × φ^(-epoch/10) | Gentler decay |
| Exponential | η × e^(-epoch/10) | η × φ^(-epoch/10) | Slower decay |
| Cosine annealing | η × cos(πt/T) | η × cos(πt/(T×φ)) | Longer cycle |
| Warm restart | T₀ = 10 | T₀ = 10 × φ | Longer restart |
| Cyclical | η_min to η_max | η_min/φ to η_max×φ | Wider range |
| 1cycle | η_max at 30% | η_max at 30%×φ | Later peak |
| Polynomial | η × (1-t/T)^α | η × (1-t/T)^φ | φ-power decay |
| Adaptive (Adam) | β₁=0.9, β₂=0.999 | β₁=φ⁻¹, β₂=φ⁻² | φ-adaptive |

---

## Table 9: Phi-Neural Oscillator Coupling

| Oscillator Pair | Standard K | Phi-K | φ-Coupling | Synchrony |
|-----------------|-----------|-------|-----------|-----------|
| Cortical-thalamic | 0.1 | 0.0618 | φ⁻¹ | Strong |
| Hippocampal-cortical | 0.08 | 0.0494 | φ⁻¹ | Medium |
| Amygdala-prefrontal | 0.05 | 0.0309 | φ⁻¹ | Weak |
| Basal ganglia-cortical | 0.07 | 0.0433 | φ⁻¹ | Medium |
| Cerebellar-thalamic | 0.06 | 0.0371 | φ⁻¹ | Medium |
| Brainstem-cortical | 0.04 | 0.0247 | φ⁻¹ | Weak |
| Olfactory-hippocampal | 0.09 | 0.0556 | φ⁻¹ | Strong |
| Visual-cortical | 0.12 | 0.0741 | φ⁻¹ | Strong |
| Auditory-cortical | 0.11 | 0.0679 | φ⁻¹ | Strong |
| Somatosensory-cortical | 0.1 | 0.0618 | φ⁻¹ | Strong |

---

## Table 10: Phi-Brain Region Connectivity

| Region Pair | Standard Weight | Phi-Weight | φ-Distance | Function |
|-------------|----------------|-----------|-----------|----------|
| PFC-Parietal | 0.8 | 0.494 | φ⁻¹ | Attention |
| PFC-Temporal | 0.6 | 0.371 | φ⁻¹ | Memory |
| PFC-OFC | 0.7 | 0.433 | φ⁻¹ | Decision |
| Hippocampus-Entorhinal | 0.9 | 0.556 | φ⁻¹ | Memory encoding |
| Amygdala-Hippocampus | 0.5 | 0.309 | φ⁻¹ | Emotional memory |
| Thalamus-Cortex (all) | 0.85 | 0.525 | φ⁻¹ | Relay |
| Basal ganglia-Thalamus | 0.7 | 0.433 | φ⁻¹ | Motor control |
| Cerebellum-Thalamus | 0.6 | 0.371 | φ⁻¹ | Coordination |
| Insula-Amygdala | 0.55 | 0.340 | φ⁻¹ | Interoception |
| ACC-PFC | 0.75 | 0.464 | φ⁻¹ | Conflict monitoring |

---

*Part of the 32_PHI_PHYSICS / 06_EXPANDED_MATHEMATICS system.*
*Version 1.0 — Agent I of 26*

---

## Table 11: Phi-Neurotransmitter Parameters

| Neurotransmitter | Receptor Affinity (nM) | Phi-Affinity | Release Rate | Phi-Release |
|------------------|----------------------|-------------|-------------|-------------|
| Dopamine | 10 | 6.18 | 100 vesicles/s | 61.8/s |
| Serotonin | 5 | 3.09 | 50 vesicles/s | 30.9/s |
| Norepinephrine | 8 | 4.94 | 80 vesicles/s | 49.4/s |
| Acetylcholine | 15 | 9.27 | 200 vesicles/s | 123.6/s |
| GABA | 20 | 12.36 | 300 vesicles/s | 185.4/s |
| Glutamate | 12 | 7.41 | 500 vesicles/s | 309/s |
| Glycine | 25 | 15.45 | 150 vesicles/s | 92.7/s |
| Endorphin | 2 | 1.24 | 20 vesicles/s | 12.4/s |

---

## Table 12: Phi-Brain Development Timeline

| Milestone | Standard Age | Phi-Age | Phi-Advancement |
|-----------|-------------|---------|-----------------|
| Neural tube closure | 28 days | 17.3 days | 38% faster |
| Synaptogenesis peak | 6 months | 3.7 months | 38% faster |
| Myelination onset | 6 months | 3.7 months | 38% faster |
| Critical period (visual) | 6-12 months | 3.7-7.4 months | 38% earlier |
| Language acquisition | 1-3 years | 0.6-1.9 years | 38% earlier |
| Prefrontal maturation | 25 years | 15.5 years | 38% earlier |
| Hippocampal adult neurogenesis | Lifelong | Lifelong x phi | Enhanced |
| White matter peak | 30 years | 18.5 years | 38% earlier |

---

## Table 13: Phi-Sleep Architecture Parameters

| Sleep Stage | Duration (min) | Phi-Duration | % of Night | Phi-% |
|-------------|---------------|-------------|-----------|-------|
| N1 (light) | 5-10 | 3.1-6.2 | 5% | 3.1% |
| N2 (intermediate) | 20-25 | 12.4-15.5 | 45% | 27.8% |
| N3 (deep) | 20-40 | 12.4-24.7 | 25% | 15.5% |
| REM | 10-60 | 6.2-37.1 | 25% | 15.5% |
| Total cycle | 90 | 55.6 | 100% | 100% |

---

## Table 14: Phi-Pain Processing Parameters

| Pain Type | Threshold (muA) | Phi-Threshold | Adaptation Rate | Phi-Adaptation |
|-----------|----------------|---------------|-----------------|----------------|
| Sharp (A-delta) | 10 | 6.18 | Fast (ms) | Faster (ms/phi) |
| Dull (C fiber) | 20 | 12.36 | Slow (s) | Slower (s x phi) |
| Chronic | 30 | 18.54 | None | None |
| Referred | 15 | 9.27 | Variable | Variable |
| Phantom | 5 | 3.09 | None | None |
| Allodynia | 8 | 4.94 | None | None |
| Hyperalgesia | 3 | 1.85 | None | None |
| Nociceptive | 12 | 7.41 | Moderate | Moderate/phi |

---

## Table 15: Phi-Autonomic Nervous System

| Parameter | Sympathetic | Phi-Symp | Parasympathetic | Phi-Parasymp |
|-----------|-------------|----------|----------------|-------------|
| Heart rate effect | +30 bpm | +18.5 bpm | -20 bpm | -12.4 bpm |
| Pupil dilation | +2 mm | +1.24 mm | -1 mm | -0.618 mm |
| Bronchodilation | +15% | +9.3% | -10% | -6.18% |
| GI motility | -20% | -12.4% | +30% | +18.5% |
| Blood glucose | +20% | +12.4% | -10% | -6.18% |
| Sweat production | +50% | +31% | -20% | -12.4% |
| Bladder contraction | -30% | -18.5% | +40% | +24.7% |
| Saliva production | -40% | -24.7% | +50% | +31% |

---

## Table 16: Phi-Neurological Disorder Biomarkers

| Disorder | Biomarker | Standard Level | Phi-Level | Change |
|----------|-----------|---------------|-----------|--------|
| Alzheimer's | Amyloid-beta 42 | 500 pg/mL | 500/phi = 309 | -38% |
| Parkinson's | Dopamine (putamen) | 100% | 100/phi = 61.8% | -38% |
| Huntington's | GABA (striatum) | 100% | 100/phi = 61.8% | -38% |
| MS | Myelin basic protein | 5 ng/mL | 5/phi = 3.09 | -38% |
| Epilepsy | GABA/glutamate ratio | 0.3 | 0.3/phi = 0.185 | -38% |
| ALS | SOD1 activity | 100% | 100/phi = 61.8% | -38% |
| PTSD | Cortisol level | High | High x phi | +62% |
| Depression | Serotonin | Low | Low/phi = Lower | -38% |

---

## Table 17: Phi-Neural Network Hyperparameters

| Parameter | Standard Search | Phi-Search Range | Optimal | Phi-Optimal |
|-----------|----------------|-----------------|---------|-------------|
| Learning rate | [1e-5, 1e-1] | [phi^(-5), phi^5] x LR | 1e-3 | 6.18e-4 |
| Batch size | [16, 512] | [phi^(-2), phi^2] x BS | 128 | 79 |
| Hidden units | [64, 1024] | [phi^(-1), phi^1] x HU | 256 | 158 |
| Dropout | [0.1, 0.5] | [phi^(-2), phi^2] x D | 0.3 | 0.185 |
| Weight decay | [1e-6, 1e-2] | [phi^(-3), phi^3] x WD | 1e-4 | 6.18e-5 |
| Momentum | [0.8, 0.99] | [phi^(-1), phi^1] x M | 0.9 | 0.556 |
| Gradient clip | [0.5, 5.0] | [phi^(-1), phi^1] x GC | 1.0 | 0.618 |
| Warmup steps | [0, 1000] | [phi^(-1), phi^1] x WU | 100 | 62 |

---

## Table 18: Phi-Neuromodulation Drug Effects

| Drug | Target | Effect Size | Phi-Effect | Duration (hr) | Phi-Duration |
|------|--------|------------|-----------|---------------|-------------|
| SSRI | Serotonin | 0.4 | 0.247 | 24 | 14.8 |
| SNRI | NE/5-HT | 0.5 | 0.309 | 24 | 14.8 |
| Benzodiazepine | GABA | 0.7 | 0.433 | 8 | 4.95 |
| Stimulant | DA/NE | 0.6 | 0.371 | 6 | 3.71 |
| Antipsychotic | D2 | 0.8 | 0.494 | 24 | 14.8 |
| Mood stabilizer | Glutamate | 0.3 | 0.185 | 12 | 7.41 |
| Alpha agonist | NE | 0.4 | 0.247 | 12 | 7.41 |
| Acetylcholinesterase | ACh | 0.5 | 0.309 | 8 | 4.95 |

---

## Table 19: Phi-Neural Oscillation Coherence

| Brain Region Pair | Coherence | Phi-Coherence | Phase Lock | Phi-Phase Lock |
|-------------------|-----------|---------------|------------|----------------|
| Prefrontal-Parietal | 0.7 | 0.433 | 0.8 | 0.494 |
| Hippocampal-Prefrontal | 0.6 | 0.371 | 0.7 | 0.433 |
| Amygdala-Prefrontal | 0.5 | 0.309 | 0.6 | 0.371 |
| Thalamocortical | 0.8 | 0.494 | 0.9 | 0.556 |
| Corticostriatal | 0.6 | 0.371 | 0.7 | 0.433 |
| Cerebellothalamic | 0.7 | 0.433 | 0.8 | 0.494 |
| Insular-Amygdala | 0.5 | 0.309 | 0.6 | 0.371 |
| Anterior cingulate-PFC | 0.6 | 0.371 | 0.7 | 0.433 |

---

## Table 20: Phi-Consciousness State Classification

| State | Integrated Info (Phi) | Phi-Threshold | Awareness Score | Phi-Score |
|-------|----------------------|---------------|----------------|-----------|
| Deep sleep | 0.1 | 0.062 | 0.1 | 0.062 |
| Dreaming | 0.3 | 0.185 | 0.4 | 0.247 |
| Sedation | 0.2 | 0.124 | 0.2 | 0.124 |
| Minimal consciousness | 0.4 | 0.247 | 0.3 | 0.185 |
| Vegetative state | 0.15 | 0.093 | 0.05 | 0.031 |
| Locked-in | 0.8 | 0.494 | 0.9 | 0.556 |
| Normal wakefulness | 1.0 | 0.618 | 1.0 | 0.618 |
| Flow state | 1.2 | 0.742 | 1.2 | 0.742 |
| Deep meditation | 1.5 | 0.927 | 1.4 | 0.864 |
| Psychedelic | 1.3 | 0.802 | 1.3 | 0.802 |

