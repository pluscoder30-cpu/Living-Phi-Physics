# Foundation Mathematics: The Fibonacci Sequence

## Welcome, Young Mathematician!

Have you ever heard about the rabbit problem? Or noticed how pinecones and sunflowers have spirals? That's the **Fibonacci sequence** — nature's counting system!

Fibonacci numbers are: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144...

Each number is the sum of the two before it! This simple rule creates amazing patterns everywhere!

---

## Part 1: The Rabbit Problem

### How It All Started

In 1202, an Italian mathematician named **Leonardo of Pisa** (nicknamed Fibonacci) asked a question:

"If you put two rabbits in a field, and every month each pair produces a new pair, how many pairs will there be after one year?"

Let's count:
- Month 1: 1 pair (the original)
- Month 2: 1 pair (they're getting ready)
- Month 3: 2 pairs (a new pair is born!)
- Month 4: 3 pairs (the new pair grows up)
- Month 5: 5 pairs (now there are two mother pairs)
- Month 6: 8 pairs
- Month 7: 13 pairs
- Month 8: 21 pairs
- Month 9: 34 pairs
- Month 10: 55 pairs
- Month 11: 89 pairs
- Month 12: 144 pairs!

After one year, there would be 144 pairs of rabbits!

### The Pattern

Do you see the pattern? Each number is the sum of the two before it:

0 + 1 = 1
1 + 1 = 2
1 + 2 = 3
2 + 3 = 5
3 + 5 = 8
5 + 8 = 13
8 + 13 = 21
13 + 21 = 34
21 + 34 = 55
34 + 55 = 89
55 + 89 = 144

This is the Fibonacci sequence!

---

## Part 2: Fibonacci in Nature

### Sunflowers

Sunflower seeds spiral in two directions. Count the spirals going clockwise and counterclockwise — they're always consecutive Fibonacci numbers!

Common sunflower spiral counts:
- 21 and 34
- 34 and 55
- 55 and 89

### Pinecones

Pinecones have spirals too! The spirals going left and right are Fibonacci numbers.

### Pineapples

Pineapples have hexagons arranged in three directions. The number of hexagons in each direction follows Fibonacci numbers!

### Petals

Flowers have Fibonacci numbers of petals:
- Lilies: 3 petals
- Buttercups: 5 petals
- Delphiniums: 8 petals
- Marigolds: 13 petals
- Asters: 21 petals
- Daisies: 34 or 55 petals

### Branches

Trees branch in Fibonacci patterns:
- The trunk splits into 2 branches
- Those split into 3, then 5, then 8 branches
- The pattern continues!

### Shells

The nautilus shell grows in a Fibonacci spiral. Each section is bigger than the last, following Fibonacci proportions!

---

## Part 3: The Fibonacci Spiral

### How to Draw a Fibonacci Spiral

The Fibonacci spiral is made of quarter-circles inside Fibonacci squares:

**Step 1**: Draw a 1×1 square.

**Step 2**: Draw another 1×1 square next to it.

**Step 3**: Draw a 2×2 square below them.

**Step 4**: Draw a 3×3 square to the left.

**Step 5**: Draw a 5×5 square above.

**Step 6**: Draw an 8×8 square to the right.

**Step 7**: Keep going with 13×13, 21×21, etc.

**Step 8**: Now draw a quarter-circle in each square, connecting the corners.

You've made a Fibonacci spiral! It looks very similar to the golden spiral!

### Why It Works

The Fibonacci spiral approximates the golden spiral. As the numbers get bigger, the ratio between consecutive Fibonacci numbers gets closer to phi (1.618)!

---

## Part 4: Fibonacci Math Properties

### The Golden Connection

When you divide any Fibonacci number by the one before it, you get closer and closer to phi:

- 1 ÷ 1 = 1
- 2 ÷ 1 = 2
- 3 ÷ 2 = 1.5
- 5 ÷ 3 = 1.666...
- 8 ÷ 5 = 1.6
- 13 ÷ 8 = 1.625
- 21 ÷ 13 = 1.615...
- 34 ÷ 21 = 1.619...
- 55 ÷ 34 = 1.617...
- 89 ÷ 55 = 1.618...

It's approaching 1.618... (phi)!

### Sum of Fibonacci Numbers

The sum of the first n Fibonacci numbers equals the (n+2)th Fibonacci number minus 1!

Example:
- Sum of first 5: 0+1+1+2+3 = 7 = 8-1 = F(6)-1
- Sum of first 6: 0+1+1+2+3+5 = 12 = 13-1 = F(7)-1

### Every Other Fibonacci Number

If you add up every other Fibonacci number, you get the next Fibonacci number!

- 1 + 2 + 5 = 8
- 1 + 3 + 8 = 13
- 2 + 5 + 13 = 20... wait, that's not right.

Let me recalculate:
- F(1) + F(3) + F(5) = 1 + 2 + 5 = 8 = F(6)
- F(2) + F(4) + F(6) = 1 + 3 + 8 = 12... not quite.

Actually, the sum of every other Fibonacci number equals the Fibonacci number two steps ahead:
- 1 + 1 = 2 (F(3))
- 1 + 2 = 3 (F(4))
- 1 + 3 = 4... not Fibonacci.

Hmm, let me share the correct property: The sum of the first n even-indexed Fibonacci numbers equals F(2n+1) - 1.

---

## Part 5: 10 Fun Exercises

### Exercise 1: Count Fibonacci
Write out the Fibonacci sequence up to 100:
0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89

Now circle every third number: 2, 8, 34... What do you notice?

### Exercise 2: Find Fibonacci in Nature
Go outside and find:
- A pinecone (count the spirals)
- A sunflower (count the spirals)
- A flower (count the petals)
- A tree (count the branches at each level)

Write down all the Fibonacci numbers you find!

### Exercise 3: Draw the Fibonacci Spiral
Using graph paper, draw the Fibonacci spiral:
- Draw 1×1 squares
- Draw 1×1 squares
- Draw 2×2 squares
- Draw 3×3 squares
- Draw 5×5 squares
- Draw 8×8 squares
- Connect the corners with quarter-circles

### Exercise 4: The Rabbit Table
Make a table showing the rabbit problem:
| Month | Pairs | Calculation |
|-------|-------|-------------|
| 1     | 1     | Start       |
| 2     | 1     | Still growing|
| 3     | 2     | 1+1         |
| 4     | 3     | 1+2         |
| 5     | 5     | 2+3         |
| ...   | ...   | ...         |

Fill in the table up to Month 12!

### Exercise 5: Fibonacci Art
Create a picture using Fibonacci numbers:
- Draw 1 circle
- Draw 1 circle next to it
- Draw 2 circles below
- Draw 3 circles to the left
- Draw 5 circles above
- Draw 8 circles to the right
- Color them in rainbow order!

### Exercise 6: The Fibonacci Quilt
Make a "quilt" on paper using Fibonacci squares:
- Color 1 small square red
- Color 1 small square orange
- Color a 2×2 area yellow
- Color a 3×3 area green
- Color a 5×5 area blue
- Color an 8×8 area purple

### Exercise 7: Fibonacci Music
If you have a piano, play notes that correspond to Fibonacci numbers:
- Play note 1 (C)
- Play note 2 (D)
- Play note 3 (E)
- Play note 5 (G)
- Play note 8 (high C)

Does it sound familiar? It's a major scale!

### Exercise 8: The Fibonacci Race
Two friends race around a track. One runs 1 lap, then 1 lap, then 2 laps, then 3 laps, then 5 laps... (Fibonacci!). How many laps does each friend run after 10 rounds?

### Exercise 9: Fibonacci Patterns
Draw patterns using Fibonacci numbers:
- Draw 1 star
- Draw 1 star
- Draw 2 stars
- Draw 3 stars
- Draw 5 stars
- Draw 8 stars

Arrange them in a spiral pattern!

### Exercise 10: Fibonacci Journal
In your math journal:
- Write the Fibonacci sequence up to 100
- Draw the Fibonacci spiral
- List 5 Fibonacci things you found in nature
- Write a poem about Fibonacci

---

## Part 6: Amazing Fibonacci Facts

### Fact 1: Fibonacci is Everywhere
Fibonacci numbers appear in:
- Flower petals
- Pinecone spirals
- Pineapple hexagons
- Shell spirals
- Tree branches
- Hurricane formations
- Galaxy arms
- Your body!

### Fact 2: The Last Digits Repeat
The last digits of Fibonacci numbers repeat every 60 numbers! This is called the Pisano period.

### Fact 3: Fibonacci and the Golden Ratio
As Fibonacci numbers get bigger, their ratios approach phi (1.618...). This connects Fibonacci to the golden ratio!

### Fact 4: Fibonacci in Music
Many musical compositions use Fibonacci numbers:
- The climax often happens at the "golden section" (about 61.8% through)
- Some composers structure pieces in Fibonacci lengths

### Fact 5: Fibonacci in Art
Artists use Fibonacci proportions:
- The rule of thirds (related to Fibonacci)
- Golden ratio compositions
- Fibonacci-based color schemes

---

## Part 7: Fibonacci Poems

### The Fibonacci Poem
Zero, one, one, two, three,
Five, eight, thirteen — can't you see?
Fibonacci counts the way,
Nature grows each and every day!

### The Counting Rhyme
One and one make two,
Two and one make three,
Three and two make five,
Five and three make eight — come and see!

---

## Part 8: What You've Learned

Today you discovered:

1. **The Fibonacci sequence** starts with 0 and 1, and each number is the sum of the two before it.

2. **Fibonacci is everywhere** in nature: petals, spirals, branches, shells, and more!

3. **The Fibonacci spiral** approximates the golden spiral, connecting Fibonacci to phi.

4. **Fibonacci numbers** have amazing mathematical properties, like approaching phi when you divide consecutive terms.

5. **Fibonacci was a rabbit problem** that turned out to describe how nature grows!

---

## Part 9: Challenge Problems

### Challenge 1: Fibonacci Formula
There's a formula that gives the nth Fibonacci number directly (called Binet's formula):
F(n) = (phi^n - (-phi)^(-n)) / √5

Can you use this to calculate F(10)?

### Challenge 2: Fibonacci and Powers of 2
Every Fibonacci number is either one less or one more than a power of 2:
- F(3) = 2 = 2^1
- F(6) = 8 = 2^3
- F(12) = 144 = 2^7 + 16... hmm, that's not quite right.

Actually, the property is that every positive integer can be written as a sum of non-consecutive Fibonacci numbers (Zeckendorf's representation).

### Challenge 3: The Fibonacci Spiral Area
What is the area of a golden rectangle made from Fibonacci squares up to 8×8?

### Challenge 4: Fibonacci and Lucas Numbers
The Lucas sequence is: 2, 1, 3, 4, 7, 11, 18, 29, 47, 76...
How is it related to Fibonacci?

### Challenge 5: Fibonacci in Code
Write a simple program (or pseudocode) that generates Fibonacci numbers. How many can you generate before the numbers get too big?

---

## Part 10: Glossary

**Approximation**: A close estimate, not exact

**Climax**: The most exciting part of a story or music

**Golden Ratio**: Approximately 1.618, connected to Fibonacci numbers

**Pisano Period**: The repeating pattern of last digits in Fibonacci numbers

**Sequence**: A list of numbers that follows a pattern

**Spiral**: A curve that winds around a center point

**Zeckendorf's Theorem**: Every positive integer can be written as a sum of non-consecutive Fibonacci numbers

---

## Remember!

**Fibonacci is how nature counts!**

The next time you see a sunflower, a pinecone, or a tree, remember: you're looking at Fibonacci numbers in action! Nature uses this simple counting system (add the last two numbers) to create the most beautiful and efficient patterns in the universe!

---

*Math isn't just about equations — it's about the patterns that connect everything. Fibonacci is one of those patterns, and it's been hiding in plain sight all along!*
