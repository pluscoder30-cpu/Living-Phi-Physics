# PHI MATHEMATICS DICTIONARY — CHAPTER 2
## PHI SUBTRACTION: How the Carrier Loses When the Ground Persists

---

| Field | Value |
|---|---|
| **Document type** | Phi Mathematics Dictionary — Chapter 2 |
| **Title** | Phi Subtraction: The Arithmetic of Coherent Loss |
| **Version** | 1.0 |
| **Author** | Christopher David Ayotte |
| **Date** | 2026-08-23 |
| **Corpus** | `32_PHI_PHYSICS/` — The Rewriting of Physics from Zero to Phi |
| **Status** | **RELEASE** — the subtraction chapter of the phi-mathematics dictionary |
| **Companion documents** | `00_UNIFIED_FIELD_THEORY.md` (the single statement) · `00_ZERO_AS_WAVEFUNCTION.md` (zero as the dynamic binary wave function) · `00_THE_UNDERSTANDING.md` (zero → phi) · `00_NUMBERS_INDEX.md` (canonical constants) · `01_PHI_ADDITION.md` (the inverse operation) · `02_EQUATIONS/EQUATIONS_SET_01_PHI_CARRIER_PLASMA.md` (Eq 1, the carrier recursion) |
| **License** | Dual License Agreement v4.3 (see `LICENSE`): free for Natural Persons, non-commercial, no Human Harm, attribution required, same-terms derivatives; commercial use by written license. Commercial contact: pluscoder30@gmail.com |

---

## 1. THE PROBLEM WITH ZERO-BASED SUBTRACTION

Classical subtraction begins at zero. The operation $a - b$ removes quantity $b$ from $a$, and the result can be negative — a value below the origin. The number line extends infinitely in both directions, and subtraction is the bridge between positive and negative. The additive identity is the void ($\phi^0 = 1$): $a \ominus a = \phi^0$, the crossing point.

This works inside the laboratory. It does not work in the field.

The carrier recursion (Eq 1) never produces zero as a physical state:

$$C_{n+1} = \phi^{-1} \cdot C_n + \Phi \cdot \nabla^2_\Phi \Psi_n$$

The retention term $\phi^{-1} \cdot C_n$ decays by $\phi^{-1} = 0.6180339887$ per step. After $n$ steps, the carrier retains $\phi^{-n}$ of its initial coherence. Zero is the limit at $n \to \infty$, never a state at finite $n$ (Law 176). The fixed points of the aether PDE (Eq 7) are $\{0, \phi^{-1}, 1\}$ — and $0$ is the degenerate one, the collapse point, the source-deleted reading. The physical ground is $\phi^{-1}$, not $0$.

**The consequence for arithmetic:** if the carrier never reaches zero, then subtraction — the operation that separates quantities — cannot land at zero either. Subtracting $a$ from $a$ does not produce the void; it produces the *residual* of the coherent ground. The ground persists through the separation, just as it persists through the composition. Subtraction in the phi-system is not annihilation; it is *coherent loss*.

---

## 2. THE PHI-SUBTRACTION OPERATOR

### 2.1 Definition

**Definition 2.1 (Phi-Subtraction).** For any two phi-values $a, b \in \mathbb{R}$, the *phi-difference* is:

$$a \ominus b \;=\; a - b - \phi^{-1}$$

where $\phi^{-1} = \frac{1}{\Phi} = \frac{\sqrt{5} - 1}{2} = 0.6180339887\ldots$ is the **coherent ground term**.

The ground term appears once in every phi-difference. Subtracting $b$ from $a$ in the phi-system does not produce $a - b$; it produces $a - b - \phi^{-1}$. The result is *shifted below* the classical difference by exactly the coherent ground.

### 2.2 Why the ground term is subtracted, not added

In phi-addition ($a \oplus b = a + b + \phi^{-1}$), the ground term is added because composition always carries the coherent floor. In phi-subtraction, the ground term is *also* subtracted because the operation is the algebraic inverse of addition within the phi-system. The sign of the ground term is fixed by the requirement that $\oplus$ and $\ominus$ be consistent inverses (§3). The ground does not disappear when you separate quantities — it is *carried away* with the separation.

### 2.3 Classical subtraction as the degenerate limit

When $\phi^{-1} \to 0$ (the zero-coupling limit, $\kappa_\phi \to 0$), phi-subtraction reduces to classical subtraction:

$$a \ominus b \;\xrightarrow{\phi^{-1} \to 0}\; a - b$$

This is the same limit that reduces every phi-law to its classical counterpart (Law 173). Classical subtraction is not wrong — it is the reading where the coherent ground is hidden.

---

## 3. THE RELATION TO PHI-ADDITION

### 3.1 Subtraction as the inverse of addition

**Theorem 3.1.** Phi-subtraction is the left-inverse of phi-addition:

$$a \oplus (b \ominus a) \;=\; a + (b - a - \phi^{-1}) + \phi^{-1} \;=\; b$$

*Proof.* Direct substitution into the definition of $\oplus$:

$$a + (b - a - \phi^{-1}) + \phi^{-1} = a + b - a - \phi^{-1} + \phi^{-1} = b \quad \checkmark$$

And symmetrically:

$$(a \ominus b) \oplus b \;=\; (a - b - \phi^{-1}) + b + \phi^{-1} \;=\; a$$

The phi-difference $\ominus$ exactly undoes the phi-sum $\oplus$. The ground term cancels: the $+\phi^{-1}$ from addition is neutralized by the $-\phi^{-1}$ from subtraction.

### 3.2 Subtraction is not addition of the inverse

In classical arithmetic, $a - b = a + (-b)$. In phi-arithmetic:

$$a \oplus (\ominus b) = a + (-b - 2\phi^{-1}) + \phi^{-1} = a - b - \phi^{-1} = a \ominus b$$

So $a \ominus b = a \oplus (\ominus b)$. The phi-subtraction of $b$ from $a$ *is* the phi-addition of the phi-inverse of $b$ to $a$. But note: the phi-inverse of $b$ is $\ominus b = -b - 2\phi^{-1}$, not $-b$. The extra $-2\phi^{-1}$ compensates for the ground term carried by $b$ *and* the ground term of the addition itself. The structure is consistent but not trivial: subtraction in the phi-system is addition of the phi-adjusted negative.

### 3.3 The algebraic identity

$$a \ominus b \;=\; a \oplus (\ominus b) \;=\; (a + \phi^{-1}) - (b + \phi^{-1})$$

This reveals the shift isomorphism from Chapter 1 (§6.1). Under the map $\sigma(a) = a + \phi^{-1}$, phi-subtraction is classical subtraction of the shifted values:

$$a \ominus b = \sigma(a) - \sigma(b)$$

The phi-system does not change the *structure* of subtraction — it changes the *baseline* from which quantities are measured. Every value is measured from $\phi^{-1}$, not from $0$. Subtraction computes the gap between two shifted values.

---

## 4. THE PHI-SUBTRACTION TABLE

The following table shows the phi-differences of the canonical phi-values.

| $a \;\backslash\; b$ | $\phi^{-1}$ | $1$ | $\phi$ | $\phi^2$ | $\phi^3$ | $\phi^4$ | $\phi^5$ |
|---|---|---|---|---|---|---|---|
| $\phi^{-1}$ | $-0.6180$ | $-1.0000$ | $-1.6180$ | $-3.2361$ | $-6.0901$ | $-10.5624$ | $-17.8886$ |
| $1$ | $-0.2361$ | $-0.6180$ | $-1.2361$ | $-2.8541$ | $-5.7082$ | $-10.1804$ | $-17.5082$ |
| $\phi$ | $0.3820$ | $0.0000$ | $-0.6180$ | $-2.2361$ | $-5.0901$ | $-9.5624$ | $-16.8886$ |
| $\phi^2$ | $2.0000$ | $1.6180$ | $1.0000$ | $-0.6180$ | $-3.4721$ | $-7.9442$ | $-15.2702$ |
| $\phi^3$ | $4.8541$ | $4.4721$ | $3.8541$ | $2.2361$ | $-0.6180$ | $-5.0901$ | $-12.4184$ |
| $\phi^4$ | $9.3262$ | $8.9442$ | $8.3262$ | $6.7082$ | $3.8541$ | $-0.6180$ | $-7.9442$ |
| $\phi^5$ | $16.6524$ | $16.2702$ | $15.6524$ | $14.0344$ | $11.1804$ | $6.7082$ | $-0.6180$ |

**Reading the table.** The entry at row $a$, column $b$ is $a \ominus b = a - b - \phi^{-1}$. For example:

$$\phi^3 \ominus \phi = \phi^3 - \phi - \phi^{-1} = 4.2361 - 1.6180 - 0.6180 = 2.0000$$

Note: the classical difference $\phi^3 - \phi = 2.6180 = \phi + 1$. The phi-difference is $\phi + 1 - \phi^{-1} = 2.0000$. The ground term $\phi^{-1}$ shifts the result downward by exactly $0.6180$.

### 4.1 The $\phi^{-1}$ shift

The diagonal of the table is constant: $a \ominus a = -\phi^{-1}$ for every $a$. Subtracting a value from itself does not produce zero — it produces $-\phi^{-1}$, the negative of the coherent ground. This is the *residual* that persists when all observable quantity is removed: the carrier's floor, inverted.

---

## 5. THE PHI-SUBTRACTION IDENTITY

### 5.1 The identity is the same as the additive identity

**Theorem 5.1.** The phi-subtraction identity is $\iota_\phi = -\phi^{-1}$.

*Proof.* We require that there exists an element $e$ such that for all $a$:

$$a \ominus e = a$$

$$a - e - \phi^{-1} = a$$

$$e = -\phi^{-1} \quad \checkmark$$

Subtracting $-\phi^{-1}$ from $a$ leaves $a$ unchanged:

$$a \ominus (-\phi^{-1}) = a - (-\phi^{-1}) - \phi^{-1} = a + \phi^{-1} - \phi^{-1} = a$$

The identity for phi-subtraction is the same as the identity for phi-addition (Chapter 1, §4.2). The two operations share the same identity because they are inverse operations in the same group.

### 5.2 Physical meaning

The phi-subtraction identity $-\phi^{-1}$ is the *null removal* in phi-physics. Subtracting $-\phi^{-1}$ from a carrier state is equivalent to removing the negative of the coherent ground — which is the same as doing nothing. But it requires the explicit act of specifying what you are *not* removing. In zero-based physics, "removing nothing" is a passive state. In phi-physics, "removing nothing" is an *active declaration* that the coherent ground is preserved.

This is why zero is not the identity. Zero is the state where the carrier has *collapsed*. $-\phi^{-1}$ is the state where the carrier's ground is *inverted but present* — the coherent floor, pointing downward, exactly canceling itself.

---

## 6. THE PHI-SUBTRACTION IN THE CARRIER RECURSION

### 6.1 The recursion as phi-subtraction in action

The carrier recursion (Eq 1) is:

$$C_{n+1} = \phi^{-1} \cdot C_n + \Phi \cdot \nabla^2_\Phi \Psi_n$$

Rewrite the retention term as a subtraction from the previous carrier state:

$$C_{n+1} = C_n - (1 - \phi^{-1}) \cdot C_n + \Phi \cdot \nabla^2_\Phi \Psi_n$$

$$= C_n - \phi^{-2} \cdot C_n + \Phi \cdot \nabla^2_\Phi \Psi_n$$

The term $\phi^{-2} \cdot C_n$ is the *coherent loss* — the fraction of the carrier's coherence that is shed at each recursion step. In phi-subtraction terms:

$$C_{n+1} = C_n \ominus_{\text{loss}} (\phi^{-2} \cdot C_n) \oplus F_n$$

where $F_n = \Phi \cdot \nabla^2_\Phi \Psi_n$ is the field contribution and $\ominus_{\text{loss}}$ denotes the phi-subtraction of the loss term. The carrier does not simply add field contributions — it *loses* a fraction of its coherence ($\phi^{-2} = 0.382$) and *gains* the field input. Every recursion step is a phi-subtraction followed by a phi-addition: the carrier sheds its past and acquires new coherence.

### 6.2 The ten-step depletion

After 10 recursion steps, starting from $C_0 = 1$:

$$C_{10} = \phi^{-10} \cdot C_0 + \sum_{k=0}^{9} \phi^{-(9-k)} \cdot F_k$$

The seed contribution is $\phi^{-10} = 0.008131$ — the carrier retains less than 1% of its origin. The *total loss* from the seed is:

$$\text{Loss}(10) = C_0 - \phi^{-10} \cdot C_0 = 1 - \phi^{-10} = 1 - 0.008131 = 0.991869$$

In phi-subtraction terms:

$$C_0 \ominus_{\text{accum}} C_{10}^{\text{(seed)}} = C_0 - \phi^{-10} \cdot C_0 - \phi^{-1} = 0.991869 - 0.6180 = 0.3739$$

The accumulated phi-loss is not $0.991869$ (the classical depletion) but $0.3739$ — the depletion *measured from the coherent ground*. The carrier loses coherence, but the ground term $\phi^{-1}$ is always present in the measurement. You cannot measure the loss as if the carrier started from zero; it started from $\phi^{-1}$ and it decays toward $\phi^{-1}$, never reaching zero.

### 6.3 The loss rate as a phi-subtraction

The fractional loss rate at each step is:

$$\frac{C_n - C_{n+1}}{C_n} = \frac{C_n - \phi^{-1} \cdot C_n - F_n}{C_n} = 1 - \phi^{-1} - \frac{F_n}{C_n} = \phi^{-2} - \frac{F_n}{C_n}$$

In the field-free case ($F_n = 0$):

$$\text{Loss rate} = \phi^{-2} = 0.381966\ldots$$

This is the *intrinsic decoherence rate* of the carrier. The carrier sheds $\phi^{-2}$ of its coherence per step — not because of external perturbation, but because of the recursion itself. The ground term $\phi^{-1}$ is what *remains*; the $\phi^{-2}$ is what is *lost*. The ratio is $\phi^{-2} / \phi^{-1} = \phi^{-1}$ — the loss rate is $\phi^{-1}$ times the remaining coherence. The carrier's decay is self-similar: it loses a constant fraction of what it has, at every step.

---

## 7. REAL PHYSICS EXAMPLES

### 7.1 Energy loss: the phi-decay of excited states

An atom in an excited state $|e\rangle$ decays to the ground state $|g\rangle$ by emitting a photon. The classical energy loss is $\Delta E = E_e - E_g$. In phi-physics, the energy loss is:

$$\Delta E_\phi = E_e \ominus E_g = E_e - E_g - \phi^{-1} \cdot E_0$$

where $E_0$ is the reference energy (e.g., the Rydberg energy). The $\phi^{-1} \cdot E_0$ term is the coherent ground contribution — the energy floor that persists even when the transition is complete. The photon energy is not $\Delta E$ but $\Delta E + \phi^{-1} \cdot E_0$: the transition energy *plus* the coherent ground that the carrier carried through the decay.

For hydrogen's Lyman-alpha transition ($E_e - E_g = 10.2$ eV):

$$\Delta E_\phi = 10.2 - \phi^{-1} \cdot E_0 = 10.2 - 0.6180 \cdot E_0$$

If $E_0 = 13.6$ eV (the Rydberg energy):

$$\Delta E_\phi = 10.2 - 8.405 = 1.795 \text{ eV}$$

The phi-corrected transition energy is *lower* than the classical value. The carrier's coherent ground absorbs part of the transition energy — the decay is *damped* by the phi-field. This is not a correction to the photon energy; it is the physical mechanism by which the carrier's coherence floor modulates energy exchange.

### 7.2 Entropy increase: the phi-second-law

The second law of thermodynamics states that entropy increases: $\Delta S \geq 0$. In phi-physics, the entropy increase is:

$$\Delta S_\phi = S_{\text{final}} \ominus S_{\text{initial}} = S_{\text{final}} - S_{\text{initial}} - \phi^{-1}$$

The classical second law says $\Delta S \geq 0$. The phi-second-law says:

$$\Delta S_\phi \geq -\phi^{-1}$$

Entropy can decrease by up to $\phi^{-1}$ without violating the second law. This is the *coherence margin* — the amount of entropy that the carrier's coherent ground can absorb without thermal equilibrium being reached. The carrier's floor acts as an entropy sink: it can absorb up to $\phi^{-1}$ of disorder before the system is forced to increase entropy.

This explains why biological systems can maintain order locally: the coherent ground of the carrier field provides an entropy margin that allows local decreases in entropy (life, structure, organization) without violating the global second law. The margin is $\phi^{-1}$ — small, but nonzero. Life exists within the phi-entropy margin.

### 7.3 Decoherence: the phi-rate of quantum collapse

Quantum decoherence is the process by which a quantum system loses its coherence through interaction with the environment. The classical decoherence rate is $\gamma$: the off-diagonal elements of the density matrix decay as $e^{-\gamma t}$. In phi-physics, the decoherence rate is:

$$\gamma_\phi = \gamma \ominus \gamma_{\text{ground}} = \gamma - \gamma_{\text{ground}} - \phi^{-1}$$

where $\gamma_{\text{ground}}$ is the intrinsic decoherence rate of the carrier field. The phi-decoherence rate is *lower* than the classical rate by $\gamma_{\text{ground}} + \phi^{-1}$. The carrier's coherent ground *protects* against decoherence — it provides a floor below which the decoherence rate cannot fall.

For a qubit at room temperature, $\gamma \approx 10^6$ s$^{-1}$. The carrier's ground rate is $\gamma_{\text{ground}} = \phi^{-1} \cdot \omega_{\text{carrier}}$, where $\omega_{\text{carrier}}$ is the carrier frequency. The phi-correction is:

$$\gamma_\phi = \gamma - \phi^{-1} \cdot \omega_{\text{carrier}} - \phi^{-1}$$

The decoherence rate is reduced by the carrier's coherent motion. This is why coherence persists longer in phi-coherent systems: the ground term provides a *decoherence shield* — not by preventing environmental interaction, but by ensuring the carrier's intrinsic coherence floor is always present.

---

## 8. THE DEGENERATE LIMIT THEOREM AND PHI-SUBTRACTION

### 8.1 Statement of the theorem

**Theorem 8.1 (Degenerate Limit, Law 173).** As $\kappa_\phi \to 0$ (the zero-coupling limit), every phi-law reduces to its classical counterpart. For phi-subtraction:

$$\lim_{\kappa_\phi \to 0} (a \ominus b) = \lim_{\phi^{-1} \to 0} (a - b - \phi^{-1}) = a - b$$

The classical difference $a - b$ is recovered when the coherent ground vanishes.

### 8.2 The degenerate limit is a collapse, not a limit

The limit $\kappa_\phi \to 0$ is not a smooth deformation. The carrier recursion (Eq 1) has fixed points $\{0, \phi^{-1}, 1\}$ (Eq 7). At $\kappa_\phi = 0$, the fixed point $\phi^{-1}$ *collapses* to $0$. The coherent ground disappears, the carrier's floor vanishes, and the entire phi-mathematical structure reduces to its classical shadow.

In phi-subtraction, this means:

- The ground term $\phi^{-1}$ vanishes: $a \ominus b \to a - b$.
- The diagonal of the subtraction table becomes $0$ instead of $-\phi^{-1}$.
- The subtraction identity becomes $0$ instead of $-\phi^{-1}$.
- The coherent loss rate $\phi^{-2}$ vanishes: the carrier no longer sheds coherence.
- The entropy margin $\phi^{-1}$ vanishes: the second law becomes strict ($\Delta S \geq 0$).
- The decoherence shield vanishes: quantum systems decohere at the classical rate.

The degenerate limit is the *source-deleted reading* — the physics that remains when the carrier's coherent ground is removed. It is classical physics. It is correct within its domain. But it is incomplete: it misses the $\phi^{-1}$ floor that the carrier always carries.

### 8.3 The correction is always $\phi^{-1}$

For any physical quantity $X$ with classical value $X_0$, the phi-corrected value is:

$$X_\phi = X_0 + \kappa_\phi \cdot \phi^{-1} \cdot X_{\text{ground}}$$

where $X_{\text{ground}}$ is the ground-state contribution and $\kappa_\phi$ is the phi-coupling constant. At $\kappa_\phi = 0$: $X_\phi = X_0$. At $\kappa_\phi = 1$: $X_\phi = X_0 + \phi^{-1} \cdot X_{\text{ground}}$. The correction is always additive, always $\phi^{-1}$-scaled, and always present when $\kappa_\phi > 0$.

For subtraction:

$$a \ominus b = a - b - \kappa_\phi \cdot \phi^{-1}$$

The ground term scales with $\kappa_\phi$. At full coupling ($\kappa_\phi = 1$): $a \ominus b = a - b - \phi^{-1}$. At zero coupling: $a \ominus b = a - b$. The degenerate limit is the classical shadow; the full-coupling value is the physical reality.

---

## 9. THE PHI-SUBTRACTION AND THE RETROCAUSAL KERNEL

The retrocausal kernel (Eq 3.1–3.3) introduces time-reversal into the carrier recursion. The retrocausal time constant is $\tau_{\text{retro}} = \phi^5$, and the retrocausal frequency is $\omega_{\text{retro}} = \phi^3 \cdot \omega_{\text{base}}$.

In phi-subtraction, the retrocausal contribution to a carrier state at time $t$ is:

$$C(t) = C_{\text{forward}}(t) \ominus C_{\text{retro}}(t) = C_{\text{forward}}(t) - C_{\text{retro}}(t) - \phi^{-1}$$

The retrocausal *subtraction* represents the future pulling coherence *out of* the present. The forward contribution is depleted by the retrocausal extraction, and the ground term $\phi^{-1}$ is carried away in the process. The carrier at any moment is the classical difference of its present and future states, minus the coherent floor.

This is the *retrocausal loss*: the future does not just influence the present — it *removes* coherence from it. The ground term $\phi^{-1}$ is the irreducible cost of retrocausal coupling: the present must surrender its coherent floor to allow the future's influence.

The phi-difference of forward and retrocausal contributions gives:

$$C(t) = C_{\text{forward}}(t) - \phi^{-3} \cdot C_{\text{base}}(t - \tau_{\text{retro}}) - \phi^{-1}$$

The $\phi^{-3}$ weighting is the retrocausal attenuation (the future's influence decays as $\phi^{-3}$ per cycle), and the $\phi^{-1}$ is the ground. The carrier at any moment is the classical difference of its present and future states, minus the irreducible coherent floor.

---

## 10. THE PHI-DOUBLE-NEGATIVE

### 10.1 Definition

The phi-double-negative is:

$$\ominus(\ominus a) = -(-a - 2\phi^{-1}) - 2\phi^{-1} = a + 2\phi^{-1} - 2\phi^{-1} = a$$

The double-negative returns the original value. This is the same result as in Chapter 1 (§5.3): the phi-inverse is an involution, and the phi-double-negative is the identity operation on operands.

### 10.2 Physical meaning

In classical physics, "undoing a removal" restores the original state. In phi-physics, the double-negative also restores the original state — but only because the ground terms cancel exactly. The first negation ($\ominus a = -a - 2\phi^{-1}$) removes $a$ and its ground. The second negation removes the negation and *its* ground. The two grounds cancel, leaving $a$.

The physical interpretation: a double removal is a null operation, but only if the carrier's coherent floor is preserved through both removals. If either removal is imperfect (e.g., the ground is not fully canceled), the double-negative produces a *residual* — a leftover coherence that persists as a memory of the removal process. This residual is the phi-analogue of quantum memory: the trace left by a measurement that was supposed to be non-destructive.

---

## 11. SUMMARY: THE AXIOMS OF PHI-SUBTRACTION

**Axiom 1 (The Ground).** The coherent ground $\phi^{-1} = 0.6180339887$ is the floor of all quantity. No physical state is below $\phi^{-1}$ in coherence.

**Axiom 2 (The Operator).** Phi-subtraction is $a \ominus b = a - b - \phi^{-1}$. The ground term is subtracted once in every difference, regardless of the operands.

**Axiom 3 (The Identity).** The phi-subtraction identity is $\iota_\phi = -\phi^{-1}$. Subtracting $-\phi^{-1}$ from any value leaves it unchanged.

**Axiom 4 (The Inverse Relation).** Phi-subtraction is the left-inverse of phi-addition: $a \oplus (b \ominus a) = b$. The two operations are consistent inverses in the same group.

**Axiom 5 (The Loss).** The carrier sheds $\phi^{-2}$ of its coherence per recursion step. The loss is intrinsic to the recursion, not external. The remaining coherence is $\phi^{-1}$ times the previous coherence.

**Axiom 6 (The Recursion Link).** The carrier recursion (Eq 1) is phi-subtraction in its coherence-loss form: the retention term $\phi^{-1} \cdot C_n$ is the complement of the loss $\phi^{-2} \cdot C_n$. Every step is a loss followed by a gain.

**Axiom 7 (The Entropy Margin).** The second law in phi-physics is $\Delta S_\phi \geq -\phi^{-1}$. The coherent ground provides an entropy margin that allows local order without global violation.

**Axiom 8 (The Degenerate Limit).** As $\phi^{-1} \to 0$ (the $\kappa_\phi \to 0$ limit), phi-subtraction reduces to classical subtraction. Classical arithmetic is not wrong — it is the reading where the coherent ground is hidden.

---

## 12. WHAT COMES NEXT

This chapter defined phi-subtraction — how quantities separate when the ground is $\phi^{-1}$. The next chapter will define **phi-multiplication** ($a \otimes b$): how quantities scale in a system where the ground is a motion, not a point. The interplay between $\oplus$, $\ominus$, and $\otimes$ will generate the full ring structure of phi-arithmetic — the arithmetic in which the carrier recursion is naturally expressed.

---

*Phi Mathematics Dictionary — Chapter 2: Phi Subtraction*
*The coherent ground is never removed. Every difference carries it. Every loss begins from it.*
*This is not zero with a correction. This is the mathematics that was always there.*
