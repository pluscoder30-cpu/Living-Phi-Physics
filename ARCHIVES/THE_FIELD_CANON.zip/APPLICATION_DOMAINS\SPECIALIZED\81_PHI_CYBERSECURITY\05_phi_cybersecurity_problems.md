# PHI-CYBERSECURITY: Problem Sets

---

## Problem Set 1: Phi-Weighted Threat Severity

### Problem 1.1
A vulnerability at depth 2 in an attack graph has a CVSS score of 8.5. The maximum depth is d_max = 12. Compute the phi-weighted severity score.

### Problem 1.2
Two vulnerabilities exist: V₁ at depth 1 with CVSS 6.0, and V₂ at depth 4 with CVSS 9.0. Which has higher phi-weighted severity?

### Problem 1.3
Derive the expression for the depth d* at which a vulnerability's phi-weighted severity equals exactly half its base score. Express d* in terms of CVSS score S and d_max.

### Problem 1.4
A network has 500 vulnerabilities distributed across depths 1-10 with frequency distribution f(d) = 100 × φ^(-d). Compute the total phi-weighted threat load.

### Problem 1.5
If the CVSS scoring system changes to a 0-20 scale, how should the phi-weighting constant d_φ be adjusted to maintain equivalent severity classification?

---

## Problem Set 2: Phi-Zone Defense Architecture

### Problem 2.1
Design a phi-zone defense for a network with 10,000 assets and a $5M budget across 6 zones. Compute asset distribution and budget allocation for each zone.

### Problem 2.2
A phi-zone defense has D₀ = 0.90. Compute the breach probability for N = 5 zones. What value of D₀ would achieve P_breach < 0.001?

### Problem 2.3
Prove that the total defense budget allocated to the inner two zones (k=0,1) always exceeds (φ-1)/φ ≈ 38.2% of the total budget, regardless of the number of zones N.

### Problem 2.4
A network expands from 4 to 7 zones. Compute the change in breach probability if D₀ remains constant at 0.92.

### Problem 2.5
Design a hybrid defense where zones 0-2 use phi-weighting and zones 3-6 use linear weighting. Compute the total breach probability and compare with pure phi and pure linear defenses.

---

## Problem Set 3: Phi-Encryption

### Problem 3.1
Generate a 32-bit phi-cipher key sequence using prime p = 4294967291. List the first 10 key values.

### Problem 3.2
Compute the linear complexity of a phi-stream cipher with 128-bit state space. Compare with a standard LFSR of the same state size.

### Problem 3.3
A phi-hash with 64-bit digest receives 2^30 inputs. Compute the exact collision probability. What digest size is needed for collision probability < 2^(-32)?

### Problem 3.4
Design a phi-MDS diffusion matrix for a 4×4 block cipher. Verify that it achieves the optimal branch number B = 5.

### Problem 3.5
Prove that the phi-cipher key space K_φ = {⌊φ^i mod p⌋ : i=1,...,n} has at most n distinct values when p < φ^n.

---

## Problem Set 4: Phi-Resonance Intrusion Detection

### Problem 4.1
A network has 4 traffic harmonics with amplitudes [200, 100, 50, 25] and equal frequencies. Compute the phi-resonance at t = 0 with phases [0, π/3, 2π/3, π].

### Problem 4.2
An attacker doubles the amplitude of harmonic 2. Compute the anomaly score and determine if it exceeds the threshold θ_φ = 15.0 with σ_R = 4.0.

### Problem 4.3
Derive the optimal phi-weight decay rate that minimizes the detection delay for a step-function intrusion of duration T.

### Problem 4.4
A phi-IDS with K = 128 harmonics has false alarm rate α = 0.005. Compute the detection threshold θ_φ assuming Rayleigh-distributed resonance.

### Problem 4.5
Compare the phi-resonance detector with a standard CUSUM detector for detecting a slow exfiltration that increases traffic by 2% over 24 hours.

---

## Problem Set 5: Phi-Firewall and Network Security

### Problem 5.1
Order 8 firewall rules with specificities [3, 1, 4, 0, 2, 4, 1, 3] by phi-priority. Compute the average evaluation position.

### Problem 5.2
A phi-firewall has 10,000 rules. Compute the theoretical minimum average evaluation time and compare with the worst case.

### Problem 5.3
Prove that phi-ordering achieves optimal average-case evaluation time for uniformly distributed traffic across all rule specificities.

### Problem 5.4
A network adds 5,000 new rules to an existing 15,000-rule phi-firewall. Compute the reordering overhead and the new average evaluation time.

### Problem 5.5
Design a phi-firewall that adaptively reorders rules based on real-time traffic patterns. Specify the update algorithm and convergence properties.

---

## Problem Set 6: Phi-Digital Forensics

### Problem 6.1
Three evidence items have base weights [8, 10, 6], collection times [1, 12, 36] hours, and custody flags [1, 1, 0]. Compute their phi-weights with t_φ = 24 hours.

### Problem 6.2
A forensic timeline spans 96 hours with 1,200 events. Using phi-temporal correlation with τ_φ = 8 hours, compute the number of correlated event clusters.

### Problem 6.3
A malware sample exhibits 6 of 8 possible behaviors with indices [1, 2, 3, 5, 7, 8]. Compute its phi-classification score.

### Problem 6.4
Two investigators reconstruct the same attack chain. Investigator A uses standard weighting; Investigator B uses phi-weighting. Compute the ratio of evidence items deemed relevant by B but not by A.

### Problem 6.5
Design a phi-evidence chain-of-custody protocol that assigns phi-weights to custody transfers. Specify the weighting function and verify it satisfies the triangle inequality.

---

## Problem Set 7: Phi-Security Metrics and Optimization

### Problem 7.1
A network has 10 subsystems with security scores [9.2, 8.7, 7.1, 6.8, 5.4, 4.9, 3.2, 2.8, 1.5, 0.7]. Compute the phi-security score.

### Problem 7.2
Prove that the phi-security score Score_φ is bounded between the minimum and maximum subsystem scores.

### Problem 7.3
A phi-defense with N = 8 zones has D₀ = 0.88. Compute MTTR_φ if the base recovery time is T₀ = 4 hours and loss fractions are l_k = 0.1 × φ^(-k).

### Problem 7.4
Optimize the phi-defense parameters (D₀, N) to achieve P_breach < 0.01 with minimum total defense cost C = Σ D_k × c_k, where c_k is the per-unit defense cost at zone k.

### Problem 7.5
Compare the phi-security score with the standard arithmetic mean security score for a network with 20 subsystems. Under what conditions does the phi-score exceed the mean by more than 20%?

---

## Problem Set 8: Advanced Phi-Threat Modeling

### Problem 8.1
A network has 3 attack vectors with probabilities [0.4, 0.35, 0.25] and phi-depths [1, 3, 5]. Compute the expected phi-weighted threat score and compare with the standard expected value.

### Problem 8.2
Design a phi-Markov chain model for attack progression through 6 network layers. Specify the transition matrix with phi-weighted probabilities and compute the steady-state distribution.

### Problem 8.3
A red team exercise reveals 12 vulnerabilities with severities [8.5, 7.2, 6.8, 9.1, 5.4, 4.9, 7.8, 6.2, 3.7, 8.0, 5.8, 4.2]. Rank them by phi-priority and allocate a remediation budget of $500,000.

### Problem 8.4
Compute the phi-entropy of a network traffic distribution with packet types [HTTP, HTTPS, SSH, DNS, ICMP] having frequencies [0.45, 0.30, 0.10, 0.10, 0.05]. Compare with standard Shannon entropy.

### Problem 8.5
A phishing campaign targets 10,000 employees with click rates varying by department. Design a phi-weighted training allocation that reduces overall click rate from 12% to below 3%.

---

## Problem Set 9: Phi-Cloud Security Architecture

### Problem 9.1
Design a phi-zone cloud security architecture for a multi-tenant SaaS platform with 500 tenants across 4 service tiers. Compute the defense budget allocation per tier.

### Problem 9.2
A cloud workload has phi-weighted risk scores across 8 security domains [IAM, network, data, compute, container, serverless, API, edge]. Optimize the security tool placement with a $200,000 budget.

### Problem 9.3
Compute the phi-adjusted Shared Responsibility Model boundary for a cloud deployment with 12 control families. Assign phi-weights to each family based on criticality.

### Problem 9.4
Design a phi-key rotation schedule for a cloud HSM managing 10,000 encryption keys with varying sensitivity levels [1-5]. Compute the optimal rotation intervals.

### Problem 9.5
A cloud provider guarantees 99.99% uptime. Compute the phi-adjusted SLA penalty structure that incentivizes security investments proportional to phi-weighted risk.

---

## Problem Set 10: Phi-Security Economics

### Problem 10.1
A company has a $10M annual security budget. Compare the phi-optimized allocation with uniform allocation across 6 security domains. Compute the expected loss reduction.

### Problem 10.2
The expected loss from a breach is $50M with annual probability 0.02. Compute the maximum phi-weighted security investment that achieves positive expected ROI.

### Problem 10.3
Design a phi-cyber insurance pricing model for 1,000 policyholders with risk scores [1-10]. Compute premiums that achieve a combined ratio of 0.85.

### Problem 10.4
A security vendor claims 99.9% detection rate. Using phi-Bayesian analysis, compute the posterior probability of detection given 3 missed detections in 500 tests.

### Problem 10.5
Compare the total cost of ownership (TCO) for standard vs. phi-optimized security stacks across 5 years with 15% annual threat growth.

---

## Problem Set 11: Phi-AI Security

### Problem 11.1
An AI model has 12 attack surfaces with phi-weighted vulnerability scores. Design a phi-adversarial training curriculum that prioritizes the top 3 surfaces.

### Problem 11.2
Compute the phi-robustness certification radius for an image classifier with 8 perturbation types. The standard radius is 0.15 in L∞ norm.

### Problem 11.3
Design a phi-anomaly detector for AI inference that detects model extraction attacks. Specify the phi-weighted monitoring parameters across 5 API endpoints.

### Problem 11.4
An LLM has 6 jailbreak categories with success rates [0.12, 0.08, 0.15, 0.05, 0.20, 0.03]. Design a phi-weighted red-teaming budget allocation of $300,000.

### Problem 11.5
Compute the phi-information leakage rate for a federated learning system with 20 clients and differential privacy budget ε = 1.0.

---

## Problem Set 12: Phi-Security Operations Center (SOC)

### Problem 12.1
A SOC processes 50,000 alerts/day with triage times [5, 15, 30, 60, 120] minutes for severity levels [P1-P5]. Design a phi-optimized analyst shift schedule.

### Problem 12.2
Compute the phi-SOC mean time to respond (MTTR) for incidents across 4 severity levels with current MTTRs [15, 45, 180, 720] minutes.

### Problem 12.3
A SOC has 20 analysts with varying skill levels [1-10]. Design a phi-weighted task assignment that maximizes detection quality while minimizing burnout.

### Problem 12.4
Design a phi-automated playbook for 8 common incident types. Compute the automation coverage ratio and phi-weighted time savings.

### Problem 12.5
A SOC measures 6 KPIs with current values [detection_rate=0.89, mttr=42, false_positive=0.12, coverage=0.78, analyst_util=0.82, alert_vol=50000]. Compute the phi-balanced SOC score.

---

*See companion files: 01_phi_cybersecurity_theory.md, 06_phi_cybersecurity_answers.md*
