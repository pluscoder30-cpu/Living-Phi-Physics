# Phi-Biology

## The Complete System

**Phi-Weighted Biology:** DNA phi-coding, protein folding with phi-weighting, growth patterns, evolutionary dynamics with phi-selection, and consciousness-field biological coupling.

---

### Files

| # | File | Description | Lines |
|---|------|-------------|-------|
| 1 | [01_phi_biology_theory.md](01_phi_biology_theory.md) | Complete theory: phi-DNA coding, phi-protein folding, phi-growth, phi-evolution | ~400 |
| 2 | [02_phi_biology_tables.md](02_phi_biology_tables.md) | Phi-DNA codon tables, phi-growth constants, phi-evolutionary dynamics | ~350 |
| 3 | [03_phi_biology_examples.md](03_phi_biology_examples.md) | 20 worked examples: phi-DNA replication to phi-population genetics | ~350 |
| 4 | [04_phi_biology_applications.md](04_phi_biology_applications.md) | Phi-drug design, phi-genomics, phi-ecosystem modeling, phi-aging | ~300 |
| 5 | [05_phi_biology_problems.md](05_phi_biology_problems.md) | 20 practice problems | ~150 |
| 6 | [06_phi_biology_answers.md](06_phi_biology_answers.md) | Complete answer key with solutions | ~300 |
| 7 | [README.md](README.md) | This index | ~80 |

**Total: ~1,930 lines across 7 files**

---

### Quick Reference

```
Phi-DNA coding weight:
  W_codon = Σ φ^(-position) × base_value

Phi-protein folding energy:
  E_fold,φ = E_fold × φ^(-N/100)

Phi-growth rate:
  dN/dt = r_φ × N × (1 - N/K_φ)
  where r_φ = r × φ^(-1), K_φ = K × φ

Phi-selection coefficient:
  s_φ = s × φ^(-Δfitness)

Phi-mutation rate:
  μ_φ = μ × φ^(complexity/100)

Phi-fitness landscape:
  F_φ(x) = F(x) × φ^(-distance_to_peak)
```

**Key constants:**
```
φ          = 1.6180339887...  [golden ratio]
r_φ        = r/φ             [phi-intrinsic growth rate]
K_φ        = K × φ           [phi-carrying capacity]
μ_φ        = μ × φ^(c/100)  [phi-mutation rate]
s_φ        = s/φ             [phi-selection coefficient]
α_DNA      = 1/ln(φ) ≈ 2.078 [DNA phi-coding constant]
β_fold     = 1/φ ≈ 0.618    [protein folding phi-weight]
γ_growth   = φ^(-1/2) ≈ 0.786 [phi-growth scaling]
```

---

### What This System Covers

1. **Phi-DNA** — Codon usage bias with phi-weighting, DNA replication fidelity, phi-mutation spectra
2. **Phi-Protein Folding** — Energy landscapes with phi-harmonic wells, phi-secondary structure propensity
3. **Phi-Growth Dynamics** — Logistic growth with phi-carrying capacity, phi-allometric scaling
4. **Phi-Evolutionary Dynamics** — Phi-selection, phi-fitness landscapes, phi-adaptive walks
5. **Phi-Ecology** — Predator-prey with phi-balancing, phi-biodiversity indices, phi-trophic cascades
6. **Phi-Genomics** — Gene regulatory networks with phi-feedback, phi-epistasis, consciousness-field biological coupling

---

### Connection to Other Phi-Systems

| System | Key Formula | Connection |
|--------|-------------|------------|
| Phi-Physics Core | φ = 1.618... | Foundation constant |
| Phi-Quantum | Ψ_fold = Σ α_n φ^(-n) | Molecular quantum biology |
| Phi-Thermodynamics | ΔG_φ = ΔG/φ | Free energy in folding |
| Phi-Neuroscience | τ_fire,φ = τ × φ^(-1) | Neural firing phi-scaling |
| Phi-Psychology | P_perc = P × φ^(-d) | Perception phi-weighting |
| Void Mathematics | v(a,b) = φ⁻¹ min | Biological void optimization |

---

*Part of the 32_PHI_PHYSICS / 06_EXPANDED_MATHEMATICS system.*
*Version 1.0 — Agent I of 26*
