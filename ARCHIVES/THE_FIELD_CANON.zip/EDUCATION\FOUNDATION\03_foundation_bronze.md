# Foundation Mathematics: The Bronze Ratio

## Welcome, Young Mathematician!

You've learned about gold (phi) and silver. Now it's time for **bronze** — the third metallic ratio! Bronze is approximately **3.3027756...** and it's the ratio of big spirals in nature!

---

## Part 1: What is the Bronze Ratio?

### The Big Spiral Number

Bronze (let's call it "tau" or just "bronze") is about **3.303**. It's called the third metallic ratio because:
- Gold (phi) = 1.618...
- Silver (sigma) = 2.414...
- Bronze (tau) = 3.303...

Each metallic ratio is bigger than the last!

### The Metallic Family

All three metallic ratios share a special property. They're all solutions to equations like:

- Phi: x² = x + 1
- Silver: x² = 2x + 1
- Bronze: x² = 3x + 1

See the pattern? The number before "x" increases by 1 each time!

### Where Bronze Hides

Bronze shows up in interesting places:

- **Tridecagons**: A 13-sided polygon has bronze proportions in its diagonals!

- **Large Spirals**: Some galaxy arms and hurricane formations use bronze ratios.

- **Metal Mixtures**: Bronze metal itself is a mix of copper and tin, and sometimes the proportions relate to bronze math!

- **Crystal Structures**: Some minerals have crystal lattices with bronze proportions.

### The Bronze Sequence

The bronze sequence works like this:

Start with: 1, 3

Then keep applying: each new term = 3 × previous term + term before that

- 3 × 3 + 1 = 10
- 3 × 10 + 3 = 33
- 3 × 33 + 10 = 109
- 3 × 109 + 33 = 360

Divide consecutive terms:
- 10 ÷ 3 = 3.333...
- 33 ÷ 10 = 3.3
- 109 ÷ 33 = 3.303...
- 360 ÷ 109 = 3.302...

Getting closer to 3.303!

---

## Part 2: The Bronze Rectangle

### How to Draw a Bronze Rectangle

A bronze rectangle has the ratio 1:3.303. Here's how to make one:

**Step 1**: Draw a square that is 5 cm on each side.

**Step 2**: On the bottom side, measure 5 cm from the left corner. Mark that point.

**Step 3**: From that point, measure another 5 cm to the right. That's 10 cm total.

**Step 4**: Measure another 5 cm. That's 15 cm.

**Step 5**: Measure one more 5 cm. That's 20 cm.

**Step 6**: Now add about 1.5 cm more. That's 21.5 cm.

**Step 7**: Draw the rectangle 5 cm × 16.5 cm. That's close to a bronze rectangle!

### The Bronze Property

Here's what makes bronze special:

If you cut off THREE squares from a bronze rectangle, you're left with ANOTHER bronze rectangle!

Try it:
- Start with a rectangle that is 1 unit × 3.303 units
- Cut off three 1×1 squares
- You're left with a rectangle that is 1 unit × 0.303 units
- Flip it: 0.303 × 1, which has ratio 1:3.303

It works! Bronze rectangles are also self-similar!

---

## Part 3: What Happens When You Add Bronze?

### Bronze Addition Properties

The bronze ratio has these special properties:

- Bronze² = 3 × Bronze + 1

Let's check:
- Bronze = 3.303...
- Bronze² = 10.910...
- 3 × Bronze + 1 = 9.909 + 1 = 10.909

Close enough (rounding)!

### More Bronze Math

- Bronze - 1 = 2.303...
- Bronze - 2 = 1.303...
- 1 ÷ Bronze = 0.303...

The decimal part of bronze is 0.303, which appears in many bronze calculations!

### The Metallic Equation

All metallic ratios satisfy: x² = n × x + 1, where n is the "metal number":
- Gold (n=1): x² = x + 1
- Silver (n=2): x² = 2x + 1
- Bronze (n=3): x² = 3x + 1

You can keep going! n=4 gives the next metallic ratio, and so on.

---

## Part 4: Bronze in Everyday Life

### Art and Design

- **Triangles**: Equilateral triangles can be arranged in bronze patterns
- **Spirals**: Some spiral staircases use bronze proportions
- **Patterns**: Textile designers use bronze for repeating patterns

### Nature

- **Shells**: Some shells grow in bronze spirals
- **Flowers**: Certain flower arrangements follow bronze ratios
- **Branches**: Tree branches sometimes split in bronze proportions

### Architecture

- **Domes**: Some domed buildings use bronze proportions
- **Arches**: Certain arches follow bronze curves
- **Floor plans**: Some rooms are laid out in bronze rectangles

---

## Part 5: 10 Fun Exercises

### Exercise 1: Draw a Bronze Rectangle
Using a ruler, draw a rectangle that is 4 cm × 13.2 cm (4 × 3.303). How does it look compared to golden and silver rectangles?

### Exercise 2: The Three-Square Cut
Draw a bronze rectangle. Cut off THREE squares from one end. What's left? Measure the remaining rectangle. Is it also bronze?

### Exercise 3: Bronze Sequence Calculator
Write out the bronze sequence:
Start with 1, 3
Then: 10, 33, 109, 360, 1189, 3927...

Now divide each by the one before it:
10÷3 = ?
33÷10 = ?
109÷33 = ?

How close to 3.303 do you get?

### Exercise 4: Bronze vs Gold vs Silver
Draw all three rectangles side by side:
- Golden: 4 cm × 6.47 cm
- Silver: 4 cm × 9.66 cm
- Bronze: 4 cm × 13.2 cm

Which is longest? Which is shortest? Which do you like best?

### Exercise 5: Bronze Spiral Art
Draw a bronze rectangle. Divide it into a square and a smaller bronze rectangle. Then divide that smaller rectangle. Keep going! Connect the corners to make a spiral. Color each section!

### Exercise 6: Find Bronze Patterns
Look for patterns in nature or your home:
- Spirals in plants
- Patterns in tiles
- Window arrangements
- Book layouts

Which ones show bronze proportions?

### Exercise 7: Build a Bronze Tower
Use blocks to build a tower where each level is 3.303 times taller than the one below. Start with a 2 cm block. What's the next height? (About 6.6 cm)

### Exercise 8: Bronze Music
If you have a piano, play notes that are a bronze interval apart. How does it sound? Is it more dissonant or consonant than golden or silver intervals?

### Exercise 9: Bronze Pattern Design
Create a repeating pattern using bronze rectangles:
- Draw a large bronze rectangle
- Divide it into smaller bronze rectangles and squares
- Repeat this pattern to fill a page
- Color it with earth tones (brown, orange, tan)

### Exercise 10: Bronze Journal
In your math journal, write down:
- Three things that show bronze proportions
- A drawing of a bronze spiral
- The bronze identity: Bronze² = 3 × Bronze + 1
- One question you have about bronze

---

## Part 6: Amazing Bronze Facts

### Fact 1: Bronze is the First "Non-Noble" Metal
While gold and silver are noble metals (they don't react with other elements), bronze is an alloy — a mix of metals. Copper + tin = bronze!

### Fact 2: The Bronze Age
The Bronze Age was a period in human history when people learned to make bronze tools. It lasted from about 3300 BC to 1200 BC!

### Fact 3: Bronze Numbers
The bronze ratio is related to the number 3 in the same way phi is related to 1 and silver is related to 2.

### Fact 4: Bronze in Sports
Medals in the Olympics are gold, silver, and bronze! The ratios of their sizes sometimes follow metallic ratios.

### Fact 5: Bronze Math is Infinite
You can keep creating new metallic ratios forever:
- n=1: gold
- n=2: silver
- n=3: bronze
- n=4: next metallic ratio
- n=5: and so on...

Each one is bigger than the last!

---

## Part 7: Bronze Poems

### The Bronze Poem
Bronze is the number of big spirals we find,
In shells, in the stars, in the back of the mind,
Not gold, not silver, but strong and true,
Bronze is the ratio for me and for you!

### The Metallic Rhyme
Gold is first, silver second, bronze is third,
Each metallic ratio is perfectly heard,
In nature, in art, in music, in stone,
Bronze makes the biggest spirals we've known!

---

## Part 8: What You've Learned

Today you discovered:

1. **The bronze ratio** is about 3.303 — the third metallic ratio after gold and silver.

2. **Bronze rectangles** have a special property: cut off THREE squares and you get another bronze rectangle.

3. **All metallic ratios** follow the pattern: x² = n × x + 1, where n increases by 1 each time.

4. **Bronze appears** in 13-sided polygons, large spirals, and the Bronze Age of human history.

5. **The bronze identity**: Bronze² = 3 × Bronze + 1

---

## Part 9: Challenge Problems

### Challenge 1: The Metallic Pattern
Can you find the next metallic ratio (n=4)?
Hint: Solve x² = 4x + 1 using the quadratic formula.

### Challenge 2: Bronze and Fibonacci
The bronze sequence (1, 3, 10, 33, 109...) is similar to Fibonacci but with different starting numbers. Can you find a pattern in how it grows?

### Challenge 3: Bronze Geometry
If you have a regular tridecagon (13-sided polygon), what is the ratio of its longest diagonal to its shortest diagonal? (It should be close to bronze!)

### Challenge 4: The Metallic Spiral
Draw golden, silver, and bronze spirals on the same page. How do they compare? Which one spirals the tightest? Which one the loosest?

### Challenge 5: Bronze in Art
Find a piece of art or a photograph that shows bronze proportions. Write a paragraph explaining how bronze helps the composition.

---

## Part 10: Glossary

**Alloy**: A mixture of two or more metals

**Bronze Age**: A historical period when people used bronze tools (about 3300-1200 BC)

**Bronze Ratio**: Approximately 3.303, the third metallic ratio

**Equation**: A math sentence that says two things are equal, like x² = 3x + 1

**Metallic Ratios**: A family of ratios (gold, silver, bronze, ...) that share similar properties

**Quadratic Formula**: A formula for solving x² + bx + c = 0: x = (-b ± √(b²-4ac)) / 2a

**Sequence**: A list of numbers that follows a pattern

**Tridecagon**: A 13-sided polygon

---

## Remember!

**Bronze is the ratio of big spirals!**

While gold and silver are beautiful, bronze is strong and practical — just like the metal itself! The next time you see a big spiral in nature, remember: bronze might be hiding there!

---

*Every number has its own personality. Bronze is bold, strong, and always growing — just like the spirals it creates!*
