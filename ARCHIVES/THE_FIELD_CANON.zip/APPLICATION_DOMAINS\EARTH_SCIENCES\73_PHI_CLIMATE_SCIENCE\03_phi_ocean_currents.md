# PHI-OCEAN CURRENTS

## PHI-HARMONIC OCEAN CIRCULATION

### 1. Phi-Geostrophic Balance

The phi-modified geostrophic equations:

```
f*v = 1/rho * dP/dx * phi^(-z/H_ocean)
f*u = -1/rho * dP/dy * phi^(-z/H_ocean)
```

Where:
- u, v = zonal and meridional velocities (m/s)
- f = Coriolis parameter = 2*Omega*sin(phi_lat)
- rho = seawater density (kg/m^3)
- P = pressure (Pa)
- z = depth (m)
- H_ocean = ocean scale depth (500 m)

The phi-depth dependence means geostrophic balance weakens with depth, producing weaker deep currents.

The geostrophic velocity:
```
u_geo = -1/(f*rho) * dP/dy * phi^(-z/H_ocean)
```

The thermal wind relation:
```
du/dz = -g/(f*rho_0) * drho/dy * phi^(-z/H_ocean)
```

### 2. Phi-Thermohaline Circulation

The overturning streamfunction:

```
Psi = Psi_0 * (1 - exp(-t/tau_phi)) * (Delta_T - Delta_S/lambda_S)^phi
```

Where:
- Psi_0 = reference overturning strength (Sv)
- tau_phi = phi-adjustment timescale (yr)
- Delta_T = North-South temperature difference (K)
- Delta_S = North-South salinity difference (psu)
- lambda_S = thermal to haline ratio (K/psu)

For Delta_T = 5 K, Delta_S = 1 psu, lambda_S = 3 K/psu:
```
Psi = Psi_0 * (1-exp(-t/tau_phi)) * (5 - 1/3)^phi = Psi_0 * (1-exp(-t/tau_phi)) * 4.667^1.618
= Psi_0 * (1-exp(-t/tau_phi)) * 14.5
```

The phi-exponent amplifies the thermal forcing.

### 3. Phi-Eddy Diffusivity

The lateral eddy diffusivity:

```
K_h = K_h0 * (L_eddy/L_ref)^phi * (U_eddy/U_ref)^(1/phi)
```

Where:
- K_h0 = reference diffusivity (m^2/s)
- L_eddy = eddy length scale (m)
- U_eddy = eddy velocity scale (m/s)

For mesoscale eddies: L_eddy = 100 km, U_eddy = 0.1 m/s
```
K_h = 100 * (100/50)^1.618 * (0.1/0.05)^0.618 = 100 * 2.618 * 1.507 = 395 m^2/s
```

The vertical eddy diffusivity:
```
K_v = K_v0 * phi^(-N_ddt)
```

Where N_ddt is the stratification parameter (Brunt-Vaisala frequency / Coriolis parameter).

### 4. Phi-Sea Surface Temperature

The SST anomaly propagation:

```
dT_anomaly/dt = -c * dT_anomaly/dx * phi^(-x/L_wave) + K * d^2T/dx^2 * phi^(x/L_K)
```

Where:
- c = propagation speed (m/s)
- L_wave = wave decay length (m)
- K = diffusion coefficient (m^2/s)
- L_K = diffusion length (m)

The phi-modulation produces asymmetric propagation: anomalies grow in the phi-direction and decay anti-phi.

The ENSO-like oscillation:
```
T_SST = T_mean + A * sin(2*pi*t/tau_ENSO + phi_phase) * phi^(-t/tau_decay)
```

Where:
- A = oscillation amplitude (K)
- tau_ENSO = ENSO period (yr) = 3-7 years
- phi_phase = phase offset
- tau_decay = decay timescale (yr)

### 5. Phi-Deep Water Formation

The deep water formation rate:

```
Q_DWF = Q_0 * (S_surface - S_deep)/(S_ref) * phi^(-(T_surface - T_ref)/Delta_T)
```

Where:
- Q_0 = reference formation rate (Sv)
- S_surface = surface salinity (psu)
- S_deep = deep water salinity (psu)
- T_surface = surface temperature (K)
- T_ref = reference temperature (K)

The phi-exponential suppresses deep water formation as surface temperature rises.

### 6. Phi-Coastal Upwelling

The upwelling velocity:

```
w_upw = tau_wind/(f*rho_0*H Ekman) * phi^(-x_coast/L_ramp)
```

Where:
- tau_wind = along-shore wind stress (Pa)
- H_Ekman = Ekman layer depth (m)
- x_coast = distance from coast (m)
- L_ramp = ramp-up length scale (m)

The phi-ramp produces a sharp upwelling near the coast that decays offshore.

The upwelled water temperature:
```
T_upw = T_deep + (T_surface - T_deep) * phi^(-w_upw/w_ref)
```

### 7. Phi-Ocean Acidification

The pH change:

```
Delta_pH = -log10(1 + Delta_CO2/C_ref) * phi^(-t/tau_buffer)
```

Where:
- Delta_CO2 = CO2 increase (ppm)
- C_ref = reference CO2 (280 ppm)
- tau_buffer = ocean buffer timescale (yr)

The phi-buffering slows the acidification rate at longer timescales.

The aragonite saturation state:
```
Omega_arag = Omega_0 * (1 - Delta_CO2/(C_ref*phi^(t/tau_buffer)))
```

---

## PHI-HARMONIC OCEAN EQUATIONS

| Eq # | Name | Formula |
|------|------|---------|
| O.1 | Geostrophic velocity | u = -1/(f*rho)*dP/dy*phi^(-z/H) |
| O.2 | Thermohaline | Psi = Psi_0*(1-exp(-t/tau))*(DT-DS/l)^phi |
| O.3 | Eddy diffusivity | K_h = K_0*(L/L_r)^phi*(U/U_r)^(1/phi) |
| O.4 | SST anomaly | dT/dt = -c*dT/dx*phi^(-x/L) + K*d^2T/dx^2*phi^(x/L_K) |
| O.5 | Deep water | Q = Q_0*(S_s-S_d)/S_r*phi^(-(T_s-T_r)/DT) |
| O.6 | Upwelling | w = tau/(f*rho*H)*phi^(-x/L) |
| O.7 | Acidification | DpH = -log10(1+DCO2/C_r)*phi^(-t/tau_b) |

---

## WORKED EXAMPLES

### Example 1: Phi-Geostrophic Velocity

**Given:**
- f = 1e-4 s^-1 (at 45 N)
- rho = 1025 kg/m^3
- dP/dy = 0.01 Pa/m
- z = 200 m, H_ocean = 500 m

**Find:** Geostrophic velocity

**Solution:**

Step 1: Calculate phi-factor
```
phi^(-z/H) = phi^(-200/500) = phi^(-0.4) = 1/phi^0.4 = 1/1.222 = 0.818
```

Step 2: Geostrophic velocity
```
u_geo = -1/(1e-4*1025) * 0.01 * 0.818 = -1/102.5 * 0.01 * 0.818 = -0.0000975*0.818 = -7.98e-5 m/s
```

Step 3: Convert to cm/s
```
u_geo = -0.008 cm/s
```

**Result:** The phi-modified geostrophic velocity is 0.008 cm/s at 200 m depth.

---

## PROBLEMS

1. Calculate the thermohaline overturning strength after 100 years of phi-adjustment.

2. Determine the eddy diffusivity for a 200 km eddy with U = 0.15 m/s.

3. Find the upwelling velocity at 50 km from coast with tau_wind = 0.1 Pa.

4. Calculate the pH change after 50 years of CO2 increase of 100 ppm.

5. Design a phi-ENSO model with period 4 years and amplitude 2 K.

---

## TABLES

### Phi-Ocean Parameters

| Parameter | Value | Units |
|-----------|-------|-------|
| H_ocean | 500 | m |
| K_h0 | 100 | m^2/s |
| K_v0 | 1e-4 | m^2/s |
| tau_ENSO | 4 | yr |
| Lambda_S | 3 | K/psu |
| H_Ekman | 50 | m |

### Ocean Circulation Response

| Timescale | Process | Phi-Factor |
|-----------|---------|------------|
| Days | Wind-driven | 0.99 |
| Months | Eddies | 0.95 |
| Years | Thermohaline | 0.82 |
| Decades | Deep water | 0.618 |
| Century | Acidification | 0.382 |
