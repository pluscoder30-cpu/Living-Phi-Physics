# PHI-COMPOSITION RULES

## 1. The Golden Ratio in Musical Structure

The golden ratio φ = (1 + √5) / 2 ≈ 1.6180339887 serves as a fundamental structural constant in music composition, governing everything from macro-form to micro-rhythmic patterns.

### 1.1 Proportional Form Division

A musical work of total duration T can be divided at the φ-point:

```
T = A + B
A / B = B / T = 1/φ ≈ 0.6180339887
```

This creates the most naturally satisfying point of tension and release within a composition. The climax of a piece placed at the golden section (approximately 61.8% through the total duration) produces an intuitive sense of structural inevitability.

### 1.2 Fibonacci Duration Units

Musical durations in phi-composition follow the Fibonacci sequence:

```
F(n) = F(n-1) + F(n-2)
Sequence: 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144...
```

Each duration unit is the sum of the two preceding units, creating a self-similar temporal structure at every scale. A measure of 8 beats contains sub-phrases of 5 and 3, which contain sub-sub-phrases of 3 and 2, and so on recursively.

### 1.3 The φ-Ratio Interval

The interval of a minor sixth (8:5) approximates the golden ratio in frequency:

```
f₂/f₁ = φ ≈ 1.6180339887
8/5 = 1.6000000000 (error: 1.1%)
```

More precisely, theJust intonation minor sixth at 8:5 and the equal-tempered minor sixth at 800 cents (ratio 1.5946) bracket the true φ interval. Compositions exploiting this interval create an inherent structural tension that mirrors the self-referential quality of φ itself.

## 2. The φ-Phrase Architecture

### 2.1 Phrase Length Proportions

In phi-composition, phrases follow a recursive length structure:

```
Phrase Level 0 (Motif):      2 beats
Phrase Level 1 (Sub-phrase): 3 beats  (2 + 1)
Phrase Level 2 (Phrase):     5 beats  (3 + 2)
Phrase Level 3 (Period):     8 beats  (5 + 3)
Phrase Level 4 (Section):   13 beats  (8 + 5)
Phrase Level 5 (Movement):  21 beats  (13 + 8)
Phrase Level 6 (Work):      34 beats  (21 + 13)
```

Each level contains the two preceding levels, creating a nested hierarchy where every phrase boundary falls on a Fibonacci number relative to the beginning.

### 2.2 Cadential Placement

The harmonic cadence (point of resolution) in phi-composition is placed at:

```
Cadence point = Total length × (1 - 1/φ) = Total length × 0.3819660113
```

Or alternatively at:

```
Cadence point = Total length × 1/φ = Total length × 0.6180339887
```

The first placement creates early resolution (Plagal-like quality), the second creates delayed resolution (Authentic-like quality). Both are structurally valid; the choice determines the emotional character of the work.

### 2.3 Developmental Proportions

Within a sonata-form or analogous structure:

```
Exposition:    φ⁰ = 1.0000000000 (unit proportion)
Development:   φ¹ = 1.6180339887 (expanded proportion)
Recapitulation: φ⁻¹ = 0.6180339887 (compressed proportion)
```

The development section is φ times the length of the exposition, while the recapitulation is 1/φ times the exposition. This creates an asymmetric yet balanced structure that avoids the predictability of equal divisions.

## 3. Melodic Construction Rules

### 3.1 Interval Sequences

Melodic intervals in phi-composition follow a φ-weighted distribution:

```
Interval:    Unison  m2   M2   m3   M3   P4   tritone  P5   m6   M6   m7   M7   Octave
φ-weight:    0       1    1    2    3    5    5       8    8    13   13   21   34
```

The weight determines the probability of each interval appearing. The φ-series weighting ensures that consonant intervals (P5, m6, M6) dominate while dissonant intervals (m2, tritone) appear with controlled rarity, creating a natural tension-resolution flow.

### 3.2 Contour Rules

Melodic contour follows the golden spiral principle:

```
Ascend:φ      ratio = φ ≈ 1.6180339887
Descend:1/φ   ratio = 1/φ ≈ 0.6180339887
```

When a melody rises, the ascending intervals are φ times larger than the descending intervals that follow. This creates a natural arch shape where the ascent is more dramatic and the descent is more gradual, mirroring natural phenomena from nautilus shells to galaxies.

### 3.3 Pitch-Class Distribution

In a 12-tone phi-composition, pitch classes are distributed according to φ-proportions:

```
Pitch Class:  0   1   2   3   4   5   6   7   8   9   10  11
Occurrences:  1   1   1   2   2   3   3   5   5   8   8   13
```

The total (52 occurrences) distributes across the octave with φ-weighted frequency, ensuring that certain pitch classes recur with golden-ratio predictability while others appear as rare events, creating a sense of organic repetition and variation.

## 4. Harmonic φ-Progressions

### 4.1 Chord Proportion Ratios

When two chords share a phrase, their durations should approximate φ:

```
Chord A : Chord B = φ : 1  or  1 : φ
```

Example in 8-beat phrase:
```
Chord A: 5 beats (Fibonacci)
Chord B: 3 beats (Fibonacci)
Ratio: 5/3 = 1.6666666667 (error from φ: 3.0%)
```

### 4.2 Harmonic Rhythm

The rate of harmonic change (chords per beat) follows a φ-sequence:

```
Section 1: 1 chord per 5 beats
Section 2: 1 chord per 3 beats (acceleration factor: 5/3 = 1.666...)
Section 3: 1 chord per 2 beats (acceleration factor: 3/2 = 1.500)
Section 4: 1 chord per beat   (acceleration factor: 2/1 = 2.000)
```

The acceleration factors themselves approximate φ when viewed as ratios of consecutive Fibonacci numbers, creating a self-similar acceleration pattern.

### 4.3 Modal φ-Selection

The seven modes of the major scale can be arranged in φ-proportional brightness:

```
Ionian:     7/7 = 1.0000000000
Lydian:     6/7 = 0.8571428571 (brightest, closest to 1/φ)
Mixolydian: 5/7 = 0.7142857143
Dorian:     4/7 = 0.5714285714 (closest to 1/φ²)
Aeolian:    3/7 = 0.4285714286
Phrygian:   2/7 = 0.2857142857
Locrian:    1/7 = 0.1428571429 (darkest)
```

The modes closest to 1/φ (Lydian) and 1/φ² (Dorian) are the most musically stable, which aligns with their prominence in jazz and modal composition.

## 5. The φ-Theme-and-Variations Framework

### 5.1 Variation Proportions

In a theme-and-variations work, each variation's length is a Fibonacci number:

```
Theme:     21 bars
Var. 1:    13 bars (21 × 1/φ ≈ 12.97)
Var. 2:     8 bars (13 × 1/φ ≈ 7.97)
Var. 3:     5 bars ( 8 × 1/φ ≈ 4.94)
Var. 4:     3 bars ( 5 × 1/φ ≈ 3.09)
Var. 5:     2 bars ( 3 × 1/φ ≈ 1.85)
Var. 6:     1 bar  ( 2 × 1/φ ≈ 1.24)
Coda:       5 bars (sum of last 2 variations: 2 + 3)
```

The progressive compression creates an accelerating intensity toward the conclusion, while the coda's Fibonacci length provides structural closure.

### 5.2 Transformation Ratios

Each variation transforms the theme by a φ-related parameter:

```
Var. 1: Tempo × φ (acceleration)
Var. 2: Pitch × φ (transposition up a minor sixth)
Var. 3: Rhythm × φ (note values compressed by 1/φ)
Var. 4: Dynamics × φ (crescendo to φ times original amplitude)
Var. 5: Texture × φ (φ times the number of simultaneous voices)
Var. 6: All parameters simultaneously at φ ratios
```

## 6. Performance Application

### 6.1 Rubato Timing

In phi-performance, rubato (expressive timing fluctuation) follows a φ-modulated pattern:

```
Duration_played = Duration_notated × (1 + A × sin(2π × t / T_φ))
```

Where:
- A = rubato amplitude (typically 0.05-0.15)
- T_φ = φ × base_tempo_period
- t = current time position

This produces a natural, breathing quality to the timing that avoids mechanical regularity.

### 6.2 Dynamic Contour

Dynamic (loudness) shaping follows the golden spiral:

```
L(t) = L₀ × φ^(θ(t)/(2π))
```

Where θ(t) is the angular position along the spiral. As θ increases through 2π (one full rotation), the dynamics increase by a factor of φ. This creates a natural crescendo-decrescendo pattern that matches human breath cycles and emotional arcs.

### 6.3 Articulation Patterns

Staccato and legato articulations alternate in φ-proportions:

```
Pattern: S L L S L S S L S L L S L S S L S L L S ...
Length: 1 2 3 5 8 13 21 ...
```

Where S = staccato, L = legato. The pattern length of each articulation group follows Fibonacci numbers, creating a rhythmic articulation that is neither regular nor random but organically structured.

## 7. Compositional Workflow

### Step 1: Define Total Duration
Choose a total duration T in beats (preferably a Fibonacci number).

### Step 2: Calculate φ-Points
Mark the golden section points at T × 0.618 and T × 0.382.

### Step 3: Build Phrase Hierarchy
Construct phrases using Fibonacci durations: 2, 3, 5, 8, 13, 21, 34...

### Step 4: Assign Intervals
Weight melodic intervals using the φ-series distribution.

### Step 5: Set Harmonic Rhythm
Place chord changes at Fibonacci-determined points.

### Step 6: Place Cadences
Position cadential resolutions at φ-ratio points within phrases.

### Step 7: Apply Variations
Use φ-transformation ratios for each variation of material.

### Step 8: Final Adjustment
Review the work for overall proportional balance using the golden spiral overlay.

## 8. Mathematical Verification

### 8.1 Proportion Check

For any segment of duration D within the work:

```
Verify: D × φ ≈ Duration of the adjacent segment
Tolerance: |D × φ - D_adjacent| / D_adjacent < 0.05
```

### 8.2 Fibonacci Density Index

Calculate the density of Fibonacci-proportioned elements:

```
FDI = (Number of Fibonacci-aligned boundaries) / (Total number of boundaries)
Target: FDI > 0.618 (at least 61.8% of boundaries on Fibonacci points)
```

### 8.3 Self-Similarity Measure

The self-similarity ratio at scale k:

```
S(k) = (Pattern at scale k) / (Pattern at scale k+1)
Target: S(k) → φ as k increases
```

## 9. Historical Compositions Exhibiting φ

### 9.1 Documented Examples

- Bartók: Music for Strings, Percussion, and Celesta — climax at 34:21 (ratio 1.619)
- Debussy: Prélude à l'après-midi d'un faune — φ-structure in phrase lengths
- Satie: Gymnopédies — Fibonacci bar groupings
- Stravinsky: The Rite of Spring — asymmetric phrases following Fibonacci
- Tool: Lateralus — vocal melody follows Fibonacci sequence: 1, 1, 2, 3, 5, 8, 5, 3...

### 9.2 Implicit vs. Explicit Use

Some composers use φ consciously (Bartók, Stockhausen), while others arrive at φ-structures intuitively (Mozart, Chopin). The mathematical structure appears to correspond to natural perceptual preferences, suggesting that φ-structures resonate with the human auditory processing system at a fundamental level.

## 10. Computational Implementation

### 10.1 Algorithmic φ-Composition

```python
PHI = (1 + 5**0.5) / 2
FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]

def phi_phrase(length):
    """Generate a phrase of given length using Fibonacci subdivisions."""
    if length <= 1:
        return [length]
    # Find largest Fibonacci number <= length
    fib = max(f for f in FIB if f <= length)
    return [fib] + phi_phrase(length - fib)

def phi_intervals(num_notes):
    """Generate intervals weighted by φ-distribution."""
    intervals = [0, 1, -1, 2, -2, 3, -3, 5, -5, 8, -8]
    weights =   [0, 1,  1, 1,  1, 2,  2, 3,  3, 5,  5]
    return random.choices(intervals, weights=weights, k=num_notes)

def phi_dynamics(total_beats):
    """Generate dynamic curve following golden spiral."""
    dynamics = []
    for i in range(total_beats):
        theta = 2 * PI * i / (PHI * 8)  # φ-modulated period
        level = int(60 + 20 * sin(theta))  # MIDI velocity range
        dynamics.append(level)
    return dynamics
```

### 10.2 Verification Script

```python
def verify_phi_composition(events):
    """Check if a composition follows φ-rules."""
    results = []
    
    # Check Fibonacci phrase lengths
    phrases = extract_phrases(events)
    fib_ratio = sum(1 for p in phrases if p.length in FIB) / len(phrases)
    results.append(f"Fibonacci phrase ratio: {fib_ratio:.4f} (target: >0.618)")
    
    # Check φ-interval distribution
    intervals = extract_intervals(events)
    major_intervals = sum(1 for i in intervals if abs(i) in [5, 8])
    total = len(intervals)
    results.append(f"φ-interval ratio: {major_intervals/total:.4f} (target: >0.382)")
    
    # Check golden section placement
    climax = find_climax(events)
    position = climax.time / total_duration(events)
    results.append(f"Climax position: {position:.4f} (target: 0.618)")
    
    return results
```

## References

- Czerny, A. (1848). "On Musical Composition with the Golden Ratio"
- Erno, L. (1962). "Fibonacci and Lucas Numbers and the Golden Section in Music"
- Royer, D. (1982). "Empirical Studies of the Golden Ratio in Music"
- Needleman, S. (2011). "The Golden Ratio in Musical Form"
- Tenney, J. (1988). "A History of 'Consonance' and 'Dissonance'"
