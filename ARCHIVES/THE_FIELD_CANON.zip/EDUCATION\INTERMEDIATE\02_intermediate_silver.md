# 02 — The Silver Ratio (δₛ) | Intermediate Level

## Ages 13–16 | Algebraic Foundations

---

## 1. Definition

The silver ratio δₛ (sometimes written σ) is defined as:

```
δₛ = 1 + √2 ≈ 2.4142135623...
```

The silver ratio arises from the octagon (8-sided polygon) just as the golden
ratio arises from the pentagon (5-sided polygon).

---

## 2. Algebraic Proof: δₛ² = 2δₛ + 1

**Claim:** δₛ² = 2δₛ + 1

**Proof:**

Let δₛ = 1 + √2.

```
δₛ² = (1 + √2)²
    = 1 + 2√2 + 2
    = 3 + 2√2
```

Now compute 2δₛ + 1:

```
2δₛ + 1 = 2(1 + √2) + 1
         = 2 + 2√2 + 1
         = 3 + 2√2
```

Since both sides equal 3 + 2√2, we have δₛ² = 2δₛ + 1. ∎

**General form:** δₛ satisfies the equation x² − 2x − 1 = 0.

---

## 3. The Conjugate

The conjugate of δₛ is:

```
δₛ* = 1 − √2 ≈ −0.4142135623...
```

Key properties:

```
δₛ · δₛ* = (1 + √2)(1 − √2) = 1 − 2 = −1
δₛ + δₛ* = (1 + √2) + (1 − √2) = 2
δₛ − δₛ* = (1 + √2) − (1 − √2) = 2√2
```

Also: δₛ* = −1/δₛ, since δₛ · δₛ* = −1.

---

## 4. Pell Numbers Connection

The Pell sequence is analogous to the Fibonacci sequence but with a different
recurrence:

```
P(0) = 0,  P(1) = 1
P(n) = 2·P(n−1) + P(n−2)
```

First few terms:

```
P(0) = 0
P(1) = 1
P(2) = 2·1 + 0 = 2
P(3) = 2·2 + 1 = 5
P(4) = 2·5 + 2 = 12
P(5) = 2·12 + 5 = 29
P(6) = 2·29 + 12 = 70
P(7) = 2·70 + 29 = 169
P(8) = 2·169 + 70 = 408
```

**Theorem:** P(n+1)/P(n) → δₛ as n → ∞.

**Proof:**

Assume P(n+1)/P(n) → L. Then:

```
P(n+1) = 2·P(n) + P(n−1)

Divide by P(n):
P(n+1)/P(n) = 2 + P(n−1)/P(n)

As n → ∞: L = 2 + 1/L
            L² = 2L + 1
            L² − 2L − 1 = 0

By quadratic formula: L = (2 ± √(4+4)) / 2 = (2 ± 2√2) / 2 = 1 ± √2

Taking the positive root: L = 1 + √2 = δₛ  ✓
```

---

## 5. Silver Ratio and Paper Sizes

The silver ratio appears in the mathematics of paper sizes. When you cut a sheet
of paper in half, the two halves are similar to the original if the ratio is 1:√2.

```
A4 paper: 210mm × 297mm
Ratio: 297/210 ≈ 1.4142 ≈ √2

When you fold it in half:
New dimensions: 148.5mm × 210mm
Ratio: 210/148.5 ≈ 1.4142 ≈ √2  (same!)
```

The connection to the silver ratio:

```
If a rectangle has ratio 1:√2, then:
  Long / Short = √2
  (Long + Short) / Long = 1 + 1/√2 = (√2 + 1)/√2 = δₛ/√2
```

The silver ratio also governs the geometry of regular octagons.

---

## 6. Regular Octagon and δₛ

In a regular octagon with side length s:

```
Width (vertex to vertex) = s(1 + √2) = s · δₛ
Width (flat to flat) = s√(4 + 2√2) ≈ s · 2.613
```

The ratio of the circumradius to the inradius involves √2 and δₛ.

---

## 7. Continued Fraction of δₛ

The silver ratio has a simple continued fraction:

```
δₛ = 2 + 1/(2 + 1/(2 + 1/(2 + ...)))
```

Written as [2; 2, 2, 2, 2, ...].

This is the simplest periodic continued fraction after φ (which has all 1s).

---

## 8. Connection to √2

Since δₛ = 1 + √2, we can express √2 in terms of δₛ:

```
√2 = δₛ − 1
```

And the Pell numbers satisfy:

```
P(n) = ((1+√2)ⁿ − (1−√2)ⁿ) / (2√2)
```

This is the Pell analogue of Binet's formula for Fibonacci numbers.

---

## 9. Powers of δₛ

Using δₛ² = 2δₛ + 1, we can reduce any power:

```
δₛ³ = δₛ · δₛ² = δₛ(2δₛ + 1) = 2δₛ² + δₛ
    = 2(2δₛ + 1) + δₛ = 4δₛ + 2 + δₛ = 5δₛ + 2

δₛ⁴ = δₛ · δₛ³ = δₛ(5δₛ + 2) = 5δₛ² + 2δₛ
    = 5(2δₛ + 1) + 2δₛ = 10δₛ + 5 + 2δₛ = 12δₛ + 5
```

General pattern: δₛⁿ = P(n)·δₛ + P(n−1), where P(n) is the nth Pell number.

---

## 10. Worked Problems

### Problem 1: Find δₛ²

**Question:** Compute δₛ² without a calculator.

**Solution:**

```
δₛ² = (1 + √2)²
    = 1 + 2√2 + 2
    = 3 + 2√2
    ≈ 3 + 2(1.4142)
    = 5.8284
```

Check: δₛ² = 2δₛ + 1 = 2(2.4142) + 1 = 5.8284 ✓

---

### Problem 2: Find 1/δₛ

**Question:** Express 1/δₛ in simplest radical form.

**Solution:**

```
1/δₛ = 1/(1 + √2)
      = (1 − √2) / ((1 + √2)(1 − √2))
      = (1 − √2) / (1 − 2)
      = (1 − √2) / (−1)
      = √2 − 1
      ≈ 0.4142
```

Note: 1/δₛ = δₛ − 2.

---

### Problem 3: Pell number ratio

**Question:** Compute P(6)/P(5) and compare to δₛ.

**Solution:**

```
P(6) = 70,  P(5) = 29
P(6)/P(5) = 70/29 ≈ 2.413793

δₛ ≈ 2.414214

Difference: |2.414214 − 2.413793| ≈ 0.000421
```

The ratio is already very close to δₛ after just 6 terms.

---

### Problem 4: Solve x² − 2x − 1 = 0

**Question:** Find both roots of x² − 2x − 1 = 0.

**Solution:**

```
x = (2 ± √(4 + 4)) / 2
  = (2 ± √8) / 2
  = (2 ± 2√2) / 2
  = 1 ± √2
```

Roots: x₁ = 1 + √2 = δₛ ≈ 2.414
       x₂ = 1 − √2 ≈ −0.414

---

### Problem 5: Octagon width

**Question:** A regular octagon has side length 5 cm. What is its vertex-to-
vertex width?

**Solution:**

```
Width = s · δₛ = s(1 + √2)
      = 5(1 + √2)
      = 5 + 5√2
      ≈ 5 + 7.071
      ≈ 12.071 cm
```

---

### Problem 6: Express √2 using δₛ

**Question:** Write √2 in terms of δₛ.

**Solution:**

```
δₛ = 1 + √2
√2 = δₛ − 1
```

Check: δₛ − 1 = 2.414214 − 1 = 1.414214 = √2 ✓

---

### Problem 7: Compute δₛ³

**Question:** Express δₛ³ in the form aδₛ + b.

**Solution:**

```
δₛ³ = 5δₛ + 2 (from the pattern derived above)
    = 5(1 + √2) + 2
    = 5 + 5√2 + 2
    = 7 + 5√2
    ≈ 7 + 7.071
    ≈ 14.071
```

Check: δₛ³ = δₛ · δₛ² = 2.414 × 5.828 ≈ 14.071 ✓

---

### Problem 8: Silver rectangle

**Question:** A silver rectangle has width 4 cm. What is its length?

**Solution:**

```
Length = δₛ × width
       = (1 + √2) × 4
       = 4 + 4√2
       ≈ 4 + 5.657
       ≈ 9.657 cm
```

---

### Problem 9: The conjugate relationship

**Question:** Verify that δₛ · δₛ* = −1.

**Solution:**

```
δₛ · δₛ* = (1 + √2)(1 − √2)
         = 1² − (√2)²
         = 1 − 2
         = −1  ✓
```

---

### Problem 10: Pell number formula

**Question:** Use the Binet-like formula to compute P(4).

**Solution:**

```
P(n) = ((1+√2)ⁿ − (1−√2)ⁿ) / (2√2)

P(4) = ((1+√2)⁴ − (1−√2)⁴) / (2√2)

(1+√2)⁴ = δₛ⁴ = 12δₛ + 5 = 12(1+√2) + 5 = 17 + 12√2 ≈ 33.9706

(1−√2)⁴ = (1−√2)⁴ ≈ 0.0294  [since |1−√2| < 1]

P(4) = (33.9706 − 0.0294) / (2√2)
     = 33.9412 / 2.8284
     ≈ 12  ✓
```

---

### Problem 11: Compare δₛ and φ

**Question:** Which is larger, δₛ or φ? By how much?

**Solution:**

```
δₛ ≈ 2.414214
φ  ≈ 1.618034

δₛ − φ = (1 + √2) − (1 + √5)/2
       = 1 + √2 − 1/2 − √5/2
       = 1/2 + √2 − √5/2
       ≈ 0.5 + 1.4142 − 1.1180
       ≈ 0.796
```

δₛ is larger than φ by approximately 0.796.

---

### Problem 12: A paper folding problem

**Question:** You have an A0 sheet (841mm × 1189mm). After folding in half 3 times,
what are the dimensions?

**Solution:**

```
A0: 841 × 1189 mm
A1: 594 × 841 mm  (fold 1)
A2: 420 × 594 mm  (fold 2)
A3: 297 × 420 mm  (fold 3)
```

Each fold halves the area and preserves the √2 ratio. The silver ratio ensures
every A-series paper size is similar to every other.

---

### Problem 13: δₛ and the octagonal spiral

**Question:** If you inscribe squares in an octagon, each with side equal to the
octagon's side, what is the ratio of successive square areas?

**Solution:**

```
In an octagon with side s:
  Inner square diagonal = s·δₛ
  Outer square side = s·δₛ/√2

Area ratio = (s·δₛ/√2)² / s² = δₛ²/2 = (2δₛ + 1)/2 = δₛ + 1/2
```

The ratio involves δₛ directly.

---

### Problem 14: Express δₛ as a continued fraction

**Question:** Write out the first 4 convergents of the continued fraction [2; 2, 2, 2].

**Solution:**

```
[2] = 2/1 = 2.000000

[2; 2] = 2 + 1/2 = 5/2 = 2.500000

[2; 2, 2] = 2 + 1/(2 + 1/2) = 2 + 1/(5/2) = 2 + 2/5 = 12/5 = 2.400000

[2; 2, 2, 2] = 2 + 1/(2 + 1/(2 + 1/2)) = 2 + 1/(12/5) = 2 + 5/12 = 29/12 = 2.416667

δₛ ≈ 2.414214

Convergents: 2, 2.5, 2.4, 2.417, ...
```

Notice the convergents are ratios of Pell numbers: 1/1, 5/2, 12/5, 29/12.

---

### Problem 15: A silver ratio identity

**Question:** Prove that δₛ + 1/δₛ = 2δₛ.

**Solution:**

```
1/δₛ = √2 − 1  (from Problem 2)

δₛ + 1/δₛ = (1 + √2) + (√2 − 1)
           = 2√2
```

Hmm, that gives 2√2, not 2δₛ. Let me recheck:

```
2δₛ = 2(1 + √2) = 2 + 2√2

δₛ + 1/δₛ = 2√2

These are NOT equal. Let me find the correct identity:

δₛ − 1/δₛ = (1 + √2) − (√2 − 1) = 2  ✓

So δₛ − 1/δₛ = 2, not δₛ + 1/δₛ = 2δₛ.
```

The correct identity: **δₛ − 1/δₛ = 2**.

---

## 11. Summary Table

| Property | Value |
|----------|-------|
| Definition | δₛ = 1 + √2 |
| Decimal | 2.4142135623... |
| Polynomial | x² − 2x − 1 = 0 |
| Conjugate | δₛ* = 1 − √2 |
| Identity | δₛ² = 2δₛ + 1 |
| Reciprocal | 1/δₛ = √2 − 1 |
| Subtraction | δₛ − 1/δₛ = 2 |
| Continued fraction | [2; 2, 2, 2, ...] |
| Pell numbers | P(n+1)/P(n) → δₛ |

---

## 12. Key Takeaways for Ages 13–16

1. **δₛ is algebraic:** Positive root of x² − 2x − 1 = 0.
2. **δₛ² = 2δₛ + 1:** Reduces powers to linear expressions.
3. **Pell numbers:** The silver-ratio analogue of Fibonacci numbers.
4. **Paper sizes:** A-series papers use √2, related to δₛ.
5. **Octagons:** The silver ratio governs octagonal geometry.
6. **Compared to φ:** δₛ > φ; both are irrational and algebraic.

---

*Next: 03_intermediate_bronze.md — The Bronze Ratio*
