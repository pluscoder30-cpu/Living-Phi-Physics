# Financial Architects & Operational Inner Circle — Epstein Network

**Agent 8 of 25 Sequential Investigation Agents**
**Research Date:** August 28, 2026
**Total Persons Investigated:** 14
**Total Documents Referenced Across Network:** 343,000+

---

## SUMMARY

| # | Person | Role | Documents | Flights | Black Book | Key Finding |
|---|--------|------|-----------|---------|------------|-------------|
| 1 | **Darren Indyke** | Personal Attorney | 368,731 | 18 | Yes (5#) | Co-executor of estate; shell company architect; $105M USVI settlement |
| 2 | **Richard Kahn** | Accountant/Co-Executor | 77,607 | 0 | Yes (3#) | Managed HBRK Associates; authorized on banking/credit cards; $25-35M class action settlement |
| 3 | **Lesley Groff** | Executive Assistant | 203,741 | 92 | Yes (4#) | NPA co-conspirator; 20-year gatekeeper; sex offender registry compliance manager |
| 4 | **Sarah Kellen** | Scheduler/Co-Conspirator | 612 | 672 | Yes | FBI probable cause affidavit; "I have girls for him" notes; NPA immunity; 672 flights |
| 5 | **Nadia Marcinkova** | Co-Conspirator/Pilot | 360 | 267 | Yes (5#) | "Global Girl"; 267 flights; NPA immunity; federal cooperator 2018-2022; Fifth Amendment 42 times |
| 6 | **Leslie Wexner** | Financial Patron | 1,311 | 19 | Yes (9#) | $1B+ relationship; power of attorney; $46M post-conviction transfer; FBI co-conspirator designation |
| 7 | **Leon Black** | Apollo Global | 82 docs w/ victim | 5 w/ Kellen | — | $170M to Epstein; $62.5M USVI settlement; Jane Doe lawsuit; Brad Karp surveillance scandal |
| 8 | **Glenn Dubin** | Highbridge Capital | 1,439 | 36 | Yes | JPMorgan SAR named; wife Eva as hedge fund gateway; Giuffre deposition allegation |
| 9 | **Jes Staley** | JPMorgan/Barclays | 11,284 | 6 | Yes | Banned by UK FCA; shared confidential bank info with Epstein; advocated keeping Epstein account |
| 10 | **Larry Visoski** | Chief Pilot | 27,746 | 439 | Yes (2#) | 28-year pilot; ~1,000 flights; Maxwell trial witness; $10M bequest in will |
| 11 | **David Rodgers** | Pilot | 447 | 1 | Yes (1#) | 30-year pilot; flight logs key evidence; Maxwell = "number two"; Qatari Boeing 727 sale |
| 12 | **Alfredo Rodriguez** | House Manager/Butler | 1,138 | 280 | No | Stole black book; $50K sale attempt; convicted obstruction; died 2014; "blind, deaf, and dumb" |
| 13 | **Juan Alessi** | House Manager | 607 | 2 | Yes (1#) | 11-year house manager; Maxwell trial witness; "lady of the house"; NDA $30K; victims picked up from school |
| 14 | **Emmy Taylor** | Maxwell's PA | 62 | 200 | Yes (2#) | "Most critical person in case" per SDNY; massage instruction; 200 flights; sued HarperCollins |

---

## DETAILED PROFILES

### 1. DARREN INDYKE — The Legal Architect

**Role:** Personal attorney to Epstein (1990s-2019); Co-executor of estate; Director, Southern Trust Company

**Financial Infrastructure Managed:**
- Shell companies: JEGE LLC, Southern Financial LLC, Southern Trust Company Inc, Neptune LLC, Plan D LLC, NYSG LLC
- All Deutsche Bank entities classified HIGH risk under "Southern Financial Relationship"
- Signatory authority across entire Epstein entity portfolio
- Created Ellmax LLC for Ghislaine Maxwell
- Purchased East 65th Street property (became Maxwell's residence)
- Butterfly Trust co-trustee
- 1953 Trust and 2018 Trust co-trustee (with Kathryn Ruemmler briefly)

**Key Documents:**
- EFTA01433023: Full entity universe at Deutsche Bank
- EFTA01385736: Daily deposit report showing all accounts under relationship manager 82289
- EFTA01295996: Deutsche Bank watchlist alert (85% fuzzy match)
- Estate settlement: $105M with USVI (Nov 2022, no admission)
- Class action settlement: $25-35M (Feb 2026, pending final approval)

**Current Status:** Subpoenaed by House Oversight Committee; testified March 19, 2026; denied knowledge of crimes

---

### 2. RICHARD KAHN — The Accountant/Co-Executor

**Role:** CPA; Co-executor of estate with Indyke; Principal of HBRK Associates

**Financial Operations:**
- Managed tax estimates, stock portfolio, insurance policies, property matters
- Authorized by Epstein for banking and credit card matters
- Signatory on Deutsche Bank accounts
- Handled jet fuel purchases for USVI
- Managed Rothschild entity payments (€183,249.60 for furniture)
- Disputed $40-60M annual advisory fees from Leon Black's family office
- Managed Epstein Victims' Compensation Program ($121M+ to 135+ claimants)
- Oversaw property sales: 9 E. 71st St ($51M), Palm Beach ($18.5M), Little St. James

**Key Documents:**
- Will signed August 8, 2019 (2 days before death)
- Estate inventory: ~$7.6M cash across First Bank, Banco Popular, Paris escrow
- 1953 Trust: Indyke and Kahn as co-trustees; employment lock-in provision
- Class action settlement: $25-35M (Feb 2026)

**Current Status:** Testified before House Oversight March 11, 2026; stated "not aware" of crimes; saw "no red flags"

---

### 3. LESLEY GROFF — The Operational Gatekeeper

**Role:** Executive assistant to Epstein for 20 years (1999-2019)

**Operational Control:**
- 203,741 document references (second only to Epstein himself)
- Managed daily operations, travel, communications, apartment door codes
- Sex offender registry compliance manager (reminders to "Darren, Sarah, etc")
- Coordinated "Money & Power" seminar invite lists (Bill Gates, Sergey Brin, Larry Page, Jes Staley, etc.)
- Gatekeeper controlling access to Epstein
- FBI CID co-conspirator designation
- NPA immunity as co-conspirator

**Key Connections:**
- Ghislaine Maxwell: 66 shared flights
- Jeffrey Epstein: 87 shared flights
- Alan Dershowitz: 5 shared flights
- Appeared on flights with 64 other persons in network

**Current Status:** Named co-conspirator with NPA immunity; no criminal charges

---

### 4. SARAH KELLEN — The Scheduler

**Role:** Primary personal scheduler; named co-conspirator

**Critical Evidence:**
- 672 flight log entries
- Palm Beach Police notes: "I have girls for him" / "I have 2 girls for him"
- Probable cause affidavit: "principal in the first degree for unlawful sexual activity with a minor and lewd and lascivious molestation"
- Shared phone account (917-855-3363) with Epstein
- NPA immunity alongside Marcinkova, Groff, and Adriana Ross
- Married NASCAR driver Brian Vickers; changed name to Sarah Kellen Vickers

**Flight Connections:**
- Jeffrey Epstein: 670 shared flights
- Larry Visoski: 92 shared flights
- Nadia Marcinkova: 20 shared flights
- Glen Dubin: 12 shared flights
- Jean-Luc Brunel: 36 shared flights
- Prince Andrew: 17 shared flights
- Leon Black: 5 shared flights

**Current Status:** Deposed by House Oversight Committee February 2026; describes herself as "victim of Epstein"

---

### 5. NADIA MARCINKOVA — The Dual-Role Associate

**Role:** Co-conspirator; licensed pilot; federal cooperator

**Background:**
- Born 1986, Kosice, Slovakia
- Brought to US ~1999-2000 as teenager; Epstein reportedly told associates he "purchased her from her family"
- Dual role: described as both trafficking victim and active participant
- "Yugoslavian sex slave" — term Epstein used

**Key Facts:**
- 267 flight log entries
- 360 case documents
- NPA immunity as co-conspirator
- Invoked Fifth Amendment 42+ times in 2010 deposition
- Visited Epstein 70+ times in Palm Beach County Jail (2008)
- Became FAA-certified commercial pilot and flight instructor
- Founded "Global Girl Inc" and "Aviloop LLC"
- Federal cooperator providing information to DOJ 2018-2022
- Received $10M trust annuity
- FBI certification as trafficking victim (I-914)

**Current Status:** Disappeared after January 2024 document release; whereabouts unknown as of 2024

---

### 6. LESLIE WEXNER — The Billionaire Patron

**Role:** L Brands/Victoria's Secret founder; Epstein's primary financial client

**Financial Relationship:**
- Only known client of Epstein (despite claims of $1B+ under management)
- Granted Epstein power of attorney (1991) over all private trusts and foundations
- Epstein secured board seat on Wexner Foundation (replacing Wexner's mother)
- 9 East 71st Street townhouse: purchased by Wexner's trust 1989, transferred to Epstein 2011 for $0
- $46M transfer from Epstein's YLK Charitable Fund to Wexner Foundation (2010 — post-conviction)
- FBI co-conspirator designation (August 15, 2019 document)
- Nine phone numbers in black book — most of any single entry

**Contradictions:**
- Wexner claimed relationship ended 2007; $46M transfer occurred 2010
- Wexner claimed Epstein "misappropriated vast sums"; documents show voluntary grant of authority
- Wexner described Epstein's ability to "see patterns in politics and financial markets"

**Current Status:** Deposed by House Oversight Committee February 2026; survivor lawsuits combined into one case (July 2026)

---

### 7. LEON BLACK — The $170M Client

**Role:** Apollo Global Management co-founder

**Financial Relationship:**
- Paid $158-170M to Epstein (2012-2017) through Southern Trust Company
- Payments via Bank of America wire transfers ($10M-$20M installments)
- Service: restructuring flawed 2006 GRAT (described as "grand slam" resolving $500M-$1B estate tax liability)
- $62.5M settlement with USVI (January 2023, no admission)

**Legal Issues:**
- Jane Doe lawsuit (July 2023): alleged trafficking of 16-year-old to Black (2002)
- Shareholder securities class action (March 2026): Apollo, Black, Marc Rowan — concealing Epstein ties
- Brad Karp (Paul Weiss chairman): emails showed tracking/deportation strategy against woman; resigned February 2026

**Current Status:** Never charged; net worth ~$13.8B; largest individual Apollo shareholder (~7%)

---

### 8. GLENN DUBIN — The Hedge Fund Gateway

**Role:** Highbridge Capital co-founder; billionaire hedge fund manager

**Key Connections:**
- Epstein early investor in Highbridge Capital
- Epstein helped JPMorgan acquire Highbridge
- Epstein served as godfather to Dubins' children
- Wife Eva Andersson-Dubin (former Miss Sweden) dated Epstein 1980s
- Eva introduced hedge fund manager David Fiszel to Epstein (2016)

**Allegations:**
- Virginia Giuffre deposition (2016): directed by Epstein to have sexual contact with Dubin while Andersson-Dubin was pregnant
- Rinaldo Rizzo (former Dubin butler): testified about distressed young woman at Dubin residence
- JPMorgan SAR: named in $1.08B suspicious activity report
- Epstein allegedly introduced Dubin to Jes Staley (2004), preceding JPMorgan's Highbridge acquisition

**Current Status:** No criminal charges; denied all allegations

---

### 9. JES STALEY — The Banking Enabler

**Role:** Former Barclays CEO; former JPMorgan private banking head

**Banking Relationship:**
- Advocated to keep Epstein's checking account after 2008 conviction
- Shared confidential JPMorgan information with Epstein
- Referred to Epstein as "a smart friend to help me think through this stuff"
- Suggested getting Epstein out of prison "for the weekend" to discuss business
- JPMorgan generated "well over $100 million" from Epstein's referrals
- Named as trustee in Epstein's Trust One and Trust Two (2012 amendments — never executed)

**Regulatory Consequences:**
- Permanently banned by UK FCA for misleading regulators
- Fined £1.1M (July 2025)
- JPMorgan sued Staley (March 2023)
- FBI Guardian complaint (2021): accusations of violent rape and human trafficking — closed "Information Only"

**Key Email Cache:**
- Personal vacation updates
- Epstein arranging Davos meetings
- Acting as informal PR adviser
- Personal/geopolitical commentary

**Current Status:** Testified before House Oversight July 2026; admitted sharing confidential bank info

---

### 10. LARRY VISOSKI — The Chief Pilot

**Role:** Epstein's chief pilot (1991-2019); 28 years; ~1,000 flights

**Flight Operations:**
- 439 documented flight log entries
- 27,746 case documents
- 57 email records
- Flew Gulfstream and Boeing 727 ("Lolita Express")
- Routes: NY, Palm Beach, New Mexico, USVI, international

**Key Testimony:**
- Maxwell trial prosecution's first witness (November 30, 2021)
- Described Maxwell as "Number 2" managing "all of Epstein's non-business affairs"
- Piloted Bill Clinton on 20+ flights
- Never witnessed sexual activity, sex toys, used condoms, or unaccompanied minors
- Received: property gifts, college tuition payments, $10M bequest in will

**Top Co-Passengers:**
- Jeffrey Epstein: 185 shared flights
- Ghislaine Maxwell: 153 shared flights
- Clare Hazell-Iveagh: 21 shared flights
- Virginia Giuffre: 14 shared flights
- Gwendolyn Beck: 10 shared flights

**Current Status:** Witness only; never charged

---

### 11. DAVID RODGERS — The Log Keeper

**Role:** Epstein's pilot (1991-2019); 30 years; maintained handwritten passenger manifests

**Key Facts:**
- 447 case documents
- Maintained Boeing 727 (N908JE) manifests
- Flight logs became key evidence in investigations
- Described Maxwell as "number two" in 2016 deposition
- Proposed Boeing 727 sale to Qatari buyer (2012 email)
- Flight log submitted at Maxwell trial was "overly redacted" per Judge Nathan

**Key Connections:**
- Jeffrey Epstein: 175 shared documents
- Ghislaine Maxwell: 57 shared documents
- Bill Clinton: 16 shared documents
- Donald Trump: 30 shared documents (1995 flights)

**Current Status:** Witness; testified at Maxwell trial 2021

---

### 12. ALFREDO RODRIGUEZ — The Butler Who Talked

**Role:** House manager/butler at Palm Beach estate (1999-2004)

**Key Actions:**
- Stole Epstein's "black book" (97-page spiral-bound contact directory)
- Kept it hidden for years
- Attempted to sell to attorneys for $50,000
- Described it as "Holy Grail" of evidence
- FBI intercepted via undercover operation (November 3, 2009)
- Circled 50 names of interest to investigators
- Provided sworn testimony about young women and sex toys
- Was instructed by Epstein to be "blind, deaf, and dumb"

**Conviction:**
- Pleaded guilty to obstruction of justice (2011)
- Sentenced to 18 months federal prison
- Died of mesothelioma December 28, 2014 (age ~60)

**Key Documents:**
- Household bank account with Epstein and Maxwell
- DOJ Data Set 7: Butler Investigation
- Black book published by Gawker 2015

---

### 13. JUAN ALESSI — The Long-Serving Manager

**Role:** Head house manager at Palm Beach estate (1991-2002)

**Key Testimony:**
- Maxwell trial prosecution witness (December 2, 2021)
- Described Maxwell as "lady of the house" who "right away took over"
- Picked up victim "Jane" from school (age 14-15)
- "Other girls constantly flying in"
- Daily massage schedule: morning/afternoon/evening
- Household Manual: "see nothing, hear nothing, say nothing"
- "Blind, deaf, and dumb" instruction
- Warned Epstein before quitting: "one of those girls is going to get you in trouble"
- Epstein replied: "they only want money"

**Separation Agreement (January 2, 2003):**
- $30,000 to Juan + $20,000 to wife Maria + COBRA
- NDA and full release of claims against Epstein, Maxwell, and entities

**Named Visitors to Palm Beach:**
- Trump, Senator George Mitchell, JFK Jr., Dershowitz, Wexner, Prince Andrew, Nobel laureates

**Current Status:** Witness; cooperated with Maxwell trial

---

### 14. EMMY TAYLER — The Critical Witness

**Role:** Personal assistant to Ghislaine Maxwell (1997-2001)

**SDNY Assessment:**
- "Potentially the most critical person in the case"
- Only non-victim witness to sexual abuse
- When she left, replaced by Sarah Kellen (individual prosecutors were "considering charging")
- "Main victim recalls that Taylor was present during instances of sexual abuse"
- Could be "the only witness to that conduct other than the victim"

**Evidence:**
- 200 flight log entries
- 62 case documents
- Black book: 2 phone numbers
- Johanna Sjoberg deposition: Tayler showed her how to massage Epstein, then participated
- Judge Loretta Preska recognized Tayler as victim of trafficking (2024)

**Legal Actions:**
- Sued Julie K. Brown and HarperCollins for defamation
- HarperCollins apologized and settled (February 2024)
- Identified as victim by court order

**Current Status:** No criminal charges; identified as victim; case managed by OIA for London interview

---

## FINANCIAL FLOW SUMMARY

```
WEXNER ($1B+) ──→ EPSTEIN ──→ SHELL COMPANIES (686 entities)
                    │                    │
                    ├→ LEON BLACK ($170M)├→ DEUTSCHE BANK (all HIGH risk)
                    │                    ├→ JPMORGAN ($1.08B SAR)
                    ├→ DUBIN (investment)├→ SOUTHERN TRUST (USVI)
                    │                    ├→ HBRK ASSOCIATES (Kahn)
                    └→ STALEY (banking)  └→ BEAR STEARNS (collapsed)
```

**Total Tracked:** $6.8 billion in forensic financial records across 2,385 financial flows and 686 entities

**Shell Company Universe (Deutsche Bank - ALL HIGH Risk):**
- Jeffrey E. Epstein (GCIS# 483289)
- Southern Financial LLC (GCIS# 483882)
- Southern Trust Company Inc (GCIS# 483883)
- Butterfly Trust (GCIS# 486426)
- JEGE LLC
- Neptune LLC
- Plan D LLC
- HBRK Associates
- Darren K. Indyke PLLC

---

## CROSS-CUTTING FINDINGS

1. **NPA Immunity Network:** 5 named co-conspirators (Kellen, Marcinkova, Groff, Adriana Ross, + unnamed) shielded from prosecution
2. **FBI Co-Conspirator Designations:** Wexner, Groff, Brunel named in August 2019 FBI CID document
3. **Settlement Total:** $687M+ (JPMorgan $365M + USVI $105M + Indyke/Kahn $25-35M + Black $62.5M + estate compensation $121M+)
4. **Pilot Network:** Visoski (1,000 flights) + Rodgers (1,000 flights) + Marcinkova (267 flights) = transportation infrastructure
5. **Banking Relationships:** Deutsche Bank (all HIGH risk) → JPMorgan ($1.08B SAR) → collapsed institutions (Bear Stearns)
6. **Household Staff as Witnesses:** Alessi, Rodriguez provided ground-level testimony; Rodriguez's black book became key evidence
7. **Maxwell's "Number 2" Status:** Confirmed by both Visoski (pilot) and Rodgers (pilot) independently

---

## RECOMMENDATIONS FOR AGENT 9

Agent 9 should investigate:
1. **The Deutsche Bank Relationship Managers:** Paul Morris, Stewart Oldfield — direct banking facilitators
2. **The NPA Negotiators:** Alexander Acosta, Krischer — prosecutorial decisions
3. **The Shell Company Network:** Southern Trust, JEGE, Neptune, Plan D — entity-level financial flows
4. **The Bear Stearns Connection:** Financial Trust Company — $1.08B in untraceable activity through collapsed institution
5. **The Investment Network:** Block chain Capital, Tudor Futures — where Epstein's money flowed
6. **The Charity Pipeline:** YLK Charitable Fund → Wexner Foundation ($46M post-conviction)
7. **The OCDETF Investigation:** 10 federal agencies, sealed indictments, "Chain Reaction" investigation shut down
8. **The Inconvenient Witnesses:** Emmy Tayler's missing 302s, Kellen's FBI interview, Marcinkova's cooperation agreement

---

*Sources: epsteinexposed.com, epstein-data.com, epsteinwiki.com, court filings, DOJ EFTA releases, House Oversight Committee documents*
*All claims sourced to public record. Inclusion does not imply guilt.*
