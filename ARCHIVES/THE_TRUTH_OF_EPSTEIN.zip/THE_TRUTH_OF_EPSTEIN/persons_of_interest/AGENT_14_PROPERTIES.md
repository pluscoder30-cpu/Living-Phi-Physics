# AGENT 14: PROPERTY NETWORK

## THE GEOGRAPHIC CAGE

Epstein owned or controlled properties across multiple jurisdictions. Each property served a specific function in the cage.

---

## PRIMARY PROPERTIES

### 1. Little St. James — US Virgin Islands
| Field | Detail |
|-------|--------|
| **Location** | Private island, USVI |
| **Size** | 72 acres |
| **Purchase** | 1998, $7.95M |
| **Nickname** | "Pedophile Island," "Orgy Island" |
| **Structures** | Main house, guest houses, temple-like structure |
| **Function** | Primary trafficking location |
| **Staff** | Full-time staff maintained year-round |
| **Visitors** | Hundreds of documented visitors |
| **Confidence** | [V] — Court records, flight logs, witness testimony |

### 2. Great St. James — US Virgin Islands
| Field | Detail |
|-------|--------|
| **Location** | Adjacent to Little St. James |
| **Size** | 165 acres |
| **Purchase** | 2016, $17.5M |
| **Function** | Expansion of island operations |
| **Unpermitted** | Land clearing reported to Governor Bryan |
| **Confidence** | [V] — Property records, DOJ files |

### 3. 9 East 71st Street — Manhattan
| Field | Detail |
|-------|--------|
| **Location** | Upper East Side, Manhattan |
| **Size** | 40,000+ sq ft (largest private home in NYC) |
| **Purchase** | 1989, $13.7M (from Les Wexner) |
| **Function** | Primary residence, events, meetings |
| **Townhouse** | 7 floors, art collection, staff |
| **Events** | Dinners, gatherings, intellectual events |
| **Staff** | Juan Alessi (house manager, 11 years) |
| **Confidence** | [V] — Property records, court testimony |

### 4. Palm Beach Mansion — Florida
| Field | Detail |
|-------|--------|
| **Location** | Palm Beach, FL |
| **Size** | 14,000+ sq ft |
| **Purchase** | 1990, $2.5M |
| **Function** | Secondary trafficking location |
| **Staff** | Alfredo Rodriguez (house manager) |
| **Operations** | Primary recruitment and abuse site |
| **Police** | 2005 Palm Beach Police investigation |
| **Confidence** | [V] — Court records, police reports |

### 5. Zorro Ranch — New Mexico
| Field | Detail |
|-------|--------|
| **Location** | Stanley, New Mexico |
| **Size** | 33,000+ acres (largest private ranch in NM) |
| **Purchase** | 1993, $4.2M |
| **Function** | Retreat, privacy, seclusion |
| **Structures** | Main house, guest houses, airstrip |
| **Visitors** | Political and academic figures |
| **Confidence** | [V] — Property records |

### 6. Paris Apartment — France
| Field | Detail |
|-------|--------|
| **Location** | Avenue Foch, Paris |
| **Size** | 7-bedroom apartment |
| **Function** | European base of operations |
| **Visitors** | International figures |
| **Steve Bannon** | Stayed at Paris apartment March 2019 |
| **Confidence** | [V] — DOJ files, Bannon texts |

---

## THE MANHATTAN BUILDING: 301 E. 66TH STREET

### A Special Property
| Field | Detail |
|-------|--------|
| **Owner** | Company connected to Mark Epstein |
| **Control** | Jeffrey Epstein |
| **Function** | Housing for models, Israeli security |
| **Units** | Loaned to Epstein contacts |
| **Israeli Security** | Installed 2016, maintained 2+ years |
| **Barak** | Frequent extended stays ("Ehud's apartment") |
| **Models** | Used to house underage models |
| **Surveillance** | Window sensors, remote access, Israeli government |
| **Confidence** | [V] — DOJ emails, Drop Site News |

---

## PROPERTY AS CAGE INFRASTRUCTURE

### How Properties Functioned
```
Palm Beach → Recruitment → Initial abuse
    ↓
Manhattan → Social events → Networking → Further abuse
    ↓
Island → Seclusion → Complete control → Compromise material
    ↓
Zorro Ranch → Privacy → Retreat → Planning
    ↓
Paris → International operations → European connections
    ↓
301 E 66th → Models housing → Israeli security → Surveillance
```

### The Geographic Pattern
Properties span multiple jurisdictions:
- **USVI** — Outside US mainland jurisdiction
- **New Mexico** — Remote, isolated
- **Florida** — Warm climate, social scene
- **Manhattan** — Urban, accessible, prestigious
- **Paris** — International, European connections

Each jurisdiction provides different legal protections and operational advantages.

---

*Agent 14 findings. Properties are the physical infrastructure of the cage.*
