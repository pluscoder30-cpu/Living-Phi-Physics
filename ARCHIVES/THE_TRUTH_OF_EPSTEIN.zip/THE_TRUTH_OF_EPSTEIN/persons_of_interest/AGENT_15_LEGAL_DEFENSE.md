# AGENT 15: LEGAL/DEFENSE TEAM

## THE LEGAL PROTECTION SPOKE

The legal team provided the most critical cage function: the 2007-2008 Non-Prosecution Agreement (NPA) that terminated the FBI investigation and granted immunity to unnamed co-conspirators.

---

## KEY LEGAL FIGURES

### 1. Alan Dershowitz — Defense Team Leader
| Field | Detail |
|-------|--------|
| **Role** | Epstein's lead defense attorney |
| **Institution** | Harvard Law School |
| **NPA** | Part of team that negotiated 2008 plea deal |
| **FBI FD-1023** | CHS alleged Dershowitz "co-opted by Mossad" |
| **Intelligence** | Told Acosta "Epstein belonged to both U.S. and allied intelligence services" |
| **Flights** | 15 flights on Epstein planes (1996-2006) |
| **Massages** | Giuffre alleged Dershowitz received massages |
| **Denial** | Vigorously denied all allegations |
| **JPMorgan SAR** | Flagged in suspicious activity report |
| **Confidence** | [V] — FBI FD-1023, court records, flight logs |

### 2. Jay Lefkowitz — NPA Negotiator
| Field | Detail |
|-------|--------|
| **Firm** | Kirkland & Ellis |
| **Role** | Led NPA negotiations for Epstein |
| **NPA Terms** | Immunity for Epstein + unnamed co-conspirators |
| **Impact** | Terminated FBI investigation |
| **Confidence** | [V] — Court records, DOJ OPR report |

### 3. Kenneth Starr — Defense Team Member
| Field | Detail |
|-------|--------|
| **Role** | Independent Counsel (Whitewater), part of Epstein defense |
| **Function** | Legal firepower, public credibility |
| **Confidence** | [V] — Court records |

### 4. Alexander Acosta — Prosecutor Who Became Defense
| Field | Detail |
|-------|--------|
| **Role** | U.S. Attorney, Southern District of Florida |
| **Action** | Negotiated 2008 NPA |
| **Terms** | 13 months jail (one day/week work release) |
| **Immunity** | Granted to unnamed co-conspirators |
| **Victims** | Never consulted |
| **Draft** | 60-count draft indictment abandoned |
| **Intelligence** | Allegedly told by Dershowitz that Epstein "belonged to intelligence" |
| **Later** | Became Trump's Labor Secretary (resigned July 2019) |
| **Testimony** | Testified before House Oversight Sept 2025 |
| **Confidence** | [V] — NPA document, DOJ OPR report, FBI FD-1023 |

### 5. Brad Edwards — Giuffre's Attorney (Anti-Cage)
| Field | Detail |
|-------|--------|
| **Role** | Represented Virginia Giuffre |
| **Function** | Pursued justice against the cage |
| **Lawsuits** | Filed multiple lawsuits against Epstein associates |
| **Confidence** | [V] — Court records |

### 6. David Boies — Giuffre's Attorney (Anti-Cage)
| Field | Detail |
|-------|--------|
| **Role** | Represented Giuffre v. Maxwell |
| **Firm** | Boies Schiller Flexner |
| **Function** | Led unsealing efforts |
| **Confidence** | [V] — Court records |

---

## THE 2008 NPA: THE CAGE'S MOST IMPORTANT DOCUMENT

### Terms
- Epstein pleaded guilty to state charges (soliciting prostitution with a minor)
- **13 months** in county jail (one day/week work release)
- **Registered** as sex offender
- **Federal investigation terminated**
- **Immunity** granted to unnamed co-conspirators
- **Victims never consulted**

### Impact
- **60-count draft indictment abandoned**
- **FBI investigation halted**
- **Co-conspirators protected** (Kellen, Marcinkova, Brunel, Maxwell)
- **No further prosecution** until 2019

### The Intelligence Connection
The FBI FD-1023 alleges:
- Dershowitz told Acosta that "Epstein belonged to both U.S. and allied intelligence services"
- This allegedly influenced the lenient plea deal
- The NPA was the legal manifestation of intelligence protection

---

## THE LEGAL CAGE FUNCTION

### How Legal Protection Worked
1. **Defense team** — High-profile attorneys shielded Epstein
2. **Plea deal** — NPA terminated federal investigation
3. **Co-conspirator immunity** — Protected operational figures
4. **Settlement pressure** — Civil cases settled with confidentiality
5. **Delay tactics** — Defense strategy delayed prosecution until death

### The Result
A convicted sex offender who:
- Served 13 months (work release)
- Had federal investigation terminated
- Had co-conspirators protected
- Maintained all properties and assets
- Continued operating for 11 more years

---

*Agent 15 findings. The legal team provided the most critical cage function: the NPA.*
