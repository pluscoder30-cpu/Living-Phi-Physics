# Co-Conspirator & NPA Analysis: Jeffrey Epstein Case

**Agent:** 23 of 25  
**Date:** 2026-08-28  
**Focus:** Co-conspirators, immunity agreement, and post-NPA conduct

---

## 1. THE 2008 NON-PROSECUTION AGREEMENT (NPA)

### Document Details
- **Signed:** September 24, 2007
- **Parties:** U.S. Attorney's Office for the Southern District of Florida (USAO-SDFL) & Jeffrey E. Epstein
- **U.S. Attorney:** R. Alexander Acosta
- **Case:** Federal investigation into sex trafficking and conspiracy (2001-2007)

### Key Terms of the NPA

| Term | Description |
|------|-------------|
| **Guilty Plea** | Epstein pled guilty to Florida state charges: solicitation of prostitution and procurement of minors for prostitution |
| **Sentence** | 18 months county jail (later served 13 months with work release) |
| **Sex Offender Registration** | Required to register in all applicable jurisdictions |
| **Victim Compensation** | Epstein agreed to provide compensation to identified victims |
| **Federal Immunity** | USAO agreed not to institute federal criminal charges against Epstein |
| **Co-Conspirator Immunity** | Extended to "any potential co-conspirators of Epstein" |
| **Grand Jury Suspension** | All pending federal grand jury subpoenas held in abeyance |
| **Confidentiality** | Both parties agreed NPA would not be part of any public record |
| **Victim Notification** | USAO provided Epstein's attorneys with list of identified victims AFTER sentencing |

### The Critical Immunity Clause

> "In consideration of Epstein's agreement to plead guilty and to provide compensation in the manner described above, if Epstein successfully fulfills all of the terms and conditions of this agreement, the United States also agrees that it will not institute any criminal charges against any potential co-conspirators of Epstein, **including but not limited to** Sarah Kellen, Adriana Ross, Lesley Groff, or Nadia Marcinkova."

**Three critical words: "but not limited to"** — This phrase extended immunity to ANY person who may have assisted Epstein, whether identified or not, whether investigated or not.

---

## 2. NAMED CO-CONSPIRATORS IN THE NPA

### Primary Named Co-Conspirators (4 Women)

| Name | Role | Status |
|------|------|--------|
| **Sarah Kellen** | Epstein's personal assistant; arranged massage appointments in NYC | Investigated by SDNY; investigation concluded December 2021 without charges |
| **Adriana Ross** | Worked from Epstein's NYC residence as personal assistant; coordinated massage appointments | Investigated by SDNY; no charges filed |
| **Lesley Groff** | Epstein's longtime secretary; arranged appointments in Florida | Investigated by SDNY; investigation concluded December 2021 without charges |
| **Nadia Marcinkova** | Recruiter and assistant; traveled with Epstein as personal assistant | Investigated; information indicates she facilitated massage appointments |

### FBI Co-Conspirator Designation (August 15, 2019)

The FBI Criminal Investigative Division document listed **8 co-conspirators**, 4 unredacted:

| Name | FBI Status | Notes |
|------|-----------|-------|
| **Les Wexner** | Named co-conspirator | Former CEO of Victoria's Secret; "limited evidence regarding his involvement"; attorneys said AUSA told counsel in 2019 he was "neither a co-conspirator nor target" |
| **Lesley Groff** | Named co-conspirator | Investigation concluded December 2021 without charges |
| **Jean-Luc Brunel** | Named co-conspirator | Owner of MC2 model agency; charged in France; died by suicide in prison February 2022 before trial |
| **Ghislaine Maxwell** | Named co-conspirator | Convicted December 2021; sentenced to 20 years prison |
| **[REDACTED 1]** | Unknown | Four names still redacted |
| **[REDACTED 2]** | Unknown | Likely female recruiters/victims who became co-conspirators |
| **[REDACTED 3]** | Unknown | DOJ stated some were victims who had been cooperating with investigators |
| **[REDACTED 4]** | Unknown | |

---

## 3. FBI CLASSIFICATION OF CO-CONSPIRATORS (2019)

### Primary Co-Conspirators (Active Participants)

| Location | Description | Status |
|----------|-------------|--------|
| **New York City** | Currently living in NYC but owns homes in Miami and North Carolina; arranged massage appointments | Subpoena served |
| **Florida** | Currently living in Florida; has been cooperating and provided information during proffer | Cooperating |
| **Boston, MA** | Currently living in Boston; at least one employee observed her recruit a victim | Subpoena served; reverse proffer set for September |
| **New York City** | Currently resides in NYC; in contact with attorneys; subpoena served | Under investigation |
| **Ghislaine Maxwell** | Property manager; considered one of the main co-conspirators; "limited information regarding Maxwell's involvement" | Subpoena served |

### Secondary Co-Conspirators (Limited Evidence)

| Name | Description | Status |
|------|-------------|--------|
| **Jean-Luc Brunel** | Owner of MC2 model agency; FBI drafted FDR requesting assistance from Legat London | Died in custody 2022 |
| **[Redacted - London]** | Currently living in London since approximately 2011; not a US citizen; limited evidence; facilitated massage appointments | FBI drafted assistance request |
| **Leslie Wexner** | Resides in Ohio; limited evidence regarding involvement | Subpoena served |

---

## 4. THE 305 PERSONS LIST (DOJ 2026)

### Overview
The DOJ released a list of 305 "politically exposed persons" in response to the Epstein Files Transparency Act. The list was NOT a co-conspirator list — it included anyone named in the millions of released documents regardless of context.

### Categories of Persons

| Category | Examples | Context |
|----------|----------|---------|
| **Direct Contact** | Trump, Clinton, Wexner, Gates | Extensive email contact, flight logs, or documented relationships |
| **Indirect Reference** | Princess Diana, Elvis Presley, Michael Jackson | Mentioned in press clippings or archived documents; no evidence of interaction |
| **Flight Log Passengers** | Trump (8 flights), various associates | Listed as passengers on Epstein's aircraft |
| **Political Figures** | Bill Clinton, Steve Bannon, Howard Lutnick | Various degrees of association |
| **Business Leaders** | Les Wexner, Leon Black, Elon Musk, Bill Gates | Financial or social connections |
| **Royals** | Prince Andrew | Documented friendship with Epstein |
| **Foreign Dignitaries** | Sultan Ahmed bin Sulayem (Emirati businessman) | Appears 4,700+ times in files |
| **Deceased** | Princess Diana, Elvis Presley, Michael Jackson | Incidental mentions in documents |

### Key Distinction
The DOJ letter stated: "Names appear in the files released under the Act in a wide variety of contexts... some individuals had extensive direct email contact with Epstein or Maxwell while other individuals are mentioned only in a portion of a document (including press reporting) that on its face is unrelated to the Epstein and Maxwell matters."

**No one on the list other than Epstein and Maxwell has ever been charged in connection with Epstein's crimes.**

---

## 5. THE IMMUNITY CLAUSE — DEEP ANALYSIS

### What the Clause Covered

1. **Four Named Women** — Kellen, Ross, Groff, Marcinkova (employees who assisted in recruitment/scheduling)
2. **"Any potential co-conspirators"** — Unbounded scope covering anyone who assisted Epstein
3. **"Known and unknown"** — Protected even persons not yet identified
4. **Federal charges only** — Did not preempt state prosecution (though state charges were also resolved)

### Legal Implications

- **Unprecedented Scope:** "I have never heard of a case where an NPA extended to people who haven't been investigated or charged yet," said former Miami federal prosecutor Richard Gregorie.
- **CVRA Violation:** Federal court found the government violated the Crime Victims' Rights Act by entering into the secret NPA without conferring with victims.
- **No Definition:** The NPA never defined the limits of who qualified as a "potential co-conspirator."
- **Confidentiality Clause:** Both parties agreed the NPA would not be made part of any public record.

### Why It Matters Today
- Ghislaine Maxwell is appealing her 20-year sentence, arguing the immunity clause invalidates her conviction
- Courts have said the immunity deal applies only in Florida (if at all) — Maxwell was tried in New York
- The clause potentially shields any unidentified persons who assisted Epstein

---

## 6. ALEXANDER ACOSTA'S ROLE

### The "Belonged to Intelligence" Claim

| Source | Quote | Context |
|--------|-------|---------|
| **Vicky Ward (Daily Beast, 2019)** | "I was told Epstein 'belonged to intelligence' and to leave it alone" | Anonymous "former senior White House official" source; alleged Acosta said this during Trump transition interview for Labor Secretary |
| **Acosta (Press Conference, 2019)** | "There has been reporting to that effect... I would hesitate to take this reporting as fact" | Evasive public response |
| **Acosta (DOJ OPR Interview, 2019)** | "No, and no" when asked if Epstein was an intelligence asset | Under oath to federal investigators |
| **Acosta (House Oversight, Sept 2025)** | "I have not" made such a statement; "No" to CIA, NSA, FBI intelligence contacts; "I have no reason to believe" Epstein was an asset | Congressional testimony under oath |

### OPR Findings on Acosta

The DOJ Office of Professional Responsibility investigation found:
- **No professional misconduct** by Acosta or other prosecutors
- Acosta exercised **"poor judgment"** by resolving the federal investigation through a state plea
- The NPA was based on a **"flawed application of the Petite Policy"** and federalism concerns
- Acosta **failed to ensure victims were informed** of the state plea hearing
- **No evidence** that Acosta was influenced by improper motive (bribe, political consideration, personal interest, or favoritism)
- **No evidence** that Epstein cooperated in other federal investigations or received special treatment on that basis

### Critical Questions Unanswered
- Who told Acosta to "back off"?
- Why was a 53-page federal indictment abandoned for a state plea to two misdemeanors?
- Why did the government agree to immunize "any potential co-conspirators" without investigation?
- Why was the NPA kept secret from victims?

---

## 7. VICTIM IMPACT

### Victim Counts

| Metric | Count | Source |
|--------|-------|--------|
| **FBI Miami victims interviewed** | 28-35+ | FBI investigation summary |
| **SDNY "dozens of victims"** | 24+ | SDNY press release |
| **Named minor victims (Maxwell trial)** | 5 | Minor Victim-1 through 5 |
| **Jane Doe civil designations** | 43+ | Court filings |
| **Victims' compensation fund** | 150 paid out $120M+ | Fund data (as of August 2021) |
| **FBI confirmed victims** | 34 minors (later 40) | FBI investigative accounting |
| **Total identified victims** | 1,000+ | DOJ memo (July 2025) |
| **Files-referenced victims** | 1,200+ | UN experts, document review |

### How Victims Were Denied Justice

1. **Secret NPA:** Victims not informed of the agreement before or after signing
2. **Active Misrepresentation:** After signing NPA, USAO sent letters to victims saying case was "still under investigation"
3. **No Consultation:** Government never conferred with victims about the NPA as required by CVRA
4. **Work Release:** Epstein served only 13 months of 18-month sentence, with 12 hours/day, 6 days/week in his office
5. **No Federal Trial:** Victims never had opportunity to testify in federal proceedings
6. **Co-Conspirator Immunity:** Those who recruited and groomed victims faced no federal charges
7. **Statute of Limitations:** By the time the NPA was challenged, some claims were time-barred

### Court Findings
- **2019:** District Court ruled government violated CVRA by entering secret NPA without consulting victims
- **2021:** 11th Circuit (6-4) rejected victims' challenge, finding CVRA doesn't apply pre-charge
- **Dissent (Judge Hull):** "The majority's ruling leaves federal prosecutors free to engage in the secret plea deals and deception pre-charge that resulted in the travesty here"

---

## 8. POST-NPA CONDUCT

### Did Protected Persons Continue Criminal Activity?

| Person | Post-2008 Activity | Status |
|--------|-------------------|--------|
| **Ghislaine Maxwell** | Continued recruiting and grooming victims through at least 2015-2018; SDNY investigation found ongoing activity | Convicted 2021; 20-year sentence |
| **Jean-Luc Brunel** | Continued modeling agency operations; French investigation found victims | Charged in France; died in custody 2022 |
| **Les Wexner** | Continued business operations; severed ties with Epstein publicly in 2019 | Never charged; FBI says "limited evidence" |
| **Sarah Kellen** | Continued employment with Epstein post-NPA | SDNY investigation concluded 2021 without charges |
| **Lesley Groff** | Continued employment with Epstein through at least 2018 (calendar evidence) | SDNY investigation concluded 2021 without charges |

### Evidence of Ongoing Activity
- Kellen plea drafts documented "hundreds of appointments" across 2002-2018
- Groff calendars showed scheduling activity through 2018
- Epstein's residence in USVI had "hundreds" of trafficked individuals (per AG lawsuit)
- FBI identified over 1,000 victims spanning 20+ years

---

## 9. NPA VIOLATIONS

### Potential Violations

| Violation | Evidence | Outcome |
|-----------|----------|---------|
| **Epstein's death** | Suicide in federal custody August 10, 2019 | NPA became moot |
| **Continued criminal activity** | Evidence of ongoing trafficking post-NPA | Never prosecuted federally |
| **CVRA violation** | Court found government violated victims' rights | No remedy granted (11th Circuit) |
| **Confidentiality breach** | NPA became public through litigation | DOJ claimed it was "anticipated" not to be public |

### The Central Problem
The NPA created a paradox: if Epstein violated its terms (by continuing criminal activity), the USAO could reinstate prosecution — but the USAO never did so, and Epstein died before any federal action was taken.

---

## 10. MAXWELL'S SENTENCE AND COOPERATION

### 20-Year Sentence
- **Conviction:** December 2021 (SDNY)
- **Charges:** Sex trafficking of minors, conspiracy, transportation of a minor for illegal sexual activity
- **Sentence:** 20 years federal prison

### 2025 DOJ Interview (Proffer Agreement)

**Date:** July 24-25, 2025  
**Interviewer:** Deputy Attorney General Todd Blanche  
**Agreement:** Limited immunity (proffer agreement — not cooperation agreement)

Key points from transcript:
- Maxwell said she had **never been approached by government** to speak before
- She claimed she was **"very keen to talk to anyone"** from the government
- She stated **"there is no list"** of clients
- She denied knowledge of any **blackmail scheme**
- She said she never witnessed inappropriate activity by **Trump, Clinton, or others**
- She reportedly provided information on **"100 different people"** linked to Epstein

### What Maxwell Revealed
- **No client list exists** (per her claim)
- **No blackmail operation** (per her claim)
- **No criminal activity by named individuals** (per her claim)
- Attorney David Markus said: "The truth will come out about what happened with Mr. Epstein and she's the person who's answering those questions"

### Criticism
- Interview was conducted with **limited immunity** — nothing she said could be used against her (except lies)
- **Not a cooperation agreement** — government made no promises
- Victims' attorneys skeptical of Maxwell's claims
- Dershowitz stated Maxwell was "really serving Jeffrey Epstein's sentence"

---

## 11. COOPERATION AGREEMENTS

### Persons Who Cooperated

| Person | Cooperation | Outcome |
|--------|-------------|---------|
| **Ghislaine Maxwell** | Proffer agreement (July 2025) — limited immunity | Still serving 20-year sentence; no deal announced |
| **Unnamed Florida resident** | Cooperated during proffer; provided information on Kellen, Marcinkova, and Maxwell | Status unknown |
| **Jean-Luc Brunel** | Cooperated with French investigators | Died in custody 2022 |
| **Various victims** | FBI tip line; dozens of interviews | Information used in investigations |

### No Federal Cooperation Deals
- No publicly announced cooperation agreements resulting in reduced sentences
- Maxwell's proffer was explicitly NOT a cooperation agreement
- Government stated it found "no credible information" others were involved in sex-trafficking scheme

---

## 12. MISSING PERSONS / DEATHS

| Person | Status | Circumstances |
|--------|--------|---------------|
| **Jeffrey Epstein** | Deceased | Suicide in federal custody, August 10, 2019; guards falsified records; cameras "malfunctioned" |
| **Jean-Luc Brunel** | Deceased | Suicide in French prison, February 2022; awaiting trial for sex trafficking |
| **[Redacted 4 names from FBI list]** | Unknown | Four co-conspirator names remain redacted in 2019 FBI document |

---

## 13. CROSS-REFERENCE ANALYSIS

### Persons Appearing in Multiple Categories

| Person | NPA Named | FBI Co-Conspirator | 305 List | Maxwell Trial | Civil Suits |
|--------|-----------|-------------------|----------|---------------|-------------|
| **Ghislaine Maxwell** | ✗ (not in NPA) | ✓ | ✓ | ✓ (defendant) | ✓ |
| **Sarah Kellen** | ✓ | ✓ | Unknown | Referenced | ✓ |
| **Lesley Groff** | ✓ | ✓ | Unknown | Referenced | ✓ |
| **Nadia Marcinkova** | ✓ | ✓ (redacted?) | Unknown | Referenced | ✓ |
| **Adriana Ross** | ✓ | ✓ (redacted?) | Unknown | Referenced | ✓ |
| **Les Wexner** | ✗ | ✓ | ✓ | Referenced | ✓ |
| **Jean-Luc Brunel** | ✗ | ✓ | Unknown | Referenced | ✓ |

---

## 14. WHAT AGENT 24 SHOULD INVESTIGATE

### Priority Questions

1. **The 4 Redacted Names:** Who are the four still-redacted co-conspirators in the August 2019 FBI document? DOJ released 3 of 8 names — who are the other 5 (4 redacted + 1 unclear)?

2. **The "Sultan" Email:** Epstein's email referencing "torture video" to a "sultan" — what is the full content and context of this communication?

3. **French Investigation Coordination:** Did U.S. authorities respond to French prosecutor Barthélémy Hennuyer's requests for information about Brunel, Maxwell, and 5 other individuals?

4. **SDNY Investigation Outcomes:** Full details on why investigations of Kellen, Groff, and Marcinkova concluded without charges in December 2021.

5. **Wexner's Role:** FBI noted "limited evidence regarding his involvement" — what does the 200+ file references to Wexner actually contain?

6. **Maxwell's Proffer Transcript:** Full analysis of what "100 different people" she discussed and whether any information led to new investigations.

7. **Intelligence Connections:** Senate Intelligence Committee inquiry into Acosta's "belonged to intelligence" claim — was any classified investigation ever initiated?

8. **Victim Lists:** The "multiple victim lists delivered to DOJ on 3/18/2025" and "19+ boxes of physical evidence containing undisclosed victim files" — what do they contain?

9. **Bill Burns (CIA Director):** Documented meetings with Epstein post-2008 — what was discussed?

10. **MEGA Corporation:** Les Wexner's co-founding of MEGA and its alleged use by Israeli intelligence for espionage — full investigation needed.

---

## 15. SUMMARY STATISTICS

| Metric | Count |
|--------|-------|
| **Named co-conspirators in NPA** | 4 (Kellen, Ross, Groff, Marcinkova) |
| **FBI-designated co-conspirators (2019)** | 8 (4 named, 4 redacted) |
| **DOJ 305-person list** | 305 "politically exposed persons" |
| **Total victims identified** | 1,000-1,200+ |
| **Victims compensated** | 150+ ($120M+ from fund) |
| **Persons charged** | 2 (Epstein, Maxwell) |
| **Persons convicted** | 1 (Maxwell) |
| **Persons who died in custody** | 2 (Epstein, Brunel) |
| **Years of criminal activity** | 20+ (early 2000s-2019) |

---

## 16. KEY FINDINGS

1. **The NPA was unprecedented in scope** — extending immunity to unidentified "potential co-conspirators" without investigation or charging.

2. **The "but not limited to" language** created an unlimited shield for anyone who assisted Epstein, known or unknown.

3. **Victims were deliberately kept in the dark** — government actively misrepresented the status of the investigation after signing the NPA.

4. **Only 2 people were ever charged** — Epstein (died) and Maxwell (convicted). No other co-conspirators faced federal charges.

5. **The intelligence question remains unresolved** — Acosta's "belonged to intelligence" claim was never formally investigated by any congressional committee with security clearances.

6. **The 4 redacted FBI co-conspirator names** may represent the most significant unresolved question in the case.

7. **Post-NPA criminal activity continued** — evidence shows trafficking operations persisted for years after the immunity agreement.

8. **Maxwell's 2025 proffer** yielded information on "100 people" but the government found "no credible information" to pursue further charges.

---

**End of Agent 23 Analysis**  
**Agent 24 should investigate:** The 4 redacted co-conspirator names, intelligence connections, French investigation coordination, and SDNY investigation closures.
