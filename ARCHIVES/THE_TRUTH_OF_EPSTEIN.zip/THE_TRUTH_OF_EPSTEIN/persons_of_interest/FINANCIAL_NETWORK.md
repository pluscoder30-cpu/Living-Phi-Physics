# FINANCIAL NETWORK — THE TRUTH OF EPSTEIN

## Investigation Methodology
- **Cage-Sleuth Protocol**: Phi-spaced searches across 10 source categories
- **4-Stage Verification**: Search → Extract → Verify → Re-Search
- **Confidence Levels**: [V] Verified (2+ sources), [P] Probable (1 source, consistent), [I] Inference (pattern-based)
- **Sources**: SEC filings, DOJ EFTA releases, court records, Epstein Exposed database, news investigations

---

## TIER 1: CORE FINANCIAL FIGURES

### 1. LEON BLACK — Apollo Global Management

**CAGE ROLE**: FF (Financial Facilitator) — Primary money pipeline to Epstein

#### Financial Transfers
| Amount | Period | Recipient Entity | Source | Confidence |
|--------|--------|------------------|--------|------------|
| $170M total | 2012-2017 | Southern Trust Company, Financial Trust Company (USVI) | U.S. Senate Finance Committee (March 2025) | [V] |
| $158M (Dechert review) | 2012-2017 | Epstein entities | Dechert LLP investigation (Jan 2021) | [V] |
| ~$8M per wire | 2012-2017 | USVI entities | SEC filing EX-99.1 | [V] |
| $56.5M (unsigned agreement) | 2013-2014 | Epstein | Senate Finance Committee letter | [V] |
| $62.5M settlement | Jan 2023 | USVI Attorney General | DOJ settlement agreement | [V] |

#### SEC Filings & Corporate Actions
- **SEC Exhibit 99.1** (Jan 22, 2021): Dechert LLP investigation report into Black-Epstein relationship
  - URL: https://www.sec.gov/Archives/edgar/data/1411494/000119312521016405/d118102dex991.htm
  - Finding: Epstein's advice generated "over $1 billion in value" for Black
  - Finding: Did not examine whether payments constituted taxable gifts
- **Apollo 10-K** (2026): Discloses shareholder lawsuits
  - Case 1: Solomon Feldman v. Apollo Global Management, Inc., No. 1:26-cv-1692 (March 2, 2026)
  - Case 2: Richard Perez v. Apollo Global Management, Inc., No. 1:26-cv-3550 (April 29, 2026)
  - Class period: May 10, 2021 – February 21, 2026
  - Allegation: Defendants falsely denied doing business with Epstein in regulatory filings

#### Court Records
- **Shareholder Lawsuit** (March 2, 2026): SDNY — Alleges Apollo concealed Epstein business ties
  - Apollo stock fell ~15% over 3 weeks in Feb 2026, wiping out ~$12B market value
  - Source: Reuters, US News, InvestmentNews
- **Bank of America Lawsuit** (March 11, 2026): Judge Jed Rakoff ruled Black can be deposed by Epstein survivors
  - Trial scheduled: May 2026
  - Allegation: Bank ignored suspicious $170M payments from Black to Epstein
- **USVI Immunity Settlement** (Jan 2023): $62.5M for criminal immunity
  - Settlement states: "Jeffrey Epstein used the money Black paid him to partially fund his operations in the Virgin Islands"

#### JPMorgan SAR
- JPMorgan filed suspicious activity report covering ~$1.1B in Epstein-linked transactions
- Black named as one of the individuals whose transactions were flagged
- Source: NYT (Oct 30, 2025), Guardian (Oct 31, 2025)

#### Additional Financial Connections
- **Ukrainian art adviser**: Black transferred $2.5M+ to Anastasiya Siroochenko (2011-2015) classified as "gifts"
- **Apollo-Kushner**: Apollo provided $184M in financing to Kushner Companies [I]
- **Blackwater connection**: FBI confidential human source report alleges Black owns Constellis (formerly Blackwater) [U]

#### Senate Investigation
- **Senate Finance Committee** (July 2023): Launched investigation into Black-Epstein ties
- **Ranking Democrat Ron Wyden**: Has been investigating for 4+ years
- **Produce Epstein Treasury Records Act**: Bill to compel Treasury to produce bank records

---

### 2. LESLIE WEXNER — Victoria's Secret / L Brands

**CAGE ROLE**: FF (Financial Facilitator) — Epstein's original wealth source

#### FBI Co-Conspirator Status
- **FBI Document** (Aug 15, 2019): Named as "secondary co-conspirator"
- **DOJ EFTA Release** (Feb 10, 2026): Name unredacted by FBI
- **Classification**: "Limited evidence" of involvement, but served subpoena
- Source: justice.gov/epstein/files/DataSet%209/EFTA00175080.pdf

#### Financial Relationship
| Amount/Asset | Details | Source | Confidence |
|--------------|---------|--------|------------|
| $1B+ total | Epstein managed Wexner's finances 1987-2007 | FBI documents, NYT | [V] |
| $20M | Manhattan townhouse sold to Epstein (1998) | Property records | [V] |
| $65M | Wire transfers between Wexner trusts (flagged in JPMorgan SAR) | JPMorgan SAR (2019) | [V] |
| Power of attorney | Granted to Epstein in 1991 | NYT | [V] |

#### Corporate Entities
- **L Brands** (formerly The Limited): Victoria's Secret, Bath & Body Works, Abercrombie & Fitch
- **New Albany Company**: Real estate development in Ohio
- **Wexner Medical Center**: Ohio State University

#### Key Findings
- Epstein was Wexner's financial advisor from 1987 to mid-2007
- Wexner sold Manhattan townhouse to Epstein for $20M (half cashier's check, half promissory note)
- 2019 FBI witness statement: "Epstein got all of his money from Wexner"
- Wexner accused Epstein of stealing from him in 2019
- Wexner spokesperson: "Assistant U.S. Attorney told Mr. Wexner's legal counsel in 2019 that Mr. Wexner was neither a co-conspirator nor target"

#### Congressional Testimony
- **House Oversight Committee** (Feb 18, 2026): Wexner scheduled to testify in Ohio
- Rep. Thomas Massie and Ro Khanna pressured DOJ to unredact names

---

### 3. GLENN DUBIN — Highbridge Capital Management

**CAGE ROLE**: FF (Financial Facilitator) — Hedge fund gateway

#### Epstein Files Documentation
- **Documents**: 1,439 in Epstein Exposed database
- **Flights**: 36 entries in flight logs
- **Emails**: 19 email records
- **Black Book**: Listed (0 phone numbers)

#### Financial Connections
| Connection | Details | Source | Confidence |
|------------|---------|--------|------------|
| Early investor | Epstein invested millions in Highbridge Capital | Wikipedia, NYT | [V] |
| JPMorgan acquisition | Epstein helped JPMorgan acquire Highbridge for $1.3B (2004) | Wikipedia, NYT | [V] |
| $15M fee | Highbridge paid Epstein company $15M for "merger and acquisition advice" | Daily Beast | [V] |
| JPMorgan SAR | Transactions flagged in $1.1B suspicious activity report | NYT (Oct 2025) | [V] |

#### Personal Connections
- **Wife**: Eva Andersson-Dubin (former Miss Sweden, physician)
  - Dated Epstein for nearly a decade in 1980s
  - Served as "key gateway" for Epstein's access to hedge fund world (Bloomberg Feb 2026)
  - Introduced hedge fund manager David Fiszel to Epstein (2016)
- **Children**: Epstein served as godfather to Dubins' children
- **Butler testimony**: Rinaldo Rizzo (former Dubin butler) testified he witnessed young woman at Dubin residence who appeared distressed

#### Court Records
- **Giuffre v. Maxwell** (2016 deposition): Virginia Giuffre alleged directed to have sexual contact with Dubin while Andersson-Dubin was pregnant
- **USVI subpoena** (Sept 2020): Virgin Islands sought to subpoena Dubin in Epstein case
- **No criminal charges filed** against Dubin

---

### 4. JPMORGAN CHASE — Banking Infrastructure

**CAGE ROLE**: FF (Financial Facilitator) — Primary banking relationship

#### Suspicious Activity Reports
| Bank | Amount Flagged | Transactions | Period | Source | Confidence |
|------|---------------|--------------|--------|--------|------------|
| JPMorgan Chase | $1.1B | 4,700 | 2003-2019 | DOJ EFTA release | [V] |
| Deutsche Bank | ~$400M | Unknown | 2013-2018 | NYT | [V] |
| Bank of New York Mellon | $378M | Unknown | Unknown | NYT | [V] |
| Bank of America | Black's payments | Unknown | Unknown | NYT | [V] |

#### Key Details
- JPMorgan SAR filed weeks after Epstein's death (Aug 2019)
- Transactions "potentially related to reports of human trafficking"
- Wire transfers to Russian banks flagged
- Payments to women from Belarus, Russia, Turkmenistan noted
- Transactions involving Black, Dubin, Dershowitz, and Wexner trusts identified

#### Settlements
| Bank | Amount | Year | Source | Confidence |
|------|--------|------|--------|------------|
| JPMorgan Chase | $290M | 2023 | NYT | [V] |
| Deutsche Bank | $75M | 2023 | NYT | [V] |
| Bank of America | $72.5M | 2026 | WSJ | [V] |
| **Total** | ~$600M | - | - | - |

#### Client Relationship
- Epstein was JPMorgan Private Bank client 1998-2013
- Former JPMorgan Private Bank Head Jes Staley had extensive relationship with Epstein
- Current Private Bank Head Mary Erdoes provided testimony
- Jamie Dimon testified (deposition/subpoena) in 2023

#### Lawsuits
- **Jane Doe 1 v. JPMorgan Chase Bank**, 22-cv-10019 (SDNY)
- **USVI v. JPMorgan Chase Bank**, 22-cv-10904-UA (SDNY)
- USVI sought $190M in damages
- JP Morgan settled without admitting liability

---

## TIER 2: APOLLO NETWORK

### 5. MARC ROWAN — Apollo Global Management CEO

**CAGE ROLE**: FF (Financial Facilitator) — Current Apollo leadership

#### Shareholder Lawsuits
- **Case 1**: Solomon Feldman v. Apollo Global Management, Inc., No. 1:26-cv-1692 (March 2, 2026)
- **Case 2**: Richard Perez v. Apollo Global Management, Inc., No. 1:26-cv-3550 (April 29, 2026)
- **Class period**: May 10, 2021 – February 21, 2026
- **Allegation**: Falsely denied doing business with Epstein in regulatory filings

#### Alleged Epstein Interactions
- **March 2016**: Rowan forwarded internal tax receivable agreement calculation to Epstein
- **2016**: Epstein involved in discussions about possible tax inversion
- **2015**: Apollo partner Sanjay Patel emailed Epstein about "Rothschild conversations" at Rowan's request
- **Meeting**: Epstein hosted meeting between Rowan and Edmond de Rothschild executives at Manhattan townhouse
- **Tax plan**: Epstein proposed plan to save co-founders up to $300M, 25% success fee

#### Apollo's Position
- Feb 18, 2026 letter to clients: "Neither Rowan nor anyone else at Apollo other than Black had a business or personal relationship with Epstein"
- Acknowledged: "In select instances" Rowan and employees provided information to Epstein for Black's tax work
- Claimed: Epstein sought work for other co-founders but was "declined at every turn"

#### Market Impact
- Apollo stock fell ~15% in Feb 2026
- ~$12B market value wiped out
- Pennsylvania School Employees' Retirement System paused investments
- Canada Pension Plan Investment Board considered pulling back

---

### 6. TODD BOEHLY — Guggenheim Partners / Eldridge Industries

**CAGE ROLE**: SN (Social Network) — Business introductions

#### Epstein Connection
- **Introduced**: Through real estate investor David Mitchell while Boehly was at Guggenheim Partners
- **Meetings**: Two business meetings arranged by Epstein in 2011 (after first jail term)
- **Source**: DOJ EFTA emails, NYT Athletic (Jan 31, 2026)

#### Business Profile
- Co-owner of Chelsea FC (English Premier League)
- Part-owner of LA Dodgers, LA Lakers, LA Sparks
- Founder of Eldridge Industries (2015)
- Former managing partner at Guggenheim Partners
- Acquired Golden Globes/HFPA

#### Documentation
- **Documents**: 107 in Epstein Exposed database
- **Flights**: 0 entries
- **Emails**: 0 entries

---

### 7. LEONARD BLAVATNIK — Access Industries

**CAGE ROLE**: SN (Social Network) — Social/business introductions

#### Epstein Files Documentation
- **Email correspondence**: Spanning 2009-2017
- **Meetings discussed**: Multiple dinner invitations, Cannes trip

#### Key Correspondence
| Date | Event | Source | Confidence |
|------|-------|--------|------------|
| Sept 2010 | Dinner invitation with Ehud Barak at Epstein's townhouse | EFTA02421173 | [V] |
| May 2012 | "Harvey Weinstein and Len Blavatnik lunch on boat" (Cannes) | EFTA schedule | [V] |
| May 2014 | Listed as guest for dinner party with Woody Allen, Larry Summers | EFTA01924576 | [V] |
| Sept 2017 | Epstein described Blavatnik as "adequate" Russian oligarch | Email exchange | [V] |

#### Business Profile
- Access Industries (conglomerate)
- Warner Music Group acquisition ($3.3B)
- Third richest person in Britain
- Oxford University donor (£75M for Blavatnik School of Government)
- Major UK political donor (£1.3M to Conservative Party in 2024)

#### Connections
- **Peter Mandelson**: Epstein used Mandelson as bridge to Blavatnik
- **Bill Gates**: Offered to introduce Epstein to Blavatnik (2014)
- **Ehud Barak**: Blavatnik invited to dinner with Barak at Epstein's townhouse

#### Nardello Transcript
- Attorney-client privileged transcript found in Epstein's files
- Records woman accusing "cabal" including "Bloomberg and Mort Zuckerman and Len Blavatnik"
- Question: Why did Epstein possess this document?

---

## TIER 3: SHELL COMPANY INFRASTRUCTURE

### 8. SOUTHERN TRUST COMPANY (USVI)

**CAGE ROLE**: FF (Financial Facilitator) — Primary operational entity

#### Corporate Details
- **Jurisdiction**: U.S. Virgin Islands
- **Type**: Trust company
- **Function**: Central operational and financial coordination hub
- **Period**: 2013-2019

#### Financial Flows
| Source | Amount | Period | Source | Confidence |
|--------|--------|--------|--------|------------|
| Leon Black | $170M+ | 2012-2017 | Senate Finance Committee | [V] |
| Edmond de Rothschild | $10M | 2015 | DB-SDNY | [V] |
| Narrow Holdings LLC | $20M | Single transaction | EFTA00027019 | [V] |
| Haze Trust | $10M | Oct 2018 | DB-SDNY-0007725 | [V] |

#### Investment Flows (to hedge funds)
- **Valar Ventures** (Peter Thiel): $15M commitment, $13.5M+ disbursed 2015-2018
- **Honeycomb Asset Management**: $11M+ disbursed 2017-2019
- **Blockchain Capital**: $15M returned to Caterpillar Trust in 2018

#### Key Findings
- Received $133M+ total inflows (largest recipient entity)
- Applied for EDC (Economic Development Commission) tax benefits
- Purported to provide "biomedical and financial services"
- Court filings describe as conduit for payments, credit cards, aircraft

---

### 9. FINANCIAL TRUST COMPANY (USVI)

**CAGE ROLE**: FF (Financial Facilitator) — Earlier entity

#### Corporate Details
- **Jurisdiction**: U.S. Virgin Islands (incorporated Nov 6, 1998)
- **Type**: Trust company
- **Assets**: $212M (last public filing 2012)
- **JP Morgan Account**: #78805-00-1

#### Key Findings
- Parent entity of Jeepers Inc (USVI corporation)
- Both entities had Bear Stearns brokerage accounts pre-Deutsche Bank
- Only authorized signer: Jeffrey Epstein
- Co-signer: Darren Indyke

---

### 10. ADDITIONAL SHELL ENTITIES

| Entity | Type | Jurisdiction | Purpose | Source |
|--------|------|--------------|---------|--------|
| Jeepers Inc | Shell/brokerage | USVI | Investment vehicle, sole stockholder Financial Trust Co. | EFTA00097633 |
| Plan D LLC | LLC | USVI | Asset holding | Bloomberg |
| Great St. Jim LLC | LLC | USVI | Asset holding | Bloomberg |
| Maple Inc | Corporation | Unknown | Unknown | ICIJ |
| Southern Financial LLC | LLC | USVI | Investment disbursement vehicle | EFTA00027019 |
| Coatue Enterprises LLC | LLC | Unknown | Shell company of Richard Kahn (Epstein accountant) | EFTA00161836 |
| HBRK Associates Inc | Corporation | Unknown | Shell company of Richard Kahn | EFTA00161836 |
| Hyperion Air LLC | LLC | USVI | Aircraft holding | Bloomberg |
| 1953 Trust | Pour-over revocable trust | Unknown | Estate planning | ICIJ |
| Gratitude America | Charitable fund | Unknown | Distribution channels | EFTA00027019 |

---

## TIER 4: MONEY FLOWS

### Documented Inflows to Epstein Network

| Source | Amount | Recipient | Period | Source |
|--------|--------|-----------|--------|--------|
| Leon Black | $170M+ | Southern Trust, Financial Trust | 2012-2017 | Senate Finance |
| Les Wexner | $1B+ (managed) | Various | 1987-2007 | FBI documents |
| Edmond de Rothschild | $10M | Southern Trust | 2015 | DB-SDNY |
| Haze Trust (art sales) | $44.5M+ | Southern Financial, Southern Trust | 2018 | EFTA00027019 |
| JPMorgan (total flagged) | $1.1B | Various transactions | 2003-2019 | JPMorgan SAR |

### Documented Outflows from Epstein Network

| Recipient | Amount | Purpose | Period | Source |
|-----------|--------|---------|--------|--------|
| Valar Ventures (Peter Thiel) | $13.5M+ | Fund investment | 2015-2018 | EFTA00597489 |
| Honeycomb Asset Mgmt | $11M+ | Fund investment | 2017-2019 | EFTA00027019 |
| Blockchain Capital | $15M | Fund investment | 2017-2018 | EFTA |
| Noam Chomsky | $270K | Payment | Unknown | Email records |
| Bard College | $225K | Donation | Unknown | Financial records |

---

## TIER 5: EVIDENCE CHAIN STATUS

### Source Documentation

| Source | Documents | Status |
|--------|-----------|--------|
| DOJ EFTA Release | 2.1M+ pages | Released Jan 2026 |
| Giuffre v. Maxwell | 3,153 filings | Partially unsealed |
| House Oversight | Multiple batches | Released |
| FBI Vault | Investigative files | Released |
| Epstein Exposed DB | 2.1M+ documents | Indexed |
| Flight Logs | 1,700+ flights | 500 with manifests |
| JPMorgan SAR | ~4,700 transactions | Released via litigation |
| Bank of America SAR | Unknown | Released via litigation |

### Key Court Cases

| Case | Court | Status | Significance |
|------|-------|--------|--------------|
| Feldman v. Apollo | SDNY | Active | Shareholder class action |
| Perez v. Apollo | SDNY | Filed April 2026 | Shareholder class action |
| Jane Doe v. JPMorgan | SDNY | Settled 2023 | $290M settlement |
| USVI v. JPMorgan | SDNY | Settled 2023 | $190M claim |
| Bank of America survivors | SDNY | Trial May 2026 | Black deposition ordered |
| USVI v. Black | USVI | Settled 2023 | $62.5M immunity |

---

## CONFIDENCE ASSESSMENT

### High Confidence [V] — Verified in 2+ independent sources
1. Leon Black paid Epstein $170M+ through Southern Trust/Financial Trust
2. JPMorgan flagged $1.1B in suspicious transactions
3. Les Wexner named FBI co-conspirator (2019)
4. Glenn Dubin had 36 flights on Epstein planes
5. Apollo shareholder lawsuits filed March/April 2026
6. Todd Boehly had two meetings arranged by Epstein (2011)
7. Leonard Blavatnik corresponded with Epstein 2009-2017

### Probable [P] — Single source, consistent with pattern
1. Epstein involvement in Apollo tax discussions
2. Rowan forwarded tax calculations to Epstein
3. Blavatnik "adequate" Russian oligarch email
4. Nardello transcript involving Blavatnik/Zuckerman/Bloomberg

### Inference [I] — Pattern-based, requires validation
1. Apollo regulatory filings may constitute securities fraud
2. Shell company infrastructure designed for tax evasion
3. Russian bank connections suggest additional financial networks
4. Art market used for money movement (Haze Trust liquidation)

---

## GAPS IN INVESTIGATION

1. **Full JPMorgan SAR**: Only summary available; detailed transaction data still sealed
2. **Deutsche Bank SAR**: $400M flagged; details not public
3. **Bank of America SAR**: Black's payments; details limited
4. **Shell company beneficial ownership**: Many nominee-owned entities unresolved
5. **Offshore jurisdictions**: BVI, Cayman, Bermuda records incomplete
6. **Trust structures**: 1953 Trust and other trusts not fully documented
7. **Russian bank connections**: Two Russian banks mentioned in SAR; identities not confirmed
8. **Art market flows**: Haze Trust liquidation details incomplete

---

*Last Updated: August 28, 2026*
*Investigation Agent: cage-sleuth protocol*
*Next Steps: Pursue FOIA for full SAR documents, cross-reference with ICIJ Offshore Leaks, map complete trust structures*
