# AGENT 12: TECHNOLOGY NETWORK

## THE INNOVATION CAPTURE SPOKE

Epstein invested in technology companies and attended Silicon Valley dinners. The technology cage ensured that emerging technologies developed in directions favorable to the cage.

---

## KEY TECHNOLOGY FIGURES

### 1. Sergey Brin — Google Co-Founder
| Field | Detail |
|-------|--------|
| **Company** | Google (co-founder) |
| **Connection** | Visited Epstein's island |
| **Maxwell** | Corresponded with Maxwell about dinners |
| **JPMorgan** | Referral from Epstein to JPMorgan |
| **Confidence** | [V] — DOJ files, NYT |

### 2. Reid Hoffman — LinkedIn Co-Founder
| Field | Detail |
|-------|--------|
| **Company** | LinkedIn (co-founder) |
| **Document Mentions** | 2,658+ |
| **Connection** | Hosted dinners for Epstein-connected academics |
| **Island** | Visited island (2014) |
| **Aug 2015 Dinner** | Hosted Baume dinner in Palo Alto |
| **Attendees** | Musk, Zuckerberg, Thiel, Boyden |
| **Confidence** | [V] — DOJ files, Epstein Exposed |

### 3. Bill Gates — Microsoft Co-Founder
| Field | Detail |
|-------|--------|
| **Company** | Microsoft (co-founder), Gates Foundation |
| **Meetings** | 30+ meetings with Epstein (2011-2014) |
| **Post-Conviction** | All meetings after 2008 conviction |
| **Photo** | Epstein showed Gates photo of "beautiful Russian girls" |
| **Congressional** | Testified about Epstein meetings |
| **Quote** | Called it a "huge mistake" |
| **Confidence** | [V] — DOJ files, congressional testimony |

### 4. Peter Thiel — Palantir/Founders Fund
| Field | Detail |
|-------|--------|
| **Companies** | Palantir, Founders Fund, Valar Ventures |
| **Investment** | $40M from Epstein into Valar Ventures |
| **Meetings** | 7+ meetings documented |
| **Barak** | Epstein introduced Barak to Thiel |
| **Palantir** | Intelligence-adjacent technology company |
| **Israel** | Palantir now has Israel MoD partnership |
| **Confidence** | [V] — DOJ files, Epstein Exposed |

### 5. Elon Musk — SpaceX/Tesla
| Field | Detail |
|-------|--------|
| **Companies** | SpaceX, Tesla, Neuralink |
| **Emails** | 16+ emails with Epstein |
| **Request** | "Wildest party" request to Epstein |
| **Island** | Attempted island visit |
| **SpaceX** | Tour offered by Epstein |
| **Aug 2015** | Photographed at Baume dinner |
| **Confidence** | [V] — DOJ files, emails |

### 6. Mark Zuckerberg — Meta/Facebook
| Field | Detail |
|-------|--------|
| **Company** | Meta (Facebook) |
| **Dinner** | Aug 2015 Baume dinner |
| **Photo** | Epstein photographed him |
| **Contact** | Epstein requested contact details |
| **Confidence** | [V] — DOJ files, photographs |

### 7. Joichi Ito — MIT Media Lab
| Field | Detail |
|-------|--------|
| **Role** | Director, MIT Media Lab |
| **Received** | $2.5M+ from Epstein |
| **Blockstream** | Invested in Blockstream with Epstein money |
| **Digital Currency** | MIT Digital Currency Initiative funded by Epstein |
| **Resignation** | Resigned over Epstein connections |
| **Kyara LLCs** | Managed 4 Delaware LLCs for Epstein investments |
| **Confidence** | [V] — DOJ files, MIT report |

---

## EPSTEIN'S TECHNOLOGY PORTFOLIO

| Company | Amount | Vehicle | Current Value |
|---------|--------|---------|---------------|
| Coinbase | $3M | IGO Company LLC | $15M (sold 50% in 2018) |
| Blockstream | $500K | Kyara Investments III | Divested (now $2.5B) |
| Jawbone | $11.25M | Mort, Inc. | Total loss |
| Valar Ventures | $40M | Southern Trust Co. | ~$170M |
| Boothbay Funds | $38.25M | Southern Financial LLC | ~$46M |
| Honeycomb Partners | $64M | Multiple entities | Mostly liquidated |
| Wearality | $250K | Kyara II LLC | Unknown |
| OH2 Labs | $250K | Kyara IV LLC | Unknown |
| **Total** | **~$160.85M** | — | — |

---

## THE AUGUST 2015 BAUME DINNER — THE TECHNOLOGY HUB

### Location: Palo Alto (Hosted by Reid Hoffman)
### Attendees:
1. Jeffrey Epstein
2. Reid Hoffman (LinkedIn)
3. Elon Musk (SpaceX/Tesla)
4. Mark Zuckerberg (Meta)
5. Priscilla Chan
6. Peter Thiel (Palantir)
7. Edward Boyden (MIT)

### Epstein's Email to Pritzker
Sent photo with Zuckerberg, Musk, Thiel. Described dinner as "wild."

### Significance
This single dinner connects **6 major technology figures** to Epstein in one documented event. It is the technology equivalent of the Nowak dinner for academics.

---

## THE TECHNOLOGY CAGE FUNCTION

### How Technology Capture Worked
1. **Investment** — Epstein invested in startups and funds
2. **Access** — Gained access to founders and executives
3. **Direction** — Influenced which technologies got funded
4. **Intelligence** — Palantir provides surveillance capabilities
5. **Legitimacy** — Association with famous founders normalized Epstein

### What Was Captured
1. **AI/Surveillance** — Palantir's intelligence-adjacent work
2. **Social Media** — Access to platform founders
3. **Space** — Access to SpaceX (Musk)
4. **Finance** — Cryptocurrency (Coinbase, Blockstream)
5. **Biotech** — OH2 Labs (MIT biotech)

---

*Agent 12 findings. Technology capture completed the six-spoke cage structure.*
