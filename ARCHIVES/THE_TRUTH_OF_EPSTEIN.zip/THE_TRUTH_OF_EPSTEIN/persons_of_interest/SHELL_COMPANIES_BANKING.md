# EPSTEIN SHELL COMPANY & BANKING INFRASTRUCTURE

**Agent 21 | Classification: FORENSIC FINANCIAL ANALYSIS**
**Date: 2026-08-28 | Total Entities Mapped: 57+ | Total Financial Flows: $3.2B+**

---

## EXECUTIVE SUMMARY

This investigation identified **57+ shell companies, financial vehicles, and banking entities** forming Epstein's financial architecture. The system operated across **4 banking institutions** (Deutsche Bank, JPMorgan Chase, Bank of America, Bear Stearns) and multiple offshore jurisdictions. Total documented flows exceed **$3.2 billion**. The architecture used layered shell companies in the USVI, BVI, Cayman Islands, and Bermuda to obscure ownership, conceal beneficiaries, and facilitate tax fraud.

**Key structural finding:** Epstein's financial system was not merely opaque — it was *designed* for opacity. Each property was isolated in its own entity. Each trust served dual purposes (estate planning + operational concealment). The banking relationships succeeded precisely because compliance failures were systematic, not accidental.

---

## PART I: CORE FINANCIAL ENTITIES

### 1. SOUTHERN TRUST COMPANY, INC. (USVI)

| Field | Value |
|-------|-------|
| **Entity Type** | Trust Company (USVI) |
| **Jurisdiction** | U.S. Virgin Islands |
| **Total Inflows** | **$133M+** (largest single entity) |
| **Peak Balance** | $45,150,000 (Deutsche Bank) |
| **Role** | Central financial hub; receives Black/Rothschild/Apollo funds; distributes to hedge funds |
| **Status** | Named in USVI AG civil suit; subject to forfeiture action |
| **Document Count** | 1,956+ documents in DOJ corpus |

**Corporate Structure:**
- Epstein was sole shareholder of STC
- STC was sole member of Southern Financial, LLC
- Created dual structure: STC = operational/payroll; Southern Financial = investment/securities
- Banks treated both as unified "Southern Financial Relationship" cluster

**Stated Purpose vs. Actual Function:**
- **Stated:** Genetic research, DNA database analysis, biomedical consulting, data analytics
- **Actual:** Central clearing entity for all Epstein financial flows; payroll vehicle; investment holding
- Used to qualify for USVI EDC tax benefits (90% income tax reduction)

**Banking Timeline:**
- 2013: Transitioned from Financial Trust Company to Southern Trust structure
- 2013-2014: Accounts at JPMorgan Chase (closed 2014)
- 2013-2019: Primary bank = Deutsche Bank (RM CODE 82289)
- All accounts closed by Deutsche Bank late 2019

**Key Personnel:**
- Cecile de Jongh — office manager (wife of former USVI governor)
- Jeanne Brennan — accounting lead
- Darren Indyke — director

**Transaction Highlights (from Epstein Exposed database):**
| Account | Volume | Transactions |
|---------|--------|-------------|
| Southern Trust Payroll Account | $783.0M | 281 txns |
| Southern Trust Company Inc. (shell) | $234.4M | 40 txns |
| Southern Trust Company Checking | $32.0M | 36 txns |
| Multiple variant accounts | $50M+ | 50+ txns |

**Major Wire Transfers:**
- $23M: Southern Trust → Deutsche Bank Account 35266976 (Nov 2015)
- $23M: Southern Trust → BNY Pershing LLC (wire)
- $20M: Narrow Holdings LLC c/o Elysium → Southern Trust
- $20M: Southern Trust → Northern Trust (Honeycomb Partners LP)
- Multiple $4-6M transfers to Silicon Valley Bank, FirstBank Puerto Rico

**Sources:** EFTA01359500, EFTA01477454, EFTA00027019, Epstein Exposed DB, NYDFS Deutsche Bank Consent Order

---

### 2. FINANCIAL TRUST COMPANY, INC. (USVI)

| Field | Value |
|-------|-------|
| **Entity Type** | Corporation (USVI) |
| **Incorporated** | November 6, 1998 |
| **Assets** | **$212M** (last public filing 2012) |
| **JPMorgan Account** | #78805-00-1 |
| **Role** | Predecessor to Southern Trust; original USVI financial hub |
| **Status** | Dissolved; absorbed into Southern Trust structure (2013) |

**Function:**
- Managed Epstein-controlled assets
- Structured tax-advantaged revenue in USVI
- Held ownership stakes in other Epstein LLCs
- Paid contractors, employees, service providers
- Facilitated financial transfers through US/offshore banks

**Transition to Southern Trust (2013):**
- Transfer of securities into Southern Financial accounts (March 2013)
- Migration of payroll and operations to STC
- Closure of FTC accounts
- Internal correspondence confirms coordinated restructuring

**Parent of Jeepers Inc:**
- Financial Trust Company was sole stockholder of Jeepers Inc.

**Bear Stearns Connection:**
- FTC maintained Bear Stearns brokerage accounts (pre-Deutsche Bank era)
- Bear Stearns accounts referenced in EFTA01260277

**Liquid Funding Ltd. Connection:**
- Epstein served as president of Liquid Funding Ltd. (Bermuda)
- Bear Stearns held substantial ownership interest in Liquid Funding
- $6.7 billion Bermuda entity documented in Paradise Papers
- Connected by purchase agreement to Financial Trust Company

**Sources:** EFTA00015176, EFTA00018778, EFTA00015184, Epstein Wiki, Paradise Papers

---

### 3. SOUTHERN FINANCIAL, LLC

| Field | Value |
|-------|-------|
| **Entity Type** | LLC (USVI) |
| **Role** | Investment disbursement vehicle |
| **Peak Balance** | $7,000,000+ (Deutsche Bank) |
| **Major Inflow** | $27M from Haze Trust Checking O ($24.6M) |
| **Function** | Pays Boothbay, Coatue Enterprises (Kahn), Joichi Ito, Neoteny |

**Money Flows:**
- Receives from Haze Trust cluster
- Distributes to hedge funds and investment vehicles
- Post-KYC inflow of $27M documented
- Pays out to: Boothbay, Coatue Enterprises, Neoteny 3 LP, Joichi Ito

**Sources:** DB-SDNY-0003845, DB-SDNY-0004032, EFTA00027019

---

## PART II: SHELL COMPANIES & OPERATING ENTITIES

### 4. JEEPERS INC

| Field | Value |
|-------|-------|
| **Entity Type** | Shell company / Investment brokerage vehicle |
| **Jurisdiction** | USVI corporation |
| **Parent** | Financial Trust Company, Inc. (sole stockholder) |
| **Account Lifecycle** | Opened 02/02/07, closed 12/31/19 |
| **Total Volume** | **$75M+** (2013-2019) |
| **Role** | Primary capitalization vehicle for Epstein's NOW/SuperNOW accounts |

**Connected Persons:**
- Jeffrey Epstein — ONLY authorized signer for checking (EFTA00128822)
- Darren Indyke — co-signer on commercial checking (EFTA00065864)

**Key Transaction:**
- 7/15/2013: $1.5M wire from Jeepers Inc to Epstein personal (EFTA01588813)

**Status:** Sub-S corporation, liquidated December 2019

**Sources:** EFTA00097633, EFTA00128822, EFTA00065864, EFTA01588813

---

### 5. PLAN D LLC

| Field | Value |
|-------|-------|
| **Entity Type** | LLC (USVI) |
| **Formed** | October 19, 2012 |
| **Purpose** | "Any lawful activity" |
| **Role** | Aircraft holding (Gulfstream G550 N212JE) |
| **Key Flow** | Received $30.5M from BV70 LLC |

**Subpoena List:** Named in USVI AG v. Estate of Epstein (Case No. ST-20-CV-014)

**Aircraft Connection:**
- Held Gulfstream G550
- Sold N212JE to Six G Aviation LLC (12/22/2020)
- Resold same day to NSSOGP LLC

**Sources:** EFTA01583466, EFTA00031569, USVI Courts

---

### 6. GREAT ST. JIM LLC

| Field | Value |
|-------|-------|
| **Entity Type** | LLC |
| **Role** | Holds Great St. James Island |
| **Status** | "Knowingly participated in the Epstein Enterprise" per GVI complaint |

**Legal Status:** Named defendant in USVI AG civil action (Case No. ST-20-CV-014)

**Sources:** EFTA00018778, USVI Courts

---

### 7. COATUE ENTERPRISES LLC

| Field | Value |
|-------|-------|
| **Entity Type** | Personal shell company |
| **Owner** | **Richard Kahn** (Epstein's accountant) — NOT Philippe Laffont's hedge fund |
| **Total Received** | $1.5M (4 txns; $1M post-KYC) |
| **Loan Receivable** | $1.5M |
| **Role** | "Functioned as shell company and engaged in no activities other than to coordinate the activities of Epstein's Enterprise" |

**Money Flows:**
- 5/5/2017: Southern Financial → Coatue Enterprises = $500,000
- 1/12/2018: Southern Financial → Coatue Enterprises = $500,000
- 6/13/2018: Southern Financial → Coatue Enterprises = $500,000

**Trust Provisions:** Named in multiple Epstein trust instruments as designated entity

**Sources:** EFTA00027019, EFTA00161836, EFTA00098341, EFTA00599617

---

### 8. MAPLE, INC.

| Field | Value |
|-------|-------|
| **Entity Type** | Corporation (USVI) |
| **Role** | Holds 9 East 71st Street, Manhattan (NYC residence) |
| **Registered Address** | 9100 Havensight, St. Thomas 00802 |

**Sources:** EFTA00031569, EFTA00031559, EFTA00017085

---

### 9. CYPRESS, INC.

| Field | Value |
|-------|-------|
| **Entity Type** | Corporation |
| **Role** | Real property holding entity |

**Sources:** USVI subpoena documents

---

### 10. LAUREL, INC.

| Field | Value |
|-------|-------|
| **Entity Type** | Corporation (Florida) |
| **Role** | Held 358 El Brillo Way, Palm Beach |
| **Transfer** | Transferred to Log & Bliss Inc. (3/2019 warranty deed) |

**Sources:** EFTA00019200, EFTA00017085

---

### 11. LSJE LLC

| Field | Value |
|-------|-------|
| **Entity Type** | LLC (USVI) |
| **Address** | 6100 Red Hook Quarters Suite B-3, St. Thomas |
| **Role** | Employer entity for Little Saint James Island staff; checking account for daily expenses |
| **Balance** | $2-3M (estimated) |

**Sources:** EFTA00003046, EFTA00003056, EFTA00015937

---

### 12. SOUTHERN COUNTRY INTERNATIONAL, LTD.

| Field | Value |
|-------|-------|
| **Entity Type** | International Banking Entity |
| **Jurisdiction** | USVI |
| **License Obtained** | 2014 |
| **Role** | Licensed offshore bank (USVI's first IBE) |
| **Operations** | Dormant — minimal/no business conducted while Epstein alive |
| **Post-Death** | Received $12M+ from estate after Epstein's death |
| **End Balance** | Less than $500,000 (end of 2019) |

**Key Finding:** A registered sex offender obtained a USVI banking license to operate an offshore bank. The bank conducted virtually no business while Epstein was alive, but received millions from his estate after death. USVI prosecutors questioned where nearly $13M went.

**Sources:** NYT 2020-02-04, NY Post, LittleSis, Miami Herald 2026-07-06

---

## PART III: TRUST STRUCTURES

### 13. THE HAZE TRUST

| Field | Value |
|-------|-------|
| **Entity Type** | Trust |
| **Peak Balance** | **$49,460,098.13** |
| **Role** | Largest single asset pool at Deutsche Bank |
| **Trustee** | Richard Kahn (sole authorized signer) |
| **Bank** | Deutsche Bank (N4G024943) |

**Tiered Portfolio (08/17/2018):**

| Tier | Entity | Balance |
|------|--------|---------|
| Tier 1 | Haze Trust Account D | $40,583,100.79 |
| Tier 2 | Haze Trust Account D | $2,503,667.84 |
| Tier 3 | Gratitude America, Ltd | $2,075,025.07 |
| Tier 3 | Zorro Management, LLC | $424,475.56 |
| Tier 5 | Southern Trust Company | $704,736.63 |
| Tier 5 | Butterfly Trust | $323,679.36 |
| Tier 6 | Southern Financial LLC | $534,440.04 |

**Critical Finding:** The Haze Trust dominated the entire portfolio, holding ~88% of total documented assets across all accounts.

**AML Investigation:**
- Deutsche Bank's AML unit actively investigating under **Alert# SAM 1788880**
- Investigation was active during the exact period of fund drawdown
- $30.7M referenced in SAR (EFTA01648786) — may indicate underreporting vs. $49.5M peak

**Sources:** EFTA00027019, EFTA0164880, EFTA01359500, NYDFS Consent Order

---

### 14. THE BUTTERFLY TRUST

| Field | Value |
|-------|-------|
| **Entity Type** | Trust |
| **Established** | 2013 (accounts opened Jan 24, 2014 at Deutsche Bank) |
| **Account #** | 44130552 |
| **Peak Balance** | $734,175.44 |
| **Co-Trustees** | Darren Indyke, Richard Kahn |
| **Bank** | Deutsche Bank |

**Beneficiaries:**
- "CO-CONSPIRATORS 1-3" (identified in NYDFS filing)
- Other unnamed beneficiaries
- Original beneficiary: Ghislaine Maxwell (later removed)

**Wire Activity:**
- 120+ wires totaling $2.65M to beneficiaries
- Transfers described as: hotel expenses, tuition, rent
- Recipients included women with Eastern European surnames
- Payments to alleged co-conspirators

**Post-Death Controversy:**
- April 2020: $13M wired to Butterfly Trust from liquidation of another fund
- USVI AG accused executors of concealing these funds from creditors/victims

**Sources:** NYDFS Deutsche Bank Consent Order, EFTA001415194, EFTA001388746, Fortune 2026-05-17

---

### 15. THE 1953 TRUST

| Field | Value |
|-------|-------|
| **Entity Type** | Revocable "pour-over" trust |
| **Created** | August 8, 2019 (2 days before death) |
| **Purpose** | Receive assets after probate; conceal 40+ beneficiaries |
| **Co-Executors** | Darren Indyke, Richard Kahn |
| **Estate Value** | $577M+ (at signing) |

**Beneficiary Structure (Article Third):**
- Karyna Shuliak (primary)
- ~40 other beneficiaries (identities not publicly disclosed)
- Removed from trust: Ghislaine Maxwell, Jean-Luc Brunel, Darren Indyke, Richard Kahn
- **Critical finding:** Indyke and Kahn were removed as *beneficiaries* but remained as *co-executors* — controlling distribution while being cut from inheritance

**$228M Gap:**

| Documented Assets | Value |
|-------------------|-------|
| Haze Trust (peak) | $49.5M + $12.7M |
| Southern Trust (peak) | $45.15M |
| Southern Financial | $7M |
| 9 East 71st Street | $13M |
| Gulfstream IVSP | $13M |
| Other entities | Partial |
| **Total Documented** | **~$372M** |
| **USVI AG Valuation** | **$600M+** |
| **UNACCOUNTED** | **~$228M** |

**Sources:** EFTA01266168, NYT 2026-02-03, CBS News, Guardian 2019-08-22

---

## PART IV: BANKING RELATIONSHIPS

### 16. DEUTSCHE BANK

| Field | Value |
|-------|-------|
| **Period** | 2013-2019 |
| **Total Transactions** | **$851.9M** |
| **Peak Consolidated Assets** | **$110M+** |
| **Accounts Opened** | 40+ for Epstein and affiliated entities |
| **RM Code** | 82289 |
| **Primary Banker** | Jj Litchford |
| **Secondary Banker** | Paul Morris |
| **Total Relationship** | "Southern Financial Relationship" |

**Onboarding Despite Known Risk (April 2013):**
- Relationship manager **Paul Morris** (former JPMorgan banker) approached bosses to woo Epstein
- Morris sent email to **Charles Packard** (head of wealth management Americas) noting Epstein's conviction but highlighting "$2-4M in annual fees"
- Packard consulted senior compliance and legal executives
- Decision: "we can move ahead so long as nothing further is identified through KYC and AML"
- **No formal record** of this conversation beyond Packard's reply

**Compliance Failures:**
- Bank classified Epstein as "high risk" from onboarding
- Processed millions in suspicious transactions
- Payments labeled as "modeling fees" and "tuition"
- Cash withdrawals exceeding $7,500
- International wire transfers without clear business purposes

**Penalties:**
- **$150 million** fine from New York regulators (2020)
- **$75 million** settlement with Epstein survivors (2023)
- Named in Wyden Senate report (2026-08-04)

**Named Executives:**
- **Paul Morris** — Relationship Manager (onboarded Epstein)
- **Charles Packard** — Head of Wealth Management Americas
- **Jan Ford** — Head of Compliance Americas (still employed)
- **Stewart Oldfield** — Successor relationship manager

**Sources:** NYDFS Consent Order, EFTA01359500, EFTA01477454, Radical Compliance, NYT, OCCRP

---

### 17. JPMORGAN CHASE

| Field | Value |
|-------|-------|
| **Period** | ~1998-2013 (with intermittent re-engagement) |
| **Total Transactions** | **$670.8M** |
| **SARs Filed** | 4,700+ transactions flagged (post-death) |
| **Suspicious Volume** | **$1B+** in flagged transactions |
| **Settlements** | $290M (victims) + $75M (USVI) = **$365M total** |

**Key Facts:**
- Epstein designated "high risk client" in 2006
- 150 cash transactions reported (2002-2013)
- SARs filed but government/law enforcement did not act for years
- Epstein was "treasured customer" with $200M+ in deposits
- Earned JPMorgan $8M in fees (2003)
- Epstein brokered JPMorgan's $1.3B purchase of Highbridge Capital (earned $15M)

**Named Executives:**
- **Jes Staley** — CEO; dinner meetings; extensive correspondence
- **Mary Erdoes** — CEO of Asset & Wealth Management; sold $29M stock before arrest
- **Jamie Dimon** — CEO; informed of Epstein's death in 2019; knowledge of accounts disputed

**Bear Stearns Merger Effect:**
- JPMorgan acquired Bear Stearns in 2008
- Bear Stearns brokerage accounts absorbed into JPMorgan systems
- Butterfly Trust and Financial Trust Company accounts migrated
- Distinction needed between: Epstein's employment, Bear Stearns brokerage, absorbed accounts, separate JPMorgan private banking

**Sources:** NYT 2025-10-30, AML Intelligence, Wikipedia, Newser, Guardian, Wyden Report

---

### 18. BANK OF AMERICA

| Field | Value |
|-------|-------|
| **Total Transactions** | **$486.4M** |
| **Key Client** | Leon Black (BofA customer, $13B net worth) |
| **SARs Filed** | February 2020 + October 2020 (post-death) |
| **Settlement** | **$72.5 million** (March 2026) |

**Critical Failure:**
- Bank filed SARs in 2020 about Leon Black's $170M in payments to Epstein
- Payments occurred years before SAR filing
- Bank processed payments "without asking for information as to the nature of the transactions"
- SARs described transactions as having "no apparent economic, business or lawful purpose"
- Epstein dead 6 months before first SAR filed

**Sources:** NYT (via Hawaii Tribune-Herald) 2024-12-14, ABC News 2026-08-27, Guardian 2026-03-16, Wyden Report

---

### 19. BEAR STEARNS

| Field | Value |
|-------|-------|
| **Period** | 1976-1981 (employment); ongoing brokerage |
| **Epstein Role** | Junior assistant → Limited Partner (1980) |
| **Departure** | 1981 after securities compliance issue |
| **Liquid Funding** | Epstein served as president; $6.7B Bermuda entity |

**Career Trajectory:**
- 1976: Joined as junior assistant to floor trader
- Transitioned to options trading, Special Products Division
- Advised wealthy clients on tax-advantaged transactions
- 1980: Made limited partner (after only 4 years)
- 1981: Left after stock transaction violation (Regulation D)
- Fine: $2,500

**Post-Employment Relationship:**
- Maintained brokerage relationships with Bear Stearns
- Financial Trust Company held Bear Stearns accounts
- Butterfly Trust had Bear Stearns/successor JPMorgan accounts
- Liquid Funding Ltd. (Bermuda) — Epstein as president; Bear Stearns held substantial ownership

**Liquid Funding Ltd.:**
- Bermuda entity; dissolved November 25, 2015
- Involved in repurchase transactions backed by mortgage securities
- Registered agent: Appleby
- Connected to Financial Trust Company via purchase agreement

**Sources:** Epstein Wiki, Bear Stearns article, EFTA01260277, EFTA01940002, OffshoreAlert

---

### 20. OTHER BANKING RELATIONSHIPS

| Institution | Relationship | Evidence |
|-------------|-------------|----------|
| **BNY Mellon/Pershing** | Custodial; $23M wire from Southern Trust | DB-SDNY records |
| **Silicon Valley Bank** | Account 330123181; multiple transfers | Epstein Exposed DB |
| **FirstBank Puerto Rico** | Multiple accounts; $925K+ in transfers | Epstein Exposed DB |
| **Banco Popular de Puerto Rico** | Account for Southern Trust | Epstein Exposed DB |
| **Morgan Stanley Smith Barney** | $2.3M inflow to Southern Trust | Epstein Exposed DB |
| **HSBC Bank Bermuda** | $58,328 inflow to Haze Trust | DB-SDNY-0007888 |
| **Edmond de Rothschild (Suisse) SA Geneva** | $10M to Southern Trust | DB-SDNY |
| **Northern Trust Intl Bkg** | Custodial for Honeycomb Partners | DB-SDNY-0006407 |
| **Credit Suisse** | Referenced in Liquid Funding filings | OffshoreAlert |
| **UBS** | CargoMetrics correspondence via Ellmax | EFTA00239492 |
| **Charles Schwab** | FinCEN SAR involving Southern Trust | EFTA01656452 |

---

## PART V: OFFSHORE & INTERNATIONAL STRUCTURES

### BVI Entities
- Account address "Cayman Cayman Islands KY1-" (EFTA01433607)
- Multiple entities registered in BVI corporate registry

### Cayman Islands
- Liquid Funding Ltd. connected structures
- Rothschild Trust Cayman Limited (related entity)

### Bermuda
- **Liquid Funding Ltd.** — $6.7B entity; Epstein chairman; dissolved 2015
- **Freestream Aircraft (Bermuda) Limited** — Aircraft management
- Registered agent: Appleby

### Rothschild Connection
- **Edmond de Rothschild** — $10M payment to Southern Trust (12/17/2015)
- **"A. de Rothschild"** (ad=r@aderfam.ch) — Email correspondence
- **EL Rothschild LLC**
- Multiple "Rothschild [C]" confidential email threads
- Personnel: Stewart Oldfield, Matt Glassman, Richard Kahn, Vahe Stepanian, Davide-A Sferrazza

### Wire Transfer Network (Offshore)
```
EPSTEIN → Southern Financial LLC (Deutsche Bank, USVI)
             ├── Kyara Investments LLC ──── $99,999
             ├── Kyara Investments II LLC ── $250,000 → Wearality
             ├── Kyara Investments III LLC ─ $500,001 → Blockstream seed
             ├── Kyara Investments IV LLC ── $250,000 → OH2 Laboratories
             └── 2017 Caterpillar Trust (GRAT)
```

---

## PART VI: ADDITIONAL ENTITIES FROM USVI SUBPOENA LIST

The following entities are confirmed via USVI court documents (Case No. ST-20-CV-014):

| Entity | Type | Role |
|--------|------|------|
| JEGE, LLC | LLC (USVI) | Aircraft holding (N212JE) |
| Nautilus, Inc. | Corp (USVI) | Real property USVI |
| Hyperion Air, LLC | LLC (USVI) | Aviation costs ($4.5M) |
| Poplar, Inc. | Corp | Property holding |
| IGO Company, LLC | LLC | Investment vehicle |
| Prytanee, LLC | LLC | Shell entity |
| Thomas World Air, LLC | LLC | Aviation |
| VT&T, LLC | LLC | Shell entity |
| LSJ Emergency, LLC | LLC | Little Saint James |
| LSJ Employees, LLC | LLC | Staff management |
| Michelle's Transportation Company, L.L.C. | LLC | Transportation |
| Zorro Management, LLC | LLC | Zorro Ranch management |
| Mort, Inc. | Corp | Held shares of Jawbone |
| CDE, Inc. | Corp | Shell entity |
| Freedom Air Petroleum, LLC | LLC | Aviation fuel |
| Financial Ballistics, LLC | LLC | Trust entity |
| FSF, LLC | LLC | Foundation entity |
| FT Real Estate, Inc. | Corp | Real estate |
| Financial Informatics | Entity | Data/tech |
| Air Ghislaine Inc. | Corp | Aviation |
| C.O U.Q. Foundation | Foundation | Charitable vehicle |
| Epstein Foundation, Inc. | Foundation | Charitable vehicle |
| J. Epstein Foundation, Inc. | Foundation | Charitable vehicle |
| Epstein Interests | Operating | Operating entity |
| Gratitude America LTD | Nonprofit | Charitable distribution |
| Southern Financial, LLC | LLC | Investment vehicle |
| IGY-AYH St. Thomas Holdings, LLC | LLC | Property holding |
| Butterfly Trust | Trust | See Part III |
| Little St. Jim, LLC | LLC | Island entity |
| Southern Country International, Ltd. | IBE | Banking (see #12) |

---

## PART VII: MONEY FLOW MAP

### Primary Flow Architecture

```
EXTERNAL SOURCES
├── Leon Black (Apollo) ──── $158.5M+ via Bank of America → Southern Trust
├── Edmond de Rothschild ──── $10M → Southern Trust
├── Narrow Holdings LLC ──── $20M → Southern Trust
├── Bear Stearns legacy ──── Liquid Funding connections
│
▼
SOUTHERN TRUST COMPANY (Hub) ──── $133M+ inflows
├── Southern Financial LLC (Disbursement)
│   ├── Boothbay Absolute Strategies ── $23.25M
│   ├── Honeycomb Partners LP ── $53M (5 txns)
│   ├── Valar Global Fund III ── $22.5M
│   ├── Coatue Enterprises (Kahn) ── $1.5M
│   └── Neoteny 3 LP (Joichi Ito)
│
├── Haze Trust (Largest Pool) ──── $49.5M peak
│   ├── Zorro Management LLC ── $424K
│   ├── Gratitude America ── $2M+
│   └── Managed Trust Accounts
│
├── Butterfly Trust ──── $734K
│   └── 120+ wires to beneficiaries ($2.65M total)
│
├── Plan D LLC ──── $30.5M from BV70 LLC
│   └── Gulfstream G550
│
└── Jeepers Inc ──── $75M+ (2013-2019)
    └── NOW/SuperNOW capitalization

CHARITABLE CONDUITS
├── Gratitude America Ltd ── $2-3M
├── J. Epstein Foundation
├── Epstein Foundation, Inc.
└── C.O U.Q. Foundation

POST-DEATH MOVEMENT
├── Estate → Southern Country International ── $12M+
├── Butterfly Trust ← $13M from fund liquidation (April 2020)
└── Estate → Settlements ($365M JPMorgan + $75M Deutsche + $72.5M BofA)
```

---

## PART VIII: COMPLIANCE FAILURES SUMMARY

| Bank | Failure | Penalty |
|------|---------|---------|
| Deutsche Bank | Onboarded known sex offender; 40+ accounts; failed AML monitoring | $150M fine + $75M settlement |
| JPMorgan Chase | 15-year relationship; SARs filed but ignored; $1B+ suspicious | $290M + $75M = $365M |
| Bank of America | Processed $170M Leon Black payments without inquiry; SARs filed years late | $72.5M settlement |
| Bear Stearns | Early career;Liquid Funding presidency; brokerage continuity | N/A (pre-crime period) |

**Senate Wyden Report Finding (August 2026):** "Top bankers looked the other way and allowed Epstein to have ready access to the mountains of cash he used to lure, harbor, and transport his victims."

---

## PART IX: KEY PERSONNEL IN FINANCIAL ARCHITECTURE

| Person | Role | Entity Connection |
|--------|------|-------------------|
| **Darren Indyke** | Co-executor, Director | Southern Trust, all entities |
| **Richard Kahn** | Co-executor, Accountant | HBRK Associates, Coatue Enterprises, Haze Trust trustee |
| **Cecile de Jongh** | Office Manager | Southern Trust (wife of former USVI governor) |
| **Lesley Groff** | Assistant | Trust administration, operational support |
| **Daphne Wallace** | Trustee | 2017 Caterpillar Trust |
| **Stewart Oldfield** | DB Relationship Manager | Deutsche Bank account management |
| **Erika Kellerhals** | Financial | Financial Ballistics Trust |
| **Bella Klein** | Financial | Multiple transfers from Southern Trust |

---

## PART X: GAPS & UNRESOLVED QUESTIONS

1. **$228M Gap:** USVI AG values estate at $600M+; only ~$372M documented. Where is the rest?
2. **Offshore Mapping:** No public accounting has fully mapped Epstein's offshore holdings
3. **Beneficiary Identities:** ~40 beneficiaries in 1953 Trust remain undisclosed
4. **Liquid Funding Full Scope:** $6.7B Bermuda entity — full transaction history unknown
5. **Intelligence Connections:** Early career at Bear Stearns potentially connected to BCCI/CIA operations (unverified)
6. **Southern Country International Post-Death:** $12M+ transferred to dormant bank after death — destination unknown
7. **Rothschild Full Relationship:** Only partial wires documented ($10M confirmed; likely more)
8. **Bilateral Banking:** Full scope of Swiss, Luxembourg, and other European banking relationships unmapped
9. **Crypto Position:** $18M+ invested in crypto companies but zero on-chain transactions found
10. **The $1.5B Total:** Senate committee states Epstein transactions totaled at least $1.5B — full accounting pending

---

## SOURCES CONSULTED

- Epstein Exposed Database (epsteinexposed.com) — 2.1M+ documents
- Epstein Data (epstein-data.com) — Master Forensic Report, Shell Entity Map, Dark Money Investigation
- DOJ EFTA Corpus (justice.gov/epstein) — 500K+ documents, 1.8M redaction events
- USVI Courts — Case No. ST-20-CV-014 (Government v. Indyke, Kahn, Estate)
- NYDFS Deutsche Bank Consent Order (July 2020)
- Senate Finance Committee Wyden Report (August 2026)
- OffshoreAlert — Liquid Funding Ltd. filings (Bermuda)
- ICIJ Offshore Leaks — Paradise Papers references
- LittleSis — Southern Country International organizational data
- Bloomberg Tax — Shell Game investigation (2019)
- ResearchGate — Financial Architecture of the Epstein Criminal Enterprise (2025)

---

*Agent 21 findings — to be consumed by Agent 22 for: Beneficiary networks, associate financial flows, and Leon Black/Apollo connection deep dive.*
