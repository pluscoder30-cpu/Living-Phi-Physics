# AGENT 86: OFFSHORE ACCOUNT CROSS-REFERENCE

## THE OFFSHORE-TO-PEOPLE LINKAGE

### Offshore Accounts Linked to Persons
| Offshore Entity | Jurisdiction | Person(s) Linked | Evidence |
|-----------------|-------------|------------------|----------|
| Southern Trust Company | USVI | Epstein, Indyke, Kahn | DOJ filings |
| Financial Trust Company | Bermuda | Epstein | DOJ filings |
| Plan D LLC | USVI | Visoski (pilot) | Aviation records |
| Great St. Jim LLC | USVI | Epstein | Property records |
| LSJE LLC | USVI | Epstein (staff employer) | DOJ filings |
| Nautilus Inc. | USVI | Epstein | Property records |
| HBRK Associates | NYC | Kahn, Indyke | DOJ filings |
| 1953 Trust | USVI | Epstein estate | Estate records |
| Butterfly Trust | Offshore | Epstein | Paradise Papers |

### The South Africa Link
| Account | Bank | Location | Linked To | Evidence |
|---------|------|----------|-----------|----------|
| Standard Bank | Standard Bank | Cape Town, SA | Unknown (redacted) | DOJ emails |
| Standard Bank | Standard Bank | SA | Epstein (sender) | DOJ emails |

### The Trump Link
| Entity | Connection | Evidence |
|--------|-----------|----------|
| Trump Organization | Social, flights | Black book, flight logs |
| Mar-a-Lago | Recruitment site | Giuffre testimony |
| Trump Tower | Black book address | Black book |

### The Wexner Link
| Entity | Connection | Evidence |
|--------|-----------|----------|
| Victoria's Secret | $1B+ relationship | FBI co-conspirator |
| New Albany Company | Real estate | Financial records |
| Abigail Plantation | Property | Black book |

---

*Agent 86 findings. Offshore accounts are linked to persons through documented evidence.*
