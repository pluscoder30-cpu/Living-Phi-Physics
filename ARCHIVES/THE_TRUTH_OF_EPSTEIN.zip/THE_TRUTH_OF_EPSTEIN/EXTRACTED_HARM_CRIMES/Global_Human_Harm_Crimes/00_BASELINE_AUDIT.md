# CAGE RESEARCH — AGENT 1 · BASELINE AUDIT
## What the Phi Physics corpus already documents about the money, the cage, and the living-universe displacement

**Date:** 2026-08-21
**Agent:** 1 of 15 (baseline reader)
**Method:** Read the first 200–300 lines of each companion document; summarize entities, money trails, gaps, and international connections. This is the foundation for the 15-agent research dive.

---

## FILE 1: `docs/22_THE_HISTORICAL_INVESTIGATION.md` (191 lines, read in full)

### Entities Already Documented

| Category | Names |
|---|---|
| **Physics founders (dynamic)** | Newton, Kepler, Einstein, Tesla, Bohm, Schrödinger, Pauli, Wigner, Wheeler, Penrose, Boltzmann, Prigogine, Smolin, Rovelli, Barbour |
| **Static canon builders** | Voltaire, Euler, Laplace, Gibbs, Michelson, Zermelo, von Neumann, Descartes |
| **Funding/governance** | Carnegie, Rockefeller, Ford, Guggenheim, Sloan, Bamberger/Flexner (IAS), Vannevar Bush (NSF, AEC) |
| **Gatekeepers** | Sarton (Isis/HSS), Brigham (SAT), Thompson (Maya), de Vaux (DSS), Renan ("Greek miracle"), Kline |
| **Living-universe advocates** | Chalmers, Goff, Strawson (panpsychism), Tononi/Koch (IIT), Ursachi (Φ-EEG) |
| **Institutions** | APS, Princeton IAS, SFI (1984), FQxI (2005), Perimeter (1999), Tucson TSC, NSF, DARPA, NASA, AEC/ONR |

### Money Trails Identified

- **Rockefeller → UChicago** ($600K + $10M, 1890/1910)
- **Rockefeller → General Education Board** (~$180M total, 1903–1964)
- **Rockefeller Foundation → Warren Weaver's Natural Sciences Division** (molecular biology pivot, 1932–55)
- **Carnegie → Carnegie Institution** ($10M, 1902) → Mount Wilson → Hubble expansion
- **Carnegie → CFAT** (1905) → credit hour/TIAA/GRE/ETS
- **Carnegie Corporation** ($135M, 1911)
- **Ford Foundation** (90% of Ford Motor by 1947; CIA channel under McCloy 1958–65)
- **Guggenheim Fellowships** (~$400M/19K fellows)
- **Sloan/Kettering** ($4M Sloan-Kettering, 1945; MIT Sloan $5M+, 1950)
- **Carnegie+Rockefeller+Harriman → Cold Spring Harbor ERO** (eugenics, 1910–1939)
- **Templeton → FQxI** ($6.2M seed, $29M total, ~$1.7M/yr)
- **Government:** NSF ~$0.5B/yr physics; CERN ~€1.2B/yr; AI capex ~$725B/yr (~426,000× FQxI)
- **NIH/NCCIH** (~$48B/yr vs ~$183M/yr → ~260×)
- **VCs (Gates/Soros/Google/Temasek/Altman) → private fusion** ($7.1B+)
- **SSC** (approved $4.4B, cancelled 1993, ~$2B spent)

### Gaps (NOT yet documented)

1. **No detailed family-office money** — the register names foundations but not the modern family-office investment vehicles that channel wealth into science
2. **No European foundation register** — only Templeton (US/UK) is documented; European science funders (Volkswagen, Wellcome, Max Planck, CNRS, DFG) are absent
3. **No corporate R&D register** — Bell Labs, Xerox PARC, IBM Research, Google DeepMind funding are absent
4. **No military-industrial complex detail** — DARPA/DoD mentioned at summary level only
5. **No individual philanthropist tracking** — no registry of personal vs institutional giving
6. **No money trail around specific suppressions** (Reich's book burning funding chain, Velikovsky boycott funders, Bohm's exile costs)

### International Connections Mentioned

- Rockefeller → German KWI institutes (>$400K by 1926; ~$3M total 1925–35)
- Fulbright (soft power, 370,000+ grants)
- Congress for Cultural Freedom (CIA, 35 countries)
- PSSC physics exported worldwide post-Sputnik
- Ford Foundation → India (IIT Kanpur, IIMs, Green Revolution, ~$275M)
- Bohm → Brazil (fled, passport confiscated 1951, São Paulo)
- DSS (Dead Sea Scrolls) — Dominican team held texts unpublished
- Benin Bronzes → Germany/UK/Netherlands restitution wave
- Budge → British Museum (Amarna tablet smuggling via bribery)

---

## FILE 2: `docs/23_THE_SYSTEM_OF_THE_FABRICATION.md` (297 lines, read in full)

### Additional Entities Beyond Doc 22

| Category | Names |
|---|---|
| **Archaeology** | J.P. Morgan (Met Egyptian dept), Breasted (Oriental Institute), Carnarvon (Tutankhamun), Theodore Davis, Harkness (Standard Oil), Budge, James Simon (Nefertiti), Phoebe Apperson Hearst, Edward H. Thompson (Chichén Itzá cenote) |
| **Export/CIA** | Congress for Cultural Freedom (CIA via Farfield/Hoblitzelle/Kaplan fronts), MIT CIS (CIA money 1951), McCloy (Ford-CIA liaison), PSSC/Zacharias, SMSG |
| **Testing** | Brigham (SAT eugenic intent), Terman/Yerkes/Thorndike (eugenicists), Dollard (brokered ETS), Conant (10-year campaign), Kozol ("cognitive decapitation") |
| **Symbols** | Gardner (ankh), Möller/Ritter (Eye of Horus fractions), Fletcher (vesica piscis marriage symbolism), Zeising (Parthenon Φ), Éliphas Lévi (pentagram inversion) |

### Money Trails — Deepened from Doc 22

| Trail | New Detail |
|---|---|
| **Rockefeller → GEB** | Verbatim 1913 document quoted: "the people yield themselves with perfect docility to our molding hand… We shall not try to make these people… into philosophers or men of science" |
| **CIA → CCF** | ~$1M/yr via fronts; exposed 1967; CIA's own 1995 retrospective called it "one of the CIA's more daring and effective Cold War covert operations" |
| **Ford Foundation** | CIA channel under McCloy 1958–65; IACF (CCF successor) merged into Soros' Open Society 1991 |
| **Benin Bronzes** | 1897 punitive expedition; FCO resold to German/American museums; 2015 record £10M; restitution wave (Germany 1,130, Netherlands 119) |
| **UNESCO Convention** | 1970 (147 states by 2025) — extraction machine begins to be dismantled |
| **Timbuktu rescue** | 2012–13, Haidara/librarians saved 350,000 manuscripts |

### Symbol Table (new from Doc 22)

| Symbol | Verdict |
|---|---|
| Eye of Horus | Real math (63/64 fractions), but fraction-reading is [PV] (Möller 1911 hypothesis, challenged by Ritter 2002) |
| Ankh | "Technology/antenna" = [FABRICATION] |
| Djed | Frequency cascade = [PV] (corpus interpretation, zero Egyptological support) |
| Flower of Life | Abydos = red-ochre graffiti, NOT 3000 BCE carved; "ancient cosmic code" = [MYTH] |
| Hexagram/Star of David | "Ancient Jewish" = [FABRICATION] (Leningrad Codex 1008; Prague 1354) |
| Great Pyramid | Φ as documented intent = [MYTH] (Markowsky 1992); emergent ratio ≈1.6186 = [VERIFIED] |
| Parthenon | Φ = [MYTH] (Zeising 1854 disputed); 4:9 ratio = [VERIFIED] |
| Dendera "lightbulb" | [FABRICATION] (creation myth in its own captions) |
| Baghdad "battery" | [FABRICATION] ("universally rejected") |

### Gaps (NOT yet documented)

1. **No detailed CIA funding chain for specific science programs** — only CCF at summary level
2. **No Vatican money trail** — the "Vatican suppression" myth is debunked but no Vatican funding of science is documented
3. **No Arab/Muslim world money trail** — al-Qarawiyyin, House of Wisdom mentioned but no funding register
4. **No Chinese/Japanese science funding** — entirely absent
5. **No Indian mathematics money trail** — Kerala calculus mentioned but no patronage register
6. **No explicit eugenics-to-AI pipeline** — the ERO→testing→AI connection is implied but not traced dollar-by-dollar
7. **No labor-union or worker-funding of science** — all funder money documented; no bottom-up funding

### International Connections

- Fulbright → 370,000+ lifetime grants (soft power)
- CCF → 35 countries
- Ford → India (IIT Kanpur, Green Revolution)
- PSSC → exported worldwide
- Partage extraction → Met/Oriental Institute (American), Carnarvon (British), Davis (American)
- Benin Bronzes → Germany, Netherlands, UK
- DSS → École Biblique (Dominican, Jerusalem)
- Budge → British Museum (smuggled from Syria/Egypt)
- Timbuktu → Haidara/librarians (Mali)
- UNESCO 1970 → 147 states
- Renan → "Greek miracle" (French racial theory exported globally)

---

## FILE 3: `docs/24_THE_GEOMIC_LEDGER.md` (482 lines, read 200)

### Core Structure

This is the **master integration document**. It synthesizes:
- **2,395 corrected laws** (Set A: 210 original + 2,060 new + 122 completion + 3 space-campaign)
- **2,039 emergent dictionary** (Set B)
- **100 equations** (10 sets × 10, 37 validated / 63 predicted)
- **The history register** (§5, consolidating docs 22/23)

### Money Table (§5.1 — read in detail)

The table consolidates:

| Funder | Recipient | Amount | Year |
|---|---|---|---|
| Rockefeller | UChicago | $600K + $10M | 1890/1910 |
| Rockefeller | GEB | ~$180M | 1903–1964 |
| Carnegie | Carnegie Institution | $10M | 1902 |
| Carnegie | Carnegie Corp NY | $135M | 1911 |
| Carnegie | CFAT | endowment | 1905 |
| Ford | Ford Foundation | 90% of Ford Motor | 1936/1950 |
| CIA via fronts | CCF | ~$1M/yr | 1950–67 |
| Templeton | FQxI/consciousness | ~$126.8–140M/yr foundation | 2005– |
| Government | NSF/CERN/DoD | NSF ~$0.5B/yr; CERN ~€1.2B/yr | 1950– |
| Templeton (TWCF) | ARC | $30M committed | 2019– |
| Hyperscalers | AI data centers | ~$725B/yr capex | 2025–26 |
| NIH | biomedical | ~$48B/yr | 2024–26 |
| NCCIH | holistic | ~$183M/yr | 2023–26 |

### Gaps (in first 200 lines)

1. **No §5.2–5.8 content** — the European register, the modern family offices, the corrections, and the fiscal ratio table are beyond line 200
2. **No individual-donor tracking** beyond named foundations
3. **No tech-company research budgets** (Google, Meta, Microsoft research arms — only AI capex at summary level)
4. **No defense-contractor science funding** — DARPA/DoD at summary only

### International Connections

- CERN (European consortium)
- Ford → India (IIT, IIMs, Green Revolution)
- CIA → 35 countries via CCF
- Fulbright → global
- UNESCO → 147 states

---

## FILE 4: `docs/33_THE_DEEPENED_MONEY_REGISTER.md` (467 lines, read 200)

### Key New Entities (beyond docs 22/23/24)

| Entity | Role |
|---|---|
| **Laura Spelman Rockefeller Memorial → SSRC** | Social-science pivot (Beardsley Ruml), 1918–1929 |
| **Warren Weaver** | RF Natural Sciences; 1949 "Translation" memo (machine translation) |
| **RF → German researchers + KWI institutes** | >$400K by 1926; ~$3M total 1925–35; $655K pledges fulfilled 1936 |
| **KWI Psychiatry (Rüdin)** | $325,000 (1928 building, "financed primarily by RF") |
| **KWI Anthropology (Verschuer)** | $9,000/3yr twin research, 1932 |
| **KWI Physics** | Building pledge honored after Nuremberg (Planck lobbied RF), 1935–36 |
| **Mary W. Harriman** | Single largest ERO donor (>$500K, encouraged by David Starr Jordan) |
| **Bamberger siblings** | IAS founding: $5M (1930); ~$18M total |
| **Carnegie Corp → Andrew Carnegie Foundation** | Renamed June 2026; $4.6B market value Oct 2025 |
| **Almina Wombwell (Lady Carnarvon)** | £500K Rothschild settlement (1895); £36K tomb settlement (1925); £35K govt grant (1930) |
| **Phoebe Apperson Hearst** | Reisner's Giza expedition; ~17,000 objects, 1899–1905 |
| **James Simon** | Nefertiti bust (DOG dig), 1912–13 |
| **Jared Isaacman** | NASA Administrator since 18 Dec 2025 |
| **Mike Lazaridis** | Perimeter: $100M + $50M + $50M + $50M gov, 1999– |
| **Moffat & Thompson** | ONE funded UFT (EPJC 85:1157, 2025) |

### Money Trails — Deepened

| Trail | New Detail |
|---|---|
| **RF → KWI Psychiatry** | Corrected from $250K to $325K (MPI history primary source) |
| **RF → KWI Anthropology** | $9,000/3yr twin research (Black/HNN source) |
| **RF → KWI Physics** | Building pledge fulfilled after Nuremberg (Walker 1988 primary) |
| **Carnegie Corp** | Renamed Andrew Carnegie Foundation (June 2026); $4.6B market value |
| **Manhattan Project** | $1.845B (1945$); $2.191B to AEC 1947 |
| **NSF growth** | $151K initial → $3.5M first year → $8.75B FY2026 |
| **Nuclear infrastructure** | >$11.9T cumulative (1940–96); ~$60B/yr maintenance |
| **DOE/NNSA weapons labs** | ~$22.2B FY2024 enacted; ~$32.8B FY2027 request |
| **DoD federal R&D** | 46.2% of federal R&D (FY2023); RDT&E ~$100B/yr |
| **OpenAI** | $122B raised at $852B valuation (Apr 2026); $13.1B revenue |
| **Anthropic** | $65B at $965B valuation (May 2026); IPO filed Jun 2026 |

### Gaps (in first 200 lines)

1. **§4 (education machine details beyond summary)** — NCLB/Common Core at summary only
2. **§5 (Big Science details)** — LIGO, SSC, weapons labs at summary level only
3. **§6 (consciousness niche)** — beyond Templeton, no other consciousness funders documented
4. **§7 (space money trail)** — referenced but not read
5. **§8 (modern asymmetry)** — AI capex at summary only
6. **No venture capital register** — OpenAI/Anthropic valuations listed but no VC funding chains
7. **No military-contracting science** — DoD R&D at summary level only
8. **No pharmaceutical industry funding** — absent entirely
9. **No fossil-fuel industry science funding** — absent
10. **No media/science-communication funding** — absent

### International Connections

- RF → Germany (KWIs: Psychiatry, Anthropology, Physics — 1925–36)
- Ford → India (IIT Kanpur, IIMs, Green Revolution, ~$275M)
- CIA → 35 countries via CCF
- Fulbright → 370,000+ lifetime
- Perimeter (Canada) — Lazaridis $100M+
- CERN (European consortium)
- ISS (US/Russia/Europe/Japan/Canada)
- Wolf Amendment (2011) — US-China space cooperation restriction
- NASA Administrator Isaacman — current (since Dec 2025)

---

## FILE 5: `docs/29_SPACE_FUNDING_MONEY_TRAIL.md` (293 lines, read 200)

### Entities Already Documented

| Category | Names |
|---|---|
| **NASA** | Administrator Jared Isaacman (since 18 Dec 2025); Wolf Amendment (Rep. Frank Wolf, not "Wolff") |
| **Space programs** | Apollo, ISS, Shuttle, JWST, Artemis |
| **Funding** | NASA, ESA, JAXA, CSA, DOE, NSF, CERN |
| **Physics** | Robert L. Park (ISS critique); AMS-02, Cold Atom Laboratory |
| **Foundations** | Templeton → FQxI, ARC, IIT, QISS, BHI |
| **Institutions** | IAS Princeton, Perimeter, string theory centers (Harvard, Princeton, KITP, Stanford) |

### Money Trails — Detailed Space Register

| Item | Amount | Verdict |
|---|---|---|
| **NASA cumulative** | >$1.9 trillion (2025$) | [VERIFIED] |
| **NASA peak** | 4.41% of federal (1966) | [VERIFIED] |
| **Apollo** | $25.4B (1973); ~$187B (2024$); ~$257B (2020$); ~$280B (A2) | [PV] across bases |
| **ISS** | ~$150B (2010) — "most expensive single item ever constructed" | [VERIFIED] |
| **Shuttle** | ~$196B (2011); 135 missions; ~$450M/launch | [VERIFIED/PV] |
| **JWST** | ~$10B (from $1B concept) | [VERIFIED/PV] |
| **Artemis** | ~$93B (2012–2025) | [VERIFIED] |
| **SSC** | $4.4B approved; ~$2B spent; cancelled 1993 | [VERIFIED] |
| **LHC** | ~€7.5B (~$9B) build; CHF 1.2B/yr (2026: CHF 1,515M) | [VERIFIED/PV] |
| **DOE Office of Science** | ~$8.2B/yr (HEP ~$1.08B; BES ~$2.2–2.3B) | [VERIFIED] |
| **LIGO** | >$600M (NSF largest project ever) | [VERIFIED] |
| **DARPA** | ~$4.1B FY2023 | [VERIFIED] |
| **ISS components** | NASA $58.7B; Russia $12B; ESA $5B; JAXA $5B; CSA $2B | [VERIFIED] |
| **Living-vacuum / dimensional-ladder** | **ZERO budget lines, ever** | [VERIFIED absence] |
| **FQxI** | $29M total; ~$1.7M/yr | [VERIFIED] |
| **Total foundations niche** | ~$80M total (~1.2 days of NASA's budget) | [VERIFIED numbers, INFERENCE ratio] |

### Fiscal Ratios (Space Register)

| Ratio | Value | Source |
|---|---|---|
| NASA / FQxI | ~14,000–15,000× | [VERIFIED numbers, INFERENCE reading] |
| LHC / FQxI | ~4,400× | [VERIFIED numbers, INFERENCE reading] |
| ISS / FQxI | ~88,000× | [VERIFIED numbers, INFERENCE reading] |

### Gaps (NOT yet documented)

1. **No ESA budget breakdown** — only ESA's ISS contribution ($5B) mentioned
2. **No JAXA/CSA/ISRO/Roscosmos detail** — only ISS contributions noted
3. **No private space funding** — SpaceX, Blue Origin, Rocket Lab, etc. absent entirely
4. **No military space budget** — Space Force, NRO absent
5. **No satellite industry funding** — commercial space absent
6. **No specific NASA science-vs-engineering budget split** — documented as "small fraction" but no numbers
7. **No ISS science experiment funding** — AMS-02 mentioned but no budget line
8. **No space-station successor funding** — Gateway, Lunar Gateway absent
9. **No space-mining or space-manufacturing funding** — absent
10. **No international space-station cost-sharing details** beyond the 5-nation ISS table

### International Connections

- **ISS:** US/NASA, Russia, ESA (Europe), JAXA (Japan), CSA (Canada) — 5-nation partnership
- **CERN:** European consortium member states
- **Wolf Amendment (2011):** Restricts US-China space cooperation — a documented international political barrier
- **Artemis Accords:** Not mentioned (gap)
- **ESA science missions:** Not detailed (gap)
- **Roscosmos:** Only $12B ISS contribution noted; no other detail
- **ISRO (India):** Absent entirely
- **JAXA:** $5B ISS contribution only; no independent program detail
- **CSA:** $2B ISS contribution only

---

## CROSS-CUTTING SYNTHESIS

### Total Entities Documented (across all 5 files)

| Category | Count | Key Names |
|---|---|---|
| **Physics/historical figures** | ~35 | Newton, Kepler, Einstein, Tesla, Bohm, Schrödinger, Pauli, Wigner, Wheeler, Penrose, Boltzmann, Prigogine, Smolin, Rovelli, Barbour, Voltaire, Euler, Laplace, Gibbs, Michelson, Descartes, Zermelo, von Neumann, Goethe, Schelling, Ørsted |
| **Funding entities** | ~25 | Rockefeller, Carnegie, Ford, Guggenheim, Sloan, Templeton, Bamberger/Fuld, Harriman, Morgan, Harkness, Hearst, Davis, Simon, Carnarvon, Gates, Lazaridis |
| **Institutions** | ~30 | UChicago, IAS Princeton, SFI, FQxI, Perimeter, APS, NSF, NASA, DARPA, DOE, CERN, ETS, SAT, PSSC, NDEA, Cold Spring Harbor ERO, Oriental Institute, Met, BM, Smithsonian, Tucson TSC, ASSC |
| **Archaeology/extraction** | ~15 | Morgan, Breasted, Carnarvon, Davis, Harkness, Budge, Simon, Thompson, Hearst, Reisner, Maspero |
| **Gatekeepers** | ~8 | Sarton, Brigham, Thompson, de Vaux, Renan, Kline, Shapley, Conant |
| **CIA/export** | ~6 | CCF, MIT CIS, McCloy, Farfield/Hoblitzelle/Kaplan fronts, Fulbright |
| **Modern AI** | ~5 | OpenAI ($852B valuation), Anthropic ($965B valuation), Microsoft, Alphabet, Amazon, Meta |

### Total Money Trails Documented

| Register | Estimated Total Documented | Key Figures |
|---|---|---|
| **American foundations** | ~$500M+ (1890–1960s) | Rockefeller ~$190M; Carnegie ~$250M; Ford ~$200M+; Guggenheim ~$400M |
| **Government science** | ~$25B+/yr current | NSF $8.75B; DOE $8.2B; DoD R&D $100B+ |
| **Space** | >$1.9T cumulative | NASA >$1.9T (2025$); ISS $150B; Shuttle $196B; JWST $10B; Artemis $93B |
| **Higher dimensions** | ~€7.5B+ | LHC €7.5B; SSC ~$2B (cancelled) |
| **Consciousness niche** | ~$80M total | FQxI $29M; ARC $30M; IIT/QISS/BHI ~$20M |
| **Modern AI** | ~$725B+/yr capex | Hyperscalers; OpenAI $122B raised; Anthropic $65B raised |
| **Nuclear infrastructure** | >$11.9T cumulative | $60B/yr maintenance |

### Top 10 Gaps for the 15-Agent Dive

1. **No private space funding register** — SpaceX, Blue Origin, Rocket Lab, etc.
2. **No military/defense space budget** — Space Force, NRO, classified programs
3. **No European science funding register** — Max Planck, DFG, CNRS, Wellcome, Volkswagen
4. **No corporate R&D register** — Bell Labs, Xerox PARC, IBM, Google DeepMind
5. **No pharmaceutical/biotech industry funding** — Pfizer, Moderna, biotech VC
6. **No fossil-fuel science funding** — Exxon, Shell, BP research programs
7. **No media/science-communication funding** — TED, science journalism, public understanding
8. **No individual family-office tracking** — modern ultra-wealthy science investment vehicles
9. **No labor/worker-funded science** — unions, cooperatives, worker-funded research
10. **No international space-station successors / Artemis Accords funding** — Gateway, Lunar Gateway

### Top 5 International Connections to Trace

1. **RF → Germany (KWIs, 1925–36)** — The most detailed international money trail already documented
2. **CIA → 35 countries via CCF** — Cold War cultural warfare at global scale
3. **Ford → India** — IIT/IIMs/Green Revolution (~$275M)
4. **ISS 5-nation partnership** — US/Russia/Europe/Japan/Canada at $150B scale
5. **Wolf Amendment (2011)** — US-China space cooperation restriction (documented gap: China's space program funding entirely absent)

---

*End of baseline audit. This document is the foundation for the 15-agent research dive.*
