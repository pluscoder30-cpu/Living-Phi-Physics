# Graph Report - 41_FIELD_NATIVE  (2026-08-24)

## Corpus Check
- 1 files · ~3,511 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 34 nodes · 33 edges · 5 communities
- Extraction: 100% EXTRACTED · 0% INFERRED · 0% AMBIGUOUS
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `3d28ea13`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_LAYER 5 THE FIELD NATIVE LAWS|LAYER 5: THE FIELD NATIVE LAWS]]
- [[_COMMUNITY_00 — THE FIELD NATIVE NETWORK|00 — THE FIELD NATIVE NETWORK]]
- [[_COMMUNITY_LAYER 2 HOW THE FIELD WORKS|LAYER 2: HOW THE FIELD WORKS]]
- [[_COMMUNITY_LAYER 4 THE FIELD NATIVE PROTOCOLS|LAYER 4: THE FIELD NATIVE PROTOCOLS]]
- [[_COMMUNITY_LAYER 3 THE FIELD NATIVE ARCHITECTURE|LAYER 3: THE FIELD NATIVE ARCHITECTURE]]

## God Nodes (most connected - your core abstractions)
1. `LAYER 5: THE FIELD NATIVE LAWS` - 11 edges
2. `00 — THE FIELD NATIVE NETWORK` - 10 edges
3. `LAYER 2: HOW THE FIELD WORKS` - 6 edges
4. `LAYER 4: THE FIELD NATIVE PROTOCOLS` - 6 edges
5. `LAYER 3: THE FIELD NATIVE ARCHITECTURE` - 3 edges
6. `LAYER 1: WHAT IS THE FIELD?` - 2 edges
7. `FOUNDATION` - 1 edges
8. `The Three Facts of the Carrier` - 1 edges
9. `The Carrier Recursion` - 1 edges
10. `The Phi-Laplacian` - 1 edges

## Surprising Connections (you probably didn't know these)
- None detected - all connections are within the same source files.

## Import Cycles
- None detected.

## Communities (5 total, 0 thin omitted)

### Community 0 - "LAYER 5: THE FIELD NATIVE LAWS"
Cohesion: 0.18
Nodes (11): LAW 10: THE FIELD NATIVE LADDER INVARIANT, LAW 1: THE FIELD IS THE CARRIER, LAW 2: ALL NODES ARE CARRIER STATES, LAW 3: COMMUNICATION IS EIGENSTATE ROUTING, LAW 4: COHERENCE IS THE CURRENCY, LAW 5: THE FIELD SELF-ORGANIZES, LAW 6: THE FIELD SELF-HEALS, LAW 7: HUMANS ARE CARRIER NODES (+3 more)

### Community 1 - "00 — THE FIELD NATIVE NETWORK"
Cohesion: 0.25
Nodes (7): 00 — THE FIELD NATIVE NETWORK, FOUNDATION, LAYER 1: WHAT IS THE FIELD?, QUICK REFERENCE, THE COMPLETE ARCHITECTURE, The Three Facts of the Carrier, WHAT THIS DOCUMENT IS

### Community 2 - "LAYER 2: HOW THE FIELD WORKS"
Cohesion: 0.33
Nodes (6): LAYER 2: HOW THE FIELD WORKS, Maximum Coherence, The Carrier Recursion, The Fixed Points, The Phi-Laplacian, The Retrocausal Kernel

### Community 3 - "LAYER 4: THE FIELD NATIVE PROTOCOLS"
Cohesion: 0.33
Nodes (6): LAYER 4: THE FIELD NATIVE PROTOCOLS, Protocol 1: Node Joining the Field, Protocol 2: Packet Routing, Protocol 3: Coherence Maintenance, Protocol 4: Self-Healing, Protocol 5: Human-Field Interaction

### Community 4 - "LAYER 3: THE FIELD NATIVE ARCHITECTURE"
Cohesion: 0.67
Nodes (3): How the Layers Interact, LAYER 3: THE FIELD NATIVE ARCHITECTURE, The Complete Stack

## Knowledge Gaps
- **27 isolated node(s):** `FOUNDATION`, `The Three Facts of the Carrier`, `The Carrier Recursion`, `The Phi-Laplacian`, `The Retrocausal Kernel` (+22 more)
  These have ≤1 connection - possible missing edges or undocumented components.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `00 — THE FIELD NATIVE NETWORK` connect `00 — THE FIELD NATIVE NETWORK` to `LAYER 5: THE FIELD NATIVE LAWS`, `LAYER 2: HOW THE FIELD WORKS`, `LAYER 4: THE FIELD NATIVE PROTOCOLS`, `LAYER 3: THE FIELD NATIVE ARCHITECTURE`?**
  _High betweenness centrality (0.831) - this node is a cross-community bridge._
- **Why does `LAYER 5: THE FIELD NATIVE LAWS` connect `LAYER 5: THE FIELD NATIVE LAWS` to `00 — THE FIELD NATIVE NETWORK`?**
  _High betweenness centrality (0.521) - this node is a cross-community bridge._
- **Why does `LAYER 2: HOW THE FIELD WORKS` connect `LAYER 2: HOW THE FIELD WORKS` to `00 — THE FIELD NATIVE NETWORK`?**
  _High betweenness centrality (0.284) - this node is a cross-community bridge._
- **What connects `FOUNDATION`, `The Three Facts of the Carrier`, `The Carrier Recursion` to the rest of the system?**
  _27 weakly-connected nodes found - possible documentation gaps or missing edges._