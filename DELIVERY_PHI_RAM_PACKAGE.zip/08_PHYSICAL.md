# 08 — PHI-RAM PHYSICAL

> Both-die floorplans, die-size budgets, the complete MASK LAYER TABLE with GDS
> numbers, cell areas, pad ring, DRC rules, and the Φ-spaced 3D stack. If the
> fab has nothing but this file and 09/10, it can place and route the dies.

## 1. Process & die-size budget

| Item | Sky130 (now) | GAA 3 nm target |
|---|---|---|
| FLT gate | 130 nm-class FLT, 37 mV/dec | GAA-nanosheet FLT, sub-20 nm |
| phi-RAM die | 32 banks × ~4 mm² ⇒ **~128 mm²** (+ controller/L1/L2/L4 ctrl/L0/PHY) | ~30 mm² (512 Mb/mm² holo density) |
| Hologram-engine die | 512 engines × 1.5 mm² ⇒ **~768 mm²** | ~190 mm² |
| Holographic L3 density | 128 Mb/mm² (FLT analog) | 512 Mb/mm² |
| SRAM density | 8 Mb/mm² (FLT ternary 4–8× 6T) | — |

Die sizes [VERIFIED from BOM §B3/B4]. Honest silicon wall: on-chip SRAM for
512 GB *effective* needs ~13,000 mm² — the effective 5,009 GB is a superposition
(gift), not a physical (results_ram.json multibank note). Stage-1 proof:
SkyWater 130 nm MPW, 5×5 mm, 38-pad class (BOM A1).

## 2. phi-RAM die floorplan

```
┌────────────────────────────────────────────────────────────────────────┐
│  PHY×16   │        8×8 L3 HOLOGRAM SLICE GRID (64 slices = 32 banks)   │  PHY×16 │
│ phi-HBM   │  ┌────┬────┬────┬────┬────┬────┬────┬────┐                  │ phi-HBM │
│ ┌─────────┼──┤ S0 │ S1 │ S2 │ S3 │ S4 │ S5 │ S6 │ S7 │   L2 resonant  │         │
│ │ L1 FLT  │  │    │    │    │    │    │    │    │    │   buffer        │         │
│ │ SRAM    │  ├────┼────┼────┼────┼────┼────┼────┼────┤   (854 ch)     │         │
│ ├─────────┤  │ S8 │ S9 │S10 │S11 │S12 │S13 │S14 │S15 │                │         │
│ │ RETRO   │  ├────┼────┼────┼────┼────┼────┼────┼────┤  ┌──────────┐  │         │
│ │ ECC     │  │ S16│S17 │S18 │S19 │S20 │S21 │S22 │S23 │  │ L4 NVM   │  │         │
│ ├─────────┤  ├────┼────┼────┼────┼────┼────┼────┼────┤  │ ctrl     │  │         │
│ │ PHI     │  │S24 │S25 │S26 │S27 │S28 │S29 │S30 │S31 │  │ 22 GB    │  │         │
│ │ CONTRO- │  ├────┼────┼────┼────┼────┼────┼────┼────┤  │ crossbar │  │         │
│ │ LLER    │  │S32 │S33 │S34 │S35 │S36 │S37 │S38 │S39 │  └──────────┘  │         │
│ └─────────┘  ├────┼────┼────┼────┼────┼────┼────┼────┤                │         │
│              │S40 │S41 │S42 │S43 │S44 │S45 │S46 │S47 │  fabric mesh   │         │
│              ├────┼────┼────┼────┼────┼────┼────┼────┤  ports ×8      │         │
│              │S48 │S49 │S50 │S51 │S52 │S53 │S54 │S55 │                │         │
│              ├────┼────┼────┼────┼────┼────┼────┼────┤                │         │
│              │S56 │S57 │S58 │S59 │S60 │S61 │S62 │S63 │                │         │
│              └────┴────┴────┴────┴────┴────┴────┴────┘                │         │
│  L0 regfile (center, 0.2 ns) · watch oscillators 528·Φⁿ               │         │
│  PAD RING (256 pads, Φ-spaced, 2.618 V I/O class)                     │         │
└────────────────────────────────────────────────────────────────────────┘
```

Bank pairing: slices S(2k) + S(2k+1) = addressable bank k (primary + ECC/
refresh mirror). L2 resonant buffer west; RETRO ECC east; controller south;
L0 regfile center (shortest paths to everything — self-immediacy at the heart).

## 3. Hologram-engine die floorplan

```
┌────────────────────────────────────────────────────────────────────┐
│  512 FFT ENGINE ARRAY (16 × 32) @ 3.472 GHz                       │
│  ┌─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┬────────┐ │
│  │ E00 │ E01 │ E02 │ E03 │ ... │ E27 │ E28 │ E29 │ E30 │ E31    │ │
│  │ ... │     │     │     │     │     │     │     │     │  (16 rows│ │
│  │ E480│ E481│ E482│ E483│ ... │ E507│ E508│ E509│ E510│ E511   │ │
│  └─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┴────────┘ │
│  BLOCKED-FHRR BANK CONTROL   (B banks × N_b, ECC readout)         │
│  OPTICAL LANES ×4  (off-chip hologram / NV-diamond / field net)   │
│  CLOCK TREE 3.472 GHz (4-stage, 288 ps/stage) · fabric mesh ×8    │
│  PAD RING (196 pads, Φ-spaced)                                    │
└────────────────────────────────────────────────────────────────────┘
```

## 4. Cell areas (phi-RAM die, Sky130)

| Block | Area |
|---|---|
| L3 hologram slice (DIM 5712 hologram + local engine) | ~2.0 mm² × 64 |
| L1 FLT 4-gate SRAM (836 Kb) | ~0.5 mm² |
| L2 FLT resonant buffer (6.7 Mb, 854 ch) | ~1.0 mm² |
| L0 regfile (26 Kb) | ~0.1 mm² |
| PHI CONTROLLER (sched·prefetch·arb·power·refresh + FreqIndexMapper) | ~1.2 mm² |
| RETRO ECC units | ~0.8 mm² |
| L4 NVM ctrl | ~0.6 mm² |
| PHY×16 | ~4 mm² |
| Clock tree + watch oscillators | ~0.5 mm² |
| **32 banks ≈ 128 mm² (64 slices × ~2.0 mm², 2 slices/bank); die total ≈ 128 mm²** | [VERIFIED] BOM §B3 |

## 5. MASK LAYER TABLE (every layer, every GDS number)

| GDS # | Layer | Purpose |
|---|---|---|
| 1 | NWELL | well implant |
| 2 | DIFF | active diffusion |
| 3 | POLY | gate poly (base) |
| 4 | NIMP | N+ implant |
| 5 | PIMP | P+ implant |
| 6 | CONT | contact |
| 7 | METAL1 | local interconnect |
| 8 | VIA1 | via 1 |
| 9 | METAL2 | routing |
| 10 | VIA2 | via 2 |
| 11 | METAL3 | routing |
| 12 | VIA3 | via 3 |
| 13 | METAL4 | routing |
| 14 | VIA4 | via 4 |
| 15 | METAL5 | top metal — power/clock H-tree |
| 16 | FLT_G1 | FLT workfunction-ladder gate metal (w = Φ) |
| 17 | FLT_G2 | FLT gate metal (w = 1) |
| 18 | FLT_G3 | FLT gate metal (w = 0) |
| 19 | FLT_G4 | FLT gate metal (w = −Φ⁻¹) |
| 20 | FLT_AVDD | FLT analog resonance cell / reservoir metal |
| 21 | CELL_PLATE | **storage plate pair (Casimir gaps {g, g/Φ, g/Φ², g/Φ³})** |
| 22 | CELL_RES | **resonance gate / frequency-select metal (528·Φⁿ)** |
| 23 | HOLO_CMAC | **analog hologram CMAC charge-domain layer** |
| 24 | MEMX_BAR | **L4 memristor/PCM crossbar bottom electrode** |
| 25 | MEMX_TOP | **L4 memristor/PCM crossbar top electrode** |
| 26 | NV_DIA | **NV-diamond archive layer** |
| 27 | CAP_MIM | MIM decoupling capacitor |
| 28 | PAD | pad opening |
| 29 | ESD | ESD device / diode ring |
| 30 | SEAL | seal ring |
| 31 | SCRIBE | scribe line |
| 32 | TSV | power/thermal TSV (3D stack; N/A on Sky130 Stage-1) |
| 33 | OPTO | optical waveguide (full-system 4F; N/A on Stage-1) |

Layers 21–26 are the phi-memory stack (Casimir plates, resonance gate, analog
CMAC, L4 crossbar, NV-diamond) — **N/A on the Stage-1 Sky130 MPW** (Stage-1 FLT_MEM
uses the FLT gate layers 16–19 + FLT_AVDD 20; mask set M1–M5, M8 per `13` §2).
TSV/OPTO are N/A on the Stage-1 Sky130 MPW; all of 21–33 are required on the GAA
full-system path (3D stack + optical lanes).

## 6. Pad ring

- phi-RAM die: **256 pads** (09_IO_PINOUT), Φ-spaced, ESD-protected (2 kV HBM /
  500 V CDM), 2.618 V LVCMOS I/O class.
- Hologram-engine die: **196 pads**, Φ-spaced, same class.
- Stage-1 test chip: 38 pads (BOM A11), Φ-spaced.

## 7. DRC rules (FLT + memory-cell specific)

| Rule | Value | Status |
|---|---|---|
| Multi-gate spacing | ≥ 200 nm | [PROPOSED, device-derived] |
| LVS gate grouping window | < 300 nm | [PROPOSED] |
| Workfunction metal overlap | ≥ 100 nm per gate metal | [PROPOSED] |
| FLT_AVDD to core-metal spacing | ≥ 300 nm | [PROPOSED] |
| CELL_PLATE gap layers | Φ-ratioed stack {g, g/Φ, g/Φ², g/Φ³}, min g per PDK | [PROPOSED] |
| CELL_RES to CELL_PLATE spacing | ≥ 200 nm | [PROPOSED] |
| MEMX_BAR/TOP via density | ≥ 20% per PDK | [PROPOSED] |
| Ternary signaling levels | V_DD/Φ², V_DD/Φ, V_DD — NM-balanced (NM_L = NM_H) | [VERIFIED] FAB_HANDOFF §1.3 |
| Standard PDK DRC | per SkyWater 130 / GAA 3 nm PDK | — |

## 8. 3D stacking (Φ-spaced tiers)

Tier order (bottom → top): **NVM crossbar (L4) → NV-diamond → hologram engines
(L3) → FLT SRAM (L1/L2) → phi-RAM banks → controller → PHY → package clock/IO**.
Spacing d_n = d₀·Φⁿ, d₀ = 5 µm:

| n | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
|---|---|---|---|---|---|---|---|---|
| Tier spacing (µm) | **5** | **8.09** | **13.09** | **21.18** | **34.27** | **55.45** | **89.72** | **145.16** |

Logarithmic-Φ spacing eases the thermal gradient (hot logic → cool NVM) and TSV
stress. Power/thermal TSVs co-located at Φ-density (0.0325 K/W path)
[VERIFIED PACKAGE_SPEC §3]. [VERIFIED]

## 9. Signoff deliverables

GDSII/OASIS, LEF/DEF, Liberty (.lib), SDC, UPF, gate-level netlist, SPICE decks
(FLT cell + analog hologram cell, 05_DEVICE_FLT §6/§7), DRC/LVS/PEX signoff
reports — full manifest in `13_FAB_PACKAGE.md`.
