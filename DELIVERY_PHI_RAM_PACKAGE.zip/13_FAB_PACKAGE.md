# 13 — PHI-RAM FAB PACKAGE (TAPE-OUT DATA PACKAGE)

> THE tape-out package: every file the fab receives, in the order the fab
> consumes it. GDSII/OASIS, LEF/DEF, Liberty, SDC, UPF, netlist, SPICE decks
> (FLT cell + analog hologram cell), DRC/LVS/PEX signoff, mask set list, MPW
> plan. Stage 1 (Sky130) is actionable now; the GAA 3 nm path is the production
> target with the same discipline.

## 1. Deliverable manifest (per die)

| # | Artifact | phi-RAM die | Holo-engine die | Gate |
|---|---|---|---|---|
| 1 | GDSII / OASIS | RAM_TOP (256-pad) + 3D stack tiers | HOLO_TOP (196-pad) | DRC clean |
| 2 | LEF / DEF | placement + Φ-spaced pad ring | engine array 16×32 | — |
| 3 | Liberty (.lib) | bank/controller/ECC cells | FFT-engine cells | characterization |
| 4 | SDC | 5 clock domains (07_CLOCK) | 3.472 GHz engine constraints | timing clean |
| 5 | UPF | 4 power domains (04 §1) | 4 power domains | — |
| 6 | Netlist | gate-level (post-synthesis) | engine array + bank ctrl | LVS clean |
| 7 | SPICE decks | FLT cell + analog hologram cell (05 §6/§7) | FFT butterfly + correlate CMAC | PEX |
| 8 | DRC report | Sky130 / GAA 3 nm rules + FLT rules (08 §7) | same | must pass clean |
| 9 | LVS report | FLT_N/FLT_P labeling, gate grouping < 300 nm | engine equivalence | must pass clean |
| 10 | PEX report | parasitics for 3.472 GHz engine paths | — | — |
| 11 | Test program | TEST-1..10 vectors (11_TEST_DFT) | engine BIST + scan | — |
| 12 | Package data | interposer + 3D stack (10_PACKAGE) | optical lanes | — |

## 2. Mask set list

| # | Mask | GDS | Purpose | Stage |
|---|---|---|---|---|
| M1 | NWELL / DIFF / POLY base | 1–3 | base flow | Sky130 + GAA |
| M2 | N/P implants + CONT | 4–6 | base flow | Sky130 + GAA |
| M3 | METAL1–5 + VIA1–4 | 7–15 | routing + H-tree top metal | Sky130 + GAA |
| M4 | FLT gate-stack (workfunction ladder) | 16–19 | φ_m,i = φ_Si + Φ^w_i·Δφ_0 | **custom** (2 masks, $3 K, BOM A2) |
| M5 | FLT_AVDD analog reservoir | 20 | resonance cells | custom |
| M6 | Cell plates + resonance + hologram CMAC | 21–23 | the phi-memory cell | custom (GAA) |
| M7 | L4 crossbar (memristor/PCM) + NV-diamond | 24–26 | non-volatile L4 | custom (GAA) |
| M8 | MIM cap / PAD / ESD / SEAL / SCRIBE | 27–31 | IO + ESD | Sky130 + GAA |
| M9 | TSV (power/thermal, Φ-density) | 32 | 3D stack | **N/A on Stage-1** |
| M10 | OPTO (optical waveguides) | 33 | 4F optical lanes | **N/A on Stage-1** |

Stage-1 Sky130 MPW uses M1–M5, M8 (2 custom FLT masks). TSV/OPTO are GAA
full-system masks.

## 3. SPICE decks delivered

- **FLT cell** (`05_DEVICE_FLT §6`): 4-gate workfunction-ladder nMOS with
  PHIEXP transport exponent, NFACTOR ≈ Φ⁻¹ (S = 37 mV/dec).
- **Analog hologram cell** (`05_DEVICE_FLT §7`): charge-domain CMAC with FLT
  transport + Casimir plate stack {g, g/Φ, g/Φ², g/Φ³} + resonance gate
  (f = 528·Φⁿ).
- Model start points are [PROPOSED]; the fab's BSIM/PSP extraction replaces
  them after TEST-1..3 (B1500A I-V/C-V).

## 4. Signoff requirements

| Check | Requirement |
|---|---|
| DRC | SkyWater 130 / GAA 3 nm PDK clean + FLT rules (08 §7) |
| LVS | gates sharing active < 300 nm grouped + labeled FLT_N/FLT_P with gate count (3–5) |
| PEX | 3.472 GHz engine paths parasitic-closed (288 ps stage) |
| Timing | SDC all 5 domains; skew ≤ 3 ps; Δφ < 55.7° (07 §3) |
| Power | UPF 4 domains; RAM ≤ 35 W, holo ≤ 200 W (04 §4) |
| Reliability | ESD 2 kV / CDM 500 V; EM/IR budgeted (12) |

## 5. MPW plan

| Stage | Shuttle | Die | Cost | Status |
|---|---|---|---|---|
| Stage-1 | SkyWater 130 nm MPW, 5×5 mm, 38-pad | FLT test chip: FLT_INV/NAND/RES/DFF/MEM, RO, 4-stage pipelined MAC, 38 pads + ESD | **$14,500** (MPW $10K + FLT masks $3K + pkg/test $1.5K) | [VERIFIED] BOM §A/§E |
| Stage-2 | Sky130 / GAA proof | 1–4 bank clusters FLT compute proof @ ≤ 983 MHz | — | [PROPOSED] |
| Production | GAA 3 nm | phi-RAM die (~128 mm² Sky130 / ~30 mm² GAA) + holo die (~768 mm² / ~190 mm²) | — | [PROPOSED] |

**Fabrication one-page (FAB_HANDOFF §4), the fab must know:**
1. FLT is a multi-gate transistor with Φ-weighted workfunctions — the phi weight
   is in the metal, not the arithmetic; same GAA flow, only the gate-stack mask
   set changes.
2. S = 37 mV/dec target — falsified if S > 55 mV/dec (3σ) on fabricated devices.
3. Dual-regime by design: near-threshold logic (≤ 1 GHz) and strong-inversion
   resonance gates (≤ 3.472 GHz). Do not "optimize" logic to the high clock —
   the slope advantage lives only near threshold.
4. **No vacuum energy.** The fab is not asked to build a free-energy device.
   Every gain is device/architecture level.
5. The hologram is a superposition memory at **253:1 safe** (DIM 5712, 90%
   rank-1) — NOT the falsified 2048:1. Tape-out acceptance uses the measured
   frontier (TEST-7..10).
