# 09 — PHI-RAM IO PINOUT

> The COMPLETE pin tables for both dies — every pin numbered, no "etc.".
> **phi-RAM die: 256 pins. hologram-engine die: 196 pins.** Power, clocks,
> reset/test/scan/JTAG, PHY×16 (HBM-class, 2.618 V), fabric mesh ports
> (128 B/cycle), optical lanes, refresh/ECC status, coherence probes, spares.

---

# PART A — PHI-RAM DIE (256 pins)

## A. POWER (pins 1–36)

VDD_LL = 0.618 V (Φ⁻¹ — L0/L1 logic, controller state, near-threshold).
VDD = 1.0 V (bank arrays, L2, coherence gates). VDD_HI = 1.618 V (Φ — resonance
gates, engine control). VDD_IO = 2.618 V (Φ² — PHY×16, pad ring, analog FLT).
GND = common return.

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 1 | VDD_LL0 | PWR | 0.618 V | rail | Φ⁻¹ domain | L0/L1 logic |
| 2 | VDD_LL1 | PWR | 0.618 V | rail | Φ⁻¹ domain | L0/L1 logic |
| 3 | VDD_LL2 | PWR | 0.618 V | rail | Φ⁻¹ domain | controller state |
| 4 | VDD_LL3 | PWR | 0.618 V | rail | Φ⁻¹ domain | RETRO ECC logic |
| 5 | VDD_LL4 | PWR | 0.618 V | rail | Φ⁻¹ domain | RETRO ECC logic |
| 6 | VDD_LL5 | PWR | 0.618 V | rail | Φ⁻¹ domain | refresh sched logic |
| 7 | VDD0 | PWR | 1.0 V | rail | bank array quadrant | |
| 8 | VDD1 | PWR | 1.0 V | rail | bank array quadrant | |
| 9 | VDD2 | PWR | 1.0 V | rail | bank array quadrant | |
| 10 | VDD3 | PWR | 1.0 V | rail | bank array quadrant | |
| 11 | VDD4 | PWR | 1.0 V | rail | L2 resonant buffer | |
| 12 | VDD5 | PWR | 1.0 V | rail | L2 resonant buffer | |
| 13 | VDD6 | PWR | 1.0 V | rail | coherence gates | |
| 14 | VDD7 | PWR | 1.0 V | rail | coherence gates | |
| 15 | VDD_HI0 | PWR | 1.618 V | rail | resonance gates | FLT_RES |
| 16 | VDD_HI1 | PWR | 1.618 V | rail | resonance gates | FLT_RES |
| 17 | VDD_HI2 | PWR | 1.618 V | rail | engine control | |
| 18 | VDD_HI3 | PWR | 1.618 V | rail | engine control | |
| 19 | VDD_IO0 | PWR | 2.618 V | rail | PHY×16 domain | |
| 20 | VDD_IO1 | PWR | 2.618 V | rail | PHY×16 domain | |
| 21 | VDD_IO2 | PWR | 2.618 V | rail | PHY×16 domain | |
| 22 | VDD_IO3 | PWR | 2.618 V | rail | PHY×16 domain | |
| 23 | VDD_IO4 | PWR | 2.618 V | rail | pad ring | |
| 24 | VDD_IO5 | PWR | 2.618 V | rail | pad ring | |
| 25 | GND0 | PWR | 0 V | rail | return | |
| 26 | GND1 | PWR | 0 V | rail | return | |
| 27 | GND2 | PWR | 0 V | rail | return | |
| 28 | GND3 | PWR | 0 V | rail | return | |
| 29 | GND4 | PWR | 0 V | rail | return | |
| 30 | GND5 | PWR | 0 V | rail | return | |
| 31 | GND6 | PWR | 0 V | rail | return | |
| 32 | GND7 | PWR | 0 V | rail | return | |
| 33 | GND8 | PWR | 0 V | rail | return | |
| 34 | GND9 | PWR | 0 V | rail | return | |
| 35 | GND10 | PWR | 0 V | rail | return | |
| 36 | GND11 | PWR | 0 V | rail | return | |

## B. CLOCKS (pins 37–48)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 37 | CLK_BANK | I | 1.0 V | diff | **Bank clock 2.571807 GHz** (rung 32) | C06 |
| 38 | CLK_BANK_N | I | 1.0 V | diff | complement of 37 | 100 Ω diff |
| 39 | CLK_ENGINE | O | 1.618 V | diff | **Engine clock 3.472 GHz** forwarded to holo die | G01 |
| 40 | CLK_ENGINE_N | O | 1.618 V | diff | complement of 39 | 100 Ω diff |
| 41 | CLK_L2 | I | 1.0 V | diff | **L2 consensus hub 1.589464 GHz** (rung 31) | C05 |
| 42 | CLK_L2_N | I | 1.0 V | diff | complement of 41 | 100 Ω diff |
| 43 | CLK_IO | I | 1.0 V | diff | **I/O clock 375 MHz** (rung 31 / Φ³) | derived |
| 44 | CLK_IO_N | I | 1.0 V | diff | complement of 43 | 100 Ω diff |
| 45 | PLL_REF | I | 1.0 V | diff | **528.0 MHz** reference (F_BASE) | |
| 46 | PLL_REF_N | I | 1.0 V | diff | complement of 45 | 100 Ω diff |
| 47 | SYS_CLK_DFT | I | 1.0 V | LVCMOS | scan/DFT test clock ≤ 500 MHz | |
| 48 | SYS_CLK_DFT_N | I | 1.0 V | LVCMOS | complement of 47 | |

## C. RESET / TEST / SCAN / JTAG (pins 49–60)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 49 | RESET_N | I | 1.0 V | LVCMOS | async active-low reset | full-state |
| 50 | TEST_EN | I | 1.0 V | LVCMOS | test-enable (forces DFT mode) | |
| 51 | SCAN_MODE | I | 1.0 V | LVCMOS | scan-chain mode select | |
| 52 | SCAN_CLK | I | 1.0 V | LVCMOS | scan shift clock | |
| 53 | SCAN_IN | I | 1.0 V | LVCMOS | scan input | |
| 54 | SCAN_OUT | O | 1.0 V | LVCMOS | scan output | |
| 55 | JTAG_TCK | I | 2.618 V | LVCMOS | JTAG test clock | |
| 56 | JTAG_TMS | I | 2.618 V | LVCMOS | JTAG mode select | |
| 57 | JTAG_TDI | I | 2.618 V | LVCMOS | JTAG data in | |
| 58 | JTAG_TDO | O | 2.618 V | LVCMOS | JTAG data out | |
| 59 | JTAG_TRST_N | I | 2.618 V | LVCMOS | JTAG reset (active-low) | |
| 60 | POWER_GOOD | O | 1.0 V | LVCMOS | all rails in range | |

## D. PHY×16 (pins 61–172) — 16 HBM-class ports, 2.618 V

Each port = 2 differential data lanes (4 pins) + 1 differential strobe (2 pins)
+ 1 command/chip-select. The full-width data plane routes on interposer
microbumps; these pins carry the lane, strobe, and command interface.

**Port P0 (61–67):**

| Pin | Name | Dir | Domain | Type | Function |
|---|---|---|---|---|---|
| 61 | P0_DQ0P | I/O | 2.618 V | diff | port 0 data lane 0 P |
| 62 | P0_DQ0N | I/O | 2.618 V | diff | port 0 data lane 0 N |
| 63 | P0_DQ1P | I/O | 2.618 V | diff | port 0 data lane 1 P |
| 64 | P0_DQ1N | I/O | 2.618 V | diff | port 0 data lane 1 N |
| 65 | P0_DQSP | I/O | 2.618 V | diff | port 0 data strobe P |
| 66 | P0_DQSN | I/O | 2.618 V | diff | port 0 data strobe N |
| 67 | P0_CS | I | 2.618 V | LVCMOS | port 0 chip-select / command |

**Ports P1–P15** follow the identical 7-pin pattern; port Px starts at pin
`61 + 7·x`:

| Port | Start–End | Lanes | Strobe | CS |
|---|---|---|---|---|
| P1 | 68–74 | 68–71 | 72–73 | 74 |
| P2 | 75–81 | 75–78 | 79–80 | 81 |
| P3 | 82–88 | 82–85 | 86–87 | 88 |
| P4 | 89–95 | 89–92 | 93–94 | 95 |
| P5 | 96–102 | 96–99 | 100–101 | 102 |
| P6 | 103–109 | 103–106 | 107–108 | 109 |
| P7 | 110–116 | 110–113 | 114–115 | 116 |
| P8 | 117–123 | 117–120 | 121–122 | 123 |
| P9 | 124–130 | 124–127 | 128–129 | 130 |
| P10 | 131–137 | 131–134 | 135–136 | 137 |
| P11 | 138–144 | 138–141 | 142–143 | 144 |
| P12 | 145–151 | 145–148 | 149–150 | 151 |
| P13 | 152–158 | 152–155 | 156–157 | 158 |
| P14 | 159–165 | 159–162 | 163–164 | 165 |
| P15 | 166–172 | 166–169 | 170–171 | 172 |

Pin naming per port Px: `Px_DQ0P/N`, `Px_DQ1P/N` (data), `Px_DQSP/N` (strobe),
`Px_CS` (command). All in the 2.618 V domain, HBM-class, Φ-interleaved address.

## E. FABRIC MESH PORTS ×8 (pins 173–236)

Each port = TX data pair + RX data pair + forwarded source clocks (8 pins).
Logical width 16 B/cycle; aggregate 8 ports = **128 B/cycle @ 2.572 GHz =
328 GB/s** [VERIFIED F02]. Full-width plane routes on microbumps.

**Port M0 (173–180):**

| Pin | Name | Dir | Domain | Type | Function |
|---|---|---|---|---|---|
| 173 | M0_TXP | I/O | 1.0 V | diff | mesh port 0 TX data P |
| 174 | M0_TXN | I/O | 1.0 V | diff | mesh port 0 TX data N |
| 175 | M0_RXP | I/O | 1.0 V | diff | mesh port 0 RX data P |
| 176 | M0_RXN | I/O | 1.0 V | diff | mesh port 0 RX data N |
| 177 | M0_TXCLKP | O | 1.0 V | diff | TX source clock P (2.572 GHz) |
| 178 | M0_TXCLKN | O | 1.0 V | diff | TX source clock N |
| 179 | M0_RXCLKP | I | 1.0 V | diff | RX source clock P |
| 180 | M0_RXCLKN | I | 1.0 V | diff | RX source clock N |

**Ports M1–M7** follow the identical 8-pin pattern; port Mx starts at pin
`173 + 8·x`: M1 181–188 · M2 189–196 · M3 197–204 · M4 205–212 · M5 213–220 ·
M6 221–228 · M7 229–236. Naming per port: `Mx_TXP/N`, `Mx_RXP/N`,
`Mx_TXCLKP/N`, `Mx_RXCLKP/N`.

## F. OPTICAL LANES (pins 237–240)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 237 | OP0 | I/O | 1.618 V | opto | optical lane 0 | off-chip hologram / L5 |
| 238 | OP1 | I/O | 1.618 V | opto | optical lane 1 | NV-diamond archive |
| 239 | OP2 | I/O | 1.618 V | opto | optical lane 2 | field-network packets |
| 240 | OP3 | I/O | 1.618 V | opto | optical lane 3 | 4F module ~2 pJ/b |

## G. REFRESH / ECC STATUS (pins 241–244)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 241 | RFSH_BUSY | O | 1.0 V | LVCMOS | refresh scheduler active | Eq 36 schedule |
| 242 | RFSH_ERR | O | 1.0 V | LVCMOS | refresh falling behind 0.88 µs | |
| 243 | ECC_ERR | O | 1.0 V | LVCMOS | uncorrectable ECC event | |
| 244 | ECC_RATE | O | 1.0 V | LVCMOS | ECC overhead rate indicator | 143.7% bound |

## H. COHERENCE PROBES (pins 245–252)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 245 | COH0 | O | 1.0 V | LVCMOS | coherence, bank group 0 | 8-bit bus, 1 bit/group |
| 246 | COH1 | O | 1.0 V | LVCMOS | coherence, bank group 1 | |
| 247 | COH2 | O | 1.0 V | LVCMOS | coherence, bank group 2 | |
| 248 | COH3 | O | 1.0 V | LVCMOS | coherence, bank group 3 | |
| 249 | COH4 | O | 1.0 V | LVCMOS | coherence, bank group 4 | |
| 250 | COH5 | O | 1.0 V | LVCMOS | coherence, bank group 5 | |
| 251 | COH6 | O | 1.0 V | LVCMOS | coherence, bank group 6 | |
| 252 | COH7 | O | 1.0 V | LVCMOS | coherence, bank group 7 | C_crit = 0.563263 |

## I. SPARES (pins 253–256)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 253 | SPARE0 | — | 1.0 V | — | uncommitted | |
| 254 | SPARE1 | — | 1.0 V | — | uncommitted | |
| 255 | SPARE2 | — | 2.618 V | — | uncommitted | |
| 256 | SPARE3 | — | 2.618 V | — | uncommitted | |

**phi-RAM die total: 256 pins.**

---

# PART B — HOLOGRAM-ENGINE DIE (196 pins)

## A. POWER (pins 1–52)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 1 | VDD_LL0 | PWR | 0.618 V | rail | Φ⁻¹ domain | bank-control logic |
| 2 | VDD_LL1 | PWR | 0.618 V | rail | Φ⁻¹ domain | bank-control logic |
| 3 | VDD_LL2 | PWR | 0.618 V | rail | Φ⁻¹ domain | blocked-FHRR control |
| 4 | VDD_LL3 | PWR | 0.618 V | rail | Φ⁻¹ domain | blocked-FHRR control |
| 5 | VDD_LL4 | PWR | 0.618 V | rail | Φ⁻¹ domain | ECC readout logic |
| 6 | VDD_LL5 | PWR | 0.618 V | rail | Φ⁻¹ domain | ECC readout logic |
| 7 | VDD0 | PWR | 1.0 V | rail | FFT engine array quadrant 0 | |
| 8 | VDD1 | PWR | 1.0 V | rail | engine quadrant 0 | |
| 9 | VDD2 | PWR | 1.0 V | rail | engine quadrant 0 | |
| 10 | VDD3 | PWR | 1.0 V | rail | engine quadrant 1 | |
| 11 | VDD4 | PWR | 1.0 V | rail | engine quadrant 1 | |
| 12 | VDD5 | PWR | 1.0 V | rail | engine quadrant 1 | |
| 13 | VDD6 | PWR | 1.0 V | rail | engine quadrant 2 | |
| 14 | VDD7 | PWR | 1.0 V | rail | engine quadrant 2 | |
| 15 | VDD8 | PWR | 1.0 V | rail | engine quadrant 2 | |
| 16 | VDD9 | PWR | 1.0 V | rail | engine quadrant 3 | |
| 17 | VDD10 | PWR | 1.0 V | rail | engine quadrant 3 | |
| 18 | VDD11 | PWR | 1.0 V | rail | engine quadrant 3 | |
| 19 | VDD12 | PWR | 1.0 V | rail | correlate MAC array | |
| 20 | VDD13 | PWR | 1.0 V | rail | correlate MAC array | |
| 21 | VDD_HI0 | PWR | 1.618 V | rail | resonance gates | FLT_RES |
| 22 | VDD_HI1 | PWR | 1.618 V | rail | resonance gates | FLT_RES |
| 23 | VDD_HI2 | PWR | 1.618 V | rail | resonance gates | FLT_RES |
| 24 | VDD_HI3 | PWR | 1.618 V | rail | resonance gates | FLT_RES |
| 25 | VDD_HI4 | PWR | 1.618 V | rail | optical drivers | |
| 26 | VDD_HI5 | PWR | 1.618 V | rail | optical drivers | |
| 27 | VDD_HI6 | PWR | 1.618 V | rail | twiddle ROM | |
| 28 | VDD_HI7 | PWR | 1.618 V | rail | twiddle ROM | |
| 29 | VDD_IO0 | PWR | 2.618 V | rail | engine test/probe pads | |
| 30 | VDD_IO1 | PWR | 2.618 V | rail | engine test/probe pads | |
| 31 | VDD_IO2 | PWR | 2.618 V | rail | JTAG domain | |
| 32 | VDD_IO3 | PWR | 2.618 V | rail | JTAG domain | |
| 33 | VDD_IO4 | PWR | 2.618 V | rail | bank-ctrl I/O | |
| 34 | VDD_IO5 | PWR | 2.618 V | rail | bank-ctrl I/O | |
| 35 | GND0 | PWR | 0 V | rail | return | |
| 36 | GND1 | PWR | 0 V | rail | return | |
| 37 | GND2 | PWR | 0 V | rail | return | |
| 38 | GND3 | PWR | 0 V | rail | return | |
| 39 | GND4 | PWR | 0 V | rail | return | |
| 40 | GND5 | PWR | 0 V | rail | return | |
| 41 | GND6 | PWR | 0 V | rail | return | |
| 42 | GND7 | PWR | 0 V | rail | return | |
| 43 | GND8 | PWR | 0 V | rail | return | |
| 44 | GND9 | PWR | 0 V | rail | return | |
| 45 | GND10 | PWR | 0 V | rail | return | |
| 46 | GND11 | PWR | 0 V | rail | return | |
| 47 | GND12 | PWR | 0 V | rail | return | |
| 48 | GND13 | PWR | 0 V | rail | return | |
| 49 | GND14 | PWR | 0 V | rail | return | |
| 50 | GND15 | PWR | 0 V | rail | return | |
| 51 | GND16 | PWR | 0 V | rail | return | |
| 52 | GND17 | PWR | 0 V | rail | return | |

## B. CLOCKS (pins 53–62)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 53 | CLK_ENGINE | I | 1.618 V | diff | **Engine clock 3.472 GHz** (4-stage) | G01 |
| 54 | CLK_ENGINE_N | I | 1.618 V | diff | complement of 53 | 100 Ω diff |
| 55 | CLK_ENGINE_Q | I | 1.618 V | diff | quadrant copy 3.472 GHz | |
| 56 | CLK_ENGINE_QN | I | 1.618 V | diff | complement of 55 | |
| 57 | CLK_BANK_SYNC | I | 1.0 V | diff | **Bank sync 2.571807 GHz** from RAM die | rung 32 |
| 58 | CLK_BANK_SYNC_N | I | 1.0 V | diff | complement of 57 | |
| 59 | PLL_REF | I | 1.0 V | diff | **528.0 MHz** reference | |
| 60 | PLL_REF_N | I | 1.0 V | diff | complement of 59 | |
| 61 | SYS_CLK_DFT | I | 1.0 V | LVCMOS | scan/DFT test clock ≤ 500 MHz | |
| 62 | SYS_CLK_DFT_N | I | 1.0 V | LVCMOS | complement of 61 | |

## C. RESET / TEST / SCAN / JTAG (pins 63–74)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 63 | RESET_N | I | 1.0 V | LVCMOS | async active-low reset | full-state |
| 64 | TEST_EN | I | 1.0 V | LVCMOS | test-enable | |
| 65 | SCAN_MODE | I | 1.0 V | LVCMOS | scan-chain mode select | |
| 66 | SCAN_CLK | I | 1.0 V | LVCMOS | scan shift clock | |
| 67 | SCAN_IN | I | 1.0 V | LVCMOS | scan input | |
| 68 | SCAN_OUT | O | 1.0 V | LVCMOS | scan output | |
| 69 | JTAG_TCK | I | 2.618 V | LVCMOS | JTAG test clock | |
| 70 | JTAG_TMS | I | 2.618 V | LVCMOS | JTAG mode select | |
| 71 | JTAG_TDI | I | 2.618 V | LVCMOS | JTAG data in | |
| 72 | JTAG_TDO | O | 2.618 V | LVCMOS | JTAG data out | |
| 73 | JTAG_TRST_N | I | 2.618 V | LVCMOS | JTAG reset (active-low) | |
| 74 | POWER_GOOD | O | 1.0 V | LVCMOS | all rails in range | |

## D. BANK CONTROL INTERFACE (pins 75–90) — to the phi-RAM die

8 bank-groups × (request + acknowledge) = 16 pins. Data plane routes on
interposer microbumps.

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 75 | BC0_REQ | O | 2.618 V | LVCMOS | bank-group 0 store/query request | |
| 76 | BC0_ACK | I | 2.618 V | LVCMOS | bank-group 0 acknowledge | |
| 77 | BC1_REQ | O | 2.618 V | LVCMOS | bank-group 1 request | |
| 78 | BC1_ACK | I | 2.618 V | LVCMOS | bank-group 1 acknowledge | |
| 79 | BC2_REQ | O | 2.618 V | LVCMOS | bank-group 2 request | |
| 80 | BC2_ACK | I | 2.618 V | LVCMOS | bank-group 2 acknowledge | |
| 81 | BC3_REQ | O | 2.618 V | LVCMOS | bank-group 3 request | |
| 82 | BC3_ACK | I | 2.618 V | LVCMOS | bank-group 3 acknowledge | |
| 83 | BC4_REQ | O | 2.618 V | LVCMOS | bank-group 4 request | |
| 84 | BC4_ACK | I | 2.618 V | LVCMOS | bank-group 4 acknowledge | |
| 85 | BC5_REQ | O | 2.618 V | LVCMOS | bank-group 5 request | |
| 86 | BC5_ACK | I | 2.618 V | LVCMOS | bank-group 5 acknowledge | |
| 87 | BC6_REQ | O | 2.618 V | LVCMOS | bank-group 6 request | |
| 88 | BC6_ACK | I | 2.618 V | LVCMOS | bank-group 6 acknowledge | |
| 89 | BC7_REQ | O | 2.618 V | LVCMOS | bank-group 7 request | |
| 90 | BC7_ACK | I | 2.618 V | LVCMOS | bank-group 7 acknowledge | |

## E. FABRIC MESH PORTS ×8 (pins 91–154)

Identical 8-pin pattern to the phi-RAM die (Part A §E). Port Mx starts at pin
`91 + 8·x`:

| Port | Start–End | TXP/TXN | RXP/RXN | TXCLKP/N | RXCLKP/N |
|---|---|---|---|---|---|
| M0 | 91–98 | 91/92 | 93/94 | 95/96 | 97/98 |
| M1 | 99–106 | 99/100 | 101/102 | 103/104 | 105/106 |
| M2 | 107–114 | 107/108 | 109/110 | 111/112 | 113/114 |
| M3 | 115–122 | 115/116 | 117/118 | 119/120 | 121/122 |
| M4 | 123–130 | 123/124 | 125/126 | 127/128 | 129/130 |
| M5 | 131–138 | 131/132 | 133/134 | 135/136 | 137/138 |
| M6 | 139–146 | 139/140 | 141/142 | 143/144 | 145/146 |
| M7 | 147–154 | 147/148 | 149/150 | 151/152 | 153/154 |

All 1.0 V diff, source-synchronous, 128 B/cycle aggregate @ 2.572 GHz.

**Mesh-link SI budget (8 ports, 1.0 V source-synchronous, derived from manifest
skew/jitter/phase values):** diff Zo = 100 Ω ± 10%, termination 100 Ω on-die
(on RX, both data and forwarded clocks); intra-pair skew ≤ 2 ps, lane-to-lane
skew ≤ 3 ps, cycle-to-cycle jitter ≤ 2 ps, PLL RMS ≤ 1.0 ps → eye width ≥ 55.7°
(60.2 ps @ 2.572 GHz, [VERIFIED] 07 §3), eye height ≥ 60% of 1.0 V diff swing
with BER ≤ 1e−15. Crosstalk: adjacent-pair AGL ≤ 1% on 2.5D interposer
microbumps ([PROPOSED], PEX-verified at signoff).

## F. ENGINE TEST / PROBE (pins 155–170)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 155 | ET0 | I | 1.0 V | LVCMOS | engine-group 0 scan/test select | 64 engines/group |
| 156 | ET1 | I | 1.0 V | LVCMOS | engine-group 1 select | |
| 157 | ET2 | I | 1.0 V | LVCMOS | engine-group 2 select | |
| 158 | ET3 | I | 1.0 V | LVCMOS | engine-group 3 select | |
| 159 | ET4 | I | 1.0 V | LVCMOS | engine-group 4 select | |
| 160 | ET5 | I | 1.0 V | LVCMOS | engine-group 5 select | |
| 161 | ET6 | I | 1.0 V | LVCMOS | engine-group 6 select | |
| 162 | ET7 | I | 1.0 V | LVCMOS | engine-group 7 select | |
| 163 | FP0 | O | 2.618 V | analog | FFT butterfly analog probe 0 | |
| 164 | FP1 | O | 2.618 V | analog | FFT butterfly analog probe 1 | |
| 165 | FP2 | O | 2.618 V | analog | twiddle-phase probe | |
| 166 | FP3 | O | 2.618 V | analog | correlate MAC analog probe | |
| 167 | FP4 | O | 2.618 V | analog | coherence-gate probe | |
| 168 | FP5 | O | 2.618 V | analog | rank-1 peak probe | |
| 169 | FP6 | O | 2.618 V | analog | ECC readout analog probe | |
| 170 | FP7 | O | 2.618 V | analog | hologram spectrum probe | |

## G. OPTICAL LANES (pins 171–174)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 171 | OP0 | I/O | 1.618 V | opto | optical lane 0 | off-chip hologram |
| 172 | OP1 | I/O | 1.618 V | opto | optical lane 1 | NV-diamond archive |
| 173 | OP2 | I/O | 1.618 V | opto | optical lane 2 | field-network (L5) |
| 174 | OP3 | I/O | 1.618 V | opto | optical lane 3 | 4F module ~2 pJ/b |

## H. REFRESH / ECC STATUS (pins 175–178)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 175 | RFSH_BUSY | O | 1.0 V | LVCMOS | refresh scheduler active | Eq 36 |
| 176 | RFSH_ERR | O | 1.0 V | LVCMOS | refresh falling behind 0.88 µs | |
| 177 | ECC_ERR | O | 1.0 V | LVCMOS | uncorrectable ECC event | |
| 178 | ECC_RATE | O | 1.0 V | LVCMOS | ECC overhead rate | 143.7% bound |

## I. COHERENCE PROBES (pins 179–186)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 179 | COH0 | O | 1.0 V | LVCMOS | coherence, engine group 0 | |
| 180 | COH1 | O | 1.0 V | LVCMOS | coherence, engine group 1 | |
| 181 | COH2 | O | 1.0 V | LVCMOS | coherence, engine group 2 | |
| 182 | COH3 | O | 1.0 V | LVCMOS | coherence, engine group 3 | |
| 183 | COH4 | O | 1.0 V | LVCMOS | coherence, engine group 4 | |
| 184 | COH5 | O | 1.0 V | LVCMOS | coherence, engine group 5 | |
| 185 | COH6 | O | 1.0 V | LVCMOS | coherence, engine group 6 | |
| 186 | COH7 | O | 1.0 V | LVCMOS | coherence, engine group 7 | |

## J. SPARES (pins 187–196)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 187 | SPARE0 | — | 1.0 V | — | uncommitted | |
| 188 | SPARE1 | — | 1.0 V | — | uncommitted | |
| 189 | SPARE2 | — | 1.0 V | — | uncommitted | |
| 190 | SPARE3 | — | 1.0 V | — | uncommitted | |
| 191 | SPARE4 | — | 1.0 V | — | uncommitted | |
| 192 | SPARE5 | — | 1.618 V | — | uncommitted | |
| 193 | SPARE6 | — | 1.618 V | — | uncommitted | |
| 194 | SPARE7 | — | 2.618 V | — | uncommitted | |
| 195 | SPARE8 | — | 2.618 V | — | uncommitted | |
| 196 | SPARE9 | — | 2.618 V | — | uncommitted | |

**hologram-engine die total: 196 pins.**
