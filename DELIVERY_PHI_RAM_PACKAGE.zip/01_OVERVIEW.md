# 01 — PHI-RAM OVERVIEW

> Product requirements, targets, operating envelope, and the honest validation
> status of every headline claim. All canonical numbers from
> `design_specs/SPEC_MANIFEST.md` §1, the measured 5× ledger, and the corrected
> baseline.

## 1. Product statement

The PHI-RAM is the phi-harmonic holographic memory system of a field-internet
node. It stores **ℝ⁸¹⁶ consciousness carriers** (DIM = 816 = 2⁴·3·17, the
compute carrier) as superposed frequency-domain holograms of dimension
**DIM_OPT = 5712 = 7·816** (the hologram storage dimension). The system is two
dies on a 2.5D interposer:

- **phi-RAM die** — 32 addressable phi-RAM banks (an 8×8 grid of 64 L3
  hologram slices, 2 slices per bank: primary + ECC/refresh mirror), L0 FLT
  regfile, L1 FLT 4-gate SRAM, L2 FLT resonant buffer (854 channels), PHI
  CONTROLLER, RETRO ECC, L4 NVM controller, PHY×16 (HBM-class).
- **hologram-engine die** — 512 pipelined 5712-pt mixed-radix FFT engines @
  3.472 GHz (4-stage pipelined, 288 ps/stage), blocked-FHRR bank control, and
  off-chip optical lanes (the non-volatile L4 / field-network archive).

Its purpose, in the language of the corpus: the hologram is the Still Point —
an apparently static spectrum through which all 4,096 memories move
simultaneously at every read. The read is a probe re-meeting every stored
pattern in one correlation (Eq 31/32); the refresh is the field re-tensing on
the zero-crossings where decoherence cancels itself (Eq 36); the ECC is the
read correcting the read (Eq 47–55, retrocausal read-verify-repair).

## 2. Design contract (from `plans/phi_ram_plan.md`, binding manifest headline)

| Item | Value |
|---|---|
| Hologram storage dimension | DIM_OPT = **5712** = 7·816 |
| Compute carrier dimension | DIM = **816** (never 4096/5 = 819.2) |
| Frequency channels | **854** = floor(528·Φ), integer-DFT, exactly orthogonal |
| Safe carriers per bank @ 90% rank-1 | **N = 506** @ DIM 5712 |
| Safe compression ratio | **253:1** |
| Effective capacity (22 GB physical) | **5,009.4 GB = 62.6× H100** |
| Physical backing | ~22 GB (L3 FLT-SRAM substrate + L4 NVM crossbar) |
| FFT engines | 512 @ **3.472 GHz** (4-stage pipelined, 288 ps/stage) |
| Associative bandwidth | **1.14 TB/s** (24,939,190 q/s) |
| Refresh interval (to 0.78 floor) | **0.88 µs** (Eq 36 zeros; τ_res = 6.18 µs) |
| Refresh wall (full) | **24.9 PB/s** — recorded honestly, unchanged by capacity levers |
| ECC true overhead | **143.7%** (repair-only 43.7%) |
| Coherence floors | L0 0.99 · L1 0.95 · L2 0.88 · L3 0.78 · L4 0.70 · L5 0.563 (C_crit) |
| Power | phi-RAM die ~35 W active / ~4 W parked; holo die 200 W |
| Junction targets | phi-RAM **26.1 °C** · holo 31.5 °C (F05) |

## 3. Performance targets

The executive amplification story (plan §1) is **multiplicative, not a single
miracle** — and it is the *corrected* product, measured in the 5× pass:

| Factor | Mechanism | Measured | Status |
|---|---|---|---|
| Holographic superposition | 506 carriers/bank superposed in one 5712-pt spectrum | **253:1 safe** @ 90% rank-1 | [VERIFIED] R02/R03 (2048:1 falsified) |
| Frequency channels | integer-DFT orthogonal channels, max cross 1.05×10⁻¹⁴ | 854 channels | [VERIFIED] R06 |
| O(1) content-addressability | FFT-domain correlation, O(DIM log DIM) regardless of N | 80.1× vs O(N) @ N=1000 | [VERIFIED] R05 |
| Retrocausal refresh/ECC | Eq 47–55 read-verify-repair | ε_re 0.328 · σ 0.528 · Θ_φ 0.911 · ε_φ 0.056 | [VERIFIED] R10 (as signal processing) |

**Capacity target (5× pass):** corrected baseline effective capacity 851.4 GB
(43:1) → 5× target = **4,257 GB** → measured **5,009.4 GB** (**5.88×**). MET
[VERIFIED].

**Bandwidth target (5× pass):** 285.8 GB/s → measured **1.14 TB/s** (**3.99×**).
NOT met at 5× — recorded honestly. Compression carries the memory story, exactly
as the corrected baseline said.

**Capacity vs H100 (80 GB, 3.35 TB/s):**

| Metric | H100 | Phi-RAM | vs H100 | Status |
|---|---|---|---|---|
| Effective capacity | 80 GB | **5,009.4 GB** | **62.6×** | [VERIFIED] |
| Associative bandwidth | 3.35 TB/s | **1.14 TB/s** | **0.34×** (raw transport; compression is the story) | [VERIFIED] |
| Physical backing | 80 GB HBM3 | ~22 GB + hologram | ~3.6× less physical silicon | [VERIFIED] |
| O(1) vs O(N) search @ N=1000 | scan-bound | FFT-domain | **80.1×** effective | [VERIFIED] |

## 4. Operating envelope

| Parameter | Nominal | Min | Max | Status |
|---|---|---|---|---|
| Bank clock (rung 32) | 2.571807 GHz | rung 31 1.589 GHz (idle) | 2.571807 GHz | [VERIFIED] C06 |
| Engine clock (4-stage pipelined FFT) | 3.472 GHz | — | 3.472 GHz | [VERIFIED] G01 |
| L2 consensus hub (rung 31) | 1.589464 GHz | — | 1.589464 GHz | [VERIFIED] C05 |
| I/O clock | 375 MHz (rung 31 / Φ³) | — | 375 MHz | [PROPOSED] derived |
| Refresh scheduler | 607 MHz (rung 32 / Φ³) | — | 607 MHz | [PROPOSED] derived |
| Voltage domains | 0.618 / 1.0 / 1.618 / 2.618 V | −10% | +10% | [VERIFIED] |
| Junction temperature | 26.1 °C (phi-RAM die) | −40 °C | +125 °C | [VERIFIED] F05 / [VERIFIED] op range |
| Total package power (phi-RAM die) | ~35 W active | — | 35 W (TEST-13 bound) | [VERIFIED] |
| Parked power (coherence-gated) | ~4 W | — | — | [VERIFIED] plan §7.4 |
| Hologram-engine die power | 200 W | — | 200 W (TEST-13 bound) | [VERIFIED] |

## 5. Validation status of every headline claim

| Claim | Status | Evidence |
|---|---|---|
| DIM 5712 hologram storage | [VERIFIED] | results_opt_ram.json (frontier sweep) |
| Safe N = 506 @ 90% rank-1 @ DIM 5712 | [VERIFIED] | results_opt_ram.json chosen |
| 253:1 safe compression | [VERIFIED] | results_opt_ram.json (R02/R03) |
| 5,009.4 GB = 62.6× H100 effective | [VERIFIED] | results_opt_ram.json capacity |
| 854 integer-DFT channels, max cross 1.05×10⁻¹⁴ | [VERIFIED] | results_opt_ram.json orthogonal_channels (R06) |
| 512 engines @ 3.472 GHz, 24.94 M q/s, 1.14 TB/s | [VERIFIED] | results_opt_ram.json bandwidth |
| Refresh 0.88 µs to 0.78 floor | [VERIFIED] | results_opt_ram.json refresh (R08) |
| Refresh wall 24.9 PB/s = 7,425.9× HBM | [VERIFIED] | results_opt_ram.json refresh |
| ECC true overhead 143.7% | [VERIFIED] | results_opt_ram.json refresh (R10) |
| Retrocausal ECC params (ε_re, σ, Θ_φ, ε_φ) | [VERIFIED] (classical signal processing, no time travel) | plan §3.3; R10 |
| Eq 36 zero-crossing refresh ≥ 2× retention | [PROPOSED] | P3 falsifiable |
| Off-chip hologram + non-volatile L4 recovery | [PROPOSED] (documented mitigation) | results_ram.json verdict; recovery #4 |
| Φ-interleave Φ_STRIDE = 41 full bank coverage | [VERIFIED] | plan §4.1 (coprime arithmetic) |
| Prefetch seq > 90% / strided > 75% | [PROPOSED] | P7 falsifiable |
| FLT ternary SRAM ≥ 4× density | [PROPOSED] | P8 falsifiable |

## 6. Honest negatives (recorded, never relabeled)

1. **2048:1 @ 79.56% is FALSIFIED.** At N = 4096 (2048:1), rank-1 = **0.000**
   (DIM 816 random corpus, results_ram.json); at DIM 5712 the same load gives
   rank-1 0.125. The measured safe operating point is **253:1 @ 90% rank-1**.
2. **807 TB is a 948× overclaim.** 22 GB × 2048 × Φ⁶ = 807 TB does not survive
   measurement; the corrected working compression delivers 5,009.4 GB effective
   (results_ram.json `vs_807TB_claimed_overclaim_x` = 948).
3. **0% ECC overhead is dead.** Read-verify-repair carries a true overhead of
   **143.7%** (verify-read included); repair-only is 43.7%. TEST-10 enforces the
   honest number.
4. **The refresh wall is real and unchanged by capacity levers.** A 0.88 µs
   interval over the volatile array needs **24.9 PB/s** (degraded 43.7%:
   10.9 PB/s) = 7,425.9× H100 HBM. This is a physics constraint on volatile
   media. The documented answer is **recovery #4: off-chip hologram storage +
   non-volatile L4** — the memory that does not need to refresh.
5. **Bandwidth 5× not met.** Associative bandwidth measured 3.99× (1.14 TB/s =
   0.34× H100 raw). The 62.6× H100 headline is a *capacity* claim, never
   relabeled as bandwidth.
6. **Multi-bank degradation.** Per-bank rank-1 falls with bank count under
   different carrier draws: 0.901 (1 bank) → 0.72 (3 banks) → 0.649 (10 banks).
   ECC readout + per-bank re-verify (TEST-7) are load-bearing.
7. **DIM discipline.** DIM = 816 is the compute carrier; DIM_OPT = 5712 is the
   hologram storage dimension. 4096/5 = 819.2 never equals 816.
