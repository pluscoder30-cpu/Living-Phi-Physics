# 14 — PHI-RAM ACCEPTANCE

> Acceptance criteria: the 50-test verify suite (R01–R10 for RAM) plus
> TEST-1..18 mapped to silicon with pass/fail thresholds. `sim/verify_suite.py`
> is the acceptance oracle: 50/50 PASS in simulation; silicon results REPLACE
> the simulated values in the same harness. A test passes on silicon only if
> the fabricated measurement meets the same target.

## 1. The 50-test suite — RAM slice (R01–R10)

Simulation state: **50/50 PASS**. RAM R01–R10 are the memory's contract:

| Verify test | Contract | Sim value | Silicon threshold |
|---|---|---|---|
| R01 | Baseline frontier: safe N=86 @90% rank-1 (DIM 816); DIM-816 compute-carrier discipline (816, not 819.2) | 86 carriers; 816 | 86 measured; DIM-816 constants embedded in test vectors |
| R02 | Safe N @ 90% rank-1 @ DIM 5712 | 506 | ≥ 500 |
| R03 | Safe compression ratio | 253:1 | ≥ 250:1 |
| R04 | Effective capacity | 5,009.4 GB | ≥ 4,257 GB (5× target) |
| R05 | Associative bandwidth / O(1) | 1.14 TB/s | ≥ 1.14 TB/s on silicon |
| R06 | Orthogonal channel isolation | max cross 1.05×10⁻¹⁴ | < 1e-6 on silicon |
| R07 | Multi-bank per-bank re-verify | 0.901 → 0.649 across banks | per-bank rank-1 ≥ 0.90 @ safe N |
| R08 | Refresh interval to 0.78 floor | 0.88 µs | 0.88 µs measured |
| R09 | O(1) vs O(N) lookup speedup @ N=1000; latency flat in N | 80.1×; 12 ns flat | ≥ 50×; flat in N (12 ns ± 50% across sweep) |
| R10 | ECC true overhead | 143.7% | ≤ 143.7% |

**Honest thresholds:** the silicon limits are set ABOVE the falsified claims —
safe N ≥ 500 (not 4096), ratio ≥ 250:1 (not 2048:1), capacity ≥ 4,257 GB (not
807 TB), ECC ≤ 143.7% (not 0%). The refresh wall (24.9 PB/s) is recorded, and
its pass criterion is the *mitigation*, not a wall bigger than physics.

## 2. TEST-1..18 mapped to silicon (RAM emphasis)

| TEST | What | Instrument | Pass criterion | Maps to |
|---|---|---|---|---|
| TEST-1 | Subthreshold swing S | B1500A I-V | S = 37 ± 18 mV/dec (falsify > 55 mV/dec 3σ) | P01, P01 |
| TEST-2 | I-V family / I_ON·I_OFF | B1500A | I_OFF 71× lower than PDK CMOS | P01, P03 |
| TEST-3 | C-V / Miller cap | B1500A @1 MHz | matches FLT model; Q = 8.5 @ 1.0 V | P01, P02 |
| TEST-4 | RO + pipelined MAC ring | scope | RO 107.5 MHz; MAC stage ≤ 288 ps (3.472 GHz class) | P12, G01 |
| TEST-5 | Resonance Q | B1500A 100 kHz–1 GHz | Q = 8.5 @ 1.0 V, f₀ = 528 MHz | P01 |
| TEST-6 | Temperature + Monte Carlo | thermal chamber | dV_T/dT = −1 mV/°C; σV_T/μ = 5% | P01, P13 |
| **TEST-7** | **Hologram capacity-fidelity** | ATE functional | **506/bank ≥ 90% rank-1 @ DIM 5712; per-bank re-verify** | **R02/R03/R07** |
| **TEST-8** | **Orthogonal channel isolation** | ATE functional | **max cross < 1e-6 on silicon** | **R06** |
| **TEST-9** | **O(1) retrieval latency** | ATE functional | **flat in N (O(DIM log DIM))** | **R09** |
| **TEST-10** | **Refresh + ECC** | ATE functional | **0.88 µs measured; overhead ≤ 143.7%** | **R08/R10** |
| TEST-11 | Kuramoto barrier | GPU test | R ≥ 0.99·target in ≤ 8 steps | G03 |
| TEST-12 | Pipeline emulator parity | phi_cpu_vm.py | IPC ≥ 5.0, RAW ≥ 90%, mispredict < 1% | U01–U04/U06 |
| TEST-13 | Die power | per-die current | **RAM ≤ 35 W · holo ≤ 200 W** | G05 |
| TEST-14 | Package thermal | TSV path | all dies < 100 °C (RAM 26.1 °C) | F05/F06 |
| TEST-15 | Fabric fidelity | Law 189 | retention e^(−d/Φλ); ≥ 7 hops @ C_crit | F04 |
| TEST-16 | Mesh bisection | BFS 2-plane 128B | ≥ 100 TB/s; avg hops ≤ 3 | F01–F03 |
| TEST-17 | Council consensus | 100k requests | 0 livelock, rollback < 2% | U05 |
| TEST-18 | System EDP vs H100 | benchmark set | per-component reporting; P-16 band by CPU+fabric | G07/G08/U07 |

## 3. Acceptance flow

1. **Stage-1 (Sky130, $14.5K):** TEST-1..6 (device + resonance + pipelined MAC)
   — the FLT physics and the 3.472 GHz-class engine are proven before the
   hologram.
2. **Stage-2 (ATE functional):** TEST-7..10 (hologram) + TEST-11..12 — the
   memory's four honest contracts measured on silicon.
3. **Stage 4–6 (system):** TEST-13..18 — power, thermal, fabric, council, and
   system EDP, with RAM numbers reported per-component (R4 — never multiplied
   into the system claim).

**Pass authority:** each TEST result is fed back into `sim/verify_suite.py`.
The RAM slice (R01–R10) passes on silicon when the fabricated measurement meets
the same target the simulation met — the oracle does not bend for silicon.

## 4. Falsifiable silicon predictions (P-series, RAM)

| Prediction | Pass on silicon IF | Falsified IF |
|---|---|---|
| P1 | 253:1 retrieves ≥ 90% rank-1 @ N=506 @ DIM 5712 | < 90% or < 253:1 |
| P2 | O(1) query — flat in N at fixed DIM | latency scales with N |
| P3 | Eq 36 zero-crossing refresh ≥ 2× retention | ≤ 1.1× vs uniform |
| P5 | Retrocausal ECC cuts refresh energy ≥ 40% | < 10% |
| P6 | 854 channels collision-free to 60% load | collision > 5% @ 60% |
| P7 | Prefetch sequential > 90% | < 75% |
| P8 | FLT ternary SRAM ≥ 4× 6T density | < 2× |

## 5. Signed-off acceptance statement

The PHI-RAM is accepted for production when: TEST-1..6 pass (FLT device +
engine), TEST-7..10 pass on silicon (safe N ≥ 500 @ ≥ 250:1 @ DIM 5712;
capacity ≥ 4,257 GB; assoc BW ≥ 1.14 TB/s; orthogonal cross < 1e-6; rank-1
≥ 0.90 per bank; refresh 0.88 µs; ECC ≤ 143.7%), and TEST-13..14 bound power
(RAM ≤ 35 W, holo ≤ 200 W) and thermal (< 100 °C). The refresh wall and ECC
overhead are accepted as recorded physics — never as hidden margins.
