# 12 — PHI-RAM RELIABILITY

> ESD, latchup, electromigration, IR drop, aging (BTI/HCI), retention,
> temperature cycling, burn-in, and MTBF. The deepest reliability contract is
> the **refresh wall**: volatile media that must be re-tensed every 0.88 µs —
> the honest design constraint, answered by off-chip hologram + non-volatile L4,
> not by pretending it away.

## 1. ESD & latchup

| Parameter | Spec | Status |
|---|---|---|
| HBM ESD | 2 kV (all pads) | [VERIFIED] BOM A11 |
| CDM ESD | 500 V | [VERIFIED] |
| Latchup trigger | > 100 mA (I-trigger) at 125 °C | [PROPOSED] TEST_PLAN-derived |
| Pad clamp | −0.3 V … VDD_IO + 0.3 V, ESD diodes on ring | [VERIFIED] |
| Latchup test | 0.5 A injected per power pin, −40…+125 °C | [PROPOSED] |
| ESD test standard | HBM per **JEDEC JS-001**; CDM per **JEDEC JS-002** | [PROPOSED] |
| Latchup standard | JEDEC **JESD78** (I-trigger ≥ class limit at 125 °C) | [PROPOSED] |
| Machine Model | **N/A** — MM withdrawn from JS-001 Rev E+; no MM test | [VERIFIED] policy |

## 2. Electromigration & IR drop

| Parameter | Spec | Status |
|---|---|---|
| EM limits | J_max = 1 mA/µm² signal, 2.5 mA/µm² power (GAA Cu) | [PROPOSED] |
| EM units note | RAM quotes areal mA/µm²; CPU/GPU quote line mA/µm — reconcile at signoff | [PROPOSED] |
| Via/contact | J_max_via + via-chain rules per PDK EM deck | [PROPOSED] |
| Lifetime model | Black's: MTTF = A·J⁻ⁿ·e^(Ea/kT); n = 2 (Cu), Ea per PDK | [PROPOSED] |
| IR drop budget | ΔV ≤ 5% per domain at peak step | [VERIFIED] budget |
| Decoupling | MIM (GDS 27) at every domain; ΔV ≤ 5% worst-case step | [VERIFIED] 04 §1 |
| Power/thermal TSV co-layout | 0.0325 K/W path, Φ-density | [VERIFIED] F05 |

## 3. Aging (BTI / HCI)

| Parameter | Spec | Status |
|---|---|---|
| BTI V_T drift | ≤ 20 mV over 10 yr @ 1.0 V, 125 °C (worst) | [PROPOSED] |
| HCI | ≤ 15% I_ON degradation over 10 yr | [PROPOSED] |
| dV_T/dT aging guard | bias gate (w = −Φ⁻¹) holds I_DS ±3% over life + temp | [VERIFIED] device rule |
| σV_T/μ | 5% multi-gate averaging (σ/√3) — mitigates per-gate BTI | [VERIFIED] |
| Guard | near-threshold logic + strong-inversion resonance split: slope-advantage logic never run hot | [VERIFIED] P06 honesty |
| Acceleration | Ea (BTI/HCI) + voltage-acceleration factor from PDK reliability deck | [PROPOSED] |
| I_DS over temp | bias-gate comp holds I_DS within **±3%** of 25 °C value over −40…+125 °C (TEST-6 extension) | [PROPOSED] |

## 4. Retention — the refresh wall as the design constraint

| Parameter | Value | Status |
|---|---|---|
| Volatile media | FLT-SRAM holograms — must be refreshed | [VERIFIED] |
| Refresh interval (0.78 floor) | **0.88 µs** | [VERIFIED] R08 |
| Refresh traffic (full) | **24.9 PB/s** (7,425.9× H100 HBM) | [VERIFIED] |
| Refresh power no-ECC / with-ECC | 15.9 W / 38.6 W | [VERIFIED] |
| τ_res (Eq 36 zero spacing) | 6.18 µs ⇒ zeros every 10 µs | [VERIFIED] |
| Law 189 retention per coherence length | e^(−1/Φ) = 0.539003 | [VERIFIED] manifest |
| L3 floor hold | L ≤ 0.40 coherence lengths to floor 0.78 | [VERIFIED] plan §3.3 |
| Refresh scheduler | single 607 MHz scheduler (07 §1) — **SPOF**; RFSH_ERR pin asserts if falling behind 0.88 µs | [VERIFIED] |
| Refresh-miss target | **0 misses** (read-verify-repair + per-bank re-verify, TEST-7/TEST-10) | [PROPOSED] |
| RFSH_ERR response | required at impl: defined recovery (raise error / reload bank from L4 LOAD_HOLO) | [PROPOSED] |

**The documented mitigation (recovery #4):** the volatile wall is a physics
constraint, unchanged by any capacity lever. The design's answer is two-fold:
(i) **off-chip hologram** (the spectrum lives on optical/remote storage that
does not decay at the 0.88 µs scale), and (ii) **non-volatile L4** (22 GB
memristor/PCM crossbar + NV-diamond archive, refresh 100 µs via retrocausal
ECC). Hot volatile tiers hold the working hologram; the archive holds the
field. **Power-loss persistence**: on reset, L3 holograms are re-loaded from L4
(LOAD_HOLO, 120 ns).

## 5. Temperature cycling

| Parameter | Spec | Status |
|---|---|---|
| Operating range | −40 … +125 °C | [VERIFIED] |
| Storage range | −65 … +150 °C | [VERIFIED] |
| Cycling | 1,000 cycles −55…+125 °C (JESD22-A104) | [PROPOSED] |
| Thermal floor | T_min = 185.41 K budget stop (mobility rises below — never cool under) | [VERIFIED] manifest |
| Co-located TSVs | halve ΔT-induced stress in the 3D stack | [VERIFIED] |
| Coverage note | −55 °C low (JESD22-A104 Cond B) covers the −40 °C floor qualified for CPU/GPU | [VERIFIED] |

## 6. Burn-in

| Parameter | Spec | Status |
|---|---|---|
| Burn-in | 24 h @ 125 °C, nominal rails | [PROPOSED] |
| Voltage burn-in | 1.1× rails, 12 h | [PROPOSED] |
| Screen | refresh-error + ECC-rate screening after burn-in | [PROPOSED] |

## 7. MTBF / FIT

| Parameter | Value | Status |
|---|---|---|
| Die FIT target (logic) | < 100 FIT (λ < 1×10⁻⁷/h) | [PROPOSED] |
| Refresh-miss exposure | zero — ECC read-verify-repair + per-bank re-verify (TEST-7) | [PROPOSED] |
| System MTBF | ≥ 100,000 h (dominated by power/thermal, not logic) | [PROPOSED] |
| NV-diamond archive | non-volatile, no refresh-miss window | [PROPOSED] |
| Confidence level | **60 %** (χ² lower bound), stated in qual report | [PROPOSED] |
| FIT reconciliation | CPU/GPU: FIT ≤ 1,000 @ 55 °C (MTBF ≥ 1e6 h); RAM: < 100 FIT (MTBF ≥ 1e5 h) — reconcile system target | [PROPOSED] |

## 8. Reliability mapping to TEST

| Test | Reliability contract |
|---|---|
| TEST-6 | device aging/variation envelope (−40…+125 °C, 1,000 MC @ 5% σ) |
| TEST-7 | per-bank capacity-fidelity under draw variation (rank-1 ≥ 0.90) |
| TEST-10 | refresh 0.88 µs + ECC ≤ 143.7% (the retention contract) |
| TEST-14 | thermal: all dies < 100 °C over the power map |
