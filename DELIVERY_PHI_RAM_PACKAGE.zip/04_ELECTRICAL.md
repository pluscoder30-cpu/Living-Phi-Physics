# 04 — PHI-RAM ELECTRICAL

> Power domains, per-block power, the honest refresh-power record, IO levels,
> operating conditions, and absolute maximum ratings. The field's power is
> delivered in Φ-ratioed domains and gated by coherence: the memory only burns
> what it is attending to.

## 1. Power domains (Φ-ratioed)

| Domain | Voltage | Serves | Supply |
|---|---|---|---|
| CORE (VDD_LL) | **0.618 V** (Φ⁻¹) | L0/L1 logic, controller state, RETRO ECC near-threshold logic, idle banks | Φ-scaled switched-cap regulator |
| MID (VDD) | **1.0 V** | bank arrays, L2 resonant buffer, coherence gates, mesh routers | Φ-scaled switched-cap regulator |
| PERIPH (VDD_HI) | **1.618 V** (Φ) | resonance gates (FLT_RES), clock tree, FFT engine control, optical drivers | Φ-scaled switched-cap regulator |
| HIGH (VDD_IO) | **2.618 V** (Φ²) | PHY×16, pad ring, phase detectors, analog FLT / hologram cell | rail input |

Regulators: switched-capacitor with Φ-ratioed capacitor arrays (C_k = C₀·Φ^k);
energy cap per unit E ≤ 1.618·E₀ (Law 020). Decoupling: MIM caps at every
domain (GDS 27, 08_PHYSICAL §5) sized so ΔV ≤ 5% on worst-case step.

**Decoupling (per rail; on-die MIM + on-package ceramic, Φ-ratioed C_k = C₀·Φ^k
per BOM C7):**

| Rail | On-die MIM | On-package ceramic | Placement |
|---|---|---|---|
| CORE VDD_LL 0.618 V | 50 nF | 50 µF | near RETRO ECC + controller retention |
| MID VDD 1.0 V | 30 nF | 30 µF | near bank arrays + mesh routers |
| PERIPH VDD_HI 1.618 V | 25 nF | 25 µF | near clock tree + optical drivers |
| HIGH VDD_IO 2.618 V | 20 nF | 20 µF | at PHY×16 + pad ring |

Target: ΔV ≤ 5% VDD on worst-case step, including the 38.6 W refresh-with-ECC
burst served from MIM + SC regulators (§5).

## 2. Per-block power (phi-RAM die)

| Block | Active | Idle | Parked | Status |
|---|---|---|---|---|
| 32 phi-RAM banks (L3) | 25 mW/bank = **800 mW** | 1 mW/bank | 0.05 mW/bank | [VERIFIED] plan §4.6 × 32 |
| L0 FLT regfile | 5 mW | 1 mW | 0.1 mW | [VERIFIED] plan §5.1 |
| L1 FLT 4-gate SRAM | **20 mW** | 5 mW | 0.5 mW | [VERIFIED] plan §5.1 |
| L2 FLT resonant buffer | **30 mW** | 8 mW | 1 mW | [VERIFIED] plan §5.1 |
| L4 NVM ctrl (crossbar + NV-diamond) | 100 mW | 10 mW | 1 mW | [VERIFIED] plan §5.1 |
| PHI CONTROLLER (sched·prefetch·arb·power·refresh) | ~5 W | 0.5 W | 0.05 W | [PROPOSED] derived |
| RETRO ECC units (verify/repair path) | ~2 W (during refresh/read-verify) | 0.2 W | 0.02 W | [PROPOSED] derived |
| PHY×16 (HBM-class, 2.618 V) | ~20 W | 8 W | 1 W | [PROPOSED] derived (HBM-class PHY power) |
| Clock tree + L0 + watch oscillators | ~2 W | 0.5 W | 0.1 W | [PROPOSED] derived |
| **phi-RAM die total** | **~35 W active** | — | **~4 W parked** | [VERIFIED] plan §7.4 / TEST-13 (RAM ≤ 35 W) |

Parked budget check: 32 banks × 0.05 mW = 1.6 mW of the ~4 W; the parked draw
is dominated by PHY low-power (1 W) and controller retention (0.05 W).

**Rail currents (derived from the VERIFIED block powers ÷ stated domain
voltage; [PROPOSED] — fixed by UPF/PEX at signoff, 13_FAB_PACKAGE §4):**

| Rail | Current (derived) | Basis |
|---|---|---|
| HIGH 2.618 V | ≈ **7.6 A** | PHY×16 20 W |
| MID 1.0 V | ≈ **0.93 A** | banks 0.80 A + L2 30 mA + L4 100 mA (PHI CONTROLLER 5 W split between CORE/MID resolved at signoff) |
| PERIPH 1.618 V | ≈ **1.2 A** | clock tree 2 W |
| CORE 0.618 V | ≈ **3.3 A** (during ECC-refresh) | RETRO ECC 2 W + L0 8 mA + L1 32 mA |

The tabulated block powers sum to ~30 W; the nominal 35 W active die adds pad
ring, watch oscillators, phase detectors, and analog FLT (unassigned by block,
resolved at signoff).

## 3. Per-block power (hologram-engine die)

| Block | Active | Status |
|---|---|---|
| 512 FFT engines @ 3.472 GHz (4-stage, 288 ps/stage) | ~190 W (≈ 370 mW/engine) | [PROPOSED] derived |
| Blocked-FHRR bank control | ~5 W | [PROPOSED] derived |
| Optical lanes ×4 (4F module ~2 pJ/b) | ~3 W | [PROPOSED] derived |
| Clock distribution + engine control | ~2 W | [PROPOSED] derived |
| **hologram-engine die total** | **200 W** | [VERIFIED] PACKAGE_SPEC §5 / TEST-13 (holo ≤ 200 W) |

Engine energy sanity: 48,709 q/s/engine × 71,285 ops/q = 3.47×10⁹ ops/s at
~0.85 fJ/op (FLT PDP) → ~3 mW ideal; the ~370 mW/engine budget carries FFT
memory access, twiddle ROM, control, and the strong-inversion clock tree at
3.472 GHz (dual-regime honesty, 05_DEVICE_FLT §4). [PROPOSED]

## 4. System power (full phi-RAM package, R4 accounting)

| Load | phi-RAM die | Holo die | Total |
|---|---|---|---|
| Active | ~35 W | 200 W | ~235 W |
| Parked (coherence-gated) | ~4 W | ~30 W | ~34 W |

Package-level total (all four dies + holo): nominal 727 W = GPU 250 + CPU 242 + RAM
35 + holo 200 [VERIFIED PACKAGE_SPEC §5]; TEST-13 worst-case 1,335 W = GPU 300 +
CPU 800 + RAM 35 + holo 200 (bounds). Junction targets: phi-RAM **26.1 °C**,
holo 31.5 °C (F05) — all < 100 °C via the parallel per-die + co-located TSV
path (0.0325 K/W).

## 5. Refresh power (honest record)

| Config | Power | Source |
|---|---|---|
| Refresh, no ECC | **15.9 W** | results_opt_ram.json refresh |
| Refresh, with ECC (read-verify-repair) | **38.6 W** | results_opt_ram.json refresh |

The corrected baseline recorded 12.8 W / 31.2 W (results_ram.json); the 5× pass
re-measured 15.9 W / 38.6 W at DIM 5712 — the corpus uses the optimized,
verified values. Honest note: the with-ECC refresh burst (38.6 W) can exceed the
35 W nominal die budget; it is served by on-die MIM decoupling + the SC
regulators, and the TEST-13 pass bound (RAM ≤ 35 W) applies to the nominal
workload, with ECC-refresh bursts recorded as measured peaks, not hidden.

## 6. IO levels (2.618 V domain)

| Parameter | Min | Nom | Max | Notes |
|---|---|---|---|---|
| VIH | 1.60 V | — | 2.618 V + 0.3 | LVCMOS 2.618 V class |
| VIL | — | — | 1.02 V | — |
| VOH | VDD_IO − 0.4 | — | — | @ I_OH |
| VOL | — | — | 0.4 V | @ I_OL |
| PHY×16 | HBM-class differential | 2.618 V | — | Φ-interleaved address |
| Output slew | 0.5–1.0 V/ns | — | — | per lane |
| Input clamp | −0.3 V | — | VDD_IO + 0.3 V | ESD-protected |

## 7. Operating conditions

| Parameter | Min | Nom | Max | Status |
|---|---|---|---|---|
| Ambient | −40 °C | 25 °C | +125 °C | [VERIFIED] op range |
| Junction | −40 °C | 26.1 °C | 125 °C | [VERIFIED] F05 junction; op max |
| VDD_LL | 0.556 V | 0.618 V | 0.680 V | ±10% |
| VDD | 0.9 V | 1.0 V | 1.1 V | ±10% |
| VDD_HI | 1.456 V | 1.618 V | 1.780 V | ±10% |
| VDD_IO | 2.356 V | 2.618 V | 2.880 V | ±10% |
| Bank clock | — | 2.571807 GHz | 2.571807 GHz | rung 32 [VERIFIED C06] |
| Engine clock | — | 3.472 GHz | 3.472 GHz | 4-stage [VERIFIED G01] |
| Cooling floor | 185.41 K | — | — | budget stop, not physics floor |

## 8. Absolute maximum ratings

| Parameter | Rating |
|---|---|
| VDD_IO (2.618 V rail) | 3.0 V |
| VDD_HI (1.618 V rail) | 2.0 V |
| VDD (1.0 V rail) | 1.35 V |
| VDD_LL (0.618 V rail) | 1.0 V |
| Input voltage (2.618 V pads) | −0.3 V … VDD_IO + 0.3 V |
| Storage temperature | −65 °C … +150 °C |
| ESD (HBM) | 2 kV |
| ESD (CDM) | 500 V |
| Latchup | 100 mA (per TEST_PLAN, I-trigger) |
| Power per pin | 20 mW |
| Peak refresh-with-ECC burst | 38.6 W (recorded, served by decoupling) |

## 9. Power sequencing and brown-out

| Item | Spec | Status |
|---|---|---|
| Power-up order | CORE (0.618) → MID (1.0) → PERIPH (1.618) → HIGH (2.618), 100 µs min ramp-to-ramp; PHY×16 + pads tri-stated until POWER_GOOD | [PROPOSED] |
| POWER_GOOD release | all four rails within ±10% nominal AND CLK_REF 528.0 MHz stable; releases controller reset | [PROPOSED] |
| Brown-out | any rail < 90% nominal for > 1 µs → brown-out reset (BOR); re-POWER_GOOD after recovery; BOR preserves FLT hologram cell charge (Law 172) | [PROPOSED] |
| 3D-stack tier note | tiers power in Φ-spacing order (10 §4); sequencing spans the 8-tier stack, co-located TSVs | [PROPOSED] |

Brown-out / rail-health observable via refresh-status + COH_STATUS pads (09 §A).
