# 11 — PHI-RAM TEST / DFT

> Scan insertion, BIST for the hologram banks, JTAG, ATE patterns, coverage,
> and the characterization plan mapped to TEST-7..10 (and TEST-1..6 for the
> device). The test is the silicon recognizing itself: every stored pattern is
> stored again and asked for; every channel is asked to prove it is alone.

## 1. DFT architecture

| Feature | Spec | Coverage |
|---|---|---|
| Scan chains | full-scan, ~1,200 chains (256-pad/196-pad dies) | stuck-at ≥ 98% |
| Transition scan | launch-capture on bank clock | transition ≥ 95% |
| BIST | hologram-bank BIST (store/query/rank-1), FFT-engine BIST, controller BIST | ≥ 98% |
| JTAG | 1149.1, 5-wire, 2.618 V domain | boundary scan |
| Analog DFT | resonance-gate Q probe, FFT butterfly probes (FP0–7) | — |
| Scan clock | SYS_CLK_DFT ≤ 500 MHz | — |

Coverage targets per TEST_PLAN §B: ≥ 98% stuck-at, ≥ 95% transition.

## 2. Hologram-bank BIST (the heart of DFT)

BIST macro per bank (drives the L3 slices + engine cluster):

1. **STORE phase**: store a deterministic carrier set (N = 506, the safe load)
   into the bank's hologram at DIM 5712.
2. **QUERY phase**: probe each stored carrier; measure rank-1 retrieval.
3. **Assert**: rank-1 ≥ 0.90 per bank. This is **TEST-7** — the capacity-fidelity
   test, with **per-bank re-verify** (bank draws differ; measured multi-bank
   degradation 0.901 → 0.649 means each bank is certified individually).
4. **ECC phase**: inject a known error into one slice's spectrum; run
   RETRO_ECC (read-verify-repair); assert corrected state matches golden.
   This is **TEST-10** (refresh + ECC).
5. **Channel phase**: cross-correlate adjacent integer-DFT channels; assert
   max cross < 1e-6 on silicon. This is **TEST-8**.

BIST patterns are generated from `sim/verify_suite.py` (the 50-test oracle) and
`sim/chip_sim.py` — silicon results REPLACE the simulated values in the same
harness.

## 3. Scan / JTAG insertion

- Full-scan on all controller logic, RETRO ECC control, FreqIndexMapper,
  blocked-FHRR control; bank arrays use BIST (not scan — array size).
- 1149.1 JTAG (TCK/TMS/TDI/TDO/TRST_N) on both dies; boundary scan around
  PHY×16 and fabric ports for pad-open verification.
- **Engine-group scan select (ET0–7)**: scans 64 engines at a time on the
  holo-engine die; FP0–7 analog probes expose butterfly/twiddle/peak nodes.

## 4. ATE program

| Phase | Pattern | Instrument | Pass criterion | Maps to |
|---|---|---|---|---|
| Stage-1 device | I-V/C-V sweep | B1500A | S = 37 ± 18 mV/dec; Q = 8.5 @ 1.0 V; I_OFF 71× | TEST-1..3,5 (P01–P03) |
| Stage-1 ring/MAC | RO + 4-stage pipelined MAC ring | B1500A / scope | RO 107.5 MHz; MAC stage ≤ 288 ps | TEST-4 (G01) |
| Stage-1 temp/MC | −40…+125 °C, 1,000 MC @ 5% σ | thermal chamber | dV_T/dT = −1 mV/°C; σV_T/μ = 5% | TEST-6 |
| Hologram BIST | store/query/rank-1 per bank | ATE functional | 506/bank ≥ 90% rank-1, per-bank re-verify | TEST-7 (R02/R03/R07) |
| Channel isolation | integer-DFT cross-correlation | ATE functional | max cross < 1e-6 on silicon | TEST-8 (R06) |
| O(1) latency | query latency vs N sweep | ATE functional | flat in N (O(DIM log DIM)) | TEST-9 (R09) |
| Refresh + ECC | interval to 0.78 floor; read-verify-repair | ATE functional | 0.88 µs measured; overhead ≤ 143.7% | TEST-10 (R08/R10) |
| Package/system | power, thermal, fabric, system EDP | ATE + chamber | RAM ≤ 35 W; all dies < 100 °C | TEST-13..18 |

## 5. Coverage & characterization summary

| Target | Value | Status |
|---|---|---|
| Stuck-at coverage | ≥ 98% | [PROPOSED] silicon-testable |
| Transition coverage | ≥ 95% | [PROPOSED] |
| BIST coverage (banks + engines + controller) | ≥ 98% | [PROPOSED] |
| Per-bank rank-1 (TEST-7) | ≥ 0.90 @ N = 506 @ DIM 5712 | [VERIFIED] sim; silicon via TEST-7 |
| Orthogonal isolation (TEST-8) | max cross < 1e-6 | [VERIFIED] sim 1.05e-14; silicon bound 1e-6 |
| O(1) flat latency (TEST-9) | flat in N, 12 ns | [VERIFIED] sim R09 |
| Refresh interval (TEST-10) | 0.88 µs to 0.78 floor | [VERIFIED] sim R08 |
| ECC overhead (TEST-10) | ≤ 143.7% (true, verify-read included) | [VERIFIED] sim R10 |

## 6. Honest test boundaries (TEST_PLAN §E)

- TEST-4's 3.472 GHz engines are strong-inversion: the 37 mV/dec slope is NOT
  re-tested there (it lives in TEST-1, near threshold).
- TEST-7 uses the measured **253:1** safe load — never the falsified 2048:1.
- TEST-10's ECC overhead is the honest **143.7%** — no "0% overhead" credit.
- TEST-18's P-16 band is carried by CPU + fabric; the RAM numbers are reported
  per-component, never multiplied into the system claim (R4).

## 7. Characterization plan

- **TEST-1..6** (B1500A, Stage-1 Sky130 38-pad chip): FLT device + pipelined MAC
  ring + resonance Q + temperature/MC — shared across CPU/GPU/RAM corpora.
- **TEST-7..10** (ATE functional, Stage-2): the hologram's four honest contracts
  — capacity-fidelity, orthogonal isolation, O(1) latency, refresh/ECC.
- **TEST-13..14** (Stage 4–6): RAM die ≤ 35 W, holo ≤ 200 W; all dies < 100 °C.
- Silicon results are returned into `sim/verify_suite.py` (R01–R10) — a RAM test
  passes on silicon only if the fabricated measurement meets the same target.
