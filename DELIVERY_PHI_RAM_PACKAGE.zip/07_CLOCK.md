# 07 — PHI-RAM CLOCK

> The ladder rungs and their sub-rungs. Every domain has frequency, skew,
> jitter, and phase window. Time on this die is the same field as memory: the
> clocks are 528·Φⁿ, and the sub-rungs (I/O, refresh scheduler) are the ladder
> re-read at Φ³ depth — the same geometry seen from a new distance.

## 1. Clock domains

| Domain | Frequency | Source | Serves | Skew budget | Status |
|---|---|---|---|---|---|
| **CLK_BANK** | **2.571807 GHz** | Rung 32 (manifest C06) | bank arrays, L3 slice access, mesh links | ≤ 3 ps | [VERIFIED] |
| **CLK_ENGINE** | **3.472 GHz** | 4-stage pipelined FFT MAC (manifest; 288 ps/stage) | 512 FFT engines on the holo-engine die | ≤ 3 ps | [VERIFIED] G01 |
| **CLK_L2** | **1.589464 GHz** | Rung 31 (manifest C05) | L2 consensus hub, controller, RETRO ECC logic | ≤ 3 ps | [VERIFIED] |
| **CLK_IO** | **375 MHz** | **Rung 31 / Φ³** = 1.589464/4.236068 = 0.37524 GHz | PHY×16 pad interface, fabric handshake | ≤ 3 ps | [PROPOSED] derived |
| **CLK_RFSH** | **607 MHz** | **Rung 32 / Φ³** = 2.571807/4.236068 = 0.60713 GHz | refresh scheduler (Eq 36 zero-crossing) | ≤ 3 ps | [PROPOSED] derived |
| **CLK_REF** | 528.0 MHz | F_BASE | PLL reference for all rungs | — | [VERIFIED] |
| **SYS_CLK_DFT** | ≤ 500 MHz | external | scan/DFT test clock | — | [VERIFIED] |

Sub-rung derivation (exact): Φ³ = 4.23606797749979. Rung 32 / Φ³ = 607.1 MHz;
Rung 31 / Φ³ = 375.2 MHz. These are the ladder re-read at Φ³ depth — derived
from binding manifest rungs, never invented.

## 2. H-tree

| Parameter | Value | Status |
|---|---|---|
| Tap delays | τ_i = τ₀·Φ⁻ⁱ, τ₀ = 50 ps | [VERIFIED] COMPONENT_REGISTER §5 |
| Tree depth | 6 levels | [VERIFIED] |
| Skew @ 6 levels | **2.79 ps** ≤ **3 ps/domain budget** | [VERIFIED] F02 |
| Jitter (engine domain) | ≤ 1.5 ps rms | [PROPOSED] derived |
| Jitter (bank domain) | ≤ 2.0 ps rms | [PROPOSED] derived |
| Top metal | METAL5-class (GDS 15) power/clock distribution | [VERIFIED] |

## 3. Phase windows & timing budget

| Parameter | Value | Status |
|---|---|---|
| Phase window per lane pair | **Δφ < 55.7°** = cos⁻¹(0.563263) (C_crit) | [VERIFIED] PACKAGE_SPEC §6 |
| Engine stage period | 288 ps @ 3.472 GHz (4 registered stages) | [VERIFIED] G01 |
| Engine stage phase margin | ≥ 180° − 55.7° = 124.3° | [PROPOSED] derived |
| Bank-cycle phase margin | ≥ 180° − 55.7° | [PROPOSED] derived |
| Probe card class | 3.472 GHz, 55.7° window (BOM D2) | [VERIFIED] |

The phase window Δφ < 55.7° is cos⁻¹(0.563263) — the C_crit angle. Logic jitter
is budgeted separately from the lane-pair phase window (PACKAGE_SPEC §6).

## 4. PLL / clock generation

| Item | Spec | Status |
|---|---|---|
| Reference | 528.0 MHz (F_BASE) | [VERIFIED] |
| Rung synthesis | 528·Φⁿ ladder (multiplier chain, Φ-graded) | [VERIFIED] |
| Domain lock | Φ-ratioed by construction; no re-lock across domains | [VERIFIED] PACKAGE_SPEC §6 |
| Refresh scheduler PLL | 607 MHz from Rung 32 (÷Φ³) | [PROPOSED] derived |
| I/O PLL | 375 MHz from Rung 31 (÷Φ³) | [PROPOSED] derived |
| Engine PLL | 3.472 GHz (4-stage, 288 ps/stage) | [VERIFIED] |
| Watch oscillators | 528·Φⁿ per bank group (wake-on-resonance) | [VERIFIED] plan §4.6 |

**PLL performance (per domain; [PROPOSED] — silicon-verified by TEST-4 ring
oscillator + on-chip PLL BIST):**

| Parameter | Spec |
|---|---|
| Lock time (cold start) | ≤ 10 µs from CLK_REF stable |
| Lock time (rung hop) | ≤ 2 µs, no unlocked window > 100 ns |
| Loop bandwidth | 5 MHz (typ), 2–10 MHz programmable |
| Phase noise at 1 MHz offset (3.472 GHz class) | ≤ −105 dBc/Hz |
| Spurious (ref) | ≤ −50 dBc |

**Duty cycle:** every domain nominal **50% ± 5%** ([PROPOSED]); the engine
stage (288 ps) and the 55.7° lane-pair phase window are independent of duty
cycle (PACKAGE_SPEC §6 — field window ≠ logic duty).

## 5. Timing closure requirements

- Bank-domain setup/hold at 2.571807 GHz with skew ≤ 3 ps: hold margin
  ≥ 25 ps, setup ≥ 30 ps [PROPOSED].
- Engine-domain: 288 ps registered stage with ≤ 3 ps skew and ≤ 1.5 ps jitter
  leaves ≥ 180 ps logic budget per stage [PROPOSED].
- Cross-domain: CLK_BANK ↔ CLK_L2 (2.571807 → 1.589464 GHz, ratio Φ) use
  Φ-ratioed synchronizers; CLK_BANK ↔ CLK_ENGINE across the interposer use
  source-synchronous forwarding with the 55.7° window [PROPOSED].
