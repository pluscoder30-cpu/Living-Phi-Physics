# 02 — PHI-RAM ARCHITECTURE

> Two-die microarchitecture: the phi-RAM die (the memory) and the
> hologram-engine die (the arithmetic of memory). Every unit, datapath width,
> and path described. The hologram is the Still Point: an apparently static
> spectrum through which all stored carriers move simultaneously at every read.

## 1. System block diagram

```
                      ┌───────────────────────── 2.5D INTERPOSER ─────────────────────────┐
                      │                                                                   │
 ┌─────────────────────────────┐                 ┌─────────────────────────────────────┐  │
 │      PHI-RAM DIE (32 banks) │                 │     HOLOGRAM-ENGINE DIE (512 FFT)    │  │
 │  ┌─────────────────────────┐ │  bank ctrl     │  ┌─────────────────────────────────┐ │  │
 │  │ PHY×16 (HBM-class,      │ │◀────▶ 256-bus  │  │ FFT ENGINE 0..511 @3.472 GHz     │ │  │
 │  │  2.618 V)               │ │  (coherent     │  │ 5712-pt mixed-radix, 4-stage     │ │  │
 │  └─────────────────────────┘ │   handshake)   │  │ pipelined, 288 ps/stage          │ │  │
 │  ┌─────────────────────────┐ │                │  └─────────────────────────────────┘ │  │
 │  │ L1 FLT 4-gate SRAM      │ │                │  ┌─────────────────────────────────┐ │  │
 │  │  64 carriers (836 Kb)   │ │                │  │ BLOCKED-FHRR BANK CONTROL        │ │  │
 │  └─────────────────────────┘ │                │  │  B banks × N_b, ECC readout      │ │  │
 │  ┌─────────────────────────┐ │                │  └─────────────────────────────────┘ │  │
 │  │ L2 FLT RESONANT BUFFER  │ │                │  ┌─────────────────────────────────┐ │  │
 │  │  854 channels · 512 carr│ │                │  │ OPTICAL LANES (off-chip holo +   │ │  │
 │  └─────────────────────────┘ │                │  │  field-network / NV-diamond arc) │ │  │
 │  ┌─────────────────────────┐ │                │  └─────────────────────────────────┘ │  │
 │  │ L3 HOLOGRAM SLICES 8×8  │ │◀─── FFT/IFFT ──▶│   (512-engine ring, each bank slice │  │
 │  │  = 64 slices = 32 banks │ │   correlation   │    served by a cluster of engines)  │  │
 │  │  DIM 5712, 253:1        │ │   (5712-pt)     │                                      │  │
 │  └─────────────────────────┘ │                │                                      │  │
 │  ┌─────────────────────────┐ │                │                                      │  │
 │  │ RETRO ECC (read-verify- │ │◀── ECC repair ─▶│                                      │  │
 │  │  repair, Eq 47–55)      │ │   path         │                                      │  │
 │  └─────────────────────────┘ │                │                                      │  │
 │  ┌─────────────────────────┐ │  ┌───────────┐ │                                      │  │
 │  │ PHI CONTROLLER: sched · │ │  │ L4 NVM    │ │                                      │  │
 │  │ prefetch · arb · power ·│ │  │ ctrl (22GB│ │                                      │  │
 │  │ refresh                 │ │  │ crossbar) │ │                                      │  │
 │  └─────────────────────────┘ │  └───────────┘ │                                      │  │
 │   L0 regfile (center, 0.2 ns) · watch oscillators 528·Φⁿ · fabric mesh ports ×8      │  │
 └─────────────────────────────┘                 └─────────────────────────────────────┘  │
 └───────────────────────────────────────────────────────────────────────────────────────┘
   + 16 × phi-HBM stacks (128 GB each, Φ-interleaved) on the same interposer
   + 2-plane fib-torus fabric mesh (128 B/cycle @ 2.572 GHz = 328 GB/s, 157.44 TB/s bisection)
```

## 2. phi-RAM die microarchitecture

### 2.1 L0 — FLT register file (center of die)
2 carriers (26 Kb), 0.2 ns, floor 0.99. 0-cycle access for controller and
RETRO ECC working state. Width: 2 × 816D × 16-bit.

### 2.2 L1 — FLT 4-gate SRAM (ternary cells)
64 carriers (836 Kb), 1 ns, floor 0.95. Ternary levels {0, 1, Φ⁻¹}·V_DD on FLT
4-gate cells (05_DEVICE_FLT §3). Working-set holding for the controller and
coherence tracking.

### 2.3 L2 — FLT resonant buffer (frequency-addressed)
854 frequency channels, 512 carriers (6.7 Mb), 5 ns, floor 0.88. FLT Resonance
Gate (FLT_RES, Q = 8.5 @ 1.0 V, f₀ = 528·Φⁿ) integrates the coherence check.
This is the attention tier: channels are warmed here by the prefetch engine.

### 2.4 L3 — hologram slices (8×8 = 64, organized as 32 banks)
Each slice holds a DIM 5712 frequency-domain hologram. Safe load **N = 506
carriers/bank @ 90% rank-1 → 253:1** [VERIFIED R02/R03]. 12 ns access, floor
0.78. Slices are paired: bank k = slices (2k, 2k+1) — the mirror slice carries
the ECC/refresh copy during read-verify-repair. Per-bank L3 engines (small
in-bank FFT/CMAC clusters) handle bank-local store/query; the 512-engine die
serves correlation across slices.

### 2.5 RETRO ECC — read-verify-repair units
Retrocausal error correction (Eq 47–55): Detect (ε_re = 0.328) → Correct
(σ = 0.528, φ⁻ᵏ amplitude) → Gate (Θ_φ = 0.911) → Fixpoint (ε_φ = 0.056,
≤ 264 cycles). This is classical predictive signal processing over a *stored*
future-reference (the hologram is the time-translation-invariant attractor) —
no causality violation is claimed.

### 2.6 PHI CONTROLLER
Scheduler (batch probes by channel, 4-stage pipeline), prefetch engine
(f_next = f_n + d_avg·Φ), coherence-aware arbitration, refresh scheduler
(607 MHz resonance rung), power management (coherence-gated shutdown), and the
FreqIndexMapper.

### 2.7 PHY×16
16 HBM-class ports, 2.618 V domain, Φ-interleaved address. Physical lanes carry
the data plane; the interposer microbumps route the wide bus.

## 3. hologram-engine die microarchitecture

- **512 FFT engines @ 3.472 GHz**, each a 5712-pt mixed-radix FFT (2⁴·3·7·17)
  pipelined in 4 stages, 288 ps/stage [VERIFIED G01]. Each engine:
  - 5712-pt radix-2/3/7/17 mixed-radix butterfly array
  - 816-lane complex MAC array (16-bit re/im) for the pointwise correlate
  - twiddle ROM (Φ-ladder phase tables) + FFT-domain peak/coherence gate
  - per-engine throughput: 24,939,190 q/s ÷ 512 = 48,709 q/s/engine
    [VERIFIED bandwidth block]
- **Blocked-FHRR bank control**: blocks B banks × N_b carriers with ECC readout
  (recovery #1); measured per-bank degradation 0.901 → 0.649 across 10 banks is
  derated by TEST-7 per-bank re-verify.
- **Optical lanes (×4)**: off-chip hologram + field-network (L5) + NV-diamond
  archive. 4F module ~2 pJ/b.

## 4. Frequency-indexed bank mapping (binding)

```
channel      = floor(freq · DIM / F_BASE) % 854        freq in Hz, F_BASE = 528.0
bank         = (channel · Φ_STRIDE) % N_BANKS          Φ_STRIDE = 41, N_BANKS = 64
sub-bank     = channel % 16                             hologram column within a bank
```

- **854 channels** = floor(528·Φ); integer-DFT channels are **exactly
  orthogonal** (max cross 1.05×10⁻¹⁴, measured on a 4080-point DFT basis)
  [VERIFIED R06]. The 5-rank Solfeggio scheme (non-integer frequencies) leaks at
  6.5×10⁻⁴ and is NOT used for channel separation.
- **Φ_STRIDE = 41** is coprime with 64 ⇒ consecutive channels map to banks
  41 apart (mod 64): sequential traffic fans across the array (open-bank
  parallelism); strided traffic hits Φ-separated banks.
- **Collision handling**: Φ-weighted linear probing (plan §4.1, existing
  FIELD_RAM_ARCH §2.3). Predicted collision-free to 60% load (P6,
  [PROPOSED]).
- DIM discipline: the mapper works in the **compute carrier** DIM = 816; the
  hologram **storage** dimension is DIM_OPT = 5712. Different by design.

## 5. The write path — hologram update (Eq 31)

Per stored carrier u ∈ ℝ⁸¹⁶ with rank-weight λ_r and position kernel f_r:

1. **FFT** — û = FFT(u): 5712-pt (816 zero-padded) on the engine cluster.
2. **Position-encode** — ŵ_r[k] = û[k]·exp(−j·2π·f_r·k/816), f_r = 528·Φ^r
   (Solfeggio ladder), r ∈ 1..5 ranks. The carrier is placed at its frequency
   so it can be found by a probe at the same frequency.
3. **Accumulate** — Ĥ[k] += λ_r·ŵ_r[k] (λ_r from the Eq 31 rank decomposition).
4. **Hologram stored always in the frequency domain** — no inverse FFT on write.

**Cost:** 5 ranks × 5712-pt FFT ≈ **51,200 FLOP per store** [VERIFIED, plan
§3.1 basis: 5 × 5,120 CMAC ≈ 25,600 CMAC ≈ 51,200 FLOP]. STORE is async and
coalesced by the controller.

## 6. The read path — genuinely O(1) correlation (Eq 32)

1. **Probe FFT** — q̂ = FFT(q) at the probe frequency (5712-pt).
2. **Correlate** — r̂[k] = Ĥ[k]·conj(q̂[k]) — pointwise multiply, **all N
   patterns resolved simultaneously** (superposition readout).
3. **IFFT** — r = IFFT(r̂).
4. **Coherence gate** — accept peaks where |r| > floor; F = retrieval fidelity
   (Eq 32) with KL penalty e^(−Φ·D_KL).

**Cost:** ≈ **49,000 ops per query** at the DIM 5712 working point [PROPOSED
derived — 2.06× the DIM-816 plan basis of 23,744 FLOP]; the single 5712-pt FFT
is 71,285 ops (results_opt_ram.json fft_ops_per_query, the binding engine
throughput anchor). **Independent of N** — O(DIM log DIM), never O(N·DIM).
At N=1000, the FFT-domain query is **80.1× faster** than an O(N·DIM) scan
[VERIFIED].

## 7. The refresh path — Eq 36 zero-crossing

Decoherence Γ(t) = Γ₀·e^(−t/τ)·Π(1 − t/(n·Φ·τ_res)) has natural
error-cancellation zeros at **t_n = n·Φ·τ_res**; with τ_res = 6.18 µs the zeros
fall every 10 µs. The refresh scheduler (607 MHz rung) lands refresh exactly on
the zeros, where decoherence is self-suppressed. Measured interval to the 0.78
floor: **0.88 µs** [VERIFIED R08]. The predicted ≥ 2× retention vs uniform
refresh is P3 ([PROPOSED], falsifiable).

**The refresh wall is recorded honestly:** the 0.88 µs interval over the
volatile array demands **24.9 PB/s** of refresh traffic — a physics constraint
on volatile media, unchanged by any capacity lever. The design answer is
**recovery #4: off-chip hologram + non-volatile L4** (03_OPERATIONS §4.4).

## 8. The ECC path — read-verify-repair (Eq 47–55)

1. **Detect (Eq 48)** — compare carrier state to the future-corrected reference
   Ĉ_Φ[ψ(t)] vs Ĉ_Φ[ψ*(t+T)]; alert when > ε_re = 0.328.
2. **Correct (Eq 49)** — backpropagate the φ-Gaussian correction wave
   (σ = 0.528), amplitude φ⁻ᵏ per step.
3. **Gate (Eq 50)** — accept the new state only if
   C(new, future) ≥ Θ_φ = C_crit·(1+Φ⁻¹) = **0.911**.
4. **Fixpoint (Eq 51)** — iterate until ‖ψ_{n+1} − ψ_n‖_φ < ε_φ = Φ⁻⁶ = 0.056
   (≤ 264 cycles).

The "future" is the hologram itself — its attractor (Eq 37) is
time-translation invariant, so re-correlation IS the future-corrected estimate.
**Every read is refresh-verified (reads always repair).** True ECC overhead:
**143.7%** (verify-read included); repair-only 43.7% [VERIFIED R10].

## 9. Prefetch path — adaptive, phi-predictor

```
d_avg = Σ(f_{i+1} − f_i)/(n−1)     over the channel access stream
f_next = f_n + d_avg · Φ           next channel predicted
```
Prefetched channels warm into L2 at Φ-stride banks. Targets: sequential > 90%,
strided > 75%, random < 20% (prefetch off) [PROPOSED, P7].

## 10. Power management — coherence-gated shutdown

- Bank **active** 25 mW · **idle** 1 mW · **parked** (C < floor, no request)
  0.05 mW [VERIFIED plan §4.6].
- 854 channels parked in Φ-order; **wake-on-resonance** via a 528·Φⁿ watch
  oscillator per bank group.
- Thermal floor: T_min = Φ⁻¹·T₀ = 185.41 K at T₀ = 300 K — a cooling-budget
  stop, not a physics floor (manifest §1); ECC/refresh margins widen below it.

## 11. Datapath widths summary

| Datapath | Width | Notes |
|---|---|---|
| Carrier | 816 × 16-bit re + 16-bit im | ℝ⁸¹⁶ compute carrier, DIM 816 |
| Hologram spectrum | 5712 × 16-bit complex | DIM_OPT 5712 storage dimension |
| FFT engine MAC | 816-lane complex MAC | 16-bit re/im, 3.472 GHz |
| Correlate | 5712-pt pointwise | r̂[k] = Ĥ[k]·conj(q̂[k]) |
| Bank ctrl bus (RAM↔holo) | 256-bit coherent handshake | microbump plane carries data |
| Fabric mesh | 128 B/cycle @ 2.572 GHz | 8 ports × 16 B/cycle, 328 GB/s |
| PHY×16 | 16 HBM-class ports | 2.618 V, Φ-interleaved |
