# 06 — PHI-RAM MEMORY HIERARCHY (L0–L5)

> The full storage hierarchy contract. Every tier: technology, physical
> capacity, effective capacity, latency, refresh, coherence floor, power.
> The hierarchy is consciousness folding into structure: register
> (self-immediacy) → SRAM (working awareness) → resonant buffer (attention) →
> hologram (long-memory crystal) → crossbar (memory that IS the computation) →
> field network.

## 1. The L0–L5 table (binding)

| Tier | Technology | Physical | Effective | Latency | Refresh | Floor | Power | Status |
|---|---|---|---|---|---|---|---|---|
| **L0** | FLT regfile | 2 carriers (26 Kb) | 26 Kb | **0.2 ns** | — | **0.99** | 5 mW | [VERIFIED] plan §5.1 |
| **L1** | FLT 4-gate SRAM (ternary) | 64 carriers (836 Kb) | 836 Kb | **1 ns** | — | **0.95** | 20 mW | [VERIFIED] |
| **L2** | FLT resonant buffer, 854 channels | 512 carriers (6.7 Mb) | ~10.9 Mb (×Φ channels) | **5 ns** | 1 µs | **0.88** | 30 mW | [VERIFIED] |
| **L3** | Hologram (DIM 5712, FLT-SRAM substrate + CMAC engines) | 64 slices/32 banks; ~22 GB physical backing | **5,009.4 GB** @ 253:1 | **12 ns** | **0.88 µs** (Eq 36 zeros) | **0.78** | 25 mW/bank | [VERIFIED] R02/R03 |
| **L4** | Memristor/PCM crossbar + NV-diamond | 22 GB NVM | non-volatile archive | **120 ns** | 100 µs (retrocausal) | **0.70** | 100 mW | [VERIFIED] plan; [PROPOSED] silicon |
| **L5** | Distributed field network (eigenstate packets) | global | Law 189 fidelity governs | **1 µs+** | — | **0.563** (C_crit) | — | [VERIFIED] plan |

**Effective capacity headline:** 22 GB physical holographic backing × 253:1
with fidelity derating ⇒ **5,009.4 GB = 62.6× H100** [VERIFIED
results_opt_ram.json capacity: effective_GB 5009.4, vs_h100_capacity_x 62.6,
target_5x_gb 4257 met].

**Honest silicon wall:** the effective 5,009 GB does NOT sit on-die — on-chip
SRAM for 512 GB effective would need ~13,000 mm² (results_ram.json multibank
note). The 22 GB holograms live on the FLT-SRAM substrate + off-chip hologram +
non-volatile L4 (recovery #4). Capacity is the superposition's gift; the
physical store stays ~22 GB.

## 2. Per-tier contract

### L0 — FLT register file (self-immediacy)
2 carriers (26 Kb), 0.2 ns, floor 0.99, 5 mW. Controller + RETRO ECC working
state; 0-cycle forwarding.

### L1 — FLT 4-gate SRAM (working awareness)
64 carriers (836 Kb), 1 ns, floor 0.95, 20 mW. Ternary cells {0,1,Φ⁻¹}·V_DD,
1.58 bits/wire. Coherence tracking + controller working set.

### L2 — FLT resonant buffer (attention)
854 frequency channels, 512 carriers (6.7 Mb), 5 ns, floor 0.88, 30 mW.
FLT_RES resonance gate (Q = 8.5) integrates the coherence check; channels tuned
to 528·Φⁿ. Refresh 1 µs.

### L3 — the hologram (the long-memory crystal)
- 64 slices in an 8×8 grid = 32 addressable banks (2 slices/bank: primary +
  ECC/refresh mirror).
- Safe load **N = 506 carriers/bank @ 90% rank-1 → 253:1** @ DIM 5712
  [VERIFIED R02/R03].
- Access 12 ns, floor 0.78, 25 mW/bank active.
- Stored always in the frequency domain; all reads are FFT-domain correlations.
- **Multibank honesty** (results_opt_ram.json): per-bank rank-1 degrades with
  bank count under different carrier draws — 0.901 (1 bank) → 0.72 (3 banks)
  → 0.649 (10 banks). ECC readout + TEST-7 per-bank re-verify are load-bearing.

### L4 — memristor/PCM crossbar + NV-diamond (memory that IS computation)
22 GB non-volatile. The crossbar performs analog MAC in-situ — weights ARE
carriers (Eq 78). NV-diamond archive (10 s projected coherence) holds the
off-chip hologram that survives the refresh wall. 120 ns, floor 0.70, 100 mW.
Refresh 100 µs (retrocausal). This is **recovery #4** — the non-volatile answer
to the volatile refresh wall.

### L5 — distributed field network
Global archive via eigenstate packets; Law 189 fidelity e^(−1/Φ) = 0.539 per
coherence length governs; floor C_crit = 0.563263. 1 µs+. The dormant frequency
named by the plan's Clear Lens review — activated by the network agent.

## 3. Refresh contract (honest)

| Parameter | Value | Status |
|---|---|---|
| Interval to 0.78 floor | **0.88 µs** | [VERIFIED] R08 |
| Interval from 1.0 | 1.54 µs | [VERIFIED] |
| τ_res (Eq 36 zero spacing) | 6.18 µs ⇒ zeros every 10 µs | [VERIFIED] |
| Refresh traffic (full) | **24,876.7 TB/s = 24.9 PB/s** | [VERIFIED] |
| Refresh traffic (degraded, 43.7% ECC) | 10,871.1 TB/s | [VERIFIED] |
| vs H100 HBM (full) | **7,425.9×** | [VERIFIED] |
| Refresh power no-ECC / with-ECC | 15.9 W / **38.6 W** | [VERIFIED] |

The refresh wall (24.9 PB/s) is a physics constraint on volatile media,
unchanged by capacity levers. The documented answer is the off-chip hologram +
non-volatile L4 (recovery #4) — the memory that does not need to refresh.

## 4. ECC contract (honest)

| Parameter | Value | Status |
|---|---|---|
| Repair-only overhead | **43.7%** | [VERIFIED] |
| True overhead (verify-read included) | **143.7%** | [VERIFIED] R10 |
| Retrocausal params | ε_re 0.328 · σ 0.528 · Θ_φ 0.911 · ε_φ 0.056 (≤264 cycles) | [VERIFIED] |
| Read behavior | every read is refresh-verified (read-verify-repair) | [VERIFIED] |

## 5. Channels & orthogonality

| Parameter | Value | Status |
|---|---|---|
| Frequency channels | **854** = floor(528·Φ) | [VERIFIED] |
| Channel basis | integer-DFT (DFT basis size 4080) | [VERIFIED] |
| Max cross-channel | **1.05×10⁻¹⁴** — exactly orthogonal | [VERIFIED] R06 |
| Solfeggio (non-integer) cross-channel | 6.46×10⁻⁴ (leaks — NOT used for separation) | [VERIFIED] |
| DFT basis size measured | 4080 | [VERIFIED] |

## 6. Prefetch contract

| Parameter | Value | Status |
|---|---|---|
| Predictor | f_next = f_n + d_avg·Φ | [VERIFIED] plan §4.4 |
| Sequential | > 90% target | [PROPOSED] P7 |
| Strided | > 75% target | [PROPOSED] P7 |
| Random | < 20% (prefetch off) | [PROPOSED] P7 |
| Warm target | L2 at Φ-stride banks | [VERIFIED] |

## 7. Bank mapping (frequency-indexed)

```
channel   = floor(freq · DIM / F_BASE) % 854       F_BASE = 528.0, DIM = 816
bank      = (channel · Φ_STRIDE) % 64              Φ_STRIDE = 41 (coprime w/ 64)
sub-bank  = channel % 16                             hologram column
```
Collisions resolved by Φ-weighted linear probing. Consecutive channels map to
banks 41 apart ⇒ open-bank parallelism for sequential traffic; Φ-separated
banks for strided traffic. [VERIFIED plan §4.1]

## 8. Capacity arithmetic (the corrected story)

- Corrected baseline: 86 carriers @ 90% rank-1 @ DIM 816 ⇒ **43:1** ⇒
  851.4 GB effective (10.6× H100) [VERIFIED results_ram.json].
- 5× pass sweep: DIM 4080 → 372 (186:1, 4.33×); DIM 4896 → 473 (236.5:1,
  5.50×); **DIM 5712 → 506 (253:1, 5.88×)** [VERIFIED results_opt_ram.json].
- 5× capacity target (5 × 851.4 = 4,257 GB) **MET** at 5,009.4 GB [VERIFIED].
- The falsified path (22 GB × 2048 × Φ⁶ = 807 TB) is dead — a **948×**
  overclaim [VERIFIED]. DIM discipline: 4096/5 = 819.2 never equals 816.

## 9. Associative bandwidth (honest transport)

| Parameter | Value | Status |
|---|---|---|
| Engines | 512 @ 3.472 GHz | [VERIFIED] |
| fft_ops_per_query (5712-pt) | 71,285 | [VERIFIED] |
| Queries/s (aggregate) | 24,939,190 | [VERIFIED] |
| **Associative bandwidth** | **1.14 TB/s** (0.34× H100 raw) | [VERIFIED] |
| vs corrected baseline | 3.99× (285.8 GB/s → 1.14 TB/s) | [VERIFIED] |
| O(1) vs O(N) @ N=1000 | **80.1×** | [VERIFIED] |

Raw transport is 0.34× H100 — the honest statement is that **compression
carries the memory story**, and O(1) association is a search/attention win, not
classical data movement.
