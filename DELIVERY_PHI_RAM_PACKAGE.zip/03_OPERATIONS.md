# 03 — PHI-RAM OPERATIONS (COMMAND SET)

> The complete memory command contract — 16 opcodes. Every command has an
> encoding, semantics, latency, energy, and a [VERIFIED]/[PROPOSED] tag.
> The commands are the field's verbs: store is the field placing a memory,
> query is the field re-meeting all memories at once, refresh is the field
> re-tensing on its own zeros, ECC is the read correcting the read.

## 1. Command word format (24-bit)

| Bits | Field | Meaning |
|---|---|---|
| [23:20] | OP | opcode (0x0–0xF) |
| [19:16] | BANK | bank select 0–15 (bank-pair for 32 banks: BANK + BANK+16) |
| [15:12] | CH | channel select 0–15 (sub-bank / channel group) |
| [11:8] | SUB | sub-op / rank select |
| [7:0] | ARG | argument (N, floor, λ_r, f_r, etc.) |

Commands enter the PHI CONTROLLER's 4-stage pipeline (decode → dispatch →
execute → commit). Priority = coherence urgency × access frequency
(04 §5: entries approaching floor refresh first).

## 2. The 16 commands

| OP | Mnemonic | Name | Latency | Energy | Cost / anchor | Status |
|---|---|---|---|---|---|---|
| 0x0 | STORE | Hologram update | 24 ns async | ~0.02 nJ/store | **~51,200 FLOP** (5 ranks × 5712-pt FFT) | [VERIFIED] plan §3.1 |
| 0x1 | QUERY | Probe correlation | 12 ns | ~0.1 nJ | **~49,000 ops** @ DIM 5712 (FFT path); O(1) in N | [PROPOSED] derived / [VERIFIED] latency |
| 0x2 | REFRESH | Eq 36 zero-crossing refresh | 0.88 µs interval | see 04 §6 | **24.9 PB/s wall** (full), 10.9 PB/s (43.7%) | [VERIFIED] R08 |
| 0x3 | RETRO_ECC | Read-verify-repair | ≤ 264 cycles | see 04 §6 | ε_re 0.328 · σ 0.528 · Θ_φ 0.911 · ε_φ 0.056; overhead 143.7% | [VERIFIED] R10 |
| 0x4 | PREFETCH | Adaptive prefetch | 5 ns (into L2) | ~0.05 nJ | f_next = f_n + d_avg·Φ; seq > 90% / strided > 75% | [VERIFIED] plan / [PROPOSED] P7 |
| 0x5 | PARK | Coherence-gated shutdown | 1 µs settle | 0.05 mW/bank | C < floor, no request ⇒ 0.05 mW/bank | [VERIFIED] plan §4.6 |
| 0x6 | WAKE | Wake-on-resonance | 0.2 µs | 1 mW idle | 528·Φⁿ watch oscillator per bank group | [VERIFIED] plan §4.6 |
| 0x7 | MAP_CHANNEL | Channel map | 1 ns | ~0.01 nJ | channel = floor(freq·DIM/F_BASE) % 854 | [VERIFIED] |
| 0x8 | MAP_BANK | Bank map | 1 ns | ~0.01 nJ | bank = (channel·41) % 64, Φ_STRIDE = 41 | [VERIFIED] |
| 0x9 | MAP_SUBBANK | Sub-bank map | 1 ns | ~0.01 nJ | sub-bank = channel % 16 | [VERIFIED] |
| 0xA | LOAD_HOLO | Load hologram from L4/off-chip | 120 ns | ~0.5 nJ | NV-diamond / NVM crossbar → L3 slices | [PROPOSED] |
| 0xB | SNAPSHOT | Export spectrum | 24 ns/col | ~0.2 nJ | Ĥ[k] readout for the field network (L5) | [PROPOSED] |
| 0xC | ECC_STATUS | ECC counters | 1 ns | — | read ε_re/σ/Θ_φ/fixpoint counters | [VERIFIED] |
| 0xD | COH_PROBE | Coherence probe | 1 ns | — | read C for channel/bank | [VERIFIED] |
| 0xE | SET_FLOOR | Set coherence floor | 1 ns | — | per-tier floor (0.99/0.95/0.88/0.78/0.70/0.563) | [VERIFIED] |
| 0xF | NOP | No-op / debug dump | 1 cycle | — | alignment + observability | — |

## 3. Command semantics (living verbs)

### 3.1 STORE (0x0) — the field placing a memory
Encodes carrier u (ℝ⁸¹⁶) with rank-weight λ_r and position kernel f_r:
1. FFT: û = FFT(u) — 5712-pt, 816 zero-padded.
2. Position-encode: ŵ_r[k] = û[k]·exp(−j·2π·f_r·k/816), f_r = 528·Φ^r.
3. Accumulate: Ĥ[k] += λ_r·ŵ_r[k].
Hologram stays in the frequency domain (no IFFT). ARG selects rank (SUB = r)
and loading (ARG = N to date); the controller coalesces writes and updates the
coherence floor bookkeeping. **~51,200 FLOP/store** [VERIFIED]. Async — never
on the critical read path.

### 3.2 QUERY (0x1) — the field re-meeting all memories at once
1. Probe FFT: q̂ = FFT(q).
2. Correlate: r̂[k] = Ĥ[k]·conj(q̂[k]) — all N patterns at once.
3. IFFT: r = IFFT(r̂).
4. Coherence gate: accept peaks where |r| > floor; fidelity F = |⟨q|Ĥ†Ĥ|s⟩|² ·
   e^(−Φ·D_KL) (Eq 32).
Top-k returned via partial sort on gated peaks. Latency **12 ns flat in N**
[VERIFIED R09]. Cost ≈ **49,000 ops** @ DIM 5712 [PROPOSED derived; single
5712-pt FFT = 71,285 ops, the binding throughput anchor]. O(1) in N: 80.1× vs
O(N·DIM) scan @ N=1000 [VERIFIED].

### 3.3 REFRESH (0x2) — the field re-tensing on its own zeros
The refresh scheduler (607 MHz rung) issues REFRESH to banks at the Eq 36
zero-crossing schedule. Decoherence Γ(t) = Γ₀·e^(−t/τ)·Π(1 − t/(n·Φ·τ_res))
has zeros at t_n = n·Φ·τ_res (τ_res = 6.18 µs ⇒ every 10 µs). The controller
schedules so that the next zero lands inside the measured 0.88 µs interval to
the 0.78 floor [VERIFIED R08]. Honest record: interval × array = **24.9 PB/s**
refresh wall on volatile media — the answer is recovery #4 (off-chip hologram +
non-volatile L4), not a bigger refresh pump.

### 3.4 RETRO_ECC (0x3) — the read correcting the read
Read-verify-repair, triggered by REFRESH and by every read (reads are always
refresh-verified):
1. Detect (Eq 48): error alert when ‖Ĉ_Φ[ψ(t)] vs Ĉ_Φ[ψ*(t+T)]‖ > ε_re = 0.328.
2. Correct (Eq 49): backpropagate φ-Gaussian correction wave, σ = 0.528,
   amplitude φ⁻ᵏ per step.
3. Gate (Eq 50): accept only if C(new, future) ≥ Θ_φ = C_crit·(1+Φ⁻¹) = 0.911.
4. Fixpoint (Eq 51): iterate until ‖ψ_{n+1} − ψ_n‖_φ < ε_φ = Φ⁻⁶ = 0.056,
   ≤ 264 cycles.
The "future" reference is the stored hologram (time-translation-invariant
attractor) — classical predictive signal processing, no causality violation.
True overhead **143.7%** (verify-read included); repair-only 43.7% [VERIFIED
R10]. The overhead is the price of honesty: TEST-10 enforces it.

### 3.5 PREFETCH (0x4) — the field reaching ahead
```
d_avg = Σ(f_{i+1} − f_i)/(n−1)     on the channel access stream
f_next = f_n + d_avg · Φ
```
Predicted channels warm into L2 at Φ-stride banks. Targets: sequential > 90%,
strided > 75%, random < 20% (prefetch disabled below the target) [PROPOSED, P7].

### 3.6 PARK / WAKE (0x5 / 0x6) — coherence-gated sleep
PARK: banks with C < floor and no pending request drop to 0.05 mW (FLT off-state
20× lower leakage). WAKE: 528·Φⁿ watch oscillator per bank group senses
resonance and wakes the bank to idle (1 mW) then active (25 mW). 854 channels
park in Φ-order. [VERIFIED plan §4.6]

### 3.7 MAP_CHANNEL / MAP_BANK / MAP_SUBBANK (0x7/0x8/0x9)
The FreqIndexMapper resolves a frequency to its physical location:
```
channel   = floor(freq · DIM / F_BASE) % 854       F_BASE = 528.0, DIM = 816
bank      = (channel · Φ_STRIDE) % N_BANKS         Φ_STRIDE = 41, N_BANKS = 64
sub-bank  = channel % 16
```
Collisions resolved by Φ-weighted linear probing. Integer-DFT channels are
exactly orthogonal (max cross 1.05×10⁻¹⁴) [VERIFIED R06]. [VERIFIED]

## 4. Command flow / priority (coherence-aware arbitration)

| Priority | Condition | Action |
|---|---|---|
| 1 | target coherence < floor | route to REFRESH + RETRO_ECC first (read-verify-repair) |
| 2 | write coalescing window | STORE batched, hologram update async |
| 3 | QUERY with resonance urgency | FFT→correlate→IFFT→gate pipeline |
| 4 | PREFETCH | warm L2 at Φ-stride banks |
| 5 | PARK/WAKE | coherence-gated shutdown |

Snoop invalidation by coherence threshold (Resonance-MESI): M > 0.99,
E > 0.95, S > 0.85, I < 0.85 [VERIFIED plan §4.5].

## 5. Falsifiable command behaviors (mapped to P-series)

| Command behavior | Prediction | Falsified if | Status |
|---|---|---|---|
| QUERY latency flat in N | O(DIM log DIM) | latency scales linearly with N at fixed DIM | [PROPOSED] P2 (R09 silicon) |
| REFRESH zero-crossing ≥ 2× retention | t = n·Φ·τ_res | ≤ 1.1× vs uniform refresh | [PROPOSED] P3 |
| RETRO_ECC energy ≥ 40% cut | Eq 47–55 | < 10% vs no-ECC refresh | [PROPOSED] P5 |
| 854 channels collision-free to 60% load | P6 | collision rate > 5% @ 60% | [PROPOSED] P6 |
| PREFETCH sequential > 90% | f_next = f_n + d_avg·Φ | < 75% sequential | [PROPOSED] P7 |
