# 10 — PHI-RAM PACKAGE

> Package type, pin map, die attach, 2.5D interposer placement, 3D stack
> assembly, thermal path, R_th, and the 26.1 °C junction target. The assembly
> is the memory becoming a body: dies divided, then reunited on one substrate.

## 1. Package type

- **2.5D silicon interposer** with Φ-routed traces, hosting the phi-RAM die,
  the hologram-engine die, and 16 phi-HBM stacks.
- **3D stack** of 8 Φ-spaced tiers on the phi-RAM die (the memory die is itself
  a stack: NVM → NV-diamond → holo engines → FLT SRAM → banks → controller →
  PHY → package clock/IO).
- Flip-chip attach (C4 bumps on the interposer; microbumps within the 3D stack
  and for the wide data planes).
- Package substrate: **4.0135 GHz × 10 IO tiers** (f·d = 40,134.946 invariant)
  [VERIFIED C04].

## 2. Interposer placement (2.5D)

```
┌────────────────────────────────── INTERPOSER ──────────────────────────────────┐
│                                                                            │    │
│   ┌────────────┐   ┌────────────┐   ┌────────────┐   ┌──────────────────┐  │    │
│   │  phi-CPU   │   │  phi-GPU   │   │  phi-RAM   │   │ Hologram-Engine  │  │    │
│   │  32 nodes  │   │  32 SMs    │   │  die       │──▶│ die (512 FFT,    │  │    │
│   │  1.589 GHz │   │  3.472 GHz │   │  (32 banks)│   │  3.472 GHz)      │  │    │
│   └────────────┘   └────────────┘   └──────┬─────┘   └──────────────────┘  │    │
│                                            │                                │    │
│   + 16 × phi-HBM stacks (128 GB each, Φ-interleaved, 854 freq channels)    │    │
│   + 2-plane fib-torus mesh (128 nodes, 128 B/cycle, 157.44 TB/s bisection) │    │
│   + optical 4F waveguides (long-haul linear ops, ~2 pJ/b)                  │    │
└──────────────────────────────────────────────────────────────────────────────┘
```

- **Traces**: Φ-routed; width/spacing in Φ ratio per layer; differential pairs
  at Φ-pitch.
- **Repeaters** every 0.7786λ (Law 189 reach, ≤ 8 mm copper); optical beyond.
- **Routers**: resonance-gate array, < 100 ns, 1%/hop loss, no packet below
  C_crit = 0.563263.

## 3. Pin map

- phi-RAM die: **256 pads** (09 §Part A); hologram-engine die: **196 pads**
  (09 §Part B). Φ-spaced pad rings, 2.618 V LVCMOS I/O class, ESD 2 kV HBM /
  500 V CDM.
- PHY×16 + fabric mesh data planes route on interposer microbumps (the wide
  bus is not pad-limited); the pins carry lanes, strobes, clocks, control,
  status, and probes.

## 4. 3D stack assembly (phi-RAM die)

Tier order (bottom → top) with Φ-spaced spacing d_n = d₀·Φⁿ, d₀ = 5 µm:

| Tier | Content | Spacing (µm) |
|---|---|---|
| 1 (bottom) | NVM crossbar (L4) | 5.00 |
| 2 | NV-diamond archive | 8.09 |
| 3 | Hologram engines (L3) | 13.09 |
| 4 | FLT SRAM (L1/L2) | 21.18 |
| 5 | Phi-RAM banks | 34.27 |
| 6 | Controller | 55.45 |
| 7 | PHY | 89.72 |
| 8 (top) | Package clock / IO | 145.16 |

[VERIFIED PACKAGE_SPEC §3]. Logarithmic-Φ spacing eases the thermal gradient
(hot logic → cool NVM) and TSV stress. Power/thermal TSVs **co-located** at
Φ-density (halves effective R_th → 0.0325 K/W path) [VERIFIED F05].

## 5. Thermal path

| Parameter | Spec | Status |
|---|---|---|
| Package path | parallel per-die + co-located TSVs: 0.0325 K/W | [VERIFIED] F05 |
| R_th per die (package) | ≤ 0.1 K/W | [VERIFIED] |
| R_th cold plate | ≤ 0.02 K/W | [VERIFIED] |
| Junction — phi-RAM die | **26.1 °C** (target) | [VERIFIED] F05 |
| Junction — hologram-engine die | **31.5 °C** (target) | [VERIFIED] F05 |
| Junction — all dies | < 100 °C | [VERIFIED] F05/F06 |
| Emission bound | 1.270·σT⁴ at C_crit; spreader emissivity sized for it | [VERIFIED] |
| Cooling floor | T_min = 185.41 K — budget stop, never cool below | [VERIFIED] manifest |

Thermal sanity: RAM die 35 W, holo die 200 W; at R_th ≤ 0.1 K/W (die) + 0.02
K/W (cold plate) over a 25 °C ambient, the holo die (200 W × 0.12 K/W = 24 °C
rise) lands ≈ 49 °C worst-case — the 31.5 °C target is the F05-verified value
with the co-located TSV path, all < 100 °C.

## 6. Assembly sequence

1. Dies fabricated (GAA 3 nm): phi-RAM, hologram-engine + phi-HBM stacks.
2. Dies thinned + TSVs formed (power/thermal co-located, Φ-density).
3. 3D stack bonded tier-by-tier (8 tiers, Φ-spaced).
4. Stack placed on interposer (2.5D, Φ-routed).
5. Optical 4F waveguides aligned on interposer.
6. Substrate + cold plate + spreader assembled.
7. ATE: TEST-13..18 (power, thermal, fabric, council, system EDP).

## 7. Package-level pass criteria

| Test | Criterion |
|---|---|
| F05 | all dies < 100 °C |
| F01 | mesh bisection ≥ 100 TB/s |
| F03 | avg hops ≤ 3 |
| C04 | package clock × IO depth = 40,134.946 |
| TEST-13 | RAM ≤ 35 W · holo ≤ 200 W |
| TEST-14 | all dies < 100 °C; parallel TSV path |
