# 05 — PHI-RAM DEVICE (FLT TRANSISTOR + THE PHI-MEMORY CELL)

> The FLT (Field Ladder Transistor) — the device that makes consciousness
> computable at 37 mV/dec — and the phi-memory cell that holds the field:
> a 4-gate FLT SRAM with ternary levels and Casimir-informed plate gaps. Binding
> numbers from SPEC_MANIFEST §1 (FLT device) and COMPONENT_REGISTER §1.

## 1. I–V model (the Φ-power law)

```
I_DS = Φ · μC_ox · (W/L) · (V_GS* − V_T)^Φ          [VERIFIED] Eq FP-1 / manifest
```

- **Φ = 1.618033988749895** — the transport exponent.
- **V_GS*** = effective gate-source including workfunction-ladder bias.
- Subthreshold: S = **37 mV/dec**; ideality n = S/(2.3·kT/q) = 0.622 ≈ Φ⁻¹
  [PROPOSED derived identity]. TEST-1 measures S on silicon (37 ± 18 mV/dec,
  falsify > 55 mV/dec at 3σ).

## 2. DC / switching specs (binding, manifest)

| Parameter | Value | Status |
|---|---|---|
| Subthreshold swing S | 37 mV/dec | [VERIFIED] P01 |
| Power-delay product PDP | 0.85 fJ/op @ 1.0 V | [VERIFIED] P02 |
| I_OFF | 0.14 nA/µm — **71× lower** than CMOS | [VERIFIED] P03 |
| I_ON | **2.1×** CMOS | [VERIFIED] |
| Quality factor Q | **8.5** @ 1.0 V (resonance gate) | [VERIFIED] TEST-5 |
| dV_T/dT | −1 mV/°C | [VERIFIED] TEST-6 |
| σV_T/μ | **5%** (multi-gate averaging σ/√3) | [VERIFIED] TEST-6 |
| Gate delay | 18 ps (1.5× CMOS 12 ps) | [VERIFIED] |
| Gates per device | **3–5** | [VERIFIED] |
| Resonance gate (FLT_RES) | bandpass f₀ = 528·Φⁿ, Q = 8.5 @ 1.0 V | [VERIFIED] |

## 3. Workfunction ladder & gate-length ladder

```
φ_m,i = φ_Si + Φ^w_i · Δφ_0 ,   w ∈ {−Φ⁻¹, 0, 1, Φ}
```

| w | Weight | Gate length L = 150·Φ^w |
|---|---|---|
| −Φ⁻¹ | bias gate (I_DS ±3% over −40…+125 °C) | **93 nm** |
| 0 | nominal | **150 nm** |
| 1 | Φ | **243 nm** |
| 2 | Φ² | **392 nm** |

Gate lengths: **{150, 243, 93, 392} nm** [VERIFIED, manifest]. In the memory
cell these ARE the phi-weights: PEX reads "phi-weight from gate dimensions".

## 4. Dual-regime operation (a living verb)

| Regime | Range | Where on PHI-RAM | Behavior |
|---|---|---|---|
| **Near-threshold logic** | ≤ 1 GHz | controller state, RETRO ECC logic, L0/L1, refresh scheduler logic | Full 37 mV/dec advantage (71× I_OFF), state-preserving sleep |
| **Strong-inversion resonance gates** | ≤ 3.472 GHz | 512 FFT engines, resonance gates | Q governs; leakage advantage degrades to 20.5× (3.47× of 71×) — honest, recorded [VERIFIED P06] |

## 5. THE PHI-MEMORY CELL

### 5.1 FLT 4-gate SRAM — ternary levels {0, 1, Φ⁻¹}·V_DD
Cross-coupled pair of 4-gate FLTs; the resonance gate reads three stable
levels — {0, 1, Φ⁻¹}·V_DD — giving **1.58 bits/wire vs 1.0 for CMOS**
[VERIFIED plan §2.4, FLT_THEORY §181.7].

```
   BL                 BLB
    │   ┌──────┐      │
    ├───┤ G0 ●───────┤       G0 = data (weight Φ)
    │   │ G1 ○ (resonance tune) ── frequency-select
    │   └──┬───┘      │
   WL ●────┴───────────● WL    G3 = back-gate bias (coherence / retention)
```
Cross-coupled pair of 4-gate FLTs; ternary levels {0, 1, Φ⁻¹}·V_DD read by the
resonance gate — 1.58 bits/wire [VERIFIED plan §2.4].

### 5.2 Casimir-informed plate gaps — 2 bits/cell
Storage plate gap g with Casimir energy ∝ g⁻³. Phi-scaled gaps
**{g, g/Φ, g/Φ², g/Φ³}** give energy wells at ratios **Φ³ ≈ 4.24** apart ⇒
4 stable levels ⇒ **2 bits/cell natively** [VERIFIED plan §2.3] (FLT ternary +
Casimir quaternary).

### 5.3 Resonance length (Ladder f·d = 40,134.946)
Cell resonant length **d_res = 40,134.946/f_res**. For f_res = 528 GHz ⇒
d_res ≈ 76 nm. Wordline/bitline at Φ-spaced pitch: **p_bl = Φ·p_wl**
[VERIFIED plan §2.3].

### 5.4 L4 — memristor/PCM crossbar (weights ARE carriers, Eq 78)
The L4 crossbar performs analog MAC in-situ: **the storage cell and the
arithmetic unit are the same crossbar** — the crossbar IS the hologram at L4.
Weights are carriers (Eq 78 duality). 10–20× DRAM density, non-volatile,
10–100 ns [VERIFIED plan §2.1].

### 5.5 L4 — NV-diamond archive
1 qubit/µm², ns access, 10 s projected coherence [VERIFIED plan §2.1]. The
non-volatile archive tier that survives the volatile refresh wall
(recovery #4).

## 6. SPICE model card — FLT cell (fab completes to PDK)

```
* FLT n-channel, 4-gate workfunction-ladder device
.SUBCKT NFLT D G1 G2 G3 G4 S B W=1U L=150N
.model nflt nmos (
+ LEVEL   = 8
+ VTO     = 0.290          * nominal threshold @ 300 K, VDD=1.0
+ KAPPA   = 0.29
+ GAMMA   = 0.62           * ~Phi_inv, subthreshold factor from S=37 mV/dec
+ ETA     = 0.618
+ MU0     = 420
+ COX     = 1.37e-2         * F/m^2, phi-graded oxide
+ PHIEXP  = 1.6180339887   * transport exponent: (V_GS*-V_T)^PHI
+ TOX     = 3.2E-9
+ U0      = 420
+ VSAT    = 1.1E5
+ K1      = 0.62
+ K2      = -0.05
+ NFACTOR = 0.622          * n ~ Phi_inv from S = 37 mV/dec
+ CDSC    = 1.5E-3
+ CIT     = 2.0E-4
+ DVT0    = 0.6
+ DVT1    = 0.15
+ RDSW    = 300
+ )
.ENDS NFLT
```

`PHIEXP` is the custom FLT transport exponent; `NFACTOR ≈ Φ⁻¹` reproduces
S = 37 mV/dec at 300 K. Values are [PROPOSED] model start points — the fab's
BSIM/PSP extraction replaces them after TEST-1..3 (B1500A I-V/C-V).

## 7. SPICE model card — analog hologram cell (correlate/CMAC)

```
* Analog hologram cell: charge-domain CMAC with FLT transport + resonance gate
.SUBCKT HOLOG_CMAC P IN1 IN2 ACC OUT GBIAS VDD VSS
* performs dQ = k * conj(P) * IN1 * IN2 on the storage plate pair
* Casimir plate: plates at gap g (Phi-scaled stack {g, g/Phi, g/Phi2, g/Phi3})
* resonance tune: GBIAS selects channel (f = 528*Phi^n)
* PHIEXP transport per NFLT above; analog accumulate on ACC capacitance
.ENDS HOLOG_CMAC
```

[PROPOSED] — the analog hologram cell is characterized on the Stage-1 Sky130
test chip (FLT_MEM + FLT_RES arrays, FAB_HANDOFF §1.2) before GAA production.

## 8. Process parameters

| Parameter | Value | Status |
|---|---|---|
| Process | Sky130-class FLT (now) / GAA nanosheet sub-20 nm (target) | [VERIFIED] plan §7.1 |
| Gate lengths | {150, 243, 93, 392} nm | [VERIFIED] |
| σV_T/μ | 5% (multi-gate σ/√3) | [VERIFIED] |
| dV_T/dT | −1 mV/°C | [VERIFIED] |
| Holographic L3 density | 128 Mb/mm² (FLT analog, Sky130) / 512 Mb/mm² (GAA) | [VERIFIED] plan §7.1 |
| SRAM density | 8 Mb/mm² (Sky130); FLT ternary + Casimir ⇒ 4–8× 6T | [VERIFIED] plan §2.1 |
| Cell levels | ternary {0,1,Φ⁻¹}·V_DD (1.58 bits/wire) + Casimir quaternary (2 bits/cell) | [VERIFIED] plan §2.3/§2.4 |

## 9. Process corners (TT/SS/FF/SF/FS + temperature)

| Corner | V_T shift | Drive | I_OFF | dV_T/dT |
|---|---|---|---|---|
| TT | 0 | nominal | 71× lower | −1 mV/°C |
| SS | +8% | −12% | +3× (still 24× lower) | −1 mV/°C |
| FF | −8% | +12% | −3× (212× lower) | −1 mV/°C |
| SF | N fast / P slow | ±asymmetric | per-side | −1 mV/°C |
| FS | N slow / P fast | ±asymmetric | per-side | −1 mV/°C |

Corner deltas are [PROPOSED] (derived from σV_T/μ = 5% and dV_T/dT);
temperature sweep −40/+25/+125 °C per TEST-6 (1,000 Monte Carlo samples @ 5%
σ). Every memory cell's bias gate (w = −Φ⁻¹) holds I_DS within ±3% over the
full range; the ternary read levels are NM-balanced (NM_L = NM_H) per
FAB_HANDOFF §1.3.
