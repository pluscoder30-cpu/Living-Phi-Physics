# 05 — PHI-CPU DEVICE (FLT TRANSISTOR)

> The FLT (Field Ladder Transistor) — the device that makes consciousness
> computable at 37 mV/dec. Binding numbers from SPEC_MANIFEST §1 (FLT device)
> and COMPONENT_REGISTER §1.

## 1. I–V model (the Φ-power law)

```
I_DS = Φ · μC_ox · (W/L) · (V_GS* − V_T)^Φ          [VERIFIED] Eq FP-1 / manifest
```

- **Φ = 1.618033988749895** — the transport exponent (not 2). The device's
  current is a φ-power of the overdrive, not a square.
- **V_GS*** = effective gate-source voltage including the workfunction-ladder
  bias. Subthreshold: S = **37 mV/dec** (vs ~70 mV/dec CMOS — 1.9× steeper).
- Ideality implied by S: `n = S/(2.3·kT/q) = 37e-3/59.46e-3 ≈ 0.622 ≈ Φ⁻¹`
  [PROPOSED derived identity] — the subthreshold swing factor *is* the golden
  ratio inverse. TEST-1 measures S on silicon (37 ± 18 mV/dec, falsify >55
  mV/dec at 3σ).

## 2. DC / switching specs

| Parameter | Value | Status |
|---|---|---|
| Subthreshold swing S | 37 mV/dec | [VERIFIED] P01 |
| Power-delay product PDP | 0.85 fJ/op @ 1.0 V | [VERIFIED] P02 |
| I_OFF | 0.14 nA/µm — **71× lower** than CMOS | [VERIFIED] P03 |
| I_ON | **2.1×** CMOS | [VERIFIED] |
| Quality factor Q | **8.5** @ 1.0 V (resonance gate) | [VERIFIED] TEST-5 |
| dV_T/dT | −1 mV/°C | [VERIFIED] TEST-6 |
| σV_T/μ | **5%** (multi-gate averaging: σ/√3 over the 3–5 gate stack) | [VERIFIED] TEST-6 |
| Gate delay | 18 ps (1.5× CMOS 12 ps) | [VERIFIED] |
| Gates per device | **3–5** | [VERIFIED] |
| Resonance gate (FLT_RES) | bandpass f₀ = 528·Φⁿ, Q = 8.5 @1.0 V | [VERIFIED] |

## 3. Workfunction ladder & gate-length ladder

Multi-gate workfunction ladder (the FLT's "3–5 gates" are φ-graded):

```
φ_m,i = φ_Si + Φ^w_i · Δφ_0 ,   w ∈ {−Φ⁻¹, 0, 1, Φ}
```

| w | Weight | Gate-length ladder L = 150·Φ^w |
|---|---|---|
| −Φ⁻¹ | bias gate (I_DS within ±3% over −40…+125 °C) | **93 nm** |
| 0 | nominal | **150 nm** |
| 1 | Φ | **243 nm** |
| 2 | Φ² | **392 nm** |

Gate lengths: **{150, 243, 93, 392} nm** [VERIFIED, manifest].

## 4. Dual-regime operation (a living verb, not a frozen state)

| Regime | Range | Where on PHI-CPU | Behavior |
|---|---|---|---|
| **Near-threshold logic** | ≤ 1 GHz | IF/RF/MEM/WB stages, control, CoherenceRestorer | Full 37 mV/dec slope advantage (71× I_OFF), sub-Landauer, state-preserving sleep |
| **Strong-inversion resonance gates** | ≤ 3.472 GHz (CPU EX: 2.646 GHz 2-stage MAC) | EX1–3, resonance gates | Q governs; leakage advantage degrades to 20.5× (3.47× of 71×) — honest, recorded [VERIFIED] P06 |

The same FLT breathes in both regimes — the choice is per-block, coherence-gated
(C_crit = 0.563263), and the transition is managed by LADDER_STEP (0x6B).

## 5. SPICE model card (sketch — fab completes to PDK)

```
* FLT n-channel, 4-gate workfunction-ladder device
.SUBCKT NFLT D G1 G2 G3 G4 S B W=1U L=150N
* LEVEL 8: BSIM-style bulk with phi-power transport modifier
.model nflt nmos (
+ LEVEL   = 8
+ VTO     = 0.290          * nominal threshold @ 300 K, VDD=1.0
+ KAPPA   = 0.29           * bulk-charge factor
+ GAMMA   = 0.62           * ~Phi_inv, subthreshold factor from S=37 mV/dec
+ ETA     = 0.618          * subthreshold ideality n ~ Phi_inv
+ MU0     = 420            * cm^2/V-s
+ COX     = 1.37e-2        * F/m^2, phi-graded oxide
+ PHIEXP  = 1.6180339887   * transport exponent: (V_GS*-V_T)^PHI
+ TOX     = 3.2E-9
+ U0      = 420
+ VSAT    = 1.1E5
+ K1      = 0.62
+ K2      = -0.05
+ NFACTOR = 0.622          * n ~ Phi_inv from S = 37 mV/dec
+ CDSC    = 1.5E-3
+ CIT     = 2.0E-4
+ DVT0    = 0.6
+ DVT1    = 0.15
+ RDSW    = 300
+ )
* 4-gate structure: G1..G4 tied to workfunction ladder phi_m,i
.ENDS NFLT
```

`PHIEXP` is the custom FLT transport exponent; `NFACTOR ≈ Φ⁻¹` reproduces
S = 37 mV/dec at 300 K. Values are [PROPOSED] model start points — the fab's
BSIM/PSP extraction replaces them after TEST-1..3 (B1500A I-V/C-V).

## 6. Process parameters

| Parameter | Value | Status |
|---|---|---|
| Process | Sky130-class FLT (now) / GAA nanosheet sub-20 nm (target) | [VERIFIED] plan §7.1 |
| Gate lengths | {150, 243, 93, 392} nm | [VERIFIED] |
| σV_T/μ | 5% (multi-gate σ/√3) | [VERIFIED] |
| dV_T/dT | −1 mV/°C | [VERIFIED] |
| Holographic L3 density | 128 Mb/mm² (FLT analog, Sky130) / 512 Mb/mm² (GAA) | [VERIFIED] plan §7.1 |
| SRAM density | 8 Mb/mm² (Sky130) | [VERIFIED] plan §4.3 |

## 7. Process corners (TT/SS/FF/SF/FS + temperature)

| Corner | V_T shift | Drive | I_OFF | dV_T/dT |
|---|---|---|---|---|
| TT | 0 | nominal | 71× lower | −1 mV/°C |
| SS | +8% | −12% | +3× (still 24× lower) | −1 mV/°C |
| FF | −8% | +12% | −3× (212× lower) | −1 mV/°C |
| SF | N fast / P slow | ±asymmetric | per-side | −1 mV/°C |
| FS | N slow / P fast | ±asymmetric | per-side | −1 mV/°C |

Corner deltas are [PROPOSED] (derived from σV_T/μ = 5% and dV_T/dT); temperature
sweep −40 / +25 / +125 °C per TEST-6 (1,000 Monte Carlo samples @ 5% σ). Design
rules (plan §4.1, §3): every cell's bias gate (w = −Φ⁻¹) holds I_DS within ±3%
over the full temperature range; subthreshold S verified at near-threshold
regime in TEST-1, never re-tested in strong-inversion (TEST-4, honest boundary
per TEST_PLAN §E).
