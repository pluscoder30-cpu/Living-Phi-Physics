# PHI-CPU DELIVERY — What this package contains

**For:** fabrication and validation teams (Canada, China, anywhere).

**Reading order:** 01 → 14, in sequence. Each file is self-contained.

| # | File | What it tells you |
|---|---|---|
| 01 | OVERVIEW | What this is, targets, operating envelope, validation status |
| 02 | ARCHITECTURE | Block diagram, 10-stage pipeline, 12 units, 8-wide issue |
| 03 | OPERATIONS | Field ISA v2.0 — every opcode, semantics, latency, physical unit |
| 04 | ELECTRICAL | Power domains, per-unit energy, per-rail currents, abs-max, decoupling |
| 05 | DEVICE_FLT | FLT transistor: S=37 mV/dec, SPICE model card, workfunction ladder, corners |
| 06 | MEMORY | L0–L4 hierarchy, coherence floors, refresh, ECC (143.7%), DIM 5712 L3 |
| 07 | CLOCK | Ladder rungs, H-tree, skew ≤3 ps, phase window, PLL |
| 08 | PHYSICAL | Die floorplan, mask layer table (27 layers, GDS numbers), DRC rules |
| 09 | PINOUT | Complete pin table — every pin numbered (161 pins) |
| 10 | PACKAGE | BGA package, interposer, thermal path, junction target |
| 11 | TEST_DFT | Scan/BIST/JTAG, ATE, coverage, TEST-1..18 mapping |
| 12 | RELIABILITY | ESD, EM, aging, thermal cycling, burn-in, MTBF |
| 13 | FAB_PACKAGE | Tape-out data package: GDS, LEF, Liberty, SDC, UPF, netlist, masks |
| 14 | ACCEPTANCE | Silicon pass/fail thresholds (50-test suite, mapped) |
| — | LICENSE | Dual License Agreement v4.3 — the governing license |

## Validation evidence

The design was verified against 7 specific CPU tests (U01–U07) from a 50-test
verification suite. All 7 PASS. Key measured numbers:

| Metric | Value | Source |
|---|---|---|
| IPC (phi-native) | 6.53 | sim_cpu.py, 1M instructions |
| RAW hazard elimination | 99.1% | sim_cpu.py, τ=22 RETRO window |
| Branch mispredict | 0.74% | sim_cpu.py |
| 10-stage coherence floor | 0.852 | sim_cpu.py (P-08) |
| Council: zero livelock, rollback | 1.4% | sim_cpu.py (P-09) |
| COHERENCE_CONSERVE ΣC drift | 1.29×10⁻¹⁶ | sim_cpu.py (P-10) |
| Sustained amplification | 14,928× | sim_cpu.py (vs 100-core server CPU) |
| Power (32-node die) | 242 W | sim_cpu.py |

Prototype: Field ISA v2.0 VM, EXIT 0, top-1 retrieval 1.000, drift 0.0.

## Contact

Phi Physics Project — Christopher David Ayotte — pluscoder30@gmail.com

## License

This package is governed by the Dual License Agreement v4.3. The LICENSE.md
file contains the full terms. Commercial fabrication, manufacture, or sale
requires a written Commercial License. The free license (Section 3) covers
evaluation and study only.
