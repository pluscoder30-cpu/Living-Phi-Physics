# 13 — PHI-CPU FAB & PACKAGE (TAPE-OUT DATA PACKAGE)

> The complete file manifest the fab receives, the mask set list, and the MPW
> plan. "Everything": if this package is all a fab receives, they can
> manufacture the PHI-CPU.

## 1. The tape-out file manifest

| # | Deliverable | Format | Contents |
|---|---|---|---|
| 1 | GDSII / OASIS | GDSII + OASIS | full die layout, 27 mask layers (see `08_PHYSICAL.md` §5) |
| 2 | LEF | .lef | abstract views, cell boundaries, pins |
| 3 | DEF | .def | placed/routed design, tile instances |
| 4 | Liberty timing | .lib | FLT cell timing/energy @ TT/SS/FF/SF/FS, −40/+25/+125 °C |
| 5 | SDC constraints | .sdc | 10-stage pipeline, dual-regime clocks (1.589 / 2.646 / 4.161 GHz), skew ≤ 3 ps, Δφ < 55.7° |
| 6 | UPF power intent | .upf | 4 domains (0.618/1.0/1.618/2.618 V), level shifters, isolation, state-retention |
| 7 | Gate-level netlist | .v | post-synthesis netlist with scan |
| 8 | SPICE decks | .sp | FLT model card (LEVEL 8, PHIEXP, NFACTOR≈Φ⁻¹), 27-layer extraction decks |
| 9 | DRC report | .rpt | multi-gate spacing ≥ 200 nm, workfunction metal overlap ≥ 100 nm |
| 10 | LVS report | .rpt | gate grouping < 300 nm, netlist-vs-layout |
| 11 | PEX report | .rpt | parasitic extraction, EM/IR signoff (≤ 5% VDD) |
| 12 | Mask set list | .xlsx | 27 layers with GDS numbers + reticle data |
| 13 | Pinout / ball map | .csv | 161 pins (`09`) + 289 BGA balls (`10`) |
| 14 | Test program | .stil/.wgl | scan/BIST/JTAG patterns, coverage ≥ 98% SA / ≥ 95% trans |
| 15 | Verify suite reference | .py | `sim/verify_suite.py` + `prototypes/phi_cpu_vm.py` — acceptance oracle |
| 16 | Thermal/power model | .csv | per-tile 30.3 W, per-die 242 W, junction 51 °C path |

## 2. Mask set (27 layers, GDS numbers)

`08_PHYSICAL.md` §5 lists every layer: NWELL 1 … METAL5 15, FLT gate metals
FLT_G1–G4 16–19, FLT_AVDD 20, PAD 21, ESD 22, SEAL 23, SCRIBE 24, CAP_MIM 25,
TSV 26, OPTO 27. Stage-1 Sky130 uses layers 1–25 (no TSV/OPTO); the GAA 3 nm
production path adds 26–27.

## 3. MPW plan

| Stage | Foundry | Cost | What ships |
|---|---|---|---|
| **Stage-1 Sky130 MPW** | SkyWater 130 nm | **$14,500** (MPW $10,000 + 2 FLT gate-stack masks $3,000 + package/test $1,500) | 5×5 mm die, 38-pad class; FLT cells, resonance gate, 31-stage RO, **pipelined resonance MAC (4-stage, ×2, 288 ps/stage target)**, pad ring, process monitor (BOM A1–A14) |
| Stage-2 compute proof | 1–4 cores @ ≤ 983 MHz | ATE functional (TEST-7..12) | hologram 253:1 proof, pipeline emulator parity |
| **Production path** | **GAA 3 nm** | full system | 8-tile CPU die (32 nodes), phi-GPU, phi-RAM, hologram die, 2.5D interposer, HBM stacks |

**Stage-1 scope per BOM §A:** FLT_INV ×16, FLT_NAND ×8, FLT_RES ×4, FLT_DFF
×8, FLT_MEM ×4, 31-stage RO (target 107.5 MHz @ Sky130), pipelined resonance
MAC (4-stage, ×2, 288 ps/stage target, BOM A10), 38 Φ-spaced pads, process monitor
(σV_T/μ = 5% target), B1500A characterization service.

## 4. Fab constraints (binding)

- FLT workfunction-ladder gate metals (FLT_G1..G4) — 2 custom masks (BOM A2).
- Gate lengths {150, 243, 93, 392} nm on the ladder; DRC multi-gate spacing
  ≥ 200 nm.
- Liberty timing must reproduce S = 37 mV/dec near-threshold and Q = 8.5 @
  1.0 V for resonance gates.
- Power intent must preserve state-retaining dark-silicon sleep below
  C_crit (Law 172/187) — UPF state-retention required.
- The die must be repackaged onto the 2.5D interposer (BOM C1) for the full
  system; mesh/holo data planes route through interposer metal.
