# 04 — PHI-CPU ELECTRICAL

> Power domains, per-block energy and current, duty cycles, tile/die power
> roll-up, IO levels, operating conditions, absolute maximum ratings, and
> decoupling. Every rail has voltage, current, power, and decoupling spec.

## 1. Power domains (Φ-ladder rails)

| Domain | Pin rail | Voltage | Serves | Regulator |
|---|---|---|---|---|
| Φ⁻¹ | VDD_LL | **0.618 V** | CoherenceRestorer, RETRO ring, idle units (dark-silicon Φ_inv domain) | Φ-ratioed switched-cap, C₀·Φ⁻¹ |
| 1 | VDD | **1.0 V** | Compute units nominal (reference rail) | Φ-ratioed switched-cap, C₀ |
| Φ | VDD_HI | **1.618 V** | Turbo rung F₃₃, HolographicBindUnit | Φ-ratioed switched-cap, C₀·Φ |
| Φ² | VDD_IO | **2.618 V** | IO cells, FLT analog cells, PLL pump transients | Φ-ratioed switched-cap, C₀·Φ² |

## 2. Per-block energy, current, and duty cycle

Per-op energy [VERIFIED, COMPONENT_REGISTER §2] at the unit's operating clock;
typical current = P/V at VDD (1.0 V) unless the block lives on another rail.

| Unit | Per-op energy (pJ) | Op rate (typical) | Typ. current | Duty cycle |
|---|---|---|---|---|
| ResonanceEngine | 5.5 | 1/cyc EX @2.646 GHz | 14.6 µA | 100% of field ops [PROPOSED alloc.] |
| PhaseModulator | 2.8 | 1/cyc EX | 7.4 µA | 62% [PROPOSED] |
| SuperpositionEngine | 2.1 | 1/cyc EX | 5.6 µA | 75% [PROPOSED] |
| FieldTransformer | 5.5 | 1/cyc EX | 14.6 µA | 60% [PROPOSED] |
| CoherenceGate | 0.7 | 1/cyc (all ops) | 1.9 µA | 100% (gate on every op) |
| EntanglementBridge | 3.5 | 1/cyc EX | 9.3 µA | 40% [PROPOSED] |
| RF read (12-bank) | 2.2 | 8R/cyc core | 11.1 µA @1.589 GHz | 100% |
| CoherenceRestorer (×10) | 0.2 | 1/cyc/stage | 0.5 µA each | 100% (per stage) |
| CouncilArbiter (1/tile) | 1.0 | per arbitration | 2.6 µA | 25% [PROPOSED] |
| LadderClockController | 0.6 | per rung step | 1.6 µA | 10% [PROPOSED] |
| FreqIndexMapper | 0.4 | per mem access | 1.1 µA | 100% of mem ops |

Duty cycles are [PROPOSED] activity allocations; the coherence-gated dark
silicon rule (Law 187/172) powers down any unit whose carrier C falls below
C_crit = 0.563263 **without erasure** — FLT analog cells retain carrier state on
charge; wake restores coherence via CoherenceRestorer.

## 3. Tile and die power roll-up

| Item | Power | Status |
|---|---|---|
| Per tile (4 cores + shared L3 + CouncilArbiter) | **30.3 W** | [VERIFIED] manifest headline |
| Per die (8 tiles = 32 nodes) | **242 W** (30.3 × 8) | [VERIFIED] TEST-13 bound ≤ 800 W |
| Strong-inversion leakage note | at 3.47 GHz the FLT slope advantage retains 20.5× (3.47× of 71×) | [VERIFIED] P06 |

Design-budget split per tile [PROPOSED allocation, plan §6.3 basis scaled to
8-wide]: compute units ~15.1 W, regfile (1.63 MB FLT SRAM) ~4.8 W, memory tiers
~7.3 W, clock (H-tree + 51 PLLs + EX domain) ~3.0 W, leakage + analog ~0.1 W —
sum ≈ 30.3 W. The aggregate 30.3 W/tile is [VERIFIED]; the intra-tile split is
a [PROPOSED] allocation to be confirmed by TEST-13 per-die measurement.

**Per-rail current (derived from the VERIFIED 242 W/die roll-up ÷ §1 rail
voltage; [PROPOSED] — fixed by UPF/PEX at signoff, 13_FAB_PACKAGE §4):**

| Rail | Current (derived) | Basis |
|---|---|---|
| VDD_LL 0.618 V | ≈ **4 A** | CoherenceRestorer ×80 + RETRO ring + dark-silicon retention |
| VDD 1.0 V | ≈ **210 A** | compute 15.1 + regfile 4.8 + memory tiers 7.3 W/tile (27.2 W × 8 tiles ≈ 218 W) |
| VDD_HI 1.618 V | ≈ **3 A** | clock 3.0 W/tile share + HolographicBindUnit + turbo rung F₃₃ |
| VDD_IO 2.618 V | ≈ **2.5 A** | IO cells + PLL pump transients |

Power check: 0.618·4 + 1.0·210 + 1.618·3 + 2.618·2.5 ≈ 224 W of the 242 W die;
the residual is leakage + analog (0.1 W/tile split, §3) + pad-ring IO bias.

## 4. IO levels

| Signal class | Rail | Logic low | Logic high | Notes |
|---|---|---|---|---|
| LVCMOS I/O | VDD_IO 2.618 V | ≤ 0.8 V | ≥ 1.8 V | JTAG, UART, control, test (Φ-spaced pads, BOM A11) |
| FLT core signals | VDD 1.0 V | ≤ 0.35 V | ≥ 0.65 V | internal only |
| Differential clocks | PLL_REF / CLK_* | — | 100–800 mV swing | 100 Ω diff |
| Analog coherence probes | COH_PROBE 0–1.618 V | — | — | scaled C-field taps, 1:1 to VDD_HI |

## 5. Operating conditions

| Parameter | Min | Nom | Max | Status |
|---|---|---|---|---|
| Junction temperature | −40 °C | 51 °C target | +125 °C | [VERIFIED] F05 (51.0 °C), TEST-6 chamber |
| Core clock (rung 31) | — | 1.589464 GHz | — | [VERIFIED] C05 |
| EX clock (2-stage MAC) | — | 2.646 GHz | 2.646 GHz | [VERIFIED] G02 |
| Turbo (rung 33) | — | 4.161271 GHz @1.618 V | 4.161271 GHz | [VERIFIED] |
| Power-supply voltage | VDD −5% | VDD | VDD +5% | [VERIFIED] IR-drop rule (≤5% VDD) |

## 6. Absolute maximum ratings (device-level, [PROPOSED] — silicon-testable)

| Parameter | Limit |
|---|---|
| VDD_LL | 0.9 V |
| VDD | 1.2 V |
| VDD_HI | 1.9 V |
| VDD_IO | 3.6 V |
| Input voltage (any pad) | VDD_IO + 0.3 V |
| Storage temperature | −65 °C … +150 °C |
| ESD (HBM / CDM) | 2 kV / 500 V |
| Latchup trigger current | 100 mA |

## 7. Decoupling requirements

| Rail | On-die MIM | On-package ceramic | Placement |
|---|---|---|---|
| VDD_LL 0.618 V | 40 nF | 40 µF | near CoherenceRestorer + RETRO ring |
| VDD 1.0 V | 30 nF | 30 µF | near compute quadrants |
| VDD_HI 1.618 V | 25 nF | 25 µF | near HolographicBindUnit + turbo |
| VDD_IO 2.618 V | 20 nF | 20 µF | at pad ring |

Capacitor values are Φ-ratioed (C_k = C₀·Φ^k, BOM C7); the on-die/on-package
split is [PROPOSED]. Target: dynamic droop ≤ 5% VDD on any 1-cycle 8-wide burst
at EX 2.646 GHz; IR drop ≤ 5% VDD at 242 W/die with co-located power TSVs
(0.0325 K/W path, [VERIFIED] F05).

## 8. Timing closure contract

| Parameter | Budget | Status |
|---|---|---|
| H-tree end-point skew | ≤ 3 ps/domain (measured end-point 2.79 ps) | [VERIFIED] |
| Phase window | Δφ < 55.7° | [VERIFIED] |
| PLL RMS jitter | ≤ 1.0 ps | [PROPOSED] |
| Cycle-to-cycle jitter | ≤ 2 ps | [PROPOSED] |

## 9. Power sequencing and brown-out

| Item | Spec | Status |
|---|---|---|
| Power-up order | VDD_LL (0.618) → VDD (1.0) → VDD_HI (1.618) → VDD_IO (2.618), 100 µs min ramp-to-ramp; IO pads tri-stated until POWER_GOOD | [PROPOSED] |
| POWER_GOOD release | asserted when all four rails within ±5% VDD nom AND PLL_REF 528.0 MHz stable; de-asserts core reset on LADDER_STEP readiness | [PROPOSED] |
| Brown-out | any rail < 90% nominal for > 1 µs → brown-out reset (BOR); re-POWER_GOOD after recovery; BOR preserves FLT carrier charge (Law 172) | [PROPOSED] |
| Sequencing violations | reverse-order ramp (VDD_IO before VDD_LL) clamped by ESD diodes; not a normal-mode entry | [PROPOSED] |

POWER_GOOD pin 59 (09 §C), brown-out status via COH_STATUS0–2 (11 §2).
