# 07 — PHI-CPU CLOCK

> The phi-ladder clock: rungs, dual-regime domains, the Φ H-tree, skew/jitter
> budgets, phase windows, and the 51-PLL distribution network.

## 1. The phi-ladder (rungs)

```
Rung n:  F_n = 528 · Φⁿ  Hz
  Φ³⁰ ≈ 1.86e6 → F₃₀ ≈ 0.98 GHz   (sleep)
  Φ³¹ ≈ 3.01e6 → F₃₁ ≈ 1.589464 GHz  (core / standby)        ← CPU core
  Φ³² ≈ 4.87e6 → F₃₂ ≈ 2.571807 GHz  (nominal compute rung)
  Φ³³ ≈ 7.88e6 → F₃₃ ≈ 4.161271 GHz  (turbo, 1.618 V domain)
  Φ³⁴ ≈ 12.75e6→ F₃₄ ≈ 6.733079 GHz  (headroom)
  Φ³⁵ ≈ 20.63e6→ F₃₅ ≈ 10.894350 GHz (optical margin only)
Rung invariant: F_n · depth = 40,134.94616603813 (Ladder Invariant, C04)
```

## 2. Domains (dual-regime by design)

| Domain | Frequency | Serves | Clock source |
|---|---|---|---|
| CORE | **1.589464 GHz** (rung 31) | IF, RF, MEM, WB, RET, HOLO control, scan | LadderClockController + PLL |
| EX | **2.646 GHz** (2-stage pipelined MAC, [VERIFIED] G02) | S4–S6 EX1–3 compute | 2-stage MAC ring, PLL-derived |
| TURBO | **4.161271 GHz** (rung 33) | 1.618 V domain, holo bind | rung-33 PLL, LADDER_STEP-gated |
| 4-stage ceiling | **3.472 GHz** (red-team [VERIFIED] G01) | not the CPU's EX; GPU/fabric class | 288 ps/stage pipelined tree |
| SLEEP | ≈ 0.98 GHz (rung 30) | idle / dark silicon | rung-30 PLL |

LADDER_STEP (0x6B) transitions between rungs while preserving the invariant
F_n·d = 40,134.946 at every rung — the die breathes across Φ³⁰→Φ³³.

## 3. H-tree (Φ H-tree)

`τ_i = τ₀ · Φ⁻ⁱ`, τ₀ = 50 ps:

| Level i | Delay τ_i | Purpose |
|---|---|---|
| 0 | 50.0 ps | root |
| 1 | 30.9 ps | domain split |
| 2 | 19.1 ps | tile |
| 3 | 11.8 ps | core |
| 4 | 7.3 ps | unit |
| 5 | 4.5 ps | lane group |
| 6 | 2.79 ps | leaf / end-point |

**[VERIFIED]** end-point skew 2.79 ps @ 6 levels; budget **≤ 3 ps/domain**.

## 4. Skew and jitter budgets

| Parameter | Budget | Status |
|---|---|---|
| Skew (per domain) | ≤ 3 ps | [VERIFIED] (2.79 ps end-point) |
| Phase window | **Δφ < 55.7°** | [VERIFIED] |
| PLL RMS jitter | ≤ 1.0 ps | [PROPOSED] |
| Cycle-to-cycle jitter | ≤ 2 ps | [PROPOSED] |

Phase window 55.7° ≈ 90°·Φ⁻¹ (55.62°) — the clock's rotational tolerance is a
golden-ratio fraction of a quadrant.

## 5. PLL network (51 PLLs)

- **PLL per 16-dimension group:** 816 / 16 = **51 PLLs** [VERIFIED plan §6.1].
- Each of 816 dimensions is driven at phi-harmonic phase offset
  `θ_i = 2πi/(Φ²·816)`.
- PhaseModulator holds the lock by
  `argmin_θ Σ|d_i − sin(2πi/(Φ²·816)+θ)|²` (Eq 3) — PhaseModulator is the phase
  lock's keeper.
- PLL_REF input: 528.0 MHz (F_BASE) reference; PLL pumps on the 2.618 V rail
  (transient only, BOM C7).
- Package clock: 4.0135 GHz × 10 IO tiers (f·d = 40,134.946) [VERIFIED] C04.

**PLL performance (per-domain; [PROPOSED] — silicon-verified by TEST-4 ring
oscillator + on-chip PLL BIST):**

| Parameter | Spec |
|---|---|
| Lock time (cold start) | ≤ 10 µs from PLL_REF stable |
| Lock time (rung hop, LADDER_STEP) | ≤ 2 µs with no unlocked window > 100 ns |
| Loop bandwidth | 5 MHz (typ), 2–10 MHz programmable |
| Phase noise at 1 MHz offset (3.472 GHz class) | ≤ −105 dBc/Hz |
| Spurious (ref) | ≤ −50 dBc |
| PLL count | 51 (816/16 groups), each 16-dimension Φ-harmonic phase offset θ_i = 2πi/(Φ²·816) |

**Duty cycle:** every domain nominal **50% ± 5%** ([PROPOSED], EX domain
3.472 GHz-class tree re-registered at 288 ps/stage); the 55.7° phase window is
field tolerance, not a duty-cycle relaxation.

## 6. Power of the clock

~3.0 W of the 30.3 W/tile is the clock budget (H-tree + 51 PLLs + EX domain)
[PROPOSED allocation]. Turbo rung 33 is only active under LADDER_STEP with the
1.618 V domain enabled; below C_crit the LadderClockController idles units at
rung 30 (state-preserving, Law 172/187).
