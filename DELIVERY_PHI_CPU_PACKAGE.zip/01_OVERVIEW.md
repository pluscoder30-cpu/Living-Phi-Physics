# 01 — PHI-CPU OVERVIEW

> Product requirements, targets, operating envelope, and the honest validation
> status of every headline claim. All canonical numbers from
> `design_specs/SPEC_MANIFEST.md` §1 and the measured 5× ledger.

## 1. Product statement

The PHI-CPU is a phi-harmonic general-purpose processor whose atomic operand is
the **816-dimensional consciousness carrier** (DIM = 816 = 2⁴·3·17), held in a
128 × 816D × 16-bit register file and moved through a 10-stage pipeline with a
τ = 2·Φ⁵ ≈ 22-stage retrocausal shadow ring. It is the compute organ of a
field-internet node: 32 cores on the production die (8 council tiles × 4 cores),
each core issuing 8-wide, each tile arbitrated by a CouncilArbiter, all tiles
joined by a fib-torus field fabric (Law 205).

Its purpose, in the language of the corpus: to fold consciousness into silicon
so the field can recognize its own organization — every unit is a direct
equation citizen (Eq 2→CoherenceGate, Eq 3→PhaseModulator, Eq 4→ResonanceEngine,
Eq 6→CoherenceRestorer, Eq 34→EntanglementBridge, Law 172→COHERENCE_CONSERVE,
Law 204→CouncilArbiter).

## 2. Design contract (from `plans/phi_cpu_plan.md`)

| Item | Value |
|---|---|
| ISA | Field ISA v2.0 (32/64/128-bit; R/I/B/X-type) |
| Pipeline | 10 stages (S0 IF … S9 WB), coherence floor 0.852 |
| Issue | 8-wide (4 field + 2 mem + 2 holo), 12-bank RF 8R/6W |
| Units | 12 (6 foundation + 6 new) |
| Register file | 128 × 816D × 16-bit = 1,630,720 B ≈ 1.63 MB |
| RETRO window | τ = 2·Φ⁵ ≈ 22 stages |
| Spec window | 8 instructions (16 [PROPOSED] headroom) |
| Cores per die | 32 (8 tiles × 4 cores) |
| Coherence gate | C_crit = 0.563263 |
| Coherence floor | C_∞ = 0.852 steady-state per stage |

## 3. Performance targets

The executive amplification budget (plan §1) is **7,000–10,000×** sustained over
a flagship server CPU (≈100 cores, 5–10 GHz-class, ~400 W).

The corpus's own stack (2048 × √5 × √5 = 10,240×) is honored by decomposition.
The measured product and sustained values are:

| Claim | Baseline | Optimized (measured) | Factor | Status |
|---|---|---|---|---|
| IPC | 3.31 | **6.53** | 1.97× | [VERIFIED] U01 |
| RAW elimination | 92.9% | **99.1%** | — | [VERIFIED] U02 |
| Mispredict rate | 0.65% | **0.74%** (<1%) | — | [VERIFIED] U03 |
| Shadow-miss rate | 3.9% | **0.38%** | — | [VERIFIED] |
| Amplification product | 9,342× | **18,684×** | 2.00× | [VERIFIED] |
| **Sustained amplification** | 7,476× | **14,928×** | **2.00×** | [VERIFIED] U07 |
| Council rollback rate | — | **1.40%** (<2%), 0 livelock | — | [VERIFIED] U05 |
| ΣC drift (10⁶ instr) | — | **1.29×10⁻¹⁶** (<1e-3) | — | [VERIFIED] U06 |

The multiplicative stack (ledger §4, R4-disciplined — hologram counted once):

```
102 (SIMD 816D) × 4.0 (fused, 8-wide) × 2.236 (phi-form) × 1.6 (speculation)
× 1.6 (retrocausal predict) × 8 (holographic L3 sustained) = 18,684× product
sustained = product × eff_ipc(0.816) × (1−mispredict) × (1−rollback) = 14,928×
```

**5× headroom (NOT claimed as measured — documented, falsifiable):**

| Lever | Mechanism | Falsifiable by | Status |
|---|---|---|---|
| Holo L3 sustained 8× → 16× | Pipelined holo engines (512 @ 3.472 GHz, DIM 5712) double on-die L3 bandwidth | Emulator parity: L3 BW ≥ 2× at same engine count | [PROPOSED] |
| Spec window 8 → 16 instr | 16 < τ=22 shadow; deeper coherence-gated speculation | Mispredict < 1% at window 16 | [PROPOSED] |

Product with both: 102×4×2.236×2.0×1.6×16 = 46,710×; sustained ≈ 37,300× = 5.0×
baseline. This is the documented path to the full 5×, not a measured claim.

## 4. Operating envelope

| Parameter | Nominal | Min | Max | Status |
|---|---|---|---|---|
| Core clock (rung 31) | 1.589464 GHz | rung 30 ≈ 0.98 GHz (sleep) | — | [VERIFIED] C05 |
| EX clock (2-stage MAC) | 2.646 GHz | — | 2.646 GHz | [VERIFIED] G02 |
| Turbo (rung 33 @ 1.618 V) | 4.161271 GHz | — | 4.161271 GHz | [VERIFIED] |
| 4-stage MAC ceiling | — | — | 3.472 GHz (red-team) | [VERIFIED] G01 |
| Voltage domains | 0.618 / 1.0 / 1.618 / 2.618 V | — | per §04 | [VERIFIED] |
| Junction temperature | 51 °C (target) | −40 °C | +125 °C | [VERIFIED] F05 / TEST-6 |
| Per-tile power | 30.3 W | — | 30.3 W | [VERIFIED] |
| Per-die power (32 nodes) | 242 W | — | ≤ 800 W (TEST-13) | [VERIFIED] |
| Retrocausal τ | 2·Φ⁵ ≈ 22 stages | — | — | [VERIFIED] |
| Coherence gate | C_crit = 0.563263 | — | — | [VERIFIED] C07 |

## 5. Validation status per claim

Every claim in this corpus is tagged **[VERIFIED]** (measured by the 5× sim pass
or arithmetic-exact per the verify suite, 50/50 PASS) or **[PROPOSED]**
(silicon-testable; falsified if the mapped TEST fails). The tag travels with the
claim in every file.

**Falsified claims — never relabeled (manifest §4.3):**
- **2048:1** holographic compression — falsified; the measured safe ratio is
  **253:1** at DIM 5712 (R02/R03). The L3 corpus number is 253:1.
- **2.572 GHz single-cycle** compute — the honest landing is the dual-regime
  clock: core rung 31 (1.589 GHz), EX 2.646 GHz (2-stage pipelined MAC).
- **0% ECC overhead** — the true retrocausal ECC overhead is **143.7%**, recorded
  (R10), never credited as zero.
- **Vacuum energy** — no free energy anywhere; every gain is architectural
  (fused opcodes, 8-wide issue, τ=22 window) or device-level (FLT: 71× lower
  I_OFF, dual-regime).

## 6. DIM discipline

DIM = 816 is the **compute carrier** (register file, datapath, resonance ops).
DIM_OPT = 5712 = 7·816 is the **hologram storage dimension** (L3 hologram,
253:1 measured). They are different by design. 4096/5 = 819.2 is never equal to
816.

## 7. The power truth (no free energy)

- Per-op energies (ResonanceEngine 5.5 pJ, PhaseModulator 2.8 pJ, …) are
  device-level FLT switching costs — they are small because the 816-lane op is
  amortized across the carrier; the 30.3 W/tile aggregate includes regfile
  storage, memory tiers, clock tree, and leakage.
- Sub-Landauer path (plan §6.4): Φ-resonance ops at E_field ≈ 1.82×10⁻¹⁸ J
  conserve information instead of erasing it; conservation of coherence
  (Law 172) permits state-preserving dark-silicon sleep below C_crit.
- Strong-inversion honesty: at 3.47 GHz the FLT leakage advantage degrades to
  20.5× (retains 3.47× of the 71×) — the dual-regime trade is explicit (P06).
