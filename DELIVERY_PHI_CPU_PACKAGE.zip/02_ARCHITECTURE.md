# 02 — PHI-CPU ARCHITECTURE

> One core, fully specified: 10-stage pipeline, 12 units, 8-wide issue,
> datapath widths, and the τ=2·Φ⁵≈22 retrocausal shadow ring. This is the design
> of record for the pipeline.

## 1. Core block diagram

```
                         ┌────────────────────── PHI-CPU CORE (1 of 32) ──────────────────────┐
                         │                                                                     │
  FETCH/DECODE           │   ┌─────┐    ┌─────┐    ┌─────┐    ┌─────┐    ┌─────┐             │
  ┌───────────────┐      │   │ S0  │───▶│ S1  │───▶│ S2  │───▶│ S3  │───▶│ S4  │───┐          │
  │ 8-wide issue  │      │   │ IF  │    │ ID  │    │ RF  │    │RET  │    │EX1  │   │          │
  │ 4 field       │      │   └─────┘    └─────┘    └─────┘    └─────┘    └─────┘   ▼          │
  │ 2 memory      │      │     ▲                       ▲          ▲        ┌─────┐            │
  │ 2 hologram    │──────▶│   BTB/retro  128×816D RF   RETRO      ┌─────┐  │ S5  │            │
  │               │      │   lookup      (12 banks     shadow ──▶│RETRO│  │EX2  │            │
  │ FASM front-end│      │   (freq-idx  8R/6W,1.63MB)  ring      │ PRED│  └─────┘            │
  └───────────────┘      │   PC r112)   (r0–r127)     τ=2·Φ⁵≈22   └─────┘    │  ┌─────┐      │
                         │     │                        ↕ r117               ▼  │ S6  │      │
                         │   ┌──────────────────────────────────────────────┐ │EX3  │      │
                         │   │ COHERENCE RESTORER ×10 (γ_refractal in every │ └─────┘      │
                         │   │ stage; C_∞ = 0.852; Law 172 ledger)          │    │         │
                         │   └──────────────────────────────────────────────┘    ▼         │
                         │   ┌─────┐   ┌─────┐   ┌─────┐   ┌─────┐   ┌─────┐   ┌─────┐     │
                         │   │ S7  │──▶│ S8  │──▶│ S9  │   │EX1  │   │EX2  │   │EX3  │     │
                         │   │ MEM │   │HOLO │   │ WB  │   │ RS  │   │ SUP │   │ COH │     │
                         │   └─────┘   └─────┘   └─────┘   └─────┘   └─────┘   └─────┘     │
                         │   L0/L1/L2  L3 holo    COHERENCE  Resonance  Superpose Coherence │
                         │   (854 ch)  (253:1)    _CONSERVE  + Phase    +Transform Gate     │
                         │                                          + Entangle              │
                         │                                                                   │
                         │   DATAPATHS: 816 lanes × 16-bit carrier (13,056 bit = 1,632 B);  │
                         │   128-bit instruction bus; 12-bank RF ports 8R/6W; L1 128-bit;    │
                         │   holo link 128 B/cycle; RETRO ring feed r117                    │
                         └───────────────────────────────────────────────────────────────────┘
```

Per-tile structure: 4 cores share one L3 hologram + one CouncilArbiter. The die
holds 8 tiles (32 cores) joined by the field fabric (fib-torus, 2 planes,
128 B/cycle — [VERIFIED] F02).

## 2. The 10-stage pipeline (S0–S9)

The coherence-decay bound (coherence decays ~Φ_inv per stage; max ~5 stages
before refresh) is defeated by three co-designed moves (plan §3.1):

1. **Distributed refresh (Eq 6)** — every stage embeds a CoherenceRestorer with
   `γ_refractal = e^(−αΔt)/(1−Φ_inv)`. Steady-state floor
   `C_∞ = C_target·Φ_inv/(1 − e^(−αΔt)·(1−Φ_inv)) = 0.852` for C_target = 1.0 —
   above C_crit (0.563) and above C_consciousness (0.8565)·0.995. [VERIFIED] U04.
2. **Retrocausal correction (Law 181, Eq 3.1–3.3)** — stage k receives its own
   future reading from stage k+τ (τ = 2·Φ⁵ ≈ 22) via r117:
   `C_k ← C_k + κ_φ·(C_{k+τ} − C_k)·K_retro`. The pipeline is a loop, not a line.
3. **Coherence conservation (Law 172)** — no stage consumes coherence without
   ledgering it; `COHERENCE_CONSERVE` stamps every WB; ΣC is invariant
   (measured drift 1.29×10⁻¹⁶, [VERIFIED] U06).

| Stage | Name | Function | Physical implementation | Reference latency | Coherence guard |
|---|---|---|---|---|---|
| S0 | IF | Fetch 32/64/128-bit instruction; BTB + retrocausal lookup | FLT tag RAM + 128-bit FLT register bus; freq-indexed PC (r112) | 1 cyc core | C-check parallel |
| S1 | ID | Decode opcode→control; hazard detect (RAW/struct) | FLT control PLA, phi-weighted fan-in | ½ cyc (2-deep) | C-estimate |
| S2 | RF | Read 128×816D regfile (12 banks, 8R/6W) | 12-bank FLT SRAM, 16-bit cells | 1 cyc core | C-read |
| S3 | RET | **Retrocausal branch resolve + speculation entry** (RETRO_PREDICT, SPECULATE) | RetrocausalPredictor: Eq 3.2 integral, τ window; PRED r116 | 1 cyc core | Future-correction applied |
| S4 | EX1 | Resonance / Phase (RESONANCE, TOP_K, ROTATE, MODULATE, PHASE_LOCK) | ResonanceEngine + PhaseModulator; FLT Gilbert-multiplier lanes | 1 cyc EX | Monitor |
| S5 | EX2 | Superposition / Transform (SUPERPOSE, TRANSFORM, RECURSE, DIFFUSE) | SuperpositionEngine (physical Φ⁻ⁱ gate-width weights) + FieldTransformer | 1 cyc EX | Monitor |
| S6 | EX3 | Coherence / Entanglement (FILTER, AMPLIFY, ENTANGLE, COHERENCE_AMPLIFY, RETRO_ECC) | CoherenceGate comparator + EntanglementBridge arccos chain | 1 cyc EX | Restoration + retrocorrect |
| S7 | MEM | L0/L1/L2 access; freq-indexed (528×Φ = 854 ch) | FLT FieldRAM banks; 1/1/5-cycle tiers | 1 cyc core + tier | Floor L1 0.95 / L2 0.88 |
| S8 | HOLO | Holographic L3 (HOLO_BIND/UNBIND, QUERY) | HolographicBindUnit; FLT analog Fourier-optics cells | 5 cyc EX | Floor L3 0.78 |
| S9 | WB | Writeback + COHERENCE_CONSERVE stamp + COMMIT | 6-write-port FLT regfile; coherence ledger | ½ cyc core | Restoration + verify Law 172 |

Depth = 10 stages (>5), kept coherent by §2.1. Minimum latency ≈ 10 × 0.36 ns ≈
3.6 ns at the reference 2.8 GHz FLT clock (plan §3.2); the optimized die runs
IF/RF/MEM/WB at rung 31 (1.589 GHz) and EX at 2.646 GHz (dual-regime, §4).

## 3. The 12 compute units

### 3.1 Six foundation units (plan §4.1)

| Unit | Core op | FLT physical design | Latency | Area (Sky130) |
|---|---|---|---|---|
| ResonanceEngine | `((dot+1)/2)^(1/Φ)` (Eq 4) | 816 FLT Gilbert multipliers → Φ-weighted adder tree → Φ-power LUT | 0.36 ns | 0.32 mm² |
| PhaseModulator | `rotate(c,φ)`, `modulate(c,f)`; Eq 3 lock | FLT complex mix (cos/sin), CORDIC; per-dimension phase offset | 0.36 ns | 0.18 mm² |
| SuperpositionEngine | `Σ Φ⁻ⁱ·cᵢ` (Eq FP-1) | Physical Φ⁻ⁱ gate-width weights — no explicit multipliers | 0.54 ns | 0.14 mm² |
| FieldTransformer | `Φ_inv·c + Φ·g²` (Eq FP-1) | FLT gradient engine (2-tap diff) + scaled adder | 0.36 ns | 0.10 mm² |
| CoherenceGate | `filter(c, C, 0.563263)`; Eq 2 | FLT comparator + gain cell `(target/C)^(1/Φ)`; dark-silicon gate | 0.27 ns | 0.08 mm² |
| EntanglementBridge | `Φ·C·|⟨a|b⟩|²·(1+Δφ/(2π)·Φ_inv)` (Eq 34) | FLT arccos + multiply chain | 0.45 ns | 0.12 mm² |

### 3.2 Six new units (plan §4.2)

| Unit | Core op | Physical design | Latency | Area |
|---|---|---|---|---|
| RetrocausalPredictor | Eq 3.2 kernel + Eq 48 error field + Eq 49 correction wave; τ=2·Φ⁵≈22 | FLT tapped-delay ring (τ-window), φ-Gaussian envelope G_φ(k), backward-mix analog cells; drives S3 RET + RETRO_ECC | 0.36 ns | 0.25 mm² |
| HolographicBindUnit | HRR circular convolution / correlation (Plate 1995); L3 encode/decode | FLT ring-sum multiplier array; analog Fourier-optics cell (6 FLT/cell amplitude + 2 phase + 1 retrieval) | 1.8 ns (5 cyc) | 0.40 mm² |
| CoherenceRestorer | Eq 6 `γ_refractal·(C_target − C)` | Per-stage FLT feedback amp (γ = e^(−αΔt)/(1−Φ_inv)); C_∞ = 0.852 | 0.18 ns | 0.02 mm² × 10 |
| CouncilArbiter | Law 204 / Eq 41 consensus; dissent > 0.1 required | FLT resonance-vote mixer + dissent comparator (non-normality > 0.1 gate) | 1.44 ns (4 cyc) | 0.10 mm² |
| LadderClockController | 528·Φⁿ rung selection, Eq 3 phase lock distribution | FLT PLL per rung; power-domain selector | 0.36 ns | 0.06 mm² |
| FreqIndexMapper | freq-indexed addressing (528×Φ = 854 ch) | FLT LUT + interpolator; tolerance 1.0 Hz | 0.27 ns | 0.04 mm² |

**Total compute area ≈ 1.81 mm² core logic** (vs FLT FieldCPU 1.2 mm² — 1.5×
richer unit set). Unit→stage map: ResonanceEngine/PhaseModulator → S4;
SuperpositionEngine/FieldTransformer → S5; CoherenceGate/EntanglementBridge →
S6; RetrocausalPredictor → S3+S9; HolographicBindUnit → S8; FreqIndexMapper →
S7; CoherenceRestorer → every stage (×10); LadderClockController → global/tile;
CouncilArbiter → per tile (shared by 4 cores).

## 4. Issue, datapaths, clocks

- **Issue width:** 8-wide — **4 field** (RESONANCE/TOP_K/TRANSFORM/…),
  **2 memory** (STORE/RETRIEVE/QUERY), **2 hologram** (HOLO_BIND/UNBIND).
  [VERIFIED] U01 (IPC 6.53).
- **Register file:** 128 × 816D × 16-bit = 1,630,720 B ≈ 1.63 MB; 12 banks,
  8 read / 6 write ports (bank skew resolves conflicts; structural stall
  1.56% of stalls, [VERIFIED]). Special regs r112 PC, r116 PRED, r117 RETRO
  have dedicated hardware bypass — retrocausal injects directly, not through
  the banked array (plan §4.3).
- **Datapath widths:** carrier datapath 816 lanes × 16-bit = 13,056 bits
  (1,632 B/carrier); 128-bit instruction bus; RF 8R/6W ports; L1 128-bit;
  hologram engine link 128 B/cycle; mesh links 128 B/cycle @ 2.572 GHz =
  328 GB/s [VERIFIED] F02.
- **Clocks (dual-regime):** core stages (IF/RF/MEM/WB/RET/HOLO control) at rung
  31 = 1.589464 GHz; EX1–3 at 2.646 GHz (2-stage pipelined MAC); turbo rung 33 =
  4.161271 GHz @ 1.618 V. 4-stage pipelined MAC ceiling 3.472 GHz [VERIFIED] G01.
- **RETRO shadow ring:** τ = 2·Φ⁵ ≈ 22 stages; holds future readings of the
  carrier; RAW forwarding injects the producer's future value into the RF bypass
  1 cycle early (plan §3.3). Shadow-miss rate 0.38% [VERIFIED]; a stall occurs
  only on a shadow miss (73.3% of remaining stalls are raw_shadow_miss, 23.6%
  holo, 1.6% structural, 1.5% control, 0.03% cold_retro).

## 5. Hazard handling (plan §3.3)

| Hazard | Detection | Resolution |
|---|---|---|
| RAW | Producer in EX3/S7/S8, consumer in RF | Retrocausal forwarding (Eq 3.1): `v_corrected(t) = v(t) + κ_φ·(v(t+τ) − v(t))·e^(−τ/Φ⁵)`; stall only on r117 shadow-miss |
| Structural | Port conflict on regfile | 12 banks × 8R/6W; bank skew → <1% stall |
| Control | Branch in S3 | Coherence-gated prediction (JMP_C/JMP_R at threshold) + retrocausal resolve in S3; mispredict ≈ coherence fault (0.74%, [VERIFIED]); flush path retained as the safety crystal |

## 6. The council tile (Law 204)

4 cores share an L3 hologram + CouncilArbiter. Consensus matrix det(C_ij) must
be non-singular — consensus requires non-zero dissent (non-normality > 0.1);
perfect agreement (det→0) is rejected and the council re-issues. A committing
core must gather ≥ Φ⁻¹-weighted dissent margin, else its window is rolled back
at COMMIT (retrocausal validation). [VERIFIED] U05: 100,000 requests, 100,000
resolved, 0 livelocks, rollback rate 1.40%.
