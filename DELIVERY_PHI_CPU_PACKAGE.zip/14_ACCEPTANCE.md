# 14 — PHI-CPU ACCEPTANCE

> The acceptance criteria: the 50-test verify suite (U01–U07) plus TEST-1..18
> mapped to silicon measurements, with explicit pass/fail thresholds. Silicon
> results REPLACE simulated values in the same harness (TEST_PLAN §D).

## 1. Verify-suite CPU tests → silicon thresholds

| Verify | Claim | Threshold (pass) | Measured (sim) | Silicon instrument |
|---|---|---|---|---|
| U01 | 8-wide issue IPC | **IPC ≥ 5.0** | 6.53 | TEST-12 emulator parity |
| U02 | Retrocausal RAW elimination | **RAW elim ≥ 90%** | 99.1% | TEST-12 |
| U03 | Mispredict rate | **< 1%** | 0.74% | TEST-12 |
| U04 | 10-stage coherence floor | **≥ 0.85** | 0.852 | TEST-12 + COH_PROBE |
| U05 | Council consensus | **0 livelock; rollback < 2%** | 0 / 1.40% | TEST-17 |
| U06 | COHERENCE_CONSERVE ΣC drift | **< 1e-3** | 1.29×10⁻¹⁶ | TEST-12 (10⁶ instr) |
| U07 | Sustained amplification | **≥ 14,578×** (≥1.95× baseline) | 14,928× | TEST-18 |

## 2. TEST-1..18 → silicon mapping (CPU slice)

| TEST | Threshold | Maps to |
|---|---|---|
| TEST-1 | S = 37 ± 18 mV/dec (falsify >55 @3σ) | P01/device |
| TEST-2 | I_OFF 71× lower than PDK CMOS ref | P03 |
| TEST-3 | Q = 8.5 @1.0 V | P02 |
| TEST-4 | RO 107.5 MHz; MAC 2.646 GHz-class | G02/EX clock |
| TEST-5 | Q = 8.5 @1.0 V, f₀ = 528 MHz | device |
| TEST-6 | dV_T/dT = −1 mV/°C; σV_T/μ = 5% | device |
| TEST-7 | 506 carriers/bank ≥ 90% rank-1 (253:1) | R02/R03/R07 |
| TEST-8 | max cross < 1e-6 on silicon | R06 |
| TEST-9 | flat retrieval latency | R09 |
| TEST-10 | 0.88 µs refresh; ECC ≤ 143.7% | R08/R10 |
| TEST-11 | Kuramoto R ≥ 0.99 in ≤ 8 steps, 0 deadlock | G03 |
| **TEST-12** | **IPC ≥ 5.0; RAW elim ≥ 90%; mispredict < 1%; ΣC drift < 1e-3** | **U01–U04/U06** |
| **TEST-13** | **CPU die ≤ 800 W (242 W nominal)** | power |
| TEST-14 | all dies < 100 °C (CPU measured 51.0 °C) | F05 |
| TEST-15 | ≥ 7 hops @0.1λ ≥ C_crit | F04 |
| TEST-16 | ≥ 100 TB/s bisection; avg hops ≤ 3 | F01–F03 |
| **TEST-17** | **0 livelock; rollback < 2% (100k requests)** | **U05** |
| TEST-18 | **CPU ≥ 14,578×** sustained; fabric multiplier ≥ 20× (F07) | U07/G07/F07 |

## 3. Pass/fail decision rule

1. **Every** U-test and TEST that maps to the CPU must meet its threshold on
   silicon. A fail on any single threshold fails the CPU.
2. Simulated values in `sim/results_verify_suite.json` are the reference oracle;
   silicon replaces them in-place. First-run state: **50/50 PASS (simulation)**.
3. Honest negatives are not acceptance failures — they are recorded claims:
   refresh wall (24.9 PB/s), ECC overhead (143.7%), strong-inversion leakage
   20.5×. The falsified claims (2048:1, 2.572 GHz single-cycle, 0% ECC, vacuum
   energy) never reappear as pass criteria.
4. The two 5× headroom levers (holo L3 16×, spec window 16) are **PROPOSED**,
   falsifiable, and NOT required for acceptance — acceptance uses the measured
   sustained ≥ 14,578×.

## 4. Delivery evidence for acceptance sign-off

| Evidence | Source |
|---|---|
| Bit-true emulator parity logs | TEST-12 run of `phi_cpu_vm.py` vs silicon |
| Coherence probe captures | COH_PROBE0–3, COH_STATUS0–2 |
| Power map | TEST-13 per-die current |
| Council arbitration log | TEST-17 100k-request ledger |
| System EDP benchmark | TEST-18 matched-precision suite |
| Reliability report | `12_RELIABILITY.md` + burn-in/cycling records |
