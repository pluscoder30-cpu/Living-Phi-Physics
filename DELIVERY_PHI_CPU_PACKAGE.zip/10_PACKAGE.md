# 10 — PHI-CPU PACKAGE

> Package type, ball map, die attach, flip-chip, 2.5D interposer placement,
> thermal path, and junction targets. The CPU die is packaged on the shared
> 2.5D interposer with the phi-GPU, phi-RAM, and hologram-engine dies (BOM C).

## 1. Package

| Item | Value |
|---|---|
| Type | **BGA, 16 × 16 mm, 289 balls (17 × 17 array)** |
| Ball pitch | 1.0 mm |
| Substrate | Φ-routed traces, 4F optical waveguides, repeater ≤ 0.7786λ (BOM C2) |
| Package clock | 4.0135 GHz × 10 IO tiers (f·d = 40,134.946, [VERIFIED] C04) |
| Die attach | **Flip-chip** (C4 bumps) on 2.5D interposer (BOM C1) |
| Thermal | Heat spreader (Φ-graded thickness, 1.270·σT⁴ emissivity, BOM C6) + cold plate |
| I/O | 161 die pads → BGA balls; mesh/hologram data plane via interposer microbumps |

## 2. Ball map (17 × 17 = 289 balls)

Rows A–Q, columns 1–17. Functional sectors:

| Sector | Balls | Function |
|---|---|---|
| Outer ring (row A, row Q, col 1, col 17) | 64 balls | VDD_IO (2.618 V) + GND + control (RESET, JTAG, UART, clock refs) |
| Second ring | 104 balls | VDD_LL (0.618 V) + VDD (1.0 V) + scan/coherence probes |
| Core array | 112 balls | Signal (fabric mesh, hologram link) + VDD_HI (1.618 V) + spares |
| Center 3×3 (I8–I10, J8–J10, K8–K10) | 9 balls | GND/thermal relief + critical VDD (1.0 V) |

Power-ball distribution: VDD_LL ~24, VDD ~34, VDD_HI ~22, VDD_IO ~30, GND ~62
(total ~172 power/ground; remaining 117 signal/control/spare). Exact ball→pin
netlist is generated at package signoff from `09_IO_PINOUT.md` (every die pad
must land on a ball; the sector map above guarantees each rail and each signal
class has assigned balls).

## 3. Die attach & interposer

- Flip-chip C4 microbumps on the 2.5D interposer; 161 die pads distributed over
  the die face.
- **2.5D interposer** co-locates the phi-CPU, phi-GPU, phi-RAM, and hologram
  dies (BOM C1). The fabric mesh (2 planes, 128 B/cycle, 328 GB/s [VERIFIED]
  F02) and hologram engine link route through interposer metal — the CPU's
  wide data plane does not travel through package balls.
- Power TSVs and thermal TSVs co-located at Φ-density (0.0325 K/W path,
  [VERIFIED] F05).

## 4. Thermal path

| Segment | R_th | Source |
|---|---|---|
| Die → package | ≤ **0.1 K/W** | heat spreader + flip-chip |
| Package → cold plate | ≤ **0.02 K/W** | cold plate, 25 °C nominal (BOM C5) |
| Total die-to-coolant | ≤ 0.12 K/W | |
| Junction (target) | **51 °C** | [VERIFIED] F05 (phi-CPU 51.0 °C @ 242 W, corrected power map) |

Thermal verification (F05): all dies < 100 °C — CPU 51.0, GPU 33.1, RAM 26.1,
holo-die 31.5 °C. TEST-14 re-verifies on silicon with the parallel TSV path.

## 5. Operating and storage

| Parameter | Value |
|---|---|
| Junction, operating | −40 … +125 °C (nom 51 °C target) |
| Storage | −65 … +150 °C |
| Power | 242 W/die nominal; TEST-13 bound ≤ 800 W |
| Socket / ATE | Stage-1: 40-pin socketable, <1 GHz (BOM D1); full system: 3.472 GHz-class probe card, 55.7° phase window (BOM D2) |
