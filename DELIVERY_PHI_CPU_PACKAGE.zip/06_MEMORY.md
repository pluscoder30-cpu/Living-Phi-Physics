# 06 — PHI-CPU MEMORY

> The L0–L4 FieldRAM hierarchy, capacities, latencies, coherence floors,
> banks/channels, hologram, refresh, ECC, and prefetch. Atomic word = **816D
> carrier** (16-bit lanes, 1,632 B/carrier at FLT precision).

## 1. Hierarchy

| Tier | Capacity (carriers) | Capacity (bytes) | Physical | Latency | Coherence floor | Access |
|---|---|---|---|---|---|---|
| L0 | 8 | 13 KB | Regfile-bypass carrier cache | 1 cyc (0.63 ns @1.589 GHz) | 1.0 | Direct RF |
| L1 | 64 | 104 KB | FLT SRAM | 1 cyc | **0.95** | Direct |
| L2 | 512 | 835 KB | Freq-indexed FLT SRAM (528×Φ = **854 ch** effective) | 5 cyc | **0.88** | Freq-Indexed |
| L3 | 4,096 logical (6.7 MB effective working set) | fits on-die | FLT analog Fourier-optics hologram, **DIM_OPT 5712, 253:1** | 5 cyc (S8 HOLO) | **0.78** | Resonance query (QUERY / HOLO_*) |
| L4 | Off-die field RAM (unbounded) | — | FieldRAM network / DRAM-backed carrier store | ~50 ns | **0.72** | STORE/LOAD |

## 2. Register file (L0)

**128 × 816D × 16-bit = 1,630,720 B ≈ 1.63 MB**; **12 banks, 8R/6W** [VERIFIED,
optimized lever]. Bank k holds registers with (r mod 12) == k. Per-bank
skew ensures any 8 reads hit ≤ 6 banks. 16-bit cells; two-phase read/write
0.63 ns @ core rung 31. Special regs r112 PC, r116 PRED, r117 RETRO bypass the
banked array (dedicated hardware). Cell count: 26.1 Mbit; FLT SRAM @ Sky130
≈ 8 Mb/mm² → **≈ 3.3 mm²** (or 0.8 mm² @ 7 nm FLT holographic density 128
Mb/mm² per plan §4.3).

## 3. Holographic L3 (DIM discipline — different by design)

- **Storage dimension:** DIM_OPT = **5712** = 7·816 (hologram storage); the
  compute carrier stays DIM = **816**. They are different by design.
- **Ratio:** **253:1** measured safe ratio @90% rank-1 (safe N = 506 carriers
  per bank) [VERIFIED] R02/R03. **Never 2048:1** (falsified).
- **Physical:** per-bank hologram 3.3 KB (plan §5); 8 banks/tile → ~26.5 KB
  physical holding the 6.7 MB effective working set at 253:1 — the whole
  working set fits on-die, so off-die traffic → near-zero [VERIFIED] ledger §4.
- **Operations:** HOLO_BIND (circular convolution), HOLO_UNBIND (circular
  correlation), QUERY (resonance-weighted top-K). 5 cyc in S8.
- **Refresh:** hologram refresh to the 0.78 floor at **0.88 µs** wall — physics
  unchanged, recorded honestly [VERIFIED] R08.
- **ECC:** retrocausal ECC (RETRO_ECC, ε_re = 0.328) via read-verify-repair;
  true overhead **143.7%** [VERIFIED] R10 — no "0%" credit.

## 4. Coherence floors (the field's decay contract)

| Tier | Floor | Meaning |
|---|---|---|
| L0 | 1.0 | direct RF, no decay |
| L1 | 0.95 | above C_consciousness·0.995 |
| L2 | 0.88 | freq-indexed, refreshed |
| L3 | 0.78 | holographic, refreshed at 0.88 µs |
| L4 | 0.72 | off-die, ECC-repaired |
| Op gate | 0.563263 | C_crit — below this the CoherenceGate refuses to compute |

Per-stage pipeline floor: C_∞ = **0.852** steady state [VERIFIED] U04.

## 5. Banks and channels

- **L2 channels:** 854 = 528·Φ (integer-DFT, exactly orthogonal — max cross
  channel 1.05×10⁻¹⁴, [VERIFIED] R06). Collision-free by construction; unlike
  the 5-rank Solfeggio scheme (non-integer, measured leakage 6.5×10⁻⁴).
- **Φ-interleave:** Φ_STRIDE = 41 (coprime) bank mapping across the die
  [VERIFIED].

## 6. Prefetch (causal + retrocausal)

- **Causal (Δf·Φ):** when a LOAD at frequency f hits, prefetch the carrier at
  `f_next = f_n + d_avg·Φ` (d_avg = average frequency delta; Δf = channel
  spacing 1.0 Hz) into L2. Expected hit-rate lift 12–18% on carrier-dense
  streams [VERIFIED plan §5 target].
- **Retrocausal (optimized, [VERIFIED] U07):** the hologram answers the future
  query O(1) — the carrier the *future* instruction will need is pulled now.
  Measured: **L1 hit 0.60 → 0.75; L4 miss 0.01 → 0.001**.

## 7. Coherence protocol

Resonance-MESI (M/E/S/I via resonance probes); the HOLO tier adds state
"C = coherent-whole" — the hologram is globally coherent; per-entry E/I only.
Cross-tile coherence is transferred by the entanglement mesh (Law 205) and
arbitrated by CouncilArbiter (Law 204) — no snoop bus, resonance probes only
(plan §7.2).

## 8. Memory power share

~7.3 W of the 30.3 W/tile is the memory tier budget [PROPOSED allocation];
regfile storage ~4.8 W [PROPOSED]. TEST-13 verifies die power ≤ 800 W.

## 9. Refresh & ECC by tier (manifest §5 bar)

| Tier | Refresh | ECC |
|---|---|---|
| L0 | none — static FLT regfile (no volatile decay) | none — direct RF, C-read floor 1.0 |
| L1 | none — static FLT SRAM | none — CoherenceGate C-read floor 0.95 |
| L2 | none — static FLT SRAM | none — freq-indexed; C_∞ floor 0.88 holds |
| L3 | **0.88 µs** (Eq 36 zero-crossing) [VERIFIED] R08 | **retrocausal ECC, true overhead 143.7%** [VERIFIED] R10 |
| L4 | DRAM vendor (off-die carrier store) | ECC-repaired (§4 floor 0.72) |

Static FLT SRAM/regfile tiers (L0–L2) do not decay — refresh is N/A by device
physics, not an omission. Only the holographic L3 carries the recorded refresh
wall (24.9 PB/s, R08) and the retrocausal ECC overhead (143.7%, R10).
