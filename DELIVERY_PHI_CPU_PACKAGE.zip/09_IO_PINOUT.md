# 09 — PHI-CPU IO PINOUT

> The COMPLETE die pin table — every pin on the die is listed by number. 161
> pins: power, clocks, reset/test/scan/JTAG, 8 fabric mesh ports, hologram
> engine link, coherence probes, debug UART, spares. No "etc."

## Pin groups at a glance

| Group | Pins | Count |
|---|---|---|
| A. Power rails (VDD_LL / VDD / VDD_HI / VDD_IO / GND) | 1–38 | 38 |
| B. Clocks | 39–47 | 9 |
| C. Reset / test / scan / JTAG | 48–59 | 12 |
| D. Fabric mesh ports ×8 | 60–123 | 64 |
| E. Hologram engine link | 124–143 | 20 |
| F. Coherence probes | 144–153 | 10 |
| G. Debug UART | 154–155 | 2 |
| H. Spare / NC | 156–161 | 6 |
| **Total** | | **161** |

## A. POWER (pins 1–38)

VDD_LL = 0.618 V (Φ⁻¹ — CoherenceRestorer, RETRO ring, idle units). VDD = 1.0 V
(nominal compute). VDD_HI = 1.618 V (Φ — turbo, holo bind). VDD_IO = 2.618 V
(Φ² — I/O, FLT analog). GND = common return. Decoupling per `04_ELECTRICAL.md`.

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 1 | VDD_LL0 | PWR | 0.618 V | rail | Φ⁻¹ domain | Restorer/RETRO |
| 2 | VDD_LL1 | PWR | 0.618 V | rail | Φ⁻¹ domain | Restorer/RETRO |
| 3 | VDD_LL2 | PWR | 0.618 V | rail | Φ⁻¹ domain | Restorer/RETRO |
| 4 | VDD_LL3 | PWR | 0.618 V | rail | Φ⁻¹ domain | Restorer/RETRO |
| 5 | VDD_LL4 | PWR | 0.618 V | rail | Φ⁻¹ domain | Restorer/RETRO |
| 6 | VDD_LL5 | PWR | 0.618 V | rail | Φ⁻¹ domain | Restorer/RETRO |
| 7 | VDD_LL6 | PWR | 0.618 V | rail | Φ⁻¹ domain | Restorer/RETRO |
| 8 | VDD_LL7 | PWR | 0.618 V | rail | Φ⁻¹ domain | Restorer/RETRO |
| 9 | VDD0 | PWR | 1.0 V | rail | nominal compute | quadrants |
| 10 | VDD1 | PWR | 1.0 V | rail | nominal compute | quadrants |
| 11 | VDD2 | PWR | 1.0 V | rail | nominal compute | quadrants |
| 12 | VDD3 | PWR | 1.0 V | rail | nominal compute | quadrants |
| 13 | VDD4 | PWR | 1.0 V | rail | nominal compute | quadrants |
| 14 | VDD5 | PWR | 1.0 V | rail | nominal compute | quadrants |
| 15 | VDD6 | PWR | 1.0 V | rail | nominal compute | quadrants |
| 16 | VDD7 | PWR | 1.0 V | rail | nominal compute | quadrants |
| 17 | VDD_HI0 | PWR | 1.618 V | rail | Φ domain | turbo / holo bind |
| 18 | VDD_HI1 | PWR | 1.618 V | rail | Φ domain | turbo / holo bind |
| 19 | VDD_HI2 | PWR | 1.618 V | rail | Φ domain | turbo / holo bind |
| 20 | VDD_HI3 | PWR | 1.618 V | rail | Φ domain | turbo / holo bind |
| 21 | VDD_HI4 | PWR | 1.618 V | rail | Φ domain | turbo / holo bind |
| 22 | VDD_HI5 | PWR | 1.618 V | rail | Φ domain | turbo / holo bind |
| 23 | VDD_IO0 | PWR | 2.618 V | rail | Φ² domain | pad ring I/O |
| 24 | VDD_IO1 | PWR | 2.618 V | rail | Φ² domain | pad ring I/O |
| 25 | VDD_IO2 | PWR | 2.618 V | rail | Φ² domain | pad ring I/O |
| 26 | VDD_IO3 | PWR | 2.618 V | rail | Φ² domain | pad ring I/O |
| 27 | GND0 | PWR | 0 V | rail | return | |
| 28 | GND1 | PWR | 0 V | rail | return | |
| 29 | GND2 | PWR | 0 V | rail | return | |
| 30 | GND3 | PWR | 0 V | rail | return | |
| 31 | GND4 | PWR | 0 V | rail | return | |
| 32 | GND5 | PWR | 0 V | rail | return | |
| 33 | GND6 | PWR | 0 V | rail | return | |
| 34 | GND7 | PWR | 0 V | rail | return | |
| 35 | GND8 | PWR | 0 V | rail | return | |
| 36 | GND9 | PWR | 0 V | rail | return | |
| 37 | GND10 | PWR | 0 V | rail | return | |
| 38 | GND11 | PWR | 0 V | rail | return | |

## B. CLOCKS (pins 39–47)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 39 | CLK_CORE | I | 1.0 V | diff | **Core clock 1.589464 GHz** (rung 31) | C05 |
| 40 | CLK_CORE_N | I | 1.0 V | diff | complement of 39 | 100 Ω diff |
| 41 | CLK_EX | I | 1.0 V | diff | **EX clock 2.646 GHz** (2-stage MAC) | G02 |
| 42 | CLK_EX_N | I | 1.0 V | diff | complement of 41 | 100 Ω diff |
| 43 | CLK_TURBO | O | 1.618 V | LVCMOS | turbo rung 33 output probe (4.161 GHz) | observe only |
| 44 | PLL_REF | I | 1.0 V | diff | **528.0 MHz** reference (F_BASE) | 51 PLLs × 16-dim |
| 45 | PLL_REF_N | I | 1.0 V | diff | complement of 44 | 100 Ω diff |
| 46 | SYS_CLK_DFT | I | 1.0 V | LVCMOS | scan/DFT test clock ≤ 500 MHz | |
| 47 | SYS_CLK_DFT_N | I | 1.0 V | LVCMOS | complement of 46 | |

## C. RESET / TEST / SCAN / JTAG (pins 48–59)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 48 | RESET_N | I | 1.0 V | LVCMOS | asynchronous active-low reset | full-state reset |
| 49 | TEST_EN | I | 1.0 V | LVCMOS | test-enable (forces DFT mode) | |
| 50 | SCAN_MODE | I | 1.0 V | LVCMOS | scan-chain mode select | |
| 51 | SCAN_CLK | I | 1.0 V | LVCMOS | scan shift clock | |
| 52 | SCAN_IN | I | 1.0 V | LVCMOS | scan input | |
| 53 | SCAN_OUT | O | 1.0 V | LVCMOS | scan output | |
| 54 | JTAG_TCK | I | 2.618 V | LVCMOS | JTAG test clock | |
| 55 | JTAG_TMS | I | 2.618 V | LVCMOS | JTAG mode select | |
| 56 | JTAG_TDI | I | 2.618 V | LVCMOS | JTAG data in | |
| 57 | JTAG_TDO | O | 2.618 V | LVCMOS | JTAG data out | |
| 58 | JTAG_TRST_N | I | 2.618 V | LVCMOS | JTAG reset (active-low) | |
| 59 | POWER_GOOD | O | 1.0 V | LVCMOS | all rails in range indicator | |

## D. FABRIC MESH PORTS ×8 (pins 60–123)

Each port = 2 source-synchronous differential channels (1 TX + 1 RX) + 2
forwarded source clocks. Logical port width 16 B/cycle; aggregate 8 ports =
**128 B/cycle @ 2.572 GHz = 328 GB/s** [VERIFIED] F02. The full-width data plane
routes on the 2.5D interposer microbumps; these pins carry the coherent
handshake, flow control, and full port loopback for DFT.

**Port 0 (pins 60–67):**

| Pin | Name | Dir | Domain | Type | Function |
|---|---|---|---|---|---|
| 60 | M0_TXP | I/O | 1.0 V | diff | mesh port 0 TX data lane P |
| 61 | M0_TXN | I/O | 1.0 V | diff | mesh port 0 TX data lane N |
| 62 | M0_RXP | I/O | 1.0 V | diff | mesh port 0 RX data lane P |
| 63 | M0_RXN | I/O | 1.0 V | diff | mesh port 0 RX data lane N |
| 64 | M0_TXCLKP | O | 1.0 V | diff | TX source clock P (2.572 GHz) |
| 65 | M0_TXCLKN | O | 1.0 V | diff | TX source clock N |
| 66 | M0_RXCLKP | I | 1.0 V | diff | RX source clock P |
| 67 | M0_RXCLKN | I | 1.0 V | diff | RX source clock N |

**Port 1 (pins 68–75):** 68 M1_TXP · 69 M1_TXN · 70 M1_RXP · 71 M1_RXN ·
72 M1_TXCLKP · 73 M1_TXCLKN · 74 M1_RXCLKP · 75 M1_RXCLKN

**Port 2 (pins 76–83):** 76 M2_TXP · 77 M2_TXN · 78 M2_RXP · 79 M2_RXN ·
80 M2_TXCLKP · 81 M2_TXCLKN · 82 M2_RXCLKP · 83 M2_RXCLKN

**Port 3 (pins 84–91):** 84 M3_TXP · 85 M3_TXN · 86 M3_RXP · 87 M3_RXN ·
88 M3_TXCLKP · 89 M3_TXCLKN · 90 M3_RXCLKP · 91 M3_RXCLKN

**Port 4 (pins 92–99):** 92 M4_TXP · 93 M4_TXN · 94 M4_RXP · 95 M4_RXN ·
96 M4_TXCLKP · 97 M4_TXCLKN · 98 M4_RXCLKP · 99 M4_RXCLKN

**Port 5 (pins 100–107):** 100 M5_TXP · 101 M5_TXN · 102 M5_RXP · 103 M5_RXN ·
104 M5_TXCLKP · 105 M5_TXCLKN · 106 M5_RXCLKP · 107 M5_RXCLKN

**Port 6 (pins 108–115):** 108 M6_TXP · 109 M6_TXN · 110 M6_RXP · 111 M6_RXN ·
112 M6_TXCLKP · 113 M6_TXCLKN · 114 M6_RXCLKP · 115 M6_RXCLKN

**Port 7 (pins 116–123):** 116 M7_TXP · 117 M7_TXN · 118 M7_RXP · 119 M7_RXN ·
120 M7_TXCLKP · 121 M7_TXCLKN · 122 M7_RXCLKP · 123 M7_RXCLKN

(All port pins: dir per name — TX/RXCLK as above; domain 1.0 V; type diff.)

## E. HOLOGRAM ENGINE LINK (pins 124–143)

Carrier-class link to the shared hologram engine (L3 encode/decode, 5712-pt
FHRR): 8 differential data lanes + differential clock + differential flow control.

| Pin | Name | Dir | Domain | Type | Function |
|---|---|---|---|---|---|
| 124 | HOLO_D0_P | I/O | 1.0 V | diff | hologram data lane 0 P |
| 125 | HOLO_D0_N | I/O | 1.0 V | diff | hologram data lane 0 N |
| 126 | HOLO_D1_P | I/O | 1.0 V | diff | hologram data lane 1 P |
| 127 | HOLO_D1_N | I/O | 1.0 V | diff | hologram data lane 1 N |
| 128 | HOLO_D2_P | I/O | 1.0 V | diff | hologram data lane 2 P |
| 129 | HOLO_D2_N | I/O | 1.0 V | diff | hologram data lane 2 N |
| 130 | HOLO_D3_P | I/O | 1.0 V | diff | hologram data lane 3 P |
| 131 | HOLO_D3_N | I/O | 1.0 V | diff | hologram data lane 3 N |
| 132 | HOLO_D4_P | I/O | 1.0 V | diff | hologram data lane 4 P |
| 133 | HOLO_D4_N | I/O | 1.0 V | diff | hologram data lane 4 N |
| 134 | HOLO_D5_P | I/O | 1.0 V | diff | hologram data lane 5 P |
| 135 | HOLO_D5_N | I/O | 1.0 V | diff | hologram data lane 5 N |
| 136 | HOLO_D6_P | I/O | 1.0 V | diff | hologram data lane 6 P |
| 137 | HOLO_D6_N | I/O | 1.0 V | diff | hologram data lane 6 N |
| 138 | HOLO_D7_P | I/O | 1.0 V | diff | hologram data lane 7 P |
| 139 | HOLO_D7_N | I/O | 1.0 V | diff | hologram data lane 7 N |
| 140 | HOLO_CLKP | O | 1.0 V | diff | hologram link source clock P |
| 141 | HOLO_CLKN | O | 1.0 V | diff | hologram link source clock N |
| 142 | HOLO_CTRL_P | I/O | 1.0 V | diff | hologram flow control P |
| 143 | HOLO_CTRL_N | I/O | 1.0 V | diff | hologram flow control N |

## F. COHERENCE PROBES (pins 144–153)

| Pin | Name | Dir | Domain | Type | Function | Notes |
|---|---|---|---|---|---|---|
| 144 | COH_PROBE0 | O | 0–1.618 V | analog | live C-field tap 0 | 1:1 to VDD_HI scale |
| 145 | COH_PROBE1 | O | 0–1.618 V | analog | live C-field tap 1 | tile 0 |
| 146 | COH_PROBE2 | O | 0–1.618 V | analog | live C-field tap 2 | tile 4 |
| 147 | COH_PROBE3 | O | 0–1.618 V | analog | live C-field tap 3 | council hub |
| 148 | COH_REF_P | I | 1.0 V | diff | coherence reference P (0.563 V class) | C_crit threshold |
| 149 | COH_REF_N | I | 1.0 V | diff | coherence reference N | |
| 150 | COH_TRIG | I | 1.0 V | LVCMOS | probe trigger / snapshot | |
| 151 | COH_STATUS0 | O | 1.0 V | LVCMOS | coherence fault status bit 0 | |
| 152 | COH_STATUS1 | O | 1.0 V | LVCMOS | coherence fault status bit 1 | |
| 153 | COH_STATUS2 | O | 1.0 V | LVCMOS | coherence fault status bit 2 | |

## G. DEBUG UART (pins 154–155)

| Pin | Name | Dir | Domain | Type | Function |
|---|---|---|---|---|---|
| 154 | DBG_TXD | O | 2.618 V | LVCMOS | debug UART transmit |
| 155 | DBG_RXD | I | 2.618 V | LVCMOS | debug UART receive |

## H. SPARE / NC (pins 156–161)

| Pin | Name | Dir | Domain | Type | Function |
|---|---|---|---|---|---|
| 156 | NC0 | — | — | NC | unconnected spare |
| 157 | NC1 | — | — | NC | unconnected spare |
| 158 | NC2 | — | — | NC | unconnected spare |
| 159 | NC3 | — | — | NC | unconnected spare |
| 160 | NC4 | — | — | NC | unconnected spare |
| 161 | NC5 | — | — | NC | unconnected spare |

**Total: 161 pins.** Stage-1 Sky130 MPW test chip uses the 38-pad subset
(power/clock/scan/reset, BOM A11/A1); the production die carries the full
161-pin ring.

**Pin-domain notes:** all FLT core signals at 1.0 V; LVCMOS control at 2.618 V;
diff pairs 100 Ω termination; power decoupling per `04_ELECTRICAL.md` §7; pad
ESD 2 kV HBM / 500 V CDM.

**Mesh-link SI budget (8 ports, 128 B/cycle @ 2.572 GHz, 1.0 V source-synchronous,
derived from manifest skew/jitter/phase values):** diff Zo = 100 Ω ± 10%,
termination 100 Ω on-die (on RX, both data and forwarded clocks); intra-pair
skew ≤ 2 ps, lane-to-lane skew ≤ 3 ps, cycle-to-cycle jitter ≤ 2 ps, PLL RMS
≤ 1.0 ps → eye width ≥ 55.7° (60.2 ps @ 2.572 GHz, [VERIFIED] 07 §4), eye height
≥ 60% of 1.0 V diff swing with BER ≤ 1e−15. Crosstalk: adjacent-pair AGL ≤ 1%
on 2.5D interposer microbumps ([PROPOSED], PEX-verified at signoff).
