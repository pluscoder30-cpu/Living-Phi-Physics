# 12 — PHI-CPU RELIABILITY

> ESD, latchup, electromigration, IR drop, aging (BTI/HCI), temperature
> cycling, burn-in, and MTBF targets. The survival contract.

## 1. ESD & latchup

| Item | Target | Status |
|---|---|---|
| ESD — Human Body Model | **2 kV** (all pins) | [VERIFIED] design rule; TEST at package |
| ESD — Charged Device Model | **500 V** | [VERIFIED] design rule |
| Latchup trigger current | **100 mA** (JEDEC JESD78 class) | [PROPOSED] silicon-verified |
| ESD clamp | Φ-spaced pad ring, 2.618 V IO class (BOM A11) | [VERIFIED] |
| ESD test standard | HBM per **JEDEC JS-001**; CDM per **JEDEC JS-002** | [PROPOSED] at package |
| Machine Model | **N/A** — MM withdrawn from JS-001 Rev E+; no MM test | [VERIFIED] policy |

## 2. Electromigration

| Metal | Max current density | Status |
|---|---|---|
| METAL1 | 1.0 mA/µm | [PROPOSED] at 105 °C |
| METAL2 | 1.2 mA/µm | [PROPOSED] |
| METAL3 | 1.5 mA/µm | [PROPOSED] |
| METAL4 | 2.0 mA/µm | [PROPOSED] |
| METAL5 | 3.0 mA/µm (power/clock) | [PROPOSED] |
| Via/contact | J_max_via + via-chain/fat-via rules per foundry PDK EM deck | [PROPOSED] |
| Lifetime model | Black's: MTTF = A·J⁻ⁿ·e^(Ea/kT); n = 2 (Cu), Ea per PDK; signoff via PEX | [PROPOSED] |

Design margin: worst-case power lane at 242 W/die with co-located power TSVs;
EM lifetime ≥ 10 years at junction ≤ 125 °C.

## 3. IR drop

| Item | Target |
|---|---|
| Dynamic droop (any 1-cycle 8-wide burst @ EX 2.646 GHz) | ≤ 5% VDD |
| Static IR drop at 242 W/die | ≤ 5% VDD (with power-TSV Φ-density grid) |
| Decoupling | per `04_ELECTRICAL.md` §7 (40/30/25/20 nF on-die; µF-class on-package) |

## 4. Aging (BTI / HCI)

| Item | Target |
|---|---|
| Lifetime | **10-year** target @ 125 °C, 242 W/die |
| ΔV_T budget | ≤ 30 mV (worst-case BTI + HCI) |
| Drive degradation | ≤ 5% I_ON at end of life |
| Guardband | σV_T/μ = 5% + aging guardband in timing closure |
| Acceleration | Ea (BTI/HCI) + voltage-acceleration factor from PDK reliability deck |
| I_DS over temp | bias-gate comp holds I_DS within **±3%** of 25 °C value over −40…+125 °C (TEST-6 extension) |

Status [PROPOSED] — silicon-verified by TEST-6 Monte Carlo (1,000 samples @ 5% σ)
and long-run burn-in.

## 5. Temperature cycling & burn-in

| Item | Spec |
|---|---|
| Temperature cycling | **−40 … +125 °C, 1,000 cycles** (JEDEC JESD22-A104) |
| Burn-in | **48 h** at 125 °C, V_max (VDD_IO 2.618 V class), active scan |
| Thermal chamber | −40…+125 °C (BOM D6) |

## 6. MTBF target

| Item | Target |
|---|---|
| MTBF | **≥ 1,000,000 h** (FIT ≤ 1,000 @ 55 °C) |
| Coherence-fault rate | 0 faults in 10⁶ instr [VERIFIED] sim; silicon via COH_STATUS + TEST-12 |
| Council livelock | 0 in 100,000 requests [VERIFIED] U05 |
| Confidence level | **60 %** (χ² lower bound on FIT), stated in qual report |

Status of MTBF number: [PROPOSED] system target — the sim-verified coherence
fault count (0, [VERIFIED] U06 context) and council livelock (0, [VERIFIED] U05)
support the design-level expectation.

## 7. Reliability test placement

Mapped into the manufacturing flow: ESD/latchup at package (with TEST-14
thermal + probe card), EM/IR in design signoff (PEX), aging via burn-in + TEST-6
Monte Carlo, cycling in the thermal chamber (BOM D6). Every survival number
traces to `12_RELIABILITY.md` → TEST_PLAN → acceptance in `14_ACCEPTANCE.md`.
