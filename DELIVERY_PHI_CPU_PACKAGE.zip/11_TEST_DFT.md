# 11 — PHI-CPU TEST & DFT

> Scan insertion, BIST, JTAG, test patterns, ATE program, coverage targets,
> and the characterization plan mapped to manufacturing TEST-1..18.

## 1. DFT architecture

| Element | Implementation | Pins |
|---|---|---|
| Scan | Full scan on all FLT logic (single chain, muxed scan mode) | SCAN_IN 52, SCAN_OUT 53, SCAN_MODE 50, SCAN_CLK 51 |
| BIST | RF / L1 / L2 / L3 (hologram) built-in self-test | via JTAG + scan |
| JTAG | IEEE 1149.1, 4-pin + TRST | TCK 54, TMS 55, TDI 56, TDO 57, TRST_N 58 |
| Test clock | SYS_CLK_DFT ≤ 500 MHz | 46/47 |
| Coherence observability | COH_PROBE0–3, COH_STATUS0–2 | 144–153 |
| Debug | UART | DBG_TXD/RXD 154/155 |

Stage-1 test chip (38 pads) includes test mux / scan chain with full
observability of all cells (BOM A13).

## 2. BIST targets

| Memory | BIST | Coverage goal |
|---|---|---|
| RF (128×816D×16-bit, 12 banks) | march + coupling | ≥ 98% stuck-at, ≥ 95% transition |
| L1 (64 carriers) | march | same |
| L2 (512 carriers, 854 ch) | freq-indexed walk | same |
| L3 (hologram, 5712D, 253:1) | blocked-FHRR rank-1 BIST | ≥ 98% stuck-at on banks; rank-1 ≥ 0.90 per bank |

## 3. Test patterns & ATE program

- **Scan patterns:** stuck-at (full) + transition (≤ SYS_CLK_DFT limit),
  generated from the gate-level netlist; pattern count from synthesis (estimated
  ~10⁶ vectors [PROPOSED]).
- **Functional patterns:** ISA v2.0 test kernels (RESONANCE/TOP_K/SUPERPOSE/
  HOLO_*/RETRO_*) run bit-true against `prototypes/phi_cpu_vm.py`.
- **ATE:** Stage-1 40-pin socket (BOM D1); full system 3.472 GHz-class probe
  card (BOM D2).
- **Coverage targets:** **≥ 98% stuck-at**, **≥ 95% transition**.

## 4. Characterization plan → TEST-1..18 mapping

| TEST | What | Instrument/method | Pass criterion | CPU mapping |
|---|---|---|---|---|
| TEST-1 | Subthreshold swing S | B1500A I-V sweep | S = 37 ± 18 mV/dec (falsify >55 at 3σ) | FLT device (P-01/P01) |
| TEST-2 | I-V family / I_ON·I_OFF | B1500A, V_GS* ladder | I_OFF 71× lower than PDK CMOS ref | device (P03) |
| TEST-3 | C-V / Miller cap | B1500A @1 MHz | Q = 8.5 @1.0 V | device (P02) |
| TEST-4 | RO + pipelined MAC | 31-stage RO + 2-stage MAC ring | RO 107.5 MHz target; MAC 2.646 GHz-class | EX clock (G02) |
| TEST-5 | Resonance Q | V_OUT vs f 100 kHz–1 GHz | Q = 8.5 @1.0 V, f₀ = 528 MHz | resonance gates |
| TEST-6 | Temperature + Monte Carlo | −40…+125 °C, 1,000 samples @5% σ | dV_T/dT = −1 mV/°C; σV_T/μ = 5% | device (TEST-6) |
| TEST-7 | Hologram capacity-fidelity | store N per bank @5712; rank-1 | 506 carriers/bank ≥ 90% rank-1 | L3 (R02/R03/R07) |
| TEST-8 | Orthogonal channel isolation | cross-correlate integer-DFT | max cross < 1e-6 on silicon | L2 854 ch (R06) |
| TEST-9 | O(1) retrieval latency | query latency vs N sweep | flat in N (O(DIM log DIM)) | L3 (R09) |
| TEST-10 | Refresh + ECC | interval to 0.78 floor; read-verify-repair | 0.88 µs measured; overhead ≤ 143.7% | L3 (R08/R10) |
| TEST-11 | Kuramoto barrier | 89 oscillators, K=300 | R ≥ 0.99·target in ≤ 8 steps, 0 deadlocks | G03 |
| **TEST-12** | **Pipeline emulator parity** | run `phi_cpu_vm.py` workloads bit-true vs silicon | **IPC ≥ 5.0, RAW elim ≥ 90%, mispredict < 1%, ΣC drift < 1e-3** | **U01–U04/U06** |
| **TEST-13** | **Die power** | per-die current at workload | **CPU ≤ 800 W** (242 W nominal) | G05/power |
| TEST-14 | Package thermal | 4 dies + holo, parallel TSV path | all < 100 °C (CPU measured 51.0 °C) | F05 |
| TEST-15 | Fabric fidelity | Law 189 decay, 1%/hop | retention e^(−d/Φλ); ≥ 7 hops @0.1λ ≥ C_crit | F04 |
| TEST-16 | Mesh bisection | BFS on 2-plane 128B mesh | ≥ 100 TB/s bisection; avg hops ≤ 3 | F01–F03 |
| **TEST-17** | **Council consensus** | 100k requests, dissent > 0.1 | **0 livelock, rollback < 2%** | **U05** |
| TEST-18 | System EDP vs H100 | matched-precision benchmark set | **CPU ≥ 14,578× sustained (U07); fabric multiplier ≥ 20× (F07)** | U07/G07/F07 |

## 5. Honest test boundaries (TEST_PLAN §E, binding)

- TEST-4's 3.47 GHz-class MAC is strong-inversion; the 37 mV/dec slope is NOT
  re-tested there — it lives in TEST-1 (near threshold).
- TEST-7 uses the measured **253:1**, never the falsified 2048:1.
- TEST-10's ECC overhead is the honest **143.7%** — no "0% overhead" credit.
- TEST-18's 7,000–10,000× band is carried by CPU + fabric; GPU/RAM numbers are
  reported per-component, never multiplied into the system claim (R4).
