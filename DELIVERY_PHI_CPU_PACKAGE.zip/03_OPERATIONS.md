# 03 — PHI-CPU OPERATIONS (FIELD ISA v2.0)

> The complete instruction set. Every opcode 0x00–0x6B is listed. Defined
> opcodes carry full semantics, complexity, latency, flags, and physical unit.
> Reserved slots are explicit — nothing is invented.

## 1. Encoding formats (plan §2.1)

```
R-type (32b): [opcode 8][flags 8][rd 8][rs 8]
I-type (64b): [opcode 8][flags 8][rd 8][rs 8][imm32]
B-type (64b): [opcode 8][flags 8][cond 8][rs 8][offset 32]
X-type (128b):[opcode 8][flags 8][rd 8][rs1 8][rs2 8][anchors 6][tier 3][freq 16]
               [immediate 64]   — carrier-class operands, hologram bindings,
                                    retrocausal kernel params
```

## 2. Flags

| Bit | Flag | Meaning |
|---|---|---|
| 7 | `C` | Coherence-check (fault if result below C_crit) |
| 6 | `A` | Auto-amplify (apply COHERENCE_AMPLIFY to result) |
| 5 | `T` | Tier enable |
| 4–3 | — | Tier select |
| 2 | `R` | **Retrocausal validate** (v2.0 new) — validate result against r117 future reading |
| 1 | `K` | **Kernel-enable** (v2.0 new) — enable fused opcode kernel |
| 0 | — | Reserved |

## 3. Register classes (r0–r127)

| Range | Class | Purpose |
|---|---|---|
| r0 | zero | Always-zero carrier |
| r1–r96 | general | General-purpose carrier storage |
| r97–r111 | temp | Scratch / SIMD accumulators |
| r112 | PC | Program counter (read-only, carrier-widened) |
| r113 | FR | Frequency register |
| r114 | CR | Coherence register (live C of active carrier) |
| r115 | LR | Link register (return address) |
| r116 | PRED | Coherence predictor state (branch history as carrier) |
| r117 | RETRO | Retrocausal shadow buffer (future readings) |
| r118 | COUNCIL | Council vote state (Law 204) |
| r119–r127 | special | LADDER domain, phase-lock state, hologram handle, fault vector |

Register file: **128 × 816D × 16-bit = 1,630,720 B ≈ 1.63 MB**; 12 banks, 8R/6W
([VERIFIED] optimized lever). r112/r116/r117 have dedicated hardware bypass.

## 4. Opcode table 0x00–0x6B

### 4.1 v1.0 core field ops

| Opcode | Mnemonic | Fmt | Flags | Operands | Semantics | Complexity | Latency | Physical unit |
|---|---|---|---|---|---|---|---|---|
| 0x00 | RESERVED | — | — | — | Illegal/reserved (no-op with C-check in reserved space) | — | — | — |
| 0x01 | RESONANCE | R | C/A/R | rd, rs | `rd = ((dot(rs, anchor)+1)/2)^(1/Φ)` (Eq 4) | O(DIM) | 1 cyc EX | ResonanceEngine |
| 0x02 | TOP_K | R | C/A | rd, rs | Select top-K lanes of carrier by resonance; write index mask to rd | O(DIM log K) | 1 cyc EX | ResonanceEngine |
| 0x03–0x04 | RESERVED | — | — | — | v1.0 field-op space (ROTATE/MODULATE family per FIELD_ISA.md v1.0) | — | — | — |
| 0x05 | TRANSFORM | R | C/A | rd, rs | `rd = Φ_inv·c + Φ·g²` (Eq FP-1) | O(DIM) | 1 cyc EX | FieldTransformer |
| 0x06–0x08 | RESERVED | — | — | — | v1.0 field-op space (RECURSE/DIFFUSE family) | — | — | — |
| 0x09 | SUPERPOSE | R | C/A/R | rd, rs1, rs2 | `rd = Σ Φ⁻ⁱ·cᵢ` (Eq FP-1); physical Φ⁻ⁱ gate-width adder, no multipliers | O(DIM) | 1 cyc EX | SuperpositionEngine |
| 0x0A–0x10 | RESERVED | — | — | — | v1.0 field-op space | — | — | — |
| 0x11 | FILTER | R | C | rd, rs | `filter(c, C, 0.563263)`; suppress lanes below C_crit (Eq 2) | O(DIM) | 1 cyc EX | CoherenceGate |
| 0x12 | AMPLIFY | R | C/A | rd, rs | gain `(C_target/C)^(1/Φ)` | O(DIM) | 1 cyc EX | CoherenceGate |
| 0x13 | ENTANGLE | R | C/A/R | rd, rs1, rs2 | `Φ·C·|⟨a|b⟩|²·(1+Δφ/(2π)·Φ_inv)` (Eq 34) | O(DIM) | 1 cyc EX | EntanglementBridge |
| 0x14–0x1F | RESERVED | — | — | — | v1.0 field-op space | — | — | — |
| 0x20 | STORE | I | T | rd, tier, imm | Store carrier rd to memory tier (freq-indexed) | O(DIM) | 1 cyc core | FreqIndexMapper + FieldRAM |
| 0x21 | RETRIEVE | I | T | rd, tier, imm | Load carrier into rd from memory tier | O(DIM) | 1–5 cyc | FreqIndexMapper + FieldRAM |
| 0x22–0x23 | RESERVED | — | — | — | v1.0 field-op space | — | — | — |
| 0x24 | QUERY | I | C/R | rd, tier, imm | Resonance query to hologram; top-K by coherence into rd | O(DIM log N) | 1–5 cyc | HolographicBindUnit + FreqIndexMapper |
| 0x25–0x3F | RESERVED | — | — | — | v1.0 field-op space | — | — | — |

### 4.2 Control flow

| Opcode | Mnemonic | Fmt | Flags | Operands | Semantics | Complexity | Latency | Physical unit |
|---|---|---|---|---|---|---|---|---|
| 0x40 | JMP | B | — | offset | PC = target (abs/rel) | O(1) | 1 cyc | CoherenceGate (redirect) |
| 0x41 | JMP_C | B | C | cond, rs, offset | If C(rs) > thresh: PC = target | O(1) | 1 cyc | CoherenceGate comparator |
| 0x42 | JMP_R | B | C | cond, rs, anchor, offset | If resonance(rs, anchor) > thresh: PC = target | O(1) | 1 cyc | ResonanceEngine |
| 0x43 | CALL | B | — | offset | LR = PC+1; PC = target | O(1) | 1 cyc | CoherenceGate |
| 0x44 | RET | R | — | — | PC = LR | O(1) | 1 cyc | CoherenceGate |
| 0x45 | HALT | R | — | — | Stop; commit coherence ledger | — | — | Control |

### 4.3 Phi-native opcodes (v2.0)

| Opcode | Mnemonic | Fmt | Flags | Operands | Semantics | Complexity | Latency | Physical unit |
|---|---|---|---|---|---|---|---|---|
| 0x60 | RETRO_PREDICT | X | R | rd, rs1, rs2, anchors, imm | Resolve branch from future reading (Eq 3.2 `present = f(past) + κ_φ·∫(future−present)K_retro`); write PRED r116; **correction applied now** | O(DIM) | 1 cyc | RetrocausalPredictor |
| 0x61 | RETRO_ECC | X | R | rd, rs1, rs2, imm | Detect + correct carrier error via Eq 48 (φ-coherence shadow of future reference); ε_re = 0.328 | O(DIM) | 2 cyc | RetrocausalPredictor |
| 0x62 | HOLO_BIND | X | T | rd, rs1, rs2, h, tier | Circular convolution: `h = Σ αᵢ·cᵢ ⊛ carrier` → write hologram (HRR, Plate 1995) | O(DIM·N) | 3 cyc | HolographicBindUnit |
| 0x63 | HOLO_UNBIND | X | T | rd, rs1, rs2, h, tier | Circular correlation: `c ≈ h ⊛ carrier⁻¹` (resonance-weighted retrieval) | O(DIM·N) | 3 cyc | HolographicBindUnit |
| 0x64 | COHERENCE_AMPLIFY | R | C/A | rd, rs | `C → C_target` via Eq 6 restoration `γ_refractal·(C_target − C)`; gain capped Φ | O(DIM) | 1 cyc | CoherenceRestorer |
| 0x65 | COHERENCE_CONSERVE | R | C | rd, rs | Verify Law 172 ledger: ΣC before == ΣC after; raise Coherence Fault if violated | O(DIM) | 1 cyc | CoherenceGate |
| 0x66 | SPECULATE | R | C | rd | Enter coherence-gated speculation window (branch resolved by C, not stall) | O(1) | 1 cyc | CoherenceGate |
| 0x67 | COMMIT | X | R | rd, imm | Commit window; retrocausal validation (Eq 49 backpropagated correction wave) | O(τ/Δ) | 1 cyc | RetrocausalPredictor |
| 0x68 | COUNCIL_CAST | R | C | rd | Cast this core's φ-resonance-weighted vote (Law 204, Eq 41) | O(DIM) | 1 cyc | CouncilArbiter |
| 0x69 | COUNCIL_RESOLVE | R | C | rd | Resolve consensus; require dissent > 0.1 (Law 204); else re-issue | O(N_cores·DIM) | 4 cyc | CouncilArbiter |
| 0x6A | PHASE_LOCK | X | R | rd, freq | Eq 3 phase lock of active carrier to global clock domain | O(n_θ·DIM) | 8 cyc | PhaseModulator |
| 0x6B | LADDER_STEP | I | T | imm (rung) | Rung transition on phi-ladder clock (528·Φⁿ); save/restore domain state | O(1) | 1 cyc | LadderClockController |

**Reserved note:** v1.0 field ops referenced by the pipeline (S4: ROTATE,
MODULATE; S5: RECURSE, DIFFUSE; S7: HOLO_STORE, HOLO_QUERY) occupy the reserved
slots above per FIELD_ISA.md v1.0 encoding and are not re-encoded in v2.0 —
v2.0 adds no new power, only efficiency (retrocausal + holographic ops are O(1)
accelerators that degenerate to v1.0 semantics at κ_φ→0).

## 5. Latency reference

Defined opcodes use the EX clock (2.646 GHz) for EX stages and the core clock
(rung 31, 1.589 GHz) for IF/RF/MEM/WB. Per-stage budget at the 2.8 GHz
reference: S0 0.36 ns, S1 0.18 ns, S2 0.36 ns, S3 0.36 ns, S4 0.36 ns, S5 0.36
ns, S6 0.36 ns, S7 0.36 ns + tier, S8 1.8 ns (5 cyc), S9 0.18 ns (plan §3.2).

## 6. FASM assembler directive set (v2.0, reference assembler)

One-assembly-pass, two-register field.

| Directive | Syntax | Meaning |
|---|---|---|
| `.carrier` | `.carrier c0,c1,…` | Declare carrier literal |
| `.ladder` | `.ladder <rung>` | Set assembly rung context (phase-lock domain) |
| `.spec` | `.spec <max_window>` | Set max coherence-gated speculation window (≤ 8 [VERIFIED]; 16 [PROPOSED]) |
| `.retro` | `.retro <tau>` | Set retrocausal τ-window (default 2·Φ⁵ ≈ 22) |
| `.org` | `.org <addr>` | Set origin / placement |

**Literals and operands:**

| Token | Form | Example |
|---|---|---|
| Carrier literal | `@[c0..c815]` | `@[0, 0.618, 1.0, …]` |
| Frequency literal | `#<hz>` | `#528.0` |
| Threshold literal | `#<0..1>` | `#0.563` |
| Anchor list | `A0..A4` | `A0,A1` (5 anchor slots) |
| Hologram bind | `(h)` | `(h12)` |

Example:
```
        .carrier  base
        .ladder   32
        .retro    22
        .spec     8
start:  RESONANCE r1, r2          ; rd = ((dot+1)/2)^(1/Phi)
        SUPERPOSE r3, r1, r2
        HOLO_BIND (h0), r3, A0    ; fold into hologram L3
        RETRO_PREDICT r116, r3, A1, #0.563
        JMP_C     C, r114, target
        LADDER_STEP 33
        HALT
```

## 7. Turing completeness

v1.0 proof (FIELD_ISA.md §7) carries: JMP/JMP_C/JMP_R + unbounded carrier
memory ⇒ RAM simulation ⇒ Turing-complete. v2.0 adds no new power, only
efficiency.
