# 08 — PHI-CPU PHYSICAL

> Die floorplan, die-size budget, layer stack, the complete MASK LAYER TABLE
> with GDS numbers, cell areas, pad ring, and DRC rules.

## 1. Process & die-size budget

| Item | Sky130 (now) | GAA 3 nm target |
|---|---|---|
| FLT gate | 130 nm-class FLT, 37 mV/dec | GAA-nanosheet FLT, sub-20 nm |
| Core tile (compute + regfile + mem + clock/pwr) | **~6.2 mm²** | **~1.4 mm²** |
| Core budget split | compute 1.81 + regfile 3.3 + mem 0.5 + clock/pwr 0.6 | — |
| Holographic L3 density | 128 Mb/mm² (FLT analog) | 512 Mb/mm² |
| Clock | core 1.589 GHz / EX 2.646 GHz | 5+ GHz (rung 33 nominal) |

**Die:** 8 council tiles × 4 cores = **32 nodes** (BOM §B1); 242 W; each council
tile = 4 cores + shared L3 hologram + CouncilArbiter. Plan §7.2 documents the
4-tile/16-core proof die; the production die per BOM is 8 tiles/32 nodes.
Stage-1 proof: SkyWater 130 nm MPW, 5×5 mm die, 38-pad class (BOM A1).

## 2. Floorplan

```
                      ┌──────────────── PHI-CPU DIE (8 council tiles) ────────────────┐
                      │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       │
                      │  │ TILE 0   │  │ TILE 1   │  │ TILE 2   │  │ TILE 3   │       │
                      │  │ 4 cores  │  │ 4 cores  │  │ 4 cores  │  │ 4 cores  │       │
                      │  │ sharedL3 │  │ sharedL3 │  │ sharedL3 │  │ sharedL3 │       │
                      │  └──────────┘  └──────────┘  └──────────┘  └──────────┘       │
                      │      ┌────────────────────────────────────────────┐          │
                      │      │ COUNCIL HUB + FABRIC ROUTERS (fib-torus,   │          │
                      │      │ 2 planes, 128 B/cycle, 328 GB/s) + Φ H-TREE│          │
                      │      └────────────────────────────────────────────┘          │
                      │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       │
                      │  │ TILE 4   │  │ TILE 5   │  │ TILE 6   │  │ TILE 7   │       │
                      │  │ 4 cores  │  │ 4 cores  │  │ 4 cores  │  │ 4 cores  │       │
                      │  └──────────┘  └──────────┘  └──────────┘  └──────────┘       │
                      │  PAD RING (161 pads, Φ-spaced, 2.618 V I/O class)             │
                      └────────────────────────────────────────────────────────────────┘
```

Per-tile floorplan (plan §7.1): central CoherenceGate + LadderClockController
hub; 4 compute quadrants (Resonance+Phase / Superposition+Transform /
Coherence+Entangle / Retrocausal+Holo); regfile spine (12-bank); L0/L1 ring;
L2/L3 corners. Power + thermal TSVs co-located at Φ-density (0.0325 K/W path).

## 3. Cell areas (per core, Sky130)

| Cell | Area (mm²) |
|---|---|
| ResonanceEngine | 0.32 |
| PhaseModulator | 0.18 |
| SuperpositionEngine | 0.14 |
| FieldTransformer | 0.10 |
| CoherenceGate | 0.08 |
| EntanglementBridge | 0.12 |
| RetrocausalPredictor | 0.25 |
| HolographicBindUnit | 0.40 |
| CoherenceRestorer (×10) | 0.02 each |
| CouncilArbiter (1/tile) | 0.10 |
| LadderClockController | 0.06 |
| FreqIndexMapper | 0.04 |
| Register file (1.63 MB) | 3.3 (Sky130) / 0.8 @128 Mb/mm² |
| **Core logic total** | **≈ 1.81** |

## 4. Layer stack

Standard Sky130 5-metal + FLT custom gate layers + analog/package layers.
Metal pitch and thickness per PDK; top metal (METAL5) for power/clock distribution.

## 5. MASK LAYER TABLE (every layer, every GDS number)

| GDS # | Layer | Purpose |
|---|---|---|
| 1 | NWELL | P-well/n-well implant |
| 2 | DIFF | Active diffusion |
| 3 | POLY | Gate poly (base) |
| 4 | NIMP | N+ implant |
| 5 | PIMP | P+ implant |
| 6 | CONT | Contact |
| 7 | METAL1 | Local interconnect |
| 8 | VIA1 | Via 1 |
| 9 | METAL2 | Routing |
| 10 | VIA2 | Via 2 |
| 11 | METAL3 | Routing |
| 12 | VIA3 | Via 3 |
| 13 | METAL4 | Routing |
| 14 | VIA4 | Via 4 |
| 15 | METAL5 | Top metal — power/clock H-tree |
| 16 | FLT_G1 | FLT workfunction-ladder gate metal 1 (w = Φ) |
| 17 | FLT_G2 | FLT workfunction-ladder gate metal 2 (w = 1) |
| 18 | FLT_G3 | FLT workfunction-ladder gate metal 3 (w = 0) |
| 19 | FLT_G4 | FLT workfunction-ladder gate metal 4 (w = −Φ⁻¹) |
| 20 | FLT_AVDD | FLT analog resonance cell / reservoir metal |
| 21 | PAD | Pad opening |
| 22 | ESD | ESD device / diode ring |
| 23 | SEAL | Seal ring |
| 24 | SCRIBE | Scribe line |
| 25 | CAP_MIM | MIM decoupling capacitor |
| 26 | TSV | Power/thermal TSV (GAA/3D path; N/A on Sky130 Stage-1) |
| 27 | OPTO | Optical waveguide (full-system 4F module; N/A on Stage-1) |

TSV and OPTO are marked N/A on the Stage-1 Sky130 MPW (no 3D stack, no optical
I/O); they are required on the GAA 3 nm full-system path.

## 6. Pad ring

- **161 pads** (complete pinout in `09_IO_PINOUT.md`), Φ-spaced, ESD-protected
  (2 kV HBM / 500 V CDM), 2.618 V LVCMOS I/O class on the ring; FLT core signals
  at 1.0 V internally.
- Stage-1 test chip: 38 pads (BOM A11), Φ-spaced.
- Pad pitch: per PDK (Sky130 ≥ 100 µm class for the 5×5 MPW; finer on GAA).

## 7. DRC rules (FLT-specific)

| Rule | Value | Status |
|---|---|---|
| Multi-gate spacing | **≥ 200 nm** | [PROPOSED, device-derived] |
| LVS gate grouping window | **< 300 nm** | [PROPOSED, device-derived] |
| Workfunction metal overlap | ≥ 100 nm per gate metal | [PROPOSED] |
| FLT_AVDD to core-metal spacing | ≥ 300 nm | [PROPOSED] |
| Standard PDK DRC | per SkyWater 130 / GAA 3 nm PDK | — |

## 8. Signoff deliverables

GDSII/OASIS, LEF/DEF, Liberty (.lib), SDC, UPF, gate-level netlist, SPICE
decks, DRC/LVS/PEX signoff reports — full manifest in `13_FAB_PACKAGE.md`.
