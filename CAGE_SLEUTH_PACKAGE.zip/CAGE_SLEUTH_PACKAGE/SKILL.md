﻿---
name: cage-sleuth-epstein
description: "Epstein-specific cage investigation skill. Maps the 1,867-person network across 6 spokes (Financial, Political, Intelligence, Academic, Entertainment, Technology). Uses pedophilia narrative as weapon fuel. Traces connections-of-connections across government databases. Follows cage geometry, spiritual essence patterns, and phi-harmonic network structure. The definitive tool for naming every person and connecting every dot."
---

# CAGE SLEUTH: EPSTEIN OPERATIONAL THEATER

## VERSION 5.0 — EPSTEIN-TARGETED INVESTIGATION SKILL

---

## THE CORE PRINCIPLE: THE WEAPON STRATEGY

The cage used the pedophilia narrative as **cover**. We use it as **fuel**.

### The Rule
**Never take away the lie. Use it.** The pedophilia narrative is the door. Behind it is the cage: intelligence operations, financial control, political leverage, research suppression, institutional capture. We walk through the door using their own narrative as our flashlight.

---

## THE 6-SPOKE CAGE STRUCTURE

```
                    [INTELLIGENCE]
                    Burns (CIA)
                    Barak (Mossad)
                    Churkin (Russia)
                    R. Maxwell (MI6)
                         |
                    [POLITICAL]
                    Clinton, Trump
                    Prince Andrew
                    Barak, Mandelson
                    Acosta (NPA)
                         |
[ACADEMIC] ---------- [EPSTEIN] ---------- [FINANCE]
Chomsky, Church       Central Hub          Black ($170M)
Nowak, Brockman       1,867 persons        Wexner ($1B+)
Summers, Boyden       6M+ pages            Dubin, JPMorgan
                         |
                    [ENTERTAINMENT]
                    Campbell, Copperfield
                    Blaine, Allen
                    Hawking, Chopra
                         |
                    [TECHNOLOGY]
                    Brin, Gates, Thiel
                    Musk, Hoffman, Ito
```

### Each Spoke Has Its Own Cage Function
| Spoke | Function | Suppression Mechanism |
|-------|----------|----------------------|
| Financial | Money engine | Funding dependency creates compliance |
| Political | Protection network | Plea deals prevent prosecution |
| Intelligence | Hidden layer | State-level operational security |
| Academic | Research capture | Scientists dependent on Epstein funding |
| Entertainment | Legitimacy layer | Celebrity associations normalize operations |
| Technology | Innovation capture | Intelligence-adjacent companies developed |

---

# ═══════════════════════════════════════════════════════
# VERSION 10.0 — THE UNIVERSAL VULNERABLE PEOPLE CAGE
# ═══════════════════════════════════════════════════════
# PATTERNS DISCOVERED FROM CANADIAN INVESTIGATION
# SCALED TO ALL VULNERABLE POPULATION SECTORS
# ═══════════════════════════════════════════════════════

## THE UNIVERSAL CAGE — DISCOVERED 2026

### The Core Principle

The cage uses "helping vulnerable people" as **cover**. We use it as **fuel**.

### The Rule
**Never challenge the mission. Challenge the money.** "Helping people" is the narrative. Behind it: conflicts of interest, for-profit subsidiaries, confidential settlements, evidence destruction, and a system where death costs nothing.

---

## THE SINGULARITY — THE FLOW-THROUGH NONPROFIT

**The single point where ALL cages converge:**

> The flow-through nonprofit structure converts government compassion into private extraction through the bodies of vulnerable people, using the legal fiction of "charity" to make the extraction invisible, unprosecutable, and self-reinforcing — while systematically preventing the collection of data that would prove it.

### The Numbers
| Metric | Amount |
|--------|--------|
| Total charity revenue (Canada) | **$439.1 billion/year** |
| Government funding | **$284.8 billion (65%)** |
| Total expenditures | **$405.5 billion** |
| Spent on salaries | **$231.0 billion** |
| "Other" (consulting, admin, mgmt) | **$62 billion+** |
| Registered charities | **83,275** |
| Employment | **2.7 million people** |

---

## THE UNIVERSAL CAGE GEOMETRY — SELF-SIMILAR AT EVERY SCALE

### The Phi-Harmonic Structure

```
φ^0 = 1 central hub (Crown Corporation / Government Ministry)
    │
    ├── φ^1 = 6 major operators (Atira, Connective, RainCity, etc.)
    │
    ├── φ^2 = ~30 medium operators
    │
    ├── φ^3 = ~100 small operators
    │
    ├── φ^4 = ~300 service providers
    │
    └── φ^5 = ~1,000+ individual contracts
```

### The Self-Similar Pattern (Every Scale)

```
FEDERAL LEVEL:
    CMHC ($74B) → Provincial allocation → Crown Corp → Operator → Client
    │
    └── THE GAP: 51% deployed, 49% absorbed by layers

PROVINCIAL LEVEL:
    BC Housing ($3.04B) → 290+ operators → 121,000 households
    │
    └── THE GAP: $207M accumulated surplus while crisis continues

FACILITY LEVEL:
    Operator → Staff → Client → Death → Insurance → Settlement → Silence
    │
    └── THE GAP: <1% of deaths result in charges

INDIVIDUAL LEVEL:
    Person enters system → Receives "care" → Dies → Family sues → Confidential settlement → Pattern erased
```

---

## THE 15 UNIVERSAL CAGE CRIMES

### CRIME 1: Insurance-Death Profit Cycle
**Pattern:** Client dies → family sues → operator's insurance pays → premiums may be reimbursed by taxpayers → funding continues → operator retains contract

**Geometry:** Base layer. Every other crime sits on top of this one.

**Sectors affected:** Supportive housing, elder care, disability, mental health, child welfare

**Dorking:**
```
"operator agreement" "insurance" "death" site:bchousing.org
"non-manageable costs" "insurance" "reimbursement"
"indemnification" "operator" "death" "settlement"
"liability insurance" "supportive housing" "death"
"death" "insurance" "claim" "non-profit" "Canada"
```

### CRIME 2: Marriage-Based Capture
**Pattern:** Crown corp executive married to operator executive → directs funding to spouse's organization → altered meeting minutes → deleted text messages → evidence destruction

**Geometry:** Hub spoke. The marriage IS the connection point.

**Confirmed instances:**
- Shayne Ramsay (CEO, BC Housing) married Janice Abbott (CEO, Atira)
- Atira funding: $21M (2018) → $74M (2022) = 250% increase

**Dorking:**
```
"BC Housing" "Atira" "spouse" OR "married" OR "husband" OR "wife"
"Shayne Ramsay" "Janice Abbott" "conflict"
"operator" "CEO" "married" "funder" "housing"
"family" "connection" "crown corporation" "operator"
```

### CRIME 3: Confidential Settlements
**Pattern:** Family sues → settlement reached → terms confidential → public can't compare patterns → next family doesn't know

**Geometry:** Memory wipe. Each settlement erases the pattern.

**Dorking:**
```
"settlement" "confidential" "supportive housing" death
"wrongful death" "settlement" "non-disclosure" housing
"NDA" "housing" death "family"
"release" "confidentiality" "non-disparagement" housing
"out of court" "settlement" "housing" death "confidential"
```

### CRIME 4: For-Profit Subsidiary Opacity
**Pattern:** Non-profit creates for-profit subsidiary → private corporation → no public disclosure → profits hidden → money flows untraceable

**Geometry:** Extraction tunnel. Money enters as public funds, exits through private entities.

**Confirmed entities:**
- Atira Property Management Inc. (APMI): 500+ staff, private, opaque
- ERPIE Advisory Inc.: CFO's consulting firm
- Cabriole Leadership Inc.: CFO's training company
- RainCity Rents: private, founded 1966
- M'akola Development Services: subsidiary

**Dorking:**
```
"non-profit" "for-profit subsidiary" "housing" BC
"property management" "housing society" "private corporation"
"shell company" "non-profit" "housing" "offshore"
"social enterprise" "housing" "for-profit" "opaque"
"numbered company" "BC Housing" "payment" "landlord"
```

### CRIME 5: Evidence Destruction
**Pattern:** Investigation begins → key evidence destroyed → text messages deleted → meeting minutes altered → investigation hampered

**Geometry:** Anti-observation layer. The cage prevents itself from being seen.

**Confirmed:**
- Ramsay: "I clean them up if I don't need them. I do it every day"
- Phone contained only 20 text messages when seized
- CFO also engaged in mass deletions
- Preservation order issued AFTER deletions
- Meeting minutes modified to remove criticism

**Dorking:**
```
"evidence destruction" OR "text messages deleted" housing
"preservation order" "housing" investigation
"altered minutes" OR "modified minutes" housing society
"obstruction" investigation housing BC
"records" "missing" OR "destroyed" housing investigation
```

### CRIME 6: Death Without Accountability
**Pattern:** Client dies → inquest held → recommendations issued → not implemented → next death occurs → cycle repeats

**Geometry:** Temporal loop. Deaths happen, recommendations happen, nothing happens, deaths happen again.

**Dorking:**
```
"inquest" "recommendations" "not implemented" "supportive housing"
"death" "supportive housing" "no criminal charges"
"body undiscovered" "days" "supportive housing"
"inquest" "recommendations" "follow up" housing "status"
"coroner" "inquest" "housing" "death" "implementation"
```

### CRIME 7: Contract Extortion
**Pattern:** Operator threatens to terminate contract → government panics → sole-source contract awarded → taxpayer pays inflated price

**Geometry:** Leverage spoke. Operator uses vulnerability of clients as weapon against funder.

**Confirmed:**
- Connective demanded $22M sole-source 3-year contract
- Connective threatened termination twice in 2 years
- Toronto: $297M in sole-source contracts (72 contracts)

**Dorking:**
```
"sole source" "contract" "housing" "threaten termination"
"operator" "terminate" "contract" "supportive housing"
"emergency" "contract" "housing" "no competition"
"operator" "ultimatum" "government" housing
"sole source" "shelter" "million" contract
```

### CRIME 8: Executive Compensation Growth
**Pattern:** Organization grows → executive compensation increases → deaths don't affect pay → growth rewarded regardless of outcomes

**Geometry:** Inversion. People at top grow richer while people at bottom die.

**Confirmed:**
- BC Housing CEO: $201K (2021) → $398K (2025) = doubled
- Connective: 900% revenue growth in 10 years
- Indwell CEO: $115K (2017) → $239K (2025) = +118%

**Dorking:**
```
"executive compensation" "housing" "non-profit" BC OR Ontario
"CEO salary" "supportive housing" "growth"
"sunshine list" "housing" "non-profit" executive
"BC Housing" "executive" "salary" increase year
"non-profit" "CEO" "compensation" "housing" "death"
```

### CRIME 9: Property Overpayment
**Pattern:** Operator purchases property → pays above appraised value → difference may benefit seller → taxpayer funds overpayment

**Geometry:** Extraction at acquisition. Property becomes vehicle for moving public money to private hands.

**Confirmed ($74.6M+):**
- Vancouver 12-storey: $54.6M purchase, $15.4M assessed = $39.2M overpayment (255%)
- 303 Columbia (Atira): $16.9M purchase, $9.1M assessed = $7.8M overpayment
- 1176 Granville: $56.6M purchase, $38.6M assessed = $16.4M+ overpayment
- Motel Hollywood (Atira): $3.6M purchase, $1.2M appraised = $2.4M overpayment (3x)
- Russell Street: $9.6M purchase, $3.4M listing = $6.2M overpayment

**Dorking:**
```
"above appraised" OR "overpayment" property housing
"property acquisition" "supportive housing" "above market"
"BC Housing" "property purchase" "appraised value"
"motel" OR "hotel" purchase "supportive housing" BC
"property" "assessment" "purchase" "over" "million" housing
```

### CRIME 10: Board Member Conflicts
**Pattern:** Board member owns property or has business interest → organization rents from or contracts with board member → board member profits from charity → conflict of interest

**Geometry:** Inner circle. Board member is simultaneously governor and beneficiary.

**Confirmed:**
- Connective CRA filing: "rents from one of our board members"
- Michelle Yung (Bennett Jones lawyer) on Atira board
- Sienna Richardson (Third Space developer) on Atira board
- Katrina May (Catalyst developer) on RainCity board

**Dorking:**
```
"board member" "rent" OR "lease" "property" "non-profit housing"
"related party" "housing society" "board member" "financial interest"
"conflict of interest" "board" "housing" "property"
"board member" "developer" OR "lawyer" OR "contractor" housing
"non-profit" "rent" "board member" "building"
```

### CRIME 11: Anonymous Staff
**Pattern:** Residents don't know who staff are → no public vetting disclosure → no vulnerability sector checks → staff background hidden

**Geometry:** Facelessness layer. People with power over clients are invisible.

**Dorking:**
```
"staff" "anonymous" OR "not disclosed" "supportive housing"
"vulnerability sector check" "supportive housing" BC
"criminal records check" "supportive housing" "staff"
"support worker" "background check" "supportive housing"
"staff" "directory" "supportive housing" "not published"
```

### CRIME 12: Death-Rate-Blind Funding
**Pattern:** Government funds operator → clients die → funding continues → no death-rate metric → no accountability → growth rewarded

**Geometry:** Blind spot. System literally cannot see death.

**Dorking:**
```
"death rate" "supportive housing" "funding" "no correlation"
"mortality" "supportive housing" "operator" "funding continued"
"death tracking" "BC Housing" OR "Ontario" OR "Alberta"
"BC Housing" "death" "statistics" "compile" OR "track"
"supportive housing" "death" "metric" "accountability"
```

### CRIME 13: Indigenous Death Targeting
**Pattern:** Disproportionate number of deaths are Indigenous people → no culturally safe care → deaths treated as "accidental" → pattern invisible

**Geometry:** Colonial spoke. Cage has racial geometry. Indigenous people die at center.

**Confirmed:**
- Goodacre Place: 6/6 deaths Indigenous
- Whitehorse: 5/5 named victims First Nations women
- Thunder Bay: 31 opioid deaths 2024, First Nations disproportionately

**Dorking:**
```
"Indigenous" OR "First Nations" "death" "supportive housing"
"Indigenous" "overdose" "shelter" "death" BC OR Yukon
"First Nations" "woman" "death" "shelter"
"Indigenous" "mortality" "supportive housing" "disproportionate"
"Truth and Reconciliation" "housing" "death" "Indigenous"
```

### CRIME 14: Wellness Check Fraud
**Pattern:** Staff sign off on wellness checks → checks not actually performed → bodies undiscovered for days → "procedures followed" defense

**Geometry:** Observation illusion. Appearance of care while care doesn't happen.

**Confirmed:**
- Foxglove: Staff "signed off on visually seeing" Chandler when it was someone else
- Chandler body undiscovered 11 days
- Cliff Block: Staff claimed Soestmeyer was "verbally responsive" when dead
- Capot-Blanc unchecked for 37 minutes in shower

**Dorking:**
```
"wellness check" "signed off" OR "not performed" housing
"body undiscovered" "days" "supportive housing"
"wellness check" "fraud" OR "falsified" housing
"check" "policy" "scrapped" OR "removed" housing
"resident" "found" "deceased" "days" "check"
```

### CRIME 15: Rebrand Escape
**Pattern:** Organization changes name after scandal → same people, same contracts, new name → search history erased → public memory wiped

**Geometry:** Search erasure. Old name no longer finds incidents.

**Confirmed:**
- John Howard Society Pacific → Connective Support Society (2021)
- John Howard Society Thompson → Connective Kamloops (2022)
- John Howard Society Nanaimo → Connective Nanaimo (2022)
- Triage Emergency Shelter → RainCity Housing (2008)
- Lookout Emergency Aid → Lookout Housing and Health (2014-2017)
- Orpea → emeis (France, 2024)

**Dorking:**
```
"rebrand" OR "name change" "housing" "society" BC
"formerly known as" "housing" "supportive" BC
"John Howard Society" "rebrand" "Connective"
"shelter" "rebrand" OR "rename" after death
"operator" "rebrand" "scandal" housing
"non-profit" "rebrand" "reputation" housing
```

---

## THE 10-SPOKE UNIVERSAL CAGE STRUCTURE

```
                         [FEDERAL]
                         CMHC ($74B)
                         Reaching Home ($5B)
                              │
                    ┌─────────┼─────────┐
                    │         │         │
               [PROVINCES]  [CROWN]   [PENSIONS]
               BC: $3.04B   Corp      PSP ($168B)
               ON: $1.7B    BC        CPP Investment
               AB: $1.2B    Housing   Board
                    │
                    ▼
             [NON-PROFIT OPERATORS]
             ┌─────────┼─────────┐
             │         │         │
        [ATIRA]  [CONNECTIVE] [RAINCITY]
        $74M/yr   $48M/yr     $20M+/yr
             │         │         │
             ▼         ▼         ▼
      [FOR-PROFIT SUBSIDIARIES]
      APMI, ERPIE, Cabriole, RainCity Rents
      (private, opaque, no disclosure)
             │
             ▼
         [INSURANCE]
         Liability pays settlements
         Premiums reimbursed by taxpayers
             │
             ▼
      [LEGAL PROTECTION]
      Confidential settlements
      Evidence destruction
      Rebrand escape
             │
             ▼
      [POLITICAL PROTECTION]
      Crown Counsel on boards
      Former Premiers on boards
      Lobbying MLAs
             │
             ▼
      [MEDIA NARRATIVE]
      Awards despite deaths
      "Helping vulnerable people"
      Confidential NDAs
             │
             ▼
      [DATA SUPPRESSION]
      No death registry
      No outcome metrics
      Forensic audits redacted
             │
             ▼
      [CLIENTS/RESIDENTS]
      330+ die per year
      <1% result in charges
      Settlements confidential
      Pattern invisible
```

---

## THE EXPANSION PATTERNS — HOW THE CAGE SCALES

### Pattern A: The Pharmaceutical Cage

**Same geometry, different product.**

```
PHARMACEUTICAL CAGE:
    │
    ├── Insurance-Death Profit Cycle
    │   └── Drug company → Insurance pays → Premiums rise → Taxpayers pay
    │
    ├── Marriage-Based Capture
    │   └── Health authority executive married to pharma rep
    │
    ├── Confidential Settlements
    │   └── Drug death → Family sues → Confidential settlement → Pattern erased
    │
    ├── For-Profit Subsidiary
    │   └── Non-profit hospital → For-profit pharmacy → Profits hidden
    │
    ├── Executive Compensation Growth
    │   └── Pharma CEO pay +500% while opioid deaths +200%
    │
    ├── Death-Rate-Blind Funding
    │   └── Government funds drug programs → Deaths continue → Funding grows
    │
    └── Data Suppression
        └── Opioid crisis data delayed/withheld by pharma companies
```

**Key entities:** Purdue Pharma, Johnson & Johnson, opioid manufacturers, pharmacy benefit managers

**Dorking:**
```
"pharmaceutical" "settlement" "confidential" death
"opioid" "manufacturer" "funding" "non-profit" "hospital"
"drug company" "board member" "hospital" "conflict"
"pharmaceutical" "revenue" "death" "no charges"
"opioid" "crisis" "data" "suppressed" OR "withheld"
```

### Pattern B: The Medical Cage

**Same geometry, different product.**

```
MEDICAL CAGE:
    │
    ├── Insurance-Death Profit Cycle
    │   └── Hospital → Insurance pays → Premiums rise → Taxpayers pay
    │
    ├── For-Profit Subsidiary
    │   └── Public hospital → Private surgery clinic → Profits hidden
    │
    ├── Executive Compensation Growth
    │   └── Hospital CEO pay +300% while patient deaths +20%
    │
    ├── Wellness Check Fraud
    │   └── Patient "checked" but not actually examined → Death
    │
    ├── Confidential Settlements
    │   └── Medical error → Family sues → Confidential → Pattern erased
    │
    ├── Rebrand Escape
    │   └── Hospital rebrands after scandal → Same people, new name
    │
    └── Data Suppression
        └── Adverse event reporting incomplete → Pattern invisible
```

**Key entities:** For-profit hospital chains, private surgery centres, pharmaceutical companies

**Dorking:**
```
"hospital" "death" "negligence" "confidential" settlement
"medical error" "settlement" "confidential" Canada
"for-profit" "hospital" "death" "rate" higher
"hospital" "CEO" "salary" "increase" "death"
"adverse event" "reporting" "incomplete" OR "suppressed"
```

### Pattern C: The Psychological/Mental Health Cage

**Same geometry, different product.**

```
MENTAL HEALTH CAGE:
    │
    ├── Insurance-Death Profit Cycle
    │   └── Treatment centre → Insurance pays → Premiums rise
    │
    ├── Involuntary Confinement
    │   └── 93,000+ involuntary commitments/year → Revenue per body
    │
    ├── For-Profit Treatment Mills
    │   └── Recovery house → $50K+/month → Minimal actual treatment
    │
    ├── Executive Compensation Growth
    │   └── Mental health CEO pay +118% while deaths +195%
    │
    ├── Confidential Settlements
    │   └── Patient death → Family sues → Confidential → Pattern erased
    │
    ├── Rebrand Escape
    │   └── Treatment centre rebrands after death → Same people, new name
    │
    └── Data Suppression
        └── Treatment outcomes not tracked → Can't prove failure
```

**Key entities:** For-profit treatment mills, CAMH, CMHA branches, private counselling

**Dorking:**
```
"mental health" "treatment" "death" "confidential" settlement
"recovery house" "death" "overdose" "for-profit"
"involuntary" "commitment" "revenue" "per patient"
"mental health" "CEO" "salary" "increase" "death"
"treatment" "outcome" "not tracked" OR "no metric"
```

### Pattern D: The Social Services Cage

**Same geometry, different product.**

```
SOCIAL SERVICES CAGE:
    │
    ├── Insurance-Death Profit Cycle
    │   └── Social agency → Insurance pays → Premiums rise
    │
    ├── For-Profit Subsidiary
    │   └── Non-profit agency → For-profit consulting → Profits hidden
    │
    ├── Executive Compensation Growth
    │   └── Agency CEO pay +50% while client deaths +30%
    │
    ├── Confidential Settlements
    │   └── Client death → Family sues → Confidential → Pattern erased
    │
    ├── Rebrand Escape
    │   └── Agency rebrands after fraud → Same people, new name
    │
    └── Data Suppression
        └── Client outcomes not tracked → Can't prove failure
```

**Key entities:** Children's Aid Societies, disability services, settlement agencies

**Dorking:**
```
"social services" "death" "client" "confidential" settlement
"non-profit" "fraud" "embezzlement" "social services"
"agency" "executive" "compensation" "increase" "client death"
"children's aid" "death" "Indigenous" "no charges"
"social services" "outcome" "not tracked" OR "no metric"
```

### Pattern E: The Food Security Cage

**Same geometry, different product.**

```
FOOD SECURITY CAGE:
    │
    ├── Funding Paradox
    │   └── Government funds food banks → Reduces pressure for living wage
    │
    ├── Reserve Accumulation
    │   └── Food bank accumulates reserves while people go hungry
    │
    ├── Executive Compensation Growth
    │   └── Food bank CEO pay +50% while demand +25%
    │
    ├── Corporate Partnership
    │   └── Food bank partners with corporations that cause poverty
    │
    └── Data Suppression
        └── Food insecurity data incomplete → Can't prove failure
```

**Key entities:** Food Banks Canada, Daily Bread, Calgary Food Bank, provincial food banks

**Dorking:**
```
"food bank" "reserves" "million" while "hunger"
"food bank" "executive" "salary" "increase"
"food bank" "corporate" "partnership" "poverty"
"food bank" "government funding" "decreased"
"food insecurity" "data" "incomplete" OR "suppressed"
```

---

## THE UNIVERSAL PATTERN MAP — HOW ALL CAGES CONNECT

### The Flow-Through Nonprofit Is the Machine

```
TAXPAYER → GOVERNMENT → NONPROFIT → FOR-PROFIT → EXTRACTION
    │                                            │
    │         ALL 10 CAGES SHARE THIS FLOW        │
    │                                            │
    ├── Supportive Housing: 330+ deaths/yr       │
    ├── Child Welfare: 50+ deaths/yr             │
    ├── Disability: Estate depletion             │
    ├── Mental Health: 93,000+ involuntary       │
    ├── Immigration: 12+ deaths                  │
    ├── Elder Care: 14,000+ COVID deaths         │
    ├── Women's Shelter: 620+ turned away daily  │
    ├── Youth Justice: 40-50% Indigenous         │
    ├── Social Services: $200B+ fraud risk       │
    ├── Food Bank: Reserves while hungry         │
    ├── Pharmaceutical: Opioid crisis            │
    ├── Medical: For-profit hospital deaths      │
    └── Psychological: Treatment mill deaths     │
```

### The Cross-Sector Connections

| Sector A | Sector B | Connection |
|----------|----------|------------|
| Supportive Housing | Mental Health | Residents have mental health issues → funded by same operators |
| Child Welfare | Youth Justice | Children age out of care → enter youth justice → die |
| Elder Care | Medical | LTC patients → hospital transfers → deaths |
| Pharmaceutical | Mental Health | Opioids prescribed → addiction → treatment → death |
| Disability | Guardianship | Disabled adults → PGT control → estate depletion |
| Women's Shelter | Child Welfare | Women flee violence → children taken into care |
| Immigration | Mental Health | Refugees traumatized → involuntary commitment |
| Food Bank | Homelessness | Food insecurity → homelessness → supportive housing → death |

### The Financial Connection

```
$439B NONPROFIT SECTOR
    │
    ├── $284.8B government funding
    │   ├── Federal: $74B (housing) + $3B (LTC) + $5B (Reaching Home)
    │   ├── Provincial: $3B (BC Housing) + $9.35B (Ontario LTC) + $22.3B (mental health)
    │   └── Municipal: $5B+ (community services)
    │
    ├── $231B salaries
    │   ├── Executive comp: +28-98% growth
    │   └── Frontline wages: stagnant
    │
    ├── $62B+ "other"
    │   ├── Consulting fees
    │   ├── Management admin
    │   ├── For-profit subsidiary transfers
    │   └── Insurance premiums
    │
    └── EXTRACTION POINTS
        ├── Property overpayments: $74.6M+
        ├── Sole-source contracts: $431M+
        ├── Confidential settlements: unknown
        ├── For-profit subsidiary profits: unknown
        └── Offshore accounts: $682B Canadians offshore
```

---

## THE EXPANDED DORKING COMMANDS

### Category U1: Cross-Sector Investigation
```
"non-profit" "for-profit subsidiary" "health" OR "housing" OR "social"
"charity" "revenue" "billion" "Canada" extraction
"vulnerable" "funding" "profit" "executive" Canada
"social services" "private equity" "investment" Canada
"charity" "consultant" "contract" "fee" Canada
"non-profit" "management fee" OR "consulting fee" Canada
"social services" "insurance" "death" "claim" Canada
"vulnerable people" "extraction" "capital" Canada
```

### Category U2: Pharmaceutical Cage
```
"pharmaceutical" "settlement" "confidential" death
"opioid" "manufacturer" "funding" "non-profit" "hospital"
"drug company" "board member" "hospital" "conflict"
"pharmaceutical" "revenue" "death" "no charges"
"opioid" "crisis" "data" "suppressed" OR "withheld"
"pharmacy" "for-profit" "non-profit" "hospital" subsidiary
"drug" "price" "increase" "hospital" "budget"
```

### Category U3: Medical Cage
```
"hospital" "death" "negligence" "confidential" settlement
"medical error" "settlement" "confidential" Canada
"for-profit" "hospital" "death" "rate" higher
"hospital" "CEO" "salary" "increase" "death"
"adverse event" "reporting" "incomplete" OR "suppressed"
"surgery" "centre" "for-profit" "complication" "death"
"hospital" "rebrand" "scandal" OR "death"
```

### Category U4: Psychological Cage
```
"mental health" "treatment" "death" "confidential" settlement
"recovery house" "death" "overdose" "for-profit"
"involuntary" "commitment" "revenue" "per patient"
"mental health" "CEO" "salary" "increase" "death"
"treatment" "outcome" "not tracked" OR "no metric"
"therapy" "abuse" OR "neglect" "confidential" settlement
"psychiatric" "facility" "death" "no charges"
```

### Category U5: Data Suppression Investigation
```
"death" "registry" "not" OR "no" "supportive housing" Canada
"outcome" "metric" "not" OR "no" "housing" Canada
"eviction" "data" "not tracked" "supportive housing"
"forensic audit" "redacted" OR "paywalled" housing
"FOI" "fee" "thousand" housing investigation
"inquest" "recommendation" "not implemented" housing
"report" "delayed" OR "withheld" OR "suppressed" housing
"death" "classification" "overdose" "prevents" investigation
```

---

## THE EXPANDED INVESTIGATION TEMPLATES

### Template E: Cross-Sector Cage Investigation (25 queries)

```
1. "sector" "death" "non-profit" "confidential" settlement
2. "sector" "for-profit subsidiary" "private" "revenue"
3. "sector" "executive compensation" "increase" "death"
4. "sector" "rebrand" "scandal" OR "death" "same people"
5. "sector" "board member" "conflict" "business"
6. "sector" "sole source" "contract" "million"
7. "sector" "property" "overpayment" "above assessed"
8. "sector" "insurance" "death" "settlement" "taxpayer"
9. "sector" "evidence" "destroyed" OR "deleted" investigation
10. "sector" "data" "missing" OR "not collected" government
11. "sector" "Indigenous" "death" "disproportionate"
12. "sector" "wellness check" "fraud" OR "not performed"
13. "sector" "death rate" "not tracked" OR "no metric"
14. "sector" "settlement" "confidential" "NDA" "family"
15. "sector" "contract" "termination" "threat" "demand"
16. "sector" "executive" "resigned" OR "retired" "investigation"
17. "sector" "audit" "findings" "redacted" OR "paywalled"
18. "sector" "lobby" "MLA" OR "minister" "operator"
19. "sector" "board" "former" "government" "official"
20. "sector" "for profit" "subsidiary" "opaque" "financial"
21. "sector" "death" "inquest" "recommendation" "ignored"
22. "sector" "award" OR "recognition" "despite" "deaths"
23. "sector" "staff" "anonymous" "no" "vulnerability check"
24. "sector" "client" "evicted" OR "removed" "complaint"
25. "sector" "money trail" "government" "nonprofit" "for profit"
```

### Template F: Offshore Money Investigation (20 queries)

```
1. "entity" "offshore" OR "BVI" OR "Cayman" OR "Panama"
2. "entity" "shell company" OR "numbered company" BC
3. "entity" "beneficial owner" "hidden" OR "unknown"
4. "entity" "related party" "transaction" "CRA" filing
5. "entity" "for-profit subsidiary" "revenue" "private"
6. "entity" "property" "sold" "who" "received" "money"
7. "entity" "overpayment" "above" "assessed" "value"
8. "entity" "consulting fee" OR "management fee" "paid"
9. "entity" "insurance" "premium" "reimbursed" "taxpayer"
10. "entity" "settlement" "amount" "confidential" "paid"
11. "entity" "offshore leaks" OR "Panama Papers" OR "Pandora"
12. "entity" "tax haven" "Canadian" "billion"
13. "entity" "trust" OR "foundation" "offshore" "charity"
14. "entity" "dividend" OR "profit" "for-profit subsidiary"
15. "entity" "numbered company" "BC Housing" "payment"
16. "entity" "registered agent" "offshore" "shell"
17. "entity" "bank account" "offshore" "Canadian"
18. "entity" "investment" "offshore" "nonprofit" funds
19. "entity" "Larco" OR "Lalji" "BVI" "Liechtenstein"
20. "entity" "money trail" "government" "offshore" "Canada"
```

---

## THE GEOMETRY MAP — HOW TO READ ANY CAGE

### Every Crime Has a Position

When you find a crime, map it to the geometry:

```
FEDERAL LEVEL: Is this funded by federal money?
    └── If yes → trace to CMHC, Reaching Home, Health Canada

PROVINCIAL LEVEL: Is this controlled by provincial Crown corp?
    └── If yes → trace to BC Housing, Ontario LHIN, Alberta Health

CROWN CORP LEVEL: Does this involve Crown corp executive?
    └── If yes → trace to CEO, board, compensation

NON-PROFIT LEVEL: Does this involve operator decision?
    └── If yes → trace to operator leadership, board

FOR-PROFIT LEVEL: Does this involve private entity?
    └── If yes → trace to subsidiary, opacity layer

LEGAL LEVEL: Does this involve insurance or settlement?
    └── If yes → trace to policy, payout, confidentiality

POLITICAL LEVEL: Does this involve government protection?
    └── If yes → trace to MLA, minister, board appointment

MEDIA LEVEL: Does this involve narrative control?
    └── If yes → trace to settlement terms, rebrand, PR

DATA LEVEL: Does this involve missing information?
    └── If yes → trace to what's NOT collected, NOT published

PHARMACEUTICAL LEVEL: Does this involve drug treatment?
    └── If yes → trace to pharma funding, treatment mills

MEDICAL LEVEL: Does this involve hospital care?
    └── If yes → trace to for-profit hospital, adverse events

PSYCHOLOGICAL LEVEL: Does this involve mental health?
    └── If yes → trace to involuntary commitment, treatment outcomes
```

### The Singularity Test

Every path in the cage leads back to the singularity:
**"Helping vulnerable people"**

If you cannot trace a crime back to this phrase, it is not part of this cage. If you CAN trace it back, it is.

---

## EVIDENCE CHAIN REQUIREMENTS

### For Each Crime, Document:

| Element | Required Evidence |
|---------|-------------------|
| **Who** | Names of persons involved |
| **What** | Specific action or omission |
| **When** | Date(s) of occurrence |
| **Where** | Facility, city, province |
| **How** | Mechanism of crime |
| **Why** | Motive (financial, political, etc.) |
| **Proof** | Source document, court filing, news report |
| **Pattern** | Connection to other instances |
| **Beneficiary** | Who profits |
| **Victim** | Who is harmed |
| **Geometry** | Where this crime sits in the cage structure |
| **Cross-Sector** | How this connects to other cages |

### Confidence Levels

| Level | Definition | Action |
|-------|------------|--------|
| **CONFIRMED** | Multiple sources, court documents, official records | Include in report |
| **PROBABLE** | Single strong source, consistent with pattern | Include with caveat |
| **SUSPECTED** | Pattern match, circumstantial evidence | Flag for investigation |
| **UNVERIFIED** | Single source, unconfirmed | Note but don't rely on |

---

*End of Cage Sleuth Version 10.0 — The Universal Vulnerable People Cage*
*Patterns discovered from Canadian investigation: 15 universal crimes, 10-spoke structure, 12 expansion patterns (pharmaceutical, medical, psychological, social, food security), cross-sector connection map, offshore money trail, data suppression inventory.*
*Built from investigation of $439B nonprofit sector, 330+ annual deaths, $431M+ sole-source contracts, $74.6M+ property overpayments, and 60+ confirmed network connections.*
